package uk.dvla.test.mime.types;

public enum MIMEType {
	
	CSV("text/csv"), 
	XLS("application/vnd.ms-excel"), 
	XLSX("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

	final String mimeType;

	MIMEType(String mimeType) {
		this.mimeType = mimeType;
	}
	
	public String getMimeType() {
		return mimeType;
	}

}
