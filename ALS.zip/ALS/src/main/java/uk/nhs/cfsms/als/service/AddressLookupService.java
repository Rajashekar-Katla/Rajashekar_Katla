package uk.nhs.cfsms.als.service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import uk.nhs.cfsms.als.repository.AddressLookupRepository;
import uk.nhs.cfsms.als.vo.AddressVo;

/**
 * Invokes the repository and returns the result to the controller.
 *
 */
public interface AddressLookupService {

    /**
     * finds the address details for given addressVo object
     * 
     * @param addressVo
     * @return List<AddressVo>
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * 
     */
    List<AddressVo> findByCriteria(final AddressVo addressVo)
            throws IllegalAccessException, InvocationTargetException;

    /**
     * Used for junit testing purpose.
     * 
     * @param addressLookupRepository
     */
    void setAddressRepository(
            final AddressLookupRepository addressLookupRepository);

    /**
     * This method used to copies addressvo properties into address domain
     * properties then insert into data base.
     * 
     * This is used for local testing purpose.
     */
    void createAddresses(List<AddressVo> vos) throws IllegalAccessException,
            InvocationTargetException;
    
    /**
     * @param async
     * Re-indexes the @Indexed domain entity
     */
    public void createIndexes(boolean async);
    
    
}
