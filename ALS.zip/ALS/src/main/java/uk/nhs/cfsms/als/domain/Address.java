package uk.nhs.cfsms.als.domain;

import static org.apache.commons.lang.builder.ToStringBuilder.reflectionToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;

/**
 * Entity class mapped to PAF_ADDRESS_TBL table
 * 
 * @author RKatla
 *
 */
@Entity
@Indexed
@Table(name = "PAF_ADDRESS_TBL")
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "UPRN")
    private long uprn;

    @Field(index = Index.YES, analyze = Analyze.NO, store = Store.YES)
    @Column(name = "POSTCODE")
    private String postCode;

    @Field(index = Index.YES, analyze = Analyze.YES, store = Store.YES)
    @Column(name = "LINE_1")
    private String addressLine1;

    @Field(index = Index.YES, analyze = Analyze.NO, store = Store.NO)
    @Column(name = "LINE_2")
    private String addressLine2;

    @Field(index = Index.YES, analyze = Analyze.NO, store = Store.NO)
    @Column(name = "LINE_3")
    private String addressLine3;

    @Field(index = Index.YES, analyze = Analyze.NO, store = Store.NO)
    @Column(name = "LINE_4")
    private String addressLine4;

    @Field(index = Index.YES, analyze = Analyze.NO, store = Store.NO)
    @Column(name = "LINE_5")
    private String addressLine5;

    @Field(index = Index.YES, analyze = Analyze.NO, store = Store.NO)
    @Column(name = "LINE_6")
    private String addressLine6;

    @Column(name = "ORGANISATION_NAME")
    private String organisationName;

    @Column(name = "DEPARTMENT_NAME")
    private String departmentName;

    public long getUprn() {
        return uprn;
    }

    public void setUprn(long uprn) {
        this.uprn = uprn;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getAddressLine4() {
        return addressLine4;
    }

    public void setAddressLine4(String addressLine4) {
        this.addressLine4 = addressLine4;
    }

    public String getAddressLine5() {
        return addressLine5;
    }

    public void setAddressLine5(String addressLine5) {
        this.addressLine5 = addressLine5;
    }

    public String getAddressLine6() {
        return addressLine6;
    }

    public void setAddressLine6(String addressLine6) {
        this.addressLine6 = addressLine6;
    }

    public String getOrganisationName() {
        return organisationName;
    }

    public void setOrganisationName(String organisationName) {
        this.organisationName = organisationName;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    @Override
    public String toString() {
        return reflectionToString(this);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (uprn ^ (uprn >>> 32));
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Address)) {
            return false;
        }
        Address other = (Address) obj;
        if (uprn != other.uprn) {
            return false;
        }
        return true;
    }

}
