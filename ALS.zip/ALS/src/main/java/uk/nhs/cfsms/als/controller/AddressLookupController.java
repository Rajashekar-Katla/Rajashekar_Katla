package uk.nhs.cfsms.als.controller;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerMapping;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import uk.nhs.cfsms.als.exceptions.ALSException;
import uk.nhs.cfsms.als.service.AddressLookupService;
import uk.nhs.cfsms.als.vo.AddressVo;

/**
 * Spring rest controller, which handles the requests and returns the list of
 * addresses in json format.
 *
 */
@RestController
public class AddressLookupController {

    private static final HttpHeaders HEADERS = new HttpHeaders();
    /**
     * Logger instance for AddressLookupController.class.
     **/
    private static final Logger LOGGER = LoggerFactory
            .getLogger(AddressLookupController.class);

    @Autowired
    AddressLookupService addressLookupService;

    /**
     * This rest method takes address details in json string and returns the
     * list of found addresses from database.
     * 
     * @param jsonAddressString
     * @return List<AddressVo>
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */

    @Async
    @RequestMapping(value = "/address/{jsonAddressString}/**", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<AddressVo>> findAddressByCriteria(
            @PathVariable("jsonAddressString") String jsonAddressString,
            HttpServletRequest request) throws IllegalAccessException,
            InvocationTargetException {

        String mvcPath = (String) request
                .getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);

        jsonAddressString = mvcPath.replace("/address/", "");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("findAddressByCriteria jsonAddressString ["
                    + jsonAddressString + "]");
        }

        final AddressVo addressVo = populateAddressVo(jsonAddressString);
        final List<AddressVo> addressList = addressLookupService
                .findByCriteria(addressVo);
        System.out.println("addressList=="+Arrays.toString(addressList.toArray()));
        final ResponseEntity<List<AddressVo>> entity = new ResponseEntity<List<AddressVo>>(
                addressList, HEADERS, HttpStatus.OK);
        return entity;

    }

    @RequestMapping(value = "/address/create-index/{async}", method = RequestMethod.GET)
    public void createIndexes(@PathVariable("async") boolean async) {
        addressLookupService.createIndexes(async);
    }

    private AddressVo populateAddressVo(final String jsonAddressString) {
        AddressVo addressVo = null;
        try {
            addressVo = new ObjectMapper().readValue(jsonAddressString,
                    AddressVo.class);
        } catch (JsonParseException e) {
            LOGGER.error("JsonParseException while parsing json string: "
                    + e.getStackTrace());
            throw new ALSException(
                    "JsonParseException while parsing json string: "
                            + e.getStackTrace());
        } catch (JsonMappingException e) {
            LOGGER.error("JsonMappingException while parsing json string: "
                    + e.getStackTrace());
            throw new ALSException(
                    "JsonMappingException while parsing json string");
        } catch (IOException e) {
            LOGGER.error("IOException while parsing json string: "
                    + e.getStackTrace());
            throw new ALSException("IOException while parsing json string");
        }
        return addressVo;
    }

}
