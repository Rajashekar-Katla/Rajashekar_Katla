package uk.nhs.cfsms.als.repository;

import java.util.List;

import org.hibernate.search.jpa.FullTextEntityManager;

import uk.nhs.cfsms.als.domain.Address;

/**
 * Address Repository
 * 
 */
public interface AddressLookupRepository {

    /**
     * This method finds the address details for given address object and
     * returns the list of found addresses.
     * 
     * @param address
     * @return List<Address>
     */
    List<Address> findAddressByCriteria(final Address address);

    /**
     * This method used to insert addresses into data base.
     * 
     * This is used for local testing purpose.
     */
    void createAddresses(List<Address> addresses);
    
    /**
     * @param async
     * @return
     * Re-indexes the domain entity (tables) with @Indexed annotation
     */
    FullTextEntityManager reIndexAll(boolean async);
}
