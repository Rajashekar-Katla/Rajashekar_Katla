package uk.nhs.cfsms.als.repository;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.hibernate.CacheMode;
import org.hibernate.search.MassIndexer;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.als.domain.Address;
import uk.nhs.cfsms.als.exceptions.ALSException;

/**
 * This class finds the addresses for given address object
 *
 */
@Repository
public class AddressLookupRepositoryImpl implements AddressLookupRepository {
    /**
     * Logger instance for AddressLookupRepositoryImpl.class.
     **/
    private static final Logger LOGGER = LoggerFactory
            .getLogger(AddressLookupRepositoryImpl.class);

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * This method finds the address details for given address object and
     * returns the list of matching addresses.
     * 
     * @param address
     * @return List<Address>
     */
    public List<Address> findAddressByCriteria(Address address) {
        FullTextEntityManager fullTextEntityManager = org.hibernate.search.jpa.Search
                .getFullTextEntityManager(entityManager);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("findAddressByCriteria For address ["
                    + address.getPostCode() + ", " + address.getAddressLine1()
                    + ", " + address.getAddressLine2() + ", "
                    + address.getAddressLine3() + ", "
                    + address.getAddressLine4() + ", "
                    + address.getAddressLine5() + ", "
                    + address.getAddressLine6() + "]");
        }

        QueryBuilder qb = fullTextEntityManager.getSearchFactory()
                .buildQueryBuilder().forEntity(Address.class).get();
        BooleanQuery finalQuery = new BooleanQuery();

        if (address.getAddressLine1() != null
                && !address.getAddressLine1().isEmpty()) {
            finalQuery.add(
                    qb.keyword().onField("addressLine1")
                            .matching(address.getAddressLine1()).createQuery(),
                    Occur.MUST);
        }
        if (address.getAddressLine2() != null
                && !address.getAddressLine2().isEmpty()) {
            finalQuery.add(
                    qb.keyword().onField("addressLine2")
                            .matching(address.getAddressLine2()).createQuery(),
                    Occur.MUST);
        }
        if (address.getAddressLine3() != null
                && !address.getAddressLine3().isEmpty()) {
            finalQuery.add(
                    qb.keyword().onField("addressLine3")
                            .matching(address.getAddressLine3()).createQuery(),
                    Occur.MUST);
        }
        if (address.getAddressLine4() != null
                && !address.getAddressLine4().isEmpty()) {
            finalQuery.add(
                    qb.keyword().onField("addressLine4")
                            .matching(address.getAddressLine4()).createQuery(),
                    Occur.MUST);
        }
        if (address.getAddressLine5() != null
                && !address.getAddressLine5().isEmpty()) {
            finalQuery.add(
                    qb.keyword().onField("addressLine5")
                            .matching(address.getAddressLine5()).createQuery(),
                    Occur.MUST);
        }
        if (address.getAddressLine6() != null
                && !address.getAddressLine6().isEmpty()) {
            finalQuery.add(
                    qb.keyword().onField("addressLine6")
                            .matching(address.getAddressLine6()).createQuery(),
                    Occur.MUST);
        }
        finalQuery.add(qb.keyword().onField("postCode")
                .matching(address.getPostCode()).createQuery(), Occur.MUST);

        javax.persistence.Query persistenceQuery = fullTextEntityManager
                .createFullTextQuery(finalQuery, Address.class);

        @SuppressWarnings("unchecked")
        List<Address> result = persistenceQuery.getResultList();

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("findAddressByCriteria Found address List [ "
                    + Arrays.toString(result.toArray()) + " ]");
        }
        return result;
    }

    /**
     * @param async
     * @return Re-indexes the domain entity (tables) with @Indexed annotation
     */
    public FullTextEntityManager reIndexAll(boolean async) {
        FullTextEntityManager txtentityManager = org.hibernate.search.jpa.Search
                .getFullTextEntityManager(entityManager);
        MassIndexer massIndexer = txtentityManager.createIndexer()
                .batchSizeToLoadObjects(500).threadsToLoadObjects(5)
                .cacheMode(CacheMode.NORMAL);
        massIndexer.purgeAllOnStart(true);
        txtentityManager.purgeAll(Address.class);
        try {

            if (async) {
                massIndexer.startAndWait();
            } else {
                massIndexer.start();
            }
        } catch (InterruptedException e) {
            LOGGER.error(
                    "InterruptedException occurred while creating ALS DB Indexes: "
                            + e.getStackTrace());
            throw new ALSException(
                    "InterruptedException while FullTextEntityManager creating indexes and starting");
        } finally {
            txtentityManager.flushToIndexes(); // Apply changes to indexes
            txtentityManager.clear(); // Free memory, since the queue is now
                                      // processed
        }
        return txtentityManager;
    }

    /**
     * This method used to insert addresses into data base.
     * 
     * This is used for local testing purpose.
     */

    public void createAddresses(final List<Address> addresses) {
        for (Address address : addresses) {
            entityManager.persist(address);
        }
    }
}
