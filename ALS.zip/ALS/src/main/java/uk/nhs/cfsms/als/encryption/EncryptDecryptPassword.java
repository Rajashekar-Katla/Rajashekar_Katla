package uk.nhs.cfsms.als.encryption;

import org.apache.commons.configuration.ConfigurationException;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EncryptDecryptPassword {

    /**
     * Class LOGGER instance.
     */
    private static final Logger LOGGER = LoggerFactory
            .getLogger(EncryptDecryptPassword.class);

    /**
     * Default private constructor.
     */
    private EncryptDecryptPassword() {
        // prevent external instantiation.
    }

    public static void encryptPropertyValue() throws ConfigurationException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Starting encryption operation");
        }
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword("@lsdbpwd$");
        String encryptedPassword = encryptor.encrypt("D3v3lopm3nt");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Encryption done and encrypted password is : "
                    + encryptedPassword);
        }

    }

    public static String decryptPropertyValue() throws ConfigurationException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Starting decryption");
        }

        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword("@lsdbpwd$");
        String decryptedPropertyValue = encryptor
                .decrypt("FOBUf4U78YmKW39gfGz4LmxnfOExeZqg");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "Decryption done and value is:" + decryptedPropertyValue);
        }
        return decryptedPropertyValue;
    }
}
