package uk.nhs.cfsms.als.exceptions;

/**
 * Custom exception class
 * 
 * @author RKatla
 *
 */

public class ALSException extends RuntimeException {

    private static final long serialVersionUID = -7034897190745766939L;

    /**
     * ALSException Constructor
     * 
     * @param message
     */
    public ALSException(final String message) {
        super(message);
    }

    /**
     * ALSException Constructor
     * 
     * @param message
     * @param cause
     */
    public ALSException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
