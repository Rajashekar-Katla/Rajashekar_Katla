/**
 *
 */
package uk.nhs.cfsms.als.config;

import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import net.bull.javamelody.MonitoredWithAnnotationPointcut;
import net.bull.javamelody.MonitoringSpringAdvisor;
import net.bull.javamelody.SpringDataSourceBeanPostProcessor;

/**
 * Configuration class replacing monitoring-spring.xml.
 * 
 * @author ntones
 */
@Configuration
public class MonitoringConfig {

    /**
     * Advise used to monitor executed methods via annotation.
     * 
     * @return
     */
    @Bean
    public MonitoringSpringAdvisor monitoringAdvisor() {
        MonitoringSpringAdvisor advisor = new MonitoringSpringAdvisor();
        advisor.setPointcut(new MonitoredWithAnnotationPointcut());
        return advisor;
    }

    /**
     * The bean to control proxy creation for advise.
     * 
     * @return
     */
    @Bean
    public DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator() {
        return new DefaultAdvisorAutoProxyCreator();
    }

    /**
     * Bean for monitoring data sources.
     * 
     * @return
     */
    @Bean
    public SpringDataSourceBeanPostProcessor springDataSourceBeanPostProcessor() {
        return new SpringDataSourceBeanPostProcessor();
    }

}
