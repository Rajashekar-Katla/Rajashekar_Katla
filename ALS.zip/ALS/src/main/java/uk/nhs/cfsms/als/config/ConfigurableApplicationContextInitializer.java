package uk.nhs.cfsms.als.config;

import java.io.IOException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import uk.nhs.cfsms.als.exceptions.ALSException;

/**
 * This class loads the environment properties based on the active profile
 * value.
 * 
 * @author RKatla
 *
 */
public class ConfigurableApplicationContextInitializer implements
        ApplicationContextInitializer<ConfigurableApplicationContext> {
    /**
     * Logger instance for ConfigurableApplicationContextInitializer.class.
     **/
    private static final Logger LOGGER = LoggerFactory
            .getLogger(ConfigurableApplicationContextInitializer.class);

    private static final String SPRING_PROFILES_ACTIVE = "spring.profiles.active";
    private static final String SPRING_PROFILE_PROPERTIES = "/spring_profile.properties";

    public void initialize(ConfigurableApplicationContext applicationContext) {
        String profile = null;
        try {
            profile = readProjectProfile(SPRING_PROFILE_PROPERTIES);
        } catch (IOException e) {
            LOGGER.error("Exception while reading spring_profile.properties file" + e.getStackTrace());
            throw new ALSException(
                    "Exception while reading spring_profile.properties file");
        }
        if (profile == null || profile.equalsIgnoreCase(Profile.TEST.name())) {
            applicationContext.getEnvironment().setActiveProfiles(
                    Profile.TEST.name());
        } else if (profile.equalsIgnoreCase(Profile.DEV.name())) {
            applicationContext.getEnvironment().setActiveProfiles(
                    Profile.DEV.name());
        } else if (profile.equalsIgnoreCase(Profile.STAGE.name())) {
            applicationContext.getEnvironment().setActiveProfiles(
                    Profile.STAGE.name());
        } else if (profile.equalsIgnoreCase(Profile.PROD.name())) {
            applicationContext.getEnvironment().setActiveProfiles(
                    Profile.PROD.name());
        }
    }

    private String readProjectProfile(final String propertiesFile)
            throws IOException {
        Resource[] resources = new ClassPathResource[] { new ClassPathResource(
                propertiesFile) };
        Properties props = null;
        props = PropertiesLoaderUtils.loadProperties(resources[0]);
        final String profile = props.getProperty(SPRING_PROFILES_ACTIVE);
        return profile;
    }

    private enum Profile {
        TEST, DEV, STAGE, PROD
    }
}
