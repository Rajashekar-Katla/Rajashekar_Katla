package uk.nhs.cfsms.als.config;

import static org.springframework.orm.jpa.vendor.Database.HSQL;

import java.util.Properties;

import javax.sql.DataSource;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/**
 * This class is to configure the database connections.
 * 
 * @author RKatla
 */

@Configuration
@EnableTransactionManagement
public class PersistenceJPAConfig {
    /**
     * Logger instance for PersistenceJPAConfig.class.
     **/
    private static final Logger LOGGER = LoggerFactory
            .getLogger(PersistenceJPAConfig.class);

    private static final String HIBERNATE_SEARCH_INDEXING_STRATEGY = "hibernate.search.indexing_strategy";

    private static final String HIBERNATE_SEARCH_WORKER_THREAD_POOL_SIZE = "hibernate.search.worker.thread_pool.size";

    private static final String HIBERNATE_SEARCH_WORKER_EXECUTION = "hibernate.search.worker.execution";

    private static final String UK_NHS_CFSMS_ALS_DOMAIN = "uk.nhs.cfsms.als.domain";

    private static final String ADDRESS_PERSISTENCE_UNIT = "addressPersistenceUnit";

    private static final String HIBERNATE_SEARCH_DEFAULT_INDEX_BASE = "hibernate.search.default.indexBase";

    private static final String HIBERNATE_SEARCH_DEFAULT_DIRECTORY_PROVIDER = "hibernate.search.default.directory_provider";

    private static final String HIBERNATE_SHOW_SQL = "hibernate.show_sql";

    private static final String HIBERNATE_DIALECT = "hibernate.dialect";

    private static final String HIBERNATE_HBM2DDL_AUTO = "hibernate.hbm2ddl.auto";

    private static final String DECRYPT_CODE = "@lsdbpwd$";

    @Autowired
    private Environment env;

    @Value("${datasource.driver}")
    private String dataSourceDriver;

    @Value("${datasource.url}")
    private String dataSourceUrl;

    @Value("${datasource.username}")
    private String dataSourceUser;

    @Value("${datasource.password}")
    private String dataSourcePassword;

    @Value("${hibernate.dialect}")
    private String dialect;

    @Value("${hibernate.search.default.directory_provider}")
    private String filesystem;

    @Value("${hibernate.hbm2ddl.auto}")
    private String hbm2ddl;

    @Value("${hibernate.search.default.indexBase}")
    private String indexBase;

    @Value("${hibernate.show_sql}")
    private String showSql;

    @Value("${hibernate.search.indexing_strategy}")
    private String indexing_Strategy;

    @Value("${hibernate.search.worker.thread_pool.size}")
    private String searchThreadPoolSize;

    @Value("${hibernate.search.worker.execution}")
    private String searchWorkerExceution;

    /**
     * Configures the LocalContainerEntityManagerFactoryBean
     * 
     * @return
     */
    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean() {
        final LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
        localContainerEntityManagerFactoryBean
                .setPersistenceUnitName(ADDRESS_PERSISTENCE_UNIT);
        localContainerEntityManagerFactoryBean
                .setPersistenceProviderClass(org.hibernate.jpa.HibernatePersistenceProvider.class);
        localContainerEntityManagerFactoryBean.setDataSource(dataSource());
        localContainerEntityManagerFactoryBean
                .setJpaVendorAdapter(getHibernateJpaVendorAdapter());
        localContainerEntityManagerFactoryBean
                .setJpaProperties(additionalProperties());
        localContainerEntityManagerFactoryBean
                .setPackagesToScan(new String[] { UK_NHS_CFSMS_ALS_DOMAIN });
        return localContainerEntityManagerFactoryBean;
    }

    /**
     * Populates the HibernateJpaVendorAdapter
     * 
     * @return HibernateJpaVendorAdapter
     */
    @Bean
    public HibernateJpaVendorAdapter getHibernateJpaVendorAdapter() {
        final HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
        hibernateJpaVendorAdapter.setDatabase(HSQL);
        hibernateJpaVendorAdapter.setDatabasePlatform(dialect);
        return hibernateJpaVendorAdapter;
    }

    /**
     * Configures the JpaTransactionManager
     * 
     * @return PlatformTransactionManager
     */
    @Bean
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager(
                this.entityManagerFactoryBean().getObject());
        return transactionManager;
    }

    /**
     * Database configuration
     * 
     * @return DataSource
     */
    @Bean
    public DataSource dataSource() {
        final HikariConfig config = new HikariConfig();
        config.setMaximumPoolSize(100);
        config.setMinimumIdle(20);
        config.setMaxLifetime(30000L);
        config.setIdleTimeout(30000L);
        config.setPoolName("HikariCP");
        config.setDataSourceClassName(dataSourceDriver);
        config.addDataSourceProperty("url", dataSourceUrl);
        config.addDataSourceProperty("user", dataSourceUser);
        config.setAutoCommit(false);

        if (!(dataSourcePassword.isEmpty())) {
            final StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
            encryptor.setPassword(DECRYPT_CODE);
            final String decryptedPassword = encryptor
                    .decrypt(dataSourcePassword);
            config.addDataSourceProperty("password", decryptedPassword);
        } else {
            config.addDataSourceProperty("password", dataSourcePassword);
        }

        return new HikariDataSource(config);
    }

    /**
     * This method is used to add hibernate properties.
     * 
     * @return Properties
     */
    private Properties additionalProperties() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("ALS Hibernate configuration [" + "hbm2ddl=" + hbm2ddl
                    + ", " + "dialect=" + dialect + ", " + "showSql=" + showSql
                    + ", " + "hibernate.search.default.directory_provider="
                    + filesystem + ", " + "hibernate.search.default.indexBase="
                    + indexBase + ", " + "hibernate.search.worker.execution="
                    + searchWorkerExceution + ", "
                    + "hibernate.search.worker.thread_pool.size="
                    + searchThreadPoolSize + ", "
                    + "hibernate.search.indexing_strategy=" + indexing_Strategy
                    + "]");
        }
        final Properties properties = new Properties();
        if (!(hbm2ddl.isEmpty())) {
            properties.setProperty(HIBERNATE_HBM2DDL_AUTO, hbm2ddl);
        }
        properties.setProperty(HIBERNATE_DIALECT, dialect);
        properties.setProperty(HIBERNATE_SHOW_SQL, showSql);
        properties.setProperty(HIBERNATE_SEARCH_DEFAULT_DIRECTORY_PROVIDER,
                filesystem);
        properties.setProperty(HIBERNATE_SEARCH_DEFAULT_INDEX_BASE, indexBase);
        properties.setProperty(HIBERNATE_SEARCH_WORKER_EXECUTION,
                searchWorkerExceution);
        properties.setProperty(HIBERNATE_SEARCH_WORKER_THREAD_POOL_SIZE,
                searchThreadPoolSize);
        properties.setProperty(HIBERNATE_SEARCH_INDEXING_STRATEGY,
                indexing_Strategy);

        return properties;
    }

}
