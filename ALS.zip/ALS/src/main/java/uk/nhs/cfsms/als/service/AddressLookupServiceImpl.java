package uk.nhs.cfsms.als.service;

import static org.apache.commons.beanutils.BeanUtils.copyProperties;
import static uk.nhs.cfsms.als.util.AlsUtils.checkNotNull;
import static uk.nhs.cfsms.als.util.AlsUtils.validateAndFormatPostCode;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.cfsms.als.domain.Address;
import uk.nhs.cfsms.als.repository.AddressLookupRepository;
import uk.nhs.cfsms.als.util.AlsUtils;
import uk.nhs.cfsms.als.vo.AddressVo;

/**
 * Service class invokes the repository and returns the result to the
 * controller.
 *
 */
@Service
@Transactional(readOnly = true)
@MonitoredWithSpring
public class AddressLookupServiceImpl implements AddressLookupService {

    /**
     * Logger instance for AddressLookupServiceImpl.class.
     **/
    private static final Logger LOGGER = LoggerFactory
            .getLogger(AddressLookupServiceImpl.class);

    @Autowired
    AddressLookupRepository addressLookupRepository;

    /**
     * finds the address details for given addressVo object
     * 
     * @param addressVo
     * @return List<AddressVo>
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * 
     */

    public List<AddressVo> findByCriteria(final AddressVo addressVo)
            throws IllegalAccessException, InvocationTargetException {
        checkNotNull(addressVo, "addressVo object");
        final String validPostCode = validateAndFormatPostCode(
                addressVo.getPostCode());
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("validPostCode: " + validPostCode);
        }
        if (validPostCode != null
                && validPostCode.equalsIgnoreCase(AlsUtils.invalidPostCode)) {
            List<AddressVo> invalidPostCodeAddressVo = new ArrayList<AddressVo>();
            AddressVo addressVo2 = new AddressVo();
            addressVo2.setError(AlsUtils.invalidPostCode);
            invalidPostCodeAddressVo.add(addressVo2);
            return invalidPostCodeAddressVo;
        }
        addressVo.setPostCode(validPostCode);
        Address address = new Address();
        copyProperties(address, addressVo);
        final List<Address> resultAddress = addressLookupRepository
                .findAddressByCriteria(address);
        return copyBeanProperties(resultAddress);
    }

    /**
     * This method used to copies addressvo properties into address domain
     * properties then insert into data base.
     * 
     * This is used for local testing purpose.
     */
    @Transactional(readOnly = false)
    public void createAddresses(final List<AddressVo> addressVos)
            throws IllegalAccessException, InvocationTargetException {
        checkNotNull(addressVos, "addressVos List");
        final List<Address> addresses = new ArrayList<Address>();
        for (AddressVo addressVo : addressVos) {
            Address address = new Address();
            copyProperties(address, addressVo);
            addresses.add(address);
        }
        addressLookupRepository.createAddresses(addresses);
    }

    /**
     * This method copies the Address domain properties to AddressVo properties
     * 
     * @param addressList
     * @return List<AddressVo>
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    private List<AddressVo> copyBeanProperties(final List<Address> addressList)
            throws IllegalAccessException, InvocationTargetException {
        final List<AddressVo> addressVos = new ArrayList<AddressVo>();
        for (final Address address : addressList) {
            AddressVo addressVo = new AddressVo();
            copyProperties(addressVo, address);
            addressVos.add(addressVo);
        }
        return addressVos;
    }

    /**
     * @param async
     *            Re-indexes the @Indexed domain entity
     */
    public void createIndexes(boolean async) {
        addressLookupRepository.reIndexAll(async);
    }

    /**
     * This method used for junit testing
     */
    public void setAddressRepository(
            final AddressLookupRepository addressLookupRepository) {
        this.addressLookupRepository = addressLookupRepository;

    }

    /**
     * This method used for junit testing
     */
    public AddressLookupRepository getAddressRepository() {
        return addressLookupRepository;

    }
}
