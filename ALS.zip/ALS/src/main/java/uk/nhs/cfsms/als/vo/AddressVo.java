package uk.nhs.cfsms.als.vo;

import static org.apache.commons.lang.builder.EqualsBuilder.reflectionEquals;
import static org.apache.commons.lang.builder.HashCodeBuilder.reflectionHashCode;
import static org.apache.commons.lang.builder.ToStringBuilder.reflectionToString;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Value object used by service class to process the address lookup requests
 *
 */
@JsonIgnoreProperties
public class AddressVo {

    private String addressLine1;
    private String addressLine2;
    private String addressLine3;
    private String addressLine4;
    private String addressLine5;
    private String addressLine6;
    private String district;
    private String organisation;
    private String postCode;
    private String error;

    public String getAddressLine1() {
        return addressLine1;
    }

    /**
     * Sets the addressLine1 value
     * 
     * @param addressLine1
     */
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    /**
     * Sets the addressLine2 value
     * 
     * @param addressLine2
     */
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    /**
     * Sets the addressline3 value
     * 
     * @param addressLine3
     */
    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    /**
     * Sets the addressline4 value
     * 
     * @param addressLine4
     */
    public void setAddressLine4(String addressLine4) {
        this.addressLine4 = addressLine4;
    }

    public String getAddressLine4() {
        return addressLine4;
    }

    /**
     * Sets the addressline5 value
     * 
     * @param addressLine5
     */
    public void setAddressLine5(String addressLine5) {
        this.addressLine5 = addressLine5;
    }

    public String getAddressLine5() {
        return addressLine5;
    }

    public String getAddressLine6() {
        return addressLine6;
    }

    /**
     * Sets the addressline6 value
     * 
     * @param addressLine6
     */
    public void setAddressLine6(String addressLine6) {
        this.addressLine6 = addressLine6;
    }

    public String getPostCode() {
        return postCode;
    }

    /**
     * Sets the postcode value
     * 
     * @param postCode
     */
    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getOrganisation() {
        return organisation;
    }

    public void setOrganisation(String organisation) {
        this.organisation = organisation;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    @Override
    public String toString() {
        return reflectionToString(this);
    }

    public int hashCode() {
        return reflectionHashCode(this);
    }

    public boolean equals(Object obj) {
        return reflectionEquals(this, obj);
    }
}
