package uk.nhs.cfsms.als.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Configuration
public class PropertySourcesConfig {

    /**
     * Logger instance for PropertySourcesConfig.class.
     **/
    private static final Logger LOGGER = LoggerFactory
            .getLogger(PropertySourcesConfig.class);

    private static final Resource[] DEV_PROPERTIES = new ClassPathResource[] {
            new ClassPathResource("/database_dev.properties"), };
    private static final Resource[] TEST_PROPERTIES = new ClassPathResource[] {
            new ClassPathResource("/database_test.properties"), };
    private static final Resource[] PROD_PROPERTIES = new ClassPathResource[] {
            new ClassPathResource("/database_prod.properties"), };
    private static final Resource[] STAGE_PROPERTIES = new ClassPathResource[] {
            new ClassPathResource("/database_stage.properties"), };

    @Profile("DEV")
    public static class DevConfig {
        @Bean
        public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
            LOGGER.info("DEV profile has been initialized");
            final PropertySourcesPlaceholderConfigurer pspc = new PropertySourcesPlaceholderConfigurer();
            pspc.setLocations(DEV_PROPERTIES);
            return pspc;
        }
    }

    @Profile("TEST")
    public static class TestConfig {
        @Bean
        public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
            LOGGER.info("TEST profile has been initialized");
            final PropertySourcesPlaceholderConfigurer pspc = new PropertySourcesPlaceholderConfigurer();
            pspc.setLocations(TEST_PROPERTIES);
            return pspc;
        }
    }

    @Profile("STAGE")
    public static class StageConfig {
        @Bean
        public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
            LOGGER.info("STAGE profile has been initialized");
            final PropertySourcesPlaceholderConfigurer pspc = new PropertySourcesPlaceholderConfigurer();
            pspc.setLocations(STAGE_PROPERTIES);
            return pspc;
        }
    }

    @Profile("PROD")
    public static class ProdConfig {
        @Bean
        public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
            LOGGER.info("PROD profile has been initialized");
            final PropertySourcesPlaceholderConfigurer pspc = new PropertySourcesPlaceholderConfigurer();
            pspc.setLocations(PROD_PROPERTIES);
            return pspc;
        }
    }

}
