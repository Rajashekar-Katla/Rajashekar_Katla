package uk.nhs.cfsms.als.util;

import static java.util.regex.Pattern.compile;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import uk.nhs.cfsms.als.exceptions.ALSException;

/**
 * Utility class, provides helper methods.
 *
 */
public class AlsUtils {

    // This regex is created based on UK postcode format
    // (https://www.mrs.org.uk/pdf/postcodeformat.pdf), but DEV DB postcodes not
    // passing this regex. So needs to be reviewed. for now commented out.

    // private static final String POSTCODE_REGEX =
    // "[A-PR-UWYZ]{1}[A-HK-Y]{0,1}[0-9]{0,2}[A-HJKSTUW]{0,1}\\s{0,1}\\d[ABD-HJLNP-UWXYZ]{2}";

    private static final String POSTCODE_REGEX = "[A-PR-UWYZ]{1}[A-HK-Y]{0,1}[0-9]{0,2}[A-Z]{0,1}\\s{0,1}\\d[ABD-HJLNP-UWXYZ]{2}";
    private static final String SPACE_REGEX = "\\s";

    public final static String invalidPostCode = "Invalid Post Code";

    /**
     * Helper method validates the given postcode and adds the space into
     * postcode if there is no space found.
     * 
     * @param postCode
     * @return
     * @throws ALSException
     */

    public static String validateAndFormatPostCode(String postCode)
            throws ALSException {
        checkNotNull(postCode, "postCode");
        if (postCode != null) {
            postCode = postCode.trim().toUpperCase();
            Pattern pattern = compile(POSTCODE_REGEX);
            Matcher matcher = pattern.matcher(postCode);
            if (!matcher.matches()) {
                throw new ALSException("Invalid Post Code");
            }

            if (!((postCode.split(SPACE_REGEX).length) > 1)) {
                final StringBuilder reversePostCode = new StringBuilder(
                        postCode).reverse();
                final StringBuilder validPostCode = new StringBuilder()
                        .append(reversePostCode.substring(0, 3))
                        .append(" ")
                        .append(reversePostCode.substring(3,
                                reversePostCode.length())).reverse();
                postCode = validPostCode.toString();
            }
        }
        return postCode;
    }

    /**
     * Helper method validates the given obj is null or not.
     * 
     * @param obj
     */
    public static <T> void checkNotNull(final T obj, final String propertyName) {
        if (obj == null) {
            throw new ALSException(propertyName + " should not be null");
        }
    }

}
