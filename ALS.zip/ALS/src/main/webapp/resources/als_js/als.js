var openBracket = '{';
var endBracket = '}';
var postCodeStr = '\"postCode\":';
var addressLine1Str = '\"addressLine1\":';
var addressLine2Str = '\"addressLine2\":';
var addressLine3Str = '\"addressLine3\":';
var addressLine4Str = '\"addressLine4\":';
var addressLine5Str = '\"addressLine5\":';
var addressLine6Str = '\"addressLine6\":';

$(document).ready(function() {

	var requestURL = $('#requestURL').val() + 'address/';

	configureDialog('mandatoryFields');
	configureDialog('error-dialog');
	configureDialog('empty-response-dialog');

	$('#addressList').DataTable({
		"scrollY" : "420px",
		"sPaginationType" : "full_numbers",
		"bPaginate" : true,
		"bJQueryUI" : true,
		"bAutoWidth" : false,
		"bScrollAutoCss" : true,
		"sScrollX" : "100%",
		"bScrollCollapse" : false,
		"sScrollInner" : "100%",
		"lengthMenu" : [ [ 10, 25, 50, 100, -1 ], [ 10, 25, 50, 100, "All" ] ]
	});

	$('#loader-dialog').dialog({
		width : "140px",
		modal : true,
		autoOpen : false,
		resizable : false,
		draggable : false,
		position : {
			my : "center center",
			at : "center center",
			of : window
		}
	});

	$(window).bind('scroll', function() {
		if ($(this).scrollTop() > 200) {
			$(".scrollToTop").show();
		} else {
			$(".scrollToTop").hide();
		}
	});

	$(".scrollToTop").click(function() {
		$('html, body').animate({
			scrollTop : $(".container").offset().top
		}, 300);
	});

	$('#search').click(function(event) {
		event.preventDefault();
		$('#result').empty();

		if (isFormValid()) {

			$("#loader-dialog").dialog("option", "minHeight", 65);
			$("#loader-dialog").siblings('div.ui-dialog-titlebar').remove();
			if (jQuery.browser.msie) {
				$('#loader-dialog').css('display', '');
				var htmlStr = $('#loader-dialog').html();
				$('#loader-dialog').html(htmlStr);
			}
			$("#loader-dialog").dialog('open');

			var jsonString = constructURL();

			var lookUpURL = requestURL + jsonString;

			setTimeout(function() {
				makeAjaxCall(lookUpURL);
				$('#loader-dialog').dialog('close');
			}, 1000);

		} else {
			$("#mandatoryFields").dialog("open");
			$('.scrollToTop').css('display', 'none');
		}
	});

});

function makeAjaxCall(lookUpURL) {
	$.ajax({
		url : lookUpURL,
		success : function(response) {
			handleData(response);
		},
		error : function(xhr, status, error) {
			$('#result').empty();
			$('#loader-dialog').dialog('close');
			$('#error-dialog').dialog('open');
			$('.scrollToTop').css('display', 'none');
			errorHandle(xhr.responseText);
		}
	});

}

function handleData(response) {
	var message;

	if (response == '') {
		$('#result').empty();
		$('#result').css('display', 'block');
		$('#empty-response-dialog').dialog('open');
		$('.scrollToTop').css('display', 'none');
	} else {
		if (response.length > 1) {
			message = '<p>Total ' + response.length + ' addresses found.</p>'
		} else {
			message = '<p>' + response.length + ' address found.</p>';
		}

		$('#result').css('display', 'block');

		/*
		 * var tableHtml = '<table id="addressList" class="table table-striped
		 * table-bordered table-responsive"></table>';
		 */var tableHtml = '<table id="addressList" class="table table-striped table-bordered" cellspacing="0" width="100%"></table>';

		$('#result').empty();

		$('#result').append(message).append(tableHtml);

		var rowData = [];

		var colData = [ "<span style='text-align:center;'><b>#</b></span>",
				"<span style='text-align:center;'><b>Address Line1</b></span>",
				"<span style='text-align:center;'><b>Address Line2</b></span>",
				"<span style='text-align:center;'><b>Address Line3</b></span>",
				"<span style='text-align:center;'><b>Address Line4</b></span>",
				"<span style='text-align:center;'><b>Address Line5</b></span>",
				"<span style='text-align:center;'><b>Address Line6</b></span>",
				"<span style='text-align:center;'><b>Post Code</b></span>" ];

		var data = {
			"Cols" : colData,
			"Rows" : rowData
		};
		var tr = $('<tr/>');
		var table = $('#addressList');

		table.append('<thead>').children('thead').append(tr);

		for (var i = 0; i < data.Cols.length; i++) {
			tr.append('<td>' + data.Cols[i] + '</td>');
		}

		for (var i = 0; i < response.length; i++) {
			var count = i + 1;
			var addressLine1 = response[i].addressLine1;
			var addressLine2 = response[i].addressLine2;
			var addressLine3 = response[i].addressLine3;
			var addressLine4 = response[i].addressLine4;
			var addressLine5 = response[i].addressLine5;
			var addressLine6 = response[i].addressLine6;
			var postCode = response[i].postCode;

			var tr = $('<tr/>');
			table.append(tr);

			rowData.push([ count, addressLine1, addressLine2, addressLine3,
					addressLine4, addressLine5, addressLine6, postCode ]);

			for (var c = 0; c < data.Cols.length; c++) {
				tr.append('<td style="text-align:center;">' + data.Rows[i][c]
						+ '</td>');
			}

			$('#result').css('display', 'block');
		}
	}
}

function errorHandle(error) {
	console.log('error=' + error)
}

function constructURL() {

	var quote = '\"';
	var line1Value = $('#addressLine1').val();
	var line2Value = $('#addressLine2').val();
	var line3Value = $('#addressLine3').val();
	var line4Value = $('#addressLine4').val();
	var line5Value = $('#addressLine5').val();
	var line6Value = $('#addressLine6').val();
	var postCodeValue = $('#postcode').val();

	var url = '';
	var comma = ',';
	url += openBracket;

	if (line1Value) {
		url += addressLine1Str + quote + line1Value + quote;
	}
	if (line2Value) {
		url += comma + addressLine2Str + quote + line2Value + quote;
	}
	if (line3Value) {
		url += comma + addressLine3Str + quote + line3Value + quote;
	}
	if (line4Value) {
		url += comma + addressLine4Str + quote + line4Value + quote;
	}
	if (line5Value) {
		url += comma + addressLine5Str + quote + line5Value + quote;
	}
	if (line6Value) {
		url += comma + addressLine6Str + quote + line6Value + quote;
	}
	if (postCodeValue) {
		url += comma + postCodeStr + quote + postCodeValue + quote;
	}
	url += endBracket;

	return url;
}

function configureDialog(dialogName) {
	$('#' + dialogName).dialog({
		show : "blind",
		hide : "explode",
		width : "400px",
		modal : true,
		height : "auto",
		autoOpen : false,
		resizable : false,
		position : {
			my : "center center",
			at : "center center",
			of : window
		},
		closeOnEscape : false,
		open : function(event, ui) {
			$(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
		},
		buttons : {
			OK : function() {
				$(this).dialog("close");
			}
		}
	});

}

function isFormValid() {

	var postCodeValue = $('#postcode').val();
	var line1Value = $('#addressLine1').val();

	if (postCodeValue == '' || line1Value == '') {
		return false;
	} else {
		return true;
	}
}