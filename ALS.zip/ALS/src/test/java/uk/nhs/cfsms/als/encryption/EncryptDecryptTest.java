package uk.nhs.cfsms.als.encryption;

import org.junit.Test;

import static uk.nhs.cfsms.als.encryption.EncryptDecryptPassword.*;

public class EncryptDecryptTest {

    @Test
    public void encryptDecryptTest() throws Exception {
        encryptPropertyValue();
        decryptPropertyValue();
    }
}
