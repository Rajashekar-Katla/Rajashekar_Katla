package uk.nhs.cfsms.als.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static uk.nhs.cfsms.als.stub.AddressStub.getListOfAddresses;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.core.Is;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import uk.nhs.cfsms.als.domain.Address;
import uk.nhs.cfsms.als.exceptions.ALSException;
import uk.nhs.cfsms.als.repository.AddressLookupRepository;
import uk.nhs.cfsms.als.vo.AddressVo;

/**
 * @author RKatla
 */
public class AddressLookupServiceImplTest {
    private AddressLookupService addressLookupService;
    private AddressLookupRepository addressRepositoryMock;

    private static final String[] VALID_POSTCODES_WITH_SPACES = { "M1 1AA",
            "EC1A 1BB", "CR2 6XH", "M60 1NW", "DN55 1PT", "W1A 1HQ", "A9 9AA",
            "A99 9AA", "AA9 9AA", "AA99 9AA", "A9A 9AA", "AA9A 9AA", "L2 3SW",
            "EH12 9DN", "SW1A 2AA" };

    private static final String[] ADDRESSLINE1 = { "M1 1AA ADDRESS LANE1",
            "EC1A 1BB ADDRESS LANE1", "CR2 6XH ADDRESS LANE1",
            "M60 1NW ADDRESS LANE1", "DN55 1PT ADDRESS LANE1",
            "W1A 1HQ ADDRESS LANE1", "A9 9AA ADDRESS LANE1",
            "A99 9AA ADDRESS LANE1", "AA9 9AA ADDRESS LANE1",
            "AA99 9AA ADDRESS LANE1", "A9A 9AA ADDRESS LANE1",
            "AA9A 9AA ADDRESS LANE1", "L2 3SW ADDRESS LANE1",
            "EH12 9DN ADDRESS LANE1", "SW1A 2AA ADDRESS LANE1" };

    private static final String[] ADDRESSLINE2 = { "M1 1AA ADDRESS LANE2",
            "EC1A 1BB ADDRESS LANE2", "CR2 6XH ADDRESS LANE2",
            "M60 1NW ADDRESS LANE2", "DN55 1PT ADDRESS LANE2",
            "W1A 1HQ ADDRESS LANE2", "A9 9AA ADDRESS LANE2",
            "A99 9AA ADDRESS LANE2", "AA9 9AA ADDRESS LANE2",
            "AA99 9AA ADDRESS LANE2", "A9A 9AA ADDRESS LANE2",
            "AA9A 9AA ADDRESS LANE2", "L2 3SW ADDRESS LANE2",
            "EH12 9DN ADDRESS LANE2", "SW1A 2AA ADDRESS LANE2" };

    private static final String[] VALID_POSTCODES_WITH_NO_SPACES = { "M11AA",
            "EC1A1BB", "CR26XH", "M601NW", "DN551PT", "W1A1HQ", "A99AA",
            "A999AA", "AA99AA", "AA999AA", "A9A9AA", "AA9A9AA", "L23SW",
            "EH129DN", "SW1A2AA" };

    private static final String[] INVALID_POSTCODES_WITH_NO_SPACES = { "M11A�",
            "M60%NW", "CR%6XH", "D�551PT", "�1A1HQ", "EC1A1B-", "EC1A1B4" };

    private static final String[] INVALID_POSTCODES_WITH_SPACES = { "Q1 1AA",
            "M60 QNW", "C!2 6XH", "D%55 1PT", "DN55    1PT", "�1A 1HQ",
            "EC1A 1B$", "EC1A 1B_" };

    private AddressVo addressVo;

    @Before
    public void setUp() {
        addressVo = new AddressVo();
        addressLookupService = new AddressLookupServiceImpl();
        addressRepositoryMock = mock(AddressLookupRepository.class);
        addressLookupService.setAddressRepository(addressRepositoryMock);
    }

    @Test
    public void testService() {
        final AddressLookupService addressLookupService = new AddressLookupServiceImpl();
        assertNotNull(addressLookupService);
    }

    @Test
    public void testSetAddressRepository() {
        final AddressLookupServiceImpl addressLookupService = new AddressLookupServiceImpl();
        addressLookupService.setAddressRepository(addressRepositoryMock);
        assertThat(addressLookupService.getAddressRepository(),
                is(addressRepositoryMock));
    }

    @Test
    public void testfindByPostCode() throws Exception {
        final List<Address> addresses = new ArrayList<Address>();
        when(addressRepositoryMock.findAddressByCriteria(any(Address.class)))
                .thenReturn(addresses);
        for (String postCode : VALID_POSTCODES_WITH_SPACES) {
            addressVo.setPostCode(postCode);
            final List<AddressVo> addressVos = addressLookupService
                    .findByCriteria(addressVo);
            assertEquals(addresses, addressVos);
        }
        verify(addressRepositoryMock, times(VALID_POSTCODES_WITH_SPACES.length))
                .findAddressByCriteria(any(Address.class));
        verifyNoMoreInteractions(addressRepositoryMock);
    }

    @Test
    public void testfindByPostCodeAndAddressLine1_With_EmptyList()
            throws Exception {
        final List<Address> address = new ArrayList<Address>();
        when(addressRepositoryMock.findAddressByCriteria(any(Address.class)))
                .thenReturn(address);
        for (int i = 0; i < VALID_POSTCODES_WITH_SPACES.length; i++) {
            addressVo.setPostCode(VALID_POSTCODES_WITH_SPACES[i]);
            addressVo.setAddressLine1(ADDRESSLINE1[i]);
            final List<AddressVo> returned = addressLookupService
                    .findByCriteria(addressVo);
            assertEquals(address, returned);
        }
        verify(addressRepositoryMock, times(VALID_POSTCODES_WITH_SPACES.length))
                .findAddressByCriteria(any(Address.class));
        verifyNoMoreInteractions(addressRepositoryMock);

    }

    @Test
    public void testfindByPostCodeAndAddressLine1_With_ListOfValidPostCodes_And_With_ListOfAddresses()
            throws Exception {
        List<Address> addresses = null;
        final Address address = new Address();
        for (int i = 0; i < VALID_POSTCODES_WITH_SPACES.length; i++) {
            final String postCode = VALID_POSTCODES_WITH_SPACES[i];
            final String addressline1 = ADDRESSLINE1[i];
            addressVo.setPostCode(postCode);
            addressVo.setAddressLine1(addressline1);

            addresses = new ArrayList<Address>();
            address.setPostCode(postCode);
            address.setAddressLine1(addressline1);
            addresses.add(address);
            when(
                    addressRepositoryMock
                            .findAddressByCriteria(any(Address.class)))
                    .thenReturn(addresses);

            final List<AddressVo> returned = addressLookupService
                    .findByCriteria(addressVo);
            assertNotNull(returned);
            for (AddressVo _addressVo : returned) {
                assertThat(_addressVo.getPostCode(), Is.is(postCode));
                assertThat(_addressVo.getAddressLine1(), Is.is(addressline1));
            }
        }
        verify(addressRepositoryMock, times(VALID_POSTCODES_WITH_SPACES.length))
                .findAddressByCriteria(any(Address.class));
        verifyNoMoreInteractions(addressRepositoryMock);
    }

    @Test
    public void testfindByPostCode_With_ListOf_ValidPostCodesWithSpaces_And_With_ListOfAddresses()
            throws Exception {
        List<Address> addresses = null;
        final Address address = new Address();

        for (int i = 0; i < VALID_POSTCODES_WITH_SPACES.length; i++) {
            final String postCode = VALID_POSTCODES_WITH_SPACES[i];
            final String addressline1 = ADDRESSLINE1[i];
            final String addressline2 = ADDRESSLINE2[i];
            addresses = new ArrayList<Address>();

            address.setPostCode(postCode);
            address.setAddressLine1(addressline1);
            address.setAddressLine2(addressline2);
            addresses.add(address);

            addressVo.setPostCode(postCode);
            addressVo.setAddressLine1(addressline1);
            addressVo.setAddressLine2(addressline2);

            when(
                    addressRepositoryMock
                            .findAddressByCriteria(any(Address.class)))
                    .thenReturn(addresses);
            final List<AddressVo> addressVos = addressLookupService
                    .findByCriteria(addressVo);

            assertNotNull(addressVos);
            for (int j = 0; j < addressVos.size(); j++) {
                assertThat(
                        isBothObjectsEqual(addressVos.get(j), addresses.get(j)),
                        Is.is(true));
            }
        }
        verify(addressRepositoryMock, times(VALID_POSTCODES_WITH_SPACES.length))
                .findAddressByCriteria(any(Address.class));
        verifyNoMoreInteractions(addressRepositoryMock);
    }

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Test
    public void testfindByPostCode_With_ListOf_InValidPostCodes_WithSpaces_And_With_ListOfAddresses()
            throws Exception {
        List<Address> addresses = null;
        final Address address = new Address();

        for (int i = 0; i < INVALID_POSTCODES_WITH_SPACES.length; i++) {
            final String postCode = INVALID_POSTCODES_WITH_SPACES[i];
            final String addressline1 = ADDRESSLINE1[i];
            final String addressline2 = ADDRESSLINE2[i];
            addresses = new ArrayList<Address>();

            address.setPostCode(postCode);
            address.setAddressLine1(addressline1);
            address.setAddressLine2(addressline2);
            addresses.add(address);

            addressVo.setPostCode(postCode);
            addressVo.setAddressLine1(addressline1);
            addressVo.setAddressLine2(addressline2);

            when(
                    addressRepositoryMock
                            .findAddressByCriteria(any(Address.class)))
                    .thenReturn(addresses);

            expectedException.expect(ALSException.class);
            expectedException.expectMessage("Invalid Post Code");

            final List<AddressVo> returned = addressLookupService
                    .findByCriteria(addressVo);

            assertEquals(null, returned);
        }
        verify(addressRepositoryMock, times(VALID_POSTCODES_WITH_SPACES.length))
                .findAddressByCriteria(any(Address.class));
        verifyNoMoreInteractions(addressRepositoryMock);
    }

    @Test
    public void testfindByPostCode_With_ListOf_InValidPostCodes_WithNoSpaces_And_With_ListOfAddresses()
            throws Exception {
        List<Address> addresses = null;
        final Address address = new Address();

        for (int i = 0; i < INVALID_POSTCODES_WITH_NO_SPACES.length; i++) {
            final String postCode = INVALID_POSTCODES_WITH_NO_SPACES[i];
            final String addressline1 = ADDRESSLINE1[i];
            final String addressline2 = ADDRESSLINE2[i];

            addresses = new ArrayList<Address>();
            address.setPostCode(postCode);
            address.setAddressLine1(addressline1);
            address.setAddressLine2(addressline2);
            addresses.add(address);

            addressVo.setPostCode(postCode);
            addressVo.setAddressLine1(addressline1);
            addressVo.setAddressLine2(addressline2);

            when(
                    addressRepositoryMock
                            .findAddressByCriteria(any(Address.class)))
                    .thenReturn(addresses);

            expectedException.expect(ALSException.class);
            expectedException.expectMessage("Invalid Post Code");

            final List<AddressVo> returned = addressLookupService
                    .findByCriteria(addressVo);

            assertEquals(null, returned);
        }
        verify(addressRepositoryMock, times(VALID_POSTCODES_WITH_SPACES.length))
                .findAddressByCriteria(any(Address.class));
        verifyNoMoreInteractions(addressRepositoryMock);
    }

    @Test
    public void testfindByPostCode_With_ListOfValidPostCodesWithNoSpaces_And_With_ListOfAddresses()
            throws Exception {
        List<Address> addresses = null;
        final Address address = new Address();

        for (int i = 0; i < VALID_POSTCODES_WITH_NO_SPACES.length; i++) {
            final String postCode = VALID_POSTCODES_WITH_NO_SPACES[i];
            final String addressline1 = ADDRESSLINE1[i];
            final String addressline2 = ADDRESSLINE2[i];
            addresses = new ArrayList<Address>();
            address.setPostCode(postCode);
            address.setAddressLine1(addressline1);
            address.setAddressLine2(addressline2);
            addresses.add(address);

            addressVo.setPostCode(postCode);
            addressVo.setAddressLine1(addressline1);
            addressVo.setAddressLine2(addressline2);

            when(
                    addressRepositoryMock
                            .findAddressByCriteria(any(Address.class)))
                    .thenReturn(addresses);
            final List<AddressVo> addressVos = addressLookupService
                    .findByCriteria(addressVo);
            assertNotNull(addressVos);

            for (int j = 0; j < addressVos.size(); j++) {
                assertThat(
                        isBothObjectsEqual(addressVos.get(j), addresses.get(j)),
                        Is.is(true));
            }
        }
        verify(addressRepositoryMock, times(VALID_POSTCODES_WITH_SPACES.length))
                .findAddressByCriteria(any(Address.class));
        verifyNoMoreInteractions(addressRepositoryMock);
    }

    @Test
    public void testfindByPostCodeAndAddressLine1_With_ListOfAddresses()
            throws Exception {
        final List<Address> addresses = getListOfAddresses();

        addressVo.setPostCode(VALID_POSTCODES_WITH_SPACES[1]);
        addressVo.setAddressLine1(ADDRESSLINE1[1]);

        when(addressRepositoryMock.findAddressByCriteria(any(Address.class)))
                .thenReturn(addresses);
        List<AddressVo> addressVos = addressLookupService
                .findByCriteria(addressVo);
        assertNotNull(addressVos);
        assertThat(addressVos.size(), Is.is(addresses.size()));
        for (int i = 0; i < addressVos.size(); i++) {
            assertThat(isBothObjectsEqual(addressVos.get(i), addresses.get(i)),
                    Is.is(true));
        }
        verify(addressRepositoryMock, times(1)).findAddressByCriteria(
                any(Address.class));
        verifyNoMoreInteractions(addressRepositoryMock);
    }

    @Test
    public void testfindByPostCode_WithListOfAddresses() throws Exception {
        final List<Address> addresses = getListOfAddresses();

        addressVo.setPostCode(VALID_POSTCODES_WITH_SPACES[1]);

        when(addressRepositoryMock.findAddressByCriteria(any(Address.class)))
                .thenReturn(addresses);
        final List<AddressVo> addressVos = addressLookupService
                .findByCriteria(addressVo);
        assertNotNull(addressVos);
        assertThat(addressVos.size(), Is.is(addresses.size()));
        for (int i = 0; i < addressVos.size(); i++) {
            assertThat(isBothObjectsEqual(addressVos.get(i), addresses.get(i)),
                    Is.is(true));
        }
        verify(addressRepositoryMock, times(1)).findAddressByCriteria(
                any(Address.class));
        verifyNoMoreInteractions(addressRepositoryMock);
    }

    private boolean isBothObjectsEqual(final AddressVo addressVo,
            final Address adress) {
        if (addressVo.getPostCode().equals(adress.getPostCode())
                && addressVo.getAddressLine1().equals(adress.getAddressLine1())
                && addressVo.getAddressLine2().equals(adress.getAddressLine2())) {
            return true;
        }
        return false;

    }
}
