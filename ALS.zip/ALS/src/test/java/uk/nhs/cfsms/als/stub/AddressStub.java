package uk.nhs.cfsms.als.stub;

import static org.apache.commons.beanutils.BeanUtils.copyProperties;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import uk.nhs.cfsms.als.domain.Address;
import uk.nhs.cfsms.als.vo.AddressVo;

/**
 * @author RKatla
 */

public class AddressStub {

    public static List<Address> getListOfAddresses()
            throws IllegalAccessException, InvocationTargetException {
        return getPopulatedAddresses(populateAddressVos());

    }

    public static List<AddressVo> populateAddressVos() {
        final List<AddressVo> addressVos = new ArrayList<AddressVo>();
        final AddressVo address1 = new AddressVo();
        address1.setAddressLine1("M1 1AA ADDRESS LANE1");
        address1.setAddressLine2("M1 1AA ADDRESS LANE2");
        address1.setPostCode("M1 1AA");

        final AddressVo address2 = new AddressVo();
        address2.setAddressLine1("EC1A 1BB ADDRESS LANE1");
        address2.setAddressLine2("EC1A 1BB ADDRESS LANE2");
        address2.setPostCode("EC1A 1BB");

        final AddressVo address3 = new AddressVo();
        address3.setAddressLine1("CR2 6XH ADDRESS LANE1");
        address3.setAddressLine2("CR2 6XH ADDRESS LANE2");
        address3.setPostCode("CR2 6XH");

        final AddressVo address4 = new AddressVo();
        address4.setAddressLine1("M60 1NW ADDRESS LANE1");
        address4.setAddressLine2("M60 1NW ADDRESS LANE2");
        address4.setPostCode("M60 1NW");

        final AddressVo address5 = new AddressVo();
        address5.setAddressLine1("DN55 1PT ADDRESS LANE1");
        address5.setAddressLine2("DN55 1PT ADDRESS LANE2");
        address5.setPostCode("DN55 1PT");

        final AddressVo address6 = new AddressVo();
        address6.setAddressLine1("W1A 1HQ ADDRESS LANE1");
        address6.setAddressLine2("W1A 1HQ ADDRESS LANE2");
        address6.setPostCode("W1A 1HQ");

        final AddressVo address7 = new AddressVo();
        address7.setAddressLine1("A9 9AA ADDRESS LANE1");
        address7.setAddressLine2("A9 9AA ADDRESS LANE2");
        address7.setPostCode("A9 9AA");

        final AddressVo address8 = new AddressVo();
        address8.setAddressLine1("A99 9AA ADDRESS LANE1");
        address8.setAddressLine2("A99 9AA ADDRESS LANE2");
        address8.setPostCode("A99 9AA");

        final AddressVo address9 = new AddressVo();
        address9.setAddressLine1("AA9 9AA ADDRESS LANE1");
        address9.setAddressLine2("AA9 9AA ADDRESS LANE2");
        address9.setPostCode("AA9 9AA");

        final AddressVo address10 = new AddressVo();
        address10.setAddressLine1("AA99 9AA ADDRESS LANE1");
        address10.setAddressLine2("AA99 9AA ADDRESS LANE2");
        address10.setPostCode("AA99 9AA");

        final AddressVo address11 = new AddressVo();
        address11.setAddressLine1("A9A 9AA ADDRESS LANE1");
        address11.setAddressLine2("A9A 9AA ADDRESS LANE2");
        address11.setPostCode("A9A 9AA");

        final AddressVo address12 = new AddressVo();
        address12.setAddressLine1("AA9A 9AA ADDRESS LANE1");
        address12.setAddressLine2("AA9A 9AA ADDRESS LANE2");
        address12.setPostCode("AA9A 9AA");

        final AddressVo address13 = new AddressVo();
        address13.setAddressLine1("L2 3SW ADDRESS LANE1");
        address13.setAddressLine2("L2 3SW ADDRESS LANE2");
        address13.setPostCode("L2 3SW");

        final AddressVo address14 = new AddressVo();
        address14.setAddressLine1("EH12 9DN ADDRESS LANE1");
        address14.setAddressLine2("EH12 9DN ADDRESS LANE2");
        address14.setPostCode("EH12 9DN");

        final AddressVo address15 = new AddressVo();
        address15.setAddressLine1("SW1A 2AA ADDRESS LANE1");
        address15.setAddressLine2("SW1A 2AA ADDRESS LANE2");
        address15.setPostCode("SW1A 2AA");

        addressVos.add(address1);
        addressVos.add(address2);
        addressVos.add(address3);
        addressVos.add(address4);
        addressVos.add(address5);
        addressVos.add(address6);
        addressVos.add(address7);
        addressVos.add(address8);
        addressVos.add(address9);
        addressVos.add(address10);
        addressVos.add(address11);
        addressVos.add(address12);
        addressVos.add(address13);
        addressVos.add(address14);
        addressVos.add(address15);

        return addressVos;
    }

    private static List<Address> getPopulatedAddresses(final List<AddressVo> vos)
            throws IllegalAccessException, InvocationTargetException {
        final List<Address> addresses = new ArrayList<Address>();
        for (AddressVo addressVo : vos) {
            Address address = new Address();
            copyProperties(address, addressVo);
            addresses.add(address);
        }
        return addresses;
    }

}
