package uk.nhs.cfsms.als.cucumber.dev.profile;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(glue = { "uk.nhs.cfsms.als.cucumber.dev" }, format = {
        "pretty", "html:target/cucumber", "json:target/cucumber.json" }, features = { "src/test/resources/scenarios/dev" })
public class CucumberRunner {
}
