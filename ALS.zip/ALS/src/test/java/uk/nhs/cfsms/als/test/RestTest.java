package uk.nhs.cfsms.als.test;

import java.util.Arrays;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import uk.nhs.cfsms.als.vo.AddressVo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Ignore
public class RestTest {

    @Test
    public void thatOrdersCanBeAddedAndQueried() throws JsonProcessingException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        AddressVo obj = new AddressVo();
        obj.setPostCode("A9 1AA");

        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(obj);

        String s = "{\"postCode\":\"IG1 1AA\", \"addressLine1\":\"addressLine1\",\"addressLine2\":\"addressLine2\""
                + ",\"addressLine3\":\"addressLine3\",\"addressLine4\":\"addressLine4\"}";

        String url = "{\"postCode\":\"DL158PL\"}";

        RestTemplate template = new RestTemplate();

        /*
         * HttpEntity<String> requestEntity = new HttpEntity<String>(url,
         * headers);
         * System.out.println("http://als.nhsprotect.nhs.uk:8080/als/address/" +
         * url);
         */
        ResponseEntity<AddressVo> entity = template.getForEntity(
                "http://als.nhsprotect.nhs.uk:8080/als/address/" + url,
                AddressVo.class);
        //
        // ResponseEntity<AddressVo> entity = template.postForEntity(
        // "http://localhost:8080/save/object", requestEntity,
        // AddressVo.class);

        // http://localhost:8080/Spring-Rest/

        String path = entity.getHeaders().getLocation().getPath();

        // assertEquals(HttpStatus.CREATED, entity.getStatusCode());
        // assertTrue(path.startsWith("/aggregators/orders/"));
        // Order order = entity.getBody();

        // System.out.println ("The Order ID is " + order.getKey());
        System.out.println("The Location is "
                + entity.getHeaders().getLocation());

        // assertEquals(2, order.getItems().size());
    }
}
