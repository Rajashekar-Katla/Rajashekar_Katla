package uk.nhs.cfsms.als.test;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.swing.JOptionPane;

import org.apache.commons.codec.binary.Base64;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class MGD5Hashing {
    private static Random rand = new Random((new Date()).getTime());

    public static void main(String[] args) throws Exception {
       /* String password = "P0larbear5";

        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(password.getBytes());

        byte byteData[] = md.digest();

        // convert the byte to hex format method 1
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < byteData.length; i++) {
            sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16)
                    .substring(1));
        }

        System.out.println("Digest(in hex format):: " + sb.toString());

        // convert the byte to hex format method 2
        StringBuffer hexString = new StringBuffer();
        for (int i = 0; i < byteData.length; i++) {
            String hex = Integer.toHexString(0xff & byteData[i]);
            if (hex.length() == 1)
                hexString.append('0');
            hexString.append(hex);
        }*/
        en();
//        System.out.println("Digest(in hex format):: " + hexString.toString());
//        MGD5Hashing hashing = new MGD5Hashing();
//        hashing.DecryptText(hexString.toString());
    }

    public String DecryptText(String EncText) {

        String RawText = "";
        byte[] keyArray = new byte[24];
        byte[] temporaryKey;
        String key = "developersnotedotcom";
        byte[] toEncryptArray = null;

        try {
            MessageDigest m = MessageDigest.getInstance("MD5");
            temporaryKey = m.digest(key.getBytes("UTF-8"));

            if (temporaryKey.length < 24) // DESede require 24 byte length key
            {
                int index = 0;
                for (int i = temporaryKey.length; i < 24; i++) {
                    keyArray[i] = temporaryKey[index];
                }
            }

            Cipher c = Cipher.getInstance("DESede/CBC/PKCS5Padding");
            // c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(keyArray,
            // "DESede"), new IvParameterSpec(sharedvector));
            byte[] decrypted = c.doFinal(Base64.decodeBase64(EncText));

            RawText = new String(decrypted, "UTF-8");
        } catch (NoSuchAlgorithmException ex1) {
            JOptionPane.showMessageDialog(null, ex1);
        } catch (UnsupportedEncodingException ex2) {
        } catch (NoSuchPaddingException ex3) {
        }
        // catch(InvalidKeyException ex4){}
        // catch(InvalidAlgorithmParameterException ex5){}
        catch (IllegalBlockSizeException ex6) {
        } catch (BadPaddingException ex7) {
            JOptionPane.showMessageDialog(null, ex7);
        }
        System.out.println("RawText==" + RawText);
        return RawText;

    }

    private static void en() {
        String st = "D3v3lopm3nt";
        String enc = encrypt(st);

        System.out.println("Encrypted string :" + enc);
        System.out.println("Decrypted string :" + decrypt(enc));
    }

    public static String encrypt(String str) {

        BASE64Encoder encoder = new BASE64Encoder();

        byte[] salt = new byte[8];

        rand.nextBytes(salt);

        return encoder.encode(salt) + encoder.encode(str.getBytes());
    }

    public static String decrypt(String encstr) {

        if (encstr.length() > 12) {

            String cipher = encstr.substring(12);

            BASE64Decoder decoder = new BASE64Decoder();

            try {

                return new String(decoder.decodeBuffer(cipher));

            } catch (IOException e) {

                // throw new InvalidImplementationException(

                // Fail

            }

        }

        return null;
    }

}
