package uk.nhs.cfsms.als.cucumber.dev.profile.steps;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import uk.nhs.cfsms.als.config.WebApplicationConfig;
import uk.nhs.cfsms.als.service.AddressLookupService;
import uk.nhs.cfsms.als.vo.AddressVo;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = WebApplicationConfig.class)
@EnableTransactionManagement
@ActiveProfiles("DEV")
public class ALSControllerSteps {
    private static final String PATH = "/address/{jsonAddressString}";

    @Autowired
    AddressLookupService addressLookupService;

    @Autowired
    protected WebApplicationContext wac;

    private ObjectMapper jsonObjectMapper;

    private MockMvc mockMvc;

    private List<AddressVo> addressVosList = new ArrayList<AddressVo>();
    static int counter = 0;

    @Before
    public void setup() {
        this.mockMvc = webAppContextSetup(this.wac).build();
        jsonObjectMapper = new ObjectMapper();
    }

    @Given("^an address repository$")
    public void an_address_repository() throws Throwable {}

    @When("^I search for address based on following first addressline and postcode$")
    public void I_search_for_address_based_on_following_first_addressline_and_postcode(
            List<String> jsonStrings) throws Throwable {
        for (String string : jsonStrings) {
            MvcResult actions = mockMvc
                    .perform(
                            get(PATH, string).contentType(
                                    MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk()).andReturn();
            addressVosList.addAll(getAddressVosList(actions));
        }
    }

    @Then("^I should get following  postcode and addressline below$")
    public void I_should_get_following_postcode_and_as_addressline_below(
            List<String> output) throws Throwable {
        for (AddressVo addressVo : addressVosList) {
            Assert.assertTrue(output.contains(addressVo.getPostCode()));
            Assert.assertTrue(output.contains(addressVo.getAddressLine1()));
        }
    }

    private List<AddressVo> getAddressVosList(final MvcResult mvcResult)
            throws Exception {
        String contentAsString = mvcResult.getResponse().getContentAsString();
        return jsonObjectMapper.readValue(contentAsString,
                new TypeReference<List<AddressVo>>() {
                });
    }
}
