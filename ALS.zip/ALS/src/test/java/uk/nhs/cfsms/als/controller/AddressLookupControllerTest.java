package uk.nhs.cfsms.als.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.cfsms.als.config.WebApplicationConfig;
import uk.nhs.cfsms.als.exceptions.ALSException;
import uk.nhs.cfsms.als.repository.AddressLookupRepository;
import uk.nhs.cfsms.als.service.AddressLookupService;
import uk.nhs.cfsms.als.stub.AddressStub;
import uk.nhs.cfsms.als.vo.AddressVo;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = WebApplicationConfig.class)
@EnableTransactionManagement
@ActiveProfiles("TEST")
public class AddressLookupControllerTest {

    @Autowired
    private WebApplicationContext wac;
    @Autowired
    private AddressLookupService addressLookupService;
    @Autowired
    AddressLookupRepository addressLookupRepository;
    @Autowired
    private AddressLookupController addressLookupController;

    final String[] spChars = { "!", "$", "&", "'", "(", ")", "*", "+", ",",
            "-", ".", "/", ":", "<", "=", ">", "@", "[", "]", "^", "_", "`",
            "{", "}", "|", "~", " ", "�", "�", "�", "�", "�", "�", "�", "�",
            "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�",
            "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�",
            "% 5C", "%3B", "%3F", "%23", "%25", };

    private MockMvc mockMvc;
    private AddressVo addressVo;
    private static boolean isSetupDone;
    private ObjectMapper jsonObjectMapper;

    @Before
    public void setup() throws IllegalAccessException,
            InvocationTargetException {
        addressVo = new AddressVo();
        this.mockMvc = webAppContextSetup(this.wac).dispatchOptions(true)
                .build();
        if (!isSetupDone) {
            List<AddressVo> addressVos = AddressStub.populateAddressVos();
            addressLookupService.createAddresses(addressVos);
        }
        isSetupDone = true;
    }

    /** Controller test **/
    @Test
    public void testControllerRequestMapping() throws Exception {

        String jsonAddressString = "{\"addressLine1\":\"BROCKHILL LANE2\", \"postCode\":\"EC1A 1BB\"}";

        ResultActions resultActions = mockMvc.perform(
                get("/address/{jsonAddressString}", jsonAddressString)
                        .contentType(MediaType.APPLICATION_JSON).accept(
                                MediaType.APPLICATION_JSON)).andDo(print());
        resultActions.andExpect(status().isOk());
    }

    @Test
    public void testControllerRequestMappingWithSPChars() throws Exception {

        for (String ch : spChars) {
            String jsonAddressString = "{\"addressLine1\":\"BROCKHIL" + ch
                    + "LANE2\", \"postCode\":\"EC1A 1BB\"}";

            ResultActions resultActions = mockMvc.perform(
                    get("/address/{jsonAddressString}", jsonAddressString)
                            .contentType(MediaType.APPLICATION_JSON).accept(
                                    MediaType.APPLICATION_JSON)).andDo(print());
            resultActions.andExpect(status().isOk());
        }
    }

    /** Service Tests **/

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Test
    public void testInvalidPostCode() throws IllegalAccessException,
            InvocationTargetException {
        String postCode = "M1$1P4";
        addressVo.setPostCode(postCode);
        expectedEx.expect(ALSException.class);
        expectedEx.expectMessage("Invalid Post Code");
        addressLookupService.findByCriteria(addressVo);
    }

    @Test
    @Ignore
    public void createIndex() {
        try {
            MvcResult mvcResults = mockMvc.perform(
                    get("/address/create-index").param("async", "true"))
                    .andReturn();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    List<AddressVo> getRawObjects(final MvcResult mvcResult) throws Exception {
        return jsonObjectMapper.readValue(mvcResult.getResponse()
                .getContentAsString(),
                new TypeReference<Collection<AddressVo>>() {
                });
    }

    AddressVo getRawObject(final MvcResult mvcResult) throws Exception {
        return jsonObjectMapper.readValue(mvcResult.getResponse()
                .getContentAsString(), new TypeReference<AddressVo>() {
        });
    }

}
