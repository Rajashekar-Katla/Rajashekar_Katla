package uk.nhs.cfsms.als.cucumber.test.profile.steps;

import static org.junit.Assert.assertThat;

import java.util.List;

import org.hamcrest.core.Is;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import uk.nhs.cfsms.als.config.WebApplicationConfig;
import uk.nhs.cfsms.als.service.AddressLookupService;
import uk.nhs.cfsms.als.vo.AddressVo;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@WebAppConfiguration
@ContextConfiguration(classes = WebApplicationConfig.class)
@ActiveProfiles("TEST")
public class AddressLookupSteps {

    @Autowired
    AddressLookupService addressLookupService;

    List<AddressVo> addresses;
    static int counter = 0;

    @Given("^a address repository$")
    public void populate_address_repository() throws Throwable {
        counter++;
    }

    @When("^I search for address based on following \"([^\"]*)\" and \"([^\"]*)\"$")
    public void I_search_for_address_based_on_postcode_and_addressLine1(
            final String addressLine1, final String postCode) throws Throwable {
        final AddressVo addressVo = new AddressVo();
        addressVo.setPostCode(postCode);
        addressVo.setAddressLine1(addressLine1);
        addresses = addressLookupService.findByCriteria(addressVo);
    }

    @When("^I search for address based on following \"([^\"]*)\"$")
    public void I_search_for_address_based_on_postcode(final String postCode)
            throws Throwable {
        final AddressVo addressVo = new AddressVo();
        addressVo.setPostCode(postCode);
        addresses = addressLookupService.findByCriteria(addressVo);
    }

    @When("^I search for address based on following mixed lower upper case postcode and line \"([^\"]*)\" and \"([^\"]*)\"$")
    public void I_search_for_address_based_on_following_mixed_lower_upper_case_postcode_and_line_and(
            final String addressLine1, final String postCode) throws Throwable {
        final AddressVo addressVo = new AddressVo();
        addressVo.setPostCode(postCode);
        addressVo.setAddressLine1(addressLine1);
        addresses = addressLookupService.findByCriteria(addressVo);
    }

    @When("^I search for address based on following postcodes with no space and line \"([^\"]*)\" and \"([^\"]*)\"$")
    public void I_search_for_address_based_on_following_postcodes_with_no_space_and_line_and(
            String addressLine1, String postCode) throws Throwable {
        final AddressVo addressVo = new AddressVo();
        addressVo.setPostCode(postCode);
        addressVo.setAddressLine1(addressLine1);
        addresses = addressLookupService.findByCriteria(addressVo);
    }

    @Then("^I should get address details as \"([^\"]*)\" and \"([^\"]*)\"$")
    public void I_should_get_expected_address_details(final String line1,
            final String postCode) throws Throwable {
        for (final AddressVo addressVo : addresses) {
            assertThat(addressVo.getAddressLine1(), Is.is(line1));
            assertThat(addressVo.getPostCode(), Is.is(postCode));
        }
    }
}
