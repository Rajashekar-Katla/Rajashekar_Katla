-- Phase6-10 is now part of change programme.
------------------------------------------------
-- CHP-1 changes...
------------------------------------------------
-- Exhibits..
ALTER TABLE FIRST.EXHIBIT_TBL ADD (
	FILE_NAME	VARCHAR2(250 BYTE),
	CREATED_STAFF_ID	VARCHAR2(20 BYTE),
	CREATED_TIME	DATE
);
-- Case...
ALTER TABLE FIRST.CASE_TBL ADD (
  ACCEPTANCE_TYPE        NUMBER,
  OTHER_ACCEPTANCE_TYPE  VARCHAR2(150 BYTE)
);

ALTER TABLE FIRST.CASE_UPDATES_TBL
 DROP PRIMARY KEY CASCADE;

DROP TABLE FIRST.CASE_UPDATES_TBL CASCADE CONSTRAINTS;

CREATE TABLE FIRST.CASE_UPDATES_TBL
(
  CASE_UPDATE_ID    NUMBER                      NOT NULL,
  DESCRIPTION       VARCHAR2(1500 BYTE)         NOT NULL,
  CREATED_DATE      DATE                        NOT NULL,
  CREATED_STAFF_ID  VARCHAR2(20 BYTE)           NOT NULL,
  CASE_ID           NUMBER                      NOT NULL
);

ALTER TABLE FIRST.CASE_UPDATES_TBL ADD (
  PRIMARY KEY 
 (CASE_UPDATE_ID)
 );
 -- Messages ...
 ALTER TABLE FIRST.MESSAGE_TBL ADD (
	DELETE_FROM       VARCHAR2(1 BYTE),
	DELETE_TO         VARCHAR2(1 BYTE),
	DELETE_NITS       VARCHAR2(1 BYTE),
	DELETE_NITN       VARCHAR2(1 BYTE)
);

-- CASE ACTION BOOK...
ALTER TABLE FIRST.CASE_ACTION_BOOK_TBL
 DROP PRIMARY KEY CASCADE;

DROP TABLE FIRST.CASE_ACTION_BOOK_TBL CASCADE CONSTRAINTS;

CREATE TABLE FIRST.CASE_ACTION_BOOK_TBL
(
  ACTION_ID         NUMBER                      NOT NULL,
  CASE_ID           NUMBER						NOT NULL,
  RECORDING_DATE    DATE,
  ALLOCATED_BY      VARCHAR2(25 BYTE),
  SOURCE_REFERENCE  VARCHAR2(25 BYTE),
  ACTION_REQUIRED   VARCHAR2(2500 BYTE),
  ALLOCATION_DATE   DATE,
  ALLOCATED_TO      VARCHAR2(25 BYTE),
  ACTION_RESULT     VARCHAR2(2500 BYTE),
  SEEN_BY_OFM       VARCHAR2(1 BYTE),
  COMPLETION_DATE   DATE,
  SENSITIVE         VARCHAR2(1 BYTE),
  ACTION_NUMBER     NUMBER,
  DUE_DATE          DATE,
  ACTION_STATUS     VARCHAR2(1 BYTE)            DEFAULT 0
);
 
ALTER TABLE FIRST.CASE_ACTION_BOOK_TBL ADD (
  CONSTRAINT CASE_ACTION_BOOK_TBL_PK
 PRIMARY KEY
 (ACTION_ID)
 );

DROP SEQUENCE FIRST.ACTION_ID_SEQ;

CREATE SEQUENCE FIRST.ACTION_ID_SEQ
  START WITH 1500
  MAXVALUE 99999999
  MINVALUE 1500
  NOCYCLE
  NOCACHE
  NOORDER;

DROP SYNONYM EXT_FIRST.ACTION_ID_SEQ;

CREATE SYNONYM EXT_FIRST.ACTION_ID_SEQ FOR FIRST.ACTION_ID_SEQ;

GRANT SELECT ON FIRST.ACTION_ID_SEQ TO EXT_FIRST;

DROP TABLE FIRST.ACTION_ATTACHMENT_TABLE CASCADE CONSTRAINTS;

CREATE TABLE FIRST.ACTION_ATTACHMENT_TABLE
(
  ACTION_ATTACHMENT_ID    NUMBER NOT NULL,
  ACTION_ID               NUMBER NOT NULL,
  ATTACHMENT_NAME         VARCHAR2(30 BYTE),
  ATTACHMENT_TYPE         VARCHAR2(10 BYTE),
  ATTACHMENT_BLOB         BLOB,
  CREATION_TIME           TIMESTAMP(6) WITH TIME ZONE,
  CREATED_BY              VARCHAR2(25 BYTE),
  SENSITIVE               VARCHAR2(1 BYTE),
  MARK_AS_DELETED         VARCHAR2(1 BYTE),
  ATTACHMENT_NUMBER       NUMBER,
  ATTACHMENT_DESCRIPTION  VARCHAR2(500 BYTE)
);
ALTER TABLE FIRST.ACTION_ATTACHMENT_TABLE ADD (
  CONSTRAINT ACTION_ATTACHMENT_TABLE_PK
 PRIMARY KEY
 (ACTION_ATTACHMENT_ID));
 
 -- Access Control list..
delete from access_control_tbl where ACCESS_ID > 190;
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (191,'/secure/deletemessage.htm','ADMIN,DIR,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS,REP','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (192,'/secure/showCaseActionBookList.htm','ADMIN,DIR,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS,REP','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (193,'/secure/addNewCaseActionBook.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (194,'/secure/deleteallmessages.htm','ADMIN,DIR,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (195,'/secure/saveCaseActionBook.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (196,'/secure/updateCaseActionBook.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (197,'/secure/viewCaseActionBook.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (198,'/secure/viewAllCaseActionBookSheets.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (199,'/secure/caseprogresslog.htm','ADMIN,DIR,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (200,'/secure/actionBookAttachments.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (201,'/secure/addActionBookAttachments.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (202,'/secure/downloadActionBookAttachment.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (203,'/secure/listAllTrashMessages.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (204,'/secure/restoreAllMessages.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (205,'/secure/filterSearchActions.htm','ADMIN,DIR,OFM,AFL,AFS','','','',sysdate,'');
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (206,'/secure/filterActionSearchResults.htm','ADMIN,DIR,OFM,AFL,AFS','','','',sysdate,'');
commit;

-- lookup group and details data...

delete from LOOKUP_GROUP_TBL where LOOKUP_GROUP_ID=42;
insert into LOOKUP_GROUP_TBL (LOOKUP_GROUP_ID,LOOKUP_GROUP_NAME,CREATED_BY,CREATED_DATE) values (42,'CASE_ACCEPTANCE_TYPE','admin',sysdate);
commit;

delete from lookup_tbl where lookup_id> 1461 and lookup_group_id=42;
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1462,42,'Bribery and/or Corruption','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1463,42,'Complex Fraud/Investigation','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1464,42,'Criminal Trend/Organised Crime','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1465,42,'Department of Health','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1466,42,'Health Act Required','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1467,42,'LCFS/LSMS/Consortia Suspects','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1468,42,'Linked Case','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1469,42,'Multi Agency Investigation','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1470,42,'National Public Interest','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1471,42,'RIPA Required','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1472,42,'Senior NHS Management Suspects','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1473,42,'Strategic/National Significance','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1474,42,'Wider NHS Impact','','Y','admin',sysdate);
insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,PARENT_ID,ACTIVE,CREATED_BY,CREATED_DATE) values (1475,42,'Other','','Y','admin',sysdate);
commit;

-- Case Action book search view..

DROP VIEW FIRST.CASE_ACTION_SEARCH_VIEW;

/* Formatted on 20/12/2012 14:41:45 (QP5 v5.126.903.23003) */
CREATE OR REPLACE FORCE VIEW FIRST.CASE_ACTION_SEARCH_VIEW (
   ACTION_ID,
   CASE_ID,
   ACTION_NUMBER,
   RECORDING_DATE,
   ALLOCATED_TO_STAFF_ID,
   ALLOCATED_BY_STAFF_ID,
   ALLOCATED_BY_FORNAME,
   ALLOCATED_BY_SURNAME,
   ALLOCATED_TO_FORNAME,
   ALLOCATED_TO_SURNAME,
   COMPLETION_DATE,
   DUE_DATE,
   ACTION_STATUS,
   CASE_NUMBER,
   OPERATION_NAME,
   CASE_STATE
)
AS
   SELECT   ca.action_id,
            ca.case_id,
            ca.action_number,
            ca.recording_date,
            ato.staff_id AS ALLOCATED_TO_STAFF_ID,
            aby.staff_id AS ALLOCATED_BY_STAFF_ID,
            aby.forename1 AS ALLOCATED_BY_FORNAME,
            aby.surname AS ALLOCATED_BY_SURNAME,
            ato.forename1 AS ALLOCATED_TO_FORNAME,
            ato.surname AS ALLOCATED_TO_SURNAME,
            ca.completion_date,
            ca.due_date,
            ca.action_status,
            c.case_number,
            c.operation_name,
            c.state
     FROM   case_action_book_tbl ca,
            case_tbl c,
            all_users_view ato,
            all_users_view aby
    WHERE       ca.case_id = c.case_id
            AND ca.allocated_to = ato.staff_id(+)
            AND ca.allocated_by = aby.staff_id(+);

-- ---------------------------------------------------
-- CHP-2 changes
-- ---------------------------------------------------

ALTER TABLE FIRST.INFORMATION_TBL ADD
(
  INFO_APPROVAL_STATUS     VARCHAR2(1 BYTE)
);

ALTER TABLE  FIRST.INFO_TRANS_TEAM_HIST_TBL ADD
(
  APPROVER_STAFF_ID   VARCHAR2(10 BYTE),
  TRANSFER_COMMENTS   VARCHAR2(200 BYTE),
  APPROVAL_COMMENTS   VARCHAR2(200 BYTE)
);

ALTER TABLE FIRST.CASE_TRANSFER_TBL ADD
(
  APPROVER_STAFF_ID  VARCHAR2(10 BYTE),
  APPROVAL_STATUS    VARCHAR2(1 BYTE),
  APPROVAL_TIME      DATE,
  APPROVER_COMMENTS  VARCHAR2(1000 BYTE)
);

-- access controls.
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (207,'/secure/informationTransfer.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');    
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (208,'/secure/pendinginformationtransferlist.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');    
insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (209,'/secure/informationTransferApproval.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
commit;

-- -----------------------------------------------
