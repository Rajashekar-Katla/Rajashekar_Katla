	-- REVISION, CASE LOGS ... 
	-- Created 	-02/May/2013
	-- Modified	-02/Aug/2013
	
	DROP TABLE FIRST.REVCHANGES CASCADE CONSTRAINTS;
	
	CREATE TABLE FIRST.REVCHANGES
	(
	  REV         NUMBER(10)                        NOT NULL,
	  ENTITYNAME  VARCHAR2(255 BYTE)
	);
	
	
	DROP TABLE FIRST.REVISION_HISTORY CASCADE CONSTRAINTS;
	
	CREATE TABLE FIRST.REVISION_HISTORY
	(
	  REV             NUMBER(10)                    NOT NULL,
	  CASE_ID         NUMBER(19),
	  REVTSTMP        NUMBER(19),
	  TABLENAME       VARCHAR2(255 CHAR),
	  INFORMATION_ID  NUMBER(19),
	  USER_ID         VARCHAR2(255 BYTE),
	  USER_NAME       VARCHAR2(255 CHAR),
	  FLOW_NAME       VARCHAR2(255 CHAR)
	);


	-- APPEALS ...
	insert into LOOKUP_GROUP_TBL (LOOKUP_GROUP_ID,LOOKUP_GROUP_NAME,CREATED_BY,CREATED_DATE) values (43,'CASE_COURT_TYPE_APPEAL','admin',sysdate);
	insert into LOOKUP_GROUP_TBL (LOOKUP_GROUP_ID,LOOKUP_GROUP_NAME,CREATED_BY,CREATED_DATE) values (44,'CASE_APPEARANCE_TYPE_APPEAL','admin',sysdate);
	
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1476,43,'Court of appeal (Single Judge)','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1477,43,'Court of appeal (Full Court)','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1478,43,'Criminal Cases Review Commission','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1479,43,'European Court of Human Rights','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1480,43,'House of Lords','Y','admin',sysdate);
	
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1481,44,'Application for leave to appeal','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1482,44,'Appeal Hearing','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1483,44,'Other','Y','admin',sysdate);

	-- SUCCESS_SANCTIONS,UNSUCCESS_SANCTIONS and SANCTION_ORDERS ...
	
	insert into LOOKUP_GROUP_TBL (LOOKUP_GROUP_ID,LOOKUP_GROUP_NAME,CREATED_BY,CREATED_DATE) values (45,'SUCCESS_SANCTIONS','admin',sysdate);
	insert into LOOKUP_GROUP_TBL (LOOKUP_GROUP_ID,LOOKUP_GROUP_NAME,CREATED_BY,CREATED_DATE) values (46,'UNSUCCESS_SANCTIONS','admin',sysdate);
	insert into LOOKUP_GROUP_TBL (LOOKUP_GROUP_ID,LOOKUP_GROUP_NAME,CREATED_BY,CREATED_DATE) values (47,'SANCTION_ORDERS','admin',sysdate);
	
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1484,45,'IMPRISONMENT','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1485,45,'IMPRISONMENT - SUSPENDED','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1486,45,'FINE','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1487,45,'CAUTION','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1488,45,'CONDITIONAL CAUTION','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1489,45,'COMMUNITY PUNISHMENT AND REHABILITATION ORDER','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1490,45,'COMMUNITY ORDERS','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1491,45,'CONDITIONAL DISCHARGE','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1492,45,'ABSOLUTE DISCHARGE','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1493,45,'INTERMITTENT CUSTODY','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1494,45,'CUSTODY PLUS','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1495,45,'CURFEW ORDER','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1496,45,'COMMUNITY REHABILITATION','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1497,45,'DRUG TREATMENT AND TESTING ORDER','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1498,45,'ATTENDANCE CENTRE ORDER','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1499,45,'OTHER','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1500,46,'WITHDRAWAL','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1501,46,'ACQUITTAL','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1502,47,'ANTI SOCIAL BEHAVIOUR ORDER','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1503,47,'PROTECTION FROM HARASSMENT ORDER','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1504,47,'CONFISCATION ORDER','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1505,47,'COMPENSATION ORDER','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1506,47,'MENTAL HEALTH ACT ORDER','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1507,47,'CONDITIONAL ORDER CAUTION','Y','admin',sysdate);

	-- APPEALS CRIMINAL/CIVIL/DISPLINARY... 25/11/2013
	
	insert into LOOKUP_GROUP_TBL (LOOKUP_GROUP_ID,LOOKUP_GROUP_NAME,CREATED_BY,CREATED_DATE) values (48,'CRIMINAL_APPEAL_COURT_TYPE','admin',sysdate);
	insert into LOOKUP_GROUP_TBL (LOOKUP_GROUP_ID,LOOKUP_GROUP_NAME,CREATED_BY,CREATED_DATE) values (49,'CIVIL_APPEAL_COURT_TYPE','admin',sysdate);
	insert into LOOKUP_GROUP_TBL (LOOKUP_GROUP_ID,LOOKUP_GROUP_NAME,CREATED_BY,CREATED_DATE) values (50,'INT_DISP_APPEAL_COURT_TYPE','admin',sysdate);
	insert into LOOKUP_GROUP_TBL (LOOKUP_GROUP_ID,LOOKUP_GROUP_NAME,CREATED_BY,CREATED_DATE) values (51,'EXT_DISP_APPEAL_COURT_TYPE','admin',sysdate);
	
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1510,48,'Crown Court','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1511,48,'Criminal Cases Review Commission','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1512,48,'Court of Appeal','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1513,48,'Supreme Court(European Court of Justice)','Y','admin',sysdate);
	
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1515,49,'County Court','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1516,49,'High Court','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1517,49,'Court of Appeal','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1518,49,'Supreme Court(European Court of Justice)','Y','admin',sysdate);

	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1520,50,'Employing Trust','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1521,50,'Employment Tribunal','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1522,50,'Employment Appeal Tribunal','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1523,50,'High Court','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1524,50,'Court of Appeal','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1526,50,'Supreme Court(European Court of Justice)','Y','admin',sysdate);

	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1527,51,'Regulatory Body (e.g. GMC)','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1528,51,'High Court','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1529,51,'Court of Appeal','Y','admin',sysdate);
	insert into LOOKUP_TBL (LOOKUP_ID,LOOKUP_GROUP_ID,DESCRIPTION,ACTIVE,CREATED_BY,CREATED_DATE) values (1530,51,'Supreme Court(European Court of Justice)','Y','admin',sysdate);

	-- Criminal appeals....
	
	DROP TABLE FIRST.CRIMINAL_APPEAL_TBL CASCADE CONSTRAINTS;
	
	CREATE TABLE FIRST.CRIMINAL_APPEAL_TBL
	(
	  APPEAL_ID              NUMBER,
	  CASE_ID                NUMBER                 NOT NULL,
	  SUBJECT_ID             NUMBER                 NOT NULL,
	  SUBJECT_TYPE           VARCHAR2(20 BYTE),
	  CREATED_STAFF_ID       VARCHAR2(10 BYTE),
	  CREATED_TIME           DATE,
	  APPEARED_DATE          DATE,
	  COURT_MAKING_DEC_NAME  VARCHAR2(100 BYTE),
	  STATE                  VARCHAR2(50 BYTE),
	  OLD_ID_KEY             NUMBER,
	  ACCESS_FLAG            VARCHAR2(1 BYTE)       DEFAULT 'R',
	  APPEAL_MAKER			 VARCHAR2(500 BYTE),
	  SANCTION_ID            NUMBER,
	  PARENT_APPEAL_ID		 NUMBER
	);
	
	DROP TABLE FIRST.APPEAL_HEARING_TBL CASCADE CONSTRAINTS;
	
	CREATE TABLE FIRST.APPEAL_HEARING_TBL
	(
	  APPEARANCE_ID    NUMBER,
	  SANCTION_ID      NUMBER,
	  SANCTION_TYPE    VARCHAR2(2000 BYTE),
	  COURT_NAME       VARCHAR2(100 BYTE),
	  HEARING_DATE     DATE,
	  HEARING_TIME     VARCHAR2(15 BYTE),
	  COURT_TYPE       VARCHAR2(50 BYTE),
	  APPEARANCE_TYPE  VARCHAR2(50 BYTE),
	  OLD_ID_KEY       NUMBER,
	  OUTCOME_INFO     CLOB,
	  ACCESS_FLAG      VARCHAR2(1 BYTE)             DEFAULT 'R'
	)
	;
	
	DROP TABLE FIRST.APPEAL_OUTCOME_TBL CASCADE CONSTRAINTS;
	DROP TABLE FIRST.APPEAL_OUTCOME_TBL_A CASCADE CONSTRAINTS; 
	
	CREATE TABLE FIRST.APPEAL_OUTCOME_TBL
	(
	  OUTCOME_ID                  NUMBER,
	  APPEAL_ID        			  NUMBER,
	  OUTCOME_DATE                DATE,
	  DESCRIPTION                 VARCHAR2(4000 BYTE),
	  CREATED_STAFF_ID            VARCHAR2(10 BYTE),
	  CREATED_TIME                DATE              DEFAULT sysdate,
	  OUTCOME_STATUS              VARCHAR2(20 BYTE),
	  SENTENCE_VARIED             VARCHAR2(200 BYTE),
	  COMPENSATION_PAYEE          VARCHAR2(50 BYTE),
	  OTHER_SANCTION              VARCHAR2(500 BYTE),
	  ORDER_CONDITION             VARCHAR2(500 BYTE),
	  AWARDED_INV_COST            NUMBER(10,2),
	  AWARDED_PROS_COST           NUMBER(10,2),
	  CRIMINAL_CONFISCATION_COST  NUMBER(10,2),
	  AWARDED_COMPENSATION        NUMBER(10,2),
	  OLD_ID_KEY                  NUMBER,
	  CONFISCATION_NUMBER         VARCHAR2(50 BYTE),
	  APPLIED_INV_COST            NUMBER(10,2),
	  APPLIED_PROS_COST           NUMBER(10,2),
	  APPLIED_COMPENSATION        NUMBER(10,2),
	  COSTS_VARIED					VARCHAR2(20),
	  COSTS_AWARDED					VARCHAR2(150),
	  ACCESS_FLAG                 VARCHAR2(1 BYTE)  DEFAULT 'R'
	)
	;

-- Disciplinary appeals.
	ALTER TABLE FIRST.DISCIPLINARY_APPEAL_TBL DROP PRIMARY KEY CASCADE;
	
	DROP TABLE FIRST.DISCIPLINARY_APPEAL_TBL CASCADE CONSTRAINTS;
	
	DROP TABLE FIRST.DISCIPLINARY_APPEAL_TBL_A CASCADE CONSTRAINTS;
	 
	CREATE TABLE FIRST.DISCIPLINARY_APPEAL_TBL
	(
	  APPEAL_ID          NUMBER,
	  CASE_ID            NUMBER,
	  SUBJECT_ID         NUMBER,
	  SUBJECT_TYPE       VARCHAR2(20 BYTE),
	  CREATED_STAFF_ID   VARCHAR2(10 BYTE),
	  CREATED_TIME       DATE,
	  STATE              VARCHAR2(50 BYTE),
	  SANCTION_TYPE      VARCHAR2(20 BYTE),
	  ORG_NAME           VARCHAR2(100 BYTE),
	  START_DATE         DATE,
	  OLD_ID_KEY         NUMBER,
	  HR_CONTACT         VARCHAR2(100 BYTE),
	  INVST_MGR_CONTACT  VARCHAR2(100 BYTE),
	  PROF_CONTACT       VARCHAR2(100 BYTE),
	  HB_CONTACT         VARCHAR2(100 BYTE),
	  ACCESS_FLAG        VARCHAR2(1 BYTE)           DEFAULT 'R',
	  ORG_MAK_DEC_NAME   VARCHAR2(100 BYTE),
	  APPEAL_MAKER       VARCHAR2(100 BYTE),
	  SANCTION_ID        NUMBER,
	  PARENT_APPEAL_ID   NUMBER,
	  OTHER_SUBJECT      VARCHAR2(500 BYTE),
	  APPELLANT_TYPE     VARCHAR2(20 BYTE)
	)
	;
	

	DROP SYNONYM EXT_FIRST.DISCIPLINARY_APPEAL_TBL;

	CREATE SYNONYM EXT_FIRST.DISCIPLINARY_APPEAL_TBL FOR FIRST.DISCIPLINARY_APPEAL_TBL;

	GRANT DELETE, INDEX, INSERT, SELECT, UPDATE ON FIRST.DISCIPLINARY_APPEAL_TBL TO EXT_FIRST;


	-- old bits - removed.
	ALTER TABLE FIRST.DISC_APPEAL_HEARING_TBL DROP PRIMARY KEY CASCADE;
	DROP TABLE FIRST.DISC_APPEAL_HEARING_TBL CASCADE CONSTRAINTS;
	DROP TABLE FIRST.DISC_APPEAL_HEARING_TBL_A CASCADE CONSTRAINTS;
	-- new naming and alterations
	ALTER TABLE FIRST.DISP_APPEAL_HEARING_TBL DROP PRIMARY KEY CASCADE;
	
	DROP TABLE FIRST.DISP_APPEAL_HEARING_TBL CASCADE CONSTRAINTS;
	
	DROP TABLE FIRST.DISP_APPEAL_HEARING_TBL_A CASCADE CONSTRAINTS;
	
	CREATE TABLE FIRST.DISP_APPEAL_HEARING_TBL
	(
	  HEARING_ID                NUMBER,
	  APPEAL_ID  				NUMBER,
	  HEARING_TYPE              VARCHAR2(200 BYTE),
	  HEARING_OUTCOME           VARCHAR2(4000 BYTE),
	  HEARING_DATE              DATE,
	  HEARING_ORG_NAME          VARCHAR2(100 BYTE),
	  HEARING_ADDRESS1          VARCHAR2(50 BYTE),
	  HEARING_ADDRESS2          VARCHAR2(50 BYTE),
	  HEARING_ADDRESS3          VARCHAR2(50 BYTE),
	  HEARING_ADDRESS4          VARCHAR2(50 BYTE),
	  HEARING_POSTCODE          VARCHAR2(20 BYTE),
	  CREATED_STAFF_ID          VARCHAR2(10 BYTE),
	  CREATED_TIME              DATE,
	  OLD_ID_KEY                NUMBER,
	  ACCESS_FLAG               VARCHAR2(1 BYTE)    DEFAULT 'R'
	)
	;

	-- old bits - removed.
	ALTER TABLE FIRST.DISC_SANC_APPEAL_OUTCOME_TBL DROP PRIMARY KEY CASCADE;
	DROP TABLE FIRST.DISC_SANC_APPEAL_OUTCOME_TBL CASCADE CONSTRAINTS;
	DROP TABLE FIRST.DISC_SANC_APPEAL_OUTCOME_TBL_A CASCADE CONSTRAINTS;
	-- new naming and alterations
	ALTER TABLE FIRST.DISP_APPEAL_OUTCOME_TBL DROP PRIMARY KEY CASCADE;
	
	DROP TABLE FIRST.DISP_APPEAL_OUTCOME_TBL CASCADE CONSTRAINTS;
	
	DROP TABLE FIRST.DISP_APPEAL_OUTCOME_TBL_A CASCADE CONSTRAINTS;
	
	CREATE TABLE FIRST.DISP_APPEAL_OUTCOME_TBL
	(
	  OUTCOME_ID                NUMBER,
	  APPEAL_ID  				NUMBER,
	  OUTCOME_DATE              DATE,
	  CREATED_STAFF_ID          VARCHAR2(10 BYTE),
	  CREATED_TIME              DATE,
	  OUTCOME_STATUS            VARCHAR2(50 BYTE),
	  SANCTIONS_IMPOSED         VARCHAR2(3000 BYTE),
	  OTHER_SANCTION_IMPOSED    VARCHAR2(100 BYTE),
	  OLD_ID_KEY                NUMBER,
	  ACCESS_FLAG               VARCHAR2(1 BYTE)    DEFAULT 'R'
	)
	;

-- Civil appeals.
	
	ALTER TABLE FIRST.CIVIL_APPEAL_TBL DROP PRIMARY KEY CASCADE;
	
	DROP TABLE FIRST.CIVIL_APPEAL_TBL CASCADE CONSTRAINTS;
	
	DROP TABLE FIRST.CIVIL_APPEAL_TBL_A CASCADE CONSTRAINTS;
	
	CREATE TABLE FIRST.CIVIL_APPEAL_TBL
	(
	  APPEAL_ID                NUMBER(19)           NOT NULL,
	  CASE_ID                  NUMBER(19)           NOT NULL,
	  PARENT_APPEAL_ID         NUMBER(19),
	  SANCTION_ID              NUMBER(19),
	  OUTCOME_TYPE             VARCHAR2(255 BYTE),
	  OUTCOME_ID               NUMBER(19),
	  APPELLANT               VARCHAR2(255 BYTE),
	  CREATED_STAFF_ID         VARCHAR2(255 BYTE),
	  CREATED_TIME             DATE,
	  APPEAL_DATE              DATE,
	  DATE_OF_ORG_DECS         DATE,
	  DECISION_APPEAL_AGAINST  VARCHAR2(255 BYTE),
	  LEGAL_CONTACT            VARCHAR2(255 BYTE),
	  COURT_ORG_DECISION       VARCHAR2(255 BYTE),
	  STATE                    VARCHAR2(255 BYTE),
	  SUBJECT_TYPE             VARCHAR2(255 BYTE),
	  SUBJECT_ID               NUMBER(19),	  
	  APPEALED_OUTCOME_ID      NUMBER(19),
	  APPEALED_OUTCOME_TYPE    VARCHAR2(255 BYTE),
	  NHS_SUBJECT_NAME         VARCHAR2(255 BYTE),
	  NON_NHS_SUBJECT_NAME     VARCHAR2(255 BYTE),
	  PERSON_SUBJECT_NAME      VARCHAR2(255 BYTE),
	  OTHERSUBJECTS            VARCHAR2(255 BYTE),
	  APPELLANT_TYPE           VARCHAR2(255 BYTE)
	);
	
	
	ALTER TABLE FIRST.CIVIL_APPEAL_OUTCOME_TBL 
	DROP PRIMARY KEY CASCADE;

	DROP TABLE FIRST.CIVIL_APPEAL_OUTCOME_TBL CASCADE CONSTRAINTS;

	CREATE TABLE FIRST.CIVIL_APPEAL_OUTCOME_TBL
	(
	  OUTCOME_ID                 NUMBER(19)         NOT NULL,
	  APPEAL_ID                  NUMBER(19)			NOT NULL, 
	  AMT_AWARDED_FOR_THIS       VARCHAR2(255 CHAR),
	  CREATED_STAFF_ID           VARCHAR2(255 CHAR),
	  CREATED_TIME               TIMESTAMP(6),
	  DATE_OUTCOME               TIMESTAMP(6),
	  SUMMONS_ORDERS_MADE        VARCHAR2(255 CHAR),
	  OUTCOME_STATUS             VARCHAR2(255 CHAR),
	  TOTAL_COST_CVL_ACT_STLLMT  VARCHAR2(255 CHAR)
	);
	
	ALTER TABLE FIRST.CIVIL_APPEAL_OUTCOME_TBL ADD (
	  PRIMARY KEY (OUTCOME_ID));
	
	ALTER TABLE FIRST.CIVIL_APPEAL_OUTCOME_TBL ADD (
	  CONSTRAINT FKC6CDD7232D74986A 
	 FOREIGN KEY (APPEAL_ID) 
	 REFERENCES FIRST.CIVIL_APPEAL_TBL (APPEAL_ID));
	

	-- Views

	DROP VIEW FIRST.AUDIT_VIEW;
	
	/* Formatted on 22/04/2013 13:13:07 (QP5 v5.126.903.23003) */
	CREATE OR REPLACE FORCE VIEW FIRST.AUDIT_VIEW (
	   REV,
	   REVTSTMP,
	   CASE_ID,
	   INFORMATION_ID,
	   USER_ID,
	   FLOW_NAME,
	   USER_NAME
	)
	AS
	     SELECT   rev.REV,
	              rev.revtstmp,
	              CASE_ID,
	              INFORMATION_ID,
	              USER_ID,
	              FLOW_NAME,
	              (SELECT      auv1.forename1
	                        || ' '
	                        || auv1.forename2
	                        || ' '
	                        || auv1.surname
	                 FROM   all_users_view auv1
	                WHERE   auv1.staff_id = rev.user_id)
	                 AS USER_NAME
	       FROM   revision_history rev
	   ORDER BY   rev DESC;
	
	
	   
	   DROP VIEW FIRST.CRIMINAL_APPEAL_VIEW;
	
	/* Formatted on 22/04/2013 13:13:48 (QP5 v5.126.903.23003) */
	CREATE OR REPLACE FORCE VIEW FIRST.CRIMINAL_APPEAL_VIEW (
	   APPEAL_ID,
	   CASE_ID,
	   SUBJECT_ID,
	   SUBJECT_TYPE,
	   CREATED_STAFF_ID,
	   CREATED_TIME,
	   APPEARED_DATE,
	   COURT_MAKING_DEC_NAME,
	   STATE,
	   NHS_SUBJECT_NAME,
	   NON_NHS_SUBJECT_NAME,
	   PERSON_SUBJECT_NAME,
	   APPELLANT_NAME,
	   SANCTION_ID,
	   PARENT_APPEAL_ID,
	   OTHER_SUBJECT
	   
	)
	AS
	   SELECT   cs.appeal_id,
	            cs.case_id,
	            cs.subject_id,
	            cs.subject_type,
	            cs.created_staff_id,
	            cs.created_time,
	            cs.appeared_Date,
	            cs.court_making_dec_name,
	            cs.state,
	            (SELECT   org1.org_name
	               FROM   organisations_tbl org1
	              WHERE   nhs.org_code = org1.org_code)
	               AS nhs_subject,
	            non.company_name AS non_nhs_subject,
	            (SELECT   p.title || ' ' || p.first_name || ' ' || p.last_name
	               FROM   person_tbl p
	              WHERE   subj.subject_person_id = p.person_id)
	               AS subject_0,
	            cs.appeal_maker,
	            cs.sanction_id,
	            cs.parent_appeal_id
	     FROM            criminal_appeal_tbl cs
	                  LEFT JOIN
	                     information_subj_non_nhs_tbl non
	                  ON cs.subject_id = non.subject_non_nhs_id
	                     AND cs.subject_type = 'NON_NHS'
	               LEFT JOIN
	                  information_subject_nhs_tbl nhs
	               ON cs.subject_id = nhs.subject_nhs_id
	                  AND cs.subject_type = 'NHS'
	            LEFT JOIN
	               information_subject_tbl subj
	            ON cs.subject_id = subj.subject_id AND cs.subject_type = 'PERSON';
	
	
	   
    DROP VIEW FIRST.CIVIL_APPEAL_VIEW;
	
	/* Formatted on 22/04/2013 13:13:30 (QP5 v5.126.903.23003) */
	CREATE OR REPLACE FORCE VIEW FIRST.CIVIL_APPEAL_VIEW (
	   APPEAL_ID,
	   SANCTION_ID,
	   APPEALED_OUTCOME_ID,
	   APPEALED_OUTCOME_TYPE,
	   SUBJECT_ID,
	   SUBJECT_TYPE,
	   LEGAL_CONTACT,
	   CREATED_STAFF_ID,
	   CREATED_TIME,
	   APPEAL_DATE,
	   STATE,
	   COURT_ORG_DECISION,
	   DATE_OF_ORG_DECS,
	   DECISION_APPEAL_AGAINST,
	   APPELLANT,
	   OTHERSUBJECTS,
	   NHS_SUBJECT_NAME,
	   NON_NHS_SUBJECT_NAME,
	   PERSON_SUBJECT_NAME,
	   CASE_ID,
	   PARENT_APPEAL_ID,
	   APPELLANT_TYPE
	)
	AS
		SELECT  cs.appeal_id,       
          cs.sanction_id,
          cs.appealed_outcome_id,
          cs.appealed_outcome_type,
          cs.subject_id,
          cs.SUBJECT_TYPE,
          cs.legal_contact,
          cs.created_staff_id,
          cs.created_time,
          cs.appeal_date,
          cs.state,
          cs.court_org_decision,
          cs.date_of_org_decs,
          cs.decision_appeal_against,
          cs.appellant,
          cs.othersubjects,          
          (SELECT org.org_name
           FROM organisations_tbl org, information_subject_nhs_tbl nhs
           WHERE nhs.org_code = org.org_code AND  cs.subject_id = nhs.subject_nhs_id(+)
           AND cs.SUBJECT_TYPE = 'NHS' ) NHS_SUBJECT_NAME,
            
          (SELECT non.company_name 
           FROM information_subj_non_nhs_tbl non
           WHERE cs.subject_id = non.subject_non_nhs_id(+)
           AND cs.SUBJECT_TYPE = 'NON_NHS' ) NON_NHS_SUBJECT_NAME,   
         
           (SELECT p.title || ' ' || p.first_name || ' ' || p.last_name as PERSON_SUBJECT_NAME
           FROM person_tbl p, information_subject_tbl subj
           WHERE subj.subject_person_id = p.person_id
           AND  cs.subject_id = subj.subject_id(+) AND cs.SUBJECT_TYPE = 'PERSON') PERSON_SUBJECT_NAME,
           
           cs.case_id,
           cs.parent_appeal_id,
           cs.APPELLANT_TYPE
           
           FROM CIVIL_APPEAL_TBL cs;
	
	
	
	DROP VIEW FIRST.DISCIPLINARY_APPEAL_VIEW;
	
DROP VIEW FIRST.DISCIPLINARY_APPEAL_VIEW;

/* Formatted on 06/01/2014 14:26:22 (QP5 v5.126.903.23003) */
CREATE OR REPLACE FORCE VIEW FIRST.DISCIPLINARY_APPEAL_VIEW (
   APPEAL_ID,
   CASE_ID,
   SUBJECT_ID,
   SUBJECT_TYPE,
   CREATED_STAFF_ID,
   CREATED_TIME,
   STATE,
   SANCTION_TYPE,
   ORG_NAME,
   START_DATE,
   HR_CONTACT,
   INVST_MGR_CONTACT,
   PROF_CONTACT,
   HB_CONTACT,
   NHS_SUBJECT_NAME,
   NON_NHS_SUBJECT_NAME,
   PERSON_SUBJECT_NAME,
   ORG_MAK_DEC_NAME,
   SANCTION_ID,
   OTHER_SUBJECT,
   APPEAL_MAKER,
   PARENT_APPEAL_ID,
   APPELLANT_TYPE
)
AS
   SELECT   ds.appeal_id,
            ds.case_id,
            ds.subject_id,
            ds.subject_type,
            ds.created_staff_id,
            ds.created_time,
            ds.state,
            ds.sanction_type,
            ds.org_name,
            ds.start_date,
            ds.hr_contact,
            ds.invst_mgr_contact,
            ds.prof_contact,
            ds.hb_contact,
            (SELECT   org1.org_name
               FROM   organisations_tbl org1
              WHERE   nhs.org_code = org1.org_code)
               AS nhs_subject_name,
            non.company_name AS non_nhs_subject_name,
            (SELECT   p.title || ' ' || p.first_name || ' ' || p.last_name
               FROM   person_tbl p
              WHERE   subj.subject_person_id = p.person_id)
               AS person_subject_name,
            ds.org_mak_dec_name,
            ds.sanction_id,
            ds.other_subject,
            ds.appeal_maker,
            ds.parent_appeal_id,
            ds.appellant_type
     FROM            disciplinary_appeal_tbl ds
                  LEFT JOIN
                     information_subj_non_nhs_tbl non
                  ON ds.subject_id = non.subject_non_nhs_id
                     AND ds.subject_type = 'NON_NHS'
               LEFT JOIN
                  information_subject_nhs_tbl nhs
               ON ds.subject_id = nhs.subject_nhs_id
                  AND ds.subject_type = 'NHS'
            LEFT JOIN
               information_subject_tbl subj
            ON ds.subject_id = subj.subject_id AND ds.subject_type = 'PERSON';
	-- Sequence...
 
	DROP SEQUENCE FIRST.CPS_DOCUMENTS_ID_SEQ;
	
	CREATE SEQUENCE FIRST.CPS_DOCUMENTS_ID_SEQ
	  START WITH 433
	  MAXVALUE 9999999999999999
	  MINVALUE 433
	  NOCYCLE
	  NOCACHE
	  NOORDER;
	
	DROP SEQUENCE FIRST.CIVIL_APPEAL_ID_SQNC;
	
	DROP SEQUENCE FIRST.DISCIPLINARY_APPEAL_ID_SQNC;
	
	CREATE SEQUENCE FIRST.DISCIPLINARY_APPEAL_ID_SQNC
	  START WITH 417
	  MAXVALUE 9999999999999999
	  MINVALUE 417
	  NOCYCLE
	  CACHE 20
	  NOORDER;
	
	CREATE SEQUENCE FIRST.CIVIL_APPEAL_ID_SQNC
	  START WITH 513
	  MAXVALUE 9999999999999999
	  MINVALUE 513
	  NOCYCLE
	  NOCACHE
	  NOORDER;
	
	DROP SEQUENCE FIRST.CVL_APPEAL_OUT_ID_SQNC;
	
	CREATE SEQUENCE FIRST.CVL_APPEAL_OUT_ID_SQNC
	  START WITH 527
	  MAXVALUE 9999999999999999
	  MINVALUE 527
	  NOCYCLE
	  CACHE 20
	  NOORDER;

 	-- Access controls
  
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (210,'/secure/entitiesChanged.htm','ADMIN,DIR,OFM,CFS,LCFS,FCRL,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (211,'/secure/criminalAppealInput.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (212,'/secure/appealDetails.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (213,'/secure/showAppealHearing.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (214,'/secure/criminalAppeal.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (215,'/secure/editCriminalAppealOutcome.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (216,'/secure/saveCriminalAppeal.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (217,'/secure/deleteCriminalAppeal.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (218,'/secure/createAppealHearing.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (219,'/secure/disciplinaryAppealDetails.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (220,'/secure/saveDisciplinaryAppeal.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (221,'/secure/showDisciplinaryAppealHearings.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (222,'/secure/disciplinaryAppealHearingDetails.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (223,'/secure/saveDisciplinaryAppealHearing.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (224,'/secure/viewCPSDocumentList.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (225,'/secure/deleteDisciplinaryAppealHearing.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (226,'/secure/showDisciplinaryAppealOutcome.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (227,'/secure/saveDisciplinaryAppealOutcome.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (228,'/secure/downloadCPSDoc.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (229,'/secure/showCriminalAppeals.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (230,'/secure/submitFiles.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (231,'/secure/showDisciplinaryAppeals.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (232,'/secure/submitLeadApproval.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (233,'/secure/showCPSDocsHistory.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (234,'/secure/showCivilAppeals.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (235,'/secure/civilAppealInput.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (237,'/secure/saveCivilAppeal.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (238,'/secure/editCivilAppealOutcome.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (239,'/secure/saveCivilAppealOutcome.htm','ADMIN,DIR,REP,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	-- Added in JUNE-2013
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (240,'/secure/markAsUnread.htm','ADMIN,DIR,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
	insert into access_control_tbl (ACCESS_ID,URL_PATH,ACCESS_LEVELS,ORIGINAL_TABLE,PARENT_ACCESS_ID,TBL_PRI_COL_NAME,MODIFIED_DATE,URL_PARAMS) values (241,'/secure/markAsRead.htm','ADMIN,DIR,OFM,CFS,LCFS,AFS,AFL,AAFS','','','',sysdate,'');
  
	

-- Modify PERM_TYPE column size from 20 to 30
	ALTER TABLE CASE_PERM_TBL 
	MODIFY 
   ( 
      PERM_TYPE VARCHAR2(30 BYTE)
   );
   
	-- Message_view
	
DROP VIEW FIRST.ALL_CASE_VIEW;

/* Formatted on 13/02/2014 15:32:11 (QP5 v5.126.903.23003) */
CREATE OR REPLACE FORCE VIEW FIRST.ALL_CASE_VIEW (
   INFORMATION_ID,
   TYPE,
   CASE_ID,
   CASE_NUMBER,
   OPERATION_NAME,
   CREATED_TIME,
   CREATED_STAFF_ID,
   TEAM_CODE,
   STATE,
   SUMMARY_ADDED,
   ACCESS_FLAG,
   RESTRICT_TO,
   OVERLOADED_CASE,
   ORG_NAME,
   ORG_CODE,
   SUBJECT_NAME,
   LEAD_ASSIGNEE,
   LEAD_ASSIGNEE_FIRSTNAME,
   LEAD_ASSIGNEE_LASTNAME,
   REOPENED_TIME,
   CLOSED_TIME
)
AS
   SELECT   c.information_id,
            CASE
               WHEN i.TYPE IS NULL
               THEN
                  (SELECT   description
                     FROM   lookup_tbl lktbl
                    WHERE   i.nhs_fraud_type = lktbl.lookup_id)
               ELSE
                  i.TYPE
            END
               AS "type",
            c.case_id,
            c.case_number,
            c.operation_name,
            c.created_time,
            c.created_staff_id,
            c.team_code,
            c.state,
            c.is_summary_added,
            c.access_flag,
            c.restrict_to,
            c.is_overloaded_case,
            org.org_name,
            org.org_code,
            CASE
               WHEN nhs.subject_type = 'Primary'
               THEN
                  (SELECT   org1.org_name
                     FROM   organisations_tbl org1
                    WHERE   nhs.org_code = org1.org_code)
               WHEN non.subject_type = 'Primary'
               THEN
                  non.company_name
               WHEN subj.subject_type = 'Primary'
               THEN
                  (SELECT      DECODE (p.title, 'Other', p.other_title)
                            || ' '
                            || p.first_name
                            || ' '
                            || p.last_name
                     FROM   person_tbl p
                    WHERE   subj.subject_person_id = p.person_id)
               ELSE
                  ''
            END
               AS "SUBJECT_NAME",
            perm.VALUE,
            user1.forename1,
            user1.surname,
            c.reopened_time,
            c.closed_time
     FROM                        case_tbl c
                              LEFT JOIN
                                 organisations_tbl org
                              ON c.org_code = org.org_code
                           LEFT JOIN
                              information_tbl i
                           ON c.information_id = i.information_id
                        LEFT JOIN
                           information_subj_non_nhs_tbl non
                        ON c.information_id = non.information_id
                           AND non.subject_type = 'Primary'
                     LEFT JOIN
                        information_subject_nhs_tbl nhs
                     ON c.information_id = nhs.information_id
                        AND nhs.subject_type = 'Primary'
                  LEFT JOIN
                     information_subject_tbl subj
                  ON c.information_id = subj.information_id
                     AND subj.subject_type = 'Primary'
               LEFT JOIN
                  case_perm_tbl perm
               ON     c.case_id = perm.case_id
                  AND perm.perm_type = 'LEAD_ASSIGNEE'
                  AND perm.status = 'Y'
            LEFT JOIN
               all_users_view user1
            ON perm.VALUE = user1.staff_id;


DROP VIEW FIRST.CIVIL_APPEAL_VIEW;

/* Formatted on 13/02/2014 15:32:11 (QP5 v5.126.903.23003) */
CREATE OR REPLACE FORCE VIEW FIRST.CIVIL_APPEAL_VIEW (
   APPEAL_ID,
   SANCTION_ID,
   APPEALED_OUTCOME_ID,
   APPEALED_OUTCOME_TYPE,
   SUBJECT_ID,
   SUBJECT_TYPE,
   LEGAL_CONTACT,
   CREATED_STAFF_ID,
   CREATED_TIME,
   APPEAL_DATE,
   STATE,
   COURT_ORG_DECISION,
   DATE_OF_ORG_DECS,
   DECISION_APPEAL_AGAINST,
   APPELLANT,
   OTHERSUBJECTS,
   NHS_SUBJECT_NAME,
   NON_NHS_SUBJECT_NAME,
   PERSON_SUBJECT_NAME,
   CASE_ID,
   PARENT_APPEAL_ID,
   APPELLANT_TYPE
)
AS
   SELECT   cs.appeal_id,
            cs.sanction_id,
            cs.appealed_outcome_id,
            cs.appealed_outcome_type,
            cs.subject_id,
            cs.SUBJECT_TYPE,
            cs.legal_contact,
            cs.created_staff_id,
            cs.created_time,
            cs.appeal_date,
            cs.state,
            cs.court_org_decision,
            cs.date_of_org_decs,
            cs.decision_appeal_against,
            cs.appellant,
            cs.othersubjects,
            (SELECT   org.org_name
               FROM   organisations_tbl org, information_subject_nhs_tbl nhs
              WHERE       nhs.org_code = org.org_code
                      AND cs.subject_id = nhs.subject_nhs_id(+)
                      AND cs.SUBJECT_TYPE = 'NHS')
               NHS_SUBJECT_NAME,
            (SELECT   non.company_name
               FROM   information_subj_non_nhs_tbl non
              WHERE   cs.subject_id = non.subject_non_nhs_id(+)
                      AND cs.SUBJECT_TYPE = 'NON_NHS')
               NON_NHS_SUBJECT_NAME,
            (SELECT   p.title || ' ' || p.first_name || ' ' || p.last_name
                         AS PERSON_SUBJECT_NAME
               FROM   person_tbl p, information_subject_tbl subj
              WHERE       subj.subject_person_id = p.person_id
                      AND cs.subject_id = subj.subject_id(+)
                      AND cs.SUBJECT_TYPE = 'PERSON')
               PERSON_SUBJECT_NAME,
            cs.case_id,
            cs.parent_appeal_id,
            cs.APPELLANT_TYPE
     FROM   CIVIL_APPEAL_TBL cs;


DROP VIEW FIRST.CRIMINAL_APPEAL_VIEW;

/* Formatted on 13/02/2014 15:32:11 (QP5 v5.126.903.23003) */
CREATE OR REPLACE FORCE VIEW FIRST.CRIMINAL_APPEAL_VIEW (
   APPEAL_ID,
   CASE_ID,
   SUBJECT_ID,
   SUBJECT_TYPE,
   CREATED_STAFF_ID,
   CREATED_TIME,
   APPEARED_DATE,
   COURT_MAKING_DEC_NAME,
   STATE,
   NHS_SUBJECT_NAME,
   NON_NHS_SUBJECT_NAME,
   PERSON_SUBJECT_NAME,
   APPEAL_MAKER,
   APPELLANT_NAME,
   SANCTION_ID,
   PARENT_APPEAL_ID,
   OTHER_SUBJECT
)
AS
   SELECT   cs.appeal_id,
            cs.case_id,
            cs.subject_id,
            cs.subject_type,
            cs.created_staff_id,
            cs.created_time,
            cs.appeared_date,
            cs.court_making_dec_name,
            cs.state,
            (SELECT   org1.org_name
               FROM   organisations_tbl org1, information_subject_nhs_tbl nhs
              WHERE       nhs.org_code = org1.org_code
                      AND cs.subject_id = nhs.subject_nhs_id
                      AND cs.subject_type = 'NHS')
               AS nhs_subject,
            (SELECT   non.company_name
               FROM   information_subj_non_nhs_tbl non
              WHERE   cs.subject_id = non.subject_non_nhs_id
                      AND cs.subject_type = 'NON_NHS')
               AS non_nhs_subject,
            (SELECT   p.title || ' ' || p.first_name || ' ' || p.last_name
               FROM   person_tbl p, information_subject_tbl subj
              WHERE       subj.subject_person_id = p.person_id
                      AND cs.subject_id = subj.subject_id
                      AND cs.subject_type = 'PERSON')
               AS subject_0,
            cs.appeal_maker,
            CASE
               WHEN ISNUMBER (cs.appeal_maker) = 1
               THEN
                  (SELECT      p1.title
                            || ' '
                            || p1.first_name
                            || ' '
                            || p1.last_name
                     FROM   person_tbl p1, information_subject_tbl ist
                    WHERE   ist.subject_person_id = p1.person_id
                            AND ist.subject_id = cs.appeal_maker)
               ELSE
                  cs.appeal_maker
            END
               AS appellant_name,
            cs.sanction_id,
            cs.parent_appeal_id,
            cs.other_subject
     FROM   criminal_appeal_tbl cs;


DROP VIEW FIRST.DISCIPLINARY_APPEAL_VIEW;

/* Formatted on 13/02/2014 15:32:11 (QP5 v5.126.903.23003) */
CREATE OR REPLACE FORCE VIEW FIRST.DISCIPLINARY_APPEAL_VIEW (
   APPEAL_ID,
   CASE_ID,
   SUBJECT_ID,
   SUBJECT_TYPE,
   CREATED_STAFF_ID,
   CREATED_TIME,
   STATE,
   SANCTION_TYPE,
   ORG_NAME,
   START_DATE,
   HR_CONTACT,
   INVST_MGR_CONTACT,
   PROF_CONTACT,
   HB_CONTACT,
   NHS_SUBJECT_NAME,
   NON_NHS_SUBJECT_NAME,
   PERSON_SUBJECT_NAME,
   ORG_MAK_DEC_NAME,
   SANCTION_ID,
   OTHER_SUBJECT,
   APPEAL_MAKER,
   PARENT_APPEAL_ID,
   APPELLANT_TYPE
)
AS
   SELECT   ds.appeal_id,
            ds.case_id,
            ds.subject_id,
            ds.subject_type,
            ds.created_staff_id,
            ds.created_time,
            ds.state,
            ds.sanction_type,
            ds.org_name,
            ds.start_date,
            ds.hr_contact,
            ds.invst_mgr_contact,
            ds.prof_contact,
            ds.hb_contact,
            (SELECT   org1.org_name
               FROM   organisations_tbl org1
              WHERE   nhs.org_code = org1.org_code)
               AS nhs_subject_name,
            non.company_name AS non_nhs_subject_name,
            (SELECT   p.title || ' ' || p.first_name || ' ' || p.last_name
               FROM   person_tbl p
              WHERE   subj.subject_person_id = p.person_id)
               AS person_subject_name,
            ds.org_mak_dec_name,
            ds.sanction_id,
            ds.other_subject,
            ds.appeal_maker,
            ds.parent_appeal_id,
            ds.appellant_type
     FROM            disciplinary_appeal_tbl ds
                  LEFT JOIN
                     information_subj_non_nhs_tbl non
                  ON ds.subject_id = non.subject_non_nhs_id
                     AND ds.subject_type = 'NON_NHS'
               LEFT JOIN
                  information_subject_nhs_tbl nhs
               ON ds.subject_id = nhs.subject_nhs_id
                  AND ds.subject_type = 'NHS'
            LEFT JOIN
               information_subject_tbl subj
            ON ds.subject_id = subj.subject_id AND ds.subject_type = 'PERSON';


DROP VIEW FIRST.MESSAGE_VIEW;

/* Formatted on 13/02/2014 15:32:11 (QP5 v5.126.903.23003) */
CREATE OR REPLACE FORCE VIEW FIRST.MESSAGE_VIEW (MESSAGE_ID,
                                                 INFORMATION_ID,
                                                 FROM_STAFF_ID,
                                                 TO_STAFF_ID,
                                                 MESSAGE,
                                                 STATE,
                                                 CREATED_STAFF_ID,
                                                 CREATED_TIME,
                                                 READ_TIME,
                                                 DELETED_TIME,
                                                 FROM_STAFF_NAME,
                                                 TO_STAFF_NAME,
                                                 INFORMATION_REF,
                                                 CASE_ID,
                                                 CASE_REF,
                                                 ACCESS_FLAG,
                                                 NITS_LEAD_STATE,
                                                 NITN_LEAD_STATE,
                                                 ACTION_DETAILS,
                                                 MESSAGE_TYPE,
                                                 CASE_NUMBER,
                                                 OPERATION_NAME,
                                                 PARENT_ID,
                                                 CASE_STATE,
                                                 DELETE_FROM,
                                                 DELETE_TO,
                                                 DELETE_NITN,
                                                 DELETE_NITS,
                                                 MARK_AS_UNREAD)
AS
   SELECT   mst.MESSAGE_ID,
            mst.INFORMATION_ID,
            mst.FROM_STAFF_ID,
            mst.TO_STAFF_ID,
            mst.MESSAGE,
            mst.STATE,
            mst.CREATED_STAFF_ID,
            mst.CREATED_TIME,
            mst.READ_TIME,
            mst.DELETED_TIME,
            mst.FROM_STAFF_NAME,
            mst.TO_STAFF_NAME,
            mst.INFORMATION_REF,
            mst.CASE_ID,
            mst.CASE_REF,
            mst.ACCESS_FLAG,
            mst.NITS_LEAD_STATE,
            mst.NITN_LEAD_STATE,
            mst.ACTION_DETAILS,
            mst.MESSAGE_TYPE,
            cst.case_number,
            cst.operation_name,
            mst.PARENT_ID,
            cst.state,
            mst.DELETE_FROM,
            mst.DELETE_TO,
            mst.DELETE_NITN,
            mst.DELETE_NITS,
            mst.MARK_AS_UNREAD
     FROM      MESSAGE_TBL mst
            LEFT OUTER JOIN
               case_tbl cst
            ON mst.case_id = cst.case_id;


DROP SYNONYM EXT_FIRST.ALL_CASE_VIEW;

CREATE SYNONYM EXT_FIRST.ALL_CASE_VIEW FOR FIRST.ALL_CASE_VIEW;


DROP SYNONYM EXT_FIRST.CIVIL_APPEAL_VIEW;

CREATE SYNONYM EXT_FIRST.CIVIL_APPEAL_VIEW FOR FIRST.CIVIL_APPEAL_VIEW;


DROP SYNONYM EXT_FIRST.CRIMINAL_APPEAL_VIEW;

CREATE SYNONYM EXT_FIRST.CRIMINAL_APPEAL_VIEW FOR FIRST.CRIMINAL_APPEAL_VIEW;


DROP SYNONYM EXT_FIRST.DISCIPLINARY_APPEAL_VIEW;

CREATE SYNONYM EXT_FIRST.DISCIPLINARY_APPEAL_VIEW FOR FIRST.DISCIPLINARY_APPEAL_VIEW;


DROP SYNONYM EXT_FIRST.MESSAGE_VIEW;

CREATE SYNONYM EXT_FIRST.MESSAGE_VIEW FOR FIRST.MESSAGE_VIEW;


GRANT INSERT, SELECT, UPDATE ON FIRST.ALL_CASE_VIEW TO EXT_FIRST;

GRANT INSERT, SELECT, UPDATE ON FIRST.CIVIL_APPEAL_VIEW TO EXT_FIRST;

GRANT INSERT, SELECT, UPDATE ON FIRST.CRIMINAL_APPEAL_VIEW TO EXT_FIRST;

GRANT INSERT, SELECT, UPDATE ON FIRST.DISCIPLINARY_APPEAL_VIEW TO EXT_FIRST;

GRANT INSERT, SELECT, UPDATE ON FIRST.MESSAGE_VIEW TO EXT_FIRST;


-- Intel_info column addition
ALTER TABLE INFORMATION_TBL ADD INTEL_INFO CLOB;
ALTER TABLE INFORMATION_TBL_A ADD INTEL_INFO CLOB;

-- CPS ORDER
ALTER TABLE FIRST.CPS_ORDER_TBL
 DROP PRIMARY KEY CASCADE;

DROP TABLE FIRST.CPS_ORDER_TBL CASCADE CONSTRAINTS;

CREATE TABLE FIRST.CPS_ORDER_TBL
(
  CPS_ORDER_ID      NUMBER                      NOT NULL,
  PRIMARY_KEY       NUMBER,
  TABLE_NAME        VARCHAR2(25 BYTE),
  STATUS            VARCHAR2(25 BYTE),
  CPS_ORDER         NUMBER,
  CREATED_STAFF_ID  VARCHAR2(25 BYTE),
  CREATED_TIME      DATE,
  CASE_ID           NUMBER
)
TABLESPACE FIRST_TDE
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX FIRST.CPS_ORDER_PK ON FIRST.CPS_ORDER_TBL
(CPS_ORDER_ID)
LOGGING
TABLESPACE FIRST_TDE
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


ALTER TABLE FIRST.CPS_ORDER_TBL ADD (
  CONSTRAINT CPS_ORDER_PK
 PRIMARY KEY
 (CPS_ORDER_ID)
    USING INDEX 
    TABLESPACE FIRST_TDE
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

DROP TABLE FIRST.CPS_ORDER_TBL_A CASCADE CONSTRAINTS;

CREATE TABLE FIRST.CPS_ORDER_TBL_A
(
  CPS_ORDER_ID      NUMBER                      NOT NULL,
  REV               NUMBER(10)                  NOT NULL,
  REVTYPE           NUMBER(3),
  PRIMARY_KEY       NUMBER,
  TABLE_NAME        VARCHAR2(25 BYTE),
  STATUS            VARCHAR2(25 BYTE),
  CPS_ORDER         NUMBER,
  CREATED_STAFF_ID  VARCHAR2(25 BYTE),
  CREATED_TIME      DATE,
  CASE_ID           NUMBER
)
TABLESPACE FIRST_TDE
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

DROP SEQUENCE FIRST.CPS_ORDER_ID_SEQ;
CREATE SEQUENCE FIRST.CPS_ORDER_ID_SEQ
  START WITH 1
  MAXVALUE 99999
  MINVALUE 1
  NOCYCLE
  NOCACHE
  NOORDER;

	commit;
	
CREATE OR REPLACE function FIRST.isnumber( p_string in varchar2 ) return number
   is
     l_number number;
   begin
      l_number := p_string;
      return 1;
   exception
      when others then return 0;
   end;
/	