package uk.nhs.cfsms.ecms.scheduler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import uk.nhs.cfsms.ecms.service.InformationGatherService;

public class InformationSchedulingTask {

	//@Autowired
	InformationGatherService informationGatherFacade;

	protected final Log log = LogFactory.getLog(getClass());

	/**
	 * Delete closed information reports more than 3 years old
	 * 
	 * Run 09:00 every day.
	 */
	//@Scheduled(cron="0 00 09 * * ?")
	/*public void executeTasks() {
		log.info("InformationSchedulingTask executeTasks() at "
				+ new Date().toString());
		informationGatherFacade.deleteThreeYearsOldClosedInformation();
	}

	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}*/
}
