package uk.nhs.cfsms.ecms.scheduler;

import java.util.Date;
import java.util.List;
import java.util.ListIterator;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.model.CaseActionBookTO;
import uk.nhs.cfsms.ecms.service.CaseActionBookService;
import uk.nhs.cfsms.ecms.service.MessageService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

public class CaseActionBookSchedulingTask {

	@Autowired
	private MessageService messageFacade;
	@Autowired
	private CaseActionBookService caseActionBookFacade;

	protected final Log log = LogFactory.getLog(getClass());

	private final int DUE_BY_ONE_DAY = 1;
	private final int DUE_BY_SEVEN_DAYS = 7;

	public static final String ADMIN_USER = "ops9999";

	/**
	 * Fetch the list of objects which are in due state of execution with in the
	 * number of days passed as integer argument.
	 * 
	 * original @Scheduled(fixedRate=86400000, fixedDelay=900000)
	 * 
	 * Run 6:00 every day.
	 */

	//@Scheduled(cron = "0 0/2 * * * ?")
	@Scheduled(cron = "0 00 6 * * ?")
	public void executeTasks() {

		Long startTime = System.currentTimeMillis();

		if (log.isDebugEnabled()) {
			log.debug("Case Action Book Scheduler, Started (mills)="
					+ startTime);
		}
		try {
			List<CaseActionBookTO> oneDayDuelist = caseActionBookFacade
					.loadDueCaseActionBook(DUE_BY_ONE_DAY);
			List<CaseActionBookTO> sevenDaysDuelist = caseActionBookFacade
					.loadDueCaseActionBook(DUE_BY_SEVEN_DAYS);

			ListIterator<CaseActionBookTO> oneDayDuelistIterator = oneDayDuelist
					.listIterator();
			ListIterator<CaseActionBookTO> sevenDaysDuelistIterator = sevenDaysDuelist
					.listIterator();

			while (sevenDaysDuelistIterator.hasNext()) {
				log.debug("Case Action Book List index = "
						+ sevenDaysDuelistIterator.nextIndex());
				this.triggerMessageSystem(sevenDaysDuelistIterator.next(), 7);
			}

			while (oneDayDuelistIterator.hasNext()) {
				log.debug("Case Action Book List index = "
						+ oneDayDuelistIterator.nextIndex());
				this.triggerMessageSystem(oneDayDuelistIterator.next(), 1);
			}

		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}
		if (log.isDebugEnabled()) {
			log.debug("Case Action Book Scheduler, Completed in (millis)= "
					+ (System.currentTimeMillis() - startTime));
		}
	}

	/**
	 * This method is responsible for triggering the ALERT messages. If some
	 * ACTION is due as ON Date
	 * 
	 * @throws Exception
	 */
	private void triggerMessageSystem(CaseActionBookTO cActionBook, int days)
			throws Exception {

		String message = null;

		if (days == 1) {
			message = "ALERT Message : Only 1 day left to complete action for action book number : "
					+ cActionBook.getActionNumber();
		}
		if (days == 7) {
			message = "ALERT Message : Only 1 week left to complete action for action book number : "
					+ cActionBook.getActionNumber();
		}

		// MessageTO messageTO[] = new MessageTO[2];

		// for (int i = 0; i < 2; i++) {

		// messageTO[i] = new MessageTO();
		//
		// messageTO[i].setMessage(message);
		// messageTO[i].setCaseId(cActionBook.getCaseID());
		// messageTO[i].setCaseRef(cActionBook.getCaseActionBookId().toString());
		// messageTO[i]
		// .setMessageType(MessageTO.Message_types.CASE_ACTION_ALERT
		// .toString());
		// messageTO[i].setCreatedTime(new Date());
		// messageTO[i].setState(ECMSConstants.MESSAGE_STATE_NEW);
		// messageTO[i].setActionDetails("Action Due Date :"
		// + EcmsUtils.getDateToddMMyyyy(cActionBook.getDueDate()));
		// messageTO[i].setCreatedStaffId(ADMIN_USER);
		// messageTO[i].setFromStaffId(ADMIN_USER);
		// messageTO[i].setFromStaffName("AUTO GENERATED");
		// }

		MessageTO messageTO = new MessageTO();

		messageTO.setMessage(message);
		messageTO.setCaseId(cActionBook.getCaseID());
		messageTO.setCaseRef(cActionBook.getCaseActionBookId().toString());
		messageTO.setMessageType("Case Action Alert");
		messageTO.setActionTitle(cActionBook.getSourceReference());
		messageTO.setCreatedTime(new Date());
		messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
		messageTO.setActionDetails("Action Due Date :"
				+ EcmsUtils.getDateToddMMyyyy(cActionBook.getDueDate()));
		messageTO.setCreatedStaffId(ADMIN_USER);
		messageTO.setFromStaffId(ADMIN_USER);
		messageTO.setFromStaffName("SYSTEM GENERATED");
		messageTO.setToStaffId(cActionBook.getAllocatedTo());
		messageTO.setToStaffName(this.caseActionBookFacade
				.getUserFullName(cActionBook.getAllocatedTo()));
		AuditFlowThread.set("Auto Message Created");
		messageFacade.saveMessage(messageTO);

		// messageTO[0].setToStaffId(cActionBook.getAllocatedBy());
		// messageTO[0].setToStaffName(this.caseActionBookFacade
		// .getUserFullName(cActionBook.getAllocatedBy()));
		// AuditFlowThread.set("Auto Message Created");
		// messageFacade.saveMessage(messageTO[0]);

		// messageTO[1].setToStaffId(cActionBook.getAllocatedTo());
		// messageTO[1].setToStaffName(this.caseActionBookFacade
		// .getUserFullName(cActionBook.getAllocatedTo()));
		// AuditFlowThread.set("Auto Message Created");
		// messageFacade.saveMessage(messageTO[1]);

		
		if (log.isDebugEnabled()) {
			log.debug("\n ***" + message + "***");
		}
	}

	/**
	 * Setter method for injecting the message Service.
	 * 
	 * @param messageFacade
	 * 
	 */
	public void setmessageFacade(MessageService messageFacade) {
		this.messageFacade = messageFacade;
	}

	/**
	 * Injecting the Case Action Book Facade.
	 * 
	 * @param caseActionBookService
	 * 
	 */
	public void setCaseActionBookFacade(
			CaseActionBookService caseActionBookFacade) {
		this.caseActionBookFacade = caseActionBookFacade;
	}
}
