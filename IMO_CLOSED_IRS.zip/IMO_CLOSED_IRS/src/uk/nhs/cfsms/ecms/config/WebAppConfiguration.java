package uk.nhs.cfsms.ecms.config;

import java.beans.PropertyEditor;
import java.text.SimpleDateFormat;
import java.util.Properties;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.view.ResourceBundleViewResolver;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.exceptions.ExceptionLoggingIntercepter;
import uk.nhs.cfsms.ecms.scheduler.CaseActionBookSchedulingTask;
import uk.nhs.cfsms.ecms.scheduler.InformationSchedulingTask;
import uk.nhs.cfsms.ecms.web.security.IWebAuthorizer;
import uk.nhs.cfsms.ecms.web.security.WebAuthorizer;
import uk.nhs.cfsms.ecms.web.security.WebSecurityInterceptor;
import uk.nhs.cfsms.ecms.web.support.BreadCrumbsInterceptor;
import uk.nhs.cfsms.ecms.web.support.CaseAndInformationInterceptor;
import uk.nhs.cfsms.ecms.web.support.CustomMappingExceptionResolver;
import uk.nhs.cfsms.ecms.web.support.SessionCleanupInterceptor;

@Configuration
@EnableWebMvc
@EnableScheduling
@EnableTransactionManagement
@ComponentScan(basePackages = { "uk.nhs.cfsms.ecms.controller",
		"uk.nhs.cfsms.ecms.serviceimpl", "uk.nhs.cfsms.ecms.dao.hibernate",
		"uk.nhs.cfsms.ecms.scheduler" })
@ImportResource({ "/WEB-INF/dispatcher-servlet.xml",
		"/WEB-INF/security-context.xml", "/WEB-INF/ehcache-config-bean.xml" })
@PropertySource({"classpath:addressLookUp.properties","classpath:messages.properties"})
public class WebAppConfiguration extends WebMvcConfigurerAdapter implements
		BeanFactoryAware {

	private BeanFactory beanFactory;

	@Bean(name = "messageSource")
	public MessageSource getMessageSource() {
		ReloadableResourceBundleMessageSource source = new ReloadableResourceBundleMessageSource();
		source.setBasename("messages");
		source.setCacheSeconds(9);
		return source;
	}

	@Bean(name = "localeResolver")
	public LocaleResolver getLocaleResolver() {
		SessionLocaleResolver resolver = new SessionLocaleResolver();
		return resolver;
	}

	@Bean(name = "exceptionResolver")
	public HandlerExceptionResolver getExceptionResolver() {
		CustomMappingExceptionResolver resolver = new CustomMappingExceptionResolver();
		return resolver;
	}

	@Bean(name = "viewResolver")
	public ViewResolver getViewResolver() {
		ResourceBundleViewResolver resolver = new ResourceBundleViewResolver();
		resolver.setDefaultParentView("index");
		return resolver;
	}

	@Bean(name = "customDateEditor")
	public PropertyEditor getCustomDateEditor() {
		CustomDateEditor dateEditor = new CustomDateEditor(
				new SimpleDateFormat("dd/MM/yyyy"), true);
		return dateEditor;
	}

	@Bean(name = "multipartResolver")
	public MultipartResolver getMultiPartResolver() {
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
		//		multipartResolver.setMaxUploadSize(5242880);
		multipartResolver.setMaxUploadSize(10485760);
		/**
		 * setMaxInMemorySize need to set to match MaxUpLoadSize, otherwise
		 * Exception
		 * "illegalstateexception file has been moved - cannot be read again"
		 * will be thrown, if the object which stores Multipart file to session
		 * and reading multiple times (Eg, MGFormTO)
		 */
		multipartResolver.setMaxInMemorySize(5242880);
		return multipartResolver;
	}

	@Bean(name = "webAuthorizer")
	public IWebAuthorizer getWebAuthorizer() {
		WebAuthorizer authorizer = new WebAuthorizer();
		return authorizer;
	}

	@Bean(name = "webSecurityInterceptor")
	public WebSecurityInterceptor getWebSecurityInterceptor() {
		WebSecurityInterceptor interceptor = new WebSecurityInterceptor();
		interceptor.setWebAuthorizer(getWebAuthorizer());
		// interceptor.setInterceptFacade(interceptFacade)
		return interceptor;
	}

	@Bean(name = "sessionCleanupInterceptor")
	public SessionCleanupInterceptor getSessionCleanupInterceptor() {
		SessionCleanupInterceptor interceptor = new SessionCleanupInterceptor();
		return interceptor;
	}

	@Bean(name = "breadCrumbsInterceptor")
	public BreadCrumbsInterceptor getBreadCrumbsInterceptor() {
		BreadCrumbsInterceptor interceptor = new BreadCrumbsInterceptor();
		return interceptor;
	}

	@Bean(name = "caseAndInformationInterceptor")
	public CaseAndInformationInterceptor getCaseAndInformationInterceptor() {
		CaseAndInformationInterceptor interceptor = new CaseAndInformationInterceptor();
		return interceptor;
	}

	@Bean(name = "exceptionInterceptor")
	public ExceptionLoggingIntercepter getExceptionInterceptor() {

		ExceptionLoggingIntercepter interceptor = new ExceptionLoggingIntercepter();
		return interceptor;
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(getCaseAndInformationInterceptor());
		registry.addInterceptor(getSessionCleanupInterceptor())
				.addPathPatterns("/secure/*");
		registry.addInterceptor(getWebSecurityInterceptor()).addPathPatterns(
				"/*");
		registry.addInterceptor(getBreadCrumbsInterceptor()).addPathPatterns(
				"/secure/*");
	}

	@Bean(name = "caseActionBookScheduler")
	public CaseActionBookSchedulingTask getCaseActionBookSchedulingTask() {

		return new CaseActionBookSchedulingTask();
	}

	/**
	 * This spring framework schedule job has been disabled as DBA (Jamie Pearson) has 
	 * implemented a procedure to delete 3 years old Information Reports and 
	 * scheduled stored procedure to run every day midnight.
	 */
	/*@Bean(name = "informationScheduler")
	public InformationSchedulingTask getInformationSchedulingTask() {

		return new InformationSchedulingTask();
	}*/

	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {

		this.beanFactory = beanFactory;
	}

	@Bean
	public SimpleMappingExceptionResolver getSimpleMappingExceptionResolver() {
		SimpleMappingExceptionResolver exceptionResolver = new SimpleMappingExceptionResolver();
		exceptionResolver.setExceptionMappings(execptionMapping());
		return exceptionResolver;
	}

	Properties execptionMapping() {
		return new Properties() {
			private static final long serialVersionUID = 1L;

			{
				// setProperty("java.lang.Exception", "mail_error");
			}
		};
	}

	@Bean
	public JavaMailSenderImpl getJavaMailSenderImpl() {
		JavaMailSenderImpl javaMailSenderImpl = new JavaMailSenderImpl();
		javaMailSenderImpl.setHost(ECMSConstants.SMTP_HOST_STRING);
		javaMailSenderImpl.setJavaMailProperties(javaMailProperties());
		return javaMailSenderImpl;
	}

	@Bean
	public RestTemplate getRestTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		return restTemplate;
	}

	Properties javaMailProperties() {
		return new Properties() {
			private static final long serialVersionUID = 1L;
			{
				setProperty("mail.transport.protocol", "smtp");
				setProperty("mail.debug", "false");
			}
		};
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		PropertySourcesPlaceholderConfigurer pspc = new PropertySourcesPlaceholderConfigurer();
		return pspc;
	}
}
