package uk.nhs.cfsms.ecms.config;

import java.beans.PropertyVetoException;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.envers.EntityTrackingRevisionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import uk.nhs.cfsms.ecms.audit.FirstCustomRevisionListener;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
@EnableTransactionManagement
@PropertySource("classpath:/database.properties")
public class PersistenceJPAConfig {

	@Autowired
	private Environment env;

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean()
			throws SQLException, PropertyVetoException {

		LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();

		factoryBean.setPersistenceUnitName("cfsms");
		factoryBean
				.setPersistenceProviderClass(org.hibernate.ejb.HibernatePersistence.class);
		factoryBean.setDataSource(this.getEcmsDataSource());
		factoryBean.setPackagesToScan(new String[] { "uk.nhs.cfsms.ecms.data",
				"uk.nhs.cfsms.ecms.audit" });
		factoryBean.setJpaVendorAdapter(jpaVendorAdapter());
		factoryBean.setJpaProperties(additionalProperties());
		return factoryBean;
	}

	Properties additionalProperties() {
		return new Properties() {
			private static final long serialVersionUID = 1L;

			{
				/** HIBERNATE Specific: */
				setProperty("hibernate.dialect",
						"org.hibernate.dialect.Oracle10gDialect");
				setProperty("hibernate.format_sql", "true");
				setProperty("org.hibernate.envers.audit_table_suffix", "_A");
				setProperty("hibernate.cglib.use_reflection_optimizer", "false");
				setProperty("hibernate.show_sql", "true");
				setProperty("format_sql","true");
				setProperty("hibernate.jdbc.use_streams_for_binary", "true");
				setProperty("hibernate.cache.region.factory_class",
						"org.hibernate.cache.ehcache.SingletonEhCacheRegionFactory");
				setProperty("hibernate.cache.use_second_level_cache", "true");
				setProperty("hibernate.generate_statistics", "true");
				System.setProperty("net.sf.ehcache.skipUpdateCheck", "true");
//				System.setProperty("com.mchange.v2.log.MLog", "com.mchange.v2.log.FallbackMLog");
				//System.setProperty("com.mchange.v2.log.FallbackMLog.DEFAULT_CUTOFF_LEVEL", "SEVERE");
			}
		};
	}

	@Bean
	public JpaVendorAdapter jpaVendorAdapter() {

		HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
		hibernateJpaVendorAdapter.setShowSql(false);
		hibernateJpaVendorAdapter.setGenerateDdl(false);
		hibernateJpaVendorAdapter.setDatabase(Database.ORACLE);
		return hibernateJpaVendorAdapter;
	}

	/*@Bean(name="ecmsDataSource")
	public DataSource getEcmsDataSource(){

		DriverManagerDataSource datasource = new DriverManagerDataSource();
		datasource.setDriverClassName(env.getProperty("datasource.driver"));
		datasource.setUrl(env.getProperty("datasource.url"));
		datasource.setUsername(env.getProperty("datasource.username"));
		datasource.setPassword(env.getProperty("datasource.password"));
		return datasource;
	}*/

	// Hikari connection pool data source

	/*@Bean(name = "ecmsDataSource")
	public DataSource getEcmsDataSource() throws SQLException {

		final String driver = env.getProperty("datasource.driver");
		final String jdbcUrl = env.getProperty("datasource.url");
		final String userName = env.getProperty("datasource.username");
		final String password = env.getProperty("datasource.password");

		HikariDataSource ds = new HikariDataSource();

		ds.setDataSourceClassName(driver);
		ds.addDataSourceProperty("url", jdbcUrl);
		ds.addDataSourceProperty("user", userName);
		ds.addDataSourceProperty("password", password);

		ds.setMaximumPoolSize(100);
//		ds.setLeakDetectionThreshold(10000);

		return ds;
	}*/

	// C3p0 connection pool configuration

	@Bean(name = "ecmsDataSource")
	public DataSource getEcmsDataSource() throws SQLException,
			PropertyVetoException {

		final String driver = env.getProperty("datasource.driver");
		final String jdbcUrl = env.getProperty("datasource.url");
		final String userName = env.getProperty("datasource.username");
		final String password = env.getProperty("datasource.password");

		ComboPooledDataSource cpds = new ComboPooledDataSource();
		cpds.setDriverClass(driver);
		cpds.setJdbcUrl(jdbcUrl);
		cpds.setUser(userName);
		cpds.setPassword(password);

		cpds.setInitialPoolSize(10);
		cpds.setMinPoolSize(10);
		cpds.setMaxPoolSize(100);
		cpds.setAcquireIncrement(5);

		/**
	 * Configuring Connection Testing
	 */
	

	cpds.setTestConnectionOnCheckout(true); // Simple and robust solution,but can make performance slow
	//cpds.setIdleConnectionTestPeriod(30); // complex, can experience broken or stale connections, if see this issue then go for above setting http://www.mchange.com/projects/c3p0/#configuring_connection_testing
	//cpds.setTestConnectionOnCheckin(true); // complex, can experience broken or stale connections, if see this issue then go for above setting http://www.mchange.com/projects/c3p0/#configuring_connection_testing
	cpds.setMaxIdleTimeExcessConnections(240);
	//cpds.setAutomaticTestTable("FIRST_DB");

	/**
	 * Configuring Recovery From Database Outages
	 * 
	 */
	

	cpds.setAcquireRetryAttempts(0);
	cpds.setAcquireRetryDelay(3000);
	cpds.setBreakAfterAcquireFailure(false);

	return cpds;

	}

	@Bean
	public PlatformTransactionManager transactionManager() throws SQLException, PropertyVetoException {
		JpaTransactionManager transactionManager = new JpaTransactionManager(
				this.entityManagerFactoryBean().getObject());
		return transactionManager;
	}

	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {

		return new PersistenceExceptionTranslationPostProcessor();
	}

	@Bean
	public EntityTrackingRevisionListener getRevisionListener()
			throws Exception {
		FirstCustomRevisionListener listener = new FirstCustomRevisionListener();
		listener.setEntityManager(entityManagerFactoryBean().getObject()
				.createEntityManager());
		return listener;
	}
}
