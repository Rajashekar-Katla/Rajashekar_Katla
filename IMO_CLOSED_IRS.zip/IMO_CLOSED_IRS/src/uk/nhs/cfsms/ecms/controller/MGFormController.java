package uk.nhs.cfsms.ecms.controller;

import static java.util.regex.Pattern.compile;
import static uk.nhs.cfsms.ecms.ECMSConstants.DOC_EXT;
import static uk.nhs.cfsms.ecms.ECMSConstants.MGFORM_TYPE;
import static uk.nhs.cfsms.ecms.ECMSConstants.OTHER;
import static uk.nhs.cfsms.ecms.ECMSConstants.TEXT;
import static uk.nhs.cfsms.ecms.ECMSConstants.TXT_EXT;
import static uk.nhs.cfsms.ecms.ECMSConstants.WORD_DOC;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.dto.mgforms.MGFormTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.CPSDocumentService;
import uk.nhs.cfsms.ecms.service.MGFormService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileExtensions;
import uk.nhs.cfsms.ecms.utility.FileUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
public class MGFormController extends BaseBinder {

	private static final Map<String, byte[]> FILE_BYTES_MAP = new HashMap<String, byte[]>();

	@Autowired
	MGFormService mgFormFacade;

	@Autowired
	private CPSDocumentService cpsDocumentsService;

	protected final Log logger = LogFactory.getLog(getClass());

	@RequestMapping(value = "/secure/validateMGFormFilename.htm")
	public ModelAndView validateFileName(MultipartHttpServletRequest request,
			HttpServletResponse response) throws IOException, ServiceException,
			CaseIDNotFoundException {

		final HttpSession httpSession = request.getSession();
		final ObjectMapper mapper = new ObjectMapper();
		final String caseID = CaseUtil.getCaseId(request);
		final Iterator<String> itr = request.getFileNames();
		final MultipartFile mpf = request.getFile(itr.next());
		final String formType = request.getParameter("formType");
		final String fullFileName = mpf.getOriginalFilename();
		final byte[] fileBytes = mpf.getBytes();

		final int id = new RandomNumberGenerator(1000).generateNewRandom(10);
		final String key = id + "-" + formType;
		FILE_BYTES_MAP.put(key, fileBytes);
		httpSession.setAttribute("fileBytesMap", FILE_BYTES_MAP);

		String documentNamingRule = null;

		List<InvalidFileNames> inValidNames = new ArrayList<InvalidFileNames>();

		inValidNames = validateAndSave((HttpServletRequest) request,
				httpSession, caseID, formType, fullFileName, fileBytes,
				documentNamingRule, inValidNames, id);
		final String invalidFiles = getFilesInJsonFormat(mapper, inValidNames);
		FileCopyUtils.copy(invalidFiles, response.getWriter());
		return null;
	}

	@RequestMapping(value = "/secure/updateAndSaveMGForms.htm")
	public ModelAndView updateAndSaveMGForms(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServiceException,
			CaseIDNotFoundException {
		final HttpSession httpSession = request.getSession();
		final ObjectMapper mapper = new ObjectMapper();
		final String caseID = CaseUtil.getCaseId(request);
		final String invalidFileNames = request
				.getParameter("invalidFileNames");

		final String[] fileNames = invalidFileNames.split(",");
		String documentNamingRule = null;
		List<InvalidFileNames> inValidNames = new ArrayList<InvalidFileNames>();

		@SuppressWarnings("unchecked")
		final Map<String, byte[]> fileBytesMap = (HashMap<String, byte[]>) httpSession
				.getAttribute("fileBytesMap");

		for (String fileName : fileNames) {
			final String[] eachFileNames = fileName.split("<>");
			final String id = eachFileNames[0];
			final String formType = eachFileNames[1];
			final String fullFileName = eachFileNames[2];

			final String key = id + "-" + formType;
			final byte[] fileBytes = fileBytesMap.get(key);

			inValidNames = validateAndSave(request, httpSession, caseID,
					formType, fullFileName, fileBytes, documentNamingRule,
					inValidNames, Integer.parseInt(id));
		}

		final String invalidFiles = getFilesInJsonFormat(mapper, inValidNames);
		FileCopyUtils.copy(invalidFiles, response.getWriter());
		return null;
	}

	/**
	 * @param request
	 * @param httpSession
	 * @param caseID
	 * @param formType
	 * @param fullFileName
	 * @param fileBytes
	 * @param documentNamingRule
	 * @param inValidNames
	 * @return
	 * @throws ServiceException
	 */
	private List<InvalidFileNames> validateAndSave(HttpServletRequest request,
			final HttpSession httpSession, final String caseID,
			final String formType, final String fullFileName,
			final byte[] fileBytes, String documentNamingRule,
			List<InvalidFileNames> inValidNames, int id)
			throws ServiceException {

		@SuppressWarnings("unchecked")
		Map<String, String> fileNamingRulesMap = (Map<String, String>) httpSession
				.getAttribute("fileNamingRulesMap");

		if (fileNamingRulesMap == null) {
			fileNamingRulesMap = this.cpsDocumentsService
					.getCPSDocumentsNamingRules();
			httpSession.setAttribute("fileNamingRulesMap", fileNamingRulesMap);
		}
		final String key = id + "-" + formType;

		documentNamingRule = getFileNamingRule(documentNamingRule, formType,
				fileNamingRulesMap);

		String fileName = null;
		if (!documentNamingRule.isEmpty()) {
			final Pattern pattern = compile(documentNamingRule);
			final String fileNameWithExt = fullFileName;

			final String extension = FilenameUtils
					.getExtension(fileNameWithExt);

			if (FileExtensions.isValidExtension(extension.toLowerCase())) {
				fileName = fileNameWithExt.substring(0,
						fileNameWithExt.indexOf("." + extension));
			} else {
				fileName = fileNameWithExt;
			}
			final Matcher matcher = pattern.matcher(fileName.trim());

			if (!matcher.matches()) {
				inValidNames = populateInvalidFileNames(formType, fullFileName,
						inValidNames, id);
			} else {
				saveMGForm(request, fullFileName, formType, fileBytes, caseID,
						key);
			}
		} else {
			saveMGForm(request, fullFileName, formType, fileBytes, caseID, key);
		}
		return inValidNames;
	}

	/**
	 * @param formType
	 * @param fullFileName
	 * @param fileBytes
	 * @param inValidNames
	 * @param id
	 */
	private List<InvalidFileNames> populateInvalidFileNames(
			final String formType, final String fullFileName,
			final List<InvalidFileNames> inValidNames, int id) {
		final InvalidFileNames invalidFileNames = new InvalidFileNames();
		invalidFileNames.setSelectId(id);
		invalidFileNames.setFullFileName(fullFileName);
		invalidFileNames.setFormType(formType);
		inValidNames.add(invalidFileNames);

		return inValidNames;
	}

	/**
	 * @param request
	 * @param fullFileName
	 * @param mgFormObject
	 * @throws ServiceException
	 */
	private void saveMGForm(HttpServletRequest request,
			final String fullFileName, final String formType,
			final byte[] fileBytes, final String caseID, final String key)
			throws ServiceException {

		final MGFormTO mgFormObject = new MGFormTO();
		final SessionUser user = EcmsUtils.getSessionUserObject(request
				.getSession());
		String fileType = FileUtils.getExtension(fullFileName);

		mgFormObject.setMgFormType(formType);
		mgFormObject.setFileName(fullFileName);
		mgFormObject.setFileType(fileType != null ? fileType.toUpperCase()
				: OTHER);
		mgFormObject.setCreatedStaffId(user.getStaffId());
		mgFormObject.setCreatedTime(new Date());
		mgFormObject.setCaseId(Long.parseLong(caseID));
		mgFormObject.setMgForm(fileBytes);
		if (mgFormObject.getFileType() != null) {
			mgFormObject.setFileType(mgFormObject.getFileType()
					.equalsIgnoreCase(DOC_EXT) ? WORD_DOC : mgFormObject
					.getFileType().equalsIgnoreCase(TXT_EXT) ? TEXT
					: mgFormObject.getFileType());
		}
		if (mgFormObject.getMgFormId() == null
				|| mgFormObject.getMgFormId() == 0L) {

			AuditFlowThread.set("MG Form Uploaded");
		}
		mgFormFacade.saveMGForm(mgFormObject);
		FILE_BYTES_MAP.remove(key);
	}

	@RequestMapping(value = "/secure/mgform.htm", method = RequestMethod.GET)
	protected String initForm(ModelMap model, HttpServletRequest request)
			throws Exception {
		final List<LookupView> lookupViews = new ArrayList<LookupView>();
		final LookupView lookupView = new LookupView();
		final MGFormTO form = new MGFormTO();
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		form.setCaseId(new Long(caseID));
		try {
			lookupView.setDescription("-- Choose one --");
			lookupViews.add(lookupView);
			lookupViews.addAll(mgFormFacade.loadMGFormTypes(MGFORM_TYPE));
			Collections.sort(lookupViews, new AlphanumericSorting());
			form.setMgFormTypeList(lookupViews);
		} catch (Exception e) {
			throw new ServletException(e);
		}
		model.addAttribute("mgFormObject", form);

		return "mgform";
	}

	/**
	 * This method is responsible to get file naming rule for given document
	 * category.
	 * 
	 * @param String
	 *            documentCategory
	 * @param String
	 *            documentNamingRule
	 * @param String
	 *            formType
	 * @param Map
	 *            <String, String> fileNamingRulesMap
	 * 
	 * @return String
	 */

	private String getFileNamingRule(String documentNamingRule,
			final String formType, final Map<String, String> fileNamingRulesMap) {

		documentNamingRule = fileNamingRulesMap.get(formType);
		documentNamingRule = documentNamingRule != null ? documentNamingRule
				.trim() : "";
		return documentNamingRule;
	}

	public void setMgFormFacade(MGFormService mgFormFacade) {

		this.mgFormFacade = mgFormFacade;
	}

	private static class RandomNumberGenerator {
		ArrayList<Integer> numbersList = new ArrayList<Integer>();

		public RandomNumberGenerator(int length) {
			for (int x = 1; x <= length; x++)
				numbersList.add(x);
			Collections.shuffle(numbersList);
		}

		public int generateNewRandom(int n) {
			return numbersList.get(n);
		}
	}

	private String getFilesInJsonFormat(final ObjectMapper mapper,
			final List<InvalidFileNames> invalidFilesList) {
		String invalidFiles = null;
		try {
			invalidFiles = mapper.writeValueAsString(invalidFilesList);
		} catch (JsonGenerationException e) {
			logger.error("Got JsonGenerationException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (JsonMappingException e) {
			logger.error("Got JsonMappingException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {
			logger.error("Got IOException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		}
		return invalidFiles;
	}

	private static class InvalidFileNames {
		private int selectId;
		private String formType;
		// private byte[] filebytes;
		private String fullFileName;

		public int getSelectId() {
			return selectId;
		}

		public void setSelectId(int selectId) {
			this.selectId = selectId;
		}

		public String getFormType() {
			return formType;
		}

		public void setFormType(String formType) {
			this.formType = formType;
		}

		/*
		 * public byte[] getFilebytes() { return filebytes; }
		 * 
		 * public void setFilebytes(byte[] filebytes) { this.filebytes =
		 * filebytes; }
		 */

		public String getFullFileName() {
			return fullFileName;
		}

		public void setFullFileName(String fullFileName) {
			this.fullFileName = fullFileName;
		}

	}

	private class AlphanumericSorting implements Comparator<LookupView> {
		/**
		 * The compare method that compares the alphanumeric strings
		 */
		public int compare(LookupView firstObjToCompare,
				LookupView secondObjToCompare) {
			String firstString = removePadding(firstObjToCompare
					.getDescription());
			String secondString = removePadding(secondObjToCompare
					.getDescription());

			if (secondString == null || firstString == null) {
				return 0;
			}

			int lengthFirstStr = firstString.length();
			int lengthSecondStr = secondString.length();

			int index1 = 0;
			int index2 = 0;

			while (index1 < lengthFirstStr && index2 < lengthSecondStr) {
				char ch1 = firstString.charAt(index1);
				char ch2 = secondString.charAt(index2);

				char[] space1 = new char[lengthFirstStr];
				char[] space2 = new char[lengthSecondStr];

				int loc1 = 0;
				int loc2 = 0;

				do {
					space1[loc1++] = ch1;
					index1++;

					if (index1 < lengthFirstStr) {
						ch1 = firstString.charAt(index1);
					} else {
						break;
					}
				} while (Character.isDigit(ch1) == Character.isDigit(space1[0]));

				do {
					space2[loc2++] = ch2;
					index2++;

					if (index2 < lengthSecondStr) {
						ch2 = secondString.charAt(index2);
					} else {
						break;
					}
				} while (Character.isDigit(ch2) == Character.isDigit(space2[0]));

				String str1 = new String(space1);
				String str2 = new String(space2);

				int result;

				if (Character.isDigit(space1[0])
						&& Character.isDigit(space2[0])) {
					Integer firstNumberToCompare = new Integer(
							Integer.parseInt(str1.trim()));
					Integer secondNumberToCompare = new Integer(
							Integer.parseInt(str2.trim()));
					result = firstNumberToCompare
							.compareTo(secondNumberToCompare);
				} else {
					result = str1.compareTo(str2);
				}

				if (result != 0) {
					return result;
				}
			}
			return lengthFirstStr - lengthSecondStr;
		}

		private String removePadding(String string) {
			String result = "";
			try {
				result += Integer.parseInt(string.trim());
			} catch (Exception e) {
				result = string;
			}
			return result;
		}
	}
}
