package uk.nhs.cfsms.ecms.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;


/**
 * @author Jshrivastav
 * 
 * This controller is responsible for information transfers.
 * 
 **/
@Controller 
public class InformationTransferController extends BaseBinderConfig {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6249452098254140900L;

	@Autowired
	private AuditLogService auditLogFacade;
	
	@Autowired
	private CaseService caseFacade;
	
	final static String REDIRECTION_URL = "listInformation.htm?fromMenu=info&infoType=open&dispatch=query";

	Logger logger = Logger.getLogger(InformationTransferController.class);

	/**
	 * Approving/rejecting the information transfer requests initiated be LCFS users to members of other team. 
	 * 
	 * @param request
	 * @param response
	 * 
	 * @return ModelAndView	
	 */
	@RequestMapping(value="/secure/informationTransferApproval.htm")
	public ModelAndView informationTransferApproval(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String auditAction = "";
		Long infoId = null;
		
		String infoID = request.getParameter("iid");
		String transferStatus = request.getParameter("ts");

		if (StringUtils.isEmpty(infoID) || StringUtils.isEmpty(transferStatus)) {
			
			String errorMessage = "Empty InformationId or transferStatus params !";
			logger.error(errorMessage);
			throw new ServletException(errorMessage);
		}
		try { 
	 		
			infoId = new Long(infoID);
						
			if (StringUtils.equalsIgnoreCase(transferStatus, "approve")){
				
				Long infoTransHistory = caseFacade.updateInformationTransfer(infoId,"approvalAccepted","Information reviewed and Approved.");
				
				if (null == infoTransHistory) {
					
					auditAction = log("Information transfer updation failed, transferID is NULL");
				}
					
				if (caseFacade.triggerTransferNotification(infoTransHistory)) {
					
					if (caseFacade.prepareInformationTransferResponses("approvalAccepted",infoTransHistory)) {
						
						auditAction = log("Information transfer approval success");
					}
					else {
						auditAction = log("Information transfer reply failed, transferID:"+infoTransHistory);
					}
				} else {
					
					auditAction = log("Information transfer notification failed, transferID:"+infoTransHistory) ;
				}
			
			}
			else if (StringUtils.equalsIgnoreCase(transferStatus, "reject")) {
				
				Long transferId = caseFacade.updateInformationTransfer(infoId,"approvalRejected","Information Rejected");
				
				if (transferId == null) {
					
					auditAction = log("Information transfer reply failed, transferID is NULL");				
				}
				
				if (caseFacade.prepareInformationTransferResponses("approvalRejected", transferId)) {
				
					auditAction = log("Information transfer rejection success");
				}
				else {					
					auditAction = log("Information transfer updation failed, transferID:" + transferId);
				}
				
			}			
			createAudit(null, AuditLogService.CREATE, auditAction,request, auditLogFacade);

		} catch (Exception e) {
			
			logger.error("Information Transfer :" + e.getMessage());
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(REDIRECTION_URL));
	
	}
	
	private String log(String description) {
		
		if (logger.isInfoEnabled()) {
			
			logger.info(description);
		}
		
		return description;
	}
	
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}
	
}
