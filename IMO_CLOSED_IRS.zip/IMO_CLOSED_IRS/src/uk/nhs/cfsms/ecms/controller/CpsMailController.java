package uk.nhs.cfsms.ecms.controller;

import static uk.nhs.cfsms.ecms.ECMSConstants.SEMI_COLON;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSDocumentsDTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSMailFormFieldsDTO;
import uk.nhs.cfsms.ecms.dto.cps.CpsMailDto;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CPSDocumentService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.CpsMailService;
import uk.nhs.cfsms.ecms.service.EhcacheService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
public class CpsMailController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private AuditLogService auditLogFacade;

	@Autowired
	private CPSDocumentService cpsDocumentsService;

	@Autowired
	private EhcacheService ehcacheService;

	@Autowired
	private CpsMailService cpsMailService;

	@Value("${cps.mail.investigation.stage.select}")
	private String chooseOneStr;

	@Value("${cps.mail.error.message}")
	private String errorMessage;

	@Value("${cps.mail.success.message}")
	private String successMessage;

	@Value("${cps.mail.json.generation.exception}")
	private String jsonGenerationException;

	@Value("${cps.mail.json.mapping.exception}")
	private String jsonMappingException;

	@Value("${cps.mail.json.generation.io.exception}")
	private String jsonGenerationioException;

	@Value("${cps.mail.writing.response.io.exception}")
	private String writingResponseioException;
	
	@Value("${cps.mail.error.retrieving.approved.docs.list}")
	private String approvedDocsListException;
	
	@Value("${cps.mail.saving.exception}")	
	private String cpsMailSavingException;
	
	@Value("${cps.mail.send.exception}")	
	private String cpsMailSendException;
	
	@Autowired
	private CaseService caseFacade;

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/secure/cpsMailForm.htm")
	public ModelAndView cpsMailForm(HttpServletRequest request,
			@RequestParam("caseNumber") final String caseNumber,
			HttpServletResponse response, Model model) throws Exception {

		final HttpSession httpSession = request.getSession();
		final SessionUser sessionUser = EcmsUtils
				.getSessionUserObject(httpSession);

		ModelAndView modelAndView = null;
		
		if (null != sessionUser) {

			String requestorNHSEmailAddress = null;
			Map<String, Object> cpsFormFieldsMap = null;

			final String caseID = CaseUtil.getCaseId(request);

			cpsFormFieldsMap = (Map<String, Object>) httpSession
					.getAttribute(caseID);

			if (cpsFormFieldsMap == null) {
				cpsFormFieldsMap = new HashMap<String, Object>();
				final Set<String> investigationSet = new TreeSet<String>();

				final List<CPSMailFormFieldsDTO> cpsFormFieldsList = cpsDocumentsService
						.getCPSFormFields(sessionUser, caseID, caseNumber);

				investigationSet.add(chooseOneStr);

				for (CPSMailFormFieldsDTO mailFormFieldsDTO : cpsFormFieldsList) {
					final String investigationStage = mailFormFieldsDTO
							.getInvestigationStage();
					investigationSet.add(investigationStage);
					cpsFormFieldsMap.put(investigationStage, mailFormFieldsDTO);
				}

				final String requestorStaffID = cpsDocumentsService
						.getCPSDocsRequestorStaffID(Long.parseLong(caseID));

				if (requestorStaffID != null) {
					requestorNHSEmailAddress = cpsDocumentsService
							.getStaffNHSEmailAddress(requestorStaffID);
					requestorNHSEmailAddress = requestorNHSEmailAddress != null ? requestorNHSEmailAddress
							: "" + ";";
				}

				final String currentUserNHSEmailAddress = sessionUser
						.getNhsEmailAddress();

				cpsFormFieldsMap.put("caseNumber", caseNumber);
				cpsFormFieldsMap.put("caseID", caseID);
				cpsFormFieldsMap.put("investigationList", investigationSet);
				cpsFormFieldsMap.put("requestorNHSEmailAddress",
						requestorNHSEmailAddress);
				cpsFormFieldsMap.put("currentUserNHSEmailAddress",
						currentUserNHSEmailAddress);

				httpSession.setAttribute(caseID, cpsFormFieldsMap);
			}

			modelAndView = new ModelAndView("viewCPSEmailForm", "cpsMailMap",
					cpsFormFieldsMap);
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;
	}

	@RequestMapping(value = "/secure/getCPSFormFields.htm")
	public ModelAndView getCPSFormFields(
			HttpServletRequest request,
			@RequestParam("investigationStage") final String investigationStage,
			final HttpServletResponse response) throws ServiceException,
			CaseIDNotFoundException {
		final ObjectMapper mapper = new ObjectMapper();

		ModelAndView modelAndView = null;

		final HttpSession httpSession = request.getSession();
		final String caseID = CaseUtil.getCaseId(request);

		final SessionUser sessionUser = EcmsUtils
				.getSessionUserObject(httpSession);

		if (null != sessionUser) {

			@SuppressWarnings("unchecked")
			final Map<String, Object> cpsMailMap = (Map<String, Object>) httpSession
					.getAttribute(caseID);

			final CPSMailFormFieldsDTO cpsMailFormFieldsDTO = (CPSMailFormFieldsDTO) cpsMailMap
					.get(investigationStage);

			String cpsMailFormFields = null;
			try {
				cpsMailFormFields = mapper
						.writeValueAsString(cpsMailFormFieldsDTO);
			} catch (JsonGenerationException e) {
				logger.error(jsonGenerationException+" getCPSFormFields.htm"
						+ ExceptionUtils.getStackTrace(e));
			} catch (JsonMappingException e) {
				logger.error(jsonMappingException+" getCPSFormFields.htm"
						+ ExceptionUtils.getStackTrace(e));
			} catch (IOException e) {
				logger.error(jsonGenerationioException+" getCPSFormFields.htm"
						+ ExceptionUtils.getStackTrace(e));
			}
			try {
				FileCopyUtils.copy(cpsMailFormFields, response.getWriter());
			} catch (IOException e) {
				logger.error(writingResponseioException+" getCPSFormFields.htm"
						+ ExceptionUtils.getStackTrace(e));
			}
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;
	}

	@RequestMapping(value = "/secure/listApprovedCPSDocuments.htm")
	public ModelAndView listApprovedCPSDocuments(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView modelAndView = null;
		final ObjectMapper mapper = new ObjectMapper();

		final SessionUser sessionUser = EcmsUtils.getSessionUserObject(request
				.getSession());

		if (null != sessionUser) {

			final HttpSession httpSession = request.getSession();
			final String caseId = CaseUtil.getCaseId(request);

			final String staffId = EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId();

			try {
				final Boolean isMailSent = (Boolean) httpSession
						.getAttribute("isMailSent");

				final Boolean isNewMailSent = (Boolean) httpSession
						.getAttribute("isNewMailSent");

				if (isMailSent != null) {
					httpSession.setAttribute("fireHistoryQuery", isMailSent);
					httpSession.removeAttribute("isMailSent");
				}
				if (isNewMailSent != null) {
					httpSession.removeAttribute("isNewMailSent");
				}

				if ((isMailSent != null && isMailSent.booleanValue() == true)
						|| (isNewMailSent != null && isNewMailSent
								.booleanValue() == true)) {
					//ehcacheService
							//.resetLoadAllCPSApprovedDocumentsByNativeSQLCache();
				}

				final List<CPSDocumentsDTO> cpsDocumentsViewDTOs = cpsDocumentsService
						.loadAllCPSApprovedDocumentsByNativeSQL(staffId,
								new Long(caseId).longValue());

				final String approvedDocumentsList = mapper
						.writeValueAsString(cpsDocumentsViewDTOs);

				FileCopyUtils.copy(approvedDocumentsList, response.getWriter());

			} catch (JsonGenerationException e) {
				logger.error(jsonGenerationException+" /secure/listApprovedCPSDocuments.htm"
						+ ExceptionUtils.getStackTrace(e));
				throw new ServletException(e);
			} catch (JsonMappingException e) {
				logger.error(jsonMappingException+" /secure/listApprovedCPSDocuments.htm"
						+ ExceptionUtils.getStackTrace(e));
				throw new ServletException(e);
			} catch (IOException e) {
				logger.error(jsonGenerationioException+" /secure/listApprovedCPSDocuments.htm"
						+ ExceptionUtils.getStackTrace(e));
				throw new ServletException(e);
			} catch (Exception ex) {
				log.error(approvedDocsListException);
				throw new ServletException(ex);
			}
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;
	}

	@RequestMapping(value = "/secure/sendEmail.htm")
	public ModelAndView sendEmail(
			HttpServletRequest request,
			@RequestParam("investigationStageValue") final String investigationStageValue,
			@RequestParam("toValue") final String toValue,
			@RequestParam("ccValue") final String ccValue,
			@RequestParam("subjectValue") final String subjectValue,
			@RequestParam("messageValue") final String messageValue,
			@RequestParam("caseID") final String caseID,
			HttpServletResponse response) throws IOException {

		final HttpSession httpSession = request.getSession();
		final SessionUser sessionUser = EcmsUtils.getSessionUserObject(request
				.getSession());

		if (null != sessionUser) {
			try {
				boolean isMailDetailsSaved = true;
				Long cpsMailID = null;

				final String attachedDocsValue = request.getParameter(
						"attachedDocsValue").replaceAll("andsymbol", "&");

				@SuppressWarnings("unchecked")
				final Map<String, Object> cpsMailMap = (Map<String, Object>) httpSession
						.getAttribute(caseID);

				final String currentUserEmailAddress = (String) cpsMailMap
						.get("currentUserNHSEmailAddress");

				final SessionUser user = EcmsUtils.getSessionUserObject(request
						.getSession());

				final String fullName = user.getFullName();

				String message = messageValue.replaceAll("<br/>", " ");
				if (message.contains("andsymbol")) {
					message = message.replaceAll("andsymbol", "&");
				}
				final String msgBody = messageValue
						.replaceAll("andsymbol", "&");

				try {
					cpsMailID = saveCPSMailInformation(isMailDetailsSaved,
							investigationStageValue, toValue, ccValue,
							subjectValue, message, attachedDocsValue, caseID,
							currentUserEmailAddress, fullName);
				} catch (Exception ex) {
					isMailDetailsSaved = false;
					FileCopyUtils.copy(errorMessage, response.getWriter());
					logger.error("Got Exception while saving cps email :"
							+ ExceptionUtils.getStackTrace(ex));
				}

				if (isMailDetailsSaved) {
					try {
						javaMailSender.send(new MimeMessagePreparator() {
							@Override
							public void prepare(MimeMessage mimeMessage)
									throws MailException, MessagingException {
								MimeMessageHelper messageHelper = new MimeMessageHelper(
										mimeMessage, true, "UTF-8");

								String[] tos = toValue.split(";");
								String[] ccs = ccValue.split(";");

								messageHelper.setTo(tos);
								messageHelper.setCc(ccs);
								messageHelper.setFrom(currentUserEmailAddress);
								messageHelper.setSubject(subjectValue);
								messageHelper.setText(msgBody, true);

								StringTokenizer stringTokenizer = new StringTokenizer(
										attachedDocsValue, SEMI_COLON);

								while (stringTokenizer.hasMoreTokens()) {
									String attachedDoc = stringTokenizer
											.nextToken().trim();
									String[] fileNameGrpID = attachedDoc
											.split(":");
									String fileName = fileNameGrpID[0];
									if (fileName.startsWith("Ex.")
											&& fileName.contains("/")) {
										fileName = fileName.replace("/", "");
									}
									final String[] grpID = fileNameGrpID[2]
											.split("-");
									final String category = grpID[0];
									final String documentID = grpID[1];
									final CPSDocumentsDTO cpsDocumentsDTO = cpsDocumentsService
											.downloadCPSDocument(
													Long.parseLong(documentID),
													Long.parseLong(caseID),
													category, true);
									messageHelper.addAttachment(
											cpsDocumentsDTO.getFileName(),
											(InputStreamSource) new ByteArrayResource(
													cpsDocumentsDTO
															.getFileBlob()));

								}
							}
						});
						httpSession.setAttribute("isMailSent", true);
						FileCopyUtils
								.copy(successMessage, response.getWriter());
						AuditFlowThread.set("Email sent");
					} catch (Exception ex) {
						FileCopyUtils.copy(errorMessage, response.getWriter());
						if (cpsMailID != null) {
							cpsMailService.delete(cpsMailID);
						}
						httpSession.setAttribute("isMailSent", false);
						logger.error(cpsMailSavingException
								+ ExceptionUtils.getStackTrace(ex));
					}
				}
			} catch (Exception ex) {
				FileCopyUtils.copy(errorMessage, response.getWriter());
				httpSession.setAttribute("isMailSent", false);
				logger.error(cpsMailSendException
						+ ExceptionUtils.getStackTrace(ex));

			}
		} else {
			final String context = request.getContextPath();
			return new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return null;
	}

	@RequestMapping(value = "/secure/cpsEmailHistory.htm")
	public ModelAndView showCPSMailsHistory(HttpServletRequest request,
			@RequestParam("caseID") final String caseID,
			HttpServletResponse response) throws JsonGenerationException,
			JsonMappingException, IOException, NumberFormatException,
			ServiceException {

		final ObjectMapper mapper = new ObjectMapper();
		final HttpSession httpSession = request.getSession();
		final CaseTO caseTO = cpsDocumentsService.loadCase(new Long(caseID));

		final SessionUser sessionUser = EcmsUtils.getSessionUserObject(request
				.getSession());

		if (null != sessionUser) {

			//if (isNewMailInserted(httpSession)) {
				//ehcacheService.resetGetCpsMailDetailsCache();
			//}

			final Map<String, String> mailHistoryMap = new HashMap<String, String>();

			final List<CpsMailDto> cpsMailDtos = cpsMailService
					.getCpsMailDetails(Long.valueOf(caseID));

			for (CpsMailDto cpsMailDto : cpsMailDtos) {
				final String attachedDocsValue = cpsMailDto.getAttachedDocs();
				final String[] attachedFiles = attachedDocsValue.split(";");
				String attDocs = "";
				for (String attDoc : attachedFiles) {
					attDocs += attDoc.split(":")[0] + ";";
				}
				cpsMailDto.setAttachedDocs(attDocs);
				cpsMailDto.setMessage(cpsMailDto.getMessage());
				cpsMailDto.setSenderName(cpsMailDto.getSenderName());
			}
			final String cpsMailHistory = mapper
					.writeValueAsString(cpsMailDtos);
			mailHistoryMap.put("cpsMailHistory", cpsMailHistory);
			mailHistoryMap.put("caseID", caseID);
			mailHistoryMap.put("caseNumber", caseTO.getCaseNumber());
			mailHistoryMap.put("operationName", caseTO.getOperationName());
			return new ModelAndView("viewCPSEmailsHistory", "cpsMailDtos",
					mailHistoryMap);
		} else {
			final String context = request.getContextPath();
			return new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
	}

	private boolean isNewMailInserted(final HttpSession httpSession) {
		boolean isNewMailInserted = false;
		final Boolean isMailSent = (Boolean) httpSession
				.getAttribute("isMailSent");
		final Boolean fireHistoryQuery = (Boolean) httpSession
				.getAttribute("fireHistoryQuery");

		if (fireHistoryQuery != null) {
			httpSession.removeAttribute("fireHistoryQuery");
		}
		if (isMailSent != null) {
			httpSession.setAttribute("isNewMailSent", isMailSent);
			httpSession.removeAttribute("isMailSent");
		}
		if ((isMailSent != null && isMailSent.booleanValue() == true)) {
			isNewMailInserted = true;
		}
		if ((fireHistoryQuery != null && fireHistoryQuery.booleanValue() == true)) {
			isNewMailInserted = true;
		}
		return isNewMailInserted;
	}

	private Long saveCPSMailInformation(boolean isMailDetailsSaved,
			final String... cpsMailFormData) throws IllegalAccessException,
			InvocationTargetException {

		final long cpsMailID;
		final CpsMailDto cpsMailDto = new CpsMailDto();

		cpsMailDto.setInvestigationStage(cpsMailFormData[0]);
		cpsMailDto.setTo(cpsMailFormData[1]);
		cpsMailDto.setCc(cpsMailFormData[2]);
		cpsMailDto.setSubject(cpsMailFormData[3]);
		cpsMailDto.setMessage(cpsMailFormData[4]);
		cpsMailDto.setAttachedDocs(cpsMailFormData[5]);
		cpsMailDto.setCaseID(Long.valueOf(cpsMailFormData[6]));
		cpsMailDto.setSenderEmailId(cpsMailFormData[7]);
		cpsMailDto.setSenderName(cpsMailFormData[8]);
		cpsMailDto.setEmailDate(new Timestamp(new Date().getTime()));
		cpsMailID = cpsMailService.save(cpsMailDto);
		isMailDetailsSaved = true;
		return cpsMailID;
	}

	/**
	 * @param auditLogFacade
	 *            the auditLogFacade to set
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}