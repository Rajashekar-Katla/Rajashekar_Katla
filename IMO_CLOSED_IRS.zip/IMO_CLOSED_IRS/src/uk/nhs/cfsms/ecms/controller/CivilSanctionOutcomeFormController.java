package uk.nhs.cfsms.ecms.controller;

import java.math.BigDecimal;
import java.text.NumberFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanction;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionOutcome;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionTO;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CivilSanctionService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
public class CivilSanctionOutcomeFormController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CivilSanctionService civilSanctionFacade;

	@SuppressWarnings("deprecation")
	public CivilSanctionOutcomeFormController() {
		
	}
	

	@RequestMapping(value="/secure/saveCivilSanctionOutcome.htm")
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, @ModelAttribute("civilSanctionOutcome") CivilSanctionOutcome outcome, BindingResult errors)
			throws Exception {
				
		validateSanctionOutcome(outcome, request, errors);
		
		if (errors.getErrorCount() > 0) {
			
		}

		// Set the status, if they have filled in the investigation costs.
	
		if (outcome.getInvestigationCosts() != null) {
			outcome.setOutcomeStatus(CaseUtil.SanctionOutcome.WITHDRAWN
					.name());
		}
		if (null != outcome) {
			outcome.setCreatedDate(new java.util.Date());
		}
		
		if (outcome.getCivilSanctionOutcomeId() == null) {
			AuditFlowThread.set("Civil Sanction Outcome Created"); 
		} else {
			AuditFlowThread.set("Civil Sanction Outcome Updated"); 
		}
		// save the outcome
		civilSanctionFacade.saveObject(outcome);
		
		createAudit(outcome, null==outcome.getCivilSanctionOutcomeId()?AuditLogService.CREATE :AuditLogService.UPDATE,
				"Civil Sanction Outcome Updated", request, auditLogFacade);

		// reset the civil sanction status to that of the outcome status
		CivilSanctionTO cs = (CivilSanctionTO) civilSanctionFacade.getObject(
				CivilSanctionTO.class, outcome.getCivilSanctionId());
		cs.setState(outcome.getOutcomeStatus());
		CivilSanction sanction = ConvertFromDTO.getInstance().convertFromDTO(cs);
		
		AuditFlowThread.set("Civil Sanction State Updated"); 
		createAudit(cs, AuditLogService.UPDATE,	"Civil Sanction State Updated", request, auditLogFacade);
		
		civilSanctionFacade.saveObject(sanction);
		
		// Redirect..
		return new ModelAndView(new RedirectView("civilSanctionMenu.htm?sanctionId=" + outcome.getCivilSanctionId()));
	}
	
	
	private void validateSanctionOutcome(CivilSanctionOutcome dto,
			HttpServletRequest request, BindingResult errors) {
		
		if (null != dto.getAwardedCost() && 
				!EcmsUtils.isValidNumber(dto.getAwardedCost().toString())) {
			
			errors.rejectValue("awardedCost", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != dto.getInvestigationCosts() && 
				!EcmsUtils.isValidNumber(dto.getInvestigationCosts().toString())) {
			
			errors.rejectValue("investigationCosts", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != dto.getNegotiatedSettlementAmount() && 
				!EcmsUtils.isValidNumber(dto.getNegotiatedSettlementAmount().toString())) {
			
			errors.rejectValue("negotiatedSettlementAmount", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != dto.getSettledAwardedAmount() && 
				!EcmsUtils.isValidNumber(dto.getSettledAwardedAmount().toString())) {
			
			errors.rejectValue("settlementAwardedAmount", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}

		log.info("SanctionOutcomeFormController.validateSanctionOutcome");
	}


	/**
	 * @param civilSanctionFacade
	 *            The civilSanctionFacade to set.
	 */
	public void setCivilSanctionFacade(CivilSanctionService civilSanctionFacade) {
		
		this.civilSanctionFacade = civilSanctionFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		
		this.auditLogFacade = auditLogFacade;
	}

	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			log.error(e);
		}
	}
	
	@InitBinder
	protected void initBinder(HttpServletRequest servletRequest,
			ServletRequestDataBinder binder) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("\n initBinder");
		}
		
		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, nf, true));
		binder
				.registerCustomEditor(String.class, new StringTrimmerEditor(
						true));
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null,
				new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}
	
}
