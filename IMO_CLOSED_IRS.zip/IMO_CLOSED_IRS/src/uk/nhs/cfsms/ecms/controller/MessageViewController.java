package uk.nhs.cfsms.ecms.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.Message;
import uk.nhs.cfsms.ecms.data.cim.MessageView;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CPSDocumentService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.IMOMessageReceiverService;
import uk.nhs.cfsms.ecms.service.MessageService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

@Controller
public class MessageViewController extends BaseMultiActionController {

	Logger logger = Logger.getLogger(MessageViewController.class);
	@Autowired
	private MessageService messageFacade;
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private IMOMessageReceiverService imoMessagereceiverService;
	
	@Autowired
	private CPSDocumentService cpsDocumentsService;

	@Autowired
	private CaseService caseFacade;

	static final String PARENT_PAGE = "parentPage";

	static final String APPROVE = "approve";

	static final String REJECT = "reject";

	@RequestMapping(value = "/secure/listmessages.htm")
	public ModelAndView listMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (log.isInfoEnabled()) {
			log.info("listMessages, both new and read");
		}

		HttpSession session = request.getSession();
		SessionUser user = EcmsUtils.getSessionUserObject(session);

		Map<String, Object> model = new HashMap<String, Object>();

		try {
			List<MessageView> newMessages = messageFacade
					.loadMessagesByToStaffId(user,
							ECMSConstants.MESSAGE_STATE_NEW);

			List<MessageView> readMessages = messageFacade
					.loadMessagesByToStaffId(user,
							ECMSConstants.MESSAGE_STATE_READ);
			final Map<String, String> imoMap = imoMessagereceiverService
					.getAllIMOMessageReceivers();
			
			final String isLoggedInUserActiveMsgReceiver = imoMap.get(user.getStaffId());
			
			final Map<String,String> imoUserNameStatusMap = new HashMap<String,String>();
			
			for(Map.Entry<String,String> entryMap : imoMap.entrySet()){
				final String userFullName = cpsDocumentsService.getUserFullName(entryMap.getKey());
				imoUserNameStatusMap.put(entryMap.getKey()+"-"+entryMap.getValue(),userFullName);
			}
			model.put("newmessages", newMessages);
			model.put("readmessages", readMessages);
			model.put("imoMap", imoUserNameStatusMap);
			model.put("isLoggedInUserActiveMsgReceiver", isLoggedInUserActiveMsgReceiver);
			
			session.setAttribute(PARENT_PAGE,
					ECMSConstants.MESSAGE_PARENT_FLOW.READ);
			return new ModelAndView("newmessagesview", "messagesMap", model);

		} catch (Exception e) {

			log.error("Exception: listMessages :" + e);
			throw new ServletException(e);
		}
	}

	@RequestMapping(value = "/secure/listsentmessages.htm")
	public ModelAndView listSentMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		HttpSession session = request.getSession();
		SessionUser user = EcmsUtils.getSessionUserObject(session);

		Map<String, List<MessageView>> model = new HashMap<String, List<MessageView>>();

		try {
			List<MessageView> sentMessages = messageFacade
					.loadMessagesByFromStaffId(user);

			model.put("sentmessages", sentMessages);

			session.setAttribute(PARENT_PAGE,
					ECMSConstants.MESSAGE_PARENT_FLOW.SENT);

			return new ModelAndView("listsentmessages", "messagesMap", model);

		} catch (Exception e) {

			log.error("ERROR: listSentMessages :" + e);
			throw new ServletException(e);
		}
	}

	@RequestMapping(value = "/secure/viewmessage.htm")
	public ModelAndView viewMessage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (log.isInfoEnabled()) {
			log.info("*viewMessage()");
		}
		HttpSession session = request.getSession();

		SessionUser sessUsr = EcmsUtils.getSessionUserObject(session);

		boolean isStaffNITNLead = (sessUsr.isNITNorthLead()) ? true : false;
		boolean isStaffNITSLead = (sessUsr.isNITSouthLead()) ? true : false;

		String mesgId = request.getParameter("messageId");
		try {
			Long messsageId = new Long(mesgId);
			MessageTO mesgTO = messageFacade.loadMessage(messsageId);

			String actualState = mesgTO.getState();
			String markedAsUnread = mesgTO.getMarkAsUnread();
			// Update message state to READ.			
			if (isStaffNITNLead) {

				mesgTO.setNitnLeadState(ECMSConstants.MESSAGE_STATE_READ);

			} else if (isStaffNITSLead) {

				mesgTO.setNitsLeadState(ECMSConstants.MESSAGE_STATE_READ);

			} else if (isMessageToSessionUser(mesgTO, sessUsr)
					&& !mesgTO.getState().equals(
							ECMSConstants.MESSAGE_STATE_READ)) {

				mesgTO.setState(ECMSConstants.MESSAGE_STATE_READ);
			}

			if (null != mesgTO
					&& sessUsr.isNITAFL()
					&& ECMSConstants.MESSAGE_STATE_READ.equals(mesgTO
							.getNitnLeadState())
					&& ECMSConstants.MESSAGE_STATE_READ.equals(mesgTO
							.getNitsLeadState())) {

				mesgTO.setState(ECMSConstants.MESSAGE_STATE_READ);
			}

			if (sessUsr.isNITAFL()
					|| (isMessageToSessionUser(mesgTO, sessUsr) && (StringUtils
							.equals(ECMSConstants.MESSAGE_STATE_NEW,
									actualState) || StringUtils.equals("Y",
							markedAsUnread)))) {

				mesgTO.setReadTime(new Date());
				mesgTO.setMarkAsUnread("");
				AuditFlowThread.set("Message Read");
				messageFacade.updateMessage(mesgTO, false);

				this.createAudit(mesgTO, AuditLogService.UPDATE, "Messages",
						request, auditLogFacade);
			}
			String readOnlyParam = request.getParameter("rdlyas");
			String trashViewFlag = request.getParameter("trashView");

			MessageView mesgView = messageFacade.loadMessageView(messsageId);
			Map<String, Object> model = new HashMap<String, Object>();
			model.put("messageObject", mesgView);
			model.put("readonly", null != readOnlyParam ? true : false);
			model.put("trashViewFlag", null != trashViewFlag ? true : false);
			//session.setAttribute(PARENT_PAGE, ECMSConstants.MESSAGE_PARENT_FLOW.VIEW);
			return new ModelAndView("viewmessage", "messageMap", model);

		} catch (Exception e) {

			log.error("ERROR loading in viewMessages :" + e);
			throw new ServletException(e);
		}
	}

	private boolean isMessageToSessionUser(MessageTO mesgTO, SessionUser user) {

		if (mesgTO.getToStaffId().equalsIgnoreCase(user.getStaffId())) {

			return true;
		}
		return false;
	}

	@RequestMapping(value = "/secure/listnewmessages.htm")
	public ModelAndView listNewMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		HttpSession session = request.getSession();
		SessionUser user = EcmsUtils.getSessionUserObject(session);
		try {
			List<MessageView> newMessages = messageFacade
					.loadMessagesByToStaffId(user,
							ECMSConstants.MESSAGE_STATE_NEW);

			Map<String, List<MessageView>> model = new HashMap<String, List<MessageView>>();
			model.put("messages", newMessages);
			session.setAttribute(PARENT_PAGE,
					ECMSConstants.MESSAGE_PARENT_FLOW.NEW);
			return new ModelAndView("newmessagesview", "messageMap", model);

		} catch (Exception e) {

			log.error("\n** ERROR: listNewMessages :" + e);
			throw new ServletException(e);
		}
	}

	@RequestMapping(value = "/secure/cancelmessage.htm")
	public ModelAndView cancelMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		return this.getModelAndViewByParentFlow(request);
	}

	@Deprecated
	@RequestMapping(value = "/secure/toplistmessages.htm")
	public ModelAndView topListMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		try {
			List<MessageView> newMessages = messageFacade
					.loadMessagesByToStaffId(user,
							ECMSConstants.MESSAGE_STATE_NEW);

			Map<String, List<MessageView>> model = new HashMap<String, List<MessageView>>();
			model.put("messages", newMessages);

			return new ModelAndView("topmessageview", "messageMap", model);

		} catch (Exception e) {
			throw new ServletException("Exception with Loading Messages.");
		}
	}

	@RequestMapping(value = "/secure/updatemessage.htm")
	public ModelAndView updateMessage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String auditAction = "";
		MessageTO auditMessage = null;
		String mesgId = request.getParameter("messageId");
		String actionDetails = request.getParameter("actionDetails");
		String actionType = request.getParameter("_reject");
		String acceptActionType = request.getParameter("_accept");
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		if (StringUtils.isEmpty(mesgId)) {
			logger.error("Invalid Empty messageId");
			throw new ServletException("Invalid Message ID");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Action Details=" + actionDetails);
			logger.debug("message ID =" + mesgId);
		}
		try {
			MessageTO message = messageFacade.loadMessage(new Long(mesgId));

			if (StringUtils.isNotEmpty(actionType)) {

				MessageTO rejectMesg = createRejectMessage(message,
						actionDetails);

				if (rejectMesg == null) {

					log.error("reject Message is NULL, Updating Message.."
							+ mesgId);
					throw new Exception(
							"NULL reject Message with Loading/Updating Message.");
				}
				AuditFlowThread.set("Message Updated");
				if (null != rejectMesg.getCaseId()
						&& rejectMesg.getMessageType().equals(
								MessageTO.Message_types.CASE_CLOSURE_REJECTED
										.toString())) {

					messageFacade.updateMessage(rejectMesg, true);

				} else if (rejectMesg.getMessageType().equals(
						MessageTO.Message_types.INFO_CLOSURE.toString())
						|| rejectMesg.getMessageType().equals(
								MessageTO.Message_types.IIU_IMO_REFERRAL
										.toString())) {

					messageFacade.updateInfoMessage(rejectMesg, true);

				} else {

					messageFacade.updateMessage(rejectMesg, false);
				}
				auditMessage = rejectMesg;
				auditAction = "Reject Message";

			} else if (StringUtils.isNotEmpty(acceptActionType)) {

				AuditFlowThread.set("Message Accepted");

				MessageTO acceptMsg = createAcceptMessage(message,
						actionDetails);
				if (null != acceptMsg
						&& null != acceptMsg.getCaseId()
						&& acceptMsg.getMessageType().equals(
								MessageTO.Message_types.CASE_CLOSURE_ACCEPTED
										.toString())) {

					messageFacade.updateAcceptedCaseClosureMessage(acceptMsg,
							true);
				}
				auditMessage = acceptMsg;
				auditAction = "Accept Message";

			} else {
				AuditFlowThread.set("Message Updated");

				message.setActionDetails(actionDetails + " -- by "
						+ user.getFullName() + " on "
						+ ECMSConstants.datetimeFormat.format(new Date()));
				message.setState(ECMSConstants.MESSAGE_STATE_READ);
				messageFacade.updateMessage(message, false);
				auditMessage = message;
				auditAction = "Updating Message";
			}

			createAudit(auditMessage, AuditLogService.UPDATE, auditAction,
					request, auditLogFacade);

		} catch (Exception e) {
			log.error("\n** ERROR: updateMessage :" + e);
			throw new ServletException(e);
		}
		return new ModelAndView("messageupdated");

	}

	/**
	 * Its a reject (almost reply) message from the original message.
	 * 
	 * @param origMesg
	 * @param actionDetails
	 * @return rejectedMessage
	 */
	private MessageTO createRejectMessage(MessageTO origMesg,
			String actionDetails) {

		MessageTO messageTo = null;

		if (origMesg.getMessageType().equalsIgnoreCase(
				MessageTO.Message_types.CASE_CLOSURE.toString())) {

			messageTo = createNewMessageByType(origMesg, actionDetails,
					MessageTO.Message_types.CASE_CLOSURE_REJECTED.toString());

		} else if (origMesg.getMessageType().equalsIgnoreCase(
				MessageTO.Message_types.CASE_CLOSURE_REJECTED.toString())) {

			messageTo = createNewMessageByType(origMesg, actionDetails,
					MessageTO.Message_types.CASE_CLOSURE_REJECTED.toString());

		} else if (origMesg.getMessageType().equalsIgnoreCase(
				MessageTO.Message_types.CASE_ACTION_ALLOCATION.toString())) {

			messageTo = createNewMessageByType(origMesg, actionDetails,
					"Case Action Rejected");
		} else {

			messageTo = createNewMessageByType(origMesg, actionDetails, "");
		}

		return messageTo;
	}

	/**
	 * Its a accept (almost reply) message from the original message.
	 * 
	 * @param origMesg
	 * @param actionDetails
	 * @return rejectedMessage
	 */
	private MessageTO createAcceptMessage(MessageTO origMesg,
			String actionDetails) {

		return createNewMessageByType(origMesg, actionDetails,
				MessageTO.Message_types.CASE_CLOSURE_ACCEPTED.toString());

	}

	private MessageTO createNewMessageByType(MessageTO mesg, String action,
			String type) {

		MessageTO acceptMesg = new MessageTO();
		acceptMesg.setToStaffId(mesg.getFromStaffId());
		acceptMesg.setToStaffName(mesg.getFromStaffName());
		acceptMesg.setFromStaffId(mesg.getToStaffId());
		acceptMesg.setFromStaffName(mesg.getToStaffName());
		acceptMesg.setCaseId(mesg.getCaseId());
		acceptMesg.setActionTitle(mesg.getActionTitle());
		acceptMesg.setCaseRef(mesg.getCaseRef());
		acceptMesg.setMessage(action);
		acceptMesg.setInformationId(mesg.getInformationId());
		acceptMesg.setInformationRef(mesg.getInformationRef());
		acceptMesg.setCreatedStaffId(mesg.getFromStaffId());
		acceptMesg.setCreatedTime(new Date());
		acceptMesg.setParentId(mesg.getMessageId());
		acceptMesg.setState(ECMSConstants.MESSAGE_STATE_NEW);
		acceptMesg.setMessageType(StringUtils.isNotEmpty(type) ? type : mesg
				.getMessageType());
		return acceptMesg;
	}

	@RequestMapping(value = "/secure/forwardIMOMessages.htm")
	public ResponseEntity<String> forwardIMOMessages(HttpServletRequest request,
			HttpServletResponse response, MessageTO messageTO,@RequestParam("messageId") final String msgIds) throws ServletException {
		
		ResponseEntity<String> responseEntity;
		
		final String toStaffId = messageTO.getToStaffId();
		final String toStaffName = messageTO.getToStaffName();
		
		try{
			messageFacade.forwardMsgsToIMOMember(toStaffName, toStaffId, msgIds);
			responseEntity = setSuccessHeader();
		}catch(Exception ex){
			responseEntity = setErrorHeader(ex);
		}
		
		return responseEntity;
	}
	
	private ResponseEntity<String> setSuccessHeader() {
		final HttpHeaders httpsHeaders = new HttpHeaders();
		httpsHeaders.set("redirect", "/secure/welcome.htm?fromMenu=home&listType=messages");
		return new ResponseEntity<String>(httpsHeaders, HttpStatus.CREATED);
	}
	
	/**
	 * @param informationId
	 * @param httpsHeaders
	 */
	private ResponseEntity<String> setErrorHeader(Exception e) {
		final HttpHeaders httpsHeaders = new HttpHeaders();
		httpsHeaders.set("error", Arrays.toString(e.getStackTrace()));
		return new ResponseEntity<String>(httpsHeaders, HttpStatus.BAD_REQUEST);
	}
	
	@RequestMapping(value = "/secure/listcasemessages.htm")
	public ModelAndView listCaseMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		HttpSession session = request.getSession();
		String caseId = null;

		try {
			caseId = request.getParameter(CaseUtil.CASE_ID_PARAM);

			List<Message> caseMessages = messageFacade
					.loadMessagesByCaseId(new Long(caseId));

			Map<String, List<Message>> model = new HashMap<String, List<Message>>();
			model.put("messagelist", caseMessages);
			session.setAttribute(PARENT_PAGE,
					ECMSConstants.MESSAGE_PARENT_FLOW.CASE);
			return new ModelAndView("listcasemessages", "messagesMap", model);

		} catch (Exception e) {

			log.error("\n** ERROR: listCaseMessages :" + e);
			throw new ServletException(e);
		}
	}

	@RequestMapping(value = "/secure/listinfomessages.htm")
	public ModelAndView listInfoMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String infoId = request.getParameter("informationId");

		HttpSession session = request.getSession();

		try {
			List<Message> infoMessages = messageFacade
					.loadMessagesByInfoId(new Long(infoId));

			Map<String, List<Message>> model = new HashMap<String, List<Message>>();
			model.put("messagelist", infoMessages);
			session.setAttribute(PARENT_PAGE,
					ECMSConstants.MESSAGE_PARENT_FLOW.INFORMATION);
			return new ModelAndView("listcasemessages", "messagesMap", model);

		} catch (Exception e) {

			log.error("\n** ERROR: listInfoMessages :" + e);
			throw new ServletException(e);
		}
	}

	@RequestMapping(value = "/secure/deleteallmessages.htm")
	public ModelAndView deleteAllMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String messageIds = request.getParameter("messageId");

		if (log.isInfoEnabled()) {

			log.info("delete AllMessages messageIds =" + messageIds);
		}
		try {
			StringTokenizer messageTokens = new StringTokenizer(messageIds, ",");

			while (messageTokens.hasMoreElements()) {

				String messageId = messageTokens.nextToken();

				if (null != messageId) {

					deleteMessagesById(request, response, messageId);
				}
			}

		} catch (Exception e) {

			log.error("\n** ERROR: deleteAllMessages :" + e);
			throw new ServletException(e);
		}

		return getModelAndViewByParentFlow(request);
	}

	/**
	 * Deleted Message filter.
	 * 
	 * This method is responsible for deleting the messages with in the system.
	 * Once message is deleted it's respective status gets updated in back-end.
	 * Front end system will not be able to list these message again.
	 * 
	 * @param request
	 * @param response
	 * 
	 * @return ModelAndView
	 * */
	@RequestMapping(value = "/secure/deletemessage.htm")
	public ModelAndView deleteMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		String mesgId = request.getParameter("messageId");

		if (StringUtils.isEmpty(mesgId)) {
			logger.error("Invalid Empty messageId");
			throw new ServletException("Invalid Message ID");
		}

		try {

			MessageTO message = messageFacade.loadMessage(Long
					.parseLong(mesgId));

			if (user.isNITNorthLead() || user.isNITSouthLead()) {
				if (user.isNITNorthLead()) {
					message.setDeleteNitn("Y");
					message.setNitnLeadState(ECMSConstants.MESSAGE_STATE_READ);
				}

				if (user.isNITSouthLead()) {
					message.setDeleteNits("Y");
					message.setNitsLeadState(ECMSConstants.MESSAGE_STATE_READ);
				}
			} else {
				if (message.getToStaffId().equalsIgnoreCase(user.getStaffId())) {
					message.setDeleteTo("Y");
					message.setState(ECMSConstants.MESSAGE_STATE_READ);
				}
				if (message.getFromStaffId()
						.equalsIgnoreCase(user.getStaffId())) {
					message.setDeleteFrom("Y");
					message.setState(ECMSConstants.MESSAGE_STATE_READ);
				}
			}
			AuditFlowThread.set("Message Updated");

			messageFacade.updateMessage(message, false);

			createAudit(message, AuditLogService.UPDATE, "Deleting Message",
					request, auditLogFacade);

		} catch (Exception e) {

			log.error("\n** ERROR: Loading/Deleting Message:" + e);
			throw new ServletException(e);
		}

		return getModelAndViewByParentFlow(request);
	}

	/**
	 * Delete Message by message id
	 * 
	 * This method is responsible for deleting the messages By message id with
	 * in the system. Once message is deleted it's respective status gets
	 * updated in back-end. Front end system will not be able to list these
	 * message again.
	 * 
	 * @param request
	 * @param response
	 * @param mesgId
	 * 
	 * @return void
	 * */

	public void deleteMessagesById(HttpServletRequest request,
			HttpServletResponse response, String mesgId)
			throws ServletException {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		if (StringUtils.isEmpty(mesgId)) {
			logger.error("Invalid Empty messageId");
			throw new ServletException("Invalid Message ID");
		}
		try {

			MessageTO message = messageFacade.loadMessage(Long
					.parseLong(mesgId));

			if (user.isNITNorthLead() || user.isNITSouthLead()) {
				if (user.isNITNorthLead()) {
					message.setDeleteNitn("Y");
					message.setNitnLeadState(ECMSConstants.MESSAGE_STATE_READ);
				}

				if (user.isNITSouthLead()) {
					message.setDeleteNits("Y");
					message.setNitsLeadState(ECMSConstants.MESSAGE_STATE_READ);
				}
			} else {
				if (message.getToStaffId().equalsIgnoreCase(user.getStaffId())) {
					message.setDeleteTo("Y");
					message.setState(ECMSConstants.MESSAGE_STATE_READ);
				}
				if (message.getFromStaffId()
						.equalsIgnoreCase(user.getStaffId())) {
					message.setDeleteFrom("Y");
					message.setState(ECMSConstants.MESSAGE_STATE_READ);
				}
			}
			AuditFlowThread.set("Message Deleted");

			messageFacade.updateMessage(message, false);

			createAudit(message, AuditLogService.UPDATE, "Deleting Message",
					request, auditLogFacade);

		} catch (Exception e) {

			log.error("\n** ERROR: deleteMessage :" + e);
			throw new ServletException(e);
		}
	}

	/**
	 * Sets Mark as unread flag
	 * 
	 * This method is responsible for setting Mark as unread flag to 'Y'
	 * 
	 * @param request
	 * @param response
	 * @param mesgId
	 * 
	 * @return void
	 * */
	@RequestMapping(value = "/secure/markAsUnread.htm")
	public ModelAndView markAsUnread(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		String messageId = request.getParameter("messageId");

		if (StringUtils.isEmpty(messageId)) {
			logger.error("Invalid Empty messageId");
			throw new ServletException("Invalid Message ID");
		}
		try {

			MessageTO message = messageFacade.loadMessage(Long
					.parseLong(messageId));
			message.setMarkAsUnread("Y");
			AuditFlowThread.set("Message Unread");
			messageFacade.updateMessage(message, false);

			createAudit(message, AuditLogService.UPDATE,
					"Setting Mark As Unread", request, auditLogFacade);

		} catch (Exception e) {

			log.error("\n** ERROR: markAsUnread :" + e);
			throw new ServletException(e);
		}
		return getModelAndViewByParentFlow(request);
	}

	/**
	 * Sets Mark as read flag
	 * 
	 * This method is responsible for setting Mark as unread flag to ''
	 * 
	 * @param request
	 * @param response
	 * @param mesgId
	 * 
	 * @return void
	 * */
	@RequestMapping(value = "/secure/markAsRead.htm")
	public ModelAndView markAsRead(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		String messageId = request.getParameter("messageId");

		if (StringUtils.isEmpty(messageId)) {
			logger.error("Invalid Empty messageId");
			throw new ServletException("Invalid Message ID");
		}
		try {

			MessageTO message = messageFacade.loadMessage(Long
					.parseLong(messageId));
			message.setMarkAsUnread("");

			messageFacade.updateMessage(message, false);

			createAudit(message, AuditLogService.UPDATE,
					"Setting Mark As Unread", request, auditLogFacade);

		} catch (Exception e) {

			log.error("\n** ERROR: markAsUnread :" + e);
			throw new ServletException(e);
		}
		return getModelAndViewByParentFlow(request);
	}

	/**
	 * List Trash Message by message id Start
	 * 
	 * This method is responsible for deleting the messages By message id with
	 * in the system. Once message is deleted it's respective status gets
	 * updated in back-end. Front end system will not be able to list these
	 * message again.
	 * 
	 * @param request
	 * @param response
	 * @param mesgId
	 * 
	 * @return void
	 * */
	@RequestMapping(value = "/secure/listAllTrashMessages.htm")
	public ModelAndView listAllTrashMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		HttpSession session = request.getSession();

		Map<String, Object> messageMap = new HashMap<String, Object>();

		SessionUser user = EcmsUtils.getSessionUserObject(session);

		List<MessageView> readTrashMessages = messageFacade
				.loadTrashMessagesByToStaffID(user,
						ECMSConstants.MESSAGE_STATE_READ);
		List<MessageView> sentTrashMessages = messageFacade
				.loadTrashMessagesByFromStaffID(user);

		messageMap.put("readTrashMessages", readTrashMessages);
		messageMap.put("sentTrashMessages", sentTrashMessages);

		session.setAttribute(PARENT_PAGE,
				ECMSConstants.MESSAGE_PARENT_FLOW.TRASH);

		return new ModelAndView("listAllTrashMessages", "messageMap",
				messageMap);

	}

	/**
	 * restore all Trashed Messages Start
	 * 
	 * This method is responsible for restoring the messages for the given IDs
	 * with in the system. Once message is deleted it's respective status gets
	 * updated in back-end. Front end system will not be able to list these
	 * message again.
	 * 
	 * @param request
	 * @param response
	 * @param mesgId
	 * 
	 * @return void
	 * */
	@RequestMapping(value = "/secure/restoreAllMessages.htm")
	public ModelAndView restoreAllMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String messageIds = request.getParameter("messageId");

		if (log.isInfoEnabled()) {
			log.info("All messageIds : " + messageIds);
		}
		try {

			StringTokenizer messageTokens = new StringTokenizer(messageIds, ",");

			while (messageTokens.hasMoreElements()) {

				String messageId = messageTokens.nextToken();

				if (StringUtils.isNotEmpty(messageId)) {

					restoreMessagesById(request, response, messageId);
				}
			}

		} catch (Exception e) {

			log.error("ERROR while restoreAllMessages :" + e);
			throw new ServletException(e);
		}
		return getModelAndViewByParentFlow(request);
	}

	/**
	 * Delete Message by message id Start
	 * 
	 * This method is responsible for deleting the messages By message id with
	 * in the system. Once message is deleted it's respective status gets
	 * updated in back-end. Front end system will not be able to list these
	 * message again.
	 * 
	 * @param request
	 * @param response
	 * @param mesgId
	 * 
	 * @return void
	 * */

	public void restoreMessagesById(HttpServletRequest request,
			HttpServletResponse response, String mesgId)
			throws ServletException {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		if (StringUtils.isEmpty(mesgId)) {
			logger.error("Invalid Empty messageId");
			throw new ServletException(
					"ERROR: restoreMessagesById : Invalid Message ID");
		}
		try {
			MessageTO message = messageFacade.loadMessage(Long
					.parseLong(mesgId));

			if (user.isNITNorthLead() || user.isNITSouthLead()) {

				if (user.isNITNorthLead()) {
					message.setDeleteNitn("N");
				}
				if (user.isNITSouthLead()) {
					message.setDeleteNits("N");
				}
			} else {

				if (message.getToStaffId().equalsIgnoreCase(user.getStaffId())) {
					message.setDeleteTo("N");
				}
				if (message.getFromStaffId()
						.equalsIgnoreCase(user.getStaffId())) {
					message.setDeleteFrom("N");
				}
			}
			AuditFlowThread.set("Message Updated");

			messageFacade.updateMessage(message, false);

			createAudit(message, AuditLogService.UPDATE, "Restoring Message",
					request, auditLogFacade);

		} catch (Exception e) {

			log.error("\n** ERROR: restoring Messages :" + e);
			throw new ServletException(e);
		}
	}

	/**
	 * Information Transfer Method is responsible for approving or rejecting the
	 * information transfer requests initiated be LCFS users to CIU users.
	 * 
	 * 
	 * @param request
	 * @param response
	 * 
	 * @return ModelAndView
	 * */
	@RequestMapping(value = "/secure/informationTransfer.htm")
	public ModelAndView informationTransferMessages(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String auditAction = "";
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		String mesgId = request.getParameter("messageId");
		String actionDetails = request.getParameter("actionDetails");
		String transferStatus = request.getParameter("ts");

		if (StringUtils.isEmpty(mesgId)) {

			logger.error("ERROR: Empty ID, expecting param messageId");
			throw new ServletException(
					"ERROR: Empty ID, expecting param messageId");
		}

		try {

			MessageTO message = messageFacade.loadMessage(Long
					.parseLong(mesgId));

			if (user.isNITNorthLead() || user.isNITSouthLead()) {

				if (user.isNITNorthLead()) {
					message.setNitnLeadState(ECMSConstants.MESSAGE_STATE_READ);
				}
				if (user.isNITSouthLead()) {
					message.setNitsLeadState(ECMSConstants.MESSAGE_STATE_READ);
				}
			} else {
				if (message.getToStaffId().equalsIgnoreCase(user.getStaffId())) {
					message.setState(ECMSConstants.MESSAGE_STATE_READ);
				}
				if (message.getFromStaffId()
						.equalsIgnoreCase(user.getStaffId())) {
					message.setState(ECMSConstants.MESSAGE_STATE_READ);
				}
			}
			AuditFlowThread.set("Message Updated");
			message.setActionDetails(actionDetails);
			messageFacade.updateMessage(message, false);

			if (StringUtils.isNotEmpty(transferStatus)
					&& APPROVE.equalsIgnoreCase(transferStatus)) {
				// TODO : Updating Information Transfer in Message section ???
				Long caseTransHisoryId = caseFacade.updateInformationTransfer(
						message.getInformationId(), "approvalAccepted",
						message.getActionDetails());

				if (null != caseTransHisoryId) {

					if (caseFacade.prepareReplyMessages(message,
							"approvalAccepted", caseTransHisoryId)) {

						caseFacade
								.triggerTransferNotification(caseTransHisoryId);
						auditAction = "Information transfer approval message success";
					} else {

						auditAction = "Information transfer updation message failed";
					}
				} else {

					auditAction = "Information transfer reply message failed.";
				}
			}

			if (StringUtils.isNotEmpty(transferStatus)
					&& REJECT.equalsIgnoreCase(transferStatus)) {
				// TODO : Updating Information Transfer in Message section ???
				Long caseTransHisoryId = caseFacade.updateInformationTransfer(
						message.getInformationId(), "approvalRejected",
						message.getActionDetails());

				if (null != caseTransHisoryId) {

					if (caseFacade.prepareReplyMessages(message,
							"approvalRejected", caseTransHisoryId)) {

						auditAction = "Information transfer rejection message success";

					} else {
						auditAction = "Information transfer updation message failed";
					}
				} else {

					auditAction = "Information transfer reply message failed";
				}
			}

			createAudit(message, AuditLogService.UPDATE, auditAction, request,
					auditLogFacade);

		} catch (Exception e) {
			log.error("\n** ERROR: Information Transfer :" + e);
			throw new ServletException(e);
		}

		return getModelAndViewByParentFlow(request);

	}

	/**
	 * Helper method to return ModelAndView based on the parent page.
	 * 
	 * @param HttpServletRequest
	 * @return ModelAndView.
	 */
	private ModelAndView getModelAndViewByParentFlow(HttpServletRequest request) {

		Object parentObj = request.getSession().getAttribute(PARENT_PAGE);

		if (null == parentObj) {

			return new ModelAndView(new RedirectView("welcome.htm"));
		}
		ECMSConstants.MESSAGE_PARENT_FLOW page = (ECMSConstants.MESSAGE_PARENT_FLOW) parentObj;

		if (page.equals(ECMSConstants.MESSAGE_PARENT_FLOW.NEW)) {
			return new ModelAndView(new RedirectView("welcome.htm"));
		} else if (page.equals(ECMSConstants.MESSAGE_PARENT_FLOW.SENT)) {
			return new ModelAndView(new RedirectView("listsentmessages.htm"));
		} else if (page.equals(ECMSConstants.MESSAGE_PARENT_FLOW.READ)) {
			return new ModelAndView(new RedirectView("welcome.htm"));
		} else if (page.equals(ECMSConstants.MESSAGE_PARENT_FLOW.INFORMATION)) {
			return new ModelAndView(new RedirectView("listinfomessages.htm"));
		} else if (page.equals(ECMSConstants.MESSAGE_PARENT_FLOW.CASE)) {
			return new ModelAndView(new RedirectView("listcasemessages.htm"));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("ECMSConstants.MESSAGE_PARENT_FLOW PAGE=" + page);
		}

		return new ModelAndView(new RedirectView("welcome.htm"));
	}

	/**
	 * Setter for the Facade
	 * 
	 * @param messageFacade
	 */
	public void setMessageFacade(MessageService messageFacade) {
		this.messageFacade = messageFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

}
