package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppeal;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealView;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.dto.caseInfo.AppealHearingTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SubjectName;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealHearingTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealOutcomeTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealSanctionTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinarySanctionTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AppealHearingService;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.DisciplinarySanctionService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * Disciplinary Appeal Controller handles the requests for the Disciplinary
 * Sanction for a particular Case.
 * 
 */
@Controller
public class DisciplinaryAppealController extends BaseMultiActionController {

	@Autowired
	private DisciplinarySanctionService sanctionFacade;
	@Autowired
	private InformationGatherService informationGatherFacade;
	@Autowired
	private LookupViewService lookupViewFacade;
	@Autowired
	private AppealHearingService appealHearingFacade;

	static final String SHOW_DISCIPLINARY_SANCTIONS = "viewDisciplinarySanctions";

	static final String SHOW_DISCIPLINARY_APPEALS = "viewDisciplinaryAppeals";

	static final String SHOW_DISCIPLINARY_APPEAL_HEARINGS = "viewDisciplinaryAppealHearings";

	static final String ADD_DISCIPLINARY_APPEAL = "addDisciplinaryAppeal";

	static final String ADD_DISCIPLINARY_APPEAL_HEARING = "addDisciplinaryAppealHearing";

	static final String ADD_DISCIPLINARY_APPEAL_OUTCOME = "addDisciplinaryAppealOutcome";

	static final String DISCIPLINARY_HEARING_ID_PARAM = "hearingId";

	static final String DISCIPLINARY_HEARING_LIST_PAGE = "showDisciplinaryAppealHearings.htm";

	static final String SHOW_DISCIPLINARY_SANCTIONS_PAGE = "showDisciplinaryAppeals.htm";

	static final String PARENT_APPEAL_ID = "parentAppealId";

	static final String APPEAL_ID = "appealId";

	static final String SANCTION_ID = "sanctionId";

	static final String PARENT_APPEAL_TO = "parentAppealTO";

	private static final String COURT_APPEARANCES = "courtAppearances";

	protected final Log log = LogFactory.getLog(getClass());

	private AuditLogService auditLogFacade;

	/**
	 * Show Disciplinary Appeals.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showDisciplinaryAppeals.htm")
	public ModelAndView showDisciplinaryAppeals(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (log.isDebugEnabled()) {
			log.debug("showDisciplinaryAppeals");
		}
		Map<String, Object> sanctionMap = new HashMap<String, Object>();

		List<DisciplinaryAppealSanctionTO> appealSanctionList = null;

		try {

			String caseID = CaseUtil.getCaseId(request);

			if (StringUtils.isEmpty(caseID)) {

				CaseUtil.logErrorCaseIDNotFound(log);

				return CaseUtil.getCasePortalView();
			}

			Long caseIdL = new Long(caseID);

			appealSanctionList = sanctionFacade
					.getAppealAndSanctionList(caseIdL);

			// Convert DisciplinaryAppealView to DisciplinaryAppealTO list
			List<DisciplinaryAppealView> appealViewList = sanctionFacade
					.loadAppealViewListByCaseId(caseIdL);

			List<DisciplinaryAppealTO> appealTOList = CaseUtil
					.convertAppealViewToAppealTOList(appealViewList);

			if (null != appealTOList) {

				for (DisciplinaryAppealTO applTO : appealTOList) {

					Long appealId = applTO.getAppealId();

					List<DisciplinaryAppeal> dispList = sanctionFacade
							.loadAppealsByParentAppealId(appealId);
					applTO.setAppealExist(dispList != null
							&& dispList.size() > 0 ? true : false);

					DisciplinaryAppealOutcomeTO outcomeTO = sanctionFacade
							.loadAppealOutcomeByAppealId(appealId);
					applTO.setOutcomeDate(outcomeTO != null ? outcomeTO
							.getOutcomeDate() : null);
				}
			}
			sanctionMap.put(CaseUtil.DISCIPLINARY_APPEAL_SANCTIONS,
					appealSanctionList);

			sanctionMap.put(CaseUtil.DISCIPLINARY_APPEALS, appealTOList);
			sanctionMap.put(CaseUtil.DISCIPLINARY_APPEALS_LIST_SIZE,
					appealViewList.size());

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}
		return new ModelAndView(SHOW_DISCIPLINARY_APPEALS,
				CaseUtil.DISCIPLINARY_SANCTIONS_MAP, sanctionMap);

	}

	/**
	 * Disciplinary Sanction Details
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/disciplinaryAppealDetails.htm")
	public ModelAndView disciplinaryAppealDetails(HttpServletRequest request,
			HttpServletResponse response, DisciplinaryAppealTO appeal)
			throws ServletException {

		String caseID = null;
		boolean errors = false;

		DisciplinaryAppealTO parentAppealTO = null;
		InformationTO infoTO = null;

		List<SubjectName> subjectList = null;
		// Request: current Appeal is edited.
		String appealID = request.getParameter(CaseUtil.APPEAL_ID);
		// Request: New Appeal is created.
		String sanctionId = request.getParameter(SANCTION_ID);
		String parentAppealId = request.getParameter(PARENT_APPEAL_ID);

		Map<String, Object> sanctionMap = new HashMap<String, Object>();

		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			CaseUtil.logErrorCaseIDNotFound(log);
		}

		if (StringUtils.isEmpty(caseID)) {

			return showDisciplinaryAppeals(request, response);
		}
		Long caseIdL = new Long(caseID);

		if (appeal == null) {

			appeal = new DisciplinaryAppealTO();
		}

		appeal.setCaseId(caseIdL);

		//List<CaseContact> contactList = new ArrayList<CaseContact>();
		try {
			infoTO = informationGatherFacade.loadInformationByCaseId(caseIdL);

			// subjectList = getSubjectsFromInformation(infoTO);

			subjectList = CaseUtil.getAllSubjectList(infoTO);

			if (StringUtils.isNotEmpty(appealID)) {

				appeal = sanctionFacade.loadDisciplinaryAppeal(new Long(
						appealID));

				if (null != appeal) {

					appeal.setSubjectName(getSubjectName(subjectList,
							appeal.getParentSubjectId()));

					// Check if other subject is not empty.
					if (StringUtils.isEmpty(appeal.getSubjectName())
							&& StringUtils.isNotEmpty(appeal.getOtherSubject())) {

						if (log.isDebugEnabled()) {
							log.debug("setting others to appeal, other subject="
									+ appeal.getOtherSubject());
						}
						appeal.setSubjectName(appeal.getOtherSubject());
					}
				}
			}
			if (StringUtils.isNotEmpty(parentAppealId)) {

				parentAppealTO = sanctionFacade
						.loadDisciplinaryAppealByParentAppealId(new Long(
								parentAppealId));

				this.updateSubjectInParentAppeal(parentAppealTO, subjectList);

			} else if (StringUtils.isNotEmpty(sanctionId)) {

				parentAppealTO = sanctionFacade
						.loadDisciplinaryAppealByParentSanctionId(new Long(
								sanctionId));
				this.updateSubjectInParentAppeal(parentAppealTO, subjectList);
			}

			//contactList = sanctionFacade.loadContactsByCaseId(caseIdL);

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}
		if (StringUtils.isEmpty(appealID) && null == parentAppealTO) {

			log.error("PARENT APPEAL IS NULL !!!");
			errors = true;
			// No parent sanction or appeal exist.
			sanctionMap.put(ECMSConstants.ERROR_MESSAGES,
					"No Parent Sanction or Appeal Found !!!");
		}

		if (null == subjectList
				|| (null != subjectList && subjectList.isEmpty())) {

			log.error(ECMSConstants.NO_SUBJECTS);
			errors = true;
			// No subjects for this case.
			sanctionMap.put(ECMSConstants.ERROR_MESSAGES,
					ECMSConstants.NO_SUBJECTS);
		}

		if (errors) {

			return new ModelAndView(SHOW_DISCIPLINARY_SANCTIONS,
					CaseUtil.DISCIPLINARY_SANCTIONS_MAP, sanctionMap);

		}

		if (null != parentAppealTO) {
			appeal.setSubjectId(parentAppealTO.getSubjectId());
			appeal.setSubjectName(parentAppealTO.getSubjectName());
			appeal.setOrganisationName(parentAppealTO.getOrganisationName());
		}

		sanctionMap.put(CaseUtil.DISCIPLINARY_SANCTION, appeal);
		sanctionMap.put(PARENT_APPEAL_TO, parentAppealTO);

		sanctionMap.put(CaseUtil.SANCTION_SUBJECTS, subjectList);
		// sanctionMap.put(CaseUtil.CONTACT_LIST, contactList);

		return new ModelAndView(ADD_DISCIPLINARY_APPEAL,
				CaseUtil.DISCIPLINARY_SANCTION_MAP, sanctionMap);

	}

	private void updateSubjectInParentAppeal(DisciplinaryAppealTO parent,
			List<SubjectName> subjectList) {

		if (null != parent.getSubjectId() && parent.getSubjectId() > 0) {

			parent.setSubjectName(getSubjectName(subjectList,
					parent.getSubjectId()));

		} else if (StringUtils.isNotEmpty(parent.getOtherSubject())) {

			parent.setSubjectName(parent.getOtherSubject());
		}
	}

	private String getSubjectName(List<SubjectName> subjects, Long subjectId) {

		for (SubjectName sn : subjects) {

			if (null != subjectId && null != sn.getId()
					&& (subjectId.equals(sn.getId()))) {

				return sn.getTitle() + " " + sn.getFirstname() + " "
						+ sn.getLastname();
			}
		}
		return "";
	}

	/**
	 * Save Disciplinary Appeal.
	 * 
	 * @param request
	 * @param response
	 * @param dispTO
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveDisciplinaryAppeal.htm")
	public ModelAndView saveDisciplinaryAppeal(HttpServletRequest request,
			HttpServletResponse response, DisciplinaryAppealTO dispappTO)
			throws ServletException {

		BindException errors = null;

		String commaSepSubjectIds = request
				.getParameter("subjectIdSemiTypeName");

		try {
			errors = bindObject(request, dispappTO,
					new DisciplinarySanctionValidator());

			Long parentAppealId = dispappTO.getParentAppealId();
			Long sanctionId = dispappTO.getSanctionId();

			if ((parentAppealId == null || parentAppealId == 0)
					&& (sanctionId == null || sanctionId == 0)) {

				throw new Exception("No Previous Sanction/Appeal Details");
			}

			if (StringUtils.isNotEmpty(commaSepSubjectIds)) {

				if (!commaSepSubjectIds.equals("0")) {

					String[] idTypeArray = commaSepSubjectIds.split(";");

					dispappTO.setSubjectId(new Long(idTypeArray[0]));
					dispappTO.setSubjectType(idTypeArray[1]);

				} else {

					dispappTO.setSubjectId(new Long(0));
					dispappTO.setSubjectType("");
				}
			}
			//Appellant information
			String appealMaker = request.getParameter("appealMakerOther");
			setUpAppelant(dispappTO, appealMaker);

			if (null == dispappTO.getCaseId()) {

				String caseID = CaseUtil.getCaseId(request);
				dispappTO.setCaseId(new Long(caseID));
			}

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		if (null == dispappTO.getSanctionType()) {

			log.error("This Disciplinary Appeal has no sanctionType, so default to EXTERNAL.");

			dispappTO.setSanctionType("EXTERNAL");
		}

		if (null == dispappTO.getAppealId()) {

			AuditFlowThread.set("Disciplinary Appeal Created ");
			dispappTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId());
			dispappTO.setCreatedTime(new Date(System.currentTimeMillis()));
			dispappTO.setState(CaseUtil.ONGOING_STATUS);
		} else {

			AuditFlowThread.set("Disciplinary Appeal Updated ");
		}

		try {

			if (!errors.hasErrors()) {

				sanctionFacade.saveDisciplinaryAppeal(dispappTO);
				createAudit(dispappTO, AuditLogService.CREATE,
						AuditFlowThread.get(), request, auditLogFacade);
			}
		} catch (ServiceException se) {
			log.error(se);
			throw new ServletException(se);
		}

		return new ModelAndView(new RedirectView(
				SHOW_DISCIPLINARY_SANCTIONS_PAGE));
	}

	private void setUpAppelant(DisciplinaryAppealTO appealTO, String appellent) {

		if ("Other".equalsIgnoreCase(appellent)
				|| "Other".equalsIgnoreCase(appealTO.getAppealMaker())) {
			appealTO.setAppellantType("Other");
		} else {
			appellent = (appellent != null && !appellent.isEmpty()) ? appellent
					: appealTO.getAppealMaker();
			appealTO.setAppellantType(null);
		}
		appealTO.setAppealMaker(appellent);
	}

	/**
	 * Disciplinary Appeal Hearings
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showDisciplinaryAppealHearings.htm")
	public ModelAndView showDisciplinaryAppealHearings(
			HttpServletRequest request, HttpServletResponse response)
			throws ServletException {

		log.info("showDisciplinaryAppealHearings");

		List<DisciplinaryAppealHearing> list = new ArrayList<DisciplinaryAppealHearing>();

		String appealID = request.getParameter(CaseUtil.APPEAL_ID);

		try {

			if (StringUtils.isNotEmpty(appealID)) {

				list = sanctionFacade
						.loadDisciplinaryAppealHearingList(new Long(appealID));
			}

			Map<String, Object> hearingMap = new HashMap<String, Object>();
			hearingMap.put(CaseUtil.DISCIPLINARY_HEARINGS, list);
			hearingMap.put(CaseUtil.LIST_SIZE, list.size());
			hearingMap.put(CaseUtil.APPEAL_ID, appealID);

			return new ModelAndView(SHOW_DISCIPLINARY_APPEAL_HEARINGS,
					CaseUtil.DISCIPLINARY_HEARINGS_MAP, hearingMap);

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * Disciplinary Appeal Outcome
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showDisciplinaryAppealOutcome.htm")
	public ModelAndView showDisciplinaryAppealOutcome(
			HttpServletRequest request, HttpServletResponse response,
			DisciplinaryAppealTO dispTO) throws ServletException {

		log.info("showDisciplinaryAppealOutcome");

		DisciplinaryAppealOutcomeTO outcomeTO = null;

		String appealID = request.getParameter(CaseUtil.APPEAL_ID);

		DisciplinaryAppealTO appealTO = new DisciplinaryAppealTO();

		try {

			Long appealId = new Long(appealID);
			if (StringUtils.isNotEmpty(appealID)) {

				outcomeTO = sanctionFacade
						.loadAppealOutcomeByAppealId(appealId);

				if (outcomeTO == null) {
					outcomeTO = new DisciplinaryAppealOutcomeTO();
				}
				appealTO = sanctionFacade.loadDisciplinaryAppeal(appealId);

				outcomeTO.setAppealId(appealId);
				outcomeTO.setLookupImposedList(sanctionFacade
						.loadSanctionImposedTypes(appealTO.getSanctionType()));
				outcomeTO.setDispType(appealTO.getSanctionType());

				this.setAppealImposedList(outcomeTO);

				// Set the appealed date to outComeTO ???
				outcomeTO.setStartDate(appealTO.getAppealedDate());
				outcomeTO.setSanctionType(appealTO.getSanctionType());

			}

			Map<String, Object> sanctionMap = new HashMap<String, Object>();
			sanctionMap.put(CaseUtil.DISCIPLINARY_OUTCOME, outcomeTO);

			return new ModelAndView(ADD_DISCIPLINARY_APPEAL_OUTCOME,
					CaseUtil.DISCIPLINARY_OUTCOME_MAP, sanctionMap);

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * Disciplinary Appeal Hearing
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/disciplinaryAppealHearingDetails.htm")
	public ModelAndView disciplinaryAppealHearingDetails(
			HttpServletRequest request, HttpServletResponse response,
			DisciplinaryAppealHearingTO dispTO) throws ServletException {

		log.info("disciplinaryAppealHearingDetails");

		String appealID = request.getParameter(CaseUtil.APPEAL_ID);
		String hearingID = request.getParameter(DISCIPLINARY_HEARING_ID_PARAM);

		List<AppealHearingTO> appealHearingsList = null;
		String sanctionType = "External";

		try {

			if (StringUtils.isEmpty(hearingID)) {

				dispTO = new DisciplinaryAppealHearingTO();
			} else {
				dispTO = sanctionFacade.loadDisciplinaryAppealHearing(new Long(
						hearingID));
			}

			if (null == dispTO.getAppealId()
					&& StringUtils.isNotEmpty(appealID)) {

				dispTO.setAppealId(new Long(appealID));
			}

			if (null == dispTO.getAppealId()) {

				logger.error("Please provide a valid Appeal for DisciplinaryAppealHearing:"
						+ dispTO.toString());

				throw new ServletException("Please check for a valid appeal.");
			}

			DisciplinaryAppealTO appealTO = sanctionFacade
					.loadDisciplinaryAppeal(dispTO.getAppealId());

			appealHearingsList = appealHearingFacade
					.loadCourtAppearancesByType(dispTO.getAppealId(),
							CaseUtil.APPLIED_SANCTION_TYPE.DISCIPLINARY_APPEAL
									.toString());

			if ("INTERNAL".equalsIgnoreCase(appealTO.getSanctionType())) {
				sanctionType = "Internal";
				setupLookupMap(
						CaseUtil.getInternalDisciplinaryAppealHearingLookupGroups(),
						dispTO);
			} else if ("EXTERNAL".equalsIgnoreCase(appealTO.getSanctionType())) {
				sanctionType = "External";
				setupLookupMap(
						CaseUtil.getExternalDisciplinaryAppealHearingLookupGroups(),
						dispTO);
			}

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		Map<String, Object> sanctionMap = new HashMap<String, Object>();
		sanctionMap.put(CaseUtil.DISCIPLINARY_HEARING, dispTO);
		sanctionMap.put(COURT_APPEARANCES, appealHearingsList);
		sanctionMap.put("sanctionType", sanctionType);

		return new ModelAndView(ADD_DISCIPLINARY_APPEAL_HEARING,
				CaseUtil.DISCIPLINARY_HEARING_MAP, sanctionMap);
	}

	/**
	 * Setup Lookup mapping to AppealHearing.
	 * 
	 * @param groupNames
	 * @param dto
	 */
	private void setupLookupMap(String[] groupNames,
			DisciplinaryAppealHearingTO dto) {

		for (String groupName : groupNames) {

			List<LookupView> list = new ArrayList<LookupView>();

			if (null != groupName) {

				if (log.isDebugEnabled()) {
					log.debug("Lookup for groupName=" + groupName);
				}
				list = lookupViewFacade
						.loadByGroupAndOrderByLookupId(groupName);
			}

			dto.addLookupViewMap(groupName, list);
		}
	}

	/**
	 * Save Disciplinary Appeal Hearing.
	 * 
	 * @param request
	 * @param response
	 * @param dispTO
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveDisciplinaryAppealHearing.htm")
	public ModelAndView saveDisciplinaryAppealHearing(
			HttpServletRequest request, HttpServletResponse response,
			DisciplinaryAppealHearingTO dispTO) throws ServletException {

		log.info("saveDisciplinaryAppealHearing");

		BindException errors = null;

		try {
			errors = bindObject(request, dispTO,
					new DisciplinaryHearingValidator());

			if (dispTO.getHearingId() == null) {

				dispTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
						request.getSession()).getStaffId());
				dispTO.setCreatedTime(new Date(System.currentTimeMillis()));
			}

			if (!errors.hasErrors()) {

				AuditFlowThread.set("Disciplinary Appeal Hearing Created ");
				sanctionFacade.saveDisciplinaryAppealHearing(dispTO);
				createAudit(dispTO, AuditLogService.UPDATE,
						"Disciplinary Hearing", request, auditLogFacade);
			}

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(DISCIPLINARY_HEARING_LIST_PAGE
				+ "?appealId=" + dispTO.getAppealId()));
	}

	/**
	 * Save Disciplinary Appeal Outcome.
	 * 
	 * @param request
	 * @param response
	 * @param outcomeTO
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveDisciplinaryAppealOutcome.htm")
	public ModelAndView saveDisciplinaryAppealOutcome(
			HttpServletRequest request, HttpServletResponse response,
			DisciplinaryAppealOutcomeTO outcomeTO) throws ServletException {

		log.info("saveDisciplinaryAppealOutcome");

		final String sanctionType = request.getParameter("sanctionType");

		BindException errors = null;

		try {
			errors = bindObject(request, outcomeTO,
					new DisciplinaryOutcomeValidator());

			if (null == outcomeTO.getOutcomeId()) {

				outcomeTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
						request.getSession()).getStaffId());

				outcomeTO.setCreatedTime(new Date(System.currentTimeMillis()));
			}

			if (!errors.hasErrors()) {

				if (outcomeTO.getLookupImposedList() == null) {

					outcomeTO.setLookupImposedList(sanctionFacade
							.loadSanctionImposedTypes(sanctionType));
				}
				setAppliedAppealList(request, outcomeTO);
				AuditFlowThread.set("Disciplinary Appeal Outcome Created ");
				sanctionFacade.saveDisciplinaryAppealOutcome(outcomeTO);

				createAudit(outcomeTO, AuditLogService.UPDATE,
						"Disciplinary Appeal Outcome", request, auditLogFacade);
			}

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(
				SHOW_DISCIPLINARY_SANCTIONS_PAGE));
	}

	/**
	 * Delete Disciplinary Sanction Details
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/deleteDisciplinaryAppeal.htm")
	public ModelAndView deleteDisciplinaryAppeal(HttpServletRequest request,
			HttpServletResponse response, DisciplinarySanctionTO dispTO)
			throws ServletException {

		String appealId = request.getParameter(CaseUtil.APPEAL_ID);

		try {

			if (StringUtils.isNotEmpty(appealId)) {

				sanctionFacade.deleteDisciplinaryAppeal(new Long(appealId));

				createAudit(new String(" Delete DisciplinaryAppeal ID ="
						+ appealId), AuditLogService.DELETE,
						"Disciplinary Appeal", request, auditLogFacade);
			}

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return showDisciplinaryAppeals(request, response);
	}

	/**
	 * Delete Disciplinary Appeal Hearing
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/deleteDisciplinaryAppealHearing.htm")
	public ModelAndView deleteDisciplinaryAppealHearing(
			HttpServletRequest request, HttpServletResponse response,
			DisciplinaryAppealHearingTO dispTO) throws ServletException {

		log.info("deleteDisciplinaryAppealHearing");

		String dHID = request.getParameter(DISCIPLINARY_HEARING_ID_PARAM);
		String appealId = request.getParameter(APPEAL_ID);

		try {
			AuditFlowThread.set("Disciplinary Appeal Hearing Deleted ");
			if (!StringUtils.isEmpty(dHID)) {
				sanctionFacade.deleteDisciplinaryAppealHearing(new Long(dHID));

				createAudit(new String(
						"Delete DisciplinarySanction Hearing ID =" + dHID),
						AuditLogService.DELETE,
						"Disciplinary Sanction Hearing", request,
						auditLogFacade);
			}

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(DISCIPLINARY_HEARING_LIST_PAGE
				+ "?appealId=" + appealId));
	}

	/**
	 * Validating Disciplinary Sanctions.
	 * 
	 */
	class DisciplinarySanctionValidator implements Validator {

		public boolean supports(Class arg0) {
			// TODO Auto-generated method stub
			return false;
		}

		public void validate(Object arg0, Errors arg1) {
			// TODO Auto-generated method stub

		}
	}

	/**
	 * Validating Disciplinary hearings.
	 * 
	 */
	class DisciplinaryHearingValidator implements Validator {

		public boolean supports(Class arg0) {
			// TODO Auto-generated method stub
			return false;
		}

		public void validate(Object arg0, Errors arg1) {
			// TODO Auto-generated method stub

		}
	}

	/**
	 * Validating Disciplinary outcome.
	 * 
	 */
	class DisciplinaryOutcomeValidator implements Validator {

		public boolean supports(Class arg0) {
			// TODO Auto-generated method stub
			return false;
		}

		public void validate(Object arg0, Errors arg1) {
			// TODO Auto-generated method stub

		}
	}

	private void setAppealImposedList(DisciplinaryAppealOutcomeTO outcomeTO) {

		for (OutcomeAppliedSanction item : outcomeTO
				.getOutcomeAppliedSanctions()) {

			setSelectedListItem(item, outcomeTO.getLookupImposedList());
		}

	}

	private void setSelectedListItem(OutcomeAppliedSanction sanction,
			List<LookupView> list) {

		for (LookupView view : list) {

			if (null != view.getDescription()
					&& null != sanction.getAppliedSanction()
					&& view.getDescription().equalsIgnoreCase(
							sanction.getAppliedSanction())) {

				view.setSelected(true);

			}
		}
	}

	private void setAppliedAppealList(HttpServletRequest request,
			DisciplinaryAppealOutcomeTO outcomeTO) {

		List<OutcomeAppliedSanction> sanType = new ArrayList<OutcomeAppliedSanction>();

		if (null != outcomeTO.getLookupImposedList()) {
			for (int i = 0; i < outcomeTO.getLookupImposedList().size(); i++) {
				String param = "checkedappliedsanction" + (i);
				String value = "valueappliedsanction" + (i);

				if (request.getParameter(param) != null
						&& request.getParameter(param).equalsIgnoreCase("true")) {

					OutcomeAppliedSanction sanction = new OutcomeAppliedSanction();
					sanction.setOutcomeId(outcomeTO.getOutcomeId());
					sanction.setAppliedSanction(request.getParameter(value));
					sanction.setSanctionType("DISCIPLINARY_APPEAL");
					sanType.add(sanction);
				}
			}
		}

		outcomeTO.setOutcomeAppliedSanctions(sanType);
	}

	/**
	 * Setter for Disciplinary Sanction Facade
	 * 
	 * @param disciplinarySanctionFacade
	 */
	public void setSanctionFacade(DisciplinarySanctionService sanctionFacade) {

		this.sanctionFacade = sanctionFacade;
	}

	/**
	 * Setter for Information Gather Facade
	 * 
	 * @param sanctionFacade
	 */
	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
}
