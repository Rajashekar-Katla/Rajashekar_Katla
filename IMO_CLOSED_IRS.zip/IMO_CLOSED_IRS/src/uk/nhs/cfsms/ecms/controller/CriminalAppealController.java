package uk.nhs.cfsms.ecms.controller;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.sanction.AppealOutcome;
import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.dto.caseInfo.AppealHearingTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.AppealHearingCourtNameComparator;
import uk.nhs.cfsms.ecms.dto.criminalsanction.AppealOutcomeTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.AppealSanctionComparator;
import uk.nhs.cfsms.ecms.dto.criminalsanction.AppealSanctionTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CourtNameComparator;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalAppealSanctionTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalAppealTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalSanctionTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SanctionApplied;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SanctionOutcomeTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SubjectName;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SubjectInformationTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AppealHearingService;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CourtAppearanceService;
import uk.nhs.cfsms.ecms.service.CriminalAppealService;
import uk.nhs.cfsms.ecms.service.CriminalSanctionService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.ConvertToDTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * Criminal Appeal Controller handles the requests for the Criminal Appeals
 * for a particular Criminal Sanction Outcome.
 * 
 */
@Controller
public class CriminalAppealController extends BaseMultiActionController {

	@Autowired
	private CriminalAppealService criminalAppealFacade;
	@Autowired	
	private CriminalSanctionService criminalSanctionFacade;
	@Autowired
	private InformationGatherService informationGatherFacade;
	@Autowired	
	private CourtAppearanceService courtAppearanceFacade;
	@Autowired	
	private AppealHearingService appealHearingFacade;
	@Autowired
	private AuditLogService auditLogFacade;

	static final String SHOW_CRIMINAL_APPEALS_PAGE = "showCriminalAppeals.htm";

	static final String CRIMINAL_SANCTIONS_DETAILS_VIEW = "criminalSanctionsDetails";
	
	static final String CRIMINAL_APPEALS_DETAILS_VIEW = "criminalAppealsDetails";
	
	static final String ADD_CRIMINAL_APPEAL_VIEW = "criminalAppealInput";
	
	static final String CRIMINAL_APPEALS_VIEW = "viewCriminalAppeals";

	// Parameters  for Criminal Appeals.
	static final String APPEAL_PARAM = "criminalAppeal";
	static final String APPEALS_PARAM = "criminalAppeals";
	static final String APPEALS_SIZE_PARAM = "criminalAppealsSize";

	static final String SANCTION_SUBJECTS = "subjects";

	static final String APPEALS_MODEL_PARAM = "csModel";

	static final String APPEALS_MAP_PARAM = "criminalAppealsMap";
	
	static final String CRIMINAL_SANCTION_PARAM = "criminalSanction";	
    static final String CRIMINAL_SANCTIONS_PARAM = "criminalSanctions";
	static final String CRIMINAL_SANCTIONS_SIZE_PARAM = "criminalSanctionsSize";
	
	static final String PARENT_APPEAL_ID = "parentAppealId"; 
	
	static final String CRIMINAL_APPEAL_SANCTION = "criminalAppealSanctionTO";

	protected final Log log = LogFactory.getLog(getClass());



	/**
	 * Show Criminal Appeals and Sanctions related to this case, other than 'ONGOING'.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value ="/secure/showCriminalAppeals.htm")
	public ModelAndView showCriminalAppeals(
			HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map<String, Object> criminalSanctionsMap = new HashMap<String, Object>(); 
		List<AppealSanctionTO> appealSanctionList = new ArrayList<AppealSanctionTO>();
		
		try {
			String caseID = CaseUtil.getCaseId(request);
			
			Long caseIdL = new Long(caseID);

			List<CriminalAppealTO> appealsList = criminalAppealFacade.loadCriminalAppeals(caseIdL);
			
			List<CriminalSanctionTO> sanctionsList = criminalSanctionFacade.loadCriminalSanctions(caseIdL);
			
			List<SubjectName> subjects = getAllSubjects(caseID);

			for(CriminalAppealTO appealTO : appealsList) {
				
				if (logger.isDebugEnabled()) {
					logger.debug("LoadCriminalAppeals appealTO=" + appealTO);
				}
				updateAppealsList(appealSanctionList, subjects, appealTO);
			} 
			for (CriminalSanctionTO sanction : sanctionsList) {
				
				AppealSanctionTO appealSanctionTO = createAppealSanction(sanction);
                
				if (null != appealSanctionTO) {
				
					appealSanctionList.add(appealSanctionTO);
                }
			} 
			if (null != appealSanctionList && !appealSanctionList.isEmpty()) {
				
				Collections.sort(appealSanctionList, new AppealSanctionComparator());
			} 
			
			criminalSanctionsMap.put(APPEALS_PARAM, appealsList);
			criminalSanctionsMap.put(APPEALS_SIZE_PARAM, appealsList.size()); 
			
			request.setAttribute("appealSanctionList", appealSanctionList); 
			
		} catch (Exception se) {
			logger.error(se);
			throw new ServletException(se);
		}

		return new ModelAndView(CRIMINAL_APPEALS_VIEW, APPEALS_MAP_PARAM, criminalSanctionsMap);
	}

	/**
	 * Create Appeal Sanction from criminal sanction and include outcome & court appearance details. 
	 * @param sanction
	 * @return AppealSanctionTO
	 * @throws ServiceException
	 */
	private AppealSanctionTO createAppealSanction(CriminalSanctionTO sanction) throws ServiceException {
		
		AppealSanctionTO appealSanction = null;
		String appellant = "";
		try {
			Long sanctionId = sanction.getCriminalSanctionId();
			CriminalSanctionOutcome outcome = criminalSanctionFacade.loadCriminalSanctionOutcome(sanctionId);
			
			if (null != outcome  && null != outcome.getOutcomeId()) {
				
				List<CourtAppearance> courtAppearanceList = courtAppearanceFacade.loadCourtAppearancesBySanctionId(sanctionId);
				
				appealSanction = new AppealSanctionTO();
				appealSanction.setSanctionId(sanctionId);
				appealSanction.setSubject(getAllSubjects(sanction)); 
				appealSanction.setAppealExistsForTheCurrent(sanction.isAppealExists());
				
				if (null != courtAppearanceList && !courtAppearanceList.isEmpty()) {
					
					Collections.sort(courtAppearanceList, new CourtNameComparator());
					appealSanction.setProsecutingAuthority(courtAppearanceList.get(0).getCourtName());
				}
				appealSanction.setOutcomeDate(outcome.getOutcomeDate());
				
				String selectedSanctions = getAllSanctions(ConvertToDTO.getInstance().convertToDTO(outcome));
				appealSanction.setSelectedSanctions(selectedSanctions);
				//appellant = getAppellantBySanctionId(sanctionId);
				appealSanction.setAppellant(appellant);
				sanction.setOutcome(outcome); // ?
				sanction.setSelectedSanctions(selectedSanctions); //?
				
			}
		}catch (ServiceException se) {
			logger.error(se);
			throw se;
		}
		return appealSanction;
	}
	 
	/** 
	 * Creating two appeals List, criminalAppeals and AppealSanctions.
	 * @param criminalAppealList
	 * @param appealSanctionList
	 * @param subjects
	 * @param appealTO
	 * @throws ServiceException
	 */
	private void updateAppealsList(
			List<AppealSanctionTO> appealSanctionList, 
			List<SubjectName> subjects, 
			CriminalAppealTO appealTO) throws ServiceException {
		 
		Long appealId = appealTO.getAppealId();
		
		if (logger.isDebugEnabled()) {
			logger.debug("updateAppealsList for appealId =" + appealId);
		}
		try{
			AppealOutcome outcome = criminalAppealFacade.loadCriminalAppealOutcome(appealId);
			
			// Get matching subject name by appeal maker.
			String subjectName = getSubjectName(subjects, appealTO);
			appealTO.setSubject(subjectName);
		 
			/*	if (StringUtils.isEmpty(appealTO.getSubject())) {
				appealTO.setSubject(appealTO.getAppealMaker());
			}*/
			
			if (null != outcome && null != outcome.getOutcomeId()) {
	
				AppealSanctionTO appealSanction = new AppealSanctionTO();
				appealSanction.setAppealId(appealId);
				appealSanction.setSanctionId(appealTO.getSanctionId());
				appealSanction.setOutcomeDate(outcome.getOutcomeDate());
				
				appealSanction.setProsecutingAuthority(appealTO.getCourtMakingDecName()); 
				
				if (logger.isDebugEnabled()) {
					logger.debug("\n\n Appeal outcome =" + outcome);
				}
				String selectedSanctions = appendAllAppealOutcomeSanctions(ConvertToDTO.getInstance().convertToDTO(outcome));
				
				if (logger.isDebugEnabled()) {
					logger.debug("Appeal selected sanctions = " + selectedSanctions);
				}
				appealSanction.setSelectedSanctions(selectedSanctions);
				
				appealSanction.setAppealExistsForTheCurrent(appealTO.isAppealExist());
				// AppellantName is like the Name rather than appellant subject Id.
				appealSanction.setAppellant(appealTO.getAppellantName() != null ? appealTO.getAppellantName() : appealTO.getAppealMaker());
				// AppealOutcome.. 
				appealTO.setSelectedSanctions(selectedSanctions); // ?
				appealTO.setOutcome(outcome); // ? 
				 
				appealSanction.setSubject(subjectName);
				appealSanction.setOtherSubject(appealTO.getOtherSubject());
				
				appealSanctionList.add(appealSanction); 
			}
		}catch (ServiceException se) {
			logger.error(se);
			throw se;
		}
	}
	
	private String getAllSubjects(CriminalSanctionTO sanction) {
		
		String subjectStr = "";
		
		if (StringUtils.isNotEmpty(sanction.getNhsSubjectName())) {
			subjectStr = sanction.getNhsSubjectName();
		}
		if (StringUtils.isNotEmpty(sanction.getNonNhsSubjectName())) {

			if (StringUtils.isNotEmpty(subjectStr)) {
				subjectStr = subjectStr + "," + sanction.getNonNhsSubjectName();
			} else {
				subjectStr = sanction.getNonNhsSubjectName();
			} 
		}
		if (StringUtils.isNotEmpty(sanction.getPersonSubjectName())) {
			
			if (StringUtils.isNotEmpty(subjectStr)) {
				subjectStr = subjectStr + "," + sanction.getPersonSubjectName();
			}else{
				subjectStr = sanction.getPersonSubjectName();
			}
			
		}
		return subjectStr; 
	}


	private String getSubjectName(List<SubjectName> subjects, CriminalAppealTO appealTO) {
		
		String subjectId = "";
		
		if (null != appealTO && null != appealTO.getSanctionId() 
				&& appealTO.getSubjectId() > 0 ) {
			
			subjectId = appealTO.getSubjectId().toString();
		}
		if (StringUtils.isNotEmpty(subjectId)) {
			
			for (SubjectName sn : subjects) {
				
				if (null != sn.getId() && 
						StringUtils.equalsIgnoreCase(subjectId, sn.getId().toString())) {
					
					return sn.getFirstname()+" "+sn.getLastname();
				}
			}
			return appealTO.getOtherSubject();
		}
		return "";
	}


	/**
	 * Retrieve sanctionDetails for a criminal Sanction ID.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value ="/secure/appealDetails.htm")
	public ModelAndView sanctionDetails(
			HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map<String, Object> model = new HashMap<String, Object>();
		CriminalAppealTO appealTO = null;
		CriminalSanctionTO sanctionTO = null; 
		
		String caseId = null; 
		String appealId = request.getParameter(CaseUtil.APPEAL_ID);
		
		if (StringUtils.isEmpty(appealId)) {
			
			logger.error("No AppealId found!!!");
			throw new ServletException("Requested Appeal not found as ID is missing !!!");
		}
		Long appealIdL = new Long(appealId);
		try {
			caseId = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.error(e);
		}
		List<SubjectName> subjects = getAllSubjects(caseId);
 
		try {
			appealTO = criminalAppealFacade.loadCriminalAppeal(appealIdL);
			
			if (logger.isDebugEnabled()) {
				logger.debug("\n AppealTO =" + appealTO);
				logger.debug("\n Getting Parent Appeal/Sanction details");
			}			
			if (appealTO != null) {
				Long parentAppealId = appealTO.getParentAppealId();
				
				if (null != parentAppealId && parentAppealId > 0) {
					 
					CriminalAppealTO parentAppeal = criminalAppealFacade.loadCriminalAppeal(parentAppealId);

					if (null != parentAppeal) {
						 
						AppealOutcome outcome = criminalAppealFacade.loadCriminalAppealOutcome(parentAppealId);
						parentAppeal.setOutcome(outcome);
						if (logger.isDebugEnabled()) {
							logger.debug("\n Appeal outcome AppliedSanctions size =" + outcome.getOutcomeAppliedSanctions().size()); 
						}
						AppealOutcomeTO aodto = ConvertToDTO.getInstance().convertToDTO(outcome);
						if (logger.isDebugEnabled()) {
							logger.debug("\n AppealTO Outcome AppliedSanctions size =" + aodto.getOutcomeAppliedSanctions().size()); 
						}
						parentAppeal.setSelectedSanctions(getOutcomesImposed(aodto.getOutcomeAppliedSanctions()));
 
						parentAppeal.setSubject(getSubjectName(subjects, parentAppeal));
						 
						appealTO.setParentAppealTO(parentAppeal);
						
						appealTO.setAppealIsParent(true);
					}
					
				} else {
					Long sanctionId = appealTO.getSanctionId();
					
					sanctionTO = criminalSanctionFacade.getCriminalSanction(
							((sanctionId == null || sanctionId == 0) ? new Long(0) : sanctionId));
					
					if (null != sanctionTO) {
						
						appealTO.setParentSanctionTO(sanctionTO);
						appealTO.setAppealIsParent(false);
						
						CriminalSanctionOutcome outcome = criminalSanctionFacade.loadCriminalSanctionOutcome(sanctionId);
						sanctionTO.setOutcome(outcome);
						SanctionOutcomeTO dto = ConvertToDTO.getInstance().convertToDTO(outcome);
		 
						sanctionTO.setSelectedSanctions(getSanctionsImposed(dto.getSanctionsImposedList()));
						List<CourtAppearance> courtAppearanceList = courtAppearanceFacade.loadCourtAppearancesBySanctionId(sanctionId);
						
						if ( null != courtAppearanceList && !courtAppearanceList.isEmpty()) {
						
							Collections.sort(courtAppearanceList, new CourtNameComparator());
							sanctionTO.setCourtName(courtAppearanceList.get(0).getCourtName());
						}
					}
				}
			} 
		} catch (ServiceException se) {
			log.error(se);
			throw new ServletException(se);
		}

		if (null == appealTO.getCaseId()) {

			appealTO.setCaseId(new Long(caseId));
		} 

		Long appealCaseId = appealTO.getCaseId();

		if (null != appealCaseId && !StringUtils.equals(appealCaseId.toString(), caseId)) {

			String error = EcmsUtils.getSessionUserObject(request.getSession()).getStaffId() + 
					" creating Criminal Appeals for appealCaseId=" + 
					appealCaseId + ", rather than for caseId=" + caseId ;
			
			log.error(error);
			throw new ServletException(error);
		}

		model.put(APPEAL_PARAM, appealTO);
		model.put(SANCTION_SUBJECTS, subjects);
		model.put(CRIMINAL_SANCTION_PARAM, sanctionTO);

		return new ModelAndView(CRIMINAL_APPEALS_DETAILS_VIEW, APPEALS_MODEL_PARAM, model);
	}
	

	private String getSanctionsImposed(List<SanctionApplied> sIList) {
		
		String selectedSanctions = ""; 
		
		for (SanctionApplied sa:sIList) {
			
			if (sa.isChecked()) {
				selectedSanctions = selectedSanctions + sa.getSanctionName()+ ",";
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("\n***Selected Sanctions=" + selectedSanctions);
		}	
		if (StringUtils.isNotEmpty(selectedSanctions)) {
			
			selectedSanctions = selectedSanctions.substring(0,selectedSanctions.lastIndexOf(','));
		}
		
		return selectedSanctions;
	}

	private String getOutcomesImposed(List<OutcomeAppliedSanction> sIList) {
		
		String appliedSanctions = ""; 
		
		for (OutcomeAppliedSanction sa : sIList) {
			
			appliedSanctions = appliedSanctions + sa.getAppliedSanction()+ ",";
			 
		}
		if (logger.isDebugEnabled()) {
			logger.debug("\n***Selected appliedSanctions=" + appliedSanctions);
		}	
		if (StringUtils.isNotEmpty(appliedSanctions)) {
			
			appliedSanctions = appliedSanctions.substring(0,appliedSanctions.lastIndexOf(','));
		}
		
		return appliedSanctions;
	}

	/**
	 * criminalAppealInput is to add new criminal Appeal.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value ="/secure/criminalAppealInput.htm")
	public ModelAndView criminalAppealInput(
			HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String caseID = null;
		Map<String, Object> model = new HashMap<String, Object>();
		CriminalAppealTO appealTO = new CriminalAppealTO();
		CriminalAppealTO parentAppealTO = new CriminalAppealTO();
		CriminalSanctionTO csto = new CriminalSanctionTO();
		CriminalAppealSanctionTO appealSanction = new CriminalAppealSanctionTO();
		
		String cSID = request.getParameter(CaseUtil.SANCTION_ID_PARAM);
		String appealId = request.getParameter(CaseUtil.APPEAL_ID);
		String parentAppealId = request.getParameter(PARENT_APPEAL_ID);

		
		try {
			if (StringUtils.isNotEmpty(appealId)) {
				appealTO = criminalAppealFacade.loadCriminalAppeal(new Long(appealId));
			}		
			caseID = CaseUtil.getCaseId(request);
			
			if (StringUtils.isNotEmpty(parentAppealId)) {
				
				parentAppealTO = criminalAppealFacade.loadCriminalAppeal(new Long(parentAppealId));
				appealSanction.setSubjectId(parentAppealTO.getSubjectId());
				setParentAppealDetails(parentAppealId, appealSanction);
			}else{
				
				csto =  criminalSanctionFacade.getCriminalSanction(new Long(cSID));
				appealSanction.setSubjectId(csto.getSubjectId());
				updateAppealDetails(cSID, appealSanction);
			}
		 
		} catch (Exception se) {
			log.error(se);
			throw new ServletException(se);
		}
		List<SubjectName> subjects = getAllSubjects(caseID);

		if (null == subjects || (null != subjects && subjects.isEmpty())) {
			
			model.put(ECMSConstants.ERROR_MESSAGES, ECMSConstants.NO_SUBJECTS);		
			
			return new ModelAndView(CRIMINAL_APPEALS_VIEW, APPEALS_MAP_PARAM, model);
		}
		
		model.put(APPEAL_PARAM, appealTO);
		model.put(SANCTION_SUBJECTS, subjects);  
		model.put(CRIMINAL_APPEAL_SANCTION, appealSanction);
		return new ModelAndView(ADD_CRIMINAL_APPEAL_VIEW, APPEALS_MODEL_PARAM, model);	
	}

	/**
	 * Update Appeal Details.
	 * @param cSID
	 * @param appealSanctionTO
	 * @throws ServiceException
	 */
	private void updateAppealDetails(
				String cSID, 
				CriminalAppealSanctionTO appealSanctionTO)  throws ServiceException {
		
		Long sanctionId = new Long(cSID);
		appealSanctionTO.setSanctionId(sanctionId);
		
		try{
			CriminalSanctionOutcome outcome = criminalSanctionFacade.loadCriminalSanctionOutcome(sanctionId);

			if(outcome != null && outcome.getOutcomeDate() != null) {
				
				appealSanctionTO.setOutcomeDate(outcome.getOutcomeDate());
			}
			SanctionOutcomeTO dto = ConvertToDTO.getInstance().convertToDTO(outcome);
			appealSanctionTO.setSelectedSanctions(getAllSanctions(dto));
		}catch (ServiceException se) {
			log.error(se);
			throw se;
		}
	}
	
	private void setParentAppealDetails(
			String parentAppealId, 
			CriminalAppealSanctionTO criminalAppealSanctionTO) {
		
		Long parentAppealIdL = new Long(parentAppealId);
		
		List<AppealHearingTO> appealHearingsList;	 
		criminalAppealSanctionTO.setAppealId(parentAppealIdL);
		try{
			AppealOutcome outcome = criminalAppealFacade.loadCriminalAppealOutcome(parentAppealIdL);
			
			appealHearingsList = appealHearingFacade.loadCourtAppearancesByType(
					parentAppealIdL, 
					CaseUtil.APPLIED_SANCTION_TYPE.CRIMINAL_APPEAL.toString());
			
			if (appealHearingsList != null && !appealHearingsList.isEmpty()){
				
				Collections.sort(appealHearingsList, new AppealHearingCourtNameComparator());
				
				criminalAppealSanctionTO.setCourtName(appealHearingsList.get(0).getCourtName());
			}
			if (outcome != null && outcome.getOutcomeDate() != null){
	
				criminalAppealSanctionTO.setOutcomeDate(outcome.getOutcomeDate());
			}
			AppealOutcomeTO appealOutcome = ConvertToDTO.getInstance().convertToDTO(outcome);
			
			criminalAppealSanctionTO.setSelectedSanctions(appendAllAppealOutcomeSanctions(appealOutcome));
			
		}catch (ServiceException se) {
			log.error(se);
		}
	}
	
	private String getAllSanctions(SanctionOutcomeTO sanctionOutcome) {
		
		List<SanctionApplied> sanctionImposedList = sanctionOutcome.getSanctionsImposedList();
		List<SanctionApplied> unsuccessSanctionImposedList = sanctionOutcome.getUnsuccessSanctionsImposedList();
		
		return appendAllSanctions(sanctionImposedList, unsuccessSanctionImposedList);
	}


	private String appendAllAppealOutcomeSanctions(AppealOutcomeTO outcomeTO) {
		
		String selectedSanctions = "";
	 
		for (OutcomeAppliedSanction sanction : outcomeTO.getOutcomeAppliedSanctions()) {
			 
			selectedSanctions = selectedSanctions + sanction.getAppliedSanction()+ ",";
			
		}
		if (StringUtils.isNotEmpty(selectedSanctions)) {
			
			selectedSanctions = selectedSanctions.substring(0,selectedSanctions.lastIndexOf(','));
		}
		return selectedSanctions; 
	}


	private String appendAllSanctions(
			List<SanctionApplied> sanctionImposedList,
			List<SanctionApplied> unsuccessSanctionImposedList) {
		
		String selectedSanctions = "";
		
		for (SanctionApplied sa:sanctionImposedList){
		 	if (sa.isChecked()) {
				
				selectedSanctions = selectedSanctions + sa.getSanctionName()+ ",";
			}
		}
		if (StringUtils.isNotEmpty(selectedSanctions)) {
			
			selectedSanctions = selectedSanctions.substring(0,selectedSanctions.lastIndexOf(','));
		
		} else {
		
			for (SanctionApplied sa:unsuccessSanctionImposedList) {
				if (sa.isChecked()) {
					selectedSanctions = selectedSanctions + sa.getSanctionName()+ ",";
				}
			}
			if (StringUtils.isNotEmpty(selectedSanctions)) {
				selectedSanctions = selectedSanctions.substring(0,selectedSanctions.lastIndexOf(','));
			}
		}
		return selectedSanctions;
	}



	/**
	 * Get All Subject List for a given caseId.
	 * @param caseId
	 * @return
	 */
	private List<SubjectName> getAllSubjects(String caseId) {

		InformationTO infoTO = informationGatherFacade.loadInformationByCaseId(new Long(caseId));

		//return EcmsUtils.getInformationSubjectList(infoTO);
		 
		List<SubjectName> subjects = new ArrayList<SubjectName>();
		
        if(infoTO != null) {
        	
			List<SubjectInformationTO> personSubjects = infoTO.getSubjectInfoList();
			
			for (int i = 0; i < personSubjects.size(); i++) {
			
				SubjectInformationTO si = personSubjects.get(i);
				
				SubjectName sn = new SubjectName();
				sn.setFirstname(si.getSubjectPersonTO().getFirstName());
				sn.setLastname(si.getSubjectPersonTO().getLastName());
				sn.setSubjectType(CaseUtil.SubjectType.PERSON.toString());
				sn.setId(si.getSubjectId());
				subjects.add(sn);
			}
        }
        
		return subjects;		
	}

	
	/**
	 * Save Criminal Appeal
	 * 
	 * @param request
	 * @param response
	 * @param CriminalAppealTO
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value ="/secure/saveCriminalAppeal.htm")
	public ModelAndView saveCriminalAppeal(HttpServletRequest request,
			HttpServletResponse response, CriminalAppealTO dto)
			throws ServletException {
 
		if (logger.isDebugEnabled()) {
			logger.debug("\n\nCriminalAppealTO =" + dto.toString());
		}
 
		int count = 0;
		
		String appealMakerOther = request.getParameter("appealMakerOther");
		
		if ((null != dto.getSanctionId() && dto.getSanctionId() > 0) || 
				(null != dto.getParentAppealId() && dto.getParentAppealId() > 0)) {
		
			count++; 
		}
		 
		if (StringUtils.isNotEmpty(appealMakerOther)) {
			dto.setAppealMaker(appealMakerOther);
		} 
        
		try {

			if (null == dto.getAppealId()) {
				if (count == 0) {
			       throw new ServletException("No Previous Sanction/Appeal Details");		
				}
				AuditFlowThread.set("Criminal Appeal Created");
				dto.setCreatedStaffId(EcmsUtils.getSessionUserObject(request.getSession()).getStaffId());
				dto.setCreatedTime(new Date(System.currentTimeMillis()));
				dto.setState(CaseUtil.ONGOING_STATUS);
			} else {
				AuditFlowThread.set("Criminal Appeal Updated");
			}
			
			criminalAppealFacade.saveAppeal(dto);
			
			createAudit(dto, AuditLogService.UPDATE, "Criminal Appeal",	request, auditLogFacade);
		
		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(SHOW_CRIMINAL_APPEALS_PAGE));

	}

	/**
	 * Delete Criminal Appeal
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value ="/secure/deleteCriminalAppeal.htm")
	public ModelAndView deleteCriminalAppeal(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String cSID = request.getParameter(CaseUtil.SANCTION_ID_PARAM);
  
		try {

			AuditFlowThread.set("Criminal Appeal Deleted");
			
			criminalAppealFacade.deleteAppeal(new Long(cSID));
			
			createAudit(cSID, AuditLogService.DELETE, "Delete Criminal Appeal with appealId ", request, auditLogFacade);
			
		} catch (ServiceException se) {
			log.error(se);
			throw new ServletException(se);
		}

		return new ModelAndView(new RedirectView(SHOW_CRIMINAL_APPEALS_PAGE));
	}
	
	
	/**
	 * Setters for the Appeals Facade.
	 * 
	 * @param criminalAppealFacade
	 */
	public void setCriminalAppealFacade(
			CriminalAppealService criminalAppealFacade) {
		
		this.criminalAppealFacade = criminalAppealFacade;
	}

	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		
		this.informationGatherFacade = informationGatherFacade;
	}	

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
	
	public void setCriminalSanctionFacade(
			CriminalSanctionService criminalSanctionFacade) {
		this.criminalSanctionFacade = criminalSanctionFacade;
	}
	
	public void setCourtAppearanceFacade(
			CourtAppearanceService courtAppearanceFacade) {
		this.courtAppearanceFacade = courtAppearanceFacade;
	}
	
	public void setAppealHearingFacade(
			AppealHearingService appealHearingFacade) {
		this.appealHearingFacade = appealHearingFacade;
	}
}
