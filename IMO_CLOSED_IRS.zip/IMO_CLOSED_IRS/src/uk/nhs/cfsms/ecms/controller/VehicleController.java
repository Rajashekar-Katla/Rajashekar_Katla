package uk.nhs.cfsms.ecms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.Vehicle;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.VehicleService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
public class VehicleController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private VehicleService vehicleFacade;

	@RequestMapping(value ="/secure/showVehicles.htm")
	public ModelAndView showVehicles(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map<String, Object> vehiclesMap = new HashMap<String, Object>();
		try {
			String caseID = CaseUtil.getCaseId(request);
			Long caseIDLong = new Long(caseID);
			List<Vehicle> vehicles = vehicleFacade.loadVehicles(caseIDLong);
			vehiclesMap.put("vehiclesSize", vehicles.size());
			vehiclesMap.put("vehicles", vehicles);
			vehiclesMap.put("caseID", caseID);
			return new ModelAndView("showVehicles", "vehiclesMap", vehiclesMap);

		} catch (CaseIDNotFoundException cnfe) {
			log.error("Exception caught while listing vehicles", cnfe);
			throw new ServletException(cnfe);
		}

	}

	@RequestMapping(value ="/secure/deleteVehicle.htm")
	public ModelAndView deleteVehicle(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String vehicleId = request.getParameter("vehicleId");
		Vehicle v = new Vehicle();
		v.setVehicleId(new Long(vehicleId));
		try {
			AuditFlowThread.set("Vehicle Deleted");
			vehicleFacade.deleteVehicle(v);
			createAudit(v, AuditLogService.DELETE, "Vehicle", request,
					auditLogFacade);
		} catch (Exception e) {
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView("showVehicles.htm"));

	}

	@RequestMapping(value ="/secure/showVehicle.htm")
	public ModelAndView showVehicle(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String vehicleID = request.getParameter("vehicleID");
		Vehicle v = new Vehicle();
		try {
			if (vehicleID != null) {
				
				v = (Vehicle) vehicleFacade.getVehicle(new Long(vehicleID));
			}
		} catch (Exception se) {
			throw new ServletException(se);
		}

		return new ModelAndView("editVehicle", "vehicle", v);

	}
	
	@RequestMapping(value ="/secure/saveVehicle.htm")
	public ModelAndView saveVehicle(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Vehicle vehicle = new Vehicle();

		// apply binder to custom target object
		ServletRequestDataBinder binder = new ServletRequestDataBinder(vehicle);

		// trigger actual binding of request parameters
		binder.bind(request);
		try {
			if (vehicle.getVehicleId() == null || vehicle.getVehicleId() == 0l) {
				AuditFlowThread.set("Vehicle Created");
			} else {
				AuditFlowThread.set("Vehicle Updated");
			}
			vehicleFacade.saveVehicle(vehicle);
			createAudit(vehicle, AuditLogService.UPDATE, "Vehicle", request,
					auditLogFacade);

		} catch (Exception se) {
			log.error(se);
			throw new ServletException(se);
		}

		return new ModelAndView(new RedirectView("showVehicles.htm"));
	}

	/**
	 * @param vehicleFacade
	 *            The vehicleFacade to set.
	 */
	public void setVehicleFacade(VehicleService vehicleFacade) {
		this.vehicleFacade = vehicleFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
