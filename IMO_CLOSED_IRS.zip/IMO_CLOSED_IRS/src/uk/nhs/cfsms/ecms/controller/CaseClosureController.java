package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionTO;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.fpureport.FpuReport;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseClosureTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalSanctionTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinarySanctionTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.CivilSanctionService;
import uk.nhs.cfsms.ecms.service.CriminalSanctionService;
import uk.nhs.cfsms.ecms.service.DisciplinarySanctionService;
import uk.nhs.cfsms.ecms.service.MessageService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
public class CaseClosureController extends BaseBinderConfig {

	protected final Log log = LogFactory.getLog(CaseClosureController.class);

	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CaseService caseFacade;
	@Autowired
	private MessageService messageFacade;

	@Autowired
	private CivilSanctionService civilSanctionFacade;
	@Autowired
	private CriminalSanctionService criminalSanctionFacade;
	@Autowired
	private DisciplinarySanctionService disciplinarySanctionFacade;

	public static final String CLOSURE_MESSAGE = "Approve Case Closure";

	@RequestMapping(value = "/secure/caseclosure.htm", params = { "hiddenId" })
	public ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, CaseClosureTO closureTO,
			BindingResult errors) throws Exception {
		if (logger.isInfoEnabled()) {
			logger.info("onSubmit");
		}

		String caseId = CaseUtil.getCaseId(request);

		if (!EcmsUtils.onSaveDraft(request)
				&& !checkFPUReport(new Long(caseId))) {

			return new ModelAndView("nofpureport");
		}

		if (EcmsUtils.onSave(request) || EcmsUtils.onSaveDraft(request)) {

			SessionUser user = EcmsUtils.getSessionUserObject(request
					.getSession());
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			MultipartFile multipartFile = multipartRequest
					.getFile("closureReport");
			closureTO.setCreatedStaffId(user.getStaffId());
			closureTO.setCreatedDate(new Date());

			if (null != multipartFile) {

				closureTO.setClosureReportFileName(multipartFile
						.getOriginalFilename());
				closureTO.setClosureReportFileType(multipartFile
						.getContentType());
			}
			if (EcmsUtils.onSave(request)) {
				AuditFlowThread.set("Closing Case");
			} else {
				AuditFlowThread.set("Updating Case Closure details");
			}

			if (EcmsUtils.onSave(request)) {
				// Saving Case Closure.
				caseFacade.saveCaseClosure(closureTO);

				createAudit(closureTO, AuditLogService.UPDATE,
						"Case Closure details", request, auditLogFacade);

				if (user.isUserNotTeamManager()) {

					if (log.isDebugEnabled()) {

						log.debug("\n Creating Case closure message by staff ID="
								+ (user != null ? user.getStaffId()
										: "Unknown Staff")
								+ ",caseId="
								+ caseId);
					}
					//Send Message..
					createCaseClosureMessage(closureTO, request);
				}
				if (closureTO.getCaseClosureId() != null
						&& !EcmsUtils.onSaveDraft(request)) {

					return new ModelAndView("caseclosuresuccess");
				}
			} else {
				// Saving Case Closure.
				caseFacade.saveCaseClosureOnly(closureTO);

				// Still in draft stage, no messaging...
				createAudit(closureTO, AuditLogService.UPDATE,
						"Case Closure details", request, auditLogFacade);

				return new ModelAndView(new RedirectView(
						CaseUtil.SHOW_CASE_PAGE + caseId));
			}

		} else if (EcmsUtils.onCancelPage(request)) {

			return new ModelAndView(new RedirectView(CaseUtil.SHOW_CASE_PAGE
					+ caseId));
		}
		if (EcmsUtils.onClose(request)) {
			//TODO: 
		}
		return new ModelAndView("caseclosure", "closureObject", closureTO);
	}

	private void createCaseClosureMessage(CaseClosureTO closureTO,
			HttpServletRequest request) throws Exception {

		Long caseId = closureTO.getCaseId();
		if (null == caseId) {
			caseId = new Long(CaseUtil.getCaseId(request));
		}
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		String message = (null != closureTO
				&& StringUtils.isEmpty(closureTO.getComments()) ? CLOSURE_MESSAGE
				: closureTO.getComments());
		MessageTO messageTO = new MessageTO();
		messageTO.setMessage(message);
		messageTO.setCaseId(caseId);
		messageTO.setMessageType(MessageTO.Message_types.CASE_CLOSURE
				.toString());
		messageTO.setCreatedStaffId(user.getStaffId());
		messageTO.setFromStaffId(user.getStaffId());
		messageTO.setFromStaffName(user.getFullName());
		messageTO.setCreatedTime(new Date());
		UserObject ofmObj = caseFacade.getOwnerDetailsBycaseId(caseId);
		if (null != ofmObj) {
			messageTO.setToStaffId(ofmObj.getStaffId());
			messageTO.setToStaffName(EcmsUtils.getFullName(ofmObj));
		} else {
			log.error("Case Closure Message: No AAFS/OFM found, CaseID="
					+ (caseId != null ? caseId.toString() : "caseId Unknown"));
			log.error("From StaffID="
					+ (user != null ? user.getStaffId() : "StaffId Unknown"));
		}

		messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
		messageTO = messageFacade.saveMessage(messageTO);
		createAudit(messageTO, AuditLogService.UPDATE, "Adding Message",
				request, auditLogFacade);

	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	public ModelAndView showCaseClosure(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		try {
			String caseId = CaseUtil.getCaseId(request);
			CaseClosureTO closureTO = caseFacade
					.loadCaseClosureByCaseId(new Long(caseId));
			closureTO.setCaseId(new Long(caseId));

			return new ModelAndView("caseclosure", "closureObject", closureTO);
		} catch (CaseIDNotFoundException cnfe) {
			throw new ServletException(cnfe);
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

	@RequestMapping(value = "/secure/caseclosure.htm", params = { "!hiddenId" })
	public ModelAndView formBackingObject(HttpServletRequest request)
			throws ServletException {

		if (logger.isInfoEnabled()) {
			logger.info("formBackingObject().");
		}
		CaseClosureTO closureTO = new CaseClosureTO();
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		try {
			closureTO = caseFacade.loadCaseClosureByCaseId(new Long(caseID));
			closureTO.setCategoryList(caseFacade.loadCaseClosureTypes());
			closureTO.setNewCategoryPart1List(caseFacade
					.loadNewCaseClosurePart1Types());
			closureTO.setNewCategoryPart2List(caseFacade
					.loadNewCaseClosurePart2Types());
			// Fix: 19/03/14, With out the below If condition check, there will be not accurate data in the view.
			// This ignores updating sanction outcome numbers for closed cases (Prior to 17/02/14, there was no check). 
			CaseTO actCase = caseFacade.loadCase(new Long(caseID));
			if (!ECMSConstants.CASE_CLOSED.equalsIgnoreCase(actCase.getState())) {
				if (logger.isInfoEnabled()) {
					logger.info("\n*** updateSanctionOutcomeStats()....");
				}
				updateSanctionOutcomeStats(closureTO, caseID);
			}

		} catch (ServiceException e) {
			log.error(e);
		}

		return new ModelAndView("caseclosure", "closureObject", closureTO);
	}

	/**
	 * This method is responsible for updating the sanction outcome stats for
	 * the case closure.
	 * 
	 * @param CaseClosureTO
	 * @param caseID
	 * 
	 * **/
	private void updateSanctionOutcomeStats(CaseClosureTO closureTO,
			String caseID) {
		/**
		 * Fetching Successful/Unsuccessful Civil,Criminal and Disciplinary
		 * Outcomes for the given case ID.
		 * */
		try {
			ArrayList<CivilSanctionTO> civilSanctions = (ArrayList<CivilSanctionTO>) this.civilSanctionFacade
					.loadCivilSanctions(new Long(caseID));
			int successCount = 0;
			int unSuccessCount = 0;
			for (CivilSanctionTO cst : civilSanctions) {
				if (StringUtils.equalsIgnoreCase(cst.getState(), "SUCCESSFUL"))
					successCount++;
				else if (StringUtils.equalsIgnoreCase(cst.getState(),
						"UNSUCCESSFUL"))
					unSuccessCount++;
			}
			closureTO.setNoOfSanctionsCateg2_1(successCount);
			closureTO.setNoOfSanctionsCateg2_6(unSuccessCount);

			civilSanctions = null;
			successCount = 0;
			unSuccessCount = 0;

			ArrayList<CriminalSanctionTO> criminalSanctions = (ArrayList<CriminalSanctionTO>) this.criminalSanctionFacade
					.loadCriminalSanctions(new Long(caseID));
			for (CriminalSanctionTO cst : criminalSanctions) {
				if (StringUtils.equalsIgnoreCase(cst.getState(), "SUCCESSFUL"))
					successCount++;
				else if (StringUtils.equalsIgnoreCase(cst.getState(),
						"UNSUCCESSFUL"))
					unSuccessCount++;
			}
			closureTO.setNoOfSanctionsCateg2_2(successCount);
			closureTO.setNoOfSanctionsCateg2_7(unSuccessCount);

			criminalSanctions = null;
			successCount = 0;
			unSuccessCount = 0;
			int extSuccessCount = 0;
			int extUnSuccessCount = 0;
			ArrayList<DisciplinarySanctionTO> disciplinarySanctions = (ArrayList<DisciplinarySanctionTO>) this.disciplinarySanctionFacade
					.loadSanctionsByCaseId(new Long(caseID));
			for (DisciplinarySanctionTO dst : disciplinarySanctions) {
				if (StringUtils.equalsIgnoreCase(dst.getSanctionType(),
						"INTERNAL")
						&& StringUtils.equalsIgnoreCase(dst.getState(),
								"SUCCESSFUL"))
					successCount++;
				else if (StringUtils.equalsIgnoreCase(dst.getSanctionType(),
						"INTERNAL")
						&& StringUtils.equalsIgnoreCase(dst.getState(),
								"UNSUCCESSFUL"))
					unSuccessCount++;
				if (StringUtils.equalsIgnoreCase(dst.getSanctionType(),
						"EXTERNAL")
						&& StringUtils.equalsIgnoreCase(dst.getState(),
								"SUCCESSFUL"))
					extSuccessCount++;
				else if (StringUtils.equalsIgnoreCase(dst.getSanctionType(),
						"EXTERNAL")
						&& StringUtils.equalsIgnoreCase(dst.getState(),
								"UNSUCCESSFUL"))
					extUnSuccessCount++;
			}
			closureTO.setNoOfSanctionsCateg2_3(successCount);
			closureTO.setNoOfSanctionsCateg2_10(extSuccessCount);
			closureTO.setNoOfSanctionsCateg2_8(unSuccessCount);
			closureTO.setNoOfSanctionsCateg2_11(extUnSuccessCount);
			disciplinarySanctions = null;
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
		}
	}

	/**
	 * Check FPU Report
	 * 
	 * @param caseId
	 * @return boolean.
	 * @throws ServletException
	 */
	private boolean checkFPUReport(Long caseId) throws ServletException {
		try {
			FpuReport fpuRep = caseFacade.loadFpuReportByCaseId(caseId);
			if (null != fpuRep && fpuRep.getCaseId() != null)
				return true;
			else
				return false;
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

	/**
	 * Setter method for the case facade
	 * 
	 * @param caseFacade
	 */
	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public void setMessageFacade(MessageService messageFacade) {
		this.messageFacade = messageFacade;
	}

	/**
	 * @param civilSanctionFacade
	 */
	public void setCivilSanctionFacade(CivilSanctionService civilSanctionFacade) {
		this.civilSanctionFacade = civilSanctionFacade;
	}

	/**
	 * @param criminalSanctionFacade
	 */
	public void setCriminalSanctionFacade(
			CriminalSanctionService criminalSanctionFacade) {
		this.criminalSanctionFacade = criminalSanctionFacade;
	}

	/**
	 * @param disciplinarySanctionFacade
	 */
	public void setDisciplinarySanctionFacade(
			DisciplinarySanctionService disciplinarySanctionFacade) {
		this.disciplinarySanctionFacade = disciplinarySanctionFacade;
	}

}
