package uk.nhs.cfsms.ecms.controller;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindException;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationProgressTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.InformationProgressService;
import uk.nhs.cfsms.ecms.service.TransformService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.xml.InformationProgressSheetXMLCreator;

@Controller
public class InformationProgressController extends BaseMultiActionController {

	private static final String DD_MM_YYYY = "dd/MM/yyyy";

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		final SimpleDateFormat dateFormat = new SimpleDateFormat(DD_MM_YYYY);
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(
				dateFormat, true));
	}

	private static final String PDF = "pdf";

	@Autowired
	private AuditLogService auditLogFacade;

	@Autowired
	private InformationProgressService informationProgressFacade;

	@Autowired
	private TransformService transformService;

	/**
	 * Update Information Progress.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @return
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/secure/saveInformationProgress.htm")
	public ResponseEntity<String> saveInformationProgress(
			HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute InformationProgressTO informationProgressTO)
			throws Exception {

		ResponseEntity<String> responseEntity = null;
		final HttpHeaders httpsHeaders = new HttpHeaders();
		final SessionUser user = EcmsUtils.getSessionUserObject(request
				.getSession());
		final Long informationId = informationProgressTO.getInformationId();
		final Long informationProgressId = informationProgressTO
				.getInformationProgressId();
		try {

			if (informationProgressId == null) {
				final Long generatedNo = informationProgressFacade
						.generateMinuteNumber(informationId);
				informationProgressTO.setCreatedTime(new Date());
				informationProgressTO
						.setMinuteNumber(null == generatedNo ? null
								: generatedNo);
				informationProgressTO.setCreatedStaffId(user.getStaffId());
				AuditFlowThread.set("Information Progress Created");
			} else {
				AuditFlowThread.set("Information Progress Updated");
			}

			informationProgressFacade
					.saveInformationProgress(informationProgressTO);

			createAudit(informationProgressTO, AuditLogService.CREATE,
					"Information Progress", request, auditLogFacade);
			httpsHeaders.set("redirect",
					"/secure/information.htm?dispatch=query&actionType=showInfo&infoId="
							+ informationId);
			responseEntity = new ResponseEntity<String>(httpsHeaders,
					HttpStatus.CREATED);
		} catch (ServiceException e) {
			log.error(e.getMessage());
			httpsHeaders.set("error", Arrays.toString(e.getStackTrace()));
			responseEntity = new ResponseEntity<String>(httpsHeaders,
					HttpStatus.BAD_REQUEST);
			throw new ServiceException(
					"Exception Generating Progress Minute Number for Information");
		} catch (Exception e) {
			log.error(e.getMessage());
			httpsHeaders.set("error", Arrays.toString(e.getStackTrace()));
			responseEntity = new ResponseEntity<String>(httpsHeaders,
					HttpStatus.BAD_REQUEST);
			throw new ServletException("Exception Saving Information Progress.");
		}

		return responseEntity;
	}

	/**
	 * View all case progress sheets based on sensitivity and order by
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 * @throws NumberFormatException
	 */
	@RequestMapping(value = "/secure/viewAllInformationProgressSheets.htm")
	public ModelAndView viewAllInformationProgressSheets(
			HttpServletRequest request, HttpServletResponse response,
			@RequestParam("infoId") String infoId) throws ServletException,
			NumberFormatException, IllegalAccessException,
			InvocationTargetException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **viewAllInformationProgressSheets");
		}
		List<InformationProgressTO> progressList = new ArrayList<InformationProgressTO>();
		Map<String, Object> informationProgressMap = new HashMap<String, Object>();

		try {
			progressList = informationProgressFacade
					.loadInformationProgresses(new Long(infoId));
		} catch (ServiceException e) {
			log.error(e.getMessage());
			throw new ServletException(
					"Exception Loading Information Progress List for Information");
		}
		Collections.sort(progressList, new ProgressSheetComparator());
		informationProgressMap.put("infoId", infoId);
		informationProgressMap.put("informationProgressSheets", progressList);

		return new ModelAndView("viewAllInformationProgresses",
				"informationProgressMap", informationProgressMap);
	}

	@RequestMapping(value = "/secure/informationProgressSheetReport.htm")
	public ModelAndView informationProgressSheetReport(
			@RequestParam(value = PDF, required = false) String pdf,
			HttpServletRequest request, HttpServletResponse response,
			@RequestParam("infoId") String infoId,
			@RequestParam("orderBy") String orderBy,
			@RequestParam("type") String type) throws ServletException,
			NumberFormatException, IllegalAccessException,
			InvocationTargetException {

		final String minuteNumber = "minuteNumber";
		List<InformationProgressTO> progressList = new ArrayList<InformationProgressTO>();

		if (logger.isDebugEnabled()) {
			logger.info("\n **progressSheetReport");
		}
		try {
			progressList = informationProgressFacade
					.loadInformationProgresses(new Long(infoId));
		} catch (ServiceException e) {
			log.error(e.getMessage());
			throw new ServletException(
					"Exception Loading Information Progress List for Information");
		}
		Collections.sort(progressList, new ProgressSheetComparator());

		if (StringUtils.isNotEmpty(orderBy)
				&& orderBy.equalsIgnoreCase(minuteNumber)) {

			Collections.reverse(progressList);
		}
		try {
			String stylesheetPath = null;
			if (pdf != null) {
				stylesheetPath = CaseUtil.getIRProgressSheetPdfXSLPath(request);
			} else {
				stylesheetPath = CaseUtil.getIRProgressSheetXSLPath(request);
			}

			Document d = transform(infoId, stylesheetPath, progressList, type);

			FileCopyUtils
					.copy(d.asXML().getBytes(), response.getOutputStream());

		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}

		return null;
	}

	private Document transform(String infoId, String stylesheet,
			List<InformationProgressTO> list, String type)
			throws ServiceException {

		if (logger.isDebugEnabled()) {
			logger.debug(" **transform");
		}

		InformationProgressSheetXMLCreator progressXML = new InformationProgressSheetXMLCreator(
				list, type);

		if (logger.isDebugEnabled()) {
			logger.debug(" infoId : " + infoId);
		}
		progressXML.createDOMWithCaseNoAndOperationName(infoId);
		Document document = progressXML.getDom();
		Document transformedDocument = transformService.transform(stylesheet,
				document);
		return transformedDocument;

	}

	protected BindException bindObject(HttpServletRequest request,
			Object command) throws Exception {

		createBinder(request, command).bind(request);

		return new BindException(command, getCommandName(command));
	}

	/**
	 * Progress sheet Comparator
	 * 
	 */
	private class ProgressSheetComparator implements
			Comparator<InformationProgressTO> {

		@Override
		public int compare(InformationProgressTO p1, InformationProgressTO p2) {

			Long min1 = p1.getMinuteNumber();
			Long min2 = p2.getMinuteNumber();

			long minNo1 = min1 == null ? 0 : min1;
			long minNo2 = min2 == null ? 0 : min2;

			if (minNo1 > minNo2) {
				return -1;
			}
			return 1;
		}
	}
}
