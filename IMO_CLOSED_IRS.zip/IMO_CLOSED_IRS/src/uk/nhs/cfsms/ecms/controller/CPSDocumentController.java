/**
 * 
 */
package uk.nhs.cfsms.ecms.controller;

import static java.util.regex.Pattern.compile;
import static org.apache.commons.lang.StringUtils.equalsIgnoreCase;
import static org.apache.commons.lang.StringUtils.isNotEmpty;
import static uk.nhs.cfsms.ecms.ECMSConstants.ACCEPT;
import static uk.nhs.cfsms.ecms.ECMSConstants.APR;
import static uk.nhs.cfsms.ecms.ECMSConstants.COMMA;
import static uk.nhs.cfsms.ecms.ECMSConstants.EXHIBITLABEL;
import static uk.nhs.cfsms.ecms.ECMSConstants.EXHIBITS;
import static uk.nhs.cfsms.ecms.ECMSConstants.HYPHEN;
import static uk.nhs.cfsms.ecms.ECMSConstants.INTERVIEWS;
import static uk.nhs.cfsms.ecms.ECMSConstants.MESSAGE_STATE_NEW;
import static uk.nhs.cfsms.ecms.ECMSConstants.MGFORMS;
import static uk.nhs.cfsms.ecms.ECMSConstants.NEW;
import static uk.nhs.cfsms.ecms.ECMSConstants.REJ;
import static uk.nhs.cfsms.ecms.ECMSConstants.REJECT;
import static uk.nhs.cfsms.ecms.ECMSConstants.WITNESS;
import static uk.nhs.cfsms.ecms.utility.EcmsUtils.getSessionUserObject;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSDocumentsDTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSDocumentsViewDTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSFileNamingRulesDocumentDTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CPSDocumentService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.EhcacheService;
import uk.nhs.cfsms.ecms.service.MessageService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileExtensions;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileTypes;

/**
 * This Controller is responsible for triggering various functionalities for the
 * CPS documents. Like viewing/Listing/Download/Create/Approve/Reject.
 * 
 */
@Controller
public class CPSDocumentController extends BaseMultiActionController {

	private static final String EMPTY_STRING = "";

	private static final String PART_2 = "part 2";

	private static final String MG15 = "MG15";

	private static final String MG11 = "MG11";

	private static final String MG11_PART_2 = "MG11 part 2";

	private static final String EXHIBIT_LABEL = "ExhibitLabel";

	private static final String CASE_SENSITIVE_EXHIBITS_STR = "Exhibits";

	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	private AuditLogService auditLogFacade;

	@Autowired
	private MessageService messageFacade;

	@Autowired
	private CPSDocumentService cpsDocumentsService;

	@Autowired
	private EhcacheService ehcacheService;

	@Autowired
	private CaseService caseFacade;

	private static final String CPS_SUBMISSION_REQUEST = "CPS Submission Request";
	private static final String CPS_SUBMISSION_APPROVED = "CPS Submission Approved";
	private static final String CPS_SUBMISSION_REJECTED = "CPS Submission Rejected";

	/**
	 * Method called with default view.
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param cpsDocumentsDTO
	 * 
	 * @return ModelAndView
	 * 
	 * @throws ServletException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 * @throws NumberFormatException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/secure/viewCPSDocumentList.htm")
	public ModelAndView viewCPSDocumentList(
			final HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse,
			@RequestParam("caseID") final String caseID)
			throws ServletException, NumberFormatException,
			IllegalAccessException, InvocationTargetException {

		final Map<String, Object> cpsDocumentsMap = new HashMap<String, Object>();
		final ObjectMapper mapper = new ObjectMapper();
		final HttpSession httpSession = httpServletRequest.getSession(false);
		final Set<CPSDocumentsDTO> approverDocuments = new HashSet<CPSDocumentsDTO>();
		final SessionUser sessionUser = getSessionUserObject(httpSession);
		ModelAndView modelAndView = null;

		if (sessionUser != null) {

			if (logger.isDebugEnabled()) {
				logger.debug("**CPS Document Listing");
			}

			final Set<CPSDocumentsDTO> invalidFileNames = (Set<CPSDocumentsDTO>) httpSession
					.getAttribute("invalidFiles");

			final String validFilesIDs = (String) httpSession
					.getAttribute("validFiles");

			final boolean isInvalid = isInvalidFileName(invalidFileNames);

			final String requesterMessage = (String) httpSession
					.getAttribute("requesterMessage");

			final String submissionType = (String) httpSession
					.getAttribute("submissionType");

			final boolean isValid = isUpdatedFileValid(validFilesIDs);

			if (isValid) {
				cpsDocumentsMap.put("validFilesReqIDs", validFilesIDs);
			}

			final List<CPSDocumentsViewDTO> submittedAllCPSDocumentsRequestsList = cpsDocumentsService
					.loadAllRequests(Long.parseLong(caseID));
			final String submittedRequests = getSubmittedRequestsInJsonFormat(
					mapper, submittedAllCPSDocumentsRequestsList);

			final List<CPSDocumentsDTO> allCPSDocumentsList = cpsDocumentsService
					.loadAllDocuments(Long.parseLong(caseID));

			final String allCpsDocsInJsonString = getAllCPSDocsinJsonFormat(
					mapper, allCPSDocumentsList);

			final String invalidFileNamesJsonString = getInvalidFileNamesInJsonFormat(
					mapper, invalidFileNames, isInvalid);

			cpsDocumentsMap.put("requesterMessage", requesterMessage);
			cpsDocumentsMap.put("submissionType", submissionType);
			cpsDocumentsMap.put("loggedUser", sessionUser.getStaffId());
			cpsDocumentsMap.put("submittedRequests", submittedRequests);
			cpsDocumentsMap.put("allCpsDocsInJsonString",
					allCpsDocsInJsonString);
			cpsDocumentsMap.put("error", isInvalid);
			cpsDocumentsMap.put("invalidFileNamesJsonString",
					invalidFileNamesJsonString);
			cpsDocumentsMap.put("caseID", caseID);
			cpsDocumentsMap.put("approverDocsTotalSize",
					getAttachmentsSize(approverDocuments));
			cpsDocumentsMap.put("totalDocumentsSize",
					getAttachmentsSize(allCPSDocumentsList));

			modelAndView = new ModelAndView("viewCPSDocumentList",
					"CPSDocumentsMap", cpsDocumentsMap);

		} else {
			final String context = httpServletRequest.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}

		return modelAndView;
	}

	/**
	 * This method is responsible for saving the state of CPS documents
	 * submission.
	 * 
	 * @param HttpServletRequest
	 * @param HttpServletResponse
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/createApprovalRequest.htm")
	public ModelAndView createApprovalRequest(final HttpServletRequest request,
			final HttpServletResponse response,
			@RequestParam("requestedIDs") final String requestedIDs,
			@RequestParam("caseID") final String caseID,
			@RequestParam("requestorMsg") final String requestorMsg,
			@RequestParam("submissionType") final String submissionType,
			@RequestParam("loggedStaffID") final String loggedStaffID)
			throws ServletException {

		ModelAndView modelAndView = null;

		final HttpSession httpSession = request.getSession();
		final SessionUser sessionUser = getSessionUserObject(httpSession);

		if (sessionUser != null) {

			if (logger.isDebugEnabled()) {
				logger.info("**CPS Document Request Saving**");
			}

			validateDocumentsName(request);

			@SuppressWarnings("unchecked")
			final Set<CPSDocumentsDTO> invalidFileNames = (Set<CPSDocumentsDTO>) httpSession
					.getAttribute("invalidFiles");

			final String validFiles = (String) httpSession
					.getAttribute("validFiles");

			final String requestIDsSet = (String) httpSession
					.getAttribute("requestIDsSet");

			final String[] requestIDsSetArray = requestIDsSet.split(",");
			final String[] validFilesArray = validFiles.split(",");

			Arrays.sort(requestIDsSetArray);
			Arrays.sort(validFilesArray);

			if (invalidFileNames.isEmpty()
					&& Arrays.toString(requestIDsSetArray).equals(
							Arrays.toString(validFilesArray))) {

				CPSDocumentsViewDTO cpsDocumentsViewDTO = populateNewCPSApprovalRequest(
						requestedIDs, caseID, requestorMsg, submissionType,
						loggedStaffID);

				try {
					cpsDocumentsViewDTO = this.cpsDocumentsService
							.createApprovalRequest(cpsDocumentsViewDTO);

					httpSession.setAttribute("isNewReqSaved", true);
					removeAttributesFromSession(httpSession);
					//ehcacheService.resetLoadAllRequestsCache();

				} catch (Exception e) {
					logger.error("Exception while saving approval request "
							+ ExceptionUtils.getStackTrace(e));
				}
				try {
					triggerMessageSystem(cpsDocumentsViewDTO, request,
							loggedStaffID, null, null, "New");
				} catch (Exception e) {
					logger.error("Exception while triggering message and after saved approval request "
							+ ExceptionUtils.getStackTrace(e));
				}
			}
			modelAndView = new ModelAndView(new RedirectView(
					"viewCPSDocumentList.htm?caseID=" + caseID));
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;
	}

	/**
	 * This method is responsible for updating the state of CPS documents
	 * submission.
	 * 
	 * @param HttpServletRequest
	 * @param HttpServletResponse
	 * 
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 * @throws ServiceException
	 */

	@RequestMapping(value = "/secure/updateCPSDocumentsFileName.htm")
	public ModelAndView updateCPSDocumentsFileName(
			final HttpServletRequest request,
			final HttpServletResponse response,
			@RequestParam("caseID") final String caseID,
			@RequestParam("invalidFileNames") final String invalidFileNames)
			throws ServletException, ServiceException {

		ModelAndView modelAndView = null;

		final HttpSession httpSession = request.getSession();
		final SessionUser sessionUser = getSessionUserObject(httpSession);

		if (sessionUser != null) {

			if (logger.isDebugEnabled()) {
				logger.info("**Update CPS Document File Names**");
			}

			final String[] fileNames = invalidFileNames.split(",");

			@SuppressWarnings("unchecked")
			final Set<CPSDocumentsDTO> invalidFiles = (Set<CPSDocumentsDTO>) httpSession
					.getAttribute("invalidFiles");
			final String validFileNames = (String) httpSession
					.getAttribute("validFiles");
			final StringBuilder validFileNamesBuilder = new StringBuilder(
					validFileNames);

			for (String fileName : fileNames) {
				final String[] eachFileNames = fileName.split("&");
				final String category = eachFileNames[0];
				final String docID = eachFileNames[1];
				final String name = eachFileNames[2];
				final String formType = eachFileNames[3];

				if (isUpdatedNameValid(category, formType, name, httpSession)) {
					this.cpsDocumentsService.updateCPSDocumentFileName(
							category, name, docID);

					if (isInvalidFileName(invalidFiles)) {
						Iterator<CPSDocumentsDTO> iterator = invalidFiles
								.iterator();
						while (iterator.hasNext()) {
							CPSDocumentsDTO cpsDocumentsDTO = iterator.next();
							if (Integer.parseInt(cpsDocumentsDTO
									.getPrimaryKey()) == Integer
									.parseInt(docID)) {
								iterator.remove();
							}
						}
					}
					validFileNamesBuilder.append(category + HYPHEN + docID
							+ COMMA);
//					ehcacheService.resetloadAllDocumentsCache();
				}
			}
			request.getSession().setAttribute("validFiles",
					validFileNamesBuilder.toString());
			request.getSession().setAttribute("invalidFiles", invalidFiles);

			modelAndView = new ModelAndView(new RedirectView(
					"viewCPSDocumentList.htm?caseID=" + caseID));
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;
	}

	/**
	 * This method is responsible for saving the CPS File Naming Rules Document.
	 * 
	 * @param HttpServletRequest
	 * @param MultipartFile
	 * 
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */

	@RequestMapping(value = "/secure/saveCPSFileNamingRulesDocument.htm", method = RequestMethod.POST)
	protected ModelAndView saveCPSFileNamingRulesDocument(
			HttpServletRequest request,
			@RequestParam("caseID") final String caseID,
			@RequestParam MultipartFile fileToUpload) throws Exception {
		final CPSFileNamingRulesDocumentDTO cpsFileNamingRulesDocumentDTO = new CPSFileNamingRulesDocumentDTO();
		cpsFileNamingRulesDocumentDTO.setCreatedTime(new Date());
		cpsFileNamingRulesDocumentDTO.setDocument(fileToUpload.getBytes());
		cpsFileNamingRulesDocumentDTO.setDocumentName(fileToUpload
				.getOriginalFilename());
		this.cpsDocumentsService
				.saveCPSFileNamingRulesDocument(cpsFileNamingRulesDocumentDTO);
		return new ModelAndView(new RedirectView(
				"viewCPSDocumentList.htm?caseID=" + caseID));
	}

	/**
	 * This method is responsible for resetting the Invalid File Names List
	 * (removing from session).
	 * 
	 * @param HttpServletRequest
	 * @param HttpServletResponse
	 * 
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */

	@RequestMapping(value = "/secure/resetInvalidFileNamesList.htm")
	public ModelAndView resetInvalidFileNamesList(
			final HttpServletRequest request, final HttpServletResponse response)
			throws ServletException {

		ModelAndView modelAndView = null;
		final HttpSession httpSession = request.getSession();
		final SessionUser sessionUser = getSessionUserObject(httpSession);

		if (sessionUser != null) {

			final String caseID = request.getParameter("caseID");

			if (logger.isDebugEnabled()) {
				logger.info("****** Reset Invalid CPS Document Files List ******");
			}
			@SuppressWarnings("unchecked")
			final Set<CPSDocumentsDTO> invalidFiles = (Set<CPSDocumentsDTO>) httpSession
					.getAttribute("invalidFiles");

			final String validFiles = (String) request.getSession()
					.getAttribute("validFiles");

			if (invalidFiles != null) {
				httpSession.removeAttribute("invalidFiles");
			}

			if (validFiles != null && validFiles.isEmpty()) {

				final String requesterMessage = (String) httpSession
						.getAttribute("requesterMessage");

				final String submissionType = (String) httpSession
						.getAttribute("submissionType");

				if (requesterMessage != null) {
					httpSession.removeAttribute("requesterMessage");
				}
				if (submissionType != null) {
					httpSession.removeAttribute("submissionType");
				}
			}

			modelAndView = new ModelAndView(new RedirectView(
					"viewCPSDocumentList.htm?caseID=" + caseID));
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;
	}

	/**
	 * This method is responsible for saving the approval state of CPS documents
	 * submission.
	 * 
	 * @param HttpServletRequest
	 * @param HttpServletResponse
	 * @return ModelAndView
	 * 
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/submitLeadResponse.htm")
	public ModelAndView submitLeadResponse(
			HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse,
			@RequestParam("caseID") final String caseID,
			@RequestParam("approvedIDs") final String approvedIDs,
			@RequestParam("approverAction") final String cpsApproverResponse,
			@RequestParam("approverComments") final String approverComments,
			@RequestParam("loggedStaffID") final String loggedStaffID)
			throws ServletException {

		ModelAndView modelAndView = null;
		final List<String> cpsDocReqList = new ArrayList<String>();
		final HttpSession httpSession = httpServletRequest.getSession();
		final SessionUser sessionUser = getSessionUserObject(httpSession);

		if (sessionUser != null) {
			if (logger.isDebugEnabled()) {
				logger.info("**CPS Document Lead Response Saving**");
			}

			final CPSDocumentsViewDTO cpsDocumentsViewDTO = populateCPSApproverResponse(
					caseID, approvedIDs, cpsApproverResponse, approverComments,
					loggedStaffID);

			final List<CPSDocumentsViewDTO> updatedCPSDocumentsRequestDTOs = this.cpsDocumentsService
					.createApprovalResponse(cpsDocumentsViewDTO);

			httpSession.setAttribute("isNewReqUpdated", true);
			//ehcacheService.resetLoadAllRequestsCache();

			for (final CPSDocumentsViewDTO cpsDocumentsRequest : updatedCPSDocumentsRequestDTOs) {
				final String cpsId = cpsDocumentsRequest.getCpsReqId();
				if (!cpsDocReqList.contains(cpsId)) {
					cpsDocReqList.add(cpsId);
					try {
						triggerMessageSystem(cpsDocumentsRequest,
								httpServletRequest, loggedStaffID,
								cpsApproverResponse, approverComments,
								EMPTY_STRING);
					} catch (Exception e) {
						logger.error("Exception while triggering message and after saved lead response "
								+ ExceptionUtils.getStackTrace(e));
					}
				}
			}
			cpsDocReqList.clear();
			modelAndView = new ModelAndView(new RedirectView(
					"viewCPSDocumentList.htm?caseID=" + caseID));
		} else {
			final String context = httpServletRequest.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;

	}

	/**
	 * This method is responsible for retrieving all CPS documents.
	 * 
	 * @param HttpServletRequest
	 * @param HttpServletResponse
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 * @throws ServiceException
	 * @throws NumberFormatException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */

	@RequestMapping(value = "/secure/showCPSDocsHistory.htm")
	public ModelAndView showCPSDocsHistory(final HttpServletRequest request,
			final HttpServletResponse response,
			@RequestParam("caseID") final String caseID)
			throws ServletException, NumberFormatException, ServiceException,
			IllegalAccessException, InvocationTargetException {

		CaseTO caseTO = null;
		ModelAndView modelAndView = null;
		final HttpSession httpSession = request.getSession();
		final SessionUser sessionUser = getSessionUserObject(httpSession);

		if (sessionUser != null) {

			if (logger.isDebugEnabled()) {
				logger.info("**CPS Document Request History**");
			}

			final Map<String, Object> cpsDocumentsRequestsHistoryMap = new HashMap<String, Object>();
			final ObjectMapper mapper = new ObjectMapper();
			List<CPSDocumentsViewDTO> allCPSDocumentsRequestList = null;
			caseTO = cpsDocumentsService.loadCase(new Long(caseID));

//			if (isNewReqInserted(httpSession)) {
//				ehcacheService.resetLoadAllRequestsHistoryCache();
//			}

			allCPSDocumentsRequestList = cpsDocumentsService
					.loadAllRequestsHistory(sessionUser.getStaffId(),
							Long.parseLong(caseID));
			final List<CPSDocumentsDTO> allCPSDocumentsList = cpsDocumentsService
					.loadAllDocuments(Long.parseLong(caseID));

			String cpsDocumentRequestsList = getSubmittedRequestsInJsonFormat(
					mapper, allCPSDocumentsRequestList);

			final String allCpsDocsInJsonString = getAllCPSDocsinJsonFormat(
					mapper, allCPSDocumentsList);

			cpsDocumentsRequestsHistoryMap.put("loggedUser",
					sessionUser.getStaffId());
			cpsDocumentsRequestsHistoryMap.put("caseID", caseID);
			cpsDocumentsRequestsHistoryMap.put("cpsDocumentRequestsList",
					cpsDocumentRequestsList);
			cpsDocumentsRequestsHistoryMap.put("allCpsDocsInJsonString",
					allCpsDocsInJsonString);
			cpsDocumentsRequestsHistoryMap.put("caseNumber",
					caseTO.getCaseNumber());
			cpsDocumentsRequestsHistoryMap.put("operationName",
					caseTO.getOperationName());

			modelAndView = new ModelAndView("viewCPSDocsHistory",
					"cpsDocumentsRequestsHistoryMap",
					cpsDocumentsRequestsHistoryMap);
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;

	}

	private boolean isNewReqInserted(final HttpSession httpSession) {
		boolean isNewReqInserted = false;

		final Boolean isNewReqSaved = (Boolean) httpSession
				.getAttribute("isNewReqSaved");

		final Boolean isNewReqUpdated = (Boolean) httpSession
				.getAttribute("isNewReqUpdated");

		if (isNewReqSaved != null) {
			httpSession.removeAttribute("isNewReqSaved");
		}

		if (isNewReqUpdated != null) {
			httpSession.removeAttribute("isNewReqUpdated");
		}

		if ((isNewReqSaved != null && isNewReqSaved.booleanValue() == true)) {
			isNewReqInserted = true;
		}

		if ((isNewReqUpdated != null && isNewReqUpdated.booleanValue() == true)) {
			isNewReqInserted = true;
		}
		return isNewReqInserted;
	}

	/**
	 * This method is responsible for downloading the requested file from the
	 * displayed list of files.
	 * 
	 * @param HttpServletRequest
	 * @param HttpServletResponse
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/downloadCPSDocument.htm")
	public ModelAndView downloadCPSDoc(final HttpServletRequest request,
			final HttpServletResponse response,
			@RequestParam("caseId") final String caseID,
			@RequestParam("docID") final String documentID,
			@RequestParam("category") final String documentCategory)
			throws ServletException {

		ModelAndView modelAndView = null;
		final HttpSession httpSession = request.getSession();
		final SessionUser sessionUser = getSessionUserObject(httpSession);

		if (sessionUser != null) {

			if (logger.isDebugEnabled()) {
				logger.info("**CPS Document download");
			}

			/*final String caseID = request.getParameter("caseId");
			final String documentID = request.getParameter("docID");
			final String documentCategory = request.getParameter("category");*/

			final CPSDocumentsDTO cpsDocumentsDTO = this.cpsDocumentsService
					.downloadCPSDocument(Long.parseLong(documentID),
							Long.parseLong(caseID), documentCategory, true);

			if (logger.isDebugEnabled()) {

				logger.debug("**CPS Document download ID=" + documentID
						+ ", category=" + documentCategory);
				if (null != cpsDocumentsDTO) {
					logger.debug("**CPS Document file, type="
							+ cpsDocumentsDTO.getFileType() + ", name="
							+ cpsDocumentsDTO.getFileName());
				}
			}
			try {
				if (null != cpsDocumentsDTO) {

					String fileNameWithExt = cpsDocumentsDTO.getFileName();
					final String fileType = cpsDocumentsDTO.getFileType();

					final String extension = FilenameUtils
							.getExtension(fileNameWithExt);

					if (FileExtensions
							.isValidExtension(extension.toLowerCase())) {
						response.setHeader("Content-Disposition",
								"attachment;filename=\"" + fileNameWithExt
										+ "\"");
					} else {
						if (extension.isEmpty()) {
							if (FileExtensions.isValidExtension(fileType
									.toLowerCase())) {
								fileNameWithExt = fileNameWithExt + "."
										+ fileType;
								response.setHeader("Content-Disposition",
										"attachment;filename=\""
												+ fileNameWithExt + "\"");
							} else {
								final FileTypes fileTypes = FileTypes
										.getExtention(fileType);
								if (fileTypes != null) {
									final String ext = fileTypes.toString();
									fileNameWithExt = fileNameWithExt + "."
											+ ext;
									response.setHeader("Content-Disposition",
											"attachment;filename=\""
													+ fileNameWithExt + "\"");
								}
							}
						}
						if (!extension.isEmpty()
								&& fileNameWithExt.startsWith("Ex.")) {
							if (FileExtensions.isValidExtension(fileType
									.toLowerCase())) {
								fileNameWithExt = fileNameWithExt + "."
										+ fileType;
								response.setHeader("Content-Disposition",
										"attachment;filename=\""
												+ fileNameWithExt + "\"");
							} else {
								final FileTypes fileTypes = FileTypes
										.getExtention(fileType);
								if (fileTypes != null) {
									final String ext = fileTypes.toString();
									fileNameWithExt = fileNameWithExt + "."
											+ ext;
									response.setHeader("Content-Disposition",
											"attachment;filename=\""
													+ fileNameWithExt + "\"");
								}
							}
						}
					}
					response.setContentType(cpsDocumentsDTO.getFileType());

					FileCopyUtils.copy(cpsDocumentsDTO.getFileBlob(),
							response.getOutputStream());
				}
			} catch (IOException e) {
				logger.error(ExceptionUtils.getStackTrace(e));
				throw new ServletException("Exception downloading CPS document");
			}
			modelAndView = null;
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;
	}

	/**
	 * This method is responsible for downloading all requested files from the
	 * displayed list of files.
	 * 
	 * @param HttpServletRequest
	 * @param HttpServletResponse
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */

	@RequestMapping(value = "/secure/downloadAllDocs.htm")
	public ModelAndView downloadAllDocs(final HttpServletRequest request,
			final HttpServletResponse response) throws ServletException {

		ModelAndView modelAndView = null;
		final HttpSession httpSession = request.getSession();
		final SessionUser sessionUser = getSessionUserObject(httpSession);

		if (sessionUser != null) {

			final Map<String, byte[]> fileNames = new HashMap<String, byte[]>();
			final List<CPSDocumentsDTO> cpsDocumentsList = new ArrayList<CPSDocumentsDTO>();
			if (logger.isDebugEnabled()) {
				logger.info("**CPS Download All Documents");
			}
			final String docsArray = request.getParameter("docsArray");
			final String caseID = request.getParameter("caseID");
			long documentID = 0L;
			String documentCategory = null;
			final String[] docs = docsArray.split(COMMA);
			for (final String doc : docs) {
				final String[] docIDCategory = doc.split(HYPHEN);
				documentCategory = docIDCategory[0];
				documentID = Long.parseLong(docIDCategory[1]);
				final CPSDocumentsDTO cpsDocumentsDTO = this.cpsDocumentsService
						.downloadCPSDocument(documentID,
								Long.parseLong(caseID), documentCategory, true);
				if (null != cpsDocumentsDTO) {
					cpsDocumentsList.add(cpsDocumentsDTO);
				}
			}
			ZipOutputStream zos = null;
			int counter = 1;
			try {
				response.setContentType("application/zip");
				response.setHeader("Content-Disposition",
						"attachment;filename=CPS_Documents_" + caseID + ".zip");
				if (!cpsDocumentsList.isEmpty()) {
					zos = new ZipOutputStream(response.getOutputStream());
					for (CPSDocumentsDTO cpsDocumentsTO : cpsDocumentsList) {
						String fileName = cpsDocumentsTO.getFileName();
						String fileType = cpsDocumentsTO.getFileType();
						if (fileNames.containsKey(fileName)) {
							final String extension = FilenameUtils
									.getExtension(fileName);

							if (FileExtensions.isValidExtension(extension
									.toLowerCase())) {
								String newName = fileName.substring(0,
										fileName.indexOf("." + extension))
										+ "_" + counter + "." + extension;

								for (int i = 0; i < cpsDocumentsList.size(); i++) {
									if (fileNames.containsKey(newName)) {
										counter++;
										newName = fileName.substring(
												0,
												fileName.indexOf("."
														+ extension))
												+ "_"
												+ counter
												+ "."
												+ extension;
									} else {
										break;
									}
								}
								fileNames.put(newName,
										cpsDocumentsTO.getFileBlob());
							} else {
								if (extension.isEmpty()) {
									if (FileExtensions
											.isValidExtension(fileType
													.toLowerCase())) {
										String fileNameWithExt = fileName + "."
												+ fileType;
										final String newName = fileNameWithExt
												.substring(
														0,
														fileName.indexOf("."
																+ fileType))
												+ "_"
												+ counter
												+ "."
												+ fileType;
										fileNames.put(newName,
												cpsDocumentsTO.getFileBlob());
									} else {
										final FileTypes fileTypes = FileTypes
												.getExtention(fileType);
										if (fileTypes != null) {
											final String ext = fileTypes
													.toString();
											final String fileNameWithExt = fileName
													+ "." + ext;
											final String newName = fileNameWithExt
													.substring(0, fileName
															.indexOf("." + ext))
													+ "_" + counter + "." + ext;
											fileNames.put(newName,
													cpsDocumentsTO
															.getFileBlob());
										}
									}

								}
								if (!extension.isEmpty()
										&& fileName.startsWith("Ex.")) {
									if (FileExtensions
											.isValidExtension(fileType
													.toLowerCase())) {
										String fileNameWithExt = fileName + "."
												+ fileType;
										final String newName = fileNameWithExt
												.substring(
														0,
														fileName.indexOf("."
																+ fileType))
												+ "_"
												+ counter
												+ "."
												+ fileType;
										fileNames.put(newName,
												cpsDocumentsTO.getFileBlob());
									} else {
										final FileTypes fileTypes = FileTypes
												.getExtention(fileType);
										if (fileTypes != null) {
											final String ext = fileTypes
													.toString();
											final String fileNameWithExt = fileName
													+ "." + ext;
											final String newName = fileNameWithExt
													.substring(0, fileName
															.indexOf("." + ext))
													+ "_" + counter + "." + ext;
											fileNames.put(newName,
													cpsDocumentsTO
															.getFileBlob());
										}
									}

								}
							}
						} else {
							final String extension = FilenameUtils
									.getExtension(fileName);
							if (FileExtensions.isValidExtension(extension
									.toLowerCase())) {
								fileNames.put(fileName,
										cpsDocumentsTO.getFileBlob());
							} else {
								if (extension.isEmpty()) {
									if (FileExtensions
											.isValidExtension(fileType
													.toLowerCase())) {
										final String fileNameWithExt = fileName
												+ "." + fileType;
										fileNames.put(fileNameWithExt,
												cpsDocumentsTO.getFileBlob());
									}
								} else {
									final FileTypes fileTypes = FileTypes
											.getExtention(fileType);
									if (fileTypes != null) {
										final String ext = fileTypes.toString();
										final String fileNameWithExt = fileName
												+ "." + ext;
										fileNames.put(fileNameWithExt,
												cpsDocumentsTO.getFileBlob());
									}
								}
								if (!extension.isEmpty()
										&& fileName.startsWith("Ex.")) {
									if (FileExtensions
											.isValidExtension(fileType
													.toLowerCase())) {
										String fileNameWithExt = fileName + "."
												+ fileType;
										fileNames.put(fileNameWithExt,
												cpsDocumentsTO.getFileBlob());
									} else {
										final FileTypes fileTypes = FileTypes
												.getExtention(fileType);
										if (fileTypes != null) {
											final String ext = fileTypes
													.toString();
											final String fileNameWithExt = fileName
													+ "." + ext;
											fileNames.put(fileNameWithExt,
													cpsDocumentsTO
															.getFileBlob());
										}
									}
								}
							}
						}
					}
				}
				for (String name : fileNames.keySet()) {
					zos.putNextEntry(new ZipEntry(name));
					zos.write(fileNames.get(name));
					zos.closeEntry();
				}
			} catch (IOException e) {
				logger.error(ExceptionUtils.getStackTrace(e));
				throw new ServletException(
						"Exception while downloading all requested CPS documents");
			} finally {
				try {
					zos.close();
					response.flushBuffer();
					response.getOutputStream().close();
				} catch (IOException e) {
					logger.error(e.getMessage());
					throw new ServletException(
							"Exception while closing IO Steam, when downloading all requested CPS documents");
				}

			}
			modelAndView = null;
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;
	}

	/**
	 * This method is responsible for downloading the CPS Naming Rules Document.
	 * 
	 * @param HttpServletRequest
	 * @param HttpServletResponse
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */

	@RequestMapping(value = "/secure/downloadCPSNamingRulesDocument.htm")
	public ModelAndView downloadCPSNamingRulesDocument(
			final HttpServletRequest request, final HttpServletResponse response)
			throws ServletException, ServiceException {

		ModelAndView modelAndView = null;
		final HttpSession httpSession = request.getSession();
		final SessionUser sessionUser = getSessionUserObject(httpSession);

		if (sessionUser != null) {

			if (logger.isDebugEnabled()) {
				logger.info("**CPS Document download");
			}
			CPSFileNamingRulesDocumentDTO cpsFileNamingRulesDocumentDTO = this.cpsDocumentsService
					.downloadCPSFileNamingRulesDocument();

			if (logger.isDebugEnabled()) {
				logger.debug("**CPS File Naming Rules  Document ***");
			}
			try {
				if (null != cpsFileNamingRulesDocumentDTO) {

					response.setHeader(
							"Content-Disposition",
							"attachment;filename=\""
									+ cpsFileNamingRulesDocumentDTO
											.getDocumentName() + "\"");

					FileCopyUtils.copy(
							cpsFileNamingRulesDocumentDTO.getDocument(),
							response.getOutputStream());
				}
			} catch (IOException e) {
				logger.error(ExceptionUtils.getStackTrace(e));
				throw new ServletException("Exception downloading CPS document");
			}

			modelAndView = null;
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;
	}

	/**
	 * This method is responsible for validating requested files name against
	 * CPS file naming convention rules before submitting to approver.
	 * 
	 * @param HttpServletRequest
	 * 
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */

	private Set<CPSDocumentsDTO> validateDocumentsName(
			final HttpServletRequest request) {

		final Set<CPSDocumentsDTO> invalidCPSDocumentsDTOs = new HashSet<CPSDocumentsDTO>();
		final StringBuilder validCPSDocumentsDTOs = new StringBuilder();
		final String reqIDs = request.getParameter("requestedIDs");
		final String caseID = request.getParameter("caseID");
		final String requesterMessage = request.getParameter("requestorMsg");
		final String submissionType = request.getParameter("submissionType");
		final HttpSession httpSession = request.getSession();

		long documentID = 0L;
		String documentCategory = null;
		final String[] docs = reqIDs.split(COMMA);
		for (final String doc : docs) {
			final String[] docIDCategory = doc.split(HYPHEN);
			documentCategory = docIDCategory[0];
			documentID = Long.parseLong(docIDCategory[1]);

			final CPSDocumentsDTO cpsDocumentsDTO = this.cpsDocumentsService
					.downloadCPSDocument(documentID, Long.parseLong(caseID),
							documentCategory, false);
			if (null != cpsDocumentsDTO) {
				String documentNamingRule = null;
				final String formType = cpsDocumentsDTO.getFormType();

				@SuppressWarnings("unchecked")
				Map<String, String> fileNamingRulesMap = (Map<String, String>) httpSession
						.getAttribute("fileNamingRulesMap");

				if (fileNamingRulesMap == null) {
					fileNamingRulesMap = this.cpsDocumentsService
							.getCPSDocumentsNamingRules();
					httpSession.setAttribute("fileNamingRulesMap",
							fileNamingRulesMap);
				}

				final String fileNameWithExt = cpsDocumentsDTO.getFileName();

				documentNamingRule = getFileNamingRule(documentCategory,
						documentNamingRule, formType, fileNamingRulesMap,
						fileNameWithExt);

				if (!documentNamingRule.isEmpty()) {
					final Pattern pattern = compile(documentNamingRule);
					String fileName = null;

					final String extension = FilenameUtils
							.getExtension(fileNameWithExt);

					if (FileExtensions
							.isValidExtension(extension.toLowerCase())) {
						fileName = fileNameWithExt.substring(0,
								fileNameWithExt.indexOf("." + extension));
					} else {
						fileName = fileNameWithExt;
					}
					final Matcher matcher = pattern.matcher(fileName.trim());

					if (!matcher.matches()) {
						invalidCPSDocumentsDTOs.add(cpsDocumentsDTO);
					} else {
						validCPSDocumentsDTOs.append(doc + COMMA);
					}
				} else {
					validCPSDocumentsDTOs.append(doc + COMMA);
				}
			}
		}

		httpSession.setAttribute("requesterMessage", requesterMessage);

		httpSession.setAttribute("submissionType", submissionType);

		httpSession.setAttribute("requestIDsSet", reqIDs);

		httpSession.setAttribute("invalidFiles", invalidCPSDocumentsDTOs);
		httpSession
				.setAttribute("validFiles", validCPSDocumentsDTOs.toString());

		return invalidCPSDocumentsDTOs;
	}

	/**
	 * This method is responsible for validating requested files name against
	 * CPS file naming convention rules before updating with new name.
	 * 
	 * @param HttpServletRequest
	 * 
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */

	private boolean isUpdatedNameValid(final String documentCategory,
			final String formType, final String name,
			final HttpSession httpSession) {
		boolean isValid = true;
		final CPSDocumentsDTO cpsDocumentsDTO = new CPSDocumentsDTO();
		cpsDocumentsDTO.setFormType(formType);
		String documentNamingRule = null;
		@SuppressWarnings("unchecked")
		Map<String, String> fileNamingRulesMap = (Map<String, String>) httpSession
				.getAttribute("fileNamingRulesMap");
		if (fileNamingRulesMap == null) {
			fileNamingRulesMap = this.cpsDocumentsService
					.getCPSDocumentsNamingRules();
			httpSession.setAttribute("fileNamingRulesMap", fileNamingRulesMap);
		}

		documentNamingRule = getFileNamingRule(documentCategory,
				documentNamingRule, formType, fileNamingRulesMap, name);

		Pattern pattern = compile(documentNamingRule);
		final String fileNameWithExt = name;
		String fileName = null;
		final String extension = FilenameUtils.getExtension(fileNameWithExt);
		if (FileExtensions.isValidExtension(extension.toLowerCase())) {
			fileName = fileNameWithExt.substring(0,
					fileNameWithExt.indexOf("." + extension));
		} else {
			fileName = fileNameWithExt;
		}

		final Matcher matcher = pattern.matcher(fileName.trim());

		if (!matcher.matches()) {
			isValid = false;
		}

		return isValid;
	}

	/**
	 * This method is responsible for calculating the size of files.
	 * 
	 * @param Collection
	 *            <CPSDocumentsDTO>
	 * 
	 * @return Map<String, Long>
	 */

	private Map<String, Long> getAttachmentsSize(
			final Collection<CPSDocumentsDTO> cpsDocumentsDTO) {
		final Map<String, Long> map = new HashMap<String, Long>();
		long totalSize = 0;
		for (CPSDocumentsDTO cpsDocument : cpsDocumentsDTO) {
			totalSize += cpsDocument.getSize();
		}
		map.put("totalSize", totalSize);
		return map;

	}

	/**
	 * This method is responsible to get file naming rule for given document
	 * category.
	 * 
	 * @param String
	 *            documentCategory
	 * @param String
	 *            documentNamingRule
	 * @param String
	 *            formType
	 * @param Map
	 *            <String, String> fileNamingRulesMap
	 * 
	 * @return String
	 */

	private String getFileNamingRule(final String documentCategory,
			String documentNamingRule, final String formType,
			final Map<String, String> fileNamingRulesMap, String fielName) {

		if (EXHIBITS.equals(documentCategory)) {
			documentNamingRule = fileNamingRulesMap
					.get(CASE_SENSITIVE_EXHIBITS_STR);
		}

		if (EXHIBITLABEL.equals(documentCategory)) {
			documentNamingRule = fileNamingRulesMap.get(EXHIBIT_LABEL);
		}

		if (WITNESS.equalsIgnoreCase(documentCategory)) {
			if (fielName.contains(PART_2)) {
				documentNamingRule = fileNamingRulesMap.get(MG11_PART_2);
			} else {
				documentNamingRule = fileNamingRulesMap.get(MG11);
			}
		}
		if (INTERVIEWS.equalsIgnoreCase(documentCategory)) {
			documentNamingRule = fileNamingRulesMap.get(MG15);
		}
		if (MGFORMS.equalsIgnoreCase(documentCategory)) {
			documentNamingRule = fileNamingRulesMap.get(formType);
		}
		documentNamingRule = documentNamingRule != null ? documentNamingRule
				.trim() : EMPTY_STRING;
		return documentNamingRule;
	}

	/**
	 * This method is responsible for preparing the transfer object for lead
	 * response.
	 * 
	 * @param HttpServletRequest
	 * 
	 * @return CPSDocumentsRequestDTO
	 * */

	private CPSDocumentsViewDTO populateCPSApproverResponse(
			final String caseID, final String approvedIDs,
			final String cpsApproverResponse, final String approverComments,
			final String loggedStaffID) {

		final CPSDocumentsViewDTO cpsDocumentsViewDTO = new CPSDocumentsViewDTO();

		cpsDocumentsViewDTO.setCaseId(Long.parseLong(caseID));
		cpsDocumentsViewDTO.setRequestedData(approvedIDs);
		cpsDocumentsViewDTO.setApproverStaffId(loggedStaffID);
		cpsDocumentsViewDTO.setApproverMessage(approverComments);
		cpsDocumentsViewDTO.setApproverResponseTime(new Timestamp(new Date()
				.getTime()));

		if (equalsIgnoreCase(cpsApproverResponse, ACCEPT)) {
			cpsDocumentsViewDTO.setRequestStatus(APR);
		} else if (equalsIgnoreCase(cpsApproverResponse, REJECT)) {
			cpsDocumentsViewDTO.setRequestStatus(REJ);
		}
		return cpsDocumentsViewDTO;
	}

	/**
	 * This method is responsible for creating the request transfer object.
	 * 
	 * @param HttpServletRequest
	 * 
	 * @return CPSDocsSubmitTO
	 * */
	private CPSDocumentsViewDTO populateNewCPSApprovalRequest(
			final String reqIDs, final String caseID,
			final String requestorMsg, final String submissionType,
			final String loggedStaffID) {

		final CPSDocumentsViewDTO cpsDocumentsViewDTO = new CPSDocumentsViewDTO();

		if (isNotEmpty(caseID)) {
			cpsDocumentsViewDTO.setCaseId(Long.parseLong(caseID));
		}

		cpsDocumentsViewDTO.setCreatedStaffId(loggedStaffID);
		cpsDocumentsViewDTO.setRequesterMessage(requestorMsg);
		cpsDocumentsViewDTO.setCreatedTime(new Timestamp(new Date().getTime()));
		cpsDocumentsViewDTO.setRequestStatus(NEW);
		cpsDocumentsViewDTO.setRequestedData(reqIDs);
		cpsDocumentsViewDTO.setSubmissionType(submissionType);

		return cpsDocumentsViewDTO;
	}

	/**
	 * This method is responsible for triggering the messaging system.
	 * 
	 * @param HttpServletRequest
	 * 
	 * @throws Exception
	 */
	private void triggerMessageSystem(
			final CPSDocumentsViewDTO cpsDocumentsViewDTO,
			HttpServletRequest request, final String loggedStaffID,
			final String cpsApproverResponse, final String comments,
			final String status) throws Exception {
		final Long caseId = cpsDocumentsViewDTO.getCaseId();

		MessageTO messageTO = new MessageTO();
		messageTO.setCaseId(caseId);
		messageTO.setCreatedTime(Calendar.getInstance().getTime());

		messageTO.setCaseRef(cpsDocumentsViewDTO.getCpsReqId().toString());

		messageTO.setCreatedStaffId(loggedStaffID);
		messageTO.setFromStaffId(loggedStaffID);
		messageTO.setFromStaffName(this.cpsDocumentsService
				.getUserFullName(loggedStaffID));

		StringBuilder message = new StringBuilder("CPS Document Request ID : ");

		if (equalsIgnoreCase(loggedStaffID,
				cpsDocumentsViewDTO.getCreatedStaffId())) {

			messageTO.setToStaffId(cpsDocumentsViewDTO.getApproverStaffId());
			messageTO.setToStaffName(this.cpsDocumentsService
					.getUserFullName(cpsDocumentsViewDTO.getApproverStaffId()));

			messageTO.setMessageType(CPS_SUBMISSION_REQUEST);

			message.append(cpsDocumentsViewDTO.getCpsReqId());
			message.append("\n Message : "
					+ cpsDocumentsViewDTO.getRequesterMessage());
			message.append("\n Status : " + status);

		} else if (equalsIgnoreCase(loggedStaffID,
				cpsDocumentsViewDTO.getApproverStaffId())) {

			if (equalsIgnoreCase(cpsApproverResponse, ACCEPT)) {
				cpsDocumentsViewDTO.setRequestStatus("Approved");
			} else if (equalsIgnoreCase(cpsApproverResponse, REJECT)) {
				cpsDocumentsViewDTO.setRequestStatus("Rejected");
			}

			messageTO.setToStaffId(cpsDocumentsViewDTO.getCreatedStaffId());
			messageTO.setToStaffName(this.cpsDocumentsService
					.getUserFullName(cpsDocumentsViewDTO.getCreatedStaffId()));

			message.append(cpsDocumentsViewDTO.getCpsReqId());
			message.append("\n Message : " + comments);
			message.append("\n Status : "
					+ cpsDocumentsViewDTO.getRequestStatus());

			if (equalsIgnoreCase(cpsDocumentsViewDTO.getRequestStatus(),
					"Approved")) {
				messageTO.setMessageType(CPS_SUBMISSION_APPROVED);
			} else if (equalsIgnoreCase(cpsDocumentsViewDTO.getRequestStatus(),
					"Rejected")) {
				messageTO.setMessageType(CPS_SUBMISSION_REJECTED);
			}
		}
		messageTO.setMessage(message.toString());
		messageTO.setState(MESSAGE_STATE_NEW);
		AuditFlowThread.set("Message Created");
		messageTO = messageFacade.saveMessage(messageTO);
	}

	/**
	 * @param invalidFileNames
	 * @return
	 */
	private boolean isInvalidFileName(
			final Set<CPSDocumentsDTO> invalidFileNames) {
		return invalidFileNames != null && !invalidFileNames.isEmpty();
	}

	/**
	 * @param validFilesIDs
	 * @return
	 */
	private boolean isUpdatedFileValid(final String validFilesIDs) {
		return validFilesIDs != null && !validFilesIDs.isEmpty();
	}

	/**
	 * @param auditLogFacade
	 *            the auditLogFacade to set
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	/**
	 * @param messageFacade
	 *            the messageFacade to set
	 */
	public void setMessageFacade(MessageService messageFacade) {
		this.messageFacade = messageFacade;
	}

	/**
	 * @param cpsDocumentService
	 *            the cpsDocumentService to set
	 */
	public void setCpsDocumentsFacade(CPSDocumentService cpsDocumentsFacade) {
		this.cpsDocumentsService = cpsDocumentsFacade;
	}

	private void removeAttributesFromSession(final HttpSession httpSession) {

		if (httpSession.getAttribute("invalidFiles") != null) {
			httpSession.removeAttribute("invalidFiles");
		}

		if (httpSession.getAttribute("validFiles") != null) {
			httpSession.removeAttribute("validFiles");
		}
		if (httpSession.getAttribute("requestIDsSet") != null) {
			httpSession.removeAttribute("requestIDsSet");
		}

		if (httpSession.getAttribute("requesterMessage") != null) {
			httpSession.removeAttribute("requesterMessage");
		}

		if (httpSession.getAttribute("submissionType") != null) {
			httpSession.removeAttribute("submissionType");
		}
	}

	private String getInvalidFileNamesInJsonFormat(final ObjectMapper mapper,
			final Set<CPSDocumentsDTO> invalidFileNames, final boolean error) {
		String invalidFileNamesJsonString = null;
		if (error) {
			try {
				invalidFileNamesJsonString = mapper
						.writeValueAsString(invalidFileNames);
			} catch (JsonGenerationException e) {
				logger.error("Got JsonGenerationException while generating Json string from invalidFileNames "
						+ ExceptionUtils.getStackTrace(e));
			} catch (JsonMappingException e) {
				logger.error("Got JsonMappingException while generating Json string from invalidFileNames "
						+ ExceptionUtils.getStackTrace(e));
			} catch (IOException e) {
				logger.error("Got IOException while generating Json string from invalidFileNamesJsonString "
						+ ExceptionUtils.getStackTrace(e));
			}
		}
		return invalidFileNamesJsonString;
	}

	private String getAllCPSDocsinJsonFormat(final ObjectMapper mapper,
			final List<CPSDocumentsDTO> allCPSDocumentsList) {
		String allCpsDocsInJsonString = null;
		try {
			allCpsDocsInJsonString = mapper
					.writeValueAsString(allCPSDocumentsList);
		} catch (JsonGenerationException e) {
			logger.error("Got JsonGenerationException while generating Json string from allCPSDocumentsList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (JsonMappingException e) {
			logger.error("Got JsonMappingException while generating Json string from allCPSDocumentsList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {
			logger.error("Got IOException while generating Json string from allCPSDocumentsList "
					+ ExceptionUtils.getStackTrace(e));
		}
		return allCpsDocsInJsonString;
	}

	private String getSubmittedRequestsInJsonFormat(final ObjectMapper mapper,
			final List<CPSDocumentsViewDTO> submittedAllCPSDocumentsRequestsList) {
		String submittedRequests = null;
		try {
			submittedRequests = mapper
					.writeValueAsString(submittedAllCPSDocumentsRequestsList);
		} catch (JsonGenerationException e) {
			logger.error("Got JsonGenerationException while generating Json string from submittedAllCPSDocumentsList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (JsonMappingException e) {
			logger.error("Got JsonMappingException while generating Json string from submittedAllCPSDocumentsList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {
			logger.error("Got IOException while generating Json string from submittedAllCPSDocumentsList "
					+ ExceptionUtils.getStackTrace(e));
		}
		return submittedRequests;
	}
}
