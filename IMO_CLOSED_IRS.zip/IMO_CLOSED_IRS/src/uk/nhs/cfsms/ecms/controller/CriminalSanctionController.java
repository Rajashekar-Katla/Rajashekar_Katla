package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppeal;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalAppealTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalSanctionTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SubjectName;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CriminalAppealService;
import uk.nhs.cfsms.ecms.service.CriminalSanctionService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * Criminal Sanction Controller handles the requests for the Criminal Sanctions
 * for a particular Case.
 */
@Controller
public class CriminalSanctionController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CriminalSanctionService criminalSanctionFacade;
	@Autowired
	private InformationGatherService informationGatherFacade;
	@Autowired
	private CriminalAppealService criminalAppealFacade;

	static final String SHOW_CRIMINAL_SANCTIONS_PAGE = "showCriminalSanctions.htm";

	static final String CRIMINAL_SANCTIONS_DETAILS_VIEW = "criminalSanctionsDetails";

	static final String ADD_CRIMINAL_SANCTION_VIEW = "criminalSanctionInput";

	static final String CRIMINAL_SANCTION_PARAM = "criminalSanction";

	static final String CRIMINAL_SANCTIONS_PARAM = "criminalSanctions";

	static final String CRIMINAL_APPEALS_PARAM = "criminalAppeals";

	static final String CRIMINAL_SANCTIONS_SIZE_PARAM = "criminalSanctionsSize";

	static final String CRIMINAL_APPEALS_SIZE_PARAM = "criminalAppealsSize";

	static final String CRIMINAL_SANCTION_SUBJECTS = "subjects";

	static final String CRIMINAL_SANCTIONS_VIEW = "viewCriminalSanctions";

	static final String CRIMINAL_SANCTION_MODEL_PARAM = "csModel";

	static final String CRIMINAL_SANCTIONS_MAP_PARAM = "criminalSanctionsMap";

	
	/**
	 * Show Criminal Sanctions
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showCriminalSanctions.htm")
	public ModelAndView showCriminalSanctions(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		return showCriminalSanctionsWithErrors(request, response,
				new ArrayList<String>());
	}

	/**
	 * Show Criminal Sanctions
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	private ModelAndView showCriminalSanctionsWithErrors(
			HttpServletRequest request, HttpServletResponse response,
			List<String> errors) throws ServletException {

		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		
		try {
			List<CriminalSanctionTO> res = criminalSanctionFacade
					.loadCriminalSanctions(new Long(caseID));

			for(CriminalSanctionTO criminalSanctionTO : res){
				if (hasAppealsForSanction(String.valueOf(criminalSanctionTO != null ? 
										  criminalSanctionTO.getCriminalSanctionId() : 0))){
					criminalSanctionTO.setAppealExists(true);
				}
			}

			List<CriminalAppealTO> appealRes = criminalAppealFacade
					.loadCriminalAppeals(new Long(caseID));
			Map<String, Object> criminalSanctionsMap = new HashMap<String, Object>();
			criminalSanctionsMap.put(CRIMINAL_SANCTIONS_PARAM, res);
			criminalSanctionsMap.put(CRIMINAL_SANCTIONS_SIZE_PARAM, res.size());
			criminalSanctionsMap.put(CRIMINAL_APPEALS_PARAM, appealRes);
			criminalSanctionsMap.put(CRIMINAL_APPEALS_SIZE_PARAM,
					appealRes.size());

			criminalSanctionsMap.put(ECMSConstants.ERROR_MESSAGES, errors);

			if (logger.isDebugEnabled()) {
				logger.debug("\n*** Error list size =" + errors.size());
			}
			return new ModelAndView(CRIMINAL_SANCTIONS_VIEW,
					CRIMINAL_SANCTIONS_MAP_PARAM, criminalSanctionsMap);

		} catch (ServiceException se) {
			throw new ServletException(se);
		}

	}

	/**
	 * Retrieve sanctionDetails foe a criminal Sanction ID.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/sanctionDetails.htm")
	public ModelAndView sanctionDetails(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map<String, Object> model = new HashMap<String, Object>();

		String cSID = request.getParameter(CaseUtil.SANCTION_ID_PARAM);
		CriminalSanctionTO csto = new CriminalSanctionTO();
		String caseId = null;
		try {
			caseId = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		try {
			csto = criminalSanctionFacade.getCriminalSanction(
					(StringUtils.isEmpty(cSID) ? new Long(0) : new Long(cSID)));

		} catch (ServiceException se) {
			log.error(se);
			throw new ServletException(se);
		}
		if (csto.getCaseId() == null) {

			csto.setCaseId(new Long(caseId));

		} else if (csto.getCaseId() != null
				&& !caseId.equals(csto.getCaseId().toString())) {

			SessionUser user = EcmsUtils.getSessionUserObject(request
					.getSession());
			log.error("Browsing caseId=" + caseId
					+ "; CriminalSanction CaseId=" + csto.getCaseId());
			ServletException exp = new ServletException(user.getStaffId()
					+ " Criminal sanction details with caseId="
					+ csto.getCaseId());
			log.error(exp);
			throw exp;
		}

		List<SubjectName> subjects = getAllSubjects(caseId);

		model.put(CRIMINAL_SANCTION_PARAM, csto);
		model.put(CRIMINAL_SANCTION_SUBJECTS, subjects);

		return new ModelAndView(CRIMINAL_SANCTIONS_DETAILS_VIEW,
				CRIMINAL_SANCTION_MODEL_PARAM, model);
	}

	/**
	 * criminalSanctionInput is to add new criminal Sanction.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/criminalSanctionInput.htm")
	public ModelAndView criminalSanctionInput(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		CriminalSanctionTO csto = null;

		String caseID = null;

		Map<String, Object> model = new HashMap<String, Object>();

		String cSID = request.getParameter(CaseUtil.SANCTION_ID_PARAM);
		
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		 
		try {
			
			csto = criminalSanctionFacade.getCriminalSanction(
						(StringUtils.isEmpty(cSID) ? new Long(0) : new Long(cSID)));
 
		} catch (ServiceException se) {
			log.error(se);
				throw new ServletException(se);
		} 

		List<SubjectName> subjectList = getAllSubjects(caseID);

		if (null == subjectList
				|| (null != subjectList && subjectList.isEmpty())) {

			model.put(ECMSConstants.ERROR_MESSAGES, ECMSConstants.NO_SUBJECTS);

			return new ModelAndView(CRIMINAL_SANCTIONS_VIEW,
					CRIMINAL_SANCTIONS_MAP_PARAM, model);
		}
		
		if ( (null != csto && null==csto.getCaseId()) && 
				StringUtils.isNotEmpty(caseID)) { 
			
			csto.setCaseId(new Long(caseID));			
		}
		
		model.put(CRIMINAL_SANCTION_PARAM, csto);
		model.put(CRIMINAL_SANCTION_SUBJECTS, subjectList);

		return new ModelAndView(ADD_CRIMINAL_SANCTION_VIEW,
				CRIMINAL_SANCTION_MODEL_PARAM, model);

	}

	private List<SubjectName> getAllSubjects(String caseId) {

		InformationTO infoTO = informationGatherFacade
				.loadInformationByCaseId(new Long(caseId));

		return EcmsUtils.getInformationSubjectList(infoTO);

	}

	/**
	 * Save Criminal Sanction
	 * 
	 * @param request
	 * @param response
	 * @param CriminalSanctionTO
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveCriminalSanction.htm")
	public ModelAndView saveCriminalSanction(HttpServletRequest request,
			HttpServletResponse response, CriminalSanctionTO dto)
			throws ServletException {

		BindException errors = null;
		String caseID = null;

		try {
			errors = bindObject(request, dto, new CriminalSanctionValidator());
		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}

		dto.setCaseId(new Long(caseID));
		// String subjectId = request.getParameter("subjectId");
		String subjectParam = request.getParameter("subjectParam");
		int index = subjectParam.indexOf("-");
		String subjectId = subjectParam.substring(0, index);
		String subjectType = subjectParam.substring(index + 1,
				subjectParam.length());
		if (subjectId != null) {
			dto.setSubjectId(new Long(subjectId));
		}
		if (subjectType != null) {
			dto.setSubjectType(subjectType);
		}

		if (dto.getCriminalSanctionId() == null) {
			dto.setCreatedStaffId(EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId());
			dto.setCreatedTime(new Date(System.currentTimeMillis()));
			dto.setState(CaseUtil.ONGOING_STATUS);
		}

		if (dto.getCriminalSanctionId() == null
				|| (dto.getCriminalSanctionId() == 0l)) {
			AuditFlowThread.set("Criminal Sanction Created");
		} else {
			AuditFlowThread.set("Criminal Sanction Updated");
		}
		try {
			if (!errors.hasErrors()) {
				criminalSanctionFacade.saveObject(dto);
				createAudit(dto, AuditLogService.UPDATE, "Criminal Sanction",
						request, auditLogFacade);
			}
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		return new ModelAndView(new RedirectView(SHOW_CRIMINAL_SANCTIONS_PAGE));

	}

	/**
	 * Delete Criminal Sanction
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/deleteCriminalSanction.htm")
	public ModelAndView deleteCriminalSanction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String cSID = request.getParameter(CaseUtil.SANCTION_ID_PARAM);

		try {
			if (hasAppealsForSanction(cSID)) {

				List<String> errorList = new ArrayList<String>();
				errorList.add("Appeal exists for this sanction.");
				errorList
						.add("Please remove the dependencies and repeat this action in order to continue.");

				return showCriminalSanctionsWithErrors(request, response, errorList);
 			}

			AuditFlowThread.set("Criminal Sanction Deleted");
			
			criminalSanctionFacade.deleteCriminalSanctionById(new Long(cSID));
			
			createAudit("criminalsanctionId=" + cSID, AuditLogService.DELETE,
					"Criminal Sanction", request, auditLogFacade);
			
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		return new ModelAndView(new RedirectView(SHOW_CRIMINAL_SANCTIONS_PAGE));
	}

	
	private boolean hasAppealsForSanction(String sanctionId)
			throws ServiceException {

		List<CriminalAppeal> appealsList = criminalAppealFacade
				.loadAppealsByParentSanctionId(new Long(sanctionId));

		if (null != appealsList && appealsList.size() > 0) {

			return true;
		}
		return false;
	}

	/**
	 * @param criminalSanctionFacade
	 *            The criminalSanctionFacade to set.
	 */
	public void setCriminalSanctionFacade(
			CriminalSanctionService criminalSanctionFacade) {

		this.criminalSanctionFacade = criminalSanctionFacade;
	}

	/**
	 * @param informationGatherFacade
	 *            The informationGatherFacade to set.
	 */
	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}

	/**
	 * Criminal Sanction Validator
	 */
	class CriminalSanctionValidator implements Validator {

		public boolean supports(Class arg0) {
			// TODO Auto-generated method stub
			return false;
		}

		public void validate(Object arg0, Errors arg1) {
			// TODO Auto-generated method stub

		}
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public void setCriminalAppealFacade(
			CriminalAppealService criminalAppealFacade) {
		this.criminalAppealFacade = criminalAppealFacade;
	}

}
