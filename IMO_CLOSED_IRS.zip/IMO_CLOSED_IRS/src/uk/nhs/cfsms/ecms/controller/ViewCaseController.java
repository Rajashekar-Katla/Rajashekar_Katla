package uk.nhs.cfsms.ecms.controller;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import uk.nhs.cfsms.ecms.data.authorization.AccessControl;
import uk.nhs.cfsms.ecms.data.cim.CaseSummaryInformation;
import uk.nhs.cfsms.ecms.data.cim.CaseUpdate;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

@Controller
public class ViewCaseController extends MultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private LookupViewService lookupViewFacade;
	@Autowired
	private CaseService caseFacade;

	static final String caseViewPath = "/secure/showCase.htm";

	static final String CASE_ACCEPTANCE_TYPE = "CASE_ACCEPTANCE_TYPE";

	/**
	 * Handle case summary.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/viewCaseSummary.htm")
	public ModelAndView handleCaseSummary(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		CaseTO caseTO = null;
		String case_id = request.getParameter("caseId");

		if (StringUtils.isEmpty(case_id)) {

			return CaseUtil.getCasePortalView();
		}

		try {
			Long caseId = new Long(case_id);

			if (checkUserIsAuthorized(request, case_id)) {

				caseTO = caseFacade.loadCase(caseId);

				CaseSummaryInformation caseInfo = caseFacade
						.loadCaseSummaryInformation(caseId);

				if (caseInfo != null) {
					caseTO.setInformationSummary(caseInfo.getInformation());
					caseTO.setSubjectNames(caseFacade
							.loadSubjectsByCaseId(caseId));
				}
				this.updateCaseTODetails(caseTO);

			} else {
				// Create empty case.
				//caseTO = new CaseTO();
				//caseTO.setDataOwner(caseFacade.getOwnerDetailsBycaseId(caseId));

				caseTO = new CaseTO();
				caseTO.setDataOwner(caseFacade.getOwnerDetailsBycaseId(caseId));
				return new ModelAndView("unauthorizedCaseView", "case", caseTO);
			}
		} catch (NumberFormatException nfe) {
			log.error("NFE converting case Id =" + case_id + " - "
					+ nfe.getMessage());
			log.error(nfe);
		} catch (ServiceException e) {
			log.error("Exception loading case with Id=" + case_id + " @ "
					+ e.getMessage());
			log.error(e);

			return CaseUtil.getCasePortalView();
		}
		return new ModelAndView("caseSummaryView", "case", caseTO);
	}

	private void updateCaseTODetails(CaseTO caseTO) throws ServiceException {

		List<CaseUpdate> updateList = caseFacade.loadAllCaseUpdates(caseTO
				.getCaseId());
		caseTO.setCaseUpdates(updateList);
		caseTO.setCaseUpdateDesc(updateList.size() > 0 ? updateList.get(
				updateList.size() - 1).getDescription() : "");
		caseTO.setAcceptanceTypeList(lookupViewFacade
				.loadActiveLookupDetailsByGroups(CASE_ACCEPTANCE_TYPE));

	}

	/**
	 * Handle View Case.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showCase.htm")
	public ModelAndView handleViewCase(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		CaseTO caseTO = null;
		String id = request.getParameter("caseId");

		if (StringUtils.isEmpty(id)) {
			log.warn("Case Id is Null. Expecting a caseId param.");
			return CaseUtil.getCasePortalView();
		}

		try {
			if (checkUserIsAuthorized(request, id)) {

				caseTO = caseFacade.loadCase(new Long(id));

				this.updateCaseTODetails(caseTO);

			} else {
				caseTO = new CaseTO();
				caseTO.setDataOwner(caseFacade
						.getOwnerDetailsBycaseId(new Long(id)));

				return new ModelAndView("unauthorizedCaseView", "case", caseTO);
			}

		} catch (ServiceException e) {
			log.error("Exception loading case number=" + id + " @ "
					+ e.getMessage());
			log.error(e);
			return CaseUtil.getCasePortalView();
		}
		// Set up form session for rest of the category's.
		CaseUtil.setCurrentCaseInSession(request.getSession(), caseTO);

		return new ModelAndView("caseDetails", "case", caseTO);
	}

	/**
	 * Check for autherization by param.
	 * 
	 * @param request
	 * @param id
	 * @return boolean
	 */
	private boolean checkUserIsAuthorized(HttpServletRequest request, String id) {

		HttpSession session = request.getSession();
		AccessControl access = EcmsUtils.getCurrentAccessControl(session,
				caseViewPath);

		if (access != null) {
			List<String> paramValues = EcmsUtils.getParamValues(request,
					access.getAllUrlParams());

			if (paramValues.contains(id)) {
				log.debug("*** CHECKING ACCESS(AUTHRZTN) for caseID :" + id);
				return caseFacade.checkAccessToCase(new Long(id),
						EcmsUtils.getSessionUserObject(session));
			}
		} else {
			log.debug("*** ACCESS CONTROL IS NULL, CHECK DATA IN DB !!!");
		}
		return true;
	}

	/**
	 * @param caseFacade
	 *            The caseFacade to set.
	 */
	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public void setLookupViewFacade(LookupViewService lookupViewFacade) {
		this.lookupViewFacade = lookupViewFacade;
	}

}
