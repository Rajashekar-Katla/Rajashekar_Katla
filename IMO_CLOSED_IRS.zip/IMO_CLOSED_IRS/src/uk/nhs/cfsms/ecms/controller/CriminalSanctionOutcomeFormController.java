package uk.nhs.cfsms.ecms.controller;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeOrderSanction;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SanctionApplied;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SanctionOutcomeTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CriminalSanctionService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.ConvertToDTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
public class CriminalSanctionOutcomeFormController {

	@Autowired
	private AuditLogService auditLogFacade;
	
	@Autowired
	private CriminalSanctionService criminalSanctionFacade; 
	
	private static final String SANCTIONS_DETAILS_LINK = "sanctionDetails.htm?sanctionId=";

	protected final Log log = LogFactory.getLog(getClass());
	
	
	public CriminalSanctionOutcomeFormController() {

	}

	@RequestMapping(value="/secure/editCriminalSanctionOutcome.htm", params = {"!outcomeDate"})
	protected ModelAndView formBackingObject(
			HttpServletRequest request)	throws Exception {
		
		ModelAndView mAV = new ModelAndView("criminalSanctionOutcome");
		log.info("** formBackingObject().");

		String sanctionID = request.getParameter(CaseUtil.SANCTION_ID_PARAM);

		SanctionOutcomeTO dto = new SanctionOutcomeTO();

		if (StringUtils.isNotEmpty(sanctionID)) {
			dto.setCriminalSanctionId(new Long(sanctionID));
		}
		if (EcmsUtils.onCancel(request)) {
			return mAV.addObject("criminalSanctionOutcome", dto);
		}
		String action = request.getParameter(CaseUtil.ACTION_TYPE_PARAM);

		if (action != null && action.equalsIgnoreCase(CaseUtil.VIEW_PARAM)) {

			if (StringUtils.isNotEmpty(sanctionID)
					&& (!EcmsUtils.onCancel(request))) {
				
				CriminalSanctionOutcome outcome = criminalSanctionFacade.loadCriminalSanctionOutcome(new Long(sanctionID));
				dto = ConvertToDTO.getInstance().convertToDTO(outcome);
			}
		}

		return mAV.addObject("criminalSanctionOutcome", dto);
	}

	@RequestMapping(value="/secure/editCriminalSanctionOutcome.htm", params = {"outcomeDate"})
	public ModelAndView processFormSubmission(HttpServletRequest request,
			HttpServletResponse response, @ModelAttribute("criminalSanctionOutcome") SanctionOutcomeTO dto, BindingResult errors)
			throws Exception {

		log.info("** processFormSubmission");

		ModelAndView mAV = new ModelAndView("criminalSanctionOutcome");

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		if (null == user) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}

		if (EcmsUtils.onCancel(request)) {
			return this.getRedirectView(dto);
		}

		validateSanctionOutcome(dto, request, errors);
		
		if (errors.getErrorCount() < 1) {
			
			// Check your actions and do the action.
			if (EcmsUtils.onFinish(request)) {
				
				updateSanctionAppliedByStatus(dto, request);
				
				if (dto.getOutcomeId() == null) {
					dto.setCreatedStaffId(user.getStaffId());
					dto.setCreatedTime(new Date());
				}
				CriminalSanctionOutcome dao = ConvertFromDTO.getInstance().convertFromDTO(dto);
				if(dao.getOutcomeId() == null || dao.getOutcomeId() == 0L) {
					AuditFlowThread.set("Criminal Sanction OutCome Created");
				} else {
					AuditFlowThread.set("Criminal Sanction OutCome Updated");
				}
				criminalSanctionFacade.saveOutcome(dao);
				createAudit(dto, AuditLogService.UPDATE,
						"Criminal Sanction Outcome Updated", request,
						auditLogFacade);
				return this.getRedirectView(dto);
			}
			if (EcmsUtils.onDelete(request)) {
				// TODO :
			}

		} else {
			  mAV.addObject(errors.getModel());
		}
		mAV.addObject("criminalSanctionOutcome", dto);
		return mAV;
	}

	/**
	 * Update Sanction Applied details depending on the outcome status
	 * 
	 * @param dto
	 */
	private void updateSanctionAppliedByStatus(SanctionOutcomeTO dto, HttpServletRequest request) {
		
		// Make sure that its unchecked depending on the outcome status.
		List<OutcomeAppliedSanction> appliedSanctions= dto.getOutcomeAppliedSanctions();
		List<OutcomeOrderSanction> orderSanctions = dto.getOutcomeOrders();
		
		if (appliedSanctions == null) {
			appliedSanctions = new ArrayList<OutcomeAppliedSanction>();
		}
		
		if (orderSanctions == null) {
			orderSanctions = new ArrayList<OutcomeOrderSanction>();
		}
		
		if (dto != null && dto.getOutcomeStatus() != null) {
			
			for (SanctionApplied sanctApp : dto.getSanctionsImposedList()) {
				if(dto.getOutcomeStatus().indexOf("UNSUCCESSFUL") != -1  && sanctApp.isChecked()) {
					sanctApp.setChecked(false);
				}
				else {
					String param = "_" + sanctApp.getSanctionName();
					String reqParam = request.getParameter(param);	
					if (reqParam != null && reqParam.equalsIgnoreCase("true")) {
						sanctApp.setChecked(true);
						appliedSanctions.add(createOutcomeSanction(dto, sanctApp));						
					}					
				}
			}
			for (SanctionApplied sanctApp : dto.getUnsuccessSanctionsImposedList()) {
				if(dto.getOutcomeStatus().indexOf("UNSUCCESSFUL") == -1 && sanctApp.isChecked()) {					
					sanctApp.setChecked(false);
					
				}
				else {
					String param = "_" + sanctApp.getSanctionName();
					String reqParam = request.getParameter(param);	
					if (reqParam != null && reqParam.equalsIgnoreCase("true")) {
						sanctApp.setChecked(true);
						appliedSanctions.add(createOutcomeSanction(dto, sanctApp));
					}
				}
			}
			 				
		}
		// Orders..
		int orderCount=0;
		for (SanctionApplied order : dto.getOrdersImposedList()) {
			String param = "_" + order.getSanctionName();
			log.info("Order Imposed PARAM=" + param);
			String reqParam = request.getParameter(param);
			if (reqParam != null && reqParam.equalsIgnoreCase("true")) {
				log.info("\n #" + param + "= TRUE");
				order.setChecked(true);
				order.setSanctionCondition(request.getParameter("sanctionCondition"+ orderCount));
				orderSanctions.add(createOutcomeOrder(dto, order));
			}
			orderCount+=1;
		}
		
	}

	private OutcomeOrderSanction createOutcomeOrder(SanctionOutcomeTO dto, SanctionApplied sanctApp) {
		OutcomeOrderSanction outcomeOrder = new OutcomeOrderSanction();
		for (OutcomeOrderSanction orderSanction : dto.getOutcomeOrders()) {
			if (orderSanction.getSanctionOrder().equals(sanctApp.getSanctionName())) {
				outcomeOrder = orderSanction;
				break;
			}
		}
		outcomeOrder.setOutcomeId(dto.getOutcomeId());
		outcomeOrder.setSanctionOrder(sanctApp.getSanctionName());
		outcomeOrder.setSanctionCondition(sanctApp.getSanctionCondition());
		return outcomeOrder;
	}

	private OutcomeAppliedSanction createOutcomeSanction(SanctionOutcomeTO dto, SanctionApplied sanctApp) {
		
		OutcomeAppliedSanction appSanction = new OutcomeAppliedSanction();
		for (OutcomeAppliedSanction outcome: dto.getOutcomeAppliedSanctions()){
			if (outcome.getAppliedSanction().equals(sanctApp.getSanctionName())) {
				appSanction = outcome;
				break;
			}
		}
		appSanction.setOutcomeId(dto.getOutcomeId());
		appSanction.setSanctionType(CaseUtil.APPLIED_SANCTION_TYPE.CRIMINAL.toString());
		appSanction.setAppliedSanction(sanctApp.getSanctionName());
		return appSanction;
	}

	/**
	 * Redirection to the Criminal Sanction List View...
	 * 
	 * @return ModelAndView
	 */
	private ModelAndView getRedirectView(SanctionOutcomeTO dto) {

		if (dto != null && dto.getCriminalSanctionId() != null) {

			return new ModelAndView(new RedirectView(SANCTIONS_DETAILS_LINK
					+ dto.getCriminalSanctionId()));
		}
		return CaseUtil.getCriminalSanctionsListView();
	}

	/**
	 * Validate Sanction Outcome.
	 * 
	 * @param SanctionOutcome
	 * @param request
	 * @param errors
	 */
	private void validateSanctionOutcome(SanctionOutcomeTO dto,
			//HttpServletRequest request, BindException errors) {
			HttpServletRequest request, BindingResult errors) {
		
		if (null != dto.getAppliedCompensation() &&  !EcmsUtils.isValidNumber(dto.getAppliedCompensation().toString())) {
			errors
					.rejectValue("appliedCompensation", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != dto.getAppliedInvCost() && !EcmsUtils.isValidNumber(dto.getAppliedInvCost().toString())) {
			errors
					.rejectValue("appliedInvCost", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != dto.getAppliedProsCost() && !EcmsUtils.isValidNumber(dto.getAppliedProsCost().toString())) {
			errors
					.rejectValue("appliedProsCost", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != dto.getAwardedCompensation() && !EcmsUtils.isValidNumber(dto.getAwardedCompensation().toString())) {
			errors
					.rejectValue("awardedCompensation", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != dto.getAwardedProsCost() && !EcmsUtils.isValidNumber(dto.getAwardedProsCost().toString())) {
			errors
					.rejectValue("awardedProsCost", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != dto.getAwardedInvCost() && !EcmsUtils.isValidNumber(dto.getAwardedInvCost().toString())) {
			errors
					.rejectValue("awardedInvCost", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}

		log.info("SanctionOutcomeFormController.validateSanctionOutcome");
	}
	
	/**
	 * SETTERS FOR FACADE
	 * @param criminalSanctionFacade
	 */
	public void setCriminalSanctionFacade(
			CriminalSanctionService criminalSanctionFacade) {
		this.criminalSanctionFacade = criminalSanctionFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
	
	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			log.error(e);
		}
	}
	
	@InitBinder
	protected void initBinder(HttpServletRequest servletRequest,
			ServletRequestDataBinder binder) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("\n initBinder");
		}
		
		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, nf, true));
		binder
				.registerCustomEditor(String.class, new StringTrimmerEditor(
						true));
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null,
				new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}
	
}
