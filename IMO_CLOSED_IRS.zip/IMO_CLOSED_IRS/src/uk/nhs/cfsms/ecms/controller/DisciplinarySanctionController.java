package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppeal;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionView;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SubjectName;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryHearingTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryOffenceTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryOutcomeTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinarySanctionTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.DisciplinarySanctionService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * Disciplinary Sanction Controller handles the requests for the Disciplinary
 * Sanction for a particular Case.
 * 
 */
@Controller
public class DisciplinarySanctionController extends BaseBinderConfig {

	@Autowired
	private DisciplinarySanctionService disciplinarySanctionFacade;
	@Autowired
	private InformationGatherService informationGatherFacade;
	@Autowired
	private AuditLogService auditLogFacade;

	static final String HEARING_ID_PARAM = "hearingId";

	static final String OFFENCE_ID_PARAM = "offenceId";

	static final String OUTCOME_ID_PARAM = "outcomeId";

	static final String SHOW_SANCTIONS = "viewDisciplinarySanctions";

	static final String SHOW_HEARINGS = "viewDisciplinaryHearings";

	static final String SHOW_OUTCOMES = "viewDisciplinaryOutcomes";

	static final String SHOW_OFFENCE = "viewDisciplinaryOffence";

	static final String ADD_SANCTION = "addDisciplinarySanction";

	static final String ADD_HEARING = "addDisciplinaryHearing";

	static final String ADD_OUTCOME = "addDisciplinaryOutcome";

	static final String SHOW_SANCTIONS_PAGE = "showDisciplinarySanctions.htm";

	static final String SHOW_HEARINGS_PAGE = "showDisciplinaryHearings.htm&disciplinarySanctionId=";

	protected final Log log = LogFactory.getLog(getClass());

	/**
	 * Show Disciplinary Sanctions.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showDisciplinarySanctions.htm")
	public ModelAndView showDisciplinarySanctions(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		return showDisciplinarySanctionsWithErrors(request, response,
				new ArrayList<String>());
	}

	public ModelAndView showDisciplinarySanctionsWithErrors(
			HttpServletRequest request, HttpServletResponse response,
			List<String> errors) throws ServletException {

		log.info("showDisciplinarySanctions");
		List<DisciplinarySanctionTO> disciplinarySanctionTOs = new ArrayList<DisciplinarySanctionTO>();

		try {

			String caseID = CaseUtil.getCaseId(request);

			if (StringUtils.isEmpty(caseID)) {

				CaseUtil.logErrorCaseIDNotFound(log);

				return CaseUtil.getCasePortalView();
			}

			List<DisciplinarySanctionView> list = disciplinarySanctionFacade
					.loadSanctionViewListByCaseId(new Long(caseID));

			if (null != list && !list.isEmpty()) {

				disciplinarySanctionTOs = CaseUtil
						.convertDispSanctionViewToSanctionTOList(list);

				for (DisciplinarySanctionTO dispSanctionTO : disciplinarySanctionTOs) {
					dispSanctionTO
							.setAppealExist(hasAppealsForSanction(String
									.valueOf(dispSanctionTO
											.getDisciplinarySanctionId())));
				}
			}

			Map<String, Object> sanctionMap = new HashMap<String, Object>();
			sanctionMap.put(CaseUtil.DISCIPLINARY_SANCTIONS,
					disciplinarySanctionTOs);
			sanctionMap.put(CaseUtil.LIST_SIZE, list.size());
			sanctionMap.put(ECMSConstants.ERROR_MESSAGES, errors);
			return new ModelAndView(SHOW_SANCTIONS,
					CaseUtil.DISCIPLINARY_SANCTIONS_MAP, sanctionMap);

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * Delete Disciplinary Sanction Details
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/deleteDisciplinarySanction.htm")
	public ModelAndView deleteDisciplinarySanction(HttpServletRequest request,
			HttpServletResponse response, DisciplinarySanctionTO dispTO)
			throws ServletException {

		String dSID = request.getParameter(CaseUtil.DISCIPLINARY_SANCTION_ID);

		try {

			if (!StringUtils.isEmpty(dSID)) {

				if (hasAppealsForSanction(dSID)) {
					List<String> errorList = new ArrayList<String>();
					errorList.add("Appeal exists for this sanction.");
					errorList
							.add("Please remove the dependencies and repeat this action in order to continue.");

					return showDisciplinarySanctionsWithErrors(request,
							response, errorList);
				}

				AuditFlowThread.set("Disciplinary Sanction Deleted");
				disciplinarySanctionFacade.deleteDisciplinarySanction(new Long(
						dSID));
				createAudit(new String(" Delete DisciplinarySanction ID ="
						+ dSID), AuditLogService.DELETE,
						"Disciplinary Sanction", request, auditLogFacade);
			}

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(SHOW_SANCTIONS_PAGE));
	}

	private boolean hasAppealsForSanction(String sanctionId)
			throws ServiceException {

		List<DisciplinaryAppeal> appealsList = disciplinarySanctionFacade
				.loadAppealsByParentSanctionId(new Long(sanctionId));

		if (null != appealsList && appealsList.size() > 0) {

			return true;
		}
		return false;
	}

	/**
	 * Disciplinary Sanction Details
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/disciplinarySanctionDetails.htm")
	public ModelAndView disciplinarySanctionDetails(HttpServletRequest request,
			HttpServletResponse response, DisciplinarySanctionTO dispTO)
			throws ServletException {

		String caseID = null;
		InformationTO infoTO = null;
		DisciplinarySanctionTO dispSanctionTO = null;
		Map<String, Object> sanctionMap = new HashMap<String, Object>();

		String sanctionID = request
				.getParameter(CaseUtil.DISCIPLINARY_SANCTION_ID);

		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		if (StringUtils.isEmpty(caseID)) {
			CaseUtil.logErrorCaseIDNotFound(log);
			return CaseUtil.getCasePortalView();
		}

		if (dispTO == null) {

			dispSanctionTO = new DisciplinarySanctionTO();
		} else {
			dispSanctionTO = dispTO;
		}
		dispSanctionTO.setCaseId(new Long(caseID));

		try {
			if (!StringUtils.isEmpty(sanctionID)) {

				dispSanctionTO = disciplinarySanctionFacade
						.loadDisciplinarySanction(new Long(sanctionID));

				dispSanctionTO
						.setAppealExist(hasAppealsForSanction(sanctionID));
			}

			infoTO = informationGatherFacade.loadInformationByCaseId(new Long(
					caseID));

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}
		List<SubjectName> subjectList = getSubjectsFromInformation(infoTO);

		if (null == subjectList
				|| (null != subjectList && subjectList.isEmpty())) {

			// No subjects for this case.
			sanctionMap.put(ECMSConstants.ERROR_MESSAGES,
					ECMSConstants.NO_SUBJECTS);

			return new ModelAndView(SHOW_SANCTIONS,
					CaseUtil.DISCIPLINARY_SANCTIONS_MAP, sanctionMap);
		}

		sanctionMap.put(CaseUtil.DISCIPLINARY_SANCTION, dispSanctionTO);
		sanctionMap.put(CaseUtil.SANCTION_SUBJECTS, subjectList);
		// sanctionMap.put(CaseUtil.CONTACT_LIST, contactList);

		return new ModelAndView(ADD_SANCTION,
				CaseUtil.DISCIPLINARY_SANCTION_MAP, sanctionMap);
	}

	/**
	 * Get all subjects from Information.
	 * 
	 * @param infoTO
	 *            InformationTO
	 * @return List List<SubjectName>
	 */
	private List<SubjectName> getSubjectsFromInformation(InformationTO infoTO) {

		List<SubjectName> subjectList = CaseUtil.getAllSubjectList(infoTO);

		return subjectList;
	}

	/**
	 * Save Disciplinary Sanction.
	 * 
	 * @param request
	 * @param response
	 * @param dispTO
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveDisciplinarySanction.htm")
	public ModelAndView saveDisciplinarySanction(HttpServletRequest request,
			HttpServletResponse response, DisciplinarySanctionTO dispTO)
			throws ServletException {

		DisciplinarySanctionTO dispSanctionTO = dispTO;

		if (dispSanctionTO.getCaseId() == null) {
			String caseID = null;
			try {
				caseID = CaseUtil.getCaseId(request);
			} catch (CaseIDNotFoundException e) {
				logger.info(e);
			}
			dispSanctionTO.setCaseId(new Long(caseID));
		}

		if (dispSanctionTO.getDisciplinarySanctionId() == null) {

			dispSanctionTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId());
			dispSanctionTO.setCreatedTime(new Date(System.currentTimeMillis()));
			dispSanctionTO.setState(CaseUtil.ONGOING_STATUS);
		}

		try {

			if (dispSanctionTO.getDisciplinarySanctionId() == null) {
				AuditFlowThread.set("Disciplinary Sanction Created");
			} else {
				AuditFlowThread.set("Disciplinary Sanction Updated");
			}
			disciplinarySanctionFacade.saveDisciplinarySanction(dispSanctionTO);
			createAudit(dispSanctionTO, AuditLogService.CREATE,
					"Disciplinary Sanction", request, auditLogFacade);

		} catch (ServiceException se) {
			log.error(se);
			throw new ServletException(se);
		}

		return new ModelAndView(new RedirectView(SHOW_SANCTIONS_PAGE));
	}

	/**
	 * Disciplinary Sanction Hearings
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showDisciplinaryHearings.htm")
	public ModelAndView showDisciplinaryHearings(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		log.info("showDisciplinaryHearings");

		List<DisciplinarySanctionHearing> list = new ArrayList<DisciplinarySanctionHearing>();

		try {

			String sanctionID = request
					.getParameter(CaseUtil.DISCIPLINARY_SANCTION_ID);

			if (!StringUtils.isEmpty(sanctionID)) {

				list = disciplinarySanctionFacade
						.loadDisciplinaryHearingList(new Long(sanctionID));

				if (log.isInfoEnabled()) {
					log.info("List<showDisciplinaryHearings> SIZE ="
							+ list.size());
				}
			}

			Map<String, Object> hearingMap = new HashMap<String, Object>();
			hearingMap.put(CaseUtil.DISCIPLINARY_HEARINGS, list);
			hearingMap.put(CaseUtil.LIST_SIZE, list.size());
			hearingMap.put(CaseUtil.DISCIPLINARY_SANCTION_ID, sanctionID);

			return new ModelAndView(SHOW_HEARINGS,
					CaseUtil.DISCIPLINARY_HEARINGS_MAP, hearingMap);

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * Disciplinary Sanction Offences
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showDisciplinaryOffences.htm")
	public ModelAndView showDisciplinaryOffences(HttpServletRequest request,
			HttpServletResponse response, DisciplinaryOffenceTO dispTO)
			throws ServletException {

		log.info("showDisciplinaryOffences");

		DisciplinaryOffenceTO dispOffenceTO = dispTO;

		try {

			String sanctionID = request
					.getParameter(CaseUtil.DISCIPLINARY_SANCTION_ID);

			if (!StringUtils.isEmpty(sanctionID)) {

				dispOffenceTO = disciplinarySanctionFacade
						.loadDisciplinaryOffence(new Long(sanctionID));

				if (dispOffenceTO == null
						|| (dispOffenceTO != null && dispOffenceTO
								.getOffenceId() == null)) {

					dispOffenceTO = new DisciplinaryOffenceTO();
					dispOffenceTO
							.setDisciplinarySanctionId(new Long(sanctionID));
				}
			}

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		Map<String, Object> offenceMap = new HashMap<String, Object>();
		offenceMap.put(CaseUtil.DISCIPLINARY_OFFENCE, dispOffenceTO);

		return new ModelAndView(SHOW_OFFENCE,
				CaseUtil.DISCIPLINARY_OFFENCE_MAP, offenceMap);

	}

	/**
	 * Disciplinary Sanction Outcome
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showDisciplinarySanctionOutcome.htm")
	public ModelAndView showDisciplinaryOutcome(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		log.info("showDisciplinaryOutcome");

		DisciplinaryOutcomeTO outcomeTO = null;

		DisciplinarySanctionTO sanction = null;

		String sanctionID = request
				.getParameter(CaseUtil.DISCIPLINARY_SANCTION_ID);

		try {

			if (!StringUtils.isEmpty(sanctionID)) {

				outcomeTO = disciplinarySanctionFacade
						.loadDisciplinaryOutcomeBySanctionId(new Long(
								sanctionID));

				if (outcomeTO == null) {
					outcomeTO = new DisciplinaryOutcomeTO();
				}
				outcomeTO.setDisciplinarySanctionId(new Long(sanctionID));
				sanction = disciplinarySanctionFacade
						.loadDisciplinarySanction(new Long(sanctionID));

				outcomeTO.setLookupImposedList(disciplinarySanctionFacade
						.loadSanctionImposedTypes(sanction.getSanctionType()));
				outcomeTO.setDispType(sanction.getSanctionType());
				outcomeTO.setSanctionType(sanction.getSanctionType());
				setSanctionImposedList(outcomeTO);
			}

			Map<String, Object> sanctionMap = new HashMap<String, Object>();
			sanctionMap.put(CaseUtil.DISCIPLINARY_OUTCOME, outcomeTO);

			return new ModelAndView(ADD_OUTCOME,
					CaseUtil.DISCIPLINARY_OUTCOME_MAP, sanctionMap);

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * Disciplinary Sanction Hearing
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/disciplinaryHearingDetails.htm")
	public ModelAndView disciplinaryHearingDetails(HttpServletRequest request,
			HttpServletResponse response, DisciplinaryHearingTO dispTO)
			throws ServletException {

		log.info("disciplinaryHearingDetails");

		DisciplinaryHearingTO dispHearingTO = dispTO;

		String sanctionID = request
				.getParameter(CaseUtil.DISCIPLINARY_SANCTION_ID);

		String hearingID = request.getParameter(HEARING_ID_PARAM);

		try {

			if (StringUtils.isEmpty(hearingID)) {

				dispHearingTO = new DisciplinaryHearingTO();

				if (!StringUtils.isEmpty(sanctionID)) {

					dispHearingTO
							.setDisciplinarySanctionId(new Long(sanctionID));
				}
			}

			if (StringUtils.isNotEmpty(hearingID)) {

				dispHearingTO = disciplinarySanctionFacade
						.loadDisciplinaryHearing(new Long(hearingID));
			}

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		Map<String, Object> sanctionMap = new HashMap<String, Object>();
		sanctionMap.put(CaseUtil.DISCIPLINARY_HEARING, dispHearingTO);

		return new ModelAndView(ADD_HEARING, CaseUtil.DISCIPLINARY_HEARING_MAP,
				sanctionMap);
	}

	/**
	 * Disciplinary Sanction Outcome
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/disciplinaryOutcomeDetails.htm")
	public ModelAndView disciplinaryOutcomeDetails(HttpServletRequest request,
			HttpServletResponse response, DisciplinaryOutcomeTO dispTO)
			throws ServletException {

		log.info("disciplinaryOutcomeDetails");

		DisciplinarySanctionTO sanction = null;

		DisciplinaryOutcomeTO dispOutcomeTO = dispTO;

		String sanctionID = request
				.getParameter(CaseUtil.DISCIPLINARY_SANCTION_ID);

		String outcomeID = request.getParameter(OUTCOME_ID_PARAM);

		try {

			if (StringUtils.isEmpty(outcomeID)) {

				dispOutcomeTO = new DisciplinaryOutcomeTO();

				if (StringUtils.isNotEmpty(sanctionID)) {

					dispOutcomeTO
							.setDisciplinarySanctionId(new Long(sanctionID));

					sanction = disciplinarySanctionFacade
							.loadDisciplinarySanction(new Long(sanctionID));
				}
			}
			if (!StringUtils.isEmpty(outcomeID)) {

				dispOutcomeTO = disciplinarySanctionFacade
						.loadDisciplinaryOutcome(new Long(outcomeID));

			}

			if (null == sanction) {
				sanction = new DisciplinarySanctionTO();
			}
			dispOutcomeTO.setLookupImposedList(disciplinarySanctionFacade
					.loadSanctionImposedTypes(sanction.getSanctionType()));
			dispOutcomeTO.setDispType(sanction.getSanctionType());
			setSanctionImposedList(dispOutcomeTO);
			dispOutcomeTO.setSanctionType(sanction.getSanctionType());

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		Map<String, Object> sanctionMap = new HashMap<String, Object>();
		sanctionMap.put(CaseUtil.DISCIPLINARY_OUTCOME, dispOutcomeTO);

		return new ModelAndView(ADD_OUTCOME, CaseUtil.DISCIPLINARY_OUTCOME_MAP,
				sanctionMap);
	}

	/**
	 * Save Disciplinary Hearing.
	 * 
	 * @param request
	 * @param response
	 * @param hearingTO
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveDisciplinaryHearing.htm")
	public ModelAndView saveDisciplinaryHearing(HttpServletRequest request,
			HttpServletResponse response, DisciplinaryHearingTO hearingTO)
			throws ServletException {

		log.info("saveDisciplinaryHearing");

		DisciplinaryHearingTO dispHearingTO = hearingTO;

		try {
			if (null == dispHearingTO.getHearingId()) {

				dispHearingTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
						request.getSession()).getStaffId());
				dispHearingTO.setCreatedTime(new Date(System
						.currentTimeMillis()));
			}

			if (null == dispHearingTO.getHearingId()) {
				AuditFlowThread.set("Disciplinary Sanction Hearing Created");
			} else {
				AuditFlowThread.set("Disciplinary Sanction Hearing Updated");
			}
			disciplinarySanctionFacade.saveDisciplinaryHearing(dispHearingTO);

			createAudit(dispHearingTO, AuditLogService.UPDATE,
					"Disciplinary Hearing", request, auditLogFacade);

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(SHOW_SANCTIONS_PAGE));
	}

	/**
	 * Save Disciplinary Offence.
	 * 
	 * @param request
	 * @param response
	 * @param offenceTO
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveDisciplinaryOffence.htm")
	public ModelAndView saveDisciplinaryOffence(HttpServletRequest request,
			HttpServletResponse response, DisciplinaryOffenceTO offenceTO)
			throws ServletException {

		log.info("saveDisciplinaryOffence");
		DisciplinaryOffenceTO dispOffenceTO = offenceTO;

		try {
			if (null == dispOffenceTO.getOffenceId()) {

				dispOffenceTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
						request.getSession()).getStaffId());
				dispOffenceTO.setCreatedTime(new Date(System
						.currentTimeMillis()));
			}

			if (null == dispOffenceTO.getOffenceId()) {
				AuditFlowThread.set("Disciplinary Sanction Offence Created");
			} else {
				AuditFlowThread.set("Disciplinary Sanction Offence Updated");
			}
			disciplinarySanctionFacade.saveDisciplinaryOffence(dispOffenceTO);
			createAudit(dispOffenceTO, AuditLogService.UPDATE,
					"Disciplinary Offence", request, auditLogFacade);

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(SHOW_SANCTIONS_PAGE));
	}

	/**
	 * Save Disciplinary Outcome.
	 * 
	 * @param request
	 * @param response
	 * @param outcomeTO
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveDisciplinaryOutcome.htm")
	public ModelAndView saveDisciplinaryOutcome(HttpServletRequest request,
			HttpServletResponse response, DisciplinaryOutcomeTO outcomeTO)
			throws ServletException {

		log.info("saveDisciplinaryOutcome");
		
		final String sanctionType = request.getParameter("sanctionType");

		DisciplinaryOutcomeTO dispOutcomeTO = outcomeTO;
		try {

			if (null == dispOutcomeTO.getOutcomeId()) {

				dispOutcomeTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
						request.getSession()).getStaffId());
				dispOutcomeTO.setCreatedTime(new Date(System
						.currentTimeMillis()));
			}
			if (null == dispOutcomeTO.getOutcomeId()) {
				AuditFlowThread.set("Disciplinary Sanction Outcome Created");
			} else {
				AuditFlowThread.set("Disciplinary Sanction Outcome Updated");
			}
			if (null == dispOutcomeTO.getLookupImposedList()) {
				dispOutcomeTO.setLookupImposedList(disciplinarySanctionFacade
						.loadSanctionImposedTypes(sanctionType));
			}
			setAppliedSanctionList(request, dispOutcomeTO);

			disciplinarySanctionFacade.saveDisciplinaryOutcome(dispOutcomeTO);
			createAudit(dispOutcomeTO, AuditLogService.UPDATE,
					"Disciplinary Outcome", request, auditLogFacade);

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(SHOW_SANCTIONS_PAGE));
	}

	/**
	 * Delete Disciplinary Sanction Outcome
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/deleteDisciplinaryOutcome.htm")
	public ModelAndView deleteDisciplinarySanctionOutcome(
			HttpServletRequest request, HttpServletResponse response,
			DisciplinarySanctionTO dispTO) throws ServletException {

		log.info("deleteDisciplinaryOutcome");

		String dOID = request.getParameter(OUTCOME_ID_PARAM);

		try {

			if (StringUtils.isNotEmpty(dOID)) {

				AuditFlowThread.set("Disciplinary Sanction Outcome Deleted");

				disciplinarySanctionFacade.deleteDisciplinaryOutcome(new Long(
						dOID));
				createAudit(new String(
						"Delete DisciplinarySanction Outcome ID =" + dOID),
						AuditLogService.DELETE,
						"Disciplinary Sanction Outcome", request,
						auditLogFacade);
			}
		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(SHOW_SANCTIONS_PAGE));
	}

	/**
	 * Delete Disciplinary Sanction Hearing
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/deleteDisciplinaryHearing.htm")
	public ModelAndView deleteDisciplinarySanctionHearing(
			HttpServletRequest request, HttpServletResponse response,
			DisciplinarySanctionTO dispTO) throws ServletException {

		log.info("deleteDisciplinarySanctionHearing");

		String dHID = request.getParameter(HEARING_ID_PARAM);

		try {

			if (!StringUtils.isEmpty(dHID)) {
				AuditFlowThread.set("Disciplinary Sanction Hearing Deleted");

				disciplinarySanctionFacade.deleteDisciplinaryHearing(new Long(
						dHID));

				createAudit("Delete DisciplinarySanction Hearing ID =" + dHID,
						AuditLogService.DELETE,
						"Disciplinary Sanction Hearing", request,
						auditLogFacade);
			}
		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(SHOW_SANCTIONS_PAGE));
	}

	public void setSanctionImposedList(DisciplinaryOutcomeTO outcomeTO) {

		List<OutcomeAppliedSanction> list = outcomeTO
				.getOutcomeAppliedSanctions();

		for (OutcomeAppliedSanction item : list) {

			setSelectedListItem(item, outcomeTO.getLookupImposedList());
		}
	}

	private void setSelectedListItem(OutcomeAppliedSanction sanction,
			List<LookupView> list) {

		for (LookupView view : list) {

			String description = view.getDescription();
			String appliedSanction = sanction.getAppliedSanction();

			if (StringUtils.isNotBlank(description)
					&& StringUtils.isNotBlank(appliedSanction)
					&& StringUtils.equalsIgnoreCase(description,
							appliedSanction)) {

				view.setSelected(true);
			}
		}
	}

	private void setAppliedSanctionList(HttpServletRequest request,
			DisciplinaryOutcomeTO outcomeTO) {

		List<OutcomeAppliedSanction> sanType = new ArrayList<OutcomeAppliedSanction>();

		if (null != outcomeTO.getLookupImposedList()) {

			for (int i = 0; i < outcomeTO.getLookupImposedList().size(); i++) {

				String param = "checkedappliedsanction" + (i);
				String value = "valueappliedsanction" + (i);

				String requestParamValue = request.getParameter(param);

				if (null != requestParamValue
						&& StringUtils.equalsIgnoreCase(requestParamValue,
								"true")) {

					OutcomeAppliedSanction sanction = new OutcomeAppliedSanction();
					sanction.setOutcomeId(outcomeTO.getOutcomeId());
					sanction.setAppliedSanction(request.getParameter(value));
					sanction.setSanctionType("DISCIPLINARY");
					sanType.add(sanction);
				}
			}
		}

		outcomeTO.setOutcomeAppliedSanctions(sanType);
	}

	/**
	 * Setter for Disciplinary Sanction Facade
	 * 
	 * @param disciplinarySanctionFacade
	 */
	public void setDisciplinarySanctionFacade(
			DisciplinarySanctionService disciplinarySanctionFacade) {

		this.disciplinarySanctionFacade = disciplinarySanctionFacade;
	}

	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {

		this.informationGatherFacade = informationGatherFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {

		this.auditLogFacade = auditLogFacade;
	}
}
