package uk.nhs.cfsms.ecms.controller;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.bind.annotation.RequestMapping;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.CaseAssigneeTO;
import uk.nhs.cfsms.ecms.data.cim.CasePermission;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.dto.user.UserObjectTo;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseAssigneeService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
public class CaseAssigneeController {

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CaseAssigneeService caseAssigneeFacade;

	static final String LIST_ASSIGNEE_PAGE = "caseassignee.htm";

	@RequestMapping(value="/secure/caseassignee.htm")
	public ModelAndView listCaseAssignee(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException {
		
		logger.info("\n List Case Assignee");
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		List<CaseAssigneeTO> assigneeList = null;
		String caseId = null;
		try {
			caseId = CaseUtil.getCaseId(request);
		
			assigneeList = caseAssigneeFacade.loadAssigneeByCaseId(
					new Long(caseId));
			
		} catch (Exception e) {
			logger.error("Error loading & list CaseAssignees" + e);
			throw new ServletException(e);
		}

		Map<String, Object> assigneeMap = new HashMap<String, Object>();
		assigneeMap.put("assigneeList", assigneeList);
		
		if (user.isUserOFM()) {
			assigneeMap.put("user", "OFM");
		}
		else if (user.isUserAntiFraudLead()) {
			assigneeMap.put("user", "AFL");
		}
		else if (user.isUserLCFS() && 
				isUserLeadAssignee(assigneeList, user.getStaffId())) {
			
			assigneeMap.put("user", "LeadLCFS");
		}
		else {
			assigneeMap.put("user", "USER");
		}
		return new ModelAndView("assigneelist", "assigneeMap", assigneeMap);

	}

	@RequestMapping(value="/secure/deleteassignee.htm")
	public ModelAndView deleteCaseAssignee(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		AuditFlowThread.set("Case Assignee Deleted");
		try {
			String permissionId = request.getParameter("permissionId");
			
			caseAssigneeFacade.deletCaseAssignee(new Long(permissionId));
			createAudit("Delete Case Assignee for permissionId=" + permissionId,
					AuditLogService.DELETE, "Case Assignee", request,
					auditLogFacade);
					
		} catch (ServiceException se) {
			logger.error(se);
			throw new ServletException(se);
		}

		return new ModelAndView(new RedirectView(LIST_ASSIGNEE_PAGE));
		
	}

	@RequestMapping(value="/secure/saveassignee.htm")
	public ModelAndView saveCaseAssignee(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		String caseID = null;
	    AuditFlowThread.set("Case Assignee Created");
		try {
			caseID = CaseUtil.getCaseId(request);
	 
			String assigneeType = request.getParameter("assigneeType");
			String assigneeStaffId = request.getParameter("assigneeStaffId");
			CaseAssigneeTO assignee = new CaseAssigneeTO();
			CasePermission perm = new CasePermission();
			perm.setCaseId(new Long(caseID));
			perm.setCreatedStaffId(user.getStaffId());
			perm.setPermissionType(assigneeType);
			perm.setValue(assigneeStaffId);
			perm.setCreatedTime(new Date());
			perm.setStatus("Y");
			assignee.setCasePermission(perm);
			caseAssigneeFacade.saveCaseAssignee(assignee);
			
			createAudit(assignee, AuditLogService.CREATE, "Case Assignee", request, auditLogFacade);		

		} catch (Exception e) {
			throw new ServletException(e);
		}

		return new ModelAndView(new RedirectView(LIST_ASSIGNEE_PAGE));

	}

	@RequestMapping(value="/secure/updateassignee.htm")
	public ModelAndView updateCaseAssignee(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
	    AuditFlowThread.set("Case Assignee Updated");
		try {
			String permissionId = request.getParameter("permissionId");
			String assigneeType = request.getParameter("assigneeType");

			CasePermission perm = caseAssigneeFacade
					.loadCasePermission(new Long(permissionId));
			perm.setPermissionType(assigneeType);

			caseAssigneeFacade.upddateCasePermission(perm);
			createAudit(perm, AuditLogService.UPDATE, "Case Assignee", request, auditLogFacade);
			
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		return new ModelAndView(new RedirectView(LIST_ASSIGNEE_PAGE));

	}

	@RequestMapping(value="/secure/viewassignee.htm")
	public ModelAndView viewCaseAssignee(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		
		String caseId = null;

		//SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		String permissionId = request.getParameter("permissionId");
		
		try {
			caseId = CaseUtil.getCaseId(request);
			CaseAssigneeTO assignee = caseAssigneeFacade.loadAssigneeByPermissionId(new Long(permissionId));
			Map<String, Object> assigneeMap = new HashMap<String, Object>();
			assigneeMap.put("isNewAssignee", "NO");
			assigneeMap.put("assignee", assignee);

			this.updateAssigneeMapForUniqueRoles(assigneeMap, caseId);

			return new ModelAndView("addassignee", "assigneeMap", assigneeMap);
			
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}

	}

	/**
	 * Helper method.
	 * @param assigneeMap
	 * @param caseId
	 * @throws ServiceException
	 */
	private void updateAssigneeMapForUniqueRoles(Map<String, Object> assigneeMap,
			String caseId) throws ServiceException {

		List<CaseAssigneeTO> assigneeList = caseAssigneeFacade.loadAssigneeByCaseId(new Long(caseId));
				
		if (isLeadAssigneeExists(assigneeList)) {
			assigneeMap.put("leadExists", "YES");
		} else {
			assigneeMap.put("leadExists", "No");
		}
		
		if (isSIOAssigneeExists(assigneeList)) {
			assigneeMap.put("sioExists", "YES");
		} else {
			assigneeMap.put("sioExists", "No");
		}
		
	}

	@RequestMapping(value="/secure/addassignee.htm")
	public ModelAndView addCaseAssignee(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
	
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		
		List<CaseAssigneeTO> assigneeList = null;
		
		String caseId = null;
		
		List<UserObjectTo> userList = null;
		
		try {
			caseId = CaseUtil.getCaseId(request);
			
			Long caseID = new Long(caseId);
			
			assigneeList = caseAssigneeFacade.loadAssigneeByCaseId(caseID);
 
			// User must not be NIT AFL or WARO OFM and is LSDS or LCFS...	
			if (this.isUserLeadAssignee(assigneeList, user.getStaffId()) 
					 && (user.isUserAntiFraudSpecialist() || user.isUserLCFS())) {
				
				userList = caseAssigneeFacade.loadNewAssigneesByCaseOrgCode(caseID, 
						this.getCurrentAssignees(assigneeList));
			}
			else {
				userList = caseAssigneeFacade.loadUsersByTeamCodes(
					CaseUtil.getTeamCodesFromResponsibilities(
							user.getUserResponsibilities()), caseID);
			}
			Map<String, Object> assigneeMap = new HashMap<String, Object>();
			Collections.sort(userList);
			assigneeMap.put("userList", userList);
			assigneeMap.put("caseId", caseId);
			assigneeMap.put("isNewAssignee", "YES");
			
			this.updateAssigneeMapForUniqueRoles(assigneeMap, caseId); 
			
			return new ModelAndView("addassignee", "assigneeMap", assigneeMap);
	
		}catch (Exception e) {
			logger.error("ERROR while adding case Assignee "+  e);
			throw new ServletException(e);
		}
	}
	
	
	private List<String> getCurrentAssignees(List<CaseAssigneeTO> assigneeList) {
		
		List<String> currentList = new ArrayList<String>();
		
		for (CaseAssigneeTO assignee : assigneeList) {
			
			CasePermission perm = assignee.getCasePermission();
			
			if (null != perm && 
					(ECMSConstants.CASE_ASSIGNEE_PERMISSION.equals(perm.getPermissionType()) || 
					ECMSConstants.ASSIGNEE_PERMISSION.equals(perm.getPermissionType()))) {
				
				currentList.add(perm.getValue());				
			}			
		}
		return currentList;
	}


	private boolean isLeadAssigneeExists(List<CaseAssigneeTO> assigneeList) {
		
		return this.isAssigneeType(assigneeList, ECMSConstants.ASSIGNEE_PERMISSION, null);
	}
	
	
	private boolean isSIOAssigneeExists(List<CaseAssigneeTO> assigneeList) {
		
		return this.isAssigneeType(assigneeList, ECMSConstants.SENIOR_INVESTIGATING_OFFICER_PERMISSION, null);
	}
	
	private boolean isUserLeadAssignee(List<CaseAssigneeTO> assigneeList, String staffId) {
		
		return this.isAssigneeType(assigneeList, ECMSConstants.ASSIGNEE_PERMISSION, staffId);
	}
	
	
	/**
	 * Helper method, check assigneeType from a list or user is a known assignee type.
	 * 
	 * @param assigneeList
	 * @param assigneeType
	 * @param staffId
	 * @return
	 */
	private boolean isAssigneeType(List<CaseAssigneeTO> assigneeList, String assigneeType, String staffId) {
		
		for (CaseAssigneeTO assignee : assigneeList) {
			
			CasePermission perm = assignee.getCasePermission();
			
			String permType = perm.getPermissionType();
			
			if  (logger.isDebugEnabled()) {
				
				logger.debug("permType=" +permType +", permValue=" + 
						perm.getValue() + ",assigneeType=" + assigneeType + ", staffId=" + staffId);
			}
			
			if (null != permType && null != assigneeType && 
					assigneeType.equalsIgnoreCase(permType) && (null == staffId || 
					(null != staffId && staffId.equalsIgnoreCase(perm.getValue())))) {
				
				return true;
			}
		}
		return false;
	}
			
	

	/**
	 * Setters for the Facade Service layer
	 * 
	 * @param caseAssigneeFacade
	 */
	public void setCaseAssigneeFacade(CaseAssigneeService caseAssigneeFacade) {
	
		this.caseAssigneeFacade = caseAssigneeFacade;
	}
	
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		
		this.auditLogFacade = auditLogFacade;
	}

	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			logger.error(e);
		}
	}
	
}
