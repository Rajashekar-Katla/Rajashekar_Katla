package uk.nhs.cfsms.ecms.controller;

import static uk.nhs.cfsms.ecms.ECMSConstants.ACEGI_SECURITY;
import static uk.nhs.cfsms.ecms.ECMSConstants.PASSWORD_MD5_COMPLAINT;
import static uk.nhs.cfsms.ecms.ECMSConstants.SESSION_USER_DETAILS;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.data.authentication.Users;
import uk.nhs.cfsms.ecms.data.common.UserHistory;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.dto.user.User;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.ChangePasswordService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

@Controller
public class ChangePasswordController {
	
	@Autowired
	AuditLogService auditLogFacade;
	@Autowired
	ChangePasswordService changePasswordFacade;

	protected final Log log = LogFactory.getLog(getClass());

	public static final String errorMesg = "Please enter a different password that meets all of the following criteria: is at least 8 characters long, has not been used in the previous password and contains at least three of the following four character types: lower case letter, upper case letter, number, and a special character such as !#�$.";

	@RequestMapping(value = "/secure/changePassword.htm", params = { "!newPassword" })
	public ModelAndView forwardToView(HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("userObject") User user) throws Exception {
		ModelAndView mAV = new ModelAndView("changePassword");

		return mAV.addObject("userObject", user);
	}

	/**
	 * Method to Change Password for the first time users
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/changePassword.htm", params = { "newPassword" })
	public ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("userObject") User user, 
			BindingResult errors) throws Exception {
		
		ModelAndView mavFcrl = new ModelAndView("fcrlwelcome");
		ModelAndView mavWel = new ModelAndView("welcome"); 
		// User user = (User) command; 
		HttpSession session = request.getSession();
		SessionUser sUser = (SessionUser) session.getAttribute(SESSION_USER_DETAILS);
		
		String staffId = (String) session.getAttribute(ACEGI_SECURITY);
 
		if (log.isDebugEnabled()) {
			log.debug("\n User old pass: " + user.getPassword());
			log.debug(", User New Pass: " + user.getNewPassword());
		}

		validatePassword(user, staffId, errors);

		if (null != errors && errors.getErrorCount() > 0) {
			if (log.isDebugEnabled()) {
				log.debug("\n has errrors");
			}
			/*
			 * return super.processFormSubmission(request, response, command,
			 * errors);
			 */
			if (sUser.isUserFCRL()) {
				mavFcrl.addObject(errors.getModel());
			} else {
				mavWel.addObject(errors.getModel());
			}
		}
		try {
			if ("Y".equals(PASSWORD_MD5_COMPLAINT)) {

				changePasswordFacade.changePassword(staffId,
						EcmsUtils.convertPwdTomd5(user.getNewPassword()));
			} else {

				changePasswordFacade.changePassword(staffId,
						user.getNewPassword());
			}
			request.setAttribute("PASSWORDCHANGED", "TRUE");

		} catch (Exception e) {

			log.error("Unable to change the password :" + e.getMessage());
		}

		UserHistory history = changePasswordFacade.loadUserHistory(staffId);

		if (null != history) {

			history.setPasswordUpdatedOn(new Date());
			changePasswordFacade.updateUserHistory(history);
		}

		auditLogFacade.save(staffId + " Password Changed Successfully",
				AuditLogService.RESET_PWD, staffId, 0);

		// Check for User is FCRL.

		if (sUser.isUserFCRL()) {

			return mavFcrl;

		} else {

			return mavWel;
		}
	}

	private void validatePassword(User user, String staffId,
			BindingResult errors) {

		if (log.isInfoEnabled()) {
			log.info("validatePassword...");
		}

		Users baseUser = changePasswordFacade.loadUser(staffId);
		String newPasswd = user.getNewPassword();

		if (null == newPasswd || null == user.getRetypePassword()) {

			errors.rejectValue("newPassword", "invalid.password", errorMesg);
		}

		if (null != newPasswd
				&& EcmsUtils.convertPwdTomd5(newPasswd).equals(
						baseUser.getPassword()) || newPasswd.length() < 8) {

			errors.rejectValue("newPassword", "invalid.password", errorMesg);
		}

		int count = 0;
		String[] partialRegexChecks = { ".*[a-z]+.*", // lower
				".*[A-Z]+.*", // upper
				".*[\\d]+.*", // digits
				".*[@#$%]+.*" // symbols
		};

		if (newPasswd.matches(partialRegexChecks[0])) {
			count = count + 1;
		}
		if (newPasswd.matches(partialRegexChecks[1])) {
			count = count + 1;
		}
		if (newPasswd.matches(partialRegexChecks[2])) {
			count = count + 1;
		}
		if (newPasswd.matches(partialRegexChecks[3])) {
			count = count + 1;
		}

		// log.info("count : "+count);
		if (count < 3) {
			log.info("Password pattern do not match");
			errors.rejectValue("newPassword", "invalid.password", errorMesg);
		}
	}

	/**
	 * Setter for the ChangePasswordFacade
	 * 
	 * @param changePasswordFacade
	 */
	public void setChangePasswordFacade(
			ChangePasswordService changePasswordFacade) {

		this.changePasswordFacade = changePasswordFacade;
	}

	/**
	 * Audit Log
	 * 
	 * @param auditLogFacade
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {

		this.auditLogFacade = auditLogFacade;
	}

}
