package uk.nhs.cfsms.ecms.controller;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.dto.caseInfo.CourtAppearanceTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.AppealOutcomeTO;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CourtAppearanceService;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * Court Appearance Form Controller is for Court Appearance from sanctions.
 * 
 * @author sChilukuri
 * 
 */
@Controller
public class CourtAppearanceFormController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CourtAppearanceService courtAppearanceFacade;
	@Autowired
	private LookupViewService lookupViewFacade;

	//private static final String VIEW_COURT_APPEARANCES_LINK = "showCourtAppearances.htm";
	

	public CourtAppearanceFormController() {
		
		//setSessionForm(true);
		/*setCommandName("courtAppearance");
		setCommandClass(CourtAppearanceTO.class);*/
	}

	@RequestMapping(value="/secure/createCourtAppearance.htm")
	protected ModelAndView formBackingObject(HttpServletRequest request)
			throws Exception {
		ModelAndView mAV = new ModelAndView("courtAppearance");
		log.info("formBackingObject().");

		String sanctionID = request.getParameter(CaseUtil.SANCTION_ID_PARAM);
		String sanctionType = request.getParameter(CaseUtil.SANCTION_TYPE);

		if (StringUtils.isEmpty(sanctionID)) {
			log.error("No " + CaseUtil.SANCTION_ID_PARAM + " found.");
		}
		if (StringUtils.isEmpty(sanctionType)) {
			log.error("No " + CaseUtil.SANCTION_TYPE + " found.");
		}

		CourtAppearanceTO dto = new CourtAppearanceTO();

		if (StringUtils.isNotEmpty(sanctionID)) {
			dto.setSanctionId(new Long(sanctionID));
		}
		if (StringUtils.isNotEmpty(sanctionType)) {
			dto.setSanctionType(sanctionType);
		}

		String action = request.getParameter(CaseUtil.ACTION_TYPE_PARAM);

		if (action != null && action.equalsIgnoreCase(CaseUtil.VIEW_PARAM)) {

			String id = request.getParameter(CaseUtil.APPEARANCE_ID_PARAM);

			if (StringUtils.isNotEmpty(id) && (!EcmsUtils.onCancel(request))) {
				CourtAppearanceTO hibernate = courtAppearanceFacade
						.loadCourtAppearanceById(new Long(id));
				if (hibernate != null) {
					dto = hibernate;
				}
			}
		}

		if (!EcmsUtils.onCancel(request)) {

			this.setupAllLookupDetails(dto);
		}

		return mAV.addObject("courtAppearance", dto);
	}
	

	@RequestMapping(value="/secure/courtAppearance.htm")
	public ModelAndView processFormSubmission(HttpServletRequest request,
			HttpServletResponse response, @ModelAttribute("courtAppearance") CourtAppearanceTO appearance, BindingResult errors)
			throws Exception {
		
		if (log.isDebugEnabled()) {
			log.debug("processFormSubmission");
		}
		String dispatch = request.getParameter("dispatch");
		if (dispatch != null){
			return formBackingObject(request);
		}
		
		ModelAndView mAV = new ModelAndView("courtAppearance");

		if (EcmsUtils.onCancel(request)) {
			return this.getRedirectView(appearance);
		}

		//validateCourtAppearance(appearance, request, errors);

		//if (errors.getErrorCount() < 1) {
			
			if (EcmsUtils.onFinish(request)) {
				
				// To overcome issue with data type, giving '-' as default. 
				if (StringUtils.isEmpty(appearance.getOutcomeInfo())) {
					appearance.setOutcomeInfo("-");
				}
				String sanction = getSanctionName(appearance.getSanctionType());
				if (appearance.getAppearanceId() == null) {
					
					String activity = sanction + " Court Appearance Created";
					AuditFlowThread.set(activity);
					courtAppearanceFacade.saveCourtAppearance(appearance);
					createAudit(appearance, AuditLogService.CREATE, activity, request, auditLogFacade);
				
				} else {
				
					String activity = sanction + " Court Appearance Updated";					
					AuditFlowThread.set(activity);
					courtAppearanceFacade.updateCourtAppearance(appearance);
					createAudit(appearance, AuditLogService.UPDATE,	activity, request, auditLogFacade);
				}

				return this.getRedirectView(appearance);
			}
			// Delete Court Appearance
			if (EcmsUtils.onDelete(request)) {
				
				String activity = getSanctionName(appearance.getSanctionType()) + " Court Appearance Deleted";
				
				AuditFlowThread.set(activity);
				
				courtAppearanceFacade.deleteCourtAppearance(appearance);
				
				createAudit(appearance, AuditLogService.DELETE, activity, 
						request, auditLogFacade);
				
				return this.getRedirectView(appearance);
			}

		//} 
		mAV.addObject("courtAppearance", appearance);
		
		return mAV;
	}
	
	private String getSanctionName(String type) {
		
		if (type.equals("criminal")) {
			
			return "Criminal";
		}
		if (type.equals("civil")) {
					
			return "Civil";
		}
		if (type.equals("disciplinary")) {
			
			return "Disciplinary";
		}
		
		return "";
	}

	/**
	 * Validate Contact details.
	 * 
	 * @param contact
	 * @param request
	 * @param errors
	 */
	private void validateCourtAppearance(CourtAppearanceTO courtAppearance,
			HttpServletRequest request, BindingResult errors) {

		log.info("validateCourtAppearance");
		// TODO Auto-generated method stub

	}

	/**
	 * Redirection View for the Court Appearance.
	 * 
	 * @param dto
	 * @return ModelAndView
	 */
	private ModelAndView getRedirectView(CourtAppearanceTO dto) {

		StringBuffer param = new StringBuffer();

		if (dto != null && dto.getSanctionId() != null) {
			param.append("?");
			param.append(CaseUtil.SANCTION_ID_PARAM);
			param.append("=");
			param.append(dto.getSanctionId());
			param.append("&");
			param.append(CaseUtil.SANCTION_TYPE);
			param.append("=");
			param.append(dto.getSanctionType());

		}

		return new ModelAndView(new RedirectView(
				CaseUtil.COURT_APPEARANCES_LINK_LINK + param));

	}

	/**
	 * Setup all lookup details for information.
	 * 
	 * @param Information
	 */
	private void setupAllLookupDetails(CourtAppearanceTO dto) {

		if (EcmsUtils.isCriminalCourtAppearanceLookupViewMapEmpty()) {

			String[] lookupGroupNames = CaseUtil
					.getCourtAppearanceLookupGroups();

			for (String groupName : lookupGroupNames) {
				
				List<LookupView> list = new ArrayList<LookupView>();
				
				if (groupName != null) {
					list = lookupViewFacade
							.loadActiveLookupDetailsByGroups(groupName);
				}
				dto.addLookupViewMap(groupName, list);
			}
			// STATIC LOOKUP MAP.
			dto.setStaticCriminalCourtAppearanceLookupViewMap();
			
		} else {
			
			dto.setLookupViewMap(EcmsUtils
					.getCriminalCourtAppearanceLookupViewMap());
		}
	}

	/**
	 * Setters for the Facade.
	 * 
	 * @param courtAppearanceFacade
	 */
	public void setCourtAppearanceFacade(
			CourtAppearanceService courtAppearanceFacade) {
		
		this.courtAppearanceFacade = courtAppearanceFacade;
	}

	public void setLookupViewFacade(LookupViewService lookupViewFacade) {
		
		this.lookupViewFacade = lookupViewFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		
		this.auditLogFacade = auditLogFacade;
	}

	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			log.error(e);
		}
	}

	@InitBinder
	protected void initBinder(HttpServletRequest servletRequest,
			ServletRequestDataBinder binder) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("\n initBinder"); 
		}

		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, nf, true));
		binder
				.registerCustomEditor(String.class, new StringTrimmerEditor(
						true));
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null,
				new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}
	
}
