package uk.nhs.cfsms.ecms.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.sanction.PoliceCharge;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CriminalSanctionService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * Police Charges for Sanctions
 * 
 */
@Controller
public class PoliceChargeFormController {

	private static final String SANCTIONS_DETAILS_LINK = "sanctionDetails.htm?sanctionId=";

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private AuditLogService auditLogFacade;

	@Autowired
	private CriminalSanctionService criminalSanctionFacade;

	public PoliceChargeFormController() {
		/*
		 * setSessionForm(true); setCommandName("policeCharge");
		 * setCommandClass(PoliceCharge.class);
		 */
	}

	@RequestMapping(value = "/secure/editPoliceCharge.htm", params = { "!chargingOfficer" })
	public ModelAndView formBackingObject(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mAV = new ModelAndView("policeCharge");
		log.info("** PoliceChargeFormController.formBackingObject().");

		String sanctionID = request.getParameter(CaseUtil.SANCTION_ID_PARAM);

		PoliceCharge dto = new PoliceCharge();

		if (StringUtils.isEmpty(sanctionID)) {
			log.error("*\n No " + CaseUtil.SANCTION_ID_PARAM + " found.");
			return CaseUtil.getCriminalSanctionsListView();
		}

		if (StringUtils.isNotEmpty(sanctionID)) {
			dto.setSanctionId(new Long(sanctionID));
		}

		String action = request.getParameter(CaseUtil.ACTION_TYPE_PARAM);

		if (action != null && action.equalsIgnoreCase(CaseUtil.VIEW_PARAM)) {

			if (StringUtils.isNotEmpty(sanctionID)
					&& (!EcmsUtils.onCancel(request))) {
				PoliceCharge hibernate = criminalSanctionFacade
						.loadPoliceCharge(new Long(sanctionID));
				if (hibernate != null) {
					dto = hibernate;
				}
			}
		}

		return mAV.addObject("policeCharge", dto);
	}

	@RequestMapping(value = "/secure/editPoliceCharge.htm", params = { "chargingOfficer" })
	public ModelAndView processFormSubmission(HttpServletRequest request,
			HttpServletResponse response, PoliceCharge charge,
			BindingResult errors) throws Exception {
		log.info("** PoliceChargeFormController.processFormSubmission");

		ModelAndView mAV = new ModelAndView("policeCharge");

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		if (null == user) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}

		if (EcmsUtils.onCancel(request)) {
			return this.getRedirectView(charge);
		}

		validatePoliceCharge(charge, request, errors);

		if (errors.getErrorCount() < 1) {
			// Check your actions and do the action.
			if (EcmsUtils.onFinish(request)) {

				if (charge.getChargeId() == null) {
					charge.setCreateStaffId(user.getStaffId());
					charge.setCreatedTime(new Date());
					AuditFlowThread.set("Police Charge Created");
				} else {
					AuditFlowThread.set("Police Charge Updated");
				}
				criminalSanctionFacade.savePoliceCharge(charge);
				/*
				 * createAudit(charge, AuditLogService.UPDATE,
				 * "Police Charges Updated", request, auditLogFacade);
				 */return this.getRedirectView(charge);
			}
			if (EcmsUtils.onDelete(request)) {
				// TODO for delete police charge...
				// criminalSanctionFacade.deleteCharge(charge);
				return this.getRedirectView(charge);
			}

		} else {
			/*
			 * return super.processFormSubmission(request, response, command,
			 * errors);
			 */
			mAV.addObject(errors.getModel());
		}
		mAV.addObject("policeCharge", charge);
		return mAV;
	}

	/**
	 * Redirection to the Criminal Sanction List View...
	 * 
	 * @return ModelAndView
	 */
	private ModelAndView getRedirectView(PoliceCharge dto) {

		if (dto != null && dto.getSanctionId() != null) {

			return new ModelAndView(new RedirectView(SANCTIONS_DETAILS_LINK
					+ dto.getSanctionId()));
		}
		return CaseUtil.getCriminalSanctionsListView();
	}

	/**
	 * Validate police charge details.
	 * 
	 * @param PoliceCharge
	 * @param request
	 * @param errors
	 */
	private void validatePoliceCharge(PoliceCharge policeCharge,
			HttpServletRequest request, BindingResult errors) {

		log.info(" PoliceChargeFormController.validatePoliceCharge");
		// TODO Auto-generated method stub
	}

	public void setCriminalSanctionFacade(
			CriminalSanctionService criminalSanctionFacade) {
		this.criminalSanctionFacade = criminalSanctionFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	//TODO  have a superclass for your controllers
	// and want to use the same date format throughout the app, put it there
	@InitBinder
	private void dateBinder(WebDataBinder binder) {
		// The date format to parse or output your dates
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		// Create a new CustomDateEditor
		CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
		// Register it as custom editor for the Date type
		binder.registerCustomEditor(Date.class, editor);
	}
}
