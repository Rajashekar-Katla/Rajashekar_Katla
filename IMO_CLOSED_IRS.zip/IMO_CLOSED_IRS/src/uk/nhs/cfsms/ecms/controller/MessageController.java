package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.MessageService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

@Controller
@SessionAttributes(value = "messageObject")
public class MessageController extends BaseFormController {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private AuditLogService auditLogFacade;

	@Autowired
	private MessageService messageFacade;

	@ModelAttribute(value = "messageObject")
	public MessageTO initModel() {

		if (logger.isInfoEnabled()) {
			logger.info("** Initialising Model.");
		}
		MessageTO messageTO = new MessageTO();

		return messageTO;
	}

	@RequestMapping(value = "/secure/savemessage.htm", method = RequestMethod.POST)
	public ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute(value = "messageObject") MessageTO messageTO,
			BindingResult errors, WebRequest webRequest, SessionStatus status)
			throws Exception {

		final List<MessageTO> messageTOList = new ArrayList<MessageTO>();

		if (logger.isInfoEnabled()) {
			logger.info("** onSubmit().");
		}

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		if (EcmsUtils.onSave(request)) {

			if (!this.createStaffDetails(messageTO, user)) {

				// No OFM/AFL or No TEAM CODE Message...
				return new ModelAndView("noofmorteamcodemessage");
			}
			messageTO.setMessageType(MessageTO.Message_types.IMO_AFL_REFERRAL
					.toString());
			AuditFlowThread.set("Message Created");
			messageTO = messageFacade.saveMessage(messageTO);

			createAudit(messageTO, AuditLogService.UPDATE, "Adding Message",
					request, auditLogFacade);

			if (messageTO.getMessageId() != null) {
				if (logger.isInfoEnabled()) {
					logger.info("** removing messageObject from session.");
				}
				status.setComplete();
				webRequest.removeAttribute("messageObject",
						WebRequest.SCOPE_SESSION);

				return new ModelAndView("messagesuccess");
			}
		} else if (EcmsUtils.onUpdate(request)) {

			MessageTO prevMessage = messageFacade.loadMessage(messageTO
					.getMessageId());
			prevMessage.setActionDetails(messageTO.getActionDetails()
					+ "-- By  " + user.getFullName() + " on " + new Date());

			messageFacade.updateMessage(messageTO, false);

			createAudit(messageTO, AuditLogService.UPDATE, "Updating Message",
					request, auditLogFacade);

			if (logger.isInfoEnabled()) {
				logger.info("** removing messageObject from session.");
			}

			status.setComplete();
			webRequest.removeAttribute("messageObject",
					WebRequest.SCOPE_SESSION);

			return new ModelAndView("messagesuccess");
		}

		return new ModelAndView("createmessage", "messageObject", messageTO);

	}

	@RequestMapping(value = "/secure/createmessage.htm")
	protected ModelAndView formBackingObject(HttpServletRequest request,
			@ModelAttribute(value = "messageObject") MessageTO messageTO)
			throws ServletException, ServiceException {

		if (logger.isInfoEnabled()) {
			logger.info("** formBackingObject().");
		}
		String infoId = messageTO.getInformationId() != null ? messageTO
				.getInformationId().toString() : null;

		String caseId = messageTO.getCaseId() != null ? messageTO.getCaseId()
				.toString() : null;

		if (StringUtils.isNotEmpty(infoId)) {
			messageTO.setInformationId(new Long(infoId));
		}
		if (StringUtils.isNotEmpty(caseId)) {
			messageTO.setCaseId(new Long(caseId));
		}

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		try {
			if (!createStaffDetails(messageTO, user)) {
				logger.error("ERROR NO AAFS/AFL for message:"
						+ (null != messageTO ? messageTO.toString() : "")
						+ ", From User:"
						+ (null != user ? user.toString() : ""));

				messageTO = resetMessage(messageTO);
			}

		} catch (ServiceException e) {
			logger.error("ERROR While creating message:"
					+ (null != messageTO ? messageTO.toString() : "")
					+ ", User:" + (null != user ? user.toString() : ""));
		}

		return new ModelAndView("createmessage", "messageObject", messageTO);

	}

	private MessageTO resetMessage(final MessageTO messageTO) {
		messageTO.setToStaffId("");
		messageTO.setToStaffName("");
		messageTO.setState("");
		messageTO.setMessageType("");
		messageTO.setCaseRef("");
		messageTO.setInformationRef("");

		return messageTO;
	}
	/**
	 * Created Staff details.
	 * 
	 * @param messageTO
	 * @param user
	 * @return
	 * @throws ServiceException
	 */
	private boolean createStaffDetails(MessageTO messageTO, SessionUser user)
			throws ServiceException {
		UserObject ofmObj = null;
		InformationView info = null;

		messageTO.setCreatedStaffId(user.getStaffId());
		messageTO.setCreatedTime(new Date());
		messageTO.setFromStaffId(user.getStaffId());

		if (null != messageTO.getInformationId()) {
			info = messageFacade.loadInformationViewById(messageTO
					.getInformationId());
		}
		if (null != messageTO.getCaseId()) {
			info = messageFacade.loadInformationViewByCaseId(messageTO
					.getCaseId());
		}

		if (user.isUserNationalLevel()) {
			if (logger.isInfoEnabled()) {
				logger.info("** User is Nation Level...");
			}
			if (null != user
					&& EcmsUtils.isNITTeamCode(user.getEmployerOrgCode())) {

				ofmObj = messageFacade.loadAFLByTeamCode(user
						.getEmployerOrgCode());
			} else {
				if (user.getEmployerOrgCode().equalsIgnoreCase(
						ECMSConstants.TEAM_FCO)) {//TODO for FCO Team, its a temporary solution
					ofmObj = messageFacade.loadOFMByTeamOrOrgCode(
							ECMSConstants.TEAM_SOP, false);
				} else {
					ofmObj = messageFacade.loadOFMByTeamOrOrgCode(
							user.getEmployerOrgCode(), false);
				}
			}

		} else {
			if (logger.isInfoEnabled()) {
				logger.info("** User is NOT Nation Level...");
			}
			if (info.hasRegionOverride()) {
				if (logger.isInfoEnabled()) {
					logger.info("** User has regional override ...");
				}
				ofmObj = messageFacade.loadOFMByTeamOrOrgCode(
						info.getTeamCode(), false);

			} else {
				if (logger.isInfoEnabled()) {
					logger.info("** User is LCFS, Loading OFM by orgCode...");
				}
				ofmObj = messageFacade.loadOFMByTeamOrOrgCode(
						info.getOrgCode(), true);
			}
		}

		if (ofmObj != null) {

			messageTO.setToStaffId(ofmObj.getStaffId());
			messageTO.setToStaffName(EcmsUtils.getFullName(ofmObj));

		} else {
			return false;
		}

		messageTO.setFromStaffName(user.getFullName());
		messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);

		if (null != info.getInformationId() && null != info.getCaseId()
				&& null == messageTO.getMessageType()) {

			messageTO.setMessageType(MessageTO.Message_types.CASE_REOPEN
					.toString());
			messageTO.setCaseRef("Case Id:" + info.getCaseId());
		} else {
			messageTO.setInformationRef(info.getCreatedStaffId() + "#"
					+ info.getInformationId());
		}

		return true;
	}

	/**
	 * SETTERS for the Facade
	 * 
	 * @param messageFacade
	 */
	public void setMessageFacade(MessageService messageFacade) {
		this.messageFacade = messageFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
}