package uk.nhs.cfsms.ecms.controller;

import static java.util.regex.Pattern.compile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.data.witness.WitnessStatement;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.dto.witness.WitnessStatementTO;
import uk.nhs.cfsms.ecms.dto.witness.WitnessTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CPSDocumentService;
import uk.nhs.cfsms.ecms.service.WitnessService;
import uk.nhs.cfsms.ecms.service.WitnessStatementService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileExtensions;
import uk.nhs.cfsms.ecms.utility.FileUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
@SessionAttributes(value = "witnessStatementObject")
public class WitnessStatementController extends BaseBinderConfig {

	@Autowired
	private WitnessStatementService witnessStatementFacade;

	@Autowired
	private WitnessService witnessFacade;

	@Autowired
	private AuditLogService auditLogFacade;

	@Autowired
	private CPSDocumentService cpsDocumentsService;

	protected final Log log = LogFactory.getLog(getClass());

	static final String WITNESS_STMT_LIST_PAGE = "listWitnessStatements.htm?actionType=listwitnessstatement&caseId=";

	static final String WITNESS_ID_PARAM = "witnessId";

	CustomDateEditor customDateEditor;

	private static final Map<String, byte[]> FILE_BYTES_MAP = new HashMap<String, byte[]>();

	@RequestMapping(value = "/secure/createWitnessStatement.htm", method = RequestMethod.GET)
	public String initModel(WitnessStatementTO statementTO,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {

		logger.info("initModel...");

		if (!EcmsUtils.onCancel(request)) {
			statementTO.setWitnessList(getAllWitnessesByCaseId(request));
		}
		model.addAttribute("witnessStatementObject", statementTO);

		logger.info("resolving createWitnessStatement...");

		return "createWitnessStatement";
	}

	@RequestMapping(value = "/secure/witnessstatement.htm", method = RequestMethod.GET)
	public String showWitnessDetils(WitnessStatementTO statementTO,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {

		logger.info("showWitnessDetils...");

		if (!EcmsUtils.onCancel(request)) {
			statementTO.setWitnessList(getAllWitnessesByCaseId(request));
		}
		model.addAttribute("witnessStatementObject", statementTO);

		logger.info("resolving createWitnessStatement...");

		return "createWitnessStatement";
	}

	@RequestMapping(value = "/secure/witnessstatement.htm", method = RequestMethod.POST)
	public ModelAndView processFormSubmission(
			@ModelAttribute("witnessStatementObject") WitnessStatementTO statementTO,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {

		logger.info("processFormSubmission()");

		if (EcmsUtils.onCancel(request)) {

			return new ModelAndView(new RedirectView(WITNESS_STMT_LIST_PAGE
					+ CaseUtil.getCaseId(request)));
		}

		String actionType = request.getParameter("actionType");

		logger.info("actionType = " + actionType);

		if (StringUtils.equalsIgnoreCase(actionType, "listwitnessstatement")) {

			return getWitnessStatementList(request, model);
		}

		if (StringUtils.equalsIgnoreCase(actionType, "viewwitnessstatement")) {

			String id = request.getParameter("statementId");

			if (StringUtils.isEmpty(id)) {
				return getWitnessStatementList(request, model);
			}
			statementTO = witnessStatementFacade
					.loadWitnessStatementById(new Long(id));
			statementTO.setWitnessList(getAllWitnessesByCaseId(request));

			model.addAttribute("witnessStatementObject", statementTO);

			return new ModelAndView("createWitnessStatement");
		}

		if (StringUtils.equalsIgnoreCase(actionType, "saveWitnessStatement")) {

			String witnessId = request.getParameter("witness.witnessId");
			statementTO.setWitness(new WitnessTO());
			statementTO.getWitness().setWitnessId(new Long(witnessId));
			statementTO.setCreatedTime(new Date());
			statementTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId());
			statementTO.setIsUploadedStatment(ECMSConstants.FILLED_STATEMENT);

			if (statementTO.getStatementId() == null) {
				statementTO.setPartNumber(1);
				witnessStatementFacade.saveWitnessStatement(statementTO);
				createAudit(statementTO, AuditLogService.CREATE,
						"Witness Statement", request, auditLogFacade);
			} else {
				witnessStatementFacade.updateWitnessStatement(statementTO);
				createAudit(statementTO, AuditLogService.UPDATE,
						"Witness Statement", request, auditLogFacade);
			}

			if (statementTO.getStatementId() != null) {

				return new ModelAndView("createWitnessStatementSuccess");
			}
		}

		if (StringUtils.equalsIgnoreCase(actionType, "saveUploadedStatement")) {

			return uploadFormSubmission(statementTO, request, response, model);
		}
		logger.info("creating form");

		model.addAttribute("witnessStatementObject", statementTO);

		return new ModelAndView("createWitnessStatement");
	}

	@RequestMapping(value = "/secure/uploadWitnessStatement.htm", method = RequestMethod.GET)
	public String initUploadModel(WitnessStatementTO statementTO,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {

		logger.info("initModel...");

		if (!EcmsUtils.onCancel(request)) {
			statementTO.setWitnessList(getAllWitnessesByCaseId(request));
		}
		model.addAttribute("witnessStatementObject", statementTO);

		logger.info("resolving createWitnessStatement...");

		return "uploadWitnessStatement";
	}

	@RequestMapping(value = "/secure/uploadWitnessStatementPart2.htm", method = RequestMethod.GET)
	public String uploadWitnessStatementPart2(WitnessStatementTO statementTO,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {

		logger.info("initModel...");

		if (!EcmsUtils.onCancel(request)) {
			statementTO.setWitnessList(getAllWitnessesByCaseId(request));
		}
		model.addAttribute("witnessStatementObject", statementTO);

		logger.info("resolving createWitnessStatement...");

		return "uploadWitnessStatementpart2";
	}
	
	@RequestMapping(value = "/secure/uploadWitnessStatement.htm", method = RequestMethod.POST)
	public ModelAndView uploadFormSubmission(
			@ModelAttribute WitnessStatementTO statementTO,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {

		logger.info("uploadFormSubmission()");

		if (EcmsUtils.onCancel(request)) {

			return new ModelAndView(new RedirectView(WITNESS_STMT_LIST_PAGE
					+ CaseUtil.getCaseId(request)));
		}

		String actionType = request.getParameter("actionType");

		if (null != actionType
				&& actionType.equalsIgnoreCase("listwitnessstatement")) {

			return getWitnessStatementList(request, model);
		}

		if (null != actionType
				&& actionType.equalsIgnoreCase("viewwitnessstatement")) {

			String id = request.getParameter("statementId");

			if (StringUtils.isEmpty(id)) {
				return getWitnessStatementList(request, model);
			}
			statementTO = witnessStatementFacade
					.loadWitnessStatementById(new Long(id));
			statementTO.setWitnessList(getAllWitnessesByCaseId(request));

			model.addAttribute("witnessStatementObject", statementTO);

			return new ModelAndView("uploadWitnessStatement");
		}

		if (null != actionType
				&& actionType.equalsIgnoreCase("saveWitnesStatement")) {

			return processFormSubmission(statementTO, request, response, model);

		}

		if (null != actionType
				&& actionType.equalsIgnoreCase("saveUploadedStatement")) {

			String staffId = EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId();
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			MultipartFile statementFile = multipartRequest
					.getFile("statementFile");
			try {
				EcmsUtils.validateCpsMailDocumentFormat((statementFile
						.getOriginalFilename() == null || statementFile
						.getOriginalFilename().isEmpty()) ? statementTO
						.getFileName() : statementFile.getOriginalFilename());
			} catch (Exception e) {
				logger.info("No success in uploaded statement saving ");
				statementTO.setFileUploadError(e.getMessage());
				return new ModelAndView("uploadWitnessStatement",
						"witnessStatementObject", statementTO);
			}

			String witnessId = request.getParameter("witness.witnessId");
			statementTO.setWitness(new WitnessTO());
			statementTO.getWitness().setWitnessId(new Long(witnessId));
			statementTO.setCreatedTime(new Date(System.currentTimeMillis()));
			statementTO.setCreatedStaffId(staffId);
			statementTO.setIsUploadedStatment(ECMSConstants.UPLOADED_STATEMENT);
			statementTO.setStatementFileType(statementFile.getContentType());
			statementTO.setFileName(statementFile.getOriginalFilename());
			witnessStatementFacade.saveWitnessStatement(statementTO);
			createAudit(statementTO, AuditLogService.CREATE,
					"Upload Witness Statement", request, auditLogFacade);

			if (null != statementTO.getStatementId()) {

				return new ModelAndView("createWitnessStatementSuccess");
			}
		}
		logger.info("No success in uploaded statement saving ");

		model.addAttribute("witnessStatementObject", statementTO);

		return new ModelAndView("createWitnessStatement");
	}

	@RequestMapping(value = "/secure/validateWitnessFilename.htm")
	public ModelAndView validateFileName(MultipartHttpServletRequest request,
			HttpServletResponse response) throws IOException, ServiceException,
			CaseIDNotFoundException {

		final HttpSession httpSession = request.getSession();
		final ObjectMapper mapper = new ObjectMapper();
		final String caseID = CaseUtil.getCaseId(request);
		final Iterator<String> itr = request.getFileNames();
		final MultipartFile mpf = request.getFile(itr.next());
		final String formType = request.getParameter("formType");
		final String fullFileName = mpf.getOriginalFilename();
		final byte[] fileBytes = mpf.getBytes();
		final int id = new RandomNumberGenerator(1000).generateNewRandom(10);
		final String key = id + "-" + formType;
		FILE_BYTES_MAP.put(key, fileBytes);

		httpSession.setAttribute("fileBytesMap", FILE_BYTES_MAP);

		String documentNamingRule = null;

		List<InvalidFileNames> inValidNames = new ArrayList<InvalidFileNames>();

		inValidNames = validateAndSave((HttpServletRequest) request,
				httpSession, caseID, formType, fullFileName, fileBytes,
				documentNamingRule, inValidNames, id);
		final String invalidFiles = getFilesInJsonFormat(mapper, inValidNames);
		FileCopyUtils.copy(invalidFiles, response.getWriter());
		return null;
	}

	@RequestMapping(value = "/secure/updateAndSaveWitness.htm")
	public ModelAndView updateAndSaveWitness(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServiceException,
			CaseIDNotFoundException {
		final HttpSession httpSession = request.getSession();
		final ObjectMapper mapper = new ObjectMapper();
		final String caseID = CaseUtil.getCaseId(request);
		final String invalidFileNames = request
				.getParameter("invalidFileNames");

		final String[] fileNames = invalidFileNames.split(",");
		String documentNamingRule = null;
		List<InvalidFileNames> inValidNames = new ArrayList<InvalidFileNames>();

		@SuppressWarnings("unchecked")
		final Map<String, byte[]> fileBytesMap = (HashMap<String, byte[]>) httpSession
				.getAttribute("fileBytesMap");

		for (String fileName : fileNames) {
			final String[] eachFileNames = fileName.split("<>");
			final String id = eachFileNames[0];
			final String formType = eachFileNames[1];
			final String fullFileName = eachFileNames[2];

			final String key = id + "-" + formType;
			final byte[] fileBytes = fileBytesMap.get(key);

			inValidNames = validateAndSave(request, httpSession, caseID,
					formType, fullFileName, fileBytes, documentNamingRule,
					inValidNames, Integer.parseInt(id));
		}

		final String invalidFiles = getFilesInJsonFormat(mapper, inValidNames);
		FileCopyUtils.copy(invalidFiles, response.getWriter());
		return null;
	}

	@SuppressWarnings("unchecked")
	private ModelAndView getWitnessStatementList(HttpServletRequest request,
			ModelMap model) throws Exception {

		String caseID = CaseUtil.getCaseId(request);
		String witnessID = request.getParameter("witnessId");
		String partNumber = request.getParameter("partNumber");
		int partNo = Integer.parseInt(partNumber);
		List<WitnessStatementTO> filledstatementsList = null;
		List<WitnessStatement> uploadedstatementsList = null;

		log.info("getWitnessStatementList");

		try {
			Long caseIDLong = new Long(caseID);
			// -- FILLED STATEMENTS
			if (StringUtils.isEmpty(witnessID)) {
				filledstatementsList = witnessStatementFacade
						.loadWitnesseStatementsByCaseId(caseIDLong,partNo,
								ECMSConstants.FILLED_STATEMENT);
			} else {
				filledstatementsList = witnessStatementFacade
						.loadStatementsByWitnessIdAndType(new Long(witnessID),partNo,
								ECMSConstants.FILLED_STATEMENT);
			}
			Map<String, Object> statementsMap = new HashMap<String, Object>();
			statementsMap.put("filledStatementSize",
					filledstatementsList.size());
			statementsMap.put("filledStatementList", filledstatementsList);
			statementsMap.put("caseID", caseID);
			// -- UPLOADED STATEMENTS
			if (StringUtils.isEmpty(witnessID)) {
				uploadedstatementsList = witnessStatementFacade
						.loadWitnesseStatementsByCaseId(caseIDLong,partNo,
								ECMSConstants.UPLOADED_STATEMENT);
			} else {
				uploadedstatementsList = witnessStatementFacade
						.loadStatementsByWitnessIdAndType(new Long(witnessID),partNo,
								ECMSConstants.UPLOADED_STATEMENT);
			}
			statementsMap.put("uploadedStatementSize",
					uploadedstatementsList.size());
			statementsMap.put("uploadedStatementList", uploadedstatementsList);

			return new ModelAndView("showWitnessStatementList",
					"statementsMap", statementsMap);

		} catch (NumberFormatException nfe) {

			throw nfe;
		}

	}

	/**
	 * @param request
	 * @param httpSession
	 * @param caseID
	 * @param formType
	 * @param fullFileName
	 * @param fileBytes
	 * @param documentNamingRule
	 * @param inValidNames
	 * @return
	 * @throws ServiceException
	 */
	private List<InvalidFileNames> validateAndSave(HttpServletRequest request,
			final HttpSession httpSession, final String caseID,
			final String formType, final String fullFileName,
			final byte[] fileBytes, String documentNamingRule,
			List<InvalidFileNames> inValidNames, int id)
			throws ServiceException {

		@SuppressWarnings("unchecked")
		Map<String, String> fileNamingRulesMap = (Map<String, String>) httpSession
				.getAttribute("fileNamingRulesMap");

		if (fileNamingRulesMap == null) {
			fileNamingRulesMap = this.cpsDocumentsService
					.getCPSDocumentsNamingRules();
			httpSession.setAttribute("fileNamingRulesMap", fileNamingRulesMap);
		}
		final String key = id + "-" + formType;

		documentNamingRule = getFileNamingRule(documentNamingRule, formType,
				fileNamingRulesMap);

		String fileName = null;

		if (!documentNamingRule.isEmpty()) {
			final Pattern pattern = compile(documentNamingRule);
			final String fileNameWithExt = fullFileName;

			final String extension = FilenameUtils
					.getExtension(fileNameWithExt);

			if (FileExtensions.isValidExtension(extension.toLowerCase())) {
				fileName = fileNameWithExt.substring(0,
						fileNameWithExt.indexOf("." + extension));
			} else {
				fileName = fileNameWithExt;
			}
			final Matcher matcher = pattern.matcher(fileName.trim());

			if (!matcher.matches()) {
				inValidNames = populateInvalidFileNames(formType, fullFileName,
						inValidNames, id);
			} else {
				saveWitness(request, fullFileName, formType, fileBytes, caseID,
						key);
			}
		} else {
			saveWitness(request, fullFileName, formType, fileBytes, caseID, key);
		}
		return inValidNames;
	}

	private String getFilesInJsonFormat(final ObjectMapper mapper,
			final List<InvalidFileNames> invalidFilesList) {
		String invalidFiles = null;
		try {
			invalidFiles = mapper.writeValueAsString(invalidFilesList);
		} catch (JsonGenerationException e) {
			logger.error("Got JsonGenerationException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (JsonMappingException e) {
			logger.error("Got JsonMappingException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {
			logger.error("Got IOException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		}
		return invalidFiles;
	}

	private static class RandomNumberGenerator {
		ArrayList<Integer> numbersList = new ArrayList<Integer>();

		public RandomNumberGenerator(int length) {
			for (int x = 1; x <= length; x++)
				numbersList.add(x);
			Collections.shuffle(numbersList);
		}

		public int generateNewRandom(int n) {
			return numbersList.get(n);
		}
	}

	/**
	 * @param request
	 * @param fullFileName
	 * @param mgFormObject
	 * @throws ServiceException
	 */
	private void saveWitness(HttpServletRequest request,
			final String fullFileName, final String formType,
			final byte[] fileBytes, final String caseID, final String key)
			throws ServiceException {

		final SessionUser user = EcmsUtils.getSessionUserObject(request
				.getSession());
		final String fileType = FileUtils.getExtension(fullFileName);
		final String witnessId = request.getParameter("witnessID");
		final WitnessStatementTO statementTO = new WitnessStatementTO();
		int partNo = 0;
		if(formType.equals("MG11 part 2")){
			partNo = 2;
		}
		if(formType.equals("MG11")){
			partNo = 1;
		}

		statementTO.setWitness(new WitnessTO());
		statementTO.getWitness().setWitnessId(new Long(witnessId));
		statementTO.setCreatedTime(new Date(System.currentTimeMillis()));
		statementTO.setCreatedStaffId(user.getStaffId());
		statementTO.setIsUploadedStatment(ECMSConstants.UPLOADED_STATEMENT);
		statementTO.setStatementFileType(fileType);
		statementTO.setFileName(fullFileName);
		statementTO.setStatementFile(fileBytes);
		statementTO.setPartNumber(partNo);

		witnessStatementFacade.saveWitnessStatement(statementTO);
		FILE_BYTES_MAP.remove(key);
		createAudit(statementTO, AuditLogService.CREATE,
				"Upload Witness Statement", request, auditLogFacade);
	}

	/**
	 * @param formType
	 * @param fullFileName
	 * @param fileBytes
	 * @param inValidNames
	 * @param id
	 */
	private List<InvalidFileNames> populateInvalidFileNames(
			final String formType, final String fullFileName,
			final List<InvalidFileNames> inValidNames, int id) {
		final InvalidFileNames invalidFileNames = new InvalidFileNames();
		invalidFileNames.setSelectId(id);
		invalidFileNames.setFullFileName(fullFileName);
		invalidFileNames.setFormType(formType);
		inValidNames.add(invalidFileNames);

		return inValidNames;
	}

	/**
	 * This method is responsible to get file naming rule for given document
	 * category.
	 * 
	 * @param String
	 *            documentCategory
	 * @param String
	 *            documentNamingRule
	 * @param String
	 *            formType
	 * @param Map
	 *            <String, String> fileNamingRulesMap
	 * 
	 * @return String
	 */

	private String getFileNamingRule(String documentNamingRule,
			final String formType, final Map<String, String> fileNamingRulesMap) {

		documentNamingRule = fileNamingRulesMap.get(formType);

		documentNamingRule = documentNamingRule != null ? documentNamingRule
				.trim() : "";
		return documentNamingRule;
	}

	private List getAllWitnessesByCaseId(HttpServletRequest request)
			throws Exception {

		String caseID = CaseUtil.getCaseId(request);
		return witnessFacade.loadWitnessesByCaseId(new Long(caseID));
	}

	/**
	 * Setter method for the Witness Statement Facade.
	 * 
	 * @param witnessStatementFacade
	 */
	public void setWitnessStatementFacade(
			WitnessStatementService witnessStatementFacade) {
		this.witnessStatementFacade = witnessStatementFacade;
	}

	public void setWitnessFacade(WitnessService witnessFacade) {
		this.witnessFacade = witnessFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public CustomDateEditor getCustomDateEditor() {
		return customDateEditor;
	}

	public void setCustomDateEditor(CustomDateEditor customDateEditor) {
		this.customDateEditor = customDateEditor;
	}

	private static class InvalidFileNames {
		private int selectId;
		private String formType;
		private String fullFileName;

		public int getSelectId() {
			return selectId;
		}

		public void setSelectId(int selectId) {
			this.selectId = selectId;
		}

		public String getFormType() {
			return formType;
		}

		public void setFormType(String formType) {
			this.formType = formType;
		}

		public String getFullFileName() {
			return fullFileName;
		}

		public void setFullFileName(String fullFileName) {
			this.fullFileName = fullFileName;
		}

	}
}
