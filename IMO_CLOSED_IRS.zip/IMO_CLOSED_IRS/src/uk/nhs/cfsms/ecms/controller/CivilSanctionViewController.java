package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionOutcome;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionTO;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionView;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealOutcomeTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SubjectName;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.CivilSanctionService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * Civil Sanction View Controller is for viewing the civil sanction details 
 *
 */
@Controller
public class CivilSanctionViewController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CivilSanctionService civilSanctionFacade;
	@Autowired
	private InformationGatherService informationGatherFacade;
	@Autowired
	private CaseService caseFacade;

	@RequestMapping(value ="/secure/showCivilSanctions.htm")
	public ModelAndView showCivilSanctions(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		return showCivilSanctionsWithErrors(request, response,
				new ArrayList<String>());
	}
	
	public ModelAndView showCivilSanctionsWithErrors(HttpServletRequest request,
			HttpServletResponse response, List<String> errors) throws ServletException {

		Map<String, Object> model = new HashMap<String, Object>();
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		try {
			List<CivilSanctionTO> results = civilSanctionFacade
					.loadCivilSanctions(new Long(caseID));
			
			for(CivilSanctionTO civilSanction : results){
				try {
					List<CivilAppealOutcomeTO> appealOutcomeTOs = civilSanctionFacade.
							loadAppealOutcomeForCivilSanctionId(civilSanction.getCivilSanctionId());
					civilSanction.setAppealExist((appealOutcomeTOs == null || appealOutcomeTOs.isEmpty()) 
							? false : true);
				} catch (Exception e) {
					logger.info(e);
				}
			}
			
			
			model.put("civilSanctions", results);
			model.put("civilSanctionsSize", results.size());
			model.put(ECMSConstants.ERROR_MESSAGES, errors);
		} catch (ServiceException e) {
			throw new ServletException(e);
		}

		return new ModelAndView("showCivilSanctions", "civilSanctionsMap",
				model);
	}

	@RequestMapping(value ="/secure/civilSanctionMenu.htm")
	public ModelAndView civilSanctionMenu(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map<String, Object> model = new HashMap<String, Object>();
		List<CivilAppealOutcomeTO> appealOutcomeTOs = null;

		String id = request.getParameter(CaseUtil.SANCTION_ID_PARAM);
		String caseId = null;
		try {
			caseId = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		CivilSanctionTO civilSanction = getCivilSanction(id, caseId);
		
		try {
			appealOutcomeTOs = civilSanctionFacade.loadAppealOutcomeForCivilSanctionId(civilSanction.getCivilSanctionId());
		} catch (Exception e) {
			logger.info(e);
		}
		
		civilSanction.setAppealExist((appealOutcomeTOs == null || appealOutcomeTOs.isEmpty()) ? false : true);

		List<SubjectName> subjects = getSubjectsForCase(new Long(caseId));
		//List<CaseContact> contacts = getContactsForCase(new Long(caseId));
		model.put("civilSanction", civilSanction);
		model.put("civilSanctionId", id);
		model.put("subjects", subjects);
		//model.put("contacts", contacts);

		return new ModelAndView("civilSanctionMenu", "civilSanctionModel",
				model);

	}	

	@RequestMapping(value ="/secure/editCivilSanction.htm")
	public ModelAndView editCivilSanction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map<String, Object> model = new HashMap<String, Object>();

		String id = request.getParameter(CaseUtil.SANCTION_ID_PARAM);
		String caseId = null;
		try {
			caseId = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		CivilSanctionTO civilSanction = getCivilSanction(id, caseId);

		List<SubjectName> subjects = getSubjectsForCase(new Long(caseId));

		if (null == subjects || (null != subjects && subjects.isEmpty())) {
			
			model.put(ECMSConstants.ERROR_MESSAGES, ECMSConstants.NO_SUBJECTS);
			
			return new ModelAndView("showCivilSanctions", "civilSanctionsMap", model);
		}
		List<CaseContact> contacts = getContactsForCase(new Long(caseId));
		model.put("civilSanction", civilSanction);
		model.put("subjects", subjects);
		model.put("contacts", contacts);

		return new ModelAndView("editCivilSanction", "civilSanctionModel",
				model);
	}

	
	private CivilSanctionTO getCivilSanction(String id, String caseId)
			throws ServletException {
		
		CivilSanctionTO civilSanction = null;
		if (id != null) {
			try {
				civilSanction = (CivilSanctionTO) civilSanctionFacade
						.getObject(CivilSanctionView.class, new Long(id));
			} catch (ServiceException e) {
				throw new ServletException(e);
			}
		} else {
			civilSanction = new CivilSanctionTO();
			civilSanction.setCaseId(new Long(caseId));
		}

		return civilSanction;
	}

	@RequestMapping(value ="/secure/editCivilSanctionOutcome.htm")
	public ModelAndView editCivilSanctionOutcome(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String id = request.getParameter(CaseUtil.SANCTION_ID_PARAM);

		CivilSanctionOutcome outcome = civilSanctionFacade
				.loadCivilSanctionOutcome(new Long(id));

		if (outcome == null) {
			outcome = new CivilSanctionOutcome();
			outcome.setCivilSanctionId(new Long(id));
		}

		return new ModelAndView("editCivilSanctionOutcome",
				"civilSanctionOutcome", outcome);
	}

	@RequestMapping(value ="/secure/deleteCivilSanction.htm")
	public ModelAndView deleteCivilSanction(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String id = request.getParameter(CaseUtil.SANCTION_ID_PARAM);
		CivilSanctionTO sanction = new CivilSanctionTO();
		sanction.setCivilSanctionId(new Long(id));
		
		try{
		civilSanctionFacade.deleteObject(sanction);
		
		AuditFlowThread.set("Civil Sanction Deleted"); 
		
		createAudit(sanction, AuditLogService.DELETE, "Civil Sanction", request,
				auditLogFacade);
		}catch (Exception e) {
			log.error("Error Deleting Civil Sanction :" + e);
			if(e.getMessage().indexOf("child record found") != -1){
				List<String> errorList = new ArrayList<String>();
				errorList.add("Appeal exists for this sanction.");
				errorList
						.add("Please remove the dependencies and repeat this action in order to continue.");

				return showCivilSanctionsWithErrors(request, response, errorList);				
			}
		}
		return showCivilSanctions(request, response);
	}

	@RequestMapping(value ="/secure/deleteCivilSanctionOutcome.htm")
	public ModelAndView deleteCivilSanctionOutcome(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String id = request.getParameter("civilSanctionOutcomeId");
		
		CivilSanctionOutcome outcome = (CivilSanctionOutcome) civilSanctionFacade
				.getObject(CivilSanctionOutcome.class, new Long(id));
		try {
			if (null != outcome) {
				
				AuditFlowThread.set("Civil Sanction Outcome Deleted");
	
				civilSanctionFacade.deleteObject(outcome);
	
				createAudit(outcome, AuditLogService.DELETE, "Civil Sanction Outcome",
						request, auditLogFacade);
			}
		}catch(Exception e) {
			log.error("Error Deleting Civil Sanction Outcome :" + e);
			throw new ServletException(e);
		}
		
		return civilSanctionMenu(request, response);
	}

	
	private List<CaseContact> getContactsForCase(Long caseId) {

		List<CaseContact> result = new ArrayList<CaseContact>();
		result = caseFacade.loadContactsByCaseId(caseId);
		return result;
	}
	

	private List<SubjectName> getSubjectsForCase(Long caseId) {

		InformationTO infoTO = informationGatherFacade
				.loadInformationByCaseId(caseId);
		
		return EcmsUtils.getInformationSubjectList(infoTO);		
	}


	/**
	 * Setters Facade.
	 * @param civilSanctionFacade
	 */
	public void setCivilSanctionFacade(CivilSanctionService civilSanctionFacade) {
		
		this.civilSanctionFacade = civilSanctionFacade;
	}
 
	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		
		this.informationGatherFacade = informationGatherFacade;
	}
 
	public void setCaseFacade(CaseService caseFacade) {
		
		this.caseFacade = caseFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		
		this.auditLogFacade = auditLogFacade;
	}

}
