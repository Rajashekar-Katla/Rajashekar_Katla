package uk.nhs.cfsms.ecms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CourtAppearanceService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

@Controller
public class CourtAppearanceViewController extends MultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CourtAppearanceService courtAppearanceFacade;

	private static final String COURT_APPEARANCES = "courtAppearances";

	private static final String LIST_MAP = "listMap";

	private static final String COURT_APPEARANCES_LIST_VIEW = "viewCourtAppearances";

	public CourtAppearanceViewController() {
		super();
	}
	@RequestMapping(value ="/secure/showCourtAppearances.htm")
	public ModelAndView showCourtAppearances(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String sanctionID = request.getParameter(CaseUtil.SANCTION_ID_PARAM);
		String sanctionType = request.getParameter(CaseUtil.SANCTION_TYPE);

		if (StringUtils.isEmpty(sanctionID)) {
			logger
					.error("\n **** No " + CaseUtil.SANCTION_ID_PARAM
							+ " found.");
			return CaseUtil.getCriminalSanctionsListView();
		}

		if (StringUtils.isEmpty(sanctionType)) {
			logger.error("\n **** No " + CaseUtil.SANCTION_TYPE + " found.");
			return CaseUtil.getCriminalSanctionsListView();
		}

		List courtAppearancesList;
		try {
			courtAppearancesList = courtAppearanceFacade
					.loadCourtAppearancesByType(new Long(sanctionID),sanctionType);
		} catch (NumberFormatException e) {
			throw new ServletException(e);
		} catch (ServiceException e) {
			throw new ServletException(e);
		}

		Map listMap = new HashMap();
		listMap.put(COURT_APPEARANCES, courtAppearancesList);
		listMap.put(CaseUtil.SANCTION_ID_PARAM, sanctionID);
		listMap.put(CaseUtil.SANCTION_TYPE, sanctionType);

		return new ModelAndView(COURT_APPEARANCES_LIST_VIEW, LIST_MAP, listMap);
	}

	public void setCourtAppearanceFacade(
			CourtAppearanceService courtAppearanceFacade) {
		this.courtAppearanceFacade = courtAppearanceFacade;
	}

	public AuditLogService getAuditLogFacade() {
		return auditLogFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
