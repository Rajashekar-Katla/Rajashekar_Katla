package uk.nhs.cfsms.ecms.controller;

import java.math.BigDecimal;
import java.text.NumberFormat;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.mvc.SimpleFormController;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;

/**
 * BaseFormController overrides common methods for controllers which extend
 * SimpleFormController.
 * 
 * @author sChilukuri
 * 
 */
@SuppressWarnings("deprecation")
public class BaseFormController extends SimpleFormController {

	@Override
	protected void initBinder(HttpServletRequest request,
			ServletRequestDataBinder binder) throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("initBinder()...");
		}
		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, null, true));
		binder
				.registerCustomEditor(String.class, new StringTrimmerEditor(
						true));
		binder.registerCustomEditor(Float.class, new CustomNumberEditor(
				Float.class, nf, true));
		
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null, 
					new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}

	/**
	 * Create Audit for Case
	 * 
	 * @param object
	 * @param state
	 * @param request
	 * @param auditLogFacade
	 */
	protected void createAudit(String object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		
		String caseID = null;
		try {
			if (null != request && null != object) {
				
				caseID = CaseUtil.getCaseId(request);
				SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
				auditLogFacade.save(object, state, action, (null != user)? user.getStaffId(): "", 
						StringUtils.isNotEmpty(caseID)? new Long(caseID) : null);
			}
		} catch (Exception e) {
			logger.error(e);
		}
	}
	
	/**
	 * Create Audit for Case
	 * 
	 * @param object
	 * @param state
	 * @param request
	 * @param auditLogFacade
	 */
	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			if (null != request && null != object) {
				
				caseID = CaseUtil.getCaseId(request);
				
				SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
				
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, (null != user)? user.getStaffId(): "", 
								StringUtils.isNotEmpty(caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			logger.error(e);
		}
	}	
	
	/**
	 * Create Audit for Information
	 * 
	 * @param object
	 * @param state
	 * @param request
	 * @param auditLogFacade
	 */
	protected void createInformationAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		
		try {
			long infoId = 0;
			if (null != request && null != object) {
				
				if (object instanceof InformationTO) {
					InformationTO infoTO = (InformationTO)object;
					infoId = infoTO.getInformationId();
				}
				SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
				
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
					state, action,(null != user)? user.getStaffId(): "", infoId);
			}

		} catch (Exception e) {
			logger.error(e);
		}
	}	
}
