package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.CaseProgress;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseProgressService;
import uk.nhs.cfsms.ecms.service.TransformService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;
import uk.nhs.cfsms.ecms.xml.ProgressSheetXMLCreator;

@Controller
public class CaseProgressController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CaseProgressService caseProgressFacade;
	@Autowired
	private TransformService transformService;

	private CustomDateEditor customDateEditor;

	final static String TYPE = "type";
	final static String ORDER = "order";
	final static String VIEW = "view";
	final static String PDF = "pdf";
	final static String PROGRESS_TYPE = "progresssheets";
	final static String DECISION_TYPE = "decisionlogs";
	final static String LEGAL_TYPE = "legallogs";

	/**
	 * Save Case Progress.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveCaseProgress.htm")
	public ModelAndView saveCaseProgress(
			@RequestParam(value = "type", required = false) String caseType,
			CaseProgress cp, HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.debug(" saveCaseProgress : caseType : " + caseType);
		}

		// apply binder to custom target object
		/*
		 * ServletRequestDataBinder binder = new ServletRequestDataBinder(cp);
		 * binder.registerCustomEditor(Date.class, getCustomDateEditor());
		 * 
		 * // bind with the values from the form binder.bind(request);
		 */

		// the description is stored as byte data
		// String description = request.getParameter("description");
		// cp.setDescription(description.getBytes());
		try {
			// if its the first time
			if (null == cp.getCaseProgressId() || cp.getCaseProgressId() == 0) {

				// Long generatedNo =
				// caseProgressFacade.generateMinuteNumber(cp.getCaseId());
				Long generatedNo = caseProgressFacade.generateMinuteNumber(
						cp.getCaseId(), caseType);
				cp.setCreatedTime(new Date());
				cp.setMinuteNumber(null == generatedNo ? null : generatedNo
						.toString());
				AuditFlowThread.set("Case Progress Created");
			} else {
				AuditFlowThread.set("Case Progress Updated");
			}
		} catch (ServiceException e) {
			log.error(e.getMessage());
			throw new ServletException(
					"Exception Generating Progress Minute Number for Case");
		}
		if (StringUtils.isEmpty(cp.getMinuteNumberCrossRefered())) {
			cp.setMinuteNumberCrossRefered(null);
		}
		if (StringUtils.isEmpty(cp.getTime())) {
			cp.setTime(null);
		}
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		cp.setCreatedStaffId(user.getStaffId());
		// Added for searching case progress
		cp.setUpdatedFlag("Y");

		try {
			caseProgressFacade.saveObject(cp);

			createAudit(cp, AuditLogService.CREATE, "Case Progress", request,
					auditLogFacade);

		} catch (ServiceException e) {
			log.error(e.getMessage());
			throw new ServletException("Exception Saving Case Progress.");
		}

		return new ModelAndView(new RedirectView("showCaseProgresses.htm"));

	}

	/**
	 * Show Case Progress by progressId
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showCaseProgress.htm")
	public ModelAndView showCaseProgress(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **showCaseProgress");
		}
		try {
			String caseId = CaseUtil.getCaseId(request);
			String caseProgressId = request.getParameter("caseProgressId");
			SessionUser user = EcmsUtils.getSessionUserObject(request
					.getSession());

			CaseProgress cp = new CaseProgress();
			cp.setCaseId(new Long(caseId));

			// cp.setRecordedBy(user.getStaffId());
			cp.setRecordedBy(user.getFirstName() + " " + user.getLastName());
			cp.setDateRecorded(new Date());

			if (caseProgressId != null) {

				cp = (CaseProgress) caseProgressFacade.getObject(
						CaseProgress.class, new Long(caseProgressId));

				cp.setIsModify(false);
			}
			// String description = new String(cp.getDescription());
			// bindObject(request, cp);
			return new ModelAndView("editCaseProgress", "caseProgress", cp);

		} catch (CaseIDNotFoundException cnfe) {
			throw new ServletException(cnfe);
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

	protected BindException bindObject(HttpServletRequest request,
			Object command) throws Exception {

		createBinder(request, command).bind(request);

		return new BindException(command, getCommandName(command));
	}

	/**
	 * Show Case Progress
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showCaseProgresses.htm")
	public ModelAndView showCaseProgresses(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **showCaseProgresses");
		}
		String caseId = null;
		String caseNumber = null;
		try {
			caseNumber = request.getParameter("caseNumber");
			caseId = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}

		String showProgressMins = "NO";
		String showPolicyMins = "NO";
		String showLegalMins = "NO";

		Map<String, Object> caseProgressMap = new HashMap<String, Object>();
		try {
			// Case Progress Sheets List
			List<CaseProgress> pList = caseProgressFacade.loadCaseProgresses(
					new Long(caseId), CaseUtil.PROGRESS_SHEET_TYPE);

			if (null != pList && !pList.isEmpty()) {

				showProgressMins = "YES";
			}
			Collections.sort(pList, new ProgressSheetComparator());

			// Case Policy Books renamed to Decision Log from Dec/2011
			List<CaseProgress> dList = caseProgressFacade.loadCaseProgresses(
					new Long(caseId), CaseUtil.DECISION_LOG_TYPE);

			if (null != dList && !dList.isEmpty()) {

				showPolicyMins = "YES";
			}
			Collections.sort(dList, new ProgressSheetComparator());

			// Case Legal Log List from Dec/2011
			List<CaseProgress> lList = caseProgressFacade.loadCaseProgresses(
					new Long(caseId), CaseUtil.LEGAL_LOG_TYPE);

			if (null != lList && !lList.isEmpty()) {

				showLegalMins = "YES";
			}
			Collections.sort(dList, new ProgressSheetComparator());

			caseProgressMap.put("caseNumber", caseNumber);
			caseProgressMap.put("caseId", caseId);
			caseProgressMap.put("caseProgressSheets", pList);
			caseProgressMap.put("showProgressMins", showProgressMins);
			caseProgressMap.put("casePolicyBooks", dList);
			caseProgressMap.put("showPolicyMins", showPolicyMins);
			caseProgressMap.put("caseLegalLog", lList);
			caseProgressMap.put("showLegalMins", showLegalMins);
		} catch (ServiceException e) {
			log.error(e.getMessage());

		}

		return new ModelAndView("showCaseProgresses", "caseProgressMap",
				caseProgressMap);

	}

	/**
	 * View all case progress sheets based on sensitivity and order by
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/viewAllCaseProgressSheets.htm")
	public ModelAndView viewAllCaseProgressSheets(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **viewAllCaseProgressSheets");
		}
		List<CaseProgress> progressList = new ArrayList<CaseProgress>();
		Map<String, Object> caseProgressMap = new HashMap<String, Object>();

		int sensitiveFilter = this.getSensitiveFilter(request);
		String caseId = null;
		String caseNumber = null;
		try {
			caseId = CaseUtil.getCaseId(request);
			caseNumber = CaseUtil.getCaseNumberInSession(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		String type = request.getParameter(TYPE);

		try {
			if (StringUtils.isNotEmpty(type)) {

				if (type.equalsIgnoreCase(PROGRESS_TYPE)) {

					if (sensitiveFilter == 0) {
						progressList = caseProgressFacade.loadCaseProgresses(
								new Long(caseId), CaseUtil.PROGRESS_SHEET_TYPE);
					} else if (sensitiveFilter == 1) {
						progressList = caseProgressFacade.loadCaseProgresses(
								new Long(caseId), CaseUtil.PROGRESS_SHEET_TYPE,
								"Y");
					} else if (sensitiveFilter == -1) {
						progressList = caseProgressFacade.loadCaseProgresses(
								new Long(caseId), CaseUtil.PROGRESS_SHEET_TYPE,
								"N");
					}

				} else if (type.equalsIgnoreCase(DECISION_TYPE)) {

					progressList = caseProgressFacade.loadCaseProgresses(
							new Long(caseId), CaseUtil.DECISION_LOG_TYPE);

				} else if (type.equalsIgnoreCase(LEGAL_TYPE)) {

					progressList = caseProgressFacade.loadCaseProgresses(
							new Long(caseId), CaseUtil.LEGAL_LOG_TYPE);
				}
			}
		} catch (ServiceException e) {
			log.error(e.getMessage());
			throw new ServletException(
					"Exception Loading Case Progress List for Case");
		}
		Collections.sort(progressList, new ProgressSheetComparator());
		caseProgressMap.put("caseNumber", caseNumber);
		caseProgressMap.put("caseId", caseId);
		caseProgressMap.put("caseProgressSheets", progressList);
		caseProgressMap.put("type", type);
		caseProgressMap.put("mins", "no");

		return new ModelAndView("viewAllCaseProgresses", "caseProgressMap",
				caseProgressMap);
	}

	/**
	 * Get sensitivity Filter, 0=All records, 1=Sensitive, -1=Non-Sensitive
	 * 
	 * @param request
	 * @return filter value.
	 */
	private int getSensitiveFilter(HttpServletRequest request) {

		int sensitiveFilter = 0;

		String viewType = request.getParameter(VIEW);

		if (StringUtils.isNotEmpty(viewType)) {

			if (viewType.equalsIgnoreCase("all")) {

				sensitiveFilter = 0;
			} else if (viewType.equalsIgnoreCase("snt")) {

				sensitiveFilter = 1;
			} else {
				sensitiveFilter = -1;
			}
		}

		return sensitiveFilter;
	}

	/**
	 * View all case decision log (also called: policy books)
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	public ModelAndView viewAllCasePolicySheets(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **viewAllCasePolicySheets");
		}

		String caseId = null;
		String caseNumber = null;
		try {
			caseId = CaseUtil.getCaseId(request);
			caseNumber = CaseUtil.getCaseNumberInSession(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		List<CaseProgress> progressList = new ArrayList<CaseProgress>();
		Map<String, Object> caseProgressMap = new HashMap<String, Object>();

		try {
			progressList = caseProgressFacade.loadCaseProgresses(new Long(
					caseId), CaseUtil.DECISION_LOG_TYPE);

		} catch (ServiceException e) {
			log.error(e.getMessage());
			throw new ServletException("Exception load case progress list.");
		}

		Collections.sort(progressList, new ProgressSheetComparator());
		caseProgressMap.put("caseNumber", caseNumber);
		caseProgressMap.put("caseId", caseId);
		caseProgressMap.put("caseProgressSheets", progressList);
		caseProgressMap.put("type", "policybooks");
		caseProgressMap.put("mins", "no");

		return new ModelAndView("viewAllCaseProgresses", "caseProgressMap",
				caseProgressMap);
	}

	/**
	 * View all Case Legal Log
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	public ModelAndView viewAllCaseLegalLog(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **viewAllCaseLegalLog");
		}
		String caseId = null;
		String caseNumber = null;
		try {
			caseId = CaseUtil.getCaseId(request);
			caseNumber = CaseUtil.getCaseNumberInSession(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		Map<String, Object> caseProgressMap = new HashMap<String, Object>();
		List<CaseProgress> caseLegalList = new ArrayList<CaseProgress>();

		try {
			caseLegalList = caseProgressFacade.loadCaseProgresses(new Long(
					caseId), CaseUtil.LEGAL_LOG_TYPE);

		} catch (ServiceException e) {
			log.error(e.getMessage());
			throw new ServletException("Exception load case progress list.");
		}
		Collections.sort(caseLegalList, new ProgressSheetComparator());
		caseProgressMap.put("caseNumber", caseNumber);
		caseProgressMap.put("caseId", caseId);
		caseProgressMap.put("caseLegalLog", caseLegalList);
		caseProgressMap.put("type", "legalLog");
		caseProgressMap.put("mins", "no");

		return new ModelAndView("viewAllCaseProgresses", "caseProgressMap",
				caseProgressMap);
	}

	@RequestMapping(value = "/secure/progressSheetReport.htm")
	public ModelAndView progressSheetReport(
			@RequestParam(value = TYPE, required = false) String type,
			@RequestParam(value = ORDER, required = false) String orderBy,
			@RequestParam(value = VIEW, required = false) String view,
			@RequestParam(value = PDF, required = false) String pdf,
			HttpServletRequest request, HttpServletResponse response)
			throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.debug(" progressSheetReport");
		}

		List<CaseProgress> progressList = new ArrayList<CaseProgress>();

		int sensitiveFilter = this.getSensitiveFilter(request);

		String caseId = null;
		try {
			caseId = CaseUtil.getCaseId(request);

		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}

		try {
			if (PROGRESS_TYPE.equalsIgnoreCase(type)) {

				if (sensitiveFilter == 0) {
					progressList = caseProgressFacade.loadCaseProgresses(
							new Long(caseId), CaseUtil.PROGRESS_SHEET_TYPE);
				} else if (sensitiveFilter == 1) {
					progressList = caseProgressFacade
							.loadCaseProgresses(new Long(caseId),
									CaseUtil.PROGRESS_SHEET_TYPE, "Y");
				} else if (sensitiveFilter == -1) {
					progressList = caseProgressFacade
							.loadCaseProgresses(new Long(caseId),
									CaseUtil.PROGRESS_SHEET_TYPE, "N");
				}
				/*
								progressList = caseProgressFacade.loadCaseProgresses(new Long(
										caseId), CaseUtil.PROGRESS_SHEET_TYPE);
				*/
			} else if (DECISION_TYPE.equalsIgnoreCase(type)) {
				progressList = caseProgressFacade.loadCaseProgresses(new Long(
						caseId), CaseUtil.DECISION_LOG_TYPE);

			} else if (LEGAL_TYPE.equalsIgnoreCase(type)) {
				progressList = caseProgressFacade.loadCaseProgresses(new Long(
						caseId), CaseUtil.LEGAL_LOG_TYPE);
			}

		} catch (ServiceException e) {
			log.error(e.getMessage());
			throw new ServletException("Exception load case progress list.");
		}

		Collections.sort(progressList, new ProgressSheetComparator());

		if (StringUtils.isNotEmpty(orderBy)
				&& orderBy.equalsIgnoreCase("minuteNumber")) {

			Collections.reverse(progressList);
		}

		try {
			String stylesheetPath = null;

			if (pdf != null) {
				stylesheetPath = CaseUtil.getProgressSheetPdfXSLPath(request);
			} else {
				stylesheetPath = CaseUtil.getProgressSheetXSLPath(request);
			}

			Document d = transform(request, stylesheetPath, progressList, type);
			FileCopyUtils
					.copy(d.asXML().getBytes(), response.getOutputStream());

		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}

		return null;
	}

	@RequestMapping(value = "/secure/progressSheetMinuteReport.htm")
	public ModelAndView progressSheetMinuteReport(
			@RequestParam(value = PDF, required = false) String pdf,
			HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **progressSheetMinuteReport");
		}
		
		String orderBy = request.getParameter(ORDER);

		HttpSession session = request.getSession();
		Object sessionProgMins = session
				.getAttribute(ECMSConstants.CASE_PROGRESS_MINS);
		Object sessionCaseProg = session
				.getAttribute(ECMSConstants.CASE_PROGRESS_TYPE);

		if (null == sessionProgMins || null == sessionCaseProg) {
			throw new ServletException(
					" NULL PROGRESS MINS or TYPE from SESSION");
		}
		List<CaseProgress> caseProgressSheets = (List<CaseProgress>) sessionProgMins;

		String type = (String) sessionCaseProg;

		Collections.sort(caseProgressSheets, new ProgressSheetComparator());

		if (StringUtils.isNotEmpty(orderBy)
				&& orderBy.equalsIgnoreCase("minuteNumber")) {

			Collections.reverse(caseProgressSheets);
		}
		try {
			String stylesheetPath = null;
			if (pdf != null) {
				stylesheetPath = CaseUtil.getProgressSheetPdfXSLPath(request);
			} else {
				stylesheetPath = CaseUtil.getProgressSheetXSLPath(request);
			}

			Document d = transform(request, stylesheetPath, caseProgressSheets,
					type);

			FileCopyUtils
					.copy(d.asXML().getBytes(), response.getOutputStream());

		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
		//		session.removeAttribute(ECMSConstants.CASE_PROGRESS_MINS);
		//		session.removeAttribute(ECMSConstants.CASE_PROGRESS_TYPE);

		return null;
	}

	@RequestMapping(value = "/secure/viewProgressSheetsMinutes.htm")
	public ModelAndView viewProgressSheetsMinutes(
			@RequestParam(value = TYPE, required = false) String type,
			HttpServletRequest request, HttpServletResponse response)
			throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("viewProgressSheetsMinutes");
		}
		String caseId = null;
		String caseNumber = null;
		try {
			caseNumber = request.getParameter("caseNumber");
			caseId = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}

		Map<String, Object> caseProgressMap = new HashMap<String, Object>();
		List<CaseProgress> progressList = new ArrayList<CaseProgress>();

		try {

			if (PROGRESS_TYPE.equalsIgnoreCase(type)) {

				String startMinStr = request
						.getParameter("startingMinuteNumber");
				String endMinStr = request.getParameter("endingMinuteNumber");

				progressList = caseProgressFacade
						.loadCaseProgressesByCaseByMinutes(new Long(caseId),
								CaseUtil.PROGRESS_SHEET_TYPE,
								Integer.parseInt(startMinStr),
								Integer.parseInt(endMinStr));

			} else if (DECISION_TYPE.equalsIgnoreCase(type)) {

				String startMinStr = request
						.getParameter("startingPolicyNumber");
				String endMinStr = request.getParameter("endingPolicyNumber");

				progressList = caseProgressFacade
						.loadCaseProgressesByCaseByMinutes(new Long(caseId),
								CaseUtil.DECISION_LOG_TYPE,
								Integer.parseInt(startMinStr),
								Integer.parseInt(endMinStr));

			} else if (LEGAL_TYPE.equalsIgnoreCase(type)) {

				String startMinStr = request
						.getParameter("startingLegalNumber");
				String endMinStr = request.getParameter("endingLegalNumber");

				progressList = caseProgressFacade
						.loadCaseProgressesByCaseByMinutes(new Long(caseId),
								CaseUtil.LEGAL_LOG_TYPE,
								Integer.parseInt(startMinStr),
								Integer.parseInt(endMinStr));
			}

		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new ServletException(
					"Exception loading case progresses by caseByMinutes");
		}

		Collections.sort(progressList, new ProgressSheetComparator());
		caseProgressMap.put("caseId", caseId);
		caseProgressMap.put("caseNumber", caseNumber);
		caseProgressMap.put("caseProgressSheets", progressList);
		caseProgressMap.put("type", type);
		caseProgressMap.put("mins", "yes");

		HttpSession session = request.getSession();
		session.setAttribute(ECMSConstants.CASE_PROGRESS_MINS, progressList);
		session.setAttribute(ECMSConstants.CASE_PROGRESS_TYPE, type);

		return new ModelAndView("viewAllCaseProgresses", "caseProgressMap",
				caseProgressMap);

	}

	private Document transform(HttpServletRequest request, String stylesheet,
			List<CaseProgress> list, String type) throws ServiceException {

		if (logger.isDebugEnabled()) {
			logger.debug(" **transform");
		}

		ProgressSheetXMLCreator progressXML = new ProgressSheetXMLCreator(list,
				type);
		// progressXML.createDOM();
		String caseNumber = CaseUtil.getCaseNumberInSession(request);
		String operationName = CaseUtil.getOperationNameInSession(request);

		if (logger.isDebugEnabled()) {
			logger.debug(" caseNumber : " + caseNumber);
			logger.debug(" operationName : " + operationName);
		}
		progressXML.createDOMWithCaseNoAndOperationName(caseNumber,
				operationName);
		Document document = progressXML.getDom();
		Document transformedDocument = transformService.transform(stylesheet,
				document);
		return transformedDocument;

	}

	@RequestMapping(value = "/secure/deleteCaseProgress.htm")
	public ModelAndView deleteCaseProgress(
			@RequestParam(value = "caseProgressId", required = false) String caseProgressId,
			HttpServletRequest request, HttpServletResponse response)
			throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.debug("Delete CaseProgress");
		}

		try {

			CaseProgress caseProgress = caseProgressFacade
					.loadCaseProgressById(new Long(caseProgressId));
			if (null != caseProgress) {
				AuditFlowThread.set("Case Progress Deleted");

				caseProgressFacade.deleteCaseProgress(caseProgress
						.getCaseProgressId());
				createAudit(caseProgress, AuditLogService.DELETE,
						"Case Progress", request, auditLogFacade);
			} else {
				log.error("No CaseProgress Found for ID=" + caseProgressId);
			}
		} catch (Exception se) {
			logger.error("Error Loading or Deleting Case Progress By ID="
					+ caseProgressId);

			throw new ServletException(se);
		}

		return new ModelAndView(new RedirectView("showCaseProgresses.htm"));
	}

	/**
	 * @param caseProgressFacade
	 *            The caseProgressFacade to set.
	 */
	public void setCaseProgressFacade(CaseProgressService caseProgressFacade) {
		this.caseProgressFacade = caseProgressFacade;
	}

	/**
	 * @return Returns the customDateEditor.
	 */
	public CustomDateEditor getCustomDateEditor() {
		return customDateEditor;
	}

	/**
	 * @param customDateEditor
	 *            The customDateEditor to set.
	 */
	public void setCustomDateEditor(CustomDateEditor customDateEditor) {
		this.customDateEditor = customDateEditor;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public TransformService getTransformService() {
		return transformService;
	}

	public void setTransformService(TransformService transformService) {
		this.transformService = transformService;
	}

}

/**
 * Progress sheet Comparator
 * 
 */
class ProgressSheetComparator implements Comparator<CaseProgress> {

	@Override
	public int compare(CaseProgress c1, CaseProgress c2) {

		String min1 = c1.getMinuteNumber();
		String min2 = c2.getMinuteNumber();

		long minNo1 = min1 == null ? 0 : Long.parseLong(min1);
		long minNo2 = min2 == null ? 0 : Long.parseLong(min2);

		if (minNo1 > minNo2) {
			return -1;
		}
		return 1;
	}
}