package uk.nhs.cfsms.ecms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.data.sanction.ChargeList;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.ChargeListService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
@Controller
public class ChargeListController extends BaseMultiActionController {
	@Autowired
	private ChargeListService chargeListFacade;

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;

	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/showChargeLists.htm")
	public ModelAndView showChargeLists(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String criminalSanctionId = request
				.getParameter(CaseUtil.SANCTION_ID_PARAM);
		List<ChargeList> charges = chargeListFacade.getChargeLists(new Long(
				criminalSanctionId));

		Map model = new HashMap();
		model.put("chargeLists", charges);
		model.put(CaseUtil.SANCTION_ID_PARAM, criminalSanctionId);

		return new ModelAndView("showChargeLists", "chargeListsModel", model);
	}

	/**
	 * This method is responsible for loading either an existing charge list
	 * object or a new one, depending whether the ID of the charge list is null.
	 * The charge list object is then put onto the model, ready for the view.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value ="/secure/editChargeList.htm")
	public ModelAndView editChargeList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String id = request.getParameter("chargeListId");
		if (id != null) {
			try {
				ChargeList chargeList = (ChargeList) chargeListFacade
						.getObject(ChargeList.class, new Long(id));
				return new ModelAndView("chargeList", "chargeList", chargeList);

			} catch (ServiceException e) {
				log.error("Exception loading chargeList with id " + id + " @"
						+ e.getMessage());
				log.error(e);
			}
		} else {
			String sanctionID = request
					.getParameter(CaseUtil.SANCTION_ID_PARAM);
			ChargeList cl = new ChargeList();
			cl.setCriminalSanctionId(new Long(sanctionID));
			return new ModelAndView("chargeList", "chargeList", cl);
		}
		return null;
	}

	public void setChargeListFacade(ChargeListService chargeListFacade) {
		this.chargeListFacade = chargeListFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
