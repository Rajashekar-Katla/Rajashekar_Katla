package uk.nhs.cfsms.ecms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.sanction.Summons;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.SummonsService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
@Controller
public class SummonsViewController extends BaseMultiActionController {
	@Autowired
	private SummonsService summonsFacade;

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	
	@RequestMapping(value ="/secure/showSummons.htm")
	public ModelAndView showSummons(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String criminalSanctionId = request
				.getParameter(CaseUtil.SANCTION_ID_PARAM);
		List<Summons> summons = summonsFacade.getSummons(new Long(
				criminalSanctionId));

		Map model = new HashMap();

		model.put("summonsList", summons);
		model.put(CaseUtil.SANCTION_ID_PARAM, criminalSanctionId);

		return new ModelAndView("showSummons", "summonsModel", model);
	}

	/**
	 * This method is responsible for loading either an existing charge list
	 * object or a new one, depending whether the ID of the charge list is null.
	 * The charge list object is then put onto the model, ready for the view.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value ="/secure/editSummons.htm")
	public ModelAndView editSummons(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String id = request.getParameter("summonsId");
		if (id != null) {
			try {
				Summons summons = (Summons) summonsFacade.getObject(
						Summons.class, new Long(id));
				return new ModelAndView("editSummons", "summons", summons);
			} catch (ServiceException e) {
				log.error("Exception loading charge list with id " + id + " @"
						+ e.getMessage());
				log.error(e);
			}
		} else {
			String sanctionID = request
					.getParameter(CaseUtil.SANCTION_ID_PARAM);
			Summons summons = new Summons();
			summons.setCriminalSanctionId(new Long(sanctionID));
			return new ModelAndView("editSummons", "summons", summons);
		}
		return null;
	}
	
	@RequestMapping(value ="/secure/deleteSummons.htm")
	public ModelAndView deleteSummons(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String id = request.getParameter("summonsId");
		try {
			Summons summons = (Summons) summonsFacade.getObject(Summons.class,
					new Long(id));
			
	        AuditFlowThread.set("Summons Deleted");
			summonsFacade.deleteObject(summons);
			createAudit(summons, AuditLogService.DELETE, "Summons", request,
					auditLogFacade);

			String params = CaseUtil.SANCTION_ID_PARAM + "="
					+ summons.getCriminalSanctionId();
			return new ModelAndView(new RedirectView("showSummons.htm?"
					+ params));
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

	}

	public void setSummonsFacade(SummonsService summonsFacade) {

		this.summonsFacade = summonsFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
