package uk.nhs.cfsms.ecms.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * This controller is called when the user clicks on the Cases option from the
 * left hand side.
 * 
 * @author Sukhraj Matharu
 * 
 */
@Controller
public class ViewCasePortalController extends AbstractController {
	
	@RequestMapping(value ="/secure/viewCasePortal.htm")
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		if (user == null) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}
		
		return new ModelAndView("casePortal");
	}

}
