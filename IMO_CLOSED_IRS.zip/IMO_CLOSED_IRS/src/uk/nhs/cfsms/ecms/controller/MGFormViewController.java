package uk.nhs.cfsms.ecms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.MGForm;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.MGFormService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.FileUtils;

@Controller
public class MGFormViewController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	MGFormService mgFormFacade;

	@RequestMapping(value = "/secure/deletemgfom.htm")
	public ModelAndView deleteMGForm(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String mgFormId = request.getParameter("mgFormId");
		AuditFlowThread.set("Mg Form Deleted");
		mgFormFacade.deleteMGForms(new Long(mgFormId));
		createAudit(new String("Delete MGForm ID=" + mgFormId),
				AuditLogService.DELETE, "DELETE MGFORM", request,
				auditLogFacade);
		return listMGForms(request, response);

	}

	@RequestMapping(value = "/secure/mgformlist.htm")
	public ModelAndView listMGForms(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String caseId = CaseUtil.getCaseId(request);

		Map<String, Object> mgFormsMap = new HashMap<String, Object>();
		try {
			List<MGForm> forms = mgFormFacade.listMGForms(new Long(caseId));
			mgFormsMap.put("mgFormList", forms);

		} catch (Exception ex) {
			log.error("Exception caught while listing mgforms");
			throw new ServletException(ex);
		}

		return new ModelAndView("mgformlist", "mgFormsMap", mgFormsMap);
	}

	@RequestMapping(value = "/secure/downloadmgfom.htm")
	public ModelAndView downloadMGForm(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String mgFormId = request.getParameter("mgFormId");
		try {
			MGForm form = mgFormFacade.loadMgForm(new Long(mgFormId));
			FileUtils.serveDownloadDocument(form.getMgForm(),
					form.getFileName(), response, false);
			createAudit(new String("Download MGForm Id=" + mgFormId + ", Name="
					+ form.getFileName()), AuditLogService.DOWNLOAD,
					"DOWNLOAD MGFORM", request, auditLogFacade);
		} catch (Exception ex) {
			log.error("Exception caught while downloading the document.");
			throw new ServletException(ex);
		}

		return null;
	}

	/**
	 * Setter for MG Form Facade.
	 * 
	 * @param mgFormFacade
	 */
	public void setMgFormFacade(MGFormService mgFormFacade) {
		this.mgFormFacade = mgFormFacade;
	}

	/**
	 * Setter for Audit Log Facade.
	 * 
	 * @param auditLogFacade
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
