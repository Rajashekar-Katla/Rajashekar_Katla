package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.cim.CaseObject;
import uk.nhs.cfsms.ecms.data.cim.InvestigationPlan;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;

@Controller
public class ListCasesController extends MultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CaseService caseFacade;

	static final String CASES_LIST_VIEW = "allCasesView";

	static final String CONTACTS_LIST_VIEW = "allCaseContacts";

	static final String INVESTIGATIONS_LIST_VIEW = "showInvestigations";

	static final String CASES = "cases";

	static final String CASE_CONTACTS = "caseContacts";

	static final String INVESTIGATIONS = "investigations";

	static final String LIST_MAP = "listMap";

	static final String LIST_TYPE = "listType";

	protected void initBinder(ServletRequest servletRequest,
			ServletRequestDataBinder binder) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("** ListCasesController.initBinder()");
		}

		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}

	protected BindException bindObject(HttpServletRequest request,
			Object command, Validator validator) throws Exception {

		ServletRequestDataBinder binder = createBinder(request, command);
		binder.bind(request);
		BindException errors = new BindException(command,
				getCommandName(command));
		if (validator.supports(command.getClass())) {
			ValidationUtils.invokeValidator(validator, command, errors);
		}
		return errors;
	}

	/**
	 * Handle Case List.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/listCases.htm")
	public ModelAndView handleCaseList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String listType = request.getParameter(LIST_TYPE);

		if (listType == null) {
			return CaseUtil.getCasePortalView();
		}
		boolean isAssigned = listType.equals("assigned");
		boolean isLCFS = listType.equals("lcfs");
		boolean isRegions = listType.equals("regions");
		boolean isPCT = listType.equals("pct");
		boolean isOnHold = listType.equals("onhold");
		boolean isClosed = listType.equals("closed");
		boolean isNITS = listType.equals("nits");
		boolean isNITN = listType.equals("nitn");
		// boolean isNIS = listType.equals("nis");
		boolean isAwait = listType.equals("await");
		boolean isSOP = listType.equals("sop");
		boolean isDHAFU = listType.equals("dhafu");

		List<UserDirectorate> list = null;
		List<CaseObject> cases = new ArrayList<CaseObject>();

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		String[] userResps = user.getOrgOrTeamResponsibilities();

		if (isAssigned) {
			cases = caseFacade.loadAssignedCases(user);
		}

		if (isLCFS) {
			list = setDirectorate(ECMSConstants.LOCAL);
			cases = caseFacade.loadCases(true, false, list, userResps);
		}
		if (isRegions) {
			if (user.isUserWARO()
					&& (user.isUserOFM() || user.isUserCFS()
							|| user.isUserAntiFraudSpecialist() || user
								.isUserAntiFraudSpecialistSupport())) {
				list = setDirectorate(ECMSConstants.REGIONAL);
			} else {
				list = setCFSDirectorate(user);
			}
			cases = caseFacade.loadRegionalCases(list, userResps);
		}

		if (isOnHold) {
			if (user.isUserWARO()
					&& (user.isUserOFM() || user.isUserCFS()
							|| user.isUserAntiFraudSpecialist() || user
								.isUserAntiFraudSpecialistSupport())) {
				list = setDirectorate(ECMSConstants.REGIONAL);
			} else {
				list = setCFSDirectorate(user);
			}
			cases = caseFacade.loadCases(true, true, userResps);
		}
		if (isPCT) {
			list = setDirectorate(ECMSConstants.LOCAL);
			cases = caseFacade.loadCases(false, true, list, userResps);
		}
		if (isClosed) {

			if (user.isUserLCFS()) {

				list = setDirectorate(ECMSConstants.LOCAL);
				cases = caseFacade
						.loadClosedCases(false, true, list, userResps);
			} else {

				list = setCFSDirectorate(user);
				cases = caseFacade
						.loadClosedCases(true, false, list, userResps);
			}
		}
		if (isSOP) {

			list = setCFSDirectorate(user);
			cases = caseFacade.loadRegionalCases(list, new String[] { "SOP",
					"CUOPS" });
		}
		if (isNITS) {

			cases = caseFacade.loadNITSCases(setDirectorate(
					ECMSConstants.NATIONAL, ECMSConstants.REGIONAL));
		}

		if (isNITN) {

			cases = caseFacade.loadNITNCases(setDirectorate(
					ECMSConstants.NATIONAL, ECMSConstants.REGIONAL));
		}

		if (isAwait) {
			cases = caseFacade.loadAwaitCases(setCFSDirectorate(user),
					userResps);
		}

		if (isDHAFU) {
			list = setCFSDirectorate(user);
			cases = caseFacade
					.loadRegionalCases(list, new String[] { "DHAFU" });
		}

		Map<String, Object> listMap = new HashMap<String, Object>();
		listMap.put(CASES, cases);
		listMap.put(LIST_TYPE, listType);

		auditLogFacade.save("Loading " + (null != listType ? listType : "")
				+ " cases", AuditLogService.LOADING, user.getStaffId(), 0);

		return new ModelAndView(CASES_LIST_VIEW, LIST_MAP, listMap);
	}

	private List<UserDirectorate> setDirectorate(String national,
			String regional) {

		UserDirectorate natUserDir = new UserDirectorate();
		natUserDir.setDirectorateLevel(national);
		UserDirectorate regUserDir = new UserDirectorate();
		regUserDir.setDirectorateLevel(regional);
		List<UserDirectorate> list = new ArrayList<UserDirectorate>();
		list.add(natUserDir);
		list.add(regUserDir);

		return list;

	}

	/**
	 * Handle Case Information.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/listCaseContacts.htm")
	public ModelAndView handleCaseContactList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		List<CaseContact> contactList = new ArrayList<CaseContact>();
		String caseId = CaseUtil.getCurrentCaseInSession(request.getSession());

		if (StringUtils.isEmpty(caseId)) {
			CaseUtil.logErrorCaseIDNotFound(log);
			return CaseUtil.getCasePortalView();
		}

		contactList = caseFacade.loadContactsByCaseId(new Long(caseId));

		Map<String, Object> listMap = new HashMap<String, Object>();
		listMap.put(CASE_CONTACTS, contactList);

		return new ModelAndView(CONTACTS_LIST_VIEW, LIST_MAP, listMap);

	}

	/**
	 * List all Case Investigations.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/listInvestigations.htm")
	public ModelAndView handleInvestigationList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		List<InvestigationPlan> list = new ArrayList<InvestigationPlan>();
		String caseID = CaseUtil.getCurrentCaseInSession(request.getSession());

		if (StringUtils.isEmpty(caseID)) {
			CaseUtil.logErrorCaseIDNotFound(log);
			return CaseUtil.getCasePortalView();
		}

		list = caseFacade.loadInvestigationsByCaseId(new Long(caseID));

		Map<String, Object> listMap = new HashMap<String, Object>();
		listMap.put(INVESTIGATIONS, list);

		return new ModelAndView(INVESTIGATIONS_LIST_VIEW, LIST_MAP, listMap);

	}

	private List<UserDirectorate> setCFSDirectorate(SessionUser user) {
		List<UserDirectorate> directorates = new ArrayList<UserDirectorate>();

		if (null != user && null != user.getDirectorates()
				&& !user.getDirectorates().isEmpty()) {
			List<UserDirectorate> dirs = user.getDirectorates();

			for (UserDirectorate dir : dirs) {
				if (dir.getDirectorateLevel() != null
						&& dir.getDirectorateLevel().equalsIgnoreCase(
								ECMSConstants.DIRECTORATE_LOCAL)) {
					directorates
							.add(setDirectorate(ECMSConstants.LOCAL).get(0));
				} else if (dir.getDirectorateLevel() != null
						&& dir.getDirectorateLevel().equalsIgnoreCase(
								ECMSConstants.DIRECTORATE_REGIONAL)) {
					directorates.add(setDirectorate(ECMSConstants.REGIONAL)
							.get(0));
				} else if (dir.getDirectorateLevel() != null
						&& dir.getDirectorateLevel().equalsIgnoreCase(
								ECMSConstants.DIRECTORATE_NATIONAL)) {
					directorates.add(setDirectorate(ECMSConstants.NATIONAL)
							.get(0));
				}

			}
		}
		return directorates;
	}

	/**
	 * Helper method to set a dummy directorate
	 * 
	 * @param level
	 * @return list
	 */
	private List<UserDirectorate> setDirectorate(String level) {

		UserDirectorate userDir = new UserDirectorate();
		userDir.setDirectorateLevel(level);
		List<UserDirectorate> list = new ArrayList<UserDirectorate>();
		list.add(userDir);

		return list;
	}

	/**
	 * Setter for CaseFacade.
	 * 
	 * @param caseFacade
	 *            The caseFacade to set.
	 */
	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
