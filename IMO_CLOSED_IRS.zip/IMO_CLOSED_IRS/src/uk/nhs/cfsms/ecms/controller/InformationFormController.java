package uk.nhs.cfsms.ecms.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindException;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.authorization.AccessControl;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.infoGath.InformationPermission;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;
import uk.nhs.cfsms.ecms.dto.infoGath.AuthorizedSubmission;
import uk.nhs.cfsms.ecms.dto.infoGath.InfoTransferHistTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationDetails;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.NHSSubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SourceInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.service.OrganisationService;
import uk.nhs.cfsms.ecms.service.UserInformationService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.InformationUtil;
import uk.nhs.cfsms.ecms.utility.PatientOccupationLookupMap;

/**
 * InformationFormController provides a single form to control the information.
 * 
 * @author schilukuri
 * 
 */
public class InformationFormController extends BaseWizardFormController {

	@Autowired
	InformationGatherService informationGatherFacade;

	@Autowired
	LookupViewService lookupViewFacade;

	@Autowired
	OrganisationService organisationFacade;

	@Autowired
	private AuditLogService auditLogFacade;
	
	@Autowired
	private UserInformationService userInformationService;

	static final String ASSOCIATE = "ASSOCIATE";
	static final String SOURCE = "SOURCE";
	static final String SUBJECT = "SUBJECT";

	static final String infoFormPath = "/secure/information.htm";

	static final String[] pages = { "informationView", "informationView",
			"informationView", "informationView", "associateInformationView",
			"informationView", "informationViewSuccess", "unAuthorizedInfoView" };

	// Form submit fields for INFORMATION embedded in Java
	private static final String[] INFO_FIELD_NAMES = { "_finish", "_cancel",
			"newSubject", "acceptAllocate", "acceptOverload", "rejectCase",
			"transfer", "intel" };

	private static final String[] INFO_FIELD_VALUES = { "Save", "Cancel",
			"Add New Subject", "Accept and Allocate", "Accept and Overload",
			"Reject as Case", "Transfer", "Intel" };

	private static final String[][] INFO_FIELD_EVENTS = {
			{ INFO_FIELD_NAMES[0], "" }, { INFO_FIELD_NAMES[1], "" },
			{ INFO_FIELD_NAMES[2], "addSubject();return false;" },
			{ INFO_FIELD_NAMES[3], "allocateUserToCase();return false;" },
			{ INFO_FIELD_NAMES[4], "acceptAndHoldCase();return false;" },
			{ INFO_FIELD_NAMES[5], "rejectCase();return false;" },
			{ INFO_FIELD_NAMES[6], "transferInfo();return false;" },
			{ INFO_FIELD_NAMES[7], "intel();return false;" } };

	protected final Log log = LogFactory.getLog(getClass());

	@SuppressWarnings("deprecation")
	public InformationFormController() {

		this.setPages(pages);
		this.setCommandName("information");
		this.setCommandClass(InformationTO.class);
		setAllowDirtyForward(true);
	}

	@Override
	protected Object formBackingObject(HttpServletRequest request)
			throws Exception {

		log.info("** formBackingObject");

		InformationDetails info = null;
		/*
		   		HttpSession session = request.getSession();
				Object obj = session.getAttribute(ECMSConstants.SESSION_INFORMATION);
				if (obj instanceof InformationDetails) {
					info = (InformationDetails) obj;
				}
		*/
		String id = request.getParameter("infoId");

		if (StringUtils.isNotEmpty(id)) {

			if (info == null || !isSameInfoId(id, info)) {

				if (EcmsUtils.onShowPage(request)) {

					info = this.getInformationDetails(id, request, true);

				} else if (EcmsUtils.onShowClosedPage(request)) { // NEW CLOSED PAGE -- TODO -- check

					info = this.getInformationDetails(id, request, false);
				}
				//	session.setAttribute(ECMSConstants.SESSION_INFORMATION, info);
			}
		}
		return info != null ? info.getInformationTO() : null;
	}

	/**
	 * Helper method.
	 * 
	 * @param id
	 * @param info
	 * @return boolean.
	 */
	private boolean isSameInfoId(String id, InformationDetails info) {

		if (null != info
				&& null != info.getInformationTO()
				&& null != info.getInformationTO().getInformationId()
				&& info.getInformationTO().getInformationId().toString()
						.equals(id.trim())) {

			return true;
		}
		return false;
	}

	/**
	 * Get the InformationDetails for an Information ID
	 * 
	 * @param id
	 *            informationId
	 * @param request
	 *            HttpServletRequest
	 * @return InformationDetails
	 */
	private InformationDetails getInformationDetails(String id,
			HttpServletRequest request, boolean state) throws Exception {

		boolean infoAuthorised = false;

		InformationDetails info = null;

		Long infoId = new Long(id);

		HttpSession session = request.getSession();

		SessionUser sessionUser = EcmsUtils.getSessionUserObject(session);

		final String userName = sessionUser.getFirstName() + " "
				+ sessionUser.getLastName();
		AccessControl access = EcmsUtils.getCurrentAccessControl(session,
				infoFormPath);

		if (null != access) {

			List<String> paramValues = EcmsUtils.getParamValues(request,
					access.getAllUrlParams());

			if (paramValues.contains(id)) {

				if (log.isDebugEnabled()) {
					log.debug("CHECKING ACCESS(AUTHRZTN), InfoId=" + id);
				}
				infoAuthorised = informationGatherFacade
						.checkAccessToInformation(infoId, sessionUser, state);
			}
		}

		if (null == access) {

			log.error("\n\n ACCESS CONTROL IS NULL, CHECK DATA !");
		}

		if (infoAuthorised) {

			if (log.isDebugEnabled()) {
				log.debug("Info Autherised : " + infoAuthorised);
			}
			info = informationGatherFacade.loadInformationById(infoId);
		} else {
			log.error(" *** No Autherisation for InfoID="
					+ infoId
					+ " for user="
					+ (null != sessionUser ? sessionUser.getStaffId()
							: "-Unknown-"));
		}

		if (null != info && null != info.getInformationTO()) {

			List teamCodes = null;

			List<Organisation> orgCodes = null;

			InformationTO infoTO = info.getInformationTO();

			infoTO.setUserName(userName);

			SourceInformationTO sourceTO = infoTO.getSourceInformationTO();

			if (null != sourceTO
					&& StringUtils.isEmpty(sourceTO.getSourceType())
					&& StringUtils.isNotEmpty(sourceTO.getOtherSource())) {

				sourceTO.setSourceType(ECMSConstants.SOURCE_TYPE_OTHER);
				infoTO.setSourceInformationTO(sourceTO);
			}

			this.setupFormSubmission(infoTO, request);

			if (session.getAttribute("teamCodesList") != null) {

				teamCodes = (List) session.getAttribute("teamCodesList");
			}
			if (session.getAttribute("orgCodesList") != null) {

				orgCodes = (List) session.getAttribute("orgCodesList");
			}

			if (null == teamCodes) {

				teamCodes = organisationFacade.loadAllTeamCodes();
				infoTO.setTeamCodesList(teamCodes);

				orgCodes = organisationFacade.loadOrganisationsByOrgName("",
						sessionUser);
				// Set in the session.
				session.setAttribute("teamCodesList", teamCodes);
				session.setAttribute("orgCodesList", orgCodes);
			}

			// Update select(drop down) list based on lookup groups.
			updateSourceLookupDetails(infoTO);
			updateFruadAreaAndTypesLookupDetails(infoTO);

			if (null != infoTO.getSubjectInfoList()) {

				updateSubjectNHSOccupationTypes(infoTO);
			}
			if (!InformationUtil.hasLookupDetails(infoTO)) {

				if (logger.isInfoEnabled()) {
					logger.info("No LOOKUP found, creating LOOKUP data");
				}
				this.setupAllLookupDetails(infoTO);
			}

			// Loading Information Transfer history.
			//InfoTransferHistTO transferHistory = informationGatherFacade.loadInformationHistory(infoId);
			InfoTransferHistTO transferHistory = informationGatherFacade
					.loadInformationHistoryByApprover(infoId,
							sessionUser.getStaffId());

			String transferTeamCode = null;

			if (null != transferHistory) {

				infoTO.setInfoTransferHistTO(transferHistory);

				transferTeamCode = transferHistory.getTransferTeamCode();
			}

			infoTO.setReadOnlyInfo(isInfoReadOnly(infoTO,
					sessionUser.getStaffId(), transferTeamCode));
			info.setInformationTO(infoTO);

		} else {

			// Create informationTo and set the created user details.
			info = informationGatherFacade.createFraudDetailsTO();

			// Case where information has been converted to a Case.
			InformationTO caseInfoTO = informationGatherFacade
					.loadInformationTOById(infoId);

			if (null != caseInfoTO && null != caseInfoTO.getCaseId()) {

				info.setInformationTO(caseInfoTO);
			}

			info.getInformationTO().setDataOwner(
					informationGatherFacade.getOwnerDetailsByInfoId(infoId));
		}

		// check for FPU system weakness record.
		info.getInformationTO().setFpuSystemWeakness(
				informationGatherFacade.isFPUSystemWeakness(infoId));

		if (log.isDebugEnabled()) {
			InformationUtil.debugLookup(info.getInformationTO(), log);
		}

		return info;
	}

	/**
	 * The information as readOnly for the Non_info_assignee users.
	 * 
	 */
	private boolean isInfoReadOnly(InformationTO infoTO, String staffId,
			String newTeam) {

		for (InformationPermission p : infoTO.getInfoPermissionList()) {

			if ((ECMSConstants.INFO_PERMISSION_READ_ONLY.equalsIgnoreCase(p
					.getPermissionType()) && staffId.equalsIgnoreCase(p
					.getPermissionValue()))
					|| (ECMSConstants.TEAM_PERMISSION.equalsIgnoreCase(p
							.getPermissionType()) && null != newTeam && !newTeam
								.equalsIgnoreCase(p.getPermissionValue()))) {

				return true;
			}
		}
		return false;
	}

	@Override
	protected void onBindAndValidate(HttpServletRequest request,
			Object command, BindException errors, int page) throws Exception {

		log.info("** onBindAndValidate, PAGE =" + page);

		if (this.isCancelRequest(request)) {

			return;
		}
		InformationTO infoTO = (InformationTO) command;

		switch (page) {

		case 0:
		case 1:
		case 2:
		case 3:
		default:

			if (request.getParameter("_target1") != null) {
				// SOURCE
				this.checkAndAddAddress(infoTO, request, SOURCE);

			} else if (request.getParameter("_target2") != null) {
				// SUBJECT PERSON
				this.checkAndAddAddress(infoTO, request, SUBJECT);

			} else if (request.getParameter("_target3") != null) {
				// ASSOCIATE
				this.checkAndAddAddress(infoTO, request, ASSOCIATE);
				// info.setTeamCodesList(baseFacade.getObjects(TeamCodes.class));
			} else if (request.getParameter("_target4") != null) {
				// ASSOCIATE
				infoTO.setTeamCodesList(organisationFacade.loadAllTeamCodes());
			}
			break;
		}
		;

		saveInformationToSession(request, infoTO);

		super.onBindAndValidate(request, command, errors, page);
	}

	@Override
	protected String getViewName(HttpServletRequest request, Object command,
			int page) {

		log.info("** getViewName @ page=" + page);

		InformationTO infoTO = (InformationTO) command;

		String pages[] = getPages();

		// Information is now a case, Not Authorised to view, except FCRL.
		if ((null == infoTO.getCreatedStaffId()
				|| null == infoTO.getCreatedDate() || null != infoTO
				.getCaseId()) && !this.isInfoCreatedByFCRL(request, infoTO)) {

			return pages[7];
		}

		if (page < 6 && infoTO != null) {

			// Save the current command details in session.
			this.saveInformationToSession(request, infoTO);

			if (request.getParameter("_target1") != null) {

				log.info("** INFO DETAILS ");

				return pages[1];
			} else if (request.getParameter("_target2") != null) {

				log.info("** SOURCE DETAILS ");

				return pages[2];
			} else if (request.getParameter("_target3") != null) {

				log.info("** ADMIN DETAILS ");

				return pages[3];
			} else if (request.getParameter("_target4") != null) {

				log.info("** ASSOCIATE DETAILS ");

				return pages[4];
			} else if (request.getParameter("_target5") != null) {

				log.info("** VEHICLE DETAILS ");

				return pages[3];
			}
		}
		return pages[page];
	}

	/**
	 * Check Information is created by the logged in FCRL.
	 * 
	 * @param request
	 * @param infoTO
	 * @return boolean.
	 */
	private boolean isInfoCreatedByFCRL(HttpServletRequest request,
			InformationTO infoTO) {

		String staffId = infoTO.getCreatedStaffId();

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		if (null != staffId && null != user && staffId.indexOf("fcrl") != -1
				&& user.isUserFCRL()) {

			return true;
		}

		return false;
	}

	private void saveInformationToSession(HttpServletRequest request,
			InformationTO infoTO) {

		HttpSession session = request.getSession();

		Object object = session.getAttribute(ECMSConstants.SESSION_INFORMATION);

		InformationDetails info = null;

		if (object != null) {
			info = (InformationDetails) object;
		} else {
			info = new InformationDetails();
		}

		info.setInformationTO(infoTO);

		session.setAttribute(ECMSConstants.SESSION_INFORMATION, info);
	}

	@Override
	protected ModelAndView processFinish(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {

		ModelAndView modelAndView = null;
		final String infoId = (String) request.getAttribute("infoId");
		final String redirect = (String) request.getAttribute("redirect_from");
		System.out.println("infoId=" + infoId);
		System.out.println("redirect=" + redirect);

		if (redirect != null && redirect.equals("info_progress")) {
			modelAndView = new ModelAndView(new RedirectView(
					"information.htm?dispatch=query&actionType=showInfo&infoId="
							+ new Long(infoId)));
		} else {
		log.info("** processFinish");

		String[] allPages = getPages();

		try {
			InformationTO info = (InformationTO) command;
			String otherSource = info.getSourceInformationTO().getOtherSource();

			if (otherSource != null && !otherSource.trim().equals("")) {
				info.getSourceInformationTO().setSource("");
			}

			if (log.isDebugEnabled()) {
				log.debug("ORG CODE =" + info.getOrgCode() + ", ORG NAME ="
						+ info.getOrgName());
			}
			validateInformation(info, request, errors);

			if (errors.getErrorCount() < 1) {
				SessionUser user = EcmsUtils.getSessionUserObject(request
						.getSession());
				String curDate = EcmsUtils.getDateToddMMyyyy(new Date(System
						.currentTimeMillis()));

				if (StringUtils.isNotEmpty(info.getInformationDetails())) {
					if (StringUtils.isNotEmpty(info.getNewInformationDetails())) {
						if(!info.getNewInformationDetails().equals(info.getInformationDetails())){
							info.setInformationDetails(info.getInformationDetails()
									.trim()
									+ "	(Created By: "
									+ user.getFullName()
									+ ", On: " + curDate + ")");
						}
					}else{
						info.setInformationDetails(info.getInformationDetails()
								.trim()
								+ "	(Created By: "
								+ user.getFullName()
								+ ", On: " + curDate + ")");
					}
				}
				
				if (StringUtils.isNotEmpty(info.getComment())) {
					
			if (StringUtils.isNotEmpty(info.getNewComment())) {
				if(!info.getNewComment().equals(info.getComment())){
					info.setComment(info.getComment()
							.trim()
							+ "	(Created By: "
							+ user.getFullName()
							+ ", On: " + curDate + ")");
				     }
				  }else{
					  info.setComment(info.getComment()
								.trim()
								+ "	(Created By: "
								+ user.getFullName()
								+ ", On: " + curDate + ")");
				  }
				}
				if (info.getInformationId() == null) {
					AuditFlowThread.set("New Information Created");
				} else {
					AuditFlowThread.set("Information Updated");
				}
				informationGatherFacade.saveInformation(info, user);
				createInformationAudit(info, AuditLogService.UPDATE,
						"Information", request, auditLogFacade);

				//return new ModelAndView(new RedirectView("listInformation.htm"));

				return new ModelAndView(new RedirectView(
						"information.htm?dispatch=query&actionType=showInfo&infoId="
								+ info.getInformationId()));

			}

		} catch (Exception e) {
			log.error(e);
				modelAndView = new ModelAndView(allPages[allPages.length - 1],
						"message", e.getMessage());
		}
			modelAndView = super.processFormSubmission(request, response,
					command, errors);
		}
		return modelAndView;
	}

	@Override
	protected ModelAndView processCancel(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		log.info("** processCancel");

		invalidateSessionAttribute(request);

		return new ModelAndView(new RedirectView("listInformation.htm"));
	}

	private void invalidateSessionAttribute(HttpServletRequest request) {

		HttpSession session = request.getSession();
		Object infoObj = session
				.getAttribute(ECMSConstants.SESSION_INFORMATION);

		if (infoObj instanceof InformationDetails) {
			session.removeAttribute(ECMSConstants.SESSION_INFORMATION);
		}
	}

	/**
	 * Setup all lookup details for information.
	 * 
	 * @param Information
	 */
	private void setupAllLookupDetails(InformationTO info) {

		log.info("Updating AllLookupDetails");

		String[] lookupGroupNames = InformationUtil.getAllLookupGroups();

		for (String groupName : lookupGroupNames) {
			info.addInfoLookupViewMap(groupName, getLookupDetails(groupName));
		}

		info.setStaticInfoLookupViewMap();

		setUpPatientOccupationLookupDetails();
	}

	/**
	 * Helper method to load Source Type and Source Lookup details.
	 * 
	 * @param info
	 */
	private void updateSourceLookupDetails(InformationTO info) throws Exception {

		log.info("Updating SourceLookupDetails");

		if (null != info && null != info.getSourceInformationTO()) {

			SourceInformationTO srcTO = info.getSourceInformationTO();

			if (null != srcTO && StringUtils.isNotEmpty(srcTO.getSource())) {

				LookupView view = lookupViewFacade
						.loadLookupDetailsById(new Integer(srcTO.getSource()));

				if (view != null) {
					srcTO.setSourceType(view.getParentId().toString());
					info.addDynamicInfoLookupViewMap(
							ECMSConstants.LOOKUP_SOURCE_SUB_TYPE,
							lookupViewFacade
									.loadActiveLookupDetailsByParentId(view
											.getParentId()));
					// info.addDynamicInfoLookupViewMap(ECMSConstants.LOOKUP_SOURCE,
					// getLookupDetails(ECMSConstants.LOOKUP_SOURCE));
				}
			}
		}
	}

	/**
	 * Update Lookup details for LOOKUP_NHS_FRAUD_AREA, LOOKUP_FRAUD_SUB_AREA_1,
	 * LOOKUP_FRAUD_SUB_AREA_2 and LOOKUP_AREA_FRAUD_TYPE
	 * 
	 * @param info
	 *            InformationTO.
	 */
	private void updateFruadAreaAndTypesLookupDetails(InformationTO info) {

		log.info("Updating FruadAreaAndTypesLookupDetails");

		if (null != info) {

			// info.addDynamicInfoLookupViewMap(ECMSConstants.LOOKUP_NHS_FRAUD_AREA,
			// getLookupDetails(ECMSConstants.LOOKUP_NHS_FRAUD_AREA));

			if (StringUtils.isNotEmpty(info.getFraudArea())) {

				LookupView view = lookupViewFacade
						.loadLookupDetailsById(new Integer(info.getFraudArea()));

				info.addDynamicInfoLookupViewMap(
						ECMSConstants.LOOKUP_FRAUD_SUB_AREA_1, lookupViewFacade
								.loadActiveLookupDetailsByParentId(new Integer(
										info.getAreatype()), view.getGroupId()));
			}

			if (StringUtils.isNotEmpty(info.getFraudSubArea())) {

				LookupView view = lookupViewFacade
						.loadLookupDetailsById(new Integer(info
								.getFraudSubArea()));

				info.addDynamicInfoLookupViewMap(
						ECMSConstants.LOOKUP_FRAUD_SUB_AREA_2,
						lookupViewFacade.loadActiveLookupDetailsByParentId(
								new Integer(info.getFraudArea()),
								view.getGroupId()));
			}

			if (StringUtils.isNotEmpty(info.getNhsFraudType())) {

				LookupView view = lookupViewFacade
						.loadLookupDetailsById(new Integer(info
								.getNhsFraudType()));

				info.addDynamicInfoLookupViewMap(
						ECMSConstants.LOOKUP_AREA_FRAUD_TYPE,
						lookupViewFacade.loadActiveLookupDetailsByParentId(
								new Integer(info.getFraudArea()),
								view.getGroupId()));
			}
		}
	}

	private void updateSubjectNHSOccupationTypes(InformationTO info) {

		log.info("Updating Subject NHS OccupationTypes");

		List<SubjectInformationTO> subjectList = info.getSubjectInfoList();

		for (int i = 0; i < subjectList.size(); i++) {

			SubjectInformationTO subj = subjectList.get(i);

			if (null != subj && null != subj.getSubjectPersonTO()) {

				PersonTO pTO = subj.getSubjectPersonTO();

				if (pTO.isPersonWorkingForNHS()
						&& null != pTO.getNhsOccupationType()) {

					LookupView view = lookupViewFacade
							.loadLookupDetailsById(new Integer(pTO
									.getNhsOccupationType()));
					info.addDynamicInfoLookupViewMap(
							ECMSConstants.LOOKUP_OCCUPATION_NHS_TYPE + i,
							lookupViewFacade.loadActiveLookupDetailsByParentId(
									new Integer(pTO.getNhsCareerArea()),
									view.getGroupId()));
				}
			}
		}
	}

	/**
	 * Validate Information.
	 * 
	 * @param info
	 * @param request
	 * @param err
	 */
	private void validateInformation(InformationTO info,
			HttpServletRequest request, BindException err) {

		// Validation orgCode in information
		ValidationUtils.rejectIfEmptyOrWhitespace(err, "orgCode",
				"required.orgCode",
				"Please enter mandatory field 'Org Code' for Information.");

		if (!info.hasValidOrgCode()) {
			err.rejectValue("orgCode", "invalid.orgCode",
					"Please enter valid 'Organisation Details' for Information.");
		}

		if (!EcmsUtils.isValidNumber(info.getCost())) {
			err.rejectValue("cost", "invalid.estimatedcost",
					"Please enter valid Estimated cost(eg.100.25 or 155)");
		}

		// Validation for OrgCode in NHS Subject.
		List<NHSSubjectInformationTO> subList = info.getNhsSubjectInfoList();

		if (null != subList && !subList.isEmpty()) {

			int count = 0;
			for (NHSSubjectInformationTO nhs : info.getNhsSubjectInfoList()) {

				if (!nhs.hasValidOrgCode()) {

					err.rejectValue("nhsSubjectInfoList[c].orgCode",
							"required.nhsSubjectInfoList[c].orgCode",
							"Please enter mandatory field 'Org Code' for NHS Subject -"
									+ (count + 1));
				}
				count++;
			}
		}
	}

	/**
	 * LookupView Details given the group name
	 * 
	 * @param groupName
	 * @return List.
	 */
	private List<LookupView> getLookupDetails(String groupName) {

		if (groupName != null) {

			return lookupViewFacade.loadActiveLookupDetailsByGroups(groupName);
		}
		return null;
	}

	/**
	 * LookupView details for patient occupation
	 * 
	 * @return List.
	 */
	private void setUpPatientOccupationLookupDetails() {
		final List<LookupView> lookupList = lookupViewFacade
				.loadPatientOccupationDescriptions();
		for (LookupView view : lookupList) {
			final String lookupId = String.valueOf(view.getLookupId());
			final String description = view.getDescription();
			final Map<String, String> map = PatientOccupationLookupMap
					.getAllPatientOccupationDetailsLookupMap();
			if (!map.containsKey(lookupId)) {
				map.put(lookupId, description);
			}
		}
	}

	/**
	 * Add new address or contact to Information SOURCE, SUBJECT, ASSOCIATE.
	 * 
	 * @param info
	 *            InformationTO
	 * @param request
	 *            HttpServletRequest
	 * @param type
	 *            (SOURCE, SUBJECT, ASSOCIATE)
	 */
	private void checkAndAddAddress(InformationTO info,
			HttpServletRequest request, String type) {

		if (log.isDebugEnabled()) {
			log.debug("CHECKING ADDRESS/CONTACT FOR THE $" + type);
		}
		int index = 0;
		PersonTO pTO = null;

		if (type != null && type.equalsIgnoreCase(SOURCE)) {
			pTO = info.getSourceInformationTO().getSourcePersonTO();
			updatePersonTO(pTO, request);

		} else if (type != null && type.equalsIgnoreCase(SUBJECT)) {
			if (request.getParameter("rowIndex") != null) {
				try {
					index = new Integer(request.getParameter("rowIndex"));
				} catch (NumberFormatException nfe) {
					logger.error("\n **NUMBER FORMAT ERROR @ "
							+ "APPLYING NEW PERSON DETAILS TO SUBJECT[0]");
					logger.error(nfe);
				}
				SubjectInformationTO[] subjTO = info.getSubjectInfoList()
						.toArray(
								new SubjectInformationTO[info
										.getSubjectInfoList().size()]);
				updatePersonTO(subjTO[index].getSubjectPersonTO(), request);
			} else {
				for (SubjectInformationTO subjInfo : info.getSubjectInfoList()) {
					pTO = subjInfo.getSubjectPersonTO();
					updatePersonTO(pTO, request);
				}
			}
		} else if (type != null && type.equalsIgnoreCase(ASSOCIATE)) {

			if (request.getParameter("rowIndex") != null) {
				try {
					index = new Integer(request.getParameter("rowIndex"));
				} catch (NumberFormatException nfe) {
					logger.error("\n **NUMBER FORMAT ERROR @ "
							+ "APPLYING NEW PERSON DETAILS TO ASSOCIATE[0]");
					logger.error(nfe);
				}
				CaseContactTO[] assocTO = info.getCaseAssociates().toArray(
						new CaseContactTO[info.getCaseAssociates().size()]);
				updatePersonTO(assocTO[index].getPersonTO(), request);
			} else {
				for (CaseContactTO associate : info.getCaseAssociates()) {
					pTO = associate.getPersonTO();
					updatePersonTO(pTO, request);
				}
			}
		}
	}

	private void updatePersonTO(PersonTO pTO, HttpServletRequest request) {
		if (pTO != null) {
			EcmsUtils.addNewAddressOrContactToPerson(pTO, request);
		}
	}

	/**
	 * Setup form submission.
	 * 
	 * @param informationTO
	 */
	private void setupFormSubmission(InformationTO infoTO,
			HttpServletRequest request) {

		List<AuthorizedSubmission> authFields = new ArrayList<AuthorizedSubmission>();

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		if (log.isDebugEnabled() && null != user) {
			log.debug("** User=" + user.getStaffId() + ", Resp Team Codes ="
					+ user.getOrgOrTeamResponsibilities());
		}
		// TODO: EXTRAS TO CHECK..
		// String assignedUser = infoTO.getAssignedUserFromInfoPermissions();
		// String OrgCode = infoTO.getOrgFromInfoPermissions();

		String teamCode = infoTO.getTeamFromInfoPermissions();

		/** Be careful with changing the ECMSConstants INFO FIELD NAMES * */
		for (int i = 0; i < INFO_FIELD_NAMES.length - 1; i++) {
			AuthorizedSubmission field = new AuthorizedSubmission();
			String fieldName = INFO_FIELD_NAMES[i];
			field.setName(fieldName);
			field.setValue(INFO_FIELD_VALUES[i]);

			List<String> permsLevelList = new ArrayList<String>();
			// For submit/cancel/Add Subjects..
			if (i < 3) {
				if (null != user
						&& null != infoTO.getCreatedStaffId()
						&& infoTO.getCreatedStaffId().equalsIgnoreCase(
								user.getStaffId())) {
					if (user.isUserLCFS()) {
						permsLevelList.add(ECMSConstants.LCFS_LEVEL);
					}
					if (user.isUserCFS()) {
						permsLevelList.add(ECMSConstants.CFS_LEVEL);
					}
					if (user.isUserFCRL()) {
						permsLevelList.add(ECMSConstants.FCRL_LEVEL);
					}
					if (user.isUserDirectorate()) {
						permsLevelList.add(ECMSConstants.OFM_LEVEL);
					}
					if (user.isUserOFM()) {
						for (String usrTC : user.getOrgOrTeamResponsibilities()) {
							if (usrTC.equals(teamCode)) {
								permsLevelList.add(ECMSConstants.OFM_LEVEL);
								break;
							}
						}
					}
					if (user.isUserAntiFraudLead()) {
						for (String usrTC : user.getOrgOrTeamResponsibilities()) {
							if (usrTC.equals(teamCode)) {
								permsLevelList.add(ECMSConstants.AFL_LEVEL);
								break;
							}
						}
					}
				}

				permsLevelList.add(ECMSConstants.DIRECTOR_LEVEL);
				permsLevelList.add(ECMSConstants.ADMIN_LEVEL);
			} else { // Rest of the ITC

				if (null != user && user.isUserOFM()) {
					permsLevelList.add(ECMSConstants.OFM_LEVEL);
				}
				if (null != user && user.isUserAntiFraudLead()) {
					permsLevelList.add(ECMSConstants.AFL_LEVEL);
				}
			}
			field.setPermissionLevelList(permsLevelList);
			List<String> eventList = new ArrayList<String>();
			for (int j = 1; j < INFO_FIELD_EVENTS[i].length; j++) {
				eventList.add(INFO_FIELD_EVENTS[i][j]);
			}
			field.setOnClickEventList(eventList);

			authFields.add(field);
		}
		infoTO.setFormFieldList(authFields);
	}

	/**
	 * Setter method for the service.
	 * 
	 * @param informationGatherFacade
	 */
	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}

	public void setLookupViewFacade(LookupViewService lookupViewFacade) {
		this.lookupViewFacade = lookupViewFacade;
	}

	/**
	 * @param organisationFacade
	 *            The organisationFacade to set.
	 */
	public void setOrganisationFacade(OrganisationService organisationFacade) {
		this.organisationFacade = organisationFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
}
