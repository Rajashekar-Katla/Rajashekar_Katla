package uk.nhs.cfsms.ecms.controller;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.infoGath.Address;
import uk.nhs.cfsms.ecms.data.infoGath.PersonAlias;
import uk.nhs.cfsms.ecms.data.infoGath.PersonContacts;
import uk.nhs.cfsms.ecms.data.infoGath.SubjectInformation;
import uk.nhs.cfsms.ecms.data.witness.NonAvailableDate;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationDetails;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.witness.WitnessTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseContactService;
import uk.nhs.cfsms.ecms.service.SubjectService;
import uk.nhs.cfsms.ecms.service.WitnessService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * WitnessController is for handling Witness form data. Includes Saving and
 * Updating witness data.
 * 
 */
@Controller
// @RequestMapping("/secure/witness.htm")
public class WitnessController extends BaseBinder {

	@Autowired
	WitnessService witnessFacade;

	@Autowired
	private SubjectService subjectFacade;

	@Autowired
	private CaseContactService caseContactFacade;

	@Autowired
	private AuditLogService auditLogFacade;

	protected final Log log = LogFactory.getLog(getClass());

	private CustomDateEditor customDateEditor;

	static final String WITNESS_LIST_PAGE = "listWitness.htm?actionType=listwitness&crumbsEnabled=false&caseId=";

	static final String WITNESS_ID_PARAM = "witnessId";

	@RequestMapping(value = "/secure/witness.htm", method = RequestMethod.POST)
	public ModelAndView processSubmit(
			@ModelAttribute("createWitness") WitnessTO witnessTO, ModelMap map,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("processSubmit()");
		}

		WitnessTO dto = null;

		if (EcmsUtils.addNewAddressOrContactToPerson(witnessTO.getPerson(),
				request)
				|| EcmsUtils.addNewNonAvailableDate(witnessTO, request)) {

			map.addAttribute("witnessObject", witnessTO);
			return new ModelAndView("createWitness");
		}

		if (EcmsUtils.onCancel(request)) {

			return new ModelAndView(new RedirectView(WITNESS_LIST_PAGE
					+ witnessTO.getCaseId()));
		}

		if (onConvertToSubject(request)) {

			AuditFlowThread.set("Convert Case Witness to Subject");
			witnessFacade.updateWitnessToSubject(witnessTO);
			// createAudit(witnessTO, AuditLogService.UPDATE,
			// "Convert Case Witness to Subject", request, auditLogFacade);

			return CaseUtil.getCaseWitnessListView();
		}

		if (EcmsUtils.onFinish(request)) {

			if (null == witnessTO.getWitnessId()) {
				witnessTO.setCreatedTime(new Timestamp(System
						.currentTimeMillis()));
			}
			witnessTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId());

			// No state then witness_used.
			if (StringUtils.isEmpty(witnessTO.getState())) {

				witnessTO.setState(ECMSConstants.WITNESS_USED);
			}

			// Redundant reloading WitnessTO for MGForm...

			if (null != witnessTO.getWitnessId()) {

				dto = loadWitness(witnessTO.getWitnessId().toString(), false);
			}

			if (witnessTO.getMg2Form().length == 0) {

				witnessTO.setMg2Form(null != dto ? dto.getMg2Form() : null);
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				MultipartFile multipartFile = multipartRequest
						.getFile("mg2Form");
				witnessTO.setMg2FormFileName(multipartFile
						.getOriginalFilename());
				witnessTO.setMg2FormFileType(multipartFile.getContentType());

			}

			if (witnessTO.getMg6Form() != null
					&& witnessTO.getMg6Form().length == 0) {

				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				MultipartFile multipartFile = multipartRequest
						.getFile("mg6Form");
				witnessTO.setMg6FormFileName(multipartFile
						.getOriginalFilename());
				witnessTO.setMg6FormFileType(multipartFile.getContentType());

				witnessTO.setMg6Form(null != dto ? dto.getMg6Form() : null);
			}

			if (null == witnessTO.getWitnessId()) {

				if (log.isDebugEnabled()) {
					log.debug(" Creating Witness!");
				}
				AuditFlowThread.set("Witness Created");
				witnessTO = witnessFacade.saveWitness(witnessTO, false);
				// createAudit(witnessTO, AuditLogService.CREATE,
				// "Witness created", request, auditLogFacade);

			} else {
				if (log.isDebugEnabled()) {
					log.debug(" Updating Witness!");
				}
				AuditFlowThread.set("Witness Updated");
				witnessFacade.updateWitness(witnessTO);

				// createAudit(witnessTO, AuditLogService.UPDATE,
				// "Witness Updated", request, auditLogFacade);
			}

			if (null != witnessTO.getWitnessId()) {

				return new ModelAndView(new RedirectView(WITNESS_LIST_PAGE
						+ witnessTO.getCaseId()));
			}
		}

		if (log.isDebugEnabled()) {
			log.debug("\nAvoiding command object and creating a new Witness!");
		}
		witnessTO = new WitnessTO();
		witnessTO.setCaseId(new Long(CaseUtil.getCaseId(request)));
		map.addAttribute("witnessObject", witnessTO);
		// return new ModelAndView(getFormView(), getCommandName(), witnessTO);
		return new ModelAndView("createWitness");

	}

	@RequestMapping(value = "/secure/saveLookupUserWitness.htm", method = RequestMethod.POST)
	public ModelAndView saveLookupUserWitness(
			@ModelAttribute("createWitness") WitnessTO witnessTO, ModelMap map,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("saveLookupUserWitness()");
		}

		// No state then witness_used.
		if (StringUtils.isEmpty(witnessTO.getState())) {
			witnessTO.setState(ECMSConstants.WITNESS_USED);
		}

		witnessTO.setCreatedTime(new Date());
		witnessTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
				request.getSession()).getStaffId());

		if (log.isDebugEnabled()) {
			log.debug(" Creating Witness!");
		}
		AuditFlowThread.set("Witness Created");
		witnessTO = witnessFacade.saveWitness(witnessTO, true);

		if (log.isDebugEnabled()) {
			log.debug("\nAvoiding command object and creating a new Witness!");
		}
		map.addAttribute("witnessObject", witnessTO);
		return new ModelAndView(new RedirectView(WITNESS_LIST_PAGE
				+ witnessTO.getCaseId()));

	}

	@RequestMapping(value = "/secure/lookupWitness.htm", method = RequestMethod.GET)
	public String lookupWitness(
			@RequestParam(value = "witnessId", required = false) String witnessID,
			@RequestParam(value = "isLookupSave", required = false) boolean isLookupSave,
			@RequestParam(value = "stateValue", required = false) String state,
			@ModelAttribute WitnessTO witnessTO, ModelMap model,
			HttpServletRequest request) throws CaseIDNotFoundException,
			ServletException, ServiceException {

		if (log.isDebugEnabled()) {
			log.debug("lookupWitness().");
		}

		final String caseId = CaseUtil.getCaseId(request);

		if (state.equals("Witness")) {
			witnessTO = loadWitness(witnessID, EcmsUtils.onCancel(request));
			witnessTO.setCaseId(new Long(caseId));
		} else if (state.equals("Subject")) {
			final SubjectInformation subjectInformation = subjectFacade
					.loadSubjectById(new Long(witnessID));
			subjectInformation.setCaseId(new Long(caseId));
			witnessTO = CaseUtil.convertToWitnessTO(subjectInformation);
		} else if (state.equals("Contact")) {
			final CaseContact caseContact = caseContactFacade
					.findContactByIdForWitnessLookupUser(new Long(witnessID));
			caseContact.setCaseId(new Long(caseId));
			witnessTO = CaseUtil.convertToWitnessTO(caseContact);
		}

		witnessTO.setWitnessId(null);
		//witnessTO.setCaseId(new Long(CaseUtil.getCaseId(request)));
		witnessTO.setLookupSave(isLookupSave);

		model.addAttribute("witnessObject", witnessTO);

		return "createWitness";

	}

	@RequestMapping(value = "/secure/lookupInfoSubjects.htm", method = RequestMethod.POST)
	public String lookupInfoSubjects(
			@RequestParam(value = "subjectId", required = false) String witnessID,
			@RequestParam(value = "isLookupSave", required = false) boolean isLookupSave,
			@RequestParam(value = "stateValue", required = false) String state,
			ModelMap model, HttpServletRequest request)
			throws CaseIDNotFoundException, ServletException, ServiceException {

		if (log.isDebugEnabled()) {
			log.debug("lookupWitness().");
		}
		InformationDetails informatonDetails = null;
		final String caseId = CaseUtil.getCaseId(request);

		if (state.equals("Witness")) {
			informatonDetails = loadWitnessforInfoSubject(witnessID,
					EcmsUtils.onCancel(request));
			informatonDetails.getSubjectInformationTO().setCaseId(
					new Long(caseId));
		} else if (state.equals("Subject")) {
			final SubjectInformation subjectInformation = subjectFacade
					.loadSubjectById(new Long(witnessID));
			subjectInformation.setCaseId(new Long(caseId));
			informatonDetails = CaseUtil
					.convertToInformationDetails(subjectInformation);
		} else if (state.equals("Contact")) {
			final CaseContact caseContact = caseContactFacade
					.findContactByIdForWitnessLookupUser(new Long(witnessID));
			caseContact.setCaseId(new Long(caseId));
			informatonDetails = CaseUtil
					.convertToInformationDetails(caseContact);
		}

		informatonDetails.getSubjectInformationTO().setSubjectId(null);
		//		witnessTO.setLookupSave(isLookupSave);

		model.addAttribute("infogath", informatonDetails);

		return "subjectPopup";

	}

	@RequestMapping(value = "/secure/lookupContacts.htm", method = RequestMethod.GET)
	public String lookupContacts(
			@RequestParam(value = "caseContactId", required = false) String caseContactId,
			@RequestParam(value = "isLookupSave", required = false) boolean isLookupSave,
			@RequestParam(value = "stateValue", required = false) String state,
			@ModelAttribute CaseContactTO caseContactTO, ModelMap model,
			HttpServletRequest request) throws CaseIDNotFoundException,
			ServletException, ServiceException {

		if (log.isDebugEnabled()) {
			log.debug("lookupWitness().");
		}

		final String caseId = CaseUtil.getCaseId(request);

		if (state.equals("Witness")) {
			caseContactTO = loadWitnessforContact(caseContactId,
					EcmsUtils.onCancel(request));
			caseContactTO.setCaseId(new Long(caseId));
		} else if (state.equals("Subject")) {
			final SubjectInformation subjectInformation = subjectFacade
					.loadSubjectById(new Long(caseContactId));
			subjectInformation.setCaseId(new Long(caseId));
			caseContactTO = CaseUtil.convertToCaseContactTO(subjectInformation);
		} else if (state.equals("Contact")) {
			final CaseContact caseContact = caseContactFacade
					.findContactByIdForWitnessLookupUser(new Long(caseContactId));
			caseContact.setCaseId(new Long(caseId));
			caseContactTO = CaseUtil.convertToCaseContactTO(caseContact);
		}
		caseContactTO.setContactId(null);
		model.addAttribute("caseContactTO", caseContactTO);

		return "caseContact";

	}

	@RequestMapping(value = "/secure/witness.htm", method = RequestMethod.GET)
	public String formBackingObject(
			@RequestParam(value = "witnessId", required = false) String witnessID,
			@RequestParam(value = "actionType", required = false) String action,
			@ModelAttribute WitnessTO witnessTO, ModelMap model,
			HttpServletRequest request) throws ServletException {

		if (log.isDebugEnabled()) {
			log.debug("formBackingObject().");
		}

		if (action != null && action.equalsIgnoreCase(CaseUtil.VIEW_PARAM)) {

			witnessTO = loadWitness(witnessID, EcmsUtils.onCancel(request));
		} else {
			witnessTO = new WitnessTO();

			try {
				witnessTO.setCaseId(new Long(CaseUtil.getCaseId(request)));

			} catch (CaseIDNotFoundException cNF) {
				log.error("CaseId not found while creating Witness:"
						+ cNF.getMessage());
				throw new ServletException(cNF);
			} catch (NumberFormatException nFE) {
				log.error("CaseId Formatting Error:" + nFE.getMessage());
				throw new ServletException(nFE);
			}
			if (null == witnessTO.getPerson()
					|| null == witnessTO.getPerson().getAddressList()
					|| witnessTO.getPerson().getAddressList().isEmpty()) {

				if (log.isDebugEnabled()) {
					log.debug("Initiating new person for Witness");
				}
				PersonTO person = new PersonTO();
				witnessTO.setPerson(person);
			}
		}
		model.addAttribute("witnessObject", witnessTO);

		return "createWitness";

	}

	@RequestMapping(value = "/secure/lookupWitnessUser.htm")
	public ModelAndView lookupWitnessUser(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServiceException,
			CaseIDNotFoundException, IllegalAccessException,
			InvocationTargetException, ParseException {
		final ObjectMapper mapper = new ObjectMapper();

		final String firstName = request.getParameter("firstName");
		final String lastName = request.getParameter("lastName");
		final String dob = request.getParameter("dob");

		final List<WitnessTO> witnessTOs = witnessFacade
				.loadWitnessByNativeSql(firstName, lastName, dob);
		final String witnessViewTOsJSONFormatList = mapper
				.writeValueAsString(witnessTOs);
		FileCopyUtils.copy(witnessViewTOsJSONFormatList, response.getWriter());

		return null;
	}

	private WitnessTO loadWitness(String witnessID, boolean noLoading)
			throws ServletException {

		if (StringUtils.isNotEmpty(witnessID) && (!noLoading)) {
			try {
				return witnessFacade.loadWitnessById(new Long(witnessID));

			} catch (Exception e) {
				log.error(e);
				throw new ServletException("Error loading Witness for ID ="
						+ witnessID);
			}
		}
		WitnessTO witnessTo = new WitnessTO();
		witnessTo.getPerson().addAddress(new Address());
		witnessTo.getPerson().addContacts(new PersonContacts());
		witnessTo.getPerson().addAlias(new PersonAlias());
		witnessTo.addNonAvailableDate(new NonAvailableDate());
		return witnessTo;
	}

	private InformationDetails loadWitnessforInfoSubject(String witnessID,
			boolean noLoading) throws ServletException {

		if (StringUtils.isNotEmpty(witnessID) && (!noLoading)) {
			try {
				return witnessFacade.loadWitnessByIdForInfoSubject(new Long(
						witnessID));

			} catch (Exception e) {
				log.error(e);
				throw new ServletException("Error loading Witness for ID ="
						+ witnessID);
			}
		}

		final InformationDetails informationDetails = new InformationDetails();
		final SubjectInformationTO subjectInformationTO = new SubjectInformationTO();
		informationDetails.setSubjectInformationTO(subjectInformationTO);
		return informationDetails;
	}

	private CaseContactTO loadWitnessforContact(String witnessID,
			boolean noLoading) throws ServletException {

		if (StringUtils.isNotEmpty(witnessID) && (!noLoading)) {
			try {
				return witnessFacade.loadWitnessByIdForContact(new Long(
						witnessID));

			} catch (Exception e) {
				log.error(e);
				throw new ServletException("Error loading Witness for ID ="
						+ witnessID);
			}
		}

		return new CaseContactTO();
	}

	/**
	 * Setter method for the WitnessFacade
	 * 
	 * @param witnessFacade
	 */
	public void setWitnessFacade(WitnessService witnessFacade) {
		this.witnessFacade = witnessFacade;
	}

	public CustomDateEditor getCustomDateEditor() {
		return customDateEditor;
	}

	public void setCustomDateEditor(CustomDateEditor customDateEditor) {
		this.customDateEditor = customDateEditor;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	/**
	 * Check whether the request is about submit to ConvertToSubject.
	 * 
	 * @param request
	 * @return boolean.
	 */
	private boolean onConvertToSubject(HttpServletRequest request) {
		if (request.getParameter("convertToSubject") != null) {
			return true;
		}
		return false;
	}
}
