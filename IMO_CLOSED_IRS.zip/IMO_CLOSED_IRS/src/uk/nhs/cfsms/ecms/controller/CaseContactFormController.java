package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.infoGath.Address;
import uk.nhs.cfsms.ecms.data.infoGath.PersonContacts;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseContactService;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.InformationUtil;
import uk.nhs.cfsms.ecms.utility.PatientOccupationLookupMap;

@Controller
public class CaseContactFormController extends BaseBinderConfig {
 
	@Autowired
	private CaseContactService caseContactFacade;

	@Autowired
	private LookupViewService lookupViewFacade;

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private AuditLogService auditLogFacade;

//	private static final String ADD_NEW_CONTACT = ECMSConstants.ADD_NEW_CONTACT;
//	private static final String ADD_NEW_ADDRESS = ECMSConstants.ADD_NEW_ADDRESS;

	public CaseContactFormController() { 
 
		/*this.setSessionForm(true);
		this.setCommandName("caseContactTO");
		this.setCommandClass(CaseContactTO.class);
		this.setBindOnNewForm(true);*/
	}

	
	@RequestMapping(value ={"/secure/addCaseContact.htm", "/secure/caseContact.htm"})
	public  ModelAndView formBackingObject(HttpServletRequest request)
			throws Exception {

		log.info("** CaseContactFormController.formBackingObject().");
		ModelAndView mAV = new ModelAndView("caseContact");
		String caseID = CaseUtil.getCaseId(request);

		CaseContactTO dto = new CaseContactTO();
		dto.getPersonTO().addAddress(new Address());
		if (StringUtils.isNotEmpty(caseID)) {
			dto.setCaseId(new Long(caseID));
		}

		String action = request.getParameter(CaseUtil.ACTION_TYPE_PARAM);

		if (action != null && action.equalsIgnoreCase(CaseUtil.VIEW_PARAM)) {

			String id = request.getParameter(CaseUtil.CONTACT_ID_PARAM);

			if (StringUtils.isNotEmpty(id)) {
				dto = caseContactFacade.loadContactById(new Long(id));
			} else {
				// if its a new object put an empty contact details object for
				// data entry
				dto.getPersonTO().addContacts(new PersonContacts());
				dto.getPersonTO().addAddress(new Address());
			}
		} else if (action == null) {
			// if its a new object put an empty contact details object for data
			// entry
			dto.getPersonTO().addContacts(new PersonContacts());
			// dto.getPersonTO().addAddress(new Address());
		}
		// Set up all Lookup View Details.
		this.setupAllLookupDetails(dto);
		mAV.addObject("caseContactTO", dto);
		return mAV;
	}

	
	@RequestMapping(value ={"/secure/caseContact.htm"}, method = RequestMethod.POST)
	public ModelAndView processFormSubmission(HttpServletRequest request,
			HttpServletResponse response, CaseContactTO contactTO , BindingResult errors)
			throws Exception {
		
		log.info("** CaseContactFormController.processFormSubmission");
		
		ModelAndView mAV = new ModelAndView("caseContact");

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		if (null == user) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}
		if (EcmsUtils.onCancel(request)) {
			return CaseUtil.getCaseContactsListView();
		}
		if (errors.getErrorCount() < 1) {

			if (EcmsUtils.addNewAddressOrContactToPerson(contactTO.getPersonTO(), request)) {
				mAV.addObject("caseContactTO", contactTO);
				return mAV;
			}

			// Check your actions and do the action.
			if (EcmsUtils.onFinish(request)) {

				if (contactTO.getContactId() == null) {
					contactTO.setCreatedStaffId(user.getStaffId());
					AuditFlowThread.set("Case Contact Created");
				} else {
					AuditFlowThread.set("Case Contact Updated");
				}
				
				caseContactFacade.saveContact(contactTO);
				createAudit(contactTO, AuditLogService.CREATE, "Create Case Contact", request, auditLogFacade);
				
				return CaseUtil.getCaseContactsListView();
			}
			if (EcmsUtils.onDelete(request)) {

				AuditFlowThread.set("Case Contact Deleted");
				caseContactFacade.deleteContact(contactTO);
				createAudit(contactTO, AuditLogService.DELETE, "Delete Case Contact", request, auditLogFacade);
				
				return CaseUtil.getCaseContactsListView();
			}

			if (onConvertToSubject(request)) {

				AuditFlowThread.set("Convert Case Contact to Subject");
				caseContactFacade.updateCaseContactToSubject(contactTO);
				createAudit(contactTO, AuditLogService.UPDATE, "Convert Case Contact to Subject", request, auditLogFacade);
				
				return CaseUtil.getCaseContactsListView();
			}

			if (onConvertToWitness(request)) {

				AuditFlowThread.set("Convert Case Contact to Witness");
				caseContactFacade.updateCaseContactToWitness(contactTO, user
						.getStaffId());
				
				createAudit(contactTO, AuditLogService.UPDATE,"Convert Case Contact to Witness", request, auditLogFacade);

				return CaseUtil.getCaseContactsListView();
			}

		} else {
			/*return super.processFormSubmission(request, response, command,
					errors);*/
		}
		mAV.addObject("caseContactTO", contactTO);
		return mAV;
	}


	/**
	 * Setup all lookup details for information.
	 * 
	 * @param Information
	 */
	private void setupAllLookupDetails(CaseContactTO dto) {

		if (EcmsUtils.isLookupViewMapEmpty()) {

			String[] lookupGroupNames = InformationUtil.getAllLookupGroups();

			for (String groupName : lookupGroupNames) {
				List<LookupView> list = new ArrayList<LookupView>();
				if (groupName != null) {
					list = lookupViewFacade
							.loadActiveLookupDetailsByGroups(groupName);
				}
				dto.addLookupViewMap(groupName, list);
			}
		}

		dto.setStaticInfoLookupViewMap();
		setUpPatientOccupationLookupDetails();
	}
	
	
	/**
	 * LookupView details for patient occupation
	 * 
	 * @return List.
	 */
	private void setUpPatientOccupationLookupDetails() {
		final List<LookupView> lookupList = lookupViewFacade
				.loadPatientOccupationDescriptions();
		for (LookupView view : lookupList) {
			final String lookupId = String.valueOf(view.getLookupId());
			final String description = view.getDescription();
			final Map<String, String> map = PatientOccupationLookupMap
					.getAllPatientOccupationDetailsLookupMap();
			if (!map.containsKey(lookupId)) {
				map.put(lookupId, description);
			}
		}
	}

	/**
	 * Check whether the request is about submit to ConvertToWitness.
	 * 
	 * @param request
	 * @return boolean
	 */
	private boolean onConvertToWitness(HttpServletRequest request) {
		if (request.getParameter("convertToWitness") != null) {
			return true;
		}
		return false;
	}

	/**
	 * Check whether the request is about submit to ConvertToSubject.
	 * 
	 * @param request
	 * @return boolean.
	 */
	private boolean onConvertToSubject(HttpServletRequest request) {
		if (request.getParameter("convertToSubject") != null) {
			return true;
		}
		return false;
	}

	/**
	 * Setter method for the Case Contact
	 * 
	 * @param caseContactFacade
	 */
	public void setCaseContactFacade(CaseContactService caseContactFacade) {
		this.caseContactFacade = caseContactFacade;
	}

	public void setLookupViewFacade(LookupViewService lookupViewFacade) {
		this.lookupViewFacade = lookupViewFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
}
