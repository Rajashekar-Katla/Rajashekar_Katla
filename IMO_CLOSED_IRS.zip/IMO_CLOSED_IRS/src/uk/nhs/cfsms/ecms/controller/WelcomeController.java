package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.acegisecurity.Authentication;
import org.acegisecurity.concurrent.SessionRegistry;
import org.acegisecurity.concurrent.SessionRegistryUtils;
import org.acegisecurity.context.SecurityContext;
import org.acegisecurity.context.SecurityContextHolder;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.data.authentication.Users;
import uk.nhs.cfsms.ecms.data.authorization.AccessControl;
import uk.nhs.cfsms.ecms.data.common.AllUserResponsibilities;
import uk.nhs.cfsms.ecms.data.common.PermissionGroup;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;
import uk.nhs.cfsms.ecms.data.common.UserHistory;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.common.UserPreference;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.dto.user.User;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.EhcacheService;
import uk.nhs.cfsms.ecms.service.PermissionGroupService;
import uk.nhs.cfsms.ecms.service.UserInformationService;
import uk.nhs.cfsms.ecms.service.UserResponsibilitiesViewService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.security.SecurityProfile;
import uk.nhs.cfsms.ecms.web.support.BreadCrumbs;

/**
 * Welcome handles login and logout and stores user details in session once
 * successfully authenticated.
 * 
 * @author sChilukuri
 * 
 */

@Controller
public class WelcomeController extends MultiActionController {
	@Autowired
	AuditLogService auditLogFacade;
	@Autowired
	PermissionGroupService permissionGroupFacade;
	@Autowired
	UserInformationService userInformationFacade;
	@Autowired
	UserResponsibilitiesViewService userResponsibilitiesViewFacade;

	@Autowired
	private EhcacheService ehcacheService;

	protected final Log log = LogFactory.getLog(getClass());

	/**
	 * Handle Login.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/welcome.htm")
	public ModelAndView handleLogin(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		HttpSession session = request.getSession(true);
		String userId = null;
		SessionUser sessionUser = null;
		String staffId = null;

		Object user = session.getAttribute(ECMSConstants.SESSION_USER_DETAILS);

		if (null != user) {
			sessionUser = (SessionUser) user;
		}

		if (null == sessionUser
				|| null == EcmsUtils.getBreadCrumbsFromSession(request)) {

			userId = getUserIdFromSession(session);

			if (null == userId) {
				log.warn("\n *** UserId is NULL, Back to Login Page");
				return new ModelAndView(EcmsUtils.getLoginView(request));
			}
			sessionUser = getSessionUser(userId);
			setUpResponsibilitiesAndPermissionGroup(sessionUser);
			staffId = sessionUser.getStaffId();
			// Set Directorates for the user, before storing user to session.
			List<UserDirectorate> directorates = userResponsibilitiesViewFacade
					.getDirectorates(staffId);
			sessionUser.setDirectorates(directorates);
			this.createAuditLog(session, staffId);

			// Security and Bread Crumbs intercept additions.
			SecurityProfile sP = new SecurityProfile(userId, "");
			Map rolePermissions = getRolePermissions(sessionUser, request);

			if (sessionUser.isNITNorthLead() || sessionUser.isNITSouthLead()) {
				// Get NIT Lead users list.
				sessionUser.setLeadStaffIds(getAFLUserList());
			}
			Date now = new Date();
			UserHistory history = userInformationFacade
					.loadUserHistory(staffId);
			if (null == history) {
				history = new UserHistory();
				history.setStaffId(staffId);
				history.setCurrentLoggedOn(now);
				history.setPasswordUpdatedOn(now);
				userInformationFacade.createUserHistory(history);
			} else {
				Date lastLoggedOn = history.getCurrentLoggedOn();
				history.setCurrentLoggedOn(now);
				history.setLastLoggedOn(lastLoggedOn);
				userInformationFacade.updateUserHistory(history);
			}

			// Applied RolePermissions to SessionUser, set user to session.
			session.setAttribute(ECMSConstants.SESSION_USER_DETAILS,
					sessionUser);
			// Create security profile with permissions and store in session
			session.setAttribute(ECMSConstants.SECURITY_PROFILE,
					new SecurityProfile(sP.getUserName(), rolePermissions));

			UserPreference curPref = userInformationFacade
					.loadUserPrefereces(staffId);
			//Set user font in the session.
			request.getSession().setAttribute(
					ECMSConstants.SESSION_USER_FONT,
					null != curPref ? curPref.getFontSize()
							: ECMSConstants.DEFAULT_USER_FONT);

			if (logger.isInfoEnabled()) {
				logger.info("\n* SetUp role permission from WelcomeController");
			}

			// Security and Bread Crumbs intercept additions. Store empty bread crumbs in session.
			EcmsUtils.setBreadCrumbsInSession(request, new BreadCrumbs());

			// If the password is set to default ask user to change it
			if (isReadyForPasswordReset(history, now)) {
				return new ModelAndView("changePassword", "userObject",
						new User());
			}

		}
		// If user is FCRL redirect to FCRL welcome page.
		if (sessionUser.isUserFCRL()) {

			return new ModelAndView("fcrlwelcome");
		} else {

			return new ModelAndView("welcome");
		}
	}

	/**
	 * Checks whether user changed the default password or not. If not, system
	 * redirect the screen to change password page, Where user can change
	 * password
	 * 
	 * @param user
	 * @return boolean
	 */
	private boolean isReadyForPasswordReset(UserHistory history, Date now) {

		boolean passwordExpiry = false;
		Users user = userInformationFacade.getUserNamePassword(history
				.getStaffId());

		Calendar todayCal = Calendar.getInstance();
		todayCal.setTime(now);
		Calendar pwdCal = Calendar.getInstance();
		pwdCal.setTime(history.getPasswordUpdatedOn());
		pwdCal.add(Calendar.DATE, 30);
		if (logger.isDebugEnabled()) {
			logger.debug("Today Cal=" + todayCal + "\n Next 30 Days Cal="
					+ pwdCal);
		}
		if (todayCal.after(pwdCal)) {

			passwordExpiry = true;
		}

		if (now.equals(history.getPasswordUpdatedOn())) {

			passwordExpiry = false;
		}

		if (("Y".equals(ECMSConstants.PASSWORD_MD5_COMPLAINT) && EcmsUtils
				.convertPwdTomd5(ECMSConstants.DEFAULT_PASSWORD).equals(
						user.getPassword()))
				|| ("N".equals(ECMSConstants.PASSWORD_MD5_COMPLAINT) && ECMSConstants.DEFAULT_PASSWORD
						.equals(user.getPassword()))) {
			passwordExpiry = true;
		}
		return passwordExpiry;
	}

	@SuppressWarnings("unchecked")
	private List<String> getAFLUserList() {

		List<String> aflStaffList = new ArrayList<String>();
		List<UserObject> list = userInformationFacade
				.loadUsersByGroups(new String[] { ECMSConstants.AFL_LEVEL });
		if (null != list && !list.isEmpty()) {
			for (UserObject usrObj : list) {
				aflStaffList.add(usrObj.getStaffId());
			}
		}
		return aflStaffList;
	}

	/**
	 * Get userId from session by ACEGI_SECURITY_LAST_USERNAME
	 * 
	 * @param session
	 * @return
	 */
	private String getUserIdFromSession(HttpSession session) {

		String userId = null;
		Enumeration enumq = session.getAttributeNames();

		while (enumq.hasMoreElements()) {
			userId = (String) session
					.getAttribute(ECMSConstants.ACEGI_SECURITY);
			break;
		}
		log.info("\n >>> User logged in userId=" + userId);
		return userId;
	}

	/**
	 * Helper method to update session user with permission group.
	 * 
	 * @param sessionUser
	 */
	private void setUpResponsibilitiesAndPermissionGroup(SessionUser sessionUser) {

		List<AllUserResponsibilities> userRespList = userResponsibilitiesViewFacade
				.loadResponsibilitiesById(sessionUser.getStaffId());
		sessionUser.setUserResponsibilities(userRespList);

		String userGroupPermId = sessionUser.getGroupPermission();

		if (log.isDebugEnabled()) {
			log.debug("User Group PermissionID=" + userGroupPermId);
		}
		/*		
		 		for (int i = 0; i < userGroupPermId.length(); i++) {
					PermissionGroup group = permissionGroupFacade.load(Long
							.parseLong(String.valueOf(userGroupPermId.charAt(i))));
					sessionUser.setPermissionGroup(group);
				}
		*/
		PermissionGroup group = permissionGroupFacade.load(Long
				.parseLong(userGroupPermId.trim()));
		sessionUser.setPermissionGroup(group);
	}

	/**
	 * Helper method to get session SessionUser
	 * 
	 * @param userId
	 * @return SessionUser
	 * @throws ServletException
	 */
	private SessionUser getSessionUser(String userId) throws ServletException {

		UserObject user = userInformationFacade.loadUserByUserId(userId);
		SessionUser sessionUser = new SessionUser();
		try {
			BeanUtils.copyProperties(sessionUser, user);
		} catch (Exception exp) {
			log.error(exp.toString() + ", \n ID=" + userId);
			throw new ServletException(exp.getMessage());
		}
		return sessionUser;
	}

	/**
	 * Create Audit Log for the staff
	 * 
	 * @param session
	 * @param staffId
	 */
	private void createAuditLog(HttpSession session, String staffId) {
		try {
			Object sessObj = session
					.getAttribute(ECMSConstants.SESSION_USER_DETAILS);
			if (sessObj != null) {
				SessionUser sessUser = (SessionUser) sessObj;
				if (!sessUser.getStaffId().equals(staffId)) {
					auditLogFacade.save(staffId + " logged in",
							AuditLogService.LOGGED_IN, staffId, 0);
				}
			} else {
				auditLogFacade.save(staffId + " logged in",
						AuditLogService.LOGGED_IN, staffId, 0);
			}
		} catch (Exception e) {
			log.error(e);
		}
	}

	/**
	 * Get Role Permissions
	 * 
	 * @param user
	 * @param request
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	private Map getRolePermissions(SessionUser user, HttpServletRequest request) {

		logger.info("getting Role permissions for user..");
		// GET ALL THE USER ROLE PERMISSIONS AND SETUP userPermissions.
		Map userPermissions = new HashMap();
		final String DELIM = "|";
		// ACCESS TO EVERY ONE.
		userPermissions.put("/" + DELIM + "ACCESS", null);
		userPermissions.put("/login.jsp" + DELIM + "ACCESS", null);
		userPermissions.put("/secure/welcome.htm" + DELIM + "ACCESS", null);

		// ACCESS BASED ON ACL.
		String aclLevel = user.getUserAccessLevel();
		log.info("\n *** CALLING FOR ACL LEVEL =" + aclLevel);

		if (!aclLevel.equals(ECMSConstants.ACL_UNKNOWN)) {

			List<AccessControl> aclList = userInformationFacade
					.loadUserAccessListByAccessLevel(aclLevel);

			if (aclList != null) {
				// Set the SessionUser with Access Control List.
				user.setAccessControlList(aclList);
				// Iterate and check for the access decision.
				for (AccessControl acl : aclList) {
					userPermissions.put(acl.getPath() + DELIM + "ACCESS",
							"ALLOWED");
				}
			}
		}
		return userPermissions;
	}

	/**
	 * Handle Logout.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/logoff.htm")
	public ModelAndView handleLogout(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		HttpSession session = request.getSession();
		String staffId = "";
		try {
			if (session != null) {
				SessionUser sUser = EcmsUtils.getSessionUserObject(session);

				if (sUser != null) {
					staffId = sUser.getStaffId();
				}
				auditLogFacade.save(staffId + " logged out",
						AuditLogService.LOGGED_OUT, staffId, 0);
				if (logger.isDebugEnabled()) {
					logger.debug("StaffId=" + staffId + " LOGGING OUT.\n\n");
				}
			}

			ehcacheService.clearAllCacheEntries();
			response.sendRedirect("/" + request.getContextPath()
					+ "/j_acegi_logout");
		} catch (Exception e) {
			logger.error("Exception Invalidating session :" + e.getMessage());
			logger.error(e);
		}
		// return new ModelAndView(EcmsUtils.getLoginView(request));
		return null;
	}

	/**
	 * Setter for the permissionGroupFacade
	 * 
	 * @param permissionGroupFacade
	 */
	public void setPermissionGroupFacade(
			PermissionGroupService permissionGroupFacade) {
		this.permissionGroupFacade = permissionGroupFacade;
	}

	/**
	 * Setter for the userInformationFacade
	 * 
	 * @param userInformationFacade
	 */
	public void setUserInformationFacade(
			UserInformationService userInformationFacade) {
		this.userInformationFacade = userInformationFacade;
	}

	/**
	 * Setter for the userResponsibilitiesViewFacade
	 * 
	 * @param userResponsibilitiesViewFacade
	 */
	public void setUserResponsibilitiesViewFacade(
			UserResponsibilitiesViewService userResponsibilitiesViewFacade) {
		this.userResponsibilitiesViewFacade = userResponsibilitiesViewFacade;
	}

	/**
	 * Audit Log
	 * 
	 * @param auditLogFacade
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
