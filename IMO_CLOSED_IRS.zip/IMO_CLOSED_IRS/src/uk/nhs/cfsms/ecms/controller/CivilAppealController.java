package uk.nhs.cfsms.ecms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealOutcomeTO;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealTO;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealsAndOutcomes;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SubjectName;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CivilSanctionService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
public class CivilAppealController extends BaseMultiActionController {

	@Autowired
	private CivilSanctionService civilSanctionFacade;
	@Autowired
	private InformationGatherService informationGatherFacade;
	@Autowired
	private AuditLogService auditLogFacade;
	
	protected final Log log = LogFactory.getLog(getClass());

	static final String APPEAL_PARAM = "civilAppeal";
	
	static final String APPEALS_PARAM = "civilAppeals";
	
	static final String APPEALS_SIZE_PARAM = "civilAppealsSize";
	
	static final String CIVIL_APPEALS_VIEW = "viewCivilAppeals";
	
	static final String CIVIL_INPUT_VIEW = "civilAppealInput";
	
	static final String APPEAL_OUTCOME_VIEW = "civilAppealOutcome";
	
	static final String APPEALS_MAP_PARAM = "civilAppealsMap";

	/**
	 * Show Criminal Appeals
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showCivilAppeals.htm")
	public ModelAndView showCivilAppeals(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Map<String, Object> civilSanctionsMap = new HashMap<String, Object>();
		
		String caseID = CaseUtil.getCaseId(request);
		
		CivilAppealsAndOutcomes res = civilSanctionFacade
				.getAppealsAndOuctomesForCase(new Long(caseID));
		
		civilSanctionsMap.put(APPEALS_PARAM, res);
		
		return new ModelAndView(CIVIL_APPEALS_VIEW, APPEALS_MAP_PARAM, civilSanctionsMap);
		
	}

	/**
	 * criminalAppealInput is to add new criminal Appeal.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws CaseIDNotFoundException
	 */
	@RequestMapping(value = "/secure/civilAppealInput.htm")
	public ModelAndView civilAppealInput(
			HttpServletRequest request,
			HttpServletResponse response, 
			@ModelAttribute CivilAppealTO appealTO) throws Exception {
		
		if (log.isDebugEnabled() ){
			log.debug("civilAppealInput");
		}
		Map<String, Object> model = new HashMap<String, Object>();
		appealTO = civilSanctionFacade.loadCivilAppeal(appealTO);
		request.getSession().setAttribute("appealTO", appealTO);
		
		String caseID = CaseUtil.getCaseId(request);
		List<SubjectName> subjects = informationGatherFacade
				.getAllSubjects(caseID);
		
		if (null == subjects || (null != subjects && subjects.isEmpty())) {
			
			model.put(ECMSConstants.ERROR_MESSAGES, ECMSConstants.NO_SUBJECTS);
		} else {
			model.put("subjects", subjects);
			appealTO.setSubjects(subjects);
			model.put(APPEAL_PARAM, appealTO);
		}
		
		return new ModelAndView(CIVIL_INPUT_VIEW, APPEALS_MAP_PARAM, model);
	}
	

	@RequestMapping(value = "/secure/saveCivilAppeal.htm")
	public ModelAndView saveAppeal(
			HttpServletRequest request,
			HttpServletResponse response, 
			CivilAppealTO appealTO)	throws Exception {
		
		if (log.isDebugEnabled() ){
			log.debug("saveAppeal");
		}
		// Below bit is a workaround for lack of conversation/page scope
		String[] idAndType = StringUtils.split(appealTO.getSubjectIdType(), '-');
		
		String appelantOtherType = appealTO.getAppellantType();
		
		String appellant = request.getParameter("appealMakerOther");
		
		
		CivilAppealTO sessAppeal = (CivilAppealTO) request.getSession()
				.getAttribute("appealTO");
		
		if (appealTO.getAppealId() != null) { 
			
			this.setUpSubject(appealTO, idAndType);		
			setUpAppelant(appealTO, appellant, appelantOtherType);
			sessAppeal.setAppellant(appealTO.getAppellant());
			
			sessAppeal.setDateOfAppeal(appealTO.getDateOfAppeal());
			sessAppeal.setSubjectId(appealTO.getSubjectId());
			sessAppeal.setSubjectType(appealTO.getSubjectType());
			sessAppeal.setOtherSubjects(appealTO.getOtherSubjects());
			sessAppeal.setAppellantType(appealTO.getAppellantType());
			
			appealTO = sessAppeal;
			
			AuditFlowThread.set("Update Civil Appeal");

		} else {

			
			if (log.isDebugEnabled() ){
				log.debug("creating new civil appeal using session appeal:"+ sessAppeal);
				
			}
			if (null != sessAppeal && null != sessAppeal.getAppealedId()) {
				appealTO.setAppealedId(sessAppeal.getAppealedId());
			}
			if (null != sessAppeal && StringUtils.isNotEmpty(sessAppeal.getAppealedOutcomeType())) {
				appealTO.setAppealedOutcomeType(sessAppeal.getAppealedOutcomeType());
			}
			if (null != sessAppeal && null != sessAppeal.getSanctionId()) {
				appealTO.setSanctionId(sessAppeal.getSanctionId());
			}
			appealTO.setState(CaseUtil.ONGOING_STATUS);
			this.setUpSubject(appealTO, idAndType);

			setUpAppelant(appealTO, appellant, appelantOtherType);
			sessAppeal.setAppellant(appealTO.getAppellant());

			AuditFlowThread.set("Create Civil Appeal");
		}
		
		civilSanctionFacade.saveAppeal(appealTO);
	
		return showCivilAppeals(request, response);
	}

	private void setUpAppelant(CivilAppealTO appealTO, String appellent, String appellentType) {
		
		if ("Other".equalsIgnoreCase(appellent) || "Other".equalsIgnoreCase(appealTO.getAppellant()) ) {
			appealTO.setAppellantType("Other");
		} else {
			//appealTO.setAppellant(appellentType);
			appellent = (appellent != null && !appellent.isEmpty()) ? appellent : appealTO.getAppellant();
			appealTO.setAppellantType(null);
		}
		appealTO.setAppellant(appellent);
	}
	
	
	private void setUpSubject(CivilAppealTO appealTO, String[] idAndType) {
		
		if ("Other".equalsIgnoreCase(appealTO.getSubjectIdType())) {
			appealTO.setSubjectType("Other");
			appealTO.setSubjectId(null);
		} else {
			appealTO.setSubjectId(Long.parseLong(idAndType[0]));
			appealTO.setSubjectType(idAndType[1]);
			appealTO.setOtherSubjects(null);
		}
	}
 
	
	@RequestMapping(value = "/secure/editCivilAppealOutcome.htm")
	public ModelAndView editAppealOutcome(
			HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		if (log.isDebugEnabled() ){
			log.debug("editAppealOutcome");
			
		}
		String appealID = request.getParameter("appealID");
		CivilAppealOutcomeTO outcomeTO = civilSanctionFacade
				.loadCivilAppealOutcome(Long.parseLong(appealID));
	
		CivilAppealTO civilAppealTO = civilSanctionFacade.loadCivilAppeal(Long.parseLong(appealID));
		outcomeTO.setDateOfAppeal(civilAppealTO.getDateOfAppeal());
		
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("outcome", outcomeTO);
		return new ModelAndView(APPEAL_OUTCOME_VIEW, "modelMap", model);
	}

	
	@RequestMapping(value = "/secure/saveCivilAppealOutcome.htm")
	public ModelAndView saveAppealOutcome(
			HttpServletRequest request,
			HttpServletResponse response, 
			CivilAppealOutcomeTO outcomeTO)	throws Exception {

		if (log.isDebugEnabled() ){
			log.debug("saveAppealOutcome");
			
		}

		if (outcomeTO.getOutcomeId() == null || outcomeTO.getOutcomeId() == 0) {
			AuditFlowThread.set("Create Civil Appeal Outcome");
		} else {
			AuditFlowThread.set("Update Civil Appeal Outcome");
		}
		civilSanctionFacade.saveObject(outcomeTO);
	
		return editAppealOutcome(request, response);
	}
	
	
	@RequestMapping(value = "/secure/deleteCivilAppeal.htm")
	public ModelAndView deleteCriminalAppeal(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String appealID = request.getParameter(CaseUtil.APPEAL_ID);
  
		try {
 		
			AuditFlowThread.set("Delete Civil Appeal");
			
			civilSanctionFacade.deleteCivilAppeal(new Long(appealID));
			
			createAudit(appealID, AuditLogService.DELETE, "Delete Civil Appeal", request, auditLogFacade);

			return showCivilAppeals(request, response);
			
		} catch (Exception se) {
			log.error(se);
			throw new ServletException(se);
		}

	}
	

	public void setCivilSanctionFacade(CivilSanctionService civilSanctionFacade) {
		this.civilSanctionFacade = civilSanctionFacade;
	}
 
	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
	
	
	
	
}
