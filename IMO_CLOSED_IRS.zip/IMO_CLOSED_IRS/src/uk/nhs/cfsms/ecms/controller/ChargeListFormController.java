 package uk.nhs.cfsms.ecms.controller;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMethod;
import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.sanction.ChargeList;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.ChargeListService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
@RequestMapping("/secure/saveChargeList.htm")
//public class ChargeListFormController extends BaseFormController {
public class ChargeListFormController{
	
	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private ChargeListService chargeListFacade;

	/*public ChargeListFormController() {
		
		setSessionForm(true);
		setCommandName("chargeList");
		setCommandClass(ChargeList.class);
	}*/

	protected Object formBackingObject(HttpServletRequest request)
			throws ServletException {
		String action = request.getParameter(CaseUtil.ACTION_TYPE_PARAM);
		ChargeList chargeList = new ChargeList();
		if (action != null && action.equalsIgnoreCase(CaseUtil.VIEW_PARAM)) {
			String id = request.getParameter("chargeListId");
			if (id != null && id.length() != 0) {
				try {
					chargeList = (ChargeList) chargeListFacade.getObject(
							ChargeList.class, new Long(id));

				} catch (ServiceException e) {
					log.error("Exception loading charge list with id " + id
							+ " @" + e.getMessage());
					log.error(e);
				}
			} else {
				String sanctionID = request
						.getParameter(CaseUtil.SANCTION_ID_PARAM);
				chargeList = new ChargeList();
				chargeList.setCriminalSanctionId(new Long(sanctionID));
			}
		}

		return chargeList;
	}
	
	@RequestMapping(method = RequestMethod.GET)
	protected String initForm(ModelMap model, 
							  HttpServletRequest request) 
										throws ServletException {
		ChargeList chargeList = (ChargeList)formBackingObject(request);
		model.addAttribute("chargeList", chargeList);
		return "chargeList";
	}

	/*@Override
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object object, BindException errors)
			throws Exception {*/
	
	@RequestMapping(method = RequestMethod.POST)
	protected ModelAndView processSubmit(@ModelAttribute("chargeList") ChargeList chargeList,
			                        HttpServletRequest request)
			                        		throws Exception {
		chargeList.setCreatedTime(new Date());
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		chargeList.setCreatedStaffId(user.getStaffId());
		if(chargeList.getChargeListId() == null || (chargeList.getChargeListId() == 0L)){
			AuditFlowThread.set("Criminal Charge Created");
		} else {
			AuditFlowThread.set("Criminal Charge Updated");
		}
		chargeListFacade.saveObject(chargeList);
		createAudit(chargeList, AuditLogService.CREATE, "Create Charges",
				request, auditLogFacade);

		String params = CaseUtil.SANCTION_ID_PARAM + "="
				+ chargeList.getCriminalSanctionId();
		return new ModelAndView(new RedirectView("showChargeLists.htm?"
				+ params));

	}

	public void setChargeListFacade(ChargeListService chargeListFacade) {
		this.chargeListFacade = chargeListFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
	
	@InitBinder
	protected void initBinder(HttpServletRequest servletRequest,
			ServletRequestDataBinder binder) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("\n initBinder"); 
		}

		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, nf, true));
		binder
				.registerCustomEditor(String.class, new StringTrimmerEditor(
						true));
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null,
				new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}
	
	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			log.error(e);
		}
	}

}
