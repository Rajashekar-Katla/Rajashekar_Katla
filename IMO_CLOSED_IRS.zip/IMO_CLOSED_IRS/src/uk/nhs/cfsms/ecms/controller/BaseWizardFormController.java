package uk.nhs.cfsms.ecms.controller;

import java.math.BigDecimal;
import java.text.NumberFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractWizardFormController;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;

public class BaseWizardFormController extends AbstractWizardFormController {

	@Override
	protected void initBinder(HttpServletRequest request,
			ServletRequestDataBinder binder) throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("\n\n** initBinder().");
		}
		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, nf, true));
		binder
				.registerCustomEditor(String.class, new StringTrimmerEditor(
						true));
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null,
				new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}

	@Override
	protected ModelAndView processFinish(HttpServletRequest arg0,
			HttpServletResponse arg1, Object arg2, BindException arg3)
			throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("\n\n** processFinish().");
		}
		return null;
	}

	/**
	 * Create Audit.
	 * 
	 * @param object
	 * @param state
	 * @param request
	 * @param auditLogFacade
	 */
	protected void createAudit(Object object, String state, String action,
			HttpServletRequest request, AuditLogService auditLogFacade) {

		try {
			String caseID = CaseUtil.getCaseId(request);
			
			auditLogFacade.save(AuditLogUtils.getProperties(object), state,
					action, EcmsUtils
							.getSessionUserObject(request.getSession())
							.getStaffId(), (caseID != null) ? new Long(caseID)
							: null);

		} catch (Exception e) {
			logger.error(e);
		}
	}

	/**
	 * Create Audit for Information
	 * 
	 * @param object
	 * @param state
	 * @param request
	 * @param auditLogFacade
	 */
	protected void createInformationAudit(Object object, String state,
			String action, HttpServletRequest request,
			AuditLogService auditLogFacade) {

		try {

			long infoId = 0;
			if (object instanceof InformationTO) {
				InformationTO infoTO = (InformationTO) object;
				infoId = infoTO != null ? infoTO.getInformationId() : 0;
					
				if(infoId != 0){
					auditLogFacade.save(object.getClass(), AuditLogUtils
						.getProperties(object), state, action, EcmsUtils
						.getSessionUserObject(request.getSession())
						.getStaffId(), infoId);
				}
			}
		} catch (Exception e) {
			logger.error(e);
		}
	}
}
