package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.InformationObject;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.Information;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.MessageService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * Case Form Controller to handle all the information to case transfer process,
 * allocation of a case to a team, transfer a case to different team and reject
 * a case.
 * 
 */
@Controller
public class CaseFormController extends BaseBinderConfig {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private AuditLogService auditLogFacade;

	@Autowired
	private CaseService caseFacade;

	@Autowired
	private MessageService messageFacade;

	static final String NO_TEAM_CODES = "No team code mapped. Please contact administrator.";

	static final String VALID_ORG = "Please provide a valid Organisation before allocating.";

	@RequestMapping(value = "/secure/allocateusertocase.htm")
	public ModelAndView processFormSubmission(HttpServletRequest request,
			HttpServletResponse response, CaseTO command) throws Exception {

		if (EcmsUtils.onCancel(request)) {
			return new ModelAndView(new RedirectView("listInformation.htm"));
		}

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		String actionType = request.getParameter("actionType");

		if (log.isDebugEnabled()) {
			log.debug("Action Type = " + actionType);
		}

		if (null != actionType) {
			try {

				if (actionType.equalsIgnoreCase("allocatecase")) {

					return handleAllocateCase(user, request, response);
				}
				if (actionType.equalsIgnoreCase("userselected")) {

					return handleAllocatedCaseUserSelected(user, request,
							response, command);
				}
				if (actionType.equalsIgnoreCase("holdcase")) {

					return handleHoldCase(user, request, response, command);
				}
				if (actionType.equalsIgnoreCase("rejectcommentpage")) {

					return handleRejectCommentPage(request, command);
				}

				if (actionType.equalsIgnoreCase("rejectcasemessage")) {

					if (user.isUserCIU()) {
						return handleRejectCase(user, request, response);

					} else {
						return handleRejectedTransferCase(user, request,
								response);
					}
				}

				if (actionType.equalsIgnoreCase("transferinfoview")) {

					return handleTranferInfoView(request, response, command);
				}

				if (actionType.equalsIgnoreCase("transferinfototeam")) {

					String transferType = request.getParameter("transferType");

					if (null != transferType
							&& transferType.equalsIgnoreCase("lcfs")) {

						return handleTransferInfoToLcfs(request, response,
								command, user);

					}
					if (user.isUserMangerAndAbove()) {

						return handleTransferInfoToTeam(request, response,
								command, user);
					} else {
						//OFM approval before transferring any information to CIU.
						return handleInfoTransferToTeamWithApproval(request,
								command, user);
					}
				}
				if (actionType.equalsIgnoreCase("allocateusertoholdcase")) {

					return handleAllocateUserToHoldCase(user, request,
							response, command);
				}
				if (actionType.equalsIgnoreCase("userselectedtoholdcase")) {
					return handleUserSelectedToHoldCase(user, request,
							response, command);
				}

				if (actionType.equalsIgnoreCase("allocatecaseteamcodechanged")) {
					return handleAllocateCaseTeamChange(user, request,
							response, command);
				}

			} catch (Exception e) {
				log.error(e);
			}
		}
		return new ModelAndView(new RedirectView("listInformation.htm"));
	}

	private ModelAndView handleRejectCommentPage(HttpServletRequest request,
			Object command) throws Exception {

		// keep case info into session and get rejected comment from user.
		request.getSession().setAttribute(ECMSConstants.CASE_INFO_IN_SESSION,
				command);

		CaseTO caseInfo = (CaseTO) command;

		InformationObject info = caseFacade.loadInfoObjectOnly(caseInfo
				.getInformationId());

		return new ModelAndView("rejectcommentpage", "infoObject", info);
	}

	/**
	 * Handle user selected to hold case.
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @param command
	 * @param errors
	 * @return ModelAndView
	 * @throws Exception
	 */
	private ModelAndView handleUserSelectedToHoldCase(SessionUser user,
			HttpServletRequest request, HttpServletResponse response,
			Object command) throws Exception {

		CaseTO caseInfo = (CaseTO) command;
		try {
			caseInfo = caseFacade.saveUserAllocatedHoldCase(caseInfo,
					user.getStaffId());

			createAudit(caseInfo, AuditLogService.UPDATE, "Update onhold Case",
					request, auditLogFacade);

		} catch (Exception e) {
			log.error("Exception while handleUserSelectedToHoldCase"
					+ e.getMessage());
			throw e;
		}
		if (caseInfo.getCaseId() != null) {

			return new ModelAndView("allocateUserToCaseSuccess");
		}

		return new ModelAndView("allocateUserToCaseUnsuccess");
	}

	/**
	 * Handle transfer information.
	 * 
	 * @param request
	 * @param response
	 * @param errors
	 * @param command
	 * @return
	 * @throws Exception
	 */
	private ModelAndView handleTranferInfoView(HttpServletRequest request,
			HttpServletResponse response, Object command) throws Exception {

		String id = request.getParameter("informationId");
		String orgCode = request.getParameter("orgCode");
		String teamCode = request.getParameter("teamCode");
		CaseTO caseTo = new CaseTO();
		caseTo.setInformationId(new Long(id));
		caseTo.setOrgCode(orgCode);
		caseTo.setTeamList(caseFacade.listTeamCodes());
		caseTo.setTeamCode(teamCode);

		if (teamCode != null) {
			Map<String, List<UserObject>> userListMap = caseFacade
					.loadUsersByTeamCodeAndGroups(teamCode);
			caseTo.setLcfsList(userListMap.get("LCFS"));
		}

		return new ModelAndView("transferInfoView", "caseInfo", caseTo);
	}

	/**
	 * Transferring the information to OFMs for approval prior to CIU transfer.
	 * Save the information, after OFM/AFL/AAFS approval.
	 * 
	 * @param request
	 * @param command
	 * @param user
	 * 
	 * @return ModelAndView
	 */

	private ModelAndView handleInfoTransferToTeamWithApproval(
			HttpServletRequest request, Object command, SessionUser user)
			throws Exception {

		checkNullCommandObject(command);

		CaseTO caseInfo = (CaseTO) command;

		String transferTeam = caseInfo.getTransferTeam();
		logInfoLevel("TransferInfoToTeam : transferTeam=" + transferTeam);

		Long infoId = caseInfo.getInformationId();
		String message = request.getParameter("messagetext");

		// update Information...
		InformationObject infoObj = caseFacade.loadInfoObjectOnly(infoId);

		//Setting the approval status of information as pending.
		infoObj.setInfoApprovalStatus(ECMSConstants.INFO_APPROVAL_STATUS_PENDING);

		String transferInfo = "Transfer Info With Approval";
		if (caseInfo.getCaseId() != null) {
			transferInfo = "Transfer Case With Approval";
		}
		// update information permission to new team.
		AuditFlowThread.set(transferInfo);
		// Information object to be saved with appropriate flags
		caseFacade.saveInfoOnly(infoObj);

		MessageTO messageTO = new MessageTO();

		messageTO.setMessage(message);
		messageTO.setInformationId(infoId);
		messageTO
				.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER_REQUEST
						.toString());

		if (!createStaffDetails(messageTO, user)) {
			return new ModelAndView("noofmmessage");
		} else {

			// Triggering the message for the OFM to review the information for transfer.
			messageTO = messageFacade.saveMessage(messageTO);

			/**
			 * Updating the transfer history table, this information will be
			 * used to provide a consolidated view of approval requests pending
			 * and upon approval to trigger require messages.
			 **/
			caseFacade.updateInformationTransferHistory(infoId,
					caseInfo.getTeamCode(), transferTeam, user.getStaffId(),
					messageTO);

			/**
			 * Audit history of actions
			 **/
			createAudit(messageTO, AuditLogService.UPDATE,
					"Adding information transfer Message", request,
					auditLogFacade);

		}

		if (messageTO.getMessageId() != null) {

			return new ModelAndView("transferInfoSuccess");
		}

		return new ModelAndView("transferInfoUnsuccess");

	}

	/**
	 * This method is responsible for fetching the required approver OFM USER
	 * */
	private boolean createStaffDetails(MessageTO messageTO, SessionUser user)
			throws ServiceException {

		UserObject ofmObj = null;
		InformationView info = null;

		final String message = messageTO.getMessage();
		final Long informationId = messageTO.getInformationId();

		messageTO.setCreatedStaffId(user.getStaffId());
		messageTO.setCreatedTime(new Date());
		messageTO.setFromStaffId(user.getStaffId());
		messageTO.setFromStaffName(user.getFullName());
		messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
		Long msgInformationId = messageTO.getInformationId();

		if (null != msgInformationId) {

			info = messageFacade.loadInformationViewById(informationId);
		}

		if (user.isUserNationalLevel()) {

			logInfoLevel("User is National Level...");
			if (null != user
					&& EcmsUtils.isNITTeamCode(user.getEmployerOrgCode())) {

				ofmObj = messageFacade.loadAFLByTeamCode(user
						.getEmployerOrgCode());
			} else {
				ofmObj = messageFacade.loadOFMByTeamOrOrgCode(
						user.getEmployerOrgCode(), false);
			}

		} else {
			logInfoLevel(" User is NOT National Level...");

			if (info.hasRegionOverride()) {

				logInfoLevel("User has Regional override.");

				ofmObj = messageFacade.loadOFMByTeamOrOrgCode(
						info.getTeamCode(), false);

			} else {

				logInfoLevel("User is LCFS, Loading OFM by orgCode...");

				ofmObj = messageFacade.loadOFMByTeamOrOrgCode(
						info.getOrgCode(), true);
			}
		}

		if (ofmObj != null) {
			messageTO.setToStaffId(ofmObj.getStaffId());
			messageTO.setToStaffName(EcmsUtils.getFullName(ofmObj));

		} else {
			return false;
		}

		messageTO.setInformationRef(info.getCreatedStaffId() + "#"
				+ info.getInformationId());

		return true;
	}

	private void logInfoLevel(String data) {

		if (logger.isInfoEnabled()) {

			logger.info(data);
		}
	}

	/**
	 * Handle Transfer Information to a team. If user OFM / AntiFraudLead
	 * /AntiFraudSpecialist
	 * 
	 * @param request
	 * @param response
	 * @param errors
	 * @param command
	 * @return ModelAndView
	 * @throws Exception
	 */
	private ModelAndView handleTransferInfoToTeam(HttpServletRequest request,
			HttpServletResponse response, Object command, SessionUser user)
			throws Exception {

		checkNullCommandObject(command);

		String message = request.getParameter("messagetext");

		CaseTO caseInfo = (CaseTO) command;

		Long infoId = caseInfo.getInformationId();
		Long newMessageId = null;
		String transferTeam = caseInfo.getTransferTeam();
		logger.info("OFMTransferInfoToTeam : transferTeam=" + transferTeam);
		String transferInfo = "Transfer Info to team";
		if (caseInfo.getCaseId() != null) {
			transferInfo = "Transfer case to Team";
		}
		// update information permission to new team.
		AuditFlowThread.set(transferInfo);
		final List<MessageTO> savedMessageTOList = new ArrayList<MessageTO>();
		try {
			// update Information...
			InformationObject infoObj = caseFacade.loadInfoObjectOnly(infoId);
			infoObj.setState(ECMSConstants.INFO_TRANSFERRED);

			// update Information & Info permission to new team.
			caseFacade.updateInfoTransferToNewTeam(transferTeam, infoId, user);

			boolean isTransferToCIUorFPU = checkTransferTOCIUorFPU(transferTeam);
			// if information is transferred to CIU or FPU, update information state as
			// REJECTED else state ACTIVE
			caseFacade
					.updateTransferInformation(caseInfo, isTransferToCIUorFPU);

			caseFacade.saveInfoOnly(infoObj);

			MessageTO messageTO = new MessageTO();
			messageTO.setMessage(message);
			messageTO.setInformationId(infoId);

			if (isTransferToCIUorFPU) {

				messageTO
						.setMessageType(MessageTO.Message_types.IIU_IMO_REFERRAL
								.toString());
			} else {
				messageTO
						.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER
								.toString());
			}

			if (!setStaffDetails(messageTO, user, transferTeam)) {
				return new ModelAndView("noofmmessage");
			} else {
				messageTO = messageFacade.saveMessage(messageTO);

				createAudit(messageTO, AuditLogService.UPDATE,
						"Adding Message", request, auditLogFacade);
				savedMessageTOList.add(messageTO);
			}

			caseFacade.updateOldAndAddNewInfoTransferHistory(infoId,
					transferTeam, user);

			newMessageId = messageTO.getMessageId();

		} catch (Exception e) {

			logger.error("ERROR OFM transfering the case " + e.getMessage());
			e.printStackTrace();
		}
		if (null != newMessageId) {

			return new ModelAndView("transferInfoSuccess");
		}

		return new ModelAndView("transferInfoUnsuccess");
	}

	private void checkNullCommandObject(Object command) throws Exception {

		if (null == command) {

			String errorMeg = "NULL Case Command object !!!";
			logger.error(errorMeg);
			throw new Exception(errorMeg);
		}
	}

	private ModelAndView handleTransferInfoToLcfs(HttpServletRequest request,
			HttpServletResponse response, Object command, SessionUser user)
			throws Exception {

		CaseTO caseInfo = (CaseTO) command;

		String message = request.getParameter("messagetext");
		String staffId = request.getParameter("transferStaffId");

		InformationObject info = caseFacade.loadInfoObjectOnly(caseInfo
				.getInformationId());

		String transferInfo = "Create and Allocate Case";
		if (caseInfo.getCaseId() != null) {
			transferInfo = "Allocate to LCFS";
		}
		// update information permission to new team.
		AuditFlowThread.set(transferInfo);
		caseFacade.updateInfoPermissionToLCFS(staffId, caseInfo, user);

		UserObject lcfsUser = messageFacade.loadUserByUserId(staffId);

		MessageTO messageTO = new MessageTO();
		messageTO.setCreatedTime(new Date());
		messageTO.setMessage(message);
		messageTO.setInformationId(caseInfo.getInformationId());
		messageTO.setFromStaffId(user.getStaffId());
		messageTO.setFromStaffName(user.getFullName());
		messageTO.setToStaffId(lcfsUser.getStaffId());
		messageTO.setToStaffName(EcmsUtils.getFullName(lcfsUser));
		messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
		messageTO.setInformationRef(info.getCreatedStaffId() + "#"
				+ info.getInformationId());
		messageTO.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER
				.toString());
		messageTO = messageFacade.saveMessage(messageTO);

		if (messageTO.getMessageId() != null) {
			return new ModelAndView("transferInfoSuccess");
		}
		return new ModelAndView("transferInfoUnsuccess");
	}

	/**
	 * HANDLE Reject Case
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @param errors
	 * @param command
	 * @return ModelAndView
	 * @throws Exception
	 */
	private ModelAndView handleRejectedTransferCase(SessionUser user,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String message = request.getParameter("messageciu");

		String comment = request.getParameter("comment");

		CaseTO caseInfo = (CaseTO) request.getSession().getAttribute(
				ECMSConstants.CASE_INFO_IN_SESSION);

		InformationObject information = caseFacade.loadInfoObjectOnly(caseInfo
				.getInformationId());

		information.setRejectedComment(comment);
		information.setState(ECMSConstants.INFO_STATE_REJECT_TRANSFER);
		AuditFlowThread.set("Rejected Transfer Case");
		caseFacade.saveRejectTransferInfo(user, information, message);

		return new ModelAndView("rejectTransferSuccess");
	}

	/**
	 * HANDLE Reject Case
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @param errors
	 * @param command
	 * @return ModelAndView
	 * @throws Exception
	 */
	private ModelAndView handleRejectCase(SessionUser user,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// String comment = request.getParameter("comment");

		CaseTO caseInfo = (CaseTO) request.getSession().getAttribute(
				ECMSConstants.CASE_INFO_IN_SESSION);

		Information infoTo = caseFacade.rejectInformation(caseInfo, user);

		createAudit(caseInfo, AuditLogService.CREATE, "Reject the Case",
				request, auditLogFacade);

		if (infoTo.getInformationDiscarded() != null) {
			return new ModelAndView("rejectCaseSuccess");
		}
		return new ModelAndView("rejectCaseUnsuccess");
	}

	/**
	 * Handle hold case.
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @param errors
	 * @param command
	 * @return ModelAndView
	 */
	private ModelAndView handleHoldCase(SessionUser user,
			HttpServletRequest request, HttpServletResponse response,
			Object command) throws Exception {

		CaseTO caseTO = (CaseTO) command;

		List<String> resp = user.getOrgOrTeamResponsibilityList();
		caseTO.setTeamList(resp);
		caseTO.setOrgCode(request.getParameter("orgCode"));
		// InCase a teamCode is selected from a list of teamCodes.
		String teamCodeParam = request.getParameter("teamSelect");

		/*		//Check for Unkown Organisation in Information.
				String orgCodeParam = request.getParameter("orgCode");		 
				if (orgCodeParam.equalsIgnoreCase(ECMSConstants.UNKOWN_ORG_CODE)) {
					return new ModelAndView("holdCaseUnsuccess", "message", VALID_ORG);
				}
				
		*/if (resp == null) {
			return new ModelAndView("holdCaseUnsuccess", "message",
					NO_TEAM_CODES);
		}
		if (resp != null && !resp.isEmpty()
				&& StringUtils.isEmpty(teamCodeParam)) {

			caseTO.setTeamCode("");
			return new ModelAndView("holdCaseSuccess", "caseInfo", caseTO);

		} else {

			if (StringUtils.isNotEmpty(teamCodeParam)) {

				caseTO.setTeamCode(teamCodeParam);
			}
			if (resp != null && resp.size() == 1) {

				caseTO.setTeamCode(resp.get(0));
			}
		}
		try {
			caseTO = caseFacade.saveHoldCase(caseTO, user);

			AuditFlowThread.set("Case on Hold Created");
			createAudit(caseTO, AuditLogService.CREATE, "Create Case on Hold",
					request, auditLogFacade);

		} catch (Exception e) {

			log.error("\n Exception saving onhold case :" + e.getMessage());
			throw new Exception(e);
		}
		if (caseTO.getCaseId() != null) {
			return new ModelAndView("holdCaseSuccess", "caseInfo", caseTO);
		}
		return new ModelAndView("holdCaseUnsuccess");
	}

	/**
	 * Handle Allocate User To Hold Case
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @param command
	 * @param errors
	 * @return ModelAndView
	 */
	private ModelAndView handleAllocateUserToHoldCase(SessionUser user,
			HttpServletRequest request, HttpServletResponse response,
			Object command) throws Exception {

		String infoIdParam = request.getParameter("informationId");
		String orgCodeParam = request.getParameter("orgCode");
		String caseIdParam = request.getParameter("caseId");
		String teamCodeParam = request.getParameter("teamCode");
		CaseTO caseTo = new CaseTO();
		caseTo.setInformationId(new Long(infoIdParam));
		caseTo.setOrgCode(orgCodeParam);
		caseTo.setCaseId(new Long(caseIdParam));

		caseTo.setActionType("userselectedtoholdcase");
		caseTo.setTeamList(user.getOrgOrTeamResponsibilityList());

		if (teamCodeParam != null) {

			Map<String, List<UserObject>> userListMap = caseFacade
					.loadUsersByTeamCodeAndGroups(teamCodeParam);
			caseTo.setLcfsList(userListMap.get("LCFS"));
			caseTo.setCfsList(userListMap.get("CFS"));
		}
		// caseTo.setLcfsList(caseFacade.loadUsersByGroups(
		//					new String[] { ECMSConstants.LCFS_LEVEL }));
		// caseTo.setCfsList(caseFacade.loadUsersByGroups(new String[] {
		// ECMSConstants.CFS_LEVEL, ECMSConstants.OFM_LEVEL }));

		return new ModelAndView("allocateUserToCaseView", "caseInfo", caseTo);
	}

	/**
	 * Handle Allocated Case User Selected
	 * 
	 * @param actionedBy
	 * @param request
	 * @param response
	 * @param errors
	 * @param command
	 * @return ModelAndView
	 */
	private ModelAndView handleAllocatedCaseUserSelected(
			SessionUser actionedBy, HttpServletRequest request,
			HttpServletResponse response, Object command) throws Exception {

		CaseTO caseInfo = (CaseTO) command;
		String teamCodeParam = request.getParameter("teamSelect");
		String lcfsStaff = request.getParameter("lcfsStaffSelect");
		String cfsStaff = request.getParameter("cfsStaffSelect");
		String message = request.getParameter("message");
		String auditMesg = "Create Case";
		boolean isClosedCase = false;
		boolean isExsistingCase = false;
		String caseID = null;
		if (null != caseInfo && null != caseInfo.getCaseId()) {

			caseID = caseInfo.getCaseId().toString();
		}
		if (StringUtils.isEmpty(caseID)) {

			caseID = request.getParameter(CaseUtil.CASE_ID_PARAM);
		}
		logInfoLevel("CASE ID = " + caseID);

		try {

			if (null != caseID && StringUtils.isNotEmpty(caseID)) {

				caseInfo = caseFacade.loadCase(Long.valueOf(caseID));

				if (null != caseInfo
						&& StringUtils.isNotEmpty(caseInfo.getState())) {

					isExsistingCase = true;
				}
				if (caseInfo.getState().equals(ECMSConstants.CASE_CLOSED)) {

					isClosedCase = true;
					caseInfo.setState(ECMSConstants.CASE_REOPENED);
				} else {
					caseInfo.setState(ECMSConstants.CASE_OPEN);
				}
			} else {
				logInfoLevel("Case ID not found, might be just information !!!");
			}

			logInfoLevel("TeamCode=" + teamCodeParam + ", LCFS=" + lcfsStaff
					+ ", CFS=" + cfsStaff);

			if (allocateCaseTOStaffCheck(teamCodeParam, lcfsStaff, cfsStaff)) {

				String allocatedStaffId = (lcfsStaff.equalsIgnoreCase("lcfs")) ? cfsStaff
						: lcfsStaff;

				logInfoLevel("Finally, allocated staff=" + allocatedStaffId);

				if (isExsistingCase) {

					auditMesg = isClosedCase ? "Reopening Closed Case"
							: "Reopening a OnHold or Awaiting Case";
					AuditFlowThread.set(auditMesg);
					caseInfo = caseFacade.reopenClosedCase(caseInfo,
							actionedBy, teamCodeParam, allocatedStaffId,
							isClosedCase);

				} else {
					auditMesg = "Creating a new Case";
					AuditFlowThread.set(auditMesg);
					caseInfo = caseFacade.saveCase(caseInfo, actionedBy,
							teamCodeParam, allocatedStaffId);
				}
				createAudit(caseInfo, AuditLogService.CREATE, auditMesg,
						request, auditLogFacade);
				MessageTO messageTo = setMessage(actionedBy, allocatedStaffId,
						caseInfo, message, true, null);
				messageTo = messageFacade.saveMessage(messageTo);
				createAudit(messageTo, AuditLogService.CREATE,
						"Creating Case Message", request, auditLogFacade);

				if (null != caseInfo && null != caseInfo.getCaseId()) {
					return new ModelAndView("allocateUserToCaseSuccess");
				}
			}

		} catch (Exception e) {
			log.error("ERROR Creating / Reopening a case :" + e.getMessage());
			throw e;
		}
		return new ModelAndView("allocateUserToCaseUnsuccess", "message",
				NO_TEAM_CODES);
	}

	/**
	 * Handle Allocate case requests including the reOpenedClosedCases.
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @param errors
	 * @param command
	 * @return ModelAndView.
	 */
	private ModelAndView handleAllocateCase(SessionUser user,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String infoIdParam = request.getParameter("informationId");
		String orgCodeParam = request.getParameter("orgCode");
		String teamCodeParam = request.getParameter("teamCode");
		String caseID = null;
		CaseTO caseTO = new CaseTO();

		try {

			if (StringUtils.isEmpty(caseID)) {

				caseID = request.getParameter(CaseUtil.CASE_ID_PARAM);
			}
			logInfoLevel("CASE ID = " + caseID);

			if (null != caseID && StringUtils.isNotEmpty(caseID)) {

				caseTO = caseFacade.loadCase(Long.valueOf(caseID));

				if (null != caseTO && StringUtils.isNotEmpty(caseTO.getState())) {

					teamCodeParam = caseTO.getTeamCode();
				}
				if (caseTO.getState().equals(ECMSConstants.CASE_CLOSED)) {

					caseTO.setState(ECMSConstants.CASE_REOPENED);
				} else {
					caseTO.setState(ECMSConstants.CASE_OPEN);
				}
			} else if (null != infoIdParam) {

				caseTO.setInformationId(new Long(infoIdParam));
				caseTO.setOrgCode(orgCodeParam);

				logInfoLevel("Case ID not found, might be just information !");
			} else {
				throw new Exception("No Information or Case details !!!");
			}
			/*
			 * <Check for UNKNOWN ORG in Information.>
			 * if(orgCodeParam.equals(ECMSConstants.UNKOWN_ORG_CODE)) {		 
			 * return new ModelAndView("allocateUserToCaseUnsuccess", "message", VALID_ORG); 
			 * } 
			 */

			if (user.isNITAFL()) {

				logInfoLevel("**USER IS AFL ***");

				Map<String, List<UserObject>> userListMap = caseFacade
						.loadNITUsersByGroups();

				caseTO.setLcfsList(userListMap.get("LCFS"));

				caseTO.setCfsList(userListMap.get("CFS"));

			} else if (teamCodeParam != null) {

				logInfoLevel("**USER with TEAM CODE ***");

				Map<String, List<UserObject>> userListMap = caseFacade
						.loadUsersByTeamCodeAndGroups(teamCodeParam);

				caseTO.setLcfsList(userListMap.get("LCFS"));

				caseTO.setCfsList(userListMap.get("CFS"));
			}
			caseTO.setTeamList(user.getOrgOrTeamResponsibilityList());
			caseTO.setAllocateTeamSelected("");

		} catch (Exception e) {
			log.error("\n ***ERROR Allocating / Reopening a case :"
					+ e.getMessage());
			e.printStackTrace();
		}
		return new ModelAndView("allocateUserToCaseView", "caseInfo", caseTO);
	}

	private ModelAndView handleAllocateCaseTeamChange(SessionUser user,
			HttpServletRequest request, HttpServletResponse response,
			Object command) throws Exception {

		String infoIdParam = request.getParameter("informationId");
		String orgCodeParam = request.getParameter("orgCode");
		String teamCodeParam = request.getParameter("teamCode");
		String caseID = request.getParameter(CaseUtil.CASE_ID_PARAM);
		logInfoLevel(" CASE ID = " + caseID);

		CaseTO caseTO = new CaseTO();

		try {

			if (null != caseID && StringUtils.isNotEmpty(caseID)) {

				caseTO = caseFacade.loadCase(Long.valueOf(caseID));

				if (null != caseTO && StringUtils.isNotEmpty(caseTO.getState())) {

					if (caseTO.getState().equals(ECMSConstants.CASE_CLOSED)) {

						caseTO.setState(ECMSConstants.CASE_REOPENED);
					} else {

						caseTO.setState(ECMSConstants.CASE_OPEN);
					}
				}
			} else if (null != infoIdParam) {

				caseTO.setInformationId(new Long(infoIdParam));
				caseTO.setOrgCode(orgCodeParam);

				logInfoLevel("Case ID not found, might be just information.");

			}
			caseTO.setTeamList(user.getOrgOrTeamResponsibilityList());

			if (null != teamCodeParam) {

				Map<String, List<UserObject>> userListMap = caseFacade
						.loadUsersByTeamCodeAndGroups(teamCodeParam);
				caseTO.setLcfsList(userListMap.get("LCFS"));
				caseTO.setCfsList(userListMap.get("CFS"));
			}
			caseTO.setAllocateTeamSelected(teamCodeParam);

		} catch (Exception e) {

			log.error("\n ERROR Allocate / Reopening case team changed :"
					+ e.getMessage());
			throw e;
		}
		return new ModelAndView("allocateUserToCaseView", "caseInfo", caseTO);
	}

	/**
	 * Helper method to check whether team code and (LCFS or CFS staff) is
	 * selected while allocating information to a CASE.
	 * 
	 * @param teamCode
	 * @param lcfsStaff
	 * @param cfsStaff
	 * @return boolean
	 */
	private boolean allocateCaseTOStaffCheck(String teamCode, String lcfsStaff,
			String cfsStaff) {

		if ((StringUtils.isNotEmpty(teamCode) && teamCode != "team")
				&& ((StringUtils.isNotEmpty(lcfsStaff) && lcfsStaff != "lcfs") || (StringUtils
						.isNotEmpty(cfsStaff) && cfsStaff != "cfs"))) {

			return true;
		}
		return false;
	}

	private MessageTO setMessage(SessionUser user, String staffId,
			CaseTO caseInfo, String message, boolean isCase, Information info)
			throws Exception {

		MessageTO messageTO = new MessageTO();
		messageTO.setCreatedStaffId(user.getStaffId());
		messageTO.setCreatedTime(new Date());
		messageTO.setFromStaffId(user.getStaffId());

		UserObject selectedUser = messageFacade.loadUserByUserId(staffId);

		messageTO.setToStaffId(selectedUser.getStaffId());
		messageTO.setToStaffName(EcmsUtils.getFullName(selectedUser));
		messageTO.setFromStaffName(user.getFullName());
		messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
		messageTO.setInformationRef("");
		if (isCase) {
			messageTO.setCaseId(caseInfo.getCaseId());
			messageTO.setCaseRef("Case Id:" + caseInfo.getCaseId());
			messageTO.setMessageType(MessageTO.Message_types.CASE_ALLOCATION
					.toString());
		} else {
			messageTO.setInformationId(info.getInformationId());
			messageTO.setInformationRef(info.getCreatedStaffId() + "#"
					+ info.getInformationId());
			messageTO
					.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER
							.toString());
		}
		messageTO.setMessage(message);

		return messageTO;
	}

	private boolean setStaffDetails(MessageTO messageTO, SessionUser user,
			String teamCode) throws ServiceException {

		messageTO.setCreatedStaffId(user.getStaffId());
		messageTO.setFromStaffId(user.getStaffId());
		messageTO.setFromStaffName(user.getFullName());
		messageTO.setCreatedTime(new Date());
		final Long informaitonId = messageTO.getInformationId();
		InformationView info = messageFacade
				.loadInformationViewById(informaitonId);
		UserObject ofmObj = messageFacade.loadOFMByTeamOrOrgCode(teamCode,
				false);

		if (ofmObj != null) {
			messageTO.setToStaffId(ofmObj.getStaffId());
			messageTO.setToStaffName(EcmsUtils.getFullName(ofmObj));
		} else {
			return false;
		}

		messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
		messageTO.setInformationRef(info.getCreatedStaffId() + "#"
				+ info.getInformationId());

		return true;
	}

	public boolean checkTransferTOCIUorFPU(String transfer) {

		if (transfer != null
				&& (transfer.equalsIgnoreCase(ECMSConstants.TEAM_CIU) || transfer
						.equalsIgnoreCase(ECMSConstants.TEAM_IMO))) {
			return true;
		}
		return false;
	}

	/**
	 * Setter method of the CaseService.
	 * 
	 * @param caseFacade
	 */
	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

	/**
	 * Setter method for Audit Log
	 * 
	 * @param auditLogFacade
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public void setMessageFacade(MessageService messageFacade) {
		this.messageFacade = messageFacade;
	}

}
