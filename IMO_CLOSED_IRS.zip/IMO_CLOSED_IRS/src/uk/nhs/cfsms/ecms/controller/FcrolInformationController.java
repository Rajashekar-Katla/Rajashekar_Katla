package uk.nhs.cfsms.ecms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.infoGath.FcrolInformationView;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationDetails;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SourceInformationTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.service.OrganisationService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.InformationUtil;
import uk.nhs.cfsms.ecms.utility.PatientOccupationLookupMap;

/**
 * FCROLInformationFormController provides similar form to the information.
 * 
 * @author vKolla
 * 
 */
@Controller
public class FcrolInformationController extends BaseMultiActionController {

	@Autowired
	InformationGatherService informationGatherFacade;
	@Autowired
	LookupViewService lookupViewFacade;
	@Autowired
	OrganisationService organisationFacade;

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;

	static final String ASSOCIATE = "ASSOCIATE";
	static final String SOURCE = "SOURCE";
	static final String SUBJECT = "SUBJECT";

	static final String infoFormPath = "/secure/information.htm";

	/**
	 * Get the InformationDetails for an Information ID
	 * 
	 * @param id
	 *            informationId
	 * @param request
	 *            HttpServletRequest
	 * @return InformationDetails
	 */
	@RequestMapping(value="/secure/viewfcrolinformation.htm")
	public ModelAndView viewFcrolInformation(HttpServletRequest request,
			HttpServletResponse response) {

		String infoId = request.getParameter("infoId");
		InformationDetails info = null;

		HttpSession session = request.getSession();
		SessionUser sessionUser = EcmsUtils.getSessionUserObject(session);
		
		List teamCodes = null;
		List<Organisation> orgCodes = null;
		
		info = informationGatherFacade
				.loadFcrolInformationById(new Long(infoId));

		String srcType = info.getInformationTO().getSourceInformationTO()
				.getSourceType();
		String otherSrc = info.getInformationTO().getSourceInformationTO()
				.getOtherSource();
		if ((srcType == null || "".equals(srcType.trim()))
				&& (otherSrc != null && !otherSrc.trim().equals(""))) {
			info.getInformationTO().getSourceInformationTO().setSourceType(
					ECMSConstants.SOURCE_TYPE_OTHER);
		}
		
		InformationTO infoTO = info.getInformationTO();
		try {

			// this.setupFormSubmission(infoTO, request);

			if (session.getAttribute("teamCodesList") != null) {
				teamCodes = (List) session.getAttribute("teamCodesList");
			}
			if (session.getAttribute("orgCodesList") != null) {
				orgCodes = (List) session.getAttribute("orgCodesList");
			}

			if (teamCodes == null) {
				teamCodes = organisationFacade.loadAllTeamCodes();
				infoTO.setTeamCodesList(teamCodes);
				session.setAttribute("teamCodesList", teamCodes);
				orgCodes = organisationFacade.loadOrganisationsByOrgName("", sessionUser);
				session.setAttribute("orgCodesList", orgCodes);
			}

			setupAllLookupDetails(infoTO);

			updateSourceLookupDetails(infoTO);

		} catch (Exception e) {
			log.error(e);
		}

		Map<String, Object> informationMap = new HashMap<String, Object>();
		informationMap.put("informationDetails", info);
		informationMap.put("information", info.getInformationTO());
		return new ModelAndView("fcrolinformationView", "informationMap",
				informationMap);

	}

	@RequestMapping(value="/secure/listfcrolinformation.htm")
	public ModelAndView listFcrolInformation(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		if (user == null) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}
		if (log.isInfoEnabled()) {
			log.info("** handleAllInformationList");
		}
		List<FcrolInformationView> infoList = informationGatherFacade
				.loadFcrolInformationView();

		Map<String,List<FcrolInformationView>> listMap = new HashMap<String,List<FcrolInformationView>>();
		listMap.put("information", infoList);

		return new ModelAndView("fcrolInformationList", "infoMap", listMap);
	}

	@RequestMapping(value="/secure/savefcrolinformation.htm")
	public ModelAndView saveFcrolInformation(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String infoId = request.getParameter("infoId");
		String teamCode = request.getParameter("teamCode");
		String regOverride = request.getParameter("regOverride");
		String orgCode = request.getParameter("orgCode");

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		informationGatherFacade.saveFcrolInformation(user.getStaffId(),
				teamCode, new Long(infoId), regOverride, orgCode);
		
		createAudit(new String("Save FCROL Information, Id="+infoId), 
				AuditLogService.CREATE, 
				"Save FCROL Information", 
				request, 
				auditLogFacade);

		return listFcrolInformation(request, response);

	}

	@RequestMapping(value="/secure/rejectfcrolinformation.htm")
	public ModelAndView rejectFcrolInformation(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String infoId = request.getParameter("infoId");
		String rejectReason = request.getParameter("rejectReason");

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		informationGatherFacade.rejectFcrolInformation(new Long(infoId), user
				.getStaffId(), rejectReason);
		
		createAudit(new String("Reject FCROL Information Id="+infoId), 
					AuditLogService.UPDATE, 
					"Reject Information", 
					request, 
					auditLogFacade);
		
		return listFcrolInformation(request, response);

	}

	private void setupAllLookupDetails(InformationTO info) {

		String[] lookupGroupNames = InformationUtil.getAllLookupGroups();

		for (String groupName : lookupGroupNames) {
			info.addInfoLookupViewMap(groupName, getLookupDetails(groupName));
		}
		info.setStaticInfoLookupViewMap();
		setUpPatientOccupationLookupDetails();
	}
	
	/**
	 * LookupView details for patient occupation
	 * 
	 * @return List.
	 */
	private void setUpPatientOccupationLookupDetails() {
		final List<LookupView> lookupList = lookupViewFacade
				.loadPatientOccupationDescriptions();
		for (LookupView view : lookupList) {
			final String lookupId = String.valueOf(view.getLookupId());
			final String description = view.getDescription();
			final Map<String, String> map = PatientOccupationLookupMap
					.getAllPatientOccupationDetailsLookupMap();
			if (!map.containsKey(lookupId)) {
				map.put(lookupId, description);
			}
		}
	}
	

	/**
	 * helper method.
	 * 
	 * @param info
	 */
	private void updateSourceLookupDetails(InformationTO info) throws Exception {

		if (info != null && info.getSourceInformationTO() != null) {
			SourceInformationTO srcTO = info.getSourceInformationTO();

			if (srcTO != null && srcTO.getSource() != null
					&& srcTO.getSource().trim().length() > 0) {

				LookupView view = lookupViewFacade
						.loadLookupDetailsById(new Integer(srcTO.getSource()));

				if (view != null) {
					srcTO.setSourceType(view.getParentId().toString());
					info.addInfoLookupViewMap(
							ECMSConstants.LOOKUP_SOURCE_SUB_TYPE,
							lookupViewFacade
									.loadActiveLookupDetailsByParentId(view
											.getParentId()));
					// Make it static
					info.setStaticInfoLookupViewMap();
				}
			}
		}
	}

	/**
	 * LookupView Details given the group name
	 * 
	 * @param groupName
	 * @return List.
	 */
	private List<LookupView> getLookupDetails(String groupName) {

		if (groupName != null)
			return lookupViewFacade.loadActiveLookupDetailsByGroups(groupName);

		return null;
	}

	/**
	 * Setter method for the service.
	 * 
	 * @param informationGatherFacade
	 */
	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}

	public void setLookupViewFacade(LookupViewService lookupViewFacade) {
		this.lookupViewFacade = lookupViewFacade;
	}

	/**
	 * @param organisationFacade
	 *            The organisationFacade to set.
	 */
	public void setOrganisationFacade(OrganisationService organisationFacade) {
		this.organisationFacade = organisationFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
}
