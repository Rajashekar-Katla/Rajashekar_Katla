package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.common.UserPreference;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.service.OrganisationService;
import uk.nhs.cfsms.ecms.service.UserInformationService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * AjaxListController delivers list of different details like organisation.
 * 
 * @author schilukuri
 * 
 */
@Controller
public class AjaxListController extends AbstractController {
	@Autowired
	private OrganisationService organisationFacade;
	@Autowired
	private LookupViewService lookupViewFacade;
	@Autowired
	private UserInformationService userInformationFacade;

	public static final String RESPONSIBLE_ORGS = "resporgs";
	public static final String ORGANISATIONS = "organisations";
	public static final String LOOKUP_PARENT = "lookupbyparent";
	public static final String LCFS_STAFF_LIST = "lcfsStaffList";
	public static final String CFS_STAFF_LIST = "cfsStaffList";
	public static final String LIST_OF_EMPLOYEES = "listOfEmployees";
	@Deprecated
	public static final String LOAD_FONT = "loadfont";
	public static final String UPDATE_FONT = "fontupdate";

	protected final Log log = LogFactory.getLog(getClass());

	@SuppressWarnings("unchecked")
	@Override
	@RequestMapping(value = "/secure/ajaxList.htm")
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String action = request.getParameter("action");
		String keyword = request.getParameter("keyword");
		String groupId = request.getParameter("groupId");

		if (log.isDebugEnabled()) {
			log.debug("\nREQ - PARAMS - Keyword='" + keyword + "', Action='"
					+ action + "', groupId=" + groupId);
		}

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		if (action != null) {

			response.setContentType("text/xml");
			response.setHeader("Cache-Control", "no-cache");

			if (action.equalsIgnoreCase(RESPONSIBLE_ORGS)) {
				List<Organisation> orgs = new ArrayList<Organisation>();
				if (user.isUserLCFS()) {
					orgs = organisationFacade.loadOrganisationsByOrgName(
							keyword, user.getStaffId());
				} else {
					orgs = organisationFacade
							.loadOrganisationsByOrgName(keyword);
				}
				response.getWriter().write(setOrganisationsXML(orgs));

			} else if (action.equalsIgnoreCase(ORGANISATIONS)) {

				List<Organisation> orgs = organisationFacade
						.loadOrganisationsByOrgName(keyword);

				response.getWriter().write(setOrganisationsXML(orgs));

			} else if (action.equalsIgnoreCase(LOOKUP_PARENT)) {

				if (StringUtils.isEmpty(groupId)
						|| (StringUtils.isNotEmpty(groupId) && groupId
								.equals("0"))
						|| StringUtils.isNotEmpty(keyword)) {

					response.getWriter().write(
							setLookupViewXML(getLookups(keyword)));
				} else {
					response.getWriter().write(
							setLookupViewXML(getLookups(keyword, groupId)));
				}

			} else if (action.equalsIgnoreCase(LCFS_STAFF_LIST)) {

				response.getWriter()
						.write(setLcfsStaffXML(userInformationFacade
								.loadUsersByGroups(new String[] { ECMSConstants.LCFS_LEVEL })));

			} else if (action.equalsIgnoreCase(CFS_STAFF_LIST)) {

				response.getWriter()
						.write(setCfsStaffXML(userInformationFacade
								.loadUsersByGroups(new String[] { ECMSConstants.LCFS_LEVEL })));

			} else if (action.equalsIgnoreCase(LOAD_FONT)) {

				UserPreference curPref = userInformationFacade
						.loadUserPrefereces(user.getStaffId());
				request.getSession().setAttribute(
						ECMSConstants.SESSION_USER_FONT,
						null != curPref ? curPref.getFontSize()
								: ECMSConstants.DEFAULT_USER_FONT);
				response.getWriter().write(setCurrentFont(curPref));

			} else if (action.equalsIgnoreCase(UPDATE_FONT)) {

				UserPreference usrPref = createPreference(user.getStaffId(),
						request.getParameter("fontsize"));
				userInformationFacade.updateUserPreferences(usrPref);
				UserPreference curPref = userInformationFacade
						.loadUserPrefereces(user.getStaffId());
				// update user_font session value with saved font. 
				request.getSession().setAttribute(
						ECMSConstants.SESSION_USER_FONT,
						null != curPref ? curPref.getFontSize()
								: ECMSConstants.DEFAULT_USER_FONT);
				response.getWriter().write(setCurrentFont(curPref));
			} else if (action.equalsIgnoreCase(LIST_OF_EMPLOYEES)) {
				List<String> list = null;
				String empSearchKeyword = keyword;
				//list=userInformationFacade.searchUsers(empSearchKeyword);
				list = userInformationFacade.searchUsers(empSearchKeyword,
						user, CaseUtil.getCaseId(request));
				response.getWriter().write(setEmployeesXML(list));

			}
		}
		return null;
	}

	private UserPreference createPreference(String staffId, String reqFont) {
		if (log.isDebugEnabled()) {
			log.debug("\n REQ - FontSize ='" + reqFont + ", staffId=" + staffId);
		}
		UserPreference usrPref = new UserPreference();
		usrPref.setStaffId(staffId);
		usrPref.setFontSize(null != reqFont ? reqFont
				: ECMSConstants.DEFAULT_USER_FONT);
		usrPref.setCreatedTime(new Date());

		return usrPref;
	}

	@Deprecated
	private String setCurrentFont(UserPreference loadUserPrefereces) {

		StringBuffer cfsSB = new StringBuffer("<stafffont>");

		if (null != loadUserPrefereces) {

			cfsSB.append(null != loadUserPrefereces.getFontSize() ? loadUserPrefereces
					.getFontSize() : ECMSConstants.DEFAULT_USER_FONT);
		}
		cfsSB.append("</stafffont>");

		return cfsSB.toString();
	}

	/**
	 * Get LookupView details by parentId
	 * 
	 * @param keyword
	 *            parentId
	 * @return List.
	 * @throws Exception
	 */
	private List<LookupView> getLookups(String keyword) throws Exception {

		List<LookupView> list = new ArrayList<LookupView>();

		try {
			list = lookupViewFacade
					.loadActiveLookupDetailsByParentId(new Integer(keyword));

		} catch (NumberFormatException e) {
			log.error("Invalid parent Id =" + keyword, e);
			log.error(e);
		}
		return list;
	}

	/**
	 * Get LookupView details by parentId
	 * 
	 * @param keyword
	 *            parentId
	 * @return List.
	 * @throws Exception
	 */
	private List<LookupView> getLookups(String keyword, String groupId)
			throws Exception {

		List<LookupView> list = new ArrayList<LookupView>();

		try {
			list = lookupViewFacade.loadActiveLookupDetailsByParentId(
					new Integer(keyword), new Integer(groupId));

		} catch (NumberFormatException e) {
			log.error("Invalid parent Id =" + keyword, e);
			log.error(e);
		}
		return list;
	}

	private String setLcfsStaffXML(List<UserObject> lcfsList) {
		StringBuffer lcfsSB = new StringBuffer("<lcfsstafflist>\r");
		for (UserObject lcfs : lcfsList) {
			lcfsSB.append("<lcfsstaff>\r");
			lcfsSB.append("<staffid>");
			lcfsSB.append(lcfs.getStaffId());
			lcfsSB.append("</staffid>\r");
			lcfsSB.append("<staffname>");
			lcfsSB.append(lcfs.getFirstName() + " " + lcfs.getLastName());
			lcfsSB.append("</staffname>\r");
			lcfsSB.append("</lcfsstaff>\r");
		}
		lcfsSB.append("</lcfsstafflist>");

		return lcfsSB.toString();
	}

	private String setCfsStaffXML(List<UserObject> lcfsList) {
		StringBuffer cfsSB = new StringBuffer("<cfsstafflist>\r");
		for (UserObject lcfs : lcfsList) {
			cfsSB.append("<cfsstaff>\r");
			cfsSB.append("<staffid>");
			cfsSB.append(lcfs.getStaffId());
			cfsSB.append("</staffid>\r");
			cfsSB.append("<staffname>");
			cfsSB.append(lcfs.getFirstName() + " " + lcfs.getLastName());
			cfsSB.append("</staffname>\r");
			cfsSB.append("</cfsstaff>\r");
		}
		cfsSB.append("</cfsstafflist>");

		return cfsSB.toString();
	}

	private String setLookupViewXML(List<LookupView> viewList) {
		StringBuffer orgSB = new StringBuffer("<listoflookups>\r");
		for (LookupView view : viewList) {
			orgSB.append("<lookup>\r");
			orgSB.append("<description>");
			orgSB.append(view.getDescription());
			orgSB.append("</description>\r");
			orgSB.append("<lookupId>");
			orgSB.append(view.getLookupId());
			orgSB.append("</lookupId>\r");
			orgSB.append("</lookup>\r");
		}
		orgSB.append("</listoflookups>");

		return orgSB.toString();
	}

	private String setOrganisationsXML(List<Organisation> orgList) {
		StringBuffer orgSB = new StringBuffer("<listoforganisations>\r");
		String orgName = "";
		for (Organisation org : orgList) {
			orgName = org.getOrgName();
			if (orgName.indexOf("&") != -1) {
				orgName = orgName.replace("&", "and");
			}
			orgSB.append("<organisation>\r");
			orgSB.append("<orgname>");
			orgSB.append(orgName);
			orgSB.append("</orgname>\r");
			orgSB.append("<orgcode>");
			orgSB.append(org.getOrgCode());
			orgSB.append("</orgcode>\r");
			orgSB.append("</organisation>\r");
		}
		orgSB.append("</listoforganisations>");

		return orgSB.toString();
	}

	private String setEmployeesXML(List<String> empList) {
		StringBuffer empSB = new StringBuffer("<listOfEmployees>\r");
		Boolean flag = false;
		for (String emp : empList) {
			String empSplit[] = emp.split("-");
			/*if(!flag){
				empSB.append("<employees>\r");
				empSB.append("<empName>");
				empSB.append("Please select");
				empSB.append("</empName>\r");
				empSB.append("<empCode>");
				empSB.append("0");
				empSB.append("</empCode>\r");
				empSB.append("</employees>\r");
				flag=true;
			}*/
			empSB.append("<employees>\r");
			empSB.append("<empName>");
			empSB.append(empSplit[0] + " (" + empSplit[1] + ")");
			empSB.append("</empName>\r");
			empSB.append("<empCode>");
			empSB.append(empSplit[1]);
			empSB.append("</empCode>\r");
			empSB.append("</employees>\r");
		}
		empSB.append("</listOfEmployees>");

		return empSB.toString();
	}

	public void setOrganisationFacade(OrganisationService organisationFacade) {
		this.organisationFacade = organisationFacade;
	}

	public void setLookupViewFacade(LookupViewService lookupViewFacade) {
		this.lookupViewFacade = lookupViewFacade;
	}

	public void setUserInformationFacade(
			UserInformationService userInformationFacade) {
		this.userInformationFacade = userInformationFacade;
	}

}
