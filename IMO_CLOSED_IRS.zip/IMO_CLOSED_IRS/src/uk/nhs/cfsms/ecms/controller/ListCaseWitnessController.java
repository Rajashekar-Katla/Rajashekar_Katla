package uk.nhs.cfsms.ecms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.data.witness.Witness;
import uk.nhs.cfsms.ecms.data.witness.WitnessStatement;
import uk.nhs.cfsms.ecms.dto.witness.WitnessStatementTO;
import uk.nhs.cfsms.ecms.dto.witness.WitnessTO;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.WitnessService;
import uk.nhs.cfsms.ecms.service.WitnessStatementService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.FileUtils;

/**
 * List Case Witness Controller is for handling Witness and Witness Statement
 * list. Provision for generating MG9 Forms. Uploading and Downloading MG2, MG6
 * Forms.
 * 
 */
@Controller
public class ListCaseWitnessController extends BaseMultiActionController {

	@Autowired
	WitnessService witnessFacade;
	@Autowired
	WitnessStatementService witnessStatementFacade;
	@Autowired
	private AuditLogService auditLogFacade;

	protected final Log log = LogFactory.getLog(getClass());
	 
	static final String CASE_ID_PARAM = "caseId";

	static final String WITNESS_ID_PARAM = "witnessId";

	static final String STATEMENT_ID_PARAM = "statementId";

	/**
	 * Handle Witness
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/listWitness.htm")
	public ModelAndView handleListCaseWitnesses(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String caseID;
		Map<String, Object> witnessMap = new HashMap<String, Object> ();

		try {
			caseID = CaseUtil.getCaseId(request);

			if (null == caseID || StringUtils.isEmpty(caseID)) {
				CaseUtil.logErrorCaseIDNotFound(logger);
				return CaseUtil.getCasePortalView();
			}
			
			Long caseIDLong = new Long(caseID);
			List<WitnessTO> witnesses = witnessFacade.loadWitnessesByCaseId(caseIDLong);
			witnessMap.put("witnessSize", witnesses.size());
			witnessMap.put("witnessList", witnesses);
			witnessMap.put(CASE_ID_PARAM, caseID);

			return new ModelAndView("showWitnesses", "witnessMap", witnessMap);

		} catch (NumberFormatException nfe) {
			logger.error(nfe);
			throw nfe;
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * Handle WitnessStatement
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/listWitnessStatements.htm")
	public ModelAndView handleWitnessStatements(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String caseID;
		String witnessID = request.getParameter("witnessId");
		String partNumber = request.getParameter("partNumber");
		int partNo = Integer.parseInt(partNumber);
		List<WitnessStatementTO> filledstatementsList = null;
		List<WitnessStatement> uploadedstatementsList = null;
		String viewName = null;
		try {
			caseID = CaseUtil.getCaseId(request);

			if (StringUtils.isEmpty(caseID)) {
				CaseUtil.logErrorCaseIDNotFound(logger);
				return CaseUtil.getCasePortalView();
			}
			Long caseIDLong = new Long(caseID);
			if (StringUtils.isEmpty(witnessID)) {
				filledstatementsList = witnessStatementFacade.loadWitnesseStatementsByCaseId(caseIDLong,partNo,
							ECMSConstants.FILLED_STATEMENT);
			} else {
				filledstatementsList = witnessStatementFacade.loadStatementsByWitnessIdAndType(new Long(witnessID),partNo,
						ECMSConstants.FILLED_STATEMENT);
			}
			Map<String, Object> statementsMap = new HashMap<String, Object>();
			statementsMap.put("filledStatementSize", filledstatementsList.size());
			statementsMap.put("filledStatementList", filledstatementsList);
			statementsMap.put(CASE_ID_PARAM, caseID);
			// Upload statement
			if (StringUtils.isEmpty(witnessID)) {
				uploadedstatementsList = witnessStatementFacade.loadWitnesseStatementsByCaseId(caseIDLong,partNo,
							ECMSConstants.UPLOADED_STATEMENT);
			} else {
				uploadedstatementsList = witnessStatementFacade.loadStatementsByWitnessIdAndType(new Long(witnessID),partNo,
						ECMSConstants.UPLOADED_STATEMENT);
			}
			statementsMap.put("uploadedStatementSize", uploadedstatementsList.size());
			statementsMap.put("uploadedStatementList", uploadedstatementsList);

			if(partNo == 1){viewName = "showWitnessStatementList";}
			if(partNo == 2){viewName = "showWitnessStatementPart2List";}
			
			return new ModelAndView(viewName,"statementsMap", statementsMap);

		} catch (NumberFormatException nfe) {
			logger.error(nfe);
			throw nfe;
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * Handle Witness Download
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value ="/secure/witnessdownload.htm")
	public ModelAndView handleWitnessDownload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String actionType = request.getParameter("actionType");
		try {
			if (null != actionType
					&& actionType.equalsIgnoreCase("downloadmg2form")) {

				String witnessId = request.getParameter(WITNESS_ID_PARAM);
				WitnessTO witnessTO = witnessFacade.loadWitnessById(new Long(
						witnessId));

				byte[] mg2Form = witnessTO.getMg2Form();
				String fileType=witnessTO.getMg2FormFileType();
				String fileName=witnessTO.getMg2FormFileName();				
			
				String contentType=FileUtils.getContentTypeByFileExt(fileType,null);
				
				if(null ==contentType) {
				
					contentType=FileUtils.getContentTypeByFileName(fileType,"application/msword");
				}
				
				if(null ==fileName) {
					
					fileName=FileUtils.getSampleFileNameByContentType(contentType,"mg2form","mg2form.doc");
				}	
				
				FileUtils.writeOutputForm(mg2Form,fileName,contentType,response);

				//writeOutputForm(mg2Form, "mg2form.doc", response);

			}
			if (null != actionType
					&& actionType.equalsIgnoreCase("downloadmg6form")) {

				String witnessId = request.getParameter(WITNESS_ID_PARAM);
				WitnessTO witnessTO = witnessFacade.loadWitnessById(new Long(
						witnessId));

				byte[] mg6Form = witnessTO.getMg6Form();
				String fileType=witnessTO.getMg6FormFileType();
				String fileName=witnessTO.getMg6FormFileName();
				
				String contentType=FileUtils.getContentTypeByFileExt(fileType,null);
				
				if (null ==contentType) {
				
					contentType=FileUtils.getContentTypeByFileName(fileType,"application/msword");	
				}
				if (null ==fileName) {
					
					fileName=FileUtils.getSampleFileNameByContentType(contentType,"mg6form","mg6form.doc");
				}	
								
				FileUtils.writeOutputForm(mg6Form,fileName,contentType,response);

				//writeOutputForm(mg6Form, "mg6form.doc", response);

			}
			if (null != actionType
					&& actionType.equalsIgnoreCase("downloadwitnessstatement")) {

				String statementId = request.getParameter(STATEMENT_ID_PARAM);
				WitnessStatementTO statementTO = witnessStatementFacade
						.loadWitnessStatementById(new Long(statementId));

				byte[] statementFile = statementTO.getStatementFile();
				//In order to match with legacy data,check data for correct conteny type.
				String fileType=statementTO.getStatementFileType();
				String fileName=statementTO.getFileName();
				
			
				String contentType=FileUtils.getContentTypeByFileExt(fileType,null);
				if(null ==contentType)
				contentType=FileUtils.getContentTypeByFileName(fileType,"application/msword");	
				
				if(null ==fileName)
				{
					
					fileName=FileUtils.getSampleFileNameByContentType(contentType,"statement","statement.doc");
				}	
				
				FileUtils.writeOutputForm(statementFile,fileName,contentType,response);
			}
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}

		return null;
	}

	/**
	 * Show MG9Form.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 *
	@RequestMapping(value ="/secure/showMG9Form.htm")
	public ModelAndView showMG9Form(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String byFilter = "surname";
		String actionType = request.getParameter("actionType");
		try {
			if (null != actionType) {
				if (actionType.equalsIgnoreCase("surname")) {
					byFilter = "surname";
				} else if (actionType.equalsIgnoreCase("statementDate")) {
					byFilter = "statementDate";
				} else if (actionType.equalsIgnoreCase("witnessSerialNo")) {
					byFilter = "witnessSerialNo";
				}
			}
			String caseID = CaseUtil.getCaseId(request);
			List<Witness> list = witnessFacade.loadAllWitnessesByCaseId(
					new Long(caseID), byFilter);

			String stylesheetPath = CaseUtil.getWitnessXSLPath(request);
			String caseNumber = CaseUtil.getCaseNumberInSession(request);
			String operationName = CaseUtil.getOperationNameInSession(request);
			if (logger.isInfoEnabled()) {
				logger.info("CASE NUMBER : "+ caseNumber);
				logger.info("OPERATION NAME : "+ operationName); 
			}
			Document d = witnessFacade.transform(stylesheetPath, list, caseNumber, operationName);
			FileCopyUtils.copy(d.asXML().getBytes(), response.getOutputStream());
 
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
		return null;
	}*/
	
 
	@RequestMapping(value ="/secure/showMG9Form.htm")
	public ModelAndView showMG9Form(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		String byFilter = "surname";
		String actionType = request.getParameter("actionType");
		try {
			if (null != actionType) {
				if (actionType.equalsIgnoreCase("surname")) {
					byFilter = "surname";
				} else if (actionType.equalsIgnoreCase("statementDate")) {
					byFilter = "statementDate";
				} else if (actionType.equalsIgnoreCase("witnessSerialNo")) {
					byFilter = "witnessSerialNo";
				}
			}
			String caseID = CaseUtil.getCaseId(request);
			
			List<Witness> list = witnessFacade.loadAllWitnessesByCaseId(new Long(caseID), byFilter);

			String caseNumber = CaseUtil.getCaseNumberInSession(request);
			
			String operationName = CaseUtil.getOperationNameInSession(request);
			
			String schemaPath = CaseUtil.getWitnessXSLPath(request);
			
			if (logger.isDebugEnabled()) {
				logger.debug("CASE NUMBER : "+ caseNumber +", OPERATION NAME : "+ operationName); 
			}
			//Document d = witnessFacade.transform(schemaPath, list, caseNumber, operationName);
			Document d = witnessFacade.transform(schemaPath, list, caseNumber, operationName);
			FileCopyUtils.copy(d.asXML().getBytes(), response.getOutputStream());
 
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
		return null;
	}
	/**
	 * Delete uploaded WitnessStatements
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/deleteWitnessStatement.htm")
	public ModelAndView deleteWitnessStatement(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String caseID;
		Map<String, Object> statementsMap = new HashMap<String, Object>();
		String statementID = request.getParameter(STATEMENT_ID_PARAM);
		String partNumber = request.getParameter("partNumber");
		int partNo = Integer.parseInt(partNumber);
		String viewName = null;
		try {
			caseID = CaseUtil.getCaseId(request);

			if (StringUtils.isEmpty(caseID)) {
				CaseUtil.logErrorCaseIDNotFound(logger);
				return CaseUtil.getCasePortalView();
			}

			if (StringUtils.isNotEmpty(statementID)	&& EcmsUtils.onDelete(request)) {

				witnessStatementFacade.deleteWitnessStatement(new Long(statementID));
				createAudit(new String("Delete WitnessStatement with Statement Id ="
								+ statementID), AuditLogService.DELETE,
						"Witness Statement", request, auditLogFacade);
			}
			
			//TODO: Rather than getting details for every one in the case. Just get witness details by witnessId.
			
			Long caseIDLong = new Long(caseID);
			
			List<WitnessStatementTO> filledstatementsList = witnessStatementFacade.loadWitnesseStatementsByCaseId(caseIDLong,partNo,
							ECMSConstants.FILLED_STATEMENT);
			statementsMap.put("filledStatementSize", filledstatementsList.size());
			statementsMap.put("filledStatementList", filledstatementsList);
			statementsMap.put(CASE_ID_PARAM, caseID);

			List<WitnessStatement> uploadedstatementsList = witnessStatementFacade.loadWitnesseStatementsByCaseId(caseIDLong,partNo,
						ECMSConstants.UPLOADED_STATEMENT);
			statementsMap.put("uploadedStatementSize", uploadedstatementsList.size());
			statementsMap.put("uploadedStatementList", uploadedstatementsList);

			if(partNo == 1){viewName = "showWitnessStatementList";}
			if(partNo == 2){viewName = "showWitnessStatementPart2List";}
			
			return new ModelAndView(viewName, "statementsMap", statementsMap);

		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * Common file Output.
	 * 
	 * @param file
	 * @param name
	 * @param response
	 * @throws Exception
	
	private void writeOutputForm(byte[] file, String name,String fileType,
			HttpServletResponse response) throws Exception {

		response.setHeader("Content-disposition", "attachment; filename="
				+ name);
		//response.setContentType("application/msword");
		response.setContentType(fileType);
		response.setContentLength(file.length);

		ServletOutputStream ouputStream = response.getOutputStream();
		ouputStream.write(file);
		ouputStream.flush();
		ouputStream.close();
	}
	 */
	

	/**
	 * Setter Method for Witness Facade.
	 * 
	 * @param witnessFacade
	 */
	public void setWitnessFacade(WitnessService witnessFacade) {
		this.witnessFacade = witnessFacade;
	}

	public void setWitnessStatementFacade(
			WitnessStatementService witnessStatementFacade) {
		this.witnessStatementFacade = witnessStatementFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
}
