package uk.nhs.cfsms.ecms.controller;


import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionTO;
import uk.nhs.cfsms.ecms.data.sanction.ChargeList;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CivilSanctionService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;

@Controller
@RequestMapping("/secure/saveCivilSanction.htm")
public class CivilSanctionFormController extends BaseFormController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CivilSanctionService civilSanctionFacade;

	@SuppressWarnings("deprecation")
	public CivilSanctionFormController() {
		
		setSessionForm(true);
		setCommandName("civilSanction");
		setCommandClass(CivilSanctionTO.class);
	}

	/*@Override
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object object, BindException errors)
			throws Exception {*/
	@RequestMapping(method = RequestMethod.POST)
	protected ModelAndView processSubmit(@ModelAttribute("civilSanction") CivilSanctionTO civilSanction,
			                        HttpServletRequest request)
			                        		throws Exception {

		//CivilSanctionTO civilSanction = (CivilSanctionTO) object;

		civilSanction.setCreatedTime(new Date());
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		civilSanction.setCreatedStaffId(user.getStaffId());

		String subjectParam = request.getParameter("subjectParam");
		int index = subjectParam.indexOf("-");
		String subjectId = subjectParam.substring(0, index);
		String subjectType = subjectParam.substring(index + 1, subjectParam
				.length());

		civilSanction.setSubjectType(subjectType);
		civilSanction.setSubjectId(new Long(subjectId));

		if (civilSanction.getCivilSanctionId() == null
				|| civilSanction.getCivilSanctionId() == 0) {

			civilSanction.setState(CaseUtil.ONGOING_SANCTION);

		}
		if (civilSanction.getCivilSanctionId() == null) {
			AuditFlowThread.set("Civil Sanction Created"); 
		} else {
			AuditFlowThread.set("Civil Sanction Updated"); 
		}
		civilSanctionFacade.saveObject(civilSanction);

		createAudit(civilSanction, AuditLogService.CREATE, "Civil Sanction Created", request,
				auditLogFacade);

		return new ModelAndView(new RedirectView("showCivilSanctions.htm"));

	}
	

	public void setCivilSanctionFacade(CivilSanctionService civilSanctionFacade) {
		
		this.civilSanctionFacade = civilSanctionFacade;
	}

	
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		
		this.auditLogFacade = auditLogFacade;
	}
	
	@InitBinder
	protected void initBinder(HttpServletRequest servletRequest,
			ServletRequestDataBinder binder) throws Exception {
 
		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, nf, true));
		binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null,
				new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}

}
