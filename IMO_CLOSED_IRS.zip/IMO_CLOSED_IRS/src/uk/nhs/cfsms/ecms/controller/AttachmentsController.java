package uk.nhs.cfsms.ecms.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.actions.DownloadAction.StreamInfo;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.Attachment;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AttachmentService;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.FileUtils;

import com.itextpdf.text.DocumentException;

@Controller
public class AttachmentsController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private AuditLogService auditLogFacade;

	@Autowired
	private AttachmentService attachmentFacade;

	public ModelAndView removeAttachment(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
 
		ModelAndView mv = new ModelAndView("attachments");

		return mv;
	}
	
	@RequestMapping(value ="/secure/attachments.htm")
	public ModelAndView listAttachment(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String caseId = CaseUtil.getCaseId(request);

		Map<String, Object> attachmentsMap = new HashMap<String, Object>();
		try {

			long caseIDlong = Long.parseLong(caseId);

			@SuppressWarnings("unchecked")
			List<Attachment> attachments = attachmentFacade.listAttachments(caseIDlong);

			attachmentsMap.put("attachmentsSize", attachments.size());
			attachmentsMap.put("attachments", attachments);
			attachmentsMap.put("caseId", caseId);

			return new ModelAndView("attachments", "attachmentsMap", attachmentsMap);
			
		} catch (Exception e) {

			log.error(e.toString() + caseId);
			throw e;
		}

	}

	@RequestMapping(value = "/secure/addAttachments.htm")
	public ModelAndView addAttachments(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		String caseId = CaseUtil.getCaseId(request);

		Long caseID = new Long(caseId);

		String description = request.getParameter("description");

		Attachment attachment = new Attachment();

		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		ServletRequestDataBinder binder = new ServletRequestDataBinder(attachment);
		binder.registerCustomEditor(byte[].class, new ByteArrayMultipartFileEditor());

		MultipartFile multipartFile = multipartRequest.getFile("attachment");
		String fileName = multipartFile.getOriginalFilename();
		String fileExtension = FileUtils.getExtension(multipartFile.getOriginalFilename());
		
		if (StringUtils.isEmpty(fileExtension)) {
			
			log.warn("***User " + user.getStaffId() + "  creating an attachment on " + 	new Date() + " with no file extension!");
		}

		binder.bind(request);

		attachment.setCaseId(caseID);
		attachment.setName(fileName);
		attachment.setCreatedStaffId(user.getStaffId());
		attachment.setDescription(description);
		attachment.setCreatedTime(new Date());
		attachment.setFileType(fileExtension);
		/**
		 * Attachment a =
		 * (Attachment)attachmentFacade.getObject(Attachment.class,
		 * attachment.getId());
		 * 
		 * if (attachment.getAttachment().length == 0) {
		 * attachment.setAttachment(a.getAttachment());
		 * attachment.setFileType(a.getFileType()); }
		 */

		AuditFlowThread.set("Attachment Created");
		attachmentFacade.saveObject(attachment);
		createAudit(attachment, AuditLogService.UPDATE, "Case Attachment",
				request, auditLogFacade);

		@SuppressWarnings("unchecked")
		List<Attachment> attachments = attachmentFacade.listAttachments(attachment.getCaseId());
		
		Map<String, Object> attachmentsMap = new HashMap<String, Object>();
		attachmentsMap.put("attachmentsSize", attachments.size());
		attachmentsMap.put("attachments", attachments);
		attachmentsMap.put("caseId", attachment.getCaseId());

		return new ModelAndView("attachments", "attachmentsMap", attachmentsMap);

	}
	
	@RequestMapping(value ="/secure/viewAttachments.htm")
	public ModelAndView viewAttachments(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String attachmentId = request.getParameter("id");

		Long attachmentIdL = new Long(attachmentId);

		Attachment attachment = (Attachment) attachmentFacade.getObject(
				Attachment.class, attachmentIdL);
		/*
		if (null != a.getFileType()) {				
			response.setContentType(FileUtils.getContentType(a.getFileType()));
		}
		response.setContentLength(a.getAttachment().length);
					
		response.addHeader("Content-Disposition", "attachment; filename=\""
				+ "file." + a.getFileType()==null ? "txt" : a.getFileType() + "\"");
		
		FileCopyUtils.copy(a.getAttachment(), response.getOutputStream());
	 	*/
		try {
			
			if (null == attachment) {
				return listAttachment(request, response);
			}
				
			String fileName = attachment.getName();
			String fileType = attachment.getFileType();
			byte[] attachmentForm = attachment.getAttachment();				
			 			
			String contentType = FileUtils.getContentTypeByFileExt(fileType, "text/csv");
			
			int finalLength = attachmentForm.length;
			if (log.isDebugEnabled()) {
				log.debug("Attachment Length = " + finalLength);
			}
			byte[] finalFile = new byte[finalLength];
			
			if (null == fileType || null == fileName) {

				contentType = FileUtils.getContentTypeByFileName(fileType, "application/pdf");
				
				String path = this.getServletContext().getContextPath();
				
				if (fileName == null) {
					
					fileName = path + "attachment" + attachmentId + ".pdf";
					
				} else if (!fileName.contains(".")) {
					
					String fullName = fileName + ".pdf";
					fileName = fullName;
				}
				finalFile = generatePDF(fileType, fileName, attachmentForm);
				
			} else {
				
				finalFile = new byte[attachmentForm.length];
				
				System.arraycopy(attachmentForm, 0, finalFile, 0, attachmentForm.length);				
			}			
			
			// FileUtils.writeOutputForm(attachmentForm, fileName, contentType, response);			
			FileUtils.writeOutputForm(finalFile, fileName, contentType, response);
			
			//FileUtils.serveDownloadDocument(finalFile,  fileName, response, contentType!=null ?  false : true);
		
		
		} catch (Exception ex) {
			log.error("Exception while getting inputstream for attachments:" + ex.getMessage());
			throw new ServletException(ex);
		}

		return null;
	}

	
	/**
	 * Generate PDF, 
	 * @param fileType
	 * @param fullName
	 * @param attachmentForm
	 * 
	 * @return byte []
	 *  
	 * @throws DocumentException
	 * @throws IOException
	 */
	private byte[] generatePDF(String fileType, String fullName, byte[] attachmentForm) throws DocumentException, IOException {
		
		String content = "";
		
		if (null != attachmentForm) {
			
			content = new String(attachmentForm);
			log.info("\n *** Attachment Content = " + content);
		}
				
		return FileUtils.getPDFDocument(fullName, content);
	}	 

	@RequestMapping(value ="/secure/deleteAttachment.htm")
	public ModelAndView deleteAttachment(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String attachmentId = request.getParameter("id");
		Long attachmentIdL = new Long(attachmentId);

		attachmentFacade.deleteAttachment(attachmentIdL);
		return listAttachment(request, response);
	}

	@RequestMapping(value = "/secure/deleteInfoAttachment.htm")
	public View deleteInfoAttachment(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String attachmentId = request.getParameter("id");
		String infoId = request.getParameter("infoId");
		Long attachmentIdL = new Long(attachmentId);

		attachmentFacade.deleteAttachment(attachmentIdL);
		String contextPath = request.getContextPath();
	    return new RedirectView(contextPath + "/secure/listInfoAttachments.htm?infoId="+infoId);
	}

	@RequestMapping(value = "/secure/listInfoAttachments.htm")
	public ModelAndView listInfoAttachments(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String infoId = request.getParameter("infoId");
		final ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> attachmentsMap = new HashMap<String, Object>();
		try {

			long infoIDlong = Long.parseLong(infoId);

			List<Attachment> attachments = attachmentFacade
					.listInfoAttachments(infoIDlong);

			final String infoAttachmentsJson = getInfoAttachmentsListInJsonFormat(
					mapper, attachments);
			attachmentsMap.put("attachmentsSize", attachments.size());
			attachmentsMap.put("attachments", attachments);
			attachmentsMap.put("infoId", infoId);
			attachmentsMap.put("infoAttachmentsJson", infoAttachmentsJson);

			return new ModelAndView("infoattachments", "attachmentsMap",
					attachmentsMap);

		} catch (Exception e) {

			log.error(e.toString() + infoId);
			throw e;
		}

	}

	@RequestMapping(value = "/secure/addInfoAttachments.htm")
	public View addInfoAttachments(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		String infoId = request.getParameter("infoId");

		String description = request.getParameter("description");

		Long infoID = new Long(infoId);

		Attachment attachment = new Attachment();

		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		ServletRequestDataBinder binder = new ServletRequestDataBinder(
				attachment);
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());

		MultipartFile multipartFile = multipartRequest.getFile("attachment");
		String fileName = multipartFile.getOriginalFilename();
		String fileExtension = FileUtils.getExtension(multipartFile
				.getOriginalFilename());

		if (StringUtils.isEmpty(fileExtension)) {

			log.warn("User " + user.getStaffId()
					+ " has created an attachment on " + new Date()
					+ " with no file extension !");
		}

		binder.bind(request);

		attachment.setInfoId(infoID);
		attachment.setName(fileName);
		attachment.setCreatedStaffId(user.getStaffId());
		attachment.setDescription(description);
		attachment.setCreatedTime(new Date());
		attachment.setFileType(fileExtension);

		attachmentFacade.saveObject(attachment);
		createAudit(attachment, AuditLogService.UPDATE, "Case Attachment",
				request, auditLogFacade);

		String contextPath = request.getContextPath();
	    return new RedirectView(contextPath + "/secure/listInfoAttachments.htm?infoId="+infoId);

	}

	/*
	private void validateAttachment(InformationTO info,
			HttpServletRequest request, BindException errors) {
		//TODO:
	}*/

	protected class ByteArrayStreamInfo implements StreamInfo {

		protected String contentType;

		protected byte[] bytes;

		public ByteArrayStreamInfo(String contentType, byte[] bytes) {
			this.contentType = contentType;
			this.bytes = bytes;
		}

		public String getContentType() {
			return contentType;
		}

		public InputStream getInputStream() throws IOException {
			return new ByteArrayInputStream(bytes);
		}
	}

	/**
	 * Setter method for the Attachment Facade.
	 * 
	 * @param attachmentFacade
	 */
	public void setAttachmentFacade(AttachmentService attachmentFacade) {
		this.attachmentFacade = attachmentFacade;
	}

	/**
	 * Setter method for the Audit Facade.
	 * 
	 * @param auditLogFacade
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	private String getInfoAttachmentsListInJsonFormat(
			final ObjectMapper mapper,
			final List<Attachment> infoAttachmentsList) {
		String infoAttachments = null;
		try {
			infoAttachments = mapper.writeValueAsString(infoAttachmentsList);
		} catch (JsonGenerationException e) {
			logger.error("Got JsonGenerationException while generating Json string from infoAttachmentsList "
					+ ExceptionUtils.getStackTrace(e));
			
		} catch (JsonMappingException e) {
			logger.error("Got JsonMappingException while generating Json string from infoAttachmentsList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {
			logger.error("Got IOException while generating Json string from infoAttachmentsList "
					+ ExceptionUtils.getStackTrace(e));
		}
		return infoAttachments;
	}
}
