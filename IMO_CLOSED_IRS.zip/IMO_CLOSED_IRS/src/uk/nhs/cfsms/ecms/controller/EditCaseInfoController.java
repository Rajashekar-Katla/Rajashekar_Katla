package uk.nhs.cfsms.ecms.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindException;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SourceInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.service.OrganisationService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.InformationUtil;
import uk.nhs.cfsms.ecms.utility.PatientOccupationLookupMap;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

public class EditCaseInfoController extends BaseFormController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private LookupViewService lookupViewFacade;
	@Autowired
	private OrganisationService organisationFacade;
	@Autowired
	private InformationGatherService informationGatherFacade;

	static final String ERROR_PRIMARY_SUBJECT = "ERROR @ SUBJECTS CLASH.";

	private static final String SOURCE_SUBJECT = "_target5";
	private static final String PERSON_SUBJECT = "_target1";
	private static final String ASSOCIATE_SUBJECT = "_target7";

	private static final String CASE_INFO = "CASE_INFORMATION";
	
	public EditCaseInfoController(){
		setSessionForm(true);
		setCommandName("information");
		setCommandClass(InformationTO.class);
		setFormView("editCaseSubjects");
		setSuccessView("editCaseSubjects");
	}

	@Override
	protected Object formBackingObject(HttpServletRequest request)
			throws ServletException {
		if (log.isInfoEnabled()) {
			log.info("formBackingObject");
		}
		InformationTO infoTO = informationGatherFacade.createFraudDetailsTO()
				.getInformationTO();
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		infoTO.setCaseId(new Long(caseID));
		HttpSession session = request.getSession();

		if ((EcmsUtils.onCancel(request) || EcmsUtils.onFinish(request))
					&& session.getAttribute(CASE_INFO) != null) {

			infoTO = (InformationTO) session.getAttribute(CASE_INFO);
			return infoTO;
		}
		try {
			if (isActionToViewInfoOrSubjects(request)
					&& null == infoTO.getInformationId()) {
				infoTO = updateInformationByCaseId(infoTO, caseID, session);
			}
		} catch (NumberFormatException nfe) {
			log.error(nfe);
		} catch (Exception e) {
			log.error(e);
		}
		if (session.getAttribute("orgs") == null) {
			session.setAttribute("orgs", this.getOrganisations(request));
		}
		if (infoTO == null) {
			log.error("ERROR @ DATA PROBLEM @ No Information for caseID="
					+ caseID);
			throw new ServletException("\n A CASE WITH OUT INFORMATION ?");
		}
		return infoTO;
	}

	@Override
	public ModelAndView processFormSubmission(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		if (log.isInfoEnabled()) {
			log.info("processFormSubmission");
		}
		InformationTO info = (InformationTO) command;

		if (EcmsUtils.onCancel(request)) {

			return getCaseListView(info.getCaseId(), request);
		}
		if (onConvertToWitness(request)) {
			
			log.info("@@ onConvertToWitness");
			SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
			String subjectIdToWitness = request.getParameter("subjectId");
			AuditFlowThread.set("Convert Case Subject to Witness");
			informationGatherFacade.updateSubjectToWitness(info, user, subjectIdToWitness);
			createAudit(info, AuditLogService.UPDATE, "Convert Case Subject to Witness", request, auditLogFacade);
			return CaseUtil.getCasePortalView();
		}
		if (EcmsUtils.onFinish(request)) {
			if (log.isInfoEnabled()) {
				log.info("@@ finish");
			}
			validateInformation(info, request, errors);

			if (errors.getErrorCount() < 1) {

				SessionUser user = EcmsUtils.getSessionUserObject(request
						.getSession());
				String curDate = EcmsUtils.getDateToddMMyyyy(new Date(System
						.currentTimeMillis()));

				if (null != info.getNewInformation()
						&& StringUtils.isNotEmpty(info.getNewInformation())) {
					info.setInformationDetails(info.getInformationDetails()
							+ " (Created By: " + user.getFullName() + ", On: "
							+ curDate + ")");
				}
				String otherSource = "";
				if(info.getSourceInformationTO() != null){
				otherSource = info.getSourceInformationTO()
						.getOtherSource();
				}
				if (otherSource != null && !otherSource.trim().equals("")) {
					info.getSourceInformationTO().setSource("");
				}
				AuditFlowThread.set("Case Information Updated");
				informationGatherFacade.saveCaseInformation(info, user);
				createAudit(info, AuditLogService.UPDATE,
						"Case Information Updated", request, auditLogFacade);
				return this.getCaseListView(info.getCaseId(), request);
			}
			else {
				log.error("ERROR count="+ errors.getErrorCount() + ", back with errors");
			}
			return super.processFormSubmission(request, response, command,
					errors);

		} else {
			if (log.isInfoEnabled()) {
				log.info("Saving not finished !!!");
			}
			info = updateInformationByCaseId(info, CaseUtil.getCaseId(request),
					request.getSession());
			return new ModelAndView(this.getFormView(), getCommandName(), info);
		}
	}
	
	/**
	 * Helper method action to view Information or subjects.
	 * @param request
	 * @return boolean
	 * @throws Exception
	 */
	private boolean isActionToViewInfoOrSubjects(HttpServletRequest request)
			throws Exception {

		String action = request.getParameter("actionType");
		if (null != action
				&& (action.equalsIgnoreCase("viewInfo") || action
						.equalsIgnoreCase("viewSubjects"))) {

			return true;
		}
		return false;
	}

	/**
	 * Update Information using caseId
	 * 
	 * @param infoTO
	 * @param caseId
	 * @param session
	 * @return InformationTO
	 * @throws Exception
	 */
	private InformationTO updateInformationByCaseId(InformationTO infoTO,
			String caseId, HttpSession session) throws Exception {
		
		String srcType = "";
		String otherSrc = "";
		InformationTO informationTO = infoTO;
		
		if (log.isDebugEnabled()) {
			log.debug("updating  Information By CaseId =" + caseId);
		}
		informationTO = informationGatherFacade.loadInformationByCaseId(new Long(
				caseId), true);

		setupRegionAndOrganisations(informationTO, session);

		if (infoTO != null) {
            if (infoTO.getSourceInformationTO() != null) {
            	srcType = informationTO.getSourceInformationTO().getSourceType();
            	otherSrc = informationTO.getSourceInformationTO().getOtherSource();
            }
			if ((srcType == null || StringUtils.isEmpty(srcType))
					&& (otherSrc != null && StringUtils.isNotEmpty(otherSrc))) {
				
				informationTO.getSourceInformationTO().setSourceType(
						ECMSConstants.SOURCE_TYPE_OTHER);
			}

			if (!InformationUtil.hasLookupDetails(informationTO)) {
				setupAllLookupDetails(informationTO);
			}
			// Update Source SubType.
			updateSourceLookupDetails(informationTO);
			updateFruadAreaAndTypesLookupDetails(informationTO);
			if (null != informationTO.getSubjectInfoList()) {
				updateSubjectNHSOccupationTypes(informationTO);
			}
			if (!InformationUtil.hasLookupDetails(informationTO)) {
				setupAllLookupDetails(informationTO);
			}
			session.setAttribute(CASE_INFO, informationTO);
		}
		
		return informationTO;
	}

	private void setupRegionAndOrganisations(InformationTO infoTO,
			HttpSession session) {

		List<TeamCodes> teamCodes = null;
		SessionUser sessionUser = EcmsUtils.getSessionUserObject(session);

		List<Organisation> orgCodes = null;

		if (session.getAttribute("teamCodesList") != null) {
			teamCodes = (List) session.getAttribute("teamCodesList");
		}
		if (session.getAttribute("orgCodesList") != null) {
			orgCodes = (List) session.getAttribute("orgCodesList");
		}
		if (null == teamCodes) {
			
			teamCodes = organisationFacade.loadAllTeamCodes();
			infoTO.setTeamCodesList(teamCodes);
			session.setAttribute("teamCodesList", teamCodes);
			
			orgCodes = organisationFacade.loadOrganisationsByOrgName("", sessionUser);
			session.setAttribute("orgCodesList", orgCodes);
		}
	}

	/**
	 * Update Lookup source sub type for a source.
	 * 
	 * @param info
	 */
	private void updateSourceLookupDetails(InformationTO info) throws Exception {

		if (null != info && null != info.getSourceInformationTO()) {

			String groupName = ECMSConstants.LOOKUP_SOURCE ;
			
			info.addInfoLookupViewMap(groupName, getLookupDetails(groupName));
			
			SourceInformationTO srcTO = info.getSourceInformationTO();
			
			if (null != srcTO && StringUtils.isNotEmpty(srcTO.getSource())) {

				LookupView view = lookupViewFacade.loadLookupDetailsById(new Integer(srcTO.getSource()));

				if (null != view) {
					
					srcTO.setSourceType(view.getParentId().toString());
					
					info.addInfoLookupViewMap(ECMSConstants.LOOKUP_SOURCE_SUB_TYPE,
							lookupViewFacade.loadActiveLookupDetailsByParentId(view.getParentId()));
					// Make it static
					info.setStaticInfoLookupViewMap();
				}
			}
	
		}
	}
	
	/**
	 * Update Lookup details for LOOKUP_NHS_FRAUD_AREA, LOOKUP_FRAUD_SUB_AREA_1, 
	 *  LOOKUP_FRAUD_SUB_AREA_2 and LOOKUP_AREA_FRAUD_TYPE
	 * 
	 * @param info	 InformationTO.
	 */
	private void updateFruadAreaAndTypesLookupDetails(InformationTO info) {

		if (null != info) {
			
			String groupName = ECMSConstants.LOOKUP_NHS_FRAUD_AREA ;
			
			info.addInfoLookupViewMap(groupName, getLookupDetails(groupName));
			
			if (StringUtils.isNotEmpty(info.getFraudArea())) {
				
				LookupView view = lookupViewFacade.loadLookupDetailsById(new Integer(info.getFraudArea().trim()));
				
				info.addInfoLookupViewMap(ECMSConstants.LOOKUP_FRAUD_SUB_AREA_1, lookupViewFacade.loadActiveLookupDetailsByParentId(new Integer(info.getAreatype()), view.getGroupId()));
			}
			
			if (StringUtils.isNotEmpty(info.getFraudSubArea())) {
				
				LookupView view = lookupViewFacade.loadLookupDetailsById(new Integer(info.getFraudSubArea().trim()));
				
				info.addInfoLookupViewMap(ECMSConstants.LOOKUP_FRAUD_SUB_AREA_2, lookupViewFacade.loadActiveLookupDetailsByParentId(new Integer(info.getFraudArea()), view.getGroupId()));
			}
			
			if (StringUtils.isNotEmpty(info.getNhsFraudType())) {
				
				LookupView view = lookupViewFacade.loadLookupDetailsById(new Integer(info.getNhsFraudType()));
				
				info.addInfoLookupViewMap(ECMSConstants.LOOKUP_AREA_FRAUD_TYPE, lookupViewFacade.loadActiveLookupDetailsByParentId(new Integer(info.getFraudArea()), view.getGroupId()));
			}
			// Adding dynamic list to the static map.
			info.setStaticInfoLookupViewMap();
		}
		
	}
	
	private void updateSubjectNHSOccupationTypes(InformationTO info) {

		log.info("Updating Subject NHS OccupationTypes");
		
		List<SubjectInformationTO> subjectList = info.getSubjectInfoList();
		
		for (int i=0; i < subjectList.size(); i++) {
			
			SubjectInformationTO subj = subjectList.get(i);
			
			if (null != subj && null != subj.getSubjectPersonTO()) {
				
				PersonTO pTO = subj.getSubjectPersonTO();
				
				if (pTO.isPersonWorkingForNHS() && null != pTO.getNhsOccupationType()) {
					
					LookupView view = lookupViewFacade.loadLookupDetailsById(new Integer(pTO.getNhsOccupationType()));
					info.addDynamicInfoLookupViewMap(ECMSConstants.LOOKUP_OCCUPATION_NHS_TYPE + i, lookupViewFacade.loadActiveLookupDetailsByParentId(new Integer(pTO.getNhsCareerArea()), view.getGroupId()));	
				}
/*				if (pTO.isPersonNHSPatient()) {
					info.addDynamicInfoLookupViewMap(ECMSConstants.LOOKUP_OCCUPATION_PATIENT_TYPE, lookupViewFacade.loadActiveLookupDetailsByGroups(ECMSConstants.LOOKUP_OCCUPATION_PATIENT_TYPE));					
				}
*/			}
		}
	}

	/**
	 * LookupView Details given the group name
	 * 
	 * @param groupName
	 * @return List.
	 */
	private List<LookupView> getLookupDetails(String groupName) {

		if (groupName != null) {
			
			return lookupViewFacade.loadActiveLookupDetailsByGroups(groupName);
		}	
		return null;
	}

	/**
	 * Add new address or contact to Information SOURCE, SUBJECT, ASSOCIATE.
	 * 
	 * @param info
	 *            InformationTO
	 * @param request
	 *            HttpServletRequest
	 */
	private void checkAndAddAddress(InformationTO info, 
			HttpServletRequest request) {

		int index = 0;
		PersonTO pTO = null;

		if (request.getParameter(SOURCE_SUBJECT) != null) {
			
			if (log.isInfoEnabled()) {
				log.info("checkig for add address @ source");
			}
			pTO = info.getSourceInformationTO().getSourcePersonTO();
			updatePersonTO(pTO, request);
		} 
		else if (request.getParameter(PERSON_SUBJECT) != null) {
			
			if (log.isInfoEnabled()) {				
				log.info("checkig for add address @ PERSON_SUBJECT");
			}
			if (request.getParameter("rowIndex") != null) {
				try {
					index = new Integer(request.getParameter("rowIndex"));
				} catch (NumberFormatException nfe) {
					logger.error("ERROR @ PERSON ADDITION TO SUBJECT");
					logger.error(nfe);
				}
				SubjectInformationTO[] subjTO = info.getSubjectInfoList()
						.toArray(
								new SubjectInformationTO[info
										.getSubjectInfoList().size()]);
				updatePersonTO(subjTO[index].getSubjectPersonTO(), request);
			} 
			else {
				for (SubjectInformationTO subjInfo : info.getSubjectInfoList()) {
					pTO = subjInfo.getSubjectPersonTO();
					updatePersonTO(pTO, request);
				}
			}
		} 
		else if (request.getParameter(ASSOCIATE_SUBJECT) != null) {

			if (request.getParameter("rowIndex") != null) {
				try {
					index = new Integer(request.getParameter("rowIndex"));
				} catch (NumberFormatException nfe) {
					logger.error("ERROR @ PERSON ADDITIONS TO ASSOCIATE");
					logger.error(nfe);
				}
				CaseContactTO[] assocTO = info.getCaseAssociates().toArray(
						new CaseContactTO[info.getCaseAssociates().size()]);
				updatePersonTO(assocTO[index].getPersonTO(), request);
			} else {
				for (CaseContactTO associate : info.getCaseAssociates()) {
					pTO = associate.getPersonTO();
					updatePersonTO(pTO, request);
				}
			}
		}
	}

	private void updatePersonTO(PersonTO pTO, HttpServletRequest request) {
		
		if (log.isInfoEnabled()) {
			log.info("update person ..");
		}
		if (pTO != null) {
		
			EcmsUtils.addNewAddressOrContactToPerson(pTO, request);
			
			if (log.isInfoEnabled()) {
				if (null != pTO.getAddressList()) {
					log.info("PERSON Address @.. =" + pTO.getAddressList().size());
				}
				if (null != pTO.getContactsList()) {
					log.info("PERSON Contacts@.. =" + pTO.getContactsList().size());
				}
				if (null != pTO.getAliasList()) {
					log.info("PERSON Alias@.. =" + pTO.getAliasList().size());
				}
			}
		}
	}

	/**
	 * Validate Information.
	 * 
	 * @param info
	 * @param request
	 * @param errors
	 */
	private void validateInformation(InformationTO info,
			HttpServletRequest request, BindException errors) {

		// Validation orgCode in information
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "orgCode",
				"required.orgCode",
				"Please enter mandatory field 'Org Code' for Information.");
	}

	/**
	 * Setup all lookup details for information.
	 * 
	 * @param Information
	 */
	private void setupAllLookupDetails(InformationTO info) {

		String[] lookupGroupNames = InformationUtil.getAllLookupGroups();

		for (String groupName : lookupGroupNames) {
			
			info.addInfoLookupViewMap(groupName, getLookupDetails(groupName));
		}
		info.setStaticInfoLookupViewMap();
		setUpPatientOccupationLookupDetails();
	}
	
	/**
	 * LookupView details for patient occupation
	 * 
	 * @return List.
	 */
	private void setUpPatientOccupationLookupDetails() {
		final List<LookupView> lookupList = lookupViewFacade
				.loadPatientOccupationDescriptions();
		for (LookupView view : lookupList) {
			final String lookupId = String.valueOf(view.getLookupId());
			final String description = view.getDescription();
			final Map<String, String> map = PatientOccupationLookupMap
					.getAllPatientOccupationDetailsLookupMap();
			if (!map.containsKey(lookupId)) {
				map.put(lookupId, description);
			}
		}
	}

	/**
	 * get Organisations.
	 * 
	 * @param request
	 * @return List. List of Organisations
	 */
	private List<Organisation> getOrganisations(HttpServletRequest request) {

		// TODO : provide a valid keyword in future.
		String keyword = "";
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		try {
			if (user != null) {
				return organisationFacade.loadOrganisationsByOrgName(keyword,
						user);
			}
		} catch (Exception e) {
			log.error(e);
		}
		return new ArrayList<Organisation>();
	}

	/**
	 * Check for whether to convert to Witness.
	 * 
	 * @param request
	 * @return
	 */
	private boolean onConvertToWitness(HttpServletRequest request) {
		if (request.getParameter("convertToWitness") != null) {
			return true;
		}
		return false;
	}

	/**
	 * Helper to redirect to new view.
	 * 
	 * @return ModelAndView
	 */
	private ModelAndView getCaseListView(Long caseId, HttpServletRequest request) {

		String caseID = null;
		
		if (null != caseId) {
			caseID = caseId.toString();
		}
		if (StringUtils.isEmpty(caseID)) {
			caseID = CaseUtil.getCurrentCaseInSession(request.getSession());
		}

		return new ModelAndView(new RedirectView(CaseUtil.SHOW_CASE_PAGE
				+ caseID));
	}

	public void setLookupViewFacade(LookupViewService lookupViewFacade) {
		this.lookupViewFacade = lookupViewFacade;
	}

	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public void setOrganisationFacade(OrganisationService organisationFacade) {
		this.organisationFacade = organisationFacade;
	}
}