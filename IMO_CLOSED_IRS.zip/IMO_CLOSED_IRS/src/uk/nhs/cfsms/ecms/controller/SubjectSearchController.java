package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.data.cim.SubjectNhsSearchResults;
import uk.nhs.cfsms.ecms.data.cim.SubjectNonNhsSearchResults;
import uk.nhs.cfsms.ecms.data.cim.SubjectSearchResults;
import uk.nhs.cfsms.ecms.data.cim.VehicleSearchResults;
import uk.nhs.cfsms.ecms.service.SubjectService;
@Controller
public class SubjectSearchController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private SubjectService subjectSearchFacade;

	@RequestMapping(value="/secure/subjectsearchperson.htm")
	public ModelAndView searchSubjectPersons(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map<String, Object> model = new HashMap<String, Object>();

		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");

		if (null == firstName && null == lastName) {
			model.put("subjects", new ArrayList());
			model.put("subjectsSize", "0");
			return new ModelAndView("showSubjectPersonResults", "subjectsMap",
					model);

		}
		if (firstName != null && lastName == null) {
			lastName = "";
		}
		if (lastName != null && firstName == null) {
			firstName = "";
		}

		List<SubjectSearchResults> results = subjectSearchFacade
				.searchPersonSubjects(firstName, lastName);

		model.put("subjects", results);
		model.put("subjectsSize", "0");
		return new ModelAndView("showSubjectPersonResults", "subjectsMap",
				model);

	}
	
	@RequestMapping(value="/secure/subjectsearchnhs.htm")
	public ModelAndView searchSubjectNhs(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map<String, Object> model = new HashMap<String, Object>();

		String orgCode = request.getParameter("orgCode");

		if (null == orgCode) {
			model.put("subjects", new ArrayList());
			model.put("subjectsSize", "0");
			return new ModelAndView("showSubjectNhsResults", "subjectsMap",
					model);

		}

		List<SubjectNhsSearchResults> results = subjectSearchFacade
				.searchNHSSubjects(orgCode);

		model.put("subjects", results);
		model.put("subjectsSize", "0");
		return new ModelAndView("showSubjectNhsResults", "subjectsMap", model);

	}

	@RequestMapping(value="/secure/subjectsearchnonnhs.htm")
	public ModelAndView searchSubjectNonNhs(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map<String, Object> model = new HashMap<String, Object>();

		String companyName = request.getParameter("companyName");

		if (null == companyName) {
			model.put("subjects", new ArrayList());
			model.put("subjectsSize", "0");
			return new ModelAndView("showSubjectNonNhsResults", "subjectsMap",
					model);

		}

		List<SubjectNonNhsSearchResults> results = subjectSearchFacade
				.searchNonNHSSubjects(companyName);

		model.put("subjects", results);
		model.put("subjectsSize", "0");
		return new ModelAndView("showSubjectNonNhsResults", "subjectsMap",
				model);

	}

	@RequestMapping(value="/secure/vehiclesearch.htm")
	public ModelAndView searchVehicle(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map<String, Object> model = new HashMap<String, Object>();

		String licenseNumber = request.getParameter("licenseNumber");

		if (null == licenseNumber) {
			model.put("vehicles", new ArrayList());

			return new ModelAndView("showVehicleResults", "vehiclesMap", model);

		}

		List<VehicleSearchResults> results = subjectSearchFacade
				.searchVehicles(licenseNumber);

		model.put("vehicles", results);

		return new ModelAndView("showVehicleResults", "vehiclesMap", model);

	}
	
	/**
	 * SETTERS for the searchFacade
	 * @param subjectSearchFacade
	 */
	public void setSubjectSearchFacade(SubjectService subjectSearchFacade) {
		this.subjectSearchFacade = subjectSearchFacade;
	}

}
