package uk.nhs.cfsms.ecms.controller;

import java.lang.reflect.InvocationTargetException;


import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.search.ActionSearchTO;
import uk.nhs.cfsms.ecms.dto.search.CaseSearchFormTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.CaseActionBookService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
@Controller
public class FilterSearchController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private CaseService caseFacade;
	@Autowired
	private CaseActionBookService actionService;

	/**
	 * Handle Search Form
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/filterSearchCases.htm")
	public ModelAndView handleFilterSearchForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		logger.info("** handleFilterSearchForm().");

		Map searchFormMap = new HashMap();

		try {

			String searchKeywordsParam = request.getParameter("searchKeywords");
			String searchTypeParam = request.getParameter("searchType");

			if (searchKeywordsParam != null && searchTypeParam != null
					&& searchTypeParam.equalsIgnoreCase("case")) {

				SessionUser user = EcmsUtils.getSessionUserObject(request
						.getSession());
				CaseSearchFormTO sto = new CaseSearchFormTO();

				sto = caseFacade.getCaseSearchResults(sto, user);

				searchFormMap.put("searchResults", sto);

			} else {
				searchFormMap.put("searchResults", new CaseSearchFormTO());
			}

			return new ModelAndView("filterSearchForm", "searchFormMap",
					searchFormMap);

		} catch (NumberFormatException nfe) {
			logger.error(nfe);
			throw nfe;
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
	}
	

	/**
	 * Action method for showing  Action Filter Search
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/filterSearchActions.htm")
	public ModelAndView handleFilterActionForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		
		logger.info("** handleFilterActionForm().");
		Map searchFormMap = new HashMap();
        searchFormMap.put("searchResults", new ActionSearchTO());
		return new ModelAndView("filterActionSearchForm", "searchFormMap",
					searchFormMap);

	
	}
	
	/**
	 * Handles submission of Action Search Form
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/filterActionSearchResults.htm")
	public ModelAndView doActionSearch(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		if (logger.isInfoEnabled()) {
			logger.info("** doActionSearch().");
		}
		String strtDateStr = "";
		String endDateStr = "";
		ActionSearchTO actionTo = null;
		String status = request.getParameter("actionStatus");
		String dateRangeTypeParam = request.getParameter("dateRangeType");
		String caseNumber = request.getParameter("caseNumber");
		String operationName = request.getParameter("operationName");
		
		if (null != dateRangeTypeParam && !dateRangeTypeParam.equalsIgnoreCase("all")) {
			
			strtDateStr = request.getParameter("startDate");
			endDateStr = request.getParameter("endDate");
		}		
		Map<String, Object> caseActionBookMap = new HashMap<String, Object>();;
		
		try {
			
			SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
			
			if (null == request.getParameter("usePreviousCriteria")) {
				
				actionTo = new ActionSearchTO();
				actionTo.setCaseNumber(caseNumber);
				actionTo.setOperationName(operationName);
				
				if (null != dateRangeTypeParam && !dateRangeTypeParam.equalsIgnoreCase("all")) {
					
					if (!StringUtils.isEmpty(strtDateStr)) {
						actionTo.setStartDate(EcmsUtils.parse(strtDateStr));
					}
					if (!StringUtils.isEmpty(endDateStr)) {
						actionTo.setEndDate(EcmsUtils.parse(endDateStr));
					}
					actionTo.setDataRange(true);
				}
				actionTo.setActionStatus(status);
				ActionSearchTO actionSearchCriteria = new ActionSearchTO();
				PropertyUtils.copyProperties(actionSearchCriteria, actionTo);
				request.getSession().setAttribute("actionSearchCriteria", actionSearchCriteria);
				
			} else {
				actionTo = (ActionSearchTO) request.getSession().getAttribute("actionSearchCriteria");
				if(actionTo != null){
					actionTo.getSearchResultsTO().clear();
					actionTo.getSearchResults().clear();
				}

			}
			if(actionTo != null){
			actionTo = actionService.getActionSearchResults(actionTo, user);
			// duplication???
			actionTo.setCaseNumber(caseNumber);
			actionTo.setOperationName(operationName);
			actionTo.setActionStatus(status);
			if (null!= dateRangeTypeParam && !dateRangeTypeParam.equalsIgnoreCase("all")) {
				if (!StringUtils.isEmpty(strtDateStr)) {
					actionTo.setStartDate(EcmsUtils.parse(strtDateStr));
				}
				if (!StringUtils.isEmpty(endDateStr)) {
					actionTo.setEndDate(EcmsUtils.parse(endDateStr));
				}
				actionTo.setDataRange(true);
			}
			caseActionBookMap.put("searchResults", actionTo);}
	        return new ModelAndView("filterActionSearchResults","searchResultsMap",caseActionBookMap);
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		} 
	
	}
	
	/**
	 * Handle SearchResults
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/filterSearchResults.htm")
	public ModelAndView handleFilterSearchResults(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		logger.info("** handleFilterSearchResults().");

		Map searchResultsMap = new HashMap();

		CaseSearchFormTO sto = new CaseSearchFormTO();
		try {
			String statusStr = request.getParameter("status");
			if (StringUtils.isNotEmpty(statusStr)
					&& !statusStr.equalsIgnoreCase("ALL")) {
				if (statusStr.equalsIgnoreCase("OPEN")) {
					sto.setCaseStatus(ECMSConstants.CASE_OPEN);
				} else if (statusStr.equalsIgnoreCase("PENDING")) {
					sto.setCaseStatus(ECMSConstants.CASE_PENDING);
				} else if (statusStr.equalsIgnoreCase("CLOSED")) {
					sto.setCaseStatus(ECMSConstants.CASE_CLOSED);
				} else if (statusStr.equalsIgnoreCase("LCFS-CLOSED")) {
					sto.setCaseStatus(ECMSConstants.CASE_CLOSED);
					sto.setClosedBy(ECMSConstants.LOCAL);
				}else if (statusStr.equalsIgnoreCase("LCFS-PENDING")) {
					sto.setCaseStatus(ECMSConstants.CASE_PENDING);
					sto.setClosedBy(ECMSConstants.LOCAL);
				}else if (statusStr.equalsIgnoreCase("LCFS-OPENED")) {
					sto.setCaseStatus(ECMSConstants.CASE_OPEN);
					sto.setClosedBy(ECMSConstants.LOCAL);
				} else if (statusStr.equalsIgnoreCase("CFS-CLOSED")) {
					sto.setCaseStatus(ECMSConstants.CASE_CLOSED);
					sto.setClosedBy(ECMSConstants.REGIONAL);
				} else if (statusStr.equalsIgnoreCase("CFS-OPENED")) {
					sto.setCaseStatus(ECMSConstants.CASE_OPEN);
					sto.setClosedBy(ECMSConstants.REGIONAL);
				}else if (statusStr.equalsIgnoreCase("CFS-PENDING")) {
					sto.setCaseStatus(ECMSConstants.CASE_PENDING);
					sto.setClosedBy(ECMSConstants.REGIONAL);
				}
			}
			else if (StringUtils.isNotEmpty(statusStr)
					&& statusStr.equalsIgnoreCase("ALL")) {
				sto.setCaseStatus("ALL");
			}
			if (!StringUtils.isEmpty(request.getParameter("caseNumber"))) {
				sto.setCaseNumber(request.getParameter("caseNumber"));
			}
			if (!StringUtils.isEmpty(request.getParameter("operationName"))) {
				sto.setOperationName(request.getParameter("operationName"));
			}

			String dateRangeTypeParam = request.getParameter("dateRangeType");
			
			if (StringUtils.isNotEmpty(dateRangeTypeParam) && !dateRangeTypeParam.equalsIgnoreCase("all")) {
				
				sto.setDateRange(true);
				String strtDateStr = request.getParameter("startDate");
				String endDateStr = request.getParameter("endDate");
				if (!StringUtils.isEmpty(strtDateStr)) {
					sto.setStartDate(EcmsUtils.parse(strtDateStr));
				}
				if (!StringUtils.isEmpty(endDateStr)) {
					sto.setEndDate(EcmsUtils.parse(endDateStr));
				}
				
			} else if(StringUtils.isNotEmpty(dateRangeTypeParam) && dateRangeTypeParam.equalsIgnoreCase("all")){
				
				sto.setDateRange(false);
			}

			String closeDateRangeType = request.getParameter("closeDateRangeType"); 
			if (StringUtils.isNotEmpty(closeDateRangeType) && !closeDateRangeType.equalsIgnoreCase("closeAll")) {
				sto.setCloseDataRange(true);
				sto.setDateRange(true);
				String strtDateStr = request.getParameter("closeStartDate");
				String endDateStr = request.getParameter("closeEndDate");
					if (!StringUtils.isEmpty(strtDateStr)) {
						sto.setStartDate(EcmsUtils.parse(strtDateStr));
					}
					if (!StringUtils.isEmpty(endDateStr)) {
						sto.setEndDate(EcmsUtils.parse(endDateStr));
					}
			} else if(StringUtils.isNotEmpty(closeDateRangeType) && closeDateRangeType.equalsIgnoreCase("closeAll")){
				
				sto.setDateRange(false);
			}
			
			if (sto.getCaseStatus() != null) {
				sto = caseFacade.getCaseSearchResults(sto, EcmsUtils
						.getSessionUserObject(request.getSession()));
				
//				List<CaseObject> list = sto.getSearchResults();
//				if (null != list && !list.isEmpty()) {
//					List<CaseTO> caseList = new ArrayList<CaseTO>();
//					for (CaseObject caseObj: list) {
//						CaseTO caseTO = createCaseTO(caseObj);
//						caseTO.setSubjectNames(caseFacade.loadSubjectsByCaseId(caseObj.getCaseId()));
//						caseList.add(caseTO);
//					}
//					sto.setSearchResultsTO(caseList);
//				}				searchResultsMap.searchResults.searchResultsTO
			}
			
			searchResultsMap.put("searchResults", sto);

			return new ModelAndView("filterSearchResults", "searchResultsMap",
					searchResultsMap);

		} catch (NumberFormatException nfe) {
			logger.error(nfe);
			throw nfe;
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
	}
	
	private CaseTO createCaseTO(Case hibernate) throws ServletException {

		CaseTO caseTO = new CaseTO();
		try {
			BeanUtils.copyProperties(caseTO, hibernate);
		} catch (IllegalAccessException iae) {
			throw new ServletException(iae);
		} catch (IllegalArgumentException iae) {
			throw new ServletException(iae);
		} catch (InvocationTargetException ite) {
			throw new ServletException(ite);
		}
		return caseTO;
	}

	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

	public void setActionService(CaseActionBookService actionService) {
		this.actionService = actionService;
	}
}
