package uk.nhs.cfsms.ecms.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.OrganisationService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

@Controller
public class CaseDetailsChangeController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CaseService caseFacade;
	@Autowired
	private OrganisationService organisationFacade;
	
	@RequestMapping(value ="/secure/changeCasePCT.htm")
	public ModelAndView viewCasePCT(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String caseID = CaseUtil.getCaseId(request);

		CaseTO caseObj = caseFacade.loadCase(new Long(caseID));

		HttpSession session = request.getSession();
		SessionUser sessionUser = EcmsUtils.getSessionUserObject(session);

		List<Organisation> orgCodes = null;

		if (session.getAttribute("orgCodesList") != null) {
			orgCodes = (List) session.getAttribute("orgCodesList");
		} else {
			orgCodes = organisationFacade.loadOrganisationsByOrgName("", sessionUser);
			session.setAttribute("orgCodesList", orgCodes);
		}
		caseObj.setOrgList(orgCodes);
		String restrictTo = caseObj.getRestrictTo();

		if (StringUtils.isNotEmpty(restrictTo)
				&& StringUtils.isNotEmpty(caseObj.getTeamCode())
				&& restrictTo.equalsIgnoreCase(ECMSConstants.LOCAL)) {

			Map<String, List<UserObject>> users = caseFacade
					.loadUsersByTeamCodeAndGroups(caseObj.getTeamCode());
			caseObj.setLcfsList(users.get("LCFS"));
		}

		return new ModelAndView("changePCT", "caseInfo", caseObj);
	}
	
	@RequestMapping(value ="/secure/saveChangeCasePCT.htm")
	public ModelAndView saveChangeCasePCT(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String caseID = CaseUtil.getCaseId(request);
		String newPCT = request.getParameter("newPCT");
		if (StringUtils.isEmpty(newPCT)) {
			logger.error("\n ** NO newPCT selected : " + newPCT);
			throw new Exception("\n ** newPCT is NULL !!!, please select newPCT");
		}
		String removeOldAssignee = request.getParameter("removeOldAssignee");
		String newLCFSAssignee = request.getParameter("newLCFSAssignee");
		boolean removalOfOldAssignee = false;

		// Check for default selection rather than selecting actual LCFS.
		if (null != newLCFSAssignee && newLCFSAssignee.equalsIgnoreCase("lcfs")) {
			newLCFSAssignee = null;
		}
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		if (removeOldAssignee != null) {
			removalOfOldAssignee = true;
		}
		AuditFlowThread.set("Case Health Body Updated");
		caseFacade.saveChangeCasePCT(user.getStaffId(), newPCT,
				removalOfOldAssignee, newLCFSAssignee, new Long(caseID));

		createAudit("Case ID=" + caseID + ", New PCT=" + newPCT
				+ ", New LCFS Assignee" + newLCFSAssignee,
				AuditLogService.UPDATE, "Update Case Health Body", request,
				auditLogFacade);

		return new ModelAndView("changePCTsuccess");
	}

	@RequestMapping(value ="/secure/awaitcase.htm")
	public ModelAndView saveAwaitCase(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Long caseId = new Long(CaseUtil.getCaseId(request));
		CaseTO caseTO = caseFacade.loadCase(caseId);
		
		caseTO.setState(ECMSConstants.CASE_AWAITING);
		caseTO.setAwaitingTime(new Date());
		
		caseFacade.saveOrUpdate(caseTO);
		
		auditLogFacade.save(caseTO.toString(), AuditLogService.UPDATE, 
				EcmsUtils.getSessionUserObject(request.getSession()).getStaffId(), 
				caseId);
	
		return new ModelAndView("casePortal");
	}
	
	@RequestMapping(value ="/secure/reopencase.htm")
	public ModelAndView saveCaseAsOpen(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Long caseId = new Long(CaseUtil.getCaseId(request));
		
		CaseTO caseTO = caseFacade.loadCase(caseId);
		
		String state = ECMSConstants.CASE_OPEN;
		
		if (null != caseTO) {
			
			if( null != caseTO.getReopenedTime()) {
				state = ECMSConstants.CASE_REOPENED;
			}
			caseTO.setState(state);
			
			caseFacade.saveOrUpdate(caseTO);
			
			auditLogFacade.save("Case state back to " + state, AuditLogService.UPDATE, 
					EcmsUtils.getSessionUserObject(request.getSession()).getStaffId(), 
					caseId);
		}
		
		return new ModelAndView("casePortal");
	}
	
	/**
	 * Setters for the Facade layer...
	 * 
	 * @param auditLogFacade
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

	public void setOrganisationFacade(OrganisationService organisationFacade) {
		this.organisationFacade = organisationFacade;
	}

}
