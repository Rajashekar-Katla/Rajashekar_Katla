package uk.nhs.cfsms.ecms.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.cim.CaseTransfer;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTransferTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseTransferService;
import uk.nhs.cfsms.ecms.service.MessageService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * Controller to deal with case transfers between LCFS to LCFS and to AFS/CFS.
 * Introduced OFM/AAFS/AFL approving the transfer before transferring the case
 * to other team.
 * 
 */
@Controller
@RequestMapping("/secure/createtransfer.htm")
public class TransferFormController extends BaseFormController {

	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private MessageService messageFacade;
	@Autowired
	private CaseTransferService caseTransferFacade;

	static final String CFS_TRANSFER_PAGE = "casecfstransfers.htm";

	static final String LCFS_TRANSFER_PAGE = "caselcfstransfers.htm";

	static final String CANCEL_TRANSFER_PAGE = "showtransferlinks.htm?dispatch=query";

	static final String RECEIVED_LCFS_TRANSFER = "receivedlcfstransferlist.htm";

	static final String RECEIVED_CFS_TRANSFER = "receivedcfstransferlist.htm";

	static final String CREATED_LCFS_TRANSFER = "createdlcfstransferlist.htm";

	static final String CREATED_CFS_TRANSFER = "createdcfstransferlist.htm";

	static final String PENDING_LCFS_TRANSFER = "pendinglcfstransferlist.htm";

	static final String PENDING_CFS_TRANSFER = "pendingcfstransferlist.htm";

	static final String CASE_CFS_TRANSFER = "casecfstransfers.htm";

	static final String CASE_LCFS_TRANSFER = "caselcfstransfers.htm";

	protected final Log log = LogFactory.getLog(getClass());

	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView formBackingObject(
			@ModelAttribute(value = "transferObject") CaseTransferTO transferTO,
			HttpServletRequest request, Model model) throws Exception {

		if (logger.isInfoEnabled()) {
			logger.info("formBackingObject().");
		}

		String caseID = null;
		String transferID = null;

		Long transferId = transferTO.getCaseTransferId();
		// duplicate checking for various forms. 
		if (transferId == null) {

			transferID = request.getParameter("transferId");

			if (StringUtils.isNotEmpty(transferID)) {
				transferId = new Long(transferID);
			}
		}

		if (transferId == null && transferID == null) {
			try {
				caseID = CaseUtil.getCaseId(request);
				// TODO-please revisit this block of code.-venkat
			} catch (Exception e) {
				transferTO = new CaseTransferTO();
				model.addAttribute("transferObject", transferTO);
				return new ModelAndView("casetransferdetails");
			}
		}
		String transferType = request.getParameter("transferType");

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		transferTO = loadCaseTransfer(transferId, caseID, transferType, user);

		model.addAttribute("transferObject", transferTO);

		return new ModelAndView("casetransferdetails");
	}

	@RequestMapping(method = RequestMethod.POST)
	public ModelAndView onSubmit(
			@ModelAttribute(value = "transferObject") CaseTransferTO transferTO,
			HttpServletRequest request, HttpServletResponse response,
			Model model) throws Exception {

		if (logger.isInfoEnabled()) {
			logger.info("** onSubmit().");
		}
		String caseID = CaseUtil.getCaseId(request);

		if (StringUtils.isNotEmpty(caseID)) {
			Case caseObj = new Case();
			caseObj.setCaseId(new Long(caseID));
			transferTO.setCaseObject(caseObj);
		}

		log.debug("\n\n *** CaseTransferTO=" + transferTO.toString());

		if (EcmsUtils.onSave(request)) {

			if (logger.isInfoEnabled()) {

				logger.info("Saving transfers.");
			}
			if (!hasTransferPendingState(transferTO)) {

				if (!isCFSTransfer(transferTO)) {

					saveTransfer(transferTO, request);
					createCaseTransferMessage(transferTO, request);

				} else {
					if (log.isInfoEnabled()) {
						log.info("Referring case to the user rather than Approval pending");
					}
					saveCFSTransfer(transferTO, request);
					// Commented for new CFS transfer implementations
					//referTransfer(transferTO, request); 
				}
			} else {
				return new ModelAndView("pendingtransfermessage");
			}
			if (null != transferTO.getCaseTransferId()) {

				return saveReturnView(transferTO);
			}
		}
		// Display Form View
		if (EcmsUtils.onView(request)) {

			log.info("\n POST, onView...");
			model.addAttribute("transferObject", transferTO);

			return new ModelAndView("casetransferdetails");
		}
		// Update Transfer 
		if (EcmsUtils.onUpdate(request)) {

			log.info("\n POST, onUpdate.");
			updateTransfer(transferTO, request);

			return updateAndCancelAndReferReturnView(transferTO, request);
		}

		// Refer Transfer
		if (EcmsUtils.onRefer(request)) {

			log.info("\n POST, onRefer.");
			referTransfer(transferTO, request);

			if (isCFSTransfer(transferTO)) {

				boolean isNotified = createCFSTransferNotification(
						"TransferRecipient", transferTO, request);

				if (logger.isDebugEnabled()) {

					logger.debug((!isNotified ? "FAILED " : "")
							+ "CFS Transfer notification for Target OFM user, transferId="
							+ transferTO.getCaseTransferId());
				}
			}
			return updateAndCancelAndReferReturnView(transferTO, request);
		}

		if (EcmsUtils.onAccept(request)) {

			acceptTransfer(transferTO,
					EcmsUtils.getSessionUserObject(request.getSession()),
					request);

			return acceptAndRejectReturnView(transferTO, request);
		}

		if (EcmsUtils.onReject(request)) {

			rejectTransfer(transferTO, request);

			return acceptAndRejectReturnView(transferTO, request);
		}

		if (EcmsUtils.onCancelTransfer(request)) {

			cancelTransfer(transferTO, request);

			if (isCFSTransfer(transferTO)) {

				boolean isNotified = createCFSTransferNotification(
						"TransferInitiator", transferTO, request);
				if (logger.isInfoEnabled()) {
					logger.info((!isNotified ? "FAILED " : "")
							+ "CFS Transfer Approval Rejection notification to initiator, transferId="
							+ transferTO.getCaseTransferId());
				}
			}
			return updateAndCancelAndReferReturnView(transferTO, request);
		}

		if (EcmsUtils.onCancelPage(request)) {

			return cancelPageReturnView(transferTO, request);
		}

		// Added to support and moved one step forward.
		if (hasTransferPendingState(transferTO)) {

			return new ModelAndView("pendingtransfermessage");
		}

		model.addAttribute("transferObject", transferTO);

		return new ModelAndView("casetransferdetails");

	}

	private void createCaseTransferMessage(CaseTransferTO transferTO,
			HttpServletRequest request) throws Exception {

		Long caseId = null;
		try {
			if (null != transferTO.getCaseObject()) {

				caseId = transferTO.getCaseObject().getCaseId();

			} else {

				caseId = new Long(CaseUtil.getCaseId(request));
			}
			SessionUser user = EcmsUtils.getSessionUserObject(request
					.getSession());
			String message = (null == transferTO.getTransferComment() ? transferTO
					.getState() : transferTO.getTransferComment());
			String teamCode = transferTO.getRecipientTeamCode();

			MessageTO messageTO = new MessageTO();
			messageTO.setMessage(message);
			messageTO.setCaseId(caseId);
			messageTO.setCaseRef(transferTO.getCaseTransferId().toString());
			messageTO.setMessageType(MessageTO.Message_types.CASE_TRANSFER
					.toString());
			messageTO.setCreatedStaffId(user.getStaffId());
			messageTO.setFromStaffId(user.getStaffId());
			messageTO.setFromStaffName(user.getFullName());
			messageTO.setCreatedTime(new Date());

			UserObject ofmObj = messageFacade.loadOFMByTeamOrOrgCode(teamCode,
					false);

			if (logger.isDebugEnabled()) {

				logger.debug("OFM user = " + ofmObj.getStaffId()
						+ ", Current user =" + user.getStaffId()
						+ ", Transfer TYpe=" + transferTO.getTransferType());
			}

			if (IsReceipientLcfs(transferTO, user, ofmObj)) {

				if (logger.isInfoEnabled()) {
					logger.info("OFM or LCFS messaging to LCFS for LCFS case transfer.");
				}
				messageTO.setToStaffId(transferTO.getReceipentLcfs());
				UserObject toUser = messageFacade.loadUserByUserId(transferTO
						.getReceipentLcfs());
				messageTO.setToStaffId(toUser.getStaffId());
				messageTO.setToStaffName(EcmsUtils.getFullName(toUser));
			} else {
				messageTO.setToStaffId(ofmObj.getStaffId());
				messageTO.setToStaffName(EcmsUtils.getFullName(ofmObj));

				if (logger.isInfoEnabled()) {
					logger.info("Messaging to OFM for case transfer.");
				}
			}
			messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
			AuditFlowThread.set("Message Created");
			messageTO = messageFacade.saveMessage(messageTO);
			createAudit(messageTO, AuditLogService.UPDATE, "Adding Message",
					request, auditLogFacade);

		} catch (Exception e) {
			log.error("ERROR saving messages / audit while transferring " + e);
			throw new ServletException(e);
		}
	}

	/**
	 * @param transferTO
	 * @param user
	 * @param ofmObj
	 * @return
	 */
	private boolean IsReceipientLcfs(CaseTransferTO transferTO,
			SessionUser user, UserObject ofmObj) {
		return (null != ofmObj && ofmObj.getStaffId().equals(user.getStaffId())
				|| (user.isUserLCFS() && null != transferTO.getReceipentLcfs()) || (user
				.isUserIMO() && (null != ofmObj && !ofmObj.getStaffId().equals(
				user.getStaffId()))))
				&& transferTO.getTransferType().equals(
						ECMSConstants.TRANSFER_LCFS);
	}

	@Override
	protected void initBinder(HttpServletRequest request,
			ServletRequestDataBinder binder) throws Exception {

		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null,
				new SqlDateEditor(false));
	}

	private CaseTransferTO loadCaseTransfer(Long transferId, String caseId,
			String transferType, SessionUser user) throws ServletException {

		CaseTransferTO caseTransferTO = null;

		try {
			if (transferId != null) {
				caseTransferTO = caseTransferFacade
						.loadCaseTransfersById(transferId);
			}
			if (StringUtils.isNotEmpty(caseId)) {

				if (null == caseTransferTO) {
					caseTransferTO = new CaseTransferTO();
				}
				caseTransferTO.setCaseObject(caseTransferFacade
						.loadCaseByCaseId(new Long(caseId)));
				caseTransferTO.setTransferType(transferType);
				caseTransferTO.setState(ECMSConstants.TRANSFER_NEW);
			}
			if (isLcfsTransfer(caseTransferTO)) {
				if (null == caseTransferTO.getCaseObject()
						|| caseTransferTO.getCaseObject().getTeamCode() == null) {
					String error = "NO TEAM CODE, for case=" + caseId;
					logger.error(error);
					throw new ServletException(error);
				}
				caseTransferTO.setLcfsList(caseTransferFacade
						.loadLcfsUsers(caseTransferTO.getCaseObject()
								.getTeamCode()));

			} else if (isCFSTransfer(caseTransferTO)) {

				caseTransferTO.setTeamList(caseTransferFacade.loadTeams());
			} else {
				caseTransferTO.setLcfsList(caseTransferFacade
						.loadLcfsUsers(caseTransferTO.getCaseObject()
								.getTeamCode()));
				caseTransferTO.setTeamList(caseTransferFacade.loadTeams());
			}
			if (log.isDebugEnabled()) {
				log.debug("caseTransferTO :"
						+ (null != caseTransferTO ? caseTransferTO.toString()
								: "NULL"));
			}
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e.getMessage());
		}

		return caseTransferTO;
	}

	private boolean isLcfsTransfer(CaseTransferTO caseTransferTo) {

		String transfer = caseTransferTo.getTransferType();

		if (transfer != null
				&& transfer.equalsIgnoreCase(ECMSConstants.TRANSFER_LCFS)) {
			return true;
		}
		return false;
	}

	private boolean isCFSTransfer(CaseTransferTO caseTransferTo) {

		String transfer = caseTransferTo.getTransferType();

		if (transfer != null
				&& transfer.equalsIgnoreCase(ECMSConstants.TRANSFER_CFS)) {

			return true;
		}
		return false;
	}

	private void saveTransfer(CaseTransferTO caseTransferTO,
			HttpServletRequest request) throws ServletException {

		try {
			SessionUser user = EcmsUtils.getSessionUserObject(request
					.getSession());
			caseTransferTO.setCreatedStaffId(user.getStaffId());
			caseTransferTO.setCreatedTime(new Date());
			// If OFM/AAFS/AFL/Director creating transfer then set state referred
			// Missing one - LCFS referred case to another LCFS. 
			if (user.isUserMangerAndAbove()
					|| (user.isUserLCFS() && null != caseTransferTO
							.getReceipentLcfs())) {

				caseTransferTO.setState(ECMSConstants.TRANSFER_REFERRED);
				caseTransferTO.setTransferTime(new Date());

			} else {

				caseTransferTO
						.setState(ECMSConstants.TRANSFER_APPROVAL_PENDING);
			}
			AuditFlowThread.set("Case Transfer Created");
			caseTransferFacade.saveCaseTransfer(caseTransferTO);
			createAudit(caseTransferTO, AuditLogService.CREATE,
					"Case Transfer", request, auditLogFacade);

		} catch (Exception e) {
			log.error("ERROR saving messages / audit while transferring " + e);
			throw new ServletException(e);
		}

	}

	private void referTransfer(CaseTransferTO caseTransferTO,
			HttpServletRequest request) throws ServletException {

		String auditMessage = "Case Transfer referred";
		caseTransferTO.setState(ECMSConstants.TRANSFER_REFERRED);
		caseTransferTO.setTransferTime(new Date());

		// Changes for CFS transfer
		try {

			if (isCFSTransfer(caseTransferTO)) {

				caseTransferTO
						.setTransferApprovalStatus(ECMSConstants.TRANSFER_LEAD_APPROVAL_APPROVED);
				caseTransferTO.setTransferApprovalTime(Calendar.getInstance()
						.getTime());
				caseTransferTO
						.setTransferApproverComments("CFS TRANSFER APPROVED.");

				auditMessage = "CFS Case Transfer ID : ["
						+ caseTransferTO.getCaseTransferId()
						+ " ] referred by Approver : ["
						+ caseTransferTO.getCfsTransferApproverStaffID() + "]";
			}
			caseTransferFacade.updateCaseTransfer(caseTransferTO);
			createAudit(caseTransferTO, AuditLogService.UPDATE, auditMessage,
					request, auditLogFacade);

		} catch (Exception e) {

			log.error("Exception in refer Tranfer" + e);
			throw new ServletException(e);
		}
	}

	private void updateTransfer(CaseTransferTO caseTransferTO,
			HttpServletRequest request) throws ServletException {

		try {
			caseTransferFacade.updateCaseTransfer(caseTransferTO);
			createAudit(caseTransferTO, AuditLogService.UPDATE,
					"Update Case Transfer", request, auditLogFacade);

		} catch (Exception e) {

			log.error("Exception in update Tranfer" + e);
			throw new ServletException(e);
		}
	}

	private void acceptTransfer(CaseTransferTO caseTransferTO,
			SessionUser user, HttpServletRequest request)
			throws ServletException {

		try {
			caseTransferTO.setAcceptedTime(new Date());
			caseTransferTO.setState(ECMSConstants.TRANSFER_ACCEPTED);
			caseTransferFacade.saveAcceptCaseTransfer(caseTransferTO, user);
			AuditFlowThread.set("Accept Case Transfer");
			createAudit(caseTransferTO, AuditLogService.UPDATE,
					"Accept Case Transfer", request, auditLogFacade);

		} catch (Exception e) {

			log.error("Exception in update Tranfer" + e);
			throw new ServletException(e);
		}
	}

	private void rejectTransfer(CaseTransferTO caseTransferTO,
			HttpServletRequest request) throws ServletException {

		try {
			String auditMessage = "Reject Case Transfer";
			caseTransferTO.setRejectedTime(Calendar.getInstance().getTime());
			caseTransferTO.setState(ECMSConstants.TRANSFER_REJECTED);
			AuditFlowThread.set(auditMessage);
			caseTransferFacade.updateCaseTransfer(caseTransferTO);
			createAudit(caseTransferTO, AuditLogService.UPDATE, auditMessage,
					request, auditLogFacade);

		} catch (Exception e) {

			log.error("Exception in update Tranfer" + e);
			throw new ServletException(e);
		}
	}

	private void cancelTransfer(CaseTransferTO caseTransferTO,
			HttpServletRequest request) throws ServletException {

		String auditMessage = "Cancel Case Transfer";
		caseTransferTO.setCancelledTime(new Date());
		caseTransferTO.setState(ECMSConstants.TRANSFER_CANCELLED);
		// Changes for CFS transfer

		try {
			if (isCFSTransfer(caseTransferTO)) {
				caseTransferTO
						.setTransferApprovalStatus(ECMSConstants.TRANSFER_LEAD_APPROVAL_REJECTED);
				caseTransferTO.setTransferApprovalTime(Calendar.getInstance()
						.getTime());
				caseTransferTO
						.setTransferApproverComments("CFS TRANSFER REJECTED."
								+ caseTransferTO.getTransferComment());
				auditMessage = "REJECTED CFS Case Trans ID : ["
						+ caseTransferTO.getCaseTransferId()
						+ " ] rejected by Approver : ["
						+ caseTransferTO.getCfsTransferApproverStaffID() + "]";
			}
			AuditFlowThread.set("Cancel Case Transfer");
			caseTransferFacade.updateCaseTransfer(caseTransferTO);
			createAudit(caseTransferTO, AuditLogService.UPDATE, auditMessage,
					request, auditLogFacade);

		} catch (Exception e) {

			log.error("Exception in update Tranfer" + e);
			throw new ServletException(e);
		}
	}

	/*
	public void viewTransfer(CaseTransferTO transferTO) throws ServletException {
		
		try {
			transferTO = caseTransferFacade.loadCaseTransfersById(transferTO
				.getCaseTransferId());
		}catch(Exception e) {
			
			log.error("Exception in Loading Case Tranfer" + e);
			throw new ServletException(e);
		}
	}
	*/

	private boolean hasTransferPendingState(CaseTransferTO transferTO)
			throws Exception {

		if (transferTO.getCaseObject() == null
				|| transferTO.getCaseObject().getCaseId() == null) {
			throw new CaseIDNotFoundException();
		}
		try {
			List<CaseTransfer> list = caseTransferFacade
					.loadPendingTransfersByCaseId(transferTO.getCaseObject()
							.getCaseId());

			if (null != list && !list.isEmpty()) {

				return true;
			}
		} catch (Exception e) {

			log.error("Exception Pending Transfers :" + e);
			throw new ServletException(e);
		}
		return false;
	}

	private ModelAndView saveReturnView(CaseTransferTO transferTO) {

		if (null != transferTO) {

			String type = transferTO.getTransferType();

			if (null != type
					&& type.equalsIgnoreCase(ECMSConstants.TRANSFER_CFS)) {

				return new ModelAndView(new RedirectView(CFS_TRANSFER_PAGE));
			} else {

				return new ModelAndView(new RedirectView(LCFS_TRANSFER_PAGE));
			}
		}

		return new ModelAndView(new RedirectView(LCFS_TRANSFER_PAGE));
	}

	private ModelAndView isFromCaseLink(CaseTransferTO transferTO) {

		if (isCFSTransfer(transferTO)) {

			return new ModelAndView(new RedirectView(CASE_CFS_TRANSFER));
		} else {

			return new ModelAndView(new RedirectView(CASE_LCFS_TRANSFER));
		}
	}

	private ModelAndView updateAndCancelAndReferReturnView(
			CaseTransferTO transferTO, HttpServletRequest request) {

		if (CaseUtil.getCurrentCaseInSession(request.getSession()) != null) {

			return isFromCaseLink(transferTO);
		} else {

			if (isCFSTransfer(transferTO)) {

				return new ModelAndView(new RedirectView(CREATED_CFS_TRANSFER));
			} else {

				return new ModelAndView(new RedirectView(CREATED_LCFS_TRANSFER));
			}
		}
	}

	private ModelAndView acceptAndRejectReturnView(CaseTransferTO transferTO,
			HttpServletRequest request) {

		if (null != CaseUtil.getCurrentCaseInSession(request.getSession())) {

			return isFromCaseLink(transferTO);

		} else {

			if (isCFSTransfer(transferTO)) {

				return new ModelAndView(new RedirectView(RECEIVED_CFS_TRANSFER));
			}

			return new ModelAndView(new RedirectView(RECEIVED_LCFS_TRANSFER));
		}
	}

	private ModelAndView cancelPageReturnView(CaseTransferTO transferTO,
			HttpServletRequest request) {

		if (CaseUtil.getCurrentCaseInSession(request.getSession()) != null) {
			return isFromCaseLink(transferTO);
		}

		return new ModelAndView(new RedirectView(CANCEL_TRANSFER_PAGE));

	}

	/**
	 * Setter for case transfer facade
	 * 
	 * @param caseTransferFacade
	 */
	public void setCaseTransferFacade(CaseTransferService caseTransferFacade) {

		this.caseTransferFacade = caseTransferFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {

		this.auditLogFacade = auditLogFacade;
	}

	public void setMessageFacade(MessageService messageFacade) {

		this.messageFacade = messageFacade;
	}

	/**
	 * Changes for the CFS transfer modifications. STARTS
	 *
	 * If the user is OFM/AFL/Director he will directly initiate the transfer,
	 * assuming the self approved (Approval status = A). for other user like
	 * AFS/CFS/LCFS case transfers will be initiated in approval pending state
	 * (Approval status = P) a notification for the lead user will be trigger
	 * who will either approve (Approval status = A) or reject (Approval status
	 * = R) the transfer. end user OFM will be notified on Manager's approval
	 * for the transfer which he can accept or reject as usual. There will not
	 * be any further notification mechanism as off now. Can be introduced later
	 * as per requirements.
	 * 
	 * This method is responsible for handling the CFS transfers initiated in
	 * the system.
	 * 
	 * @throws Exception
	 * 
	 * */
	private void saveCFSTransfer(CaseTransferTO caseTransferTO,
			HttpServletRequest request) throws Exception {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		caseTransferTO.setCreatedStaffId(user.getStaffId());
		caseTransferTO.setCreatedTime(Calendar.getInstance().getTime());

		if (user.isUserAntiFraudSpecialist()
				|| user.isUserAntiFraudSpecialistSupport()
				|| user.isUserAntiFraudLead() || user.isUserOFM()
				|| user.isUserDirector()) {

			//  Transfer is updated as referred
			caseTransferTO.setState(ECMSConstants.TRANSFER_REFERRED);
			caseTransferTO.setTransferTime(Calendar.getInstance().getTime());

			// Transfer request is updated as default updated for OFM/AFL.
			caseTransferTO.setCfsTransferApproverStaffID(user.getStaffId());
			caseTransferTO
					.setTransferApprovalStatus(ECMSConstants.TRANSFER_LEAD_APPROVAL_APPROVED);
			caseTransferTO.setTransferApprovalTime(Calendar.getInstance()
					.getTime());
			caseTransferTO
					.setTransferApproverComments("CFS TRANSFER APPROVED.");

		} else {

			caseTransferTO.setState(ECMSConstants.TRANSFER_APPROVAL_PENDING);

			// Transfer request is updated as default updated for OFM/AFL.			
			caseTransferTO.setCfsTransferApproverStaffID(fetchApproverStaffId(
					caseTransferTO, user));
			caseTransferTO
					.setTransferApprovalStatus(ECMSConstants.TRANSFER_LEAD_APPROVAL_PENDING);
		}
		AuditFlowThread.set("Case Transfer Request Created");
		caseTransferTO = caseTransferFacade.saveCaseTransfer(caseTransferTO);
		createAudit(caseTransferTO, AuditLogService.CREATE,
				"Case Transfer Request Created", request, auditLogFacade);

		if (StringUtils.isNotEmpty(caseTransferTO
				.getCfsTransferApproverStaffID())
				&& ECMSConstants.TRANSFER_LEAD_APPROVAL_PENDING
						.equalsIgnoreCase(caseTransferTO
								.getTransferApprovalStatus())) {

			boolean isNotified = createCFSTransferNotification(
					"TransferApprover", caseTransferTO, request);

			if (logger.isDebugEnabled()) {
				logger.debug((!isNotified ? "Failed " : "")
						+ "CFS Transfer notification for Approver creation, transferId: "
						+ caseTransferTO.getCaseTransferId());
			}

		} else if (ECMSConstants.TRANSFER_LEAD_APPROVAL_APPROVED
				.equalsIgnoreCase(caseTransferTO.getTransferApprovalStatus())) {

			boolean isNotified = createCFSTransferNotification(
					"TransferRecipient", caseTransferTO, request);

			if (logger.isDebugEnabled()) {
				logger.debug((!isNotified ? "Failed " : "")
						+ "CFS Transfer notification for Target user OFM, transferId: "
						+ caseTransferTO.getCaseTransferId());
			}
		}
	}

	/**
	 * Triggering notification for the transfer to the end user.
	 * 
	 **/
	private boolean createCFSTransferNotification(String toUser,
			CaseTransferTO transferTO, HttpServletRequest request)
			throws Exception {

		UserObject ofmObj = null;
		boolean isOFMPresent = false;
		long caseID;
		String auditMessage = "Creating Tranfer notification message";

		try {
			if (null != transferTO.getCaseObject()) {

				caseID = transferTO.getCaseObject().getCaseId();
			} else {

				caseID = new Long(CaseUtil.getCaseId(request));
			}

			String message = (null == transferTO.getTransferComment() ? transferTO
					.getState() : transferTO.getTransferComment());

			MessageTO messageTO = new MessageTO();
			messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
			messageTO.setMessage(message);
			messageTO.setCaseId(caseID);
			messageTO.setCaseRef(transferTO.getCaseTransferId().toString());
			messageTO.setCreatedTime(Calendar.getInstance().getTime());

			SessionUser user = EcmsUtils.getSessionUserObject(request
					.getSession());
			messageTO.setCreatedStaffId(user.getStaffId());
			messageTO.setFromStaffId(user.getStaffId());
			messageTO.setFromStaffName(user.getFullName());

			if (StringUtils.equalsIgnoreCase(toUser, "TransferApprover")) {

				messageTO
						.setMessageType(MessageTO.Message_types.CFS_TRANSFER_APPROVAL_REQUEST
								.toString());

				// Fetching the user object for the aligned CFS Transfer Approver.

				ofmObj = messageFacade.loadUserByUserId(transferTO
						.getCfsTransferApproverStaffID());

				if (logger.isDebugEnabled()) {

					logger.debug("Approver user = " + ofmObj.getStaffId());
				}
				auditMessage = "CFS CASE Transfer Approved request Message, Approver user [ "
						+ ofmObj.getStaffId() + " ]";

			} else if (StringUtils
					.equalsIgnoreCase(toUser, "TransferRecipient")) {

				messageTO.setMessageType(MessageTO.Message_types.CASE_TRANSFER
						.toString());

				// Fetching the user object for the aligned CFS Transfer Approver.

				ofmObj = messageFacade.loadOFMByTeamOrOrgCode(
						transferTO.getRecipientTeamCode(), false);

				if (logger.isDebugEnabled()) {

					logger.debug("Recipient user [ " + ofmObj.getStaffId()
							+ " ]");
				}
				auditMessage = "CFS CASE Transfer Approved request Message, Recipient user [ "
						+ ofmObj.getStaffId() + " ]";

			} else if (StringUtils
					.equalsIgnoreCase(toUser, "TransferInitiator")) {

				messageTO
						.setMessageType(MessageTO.Message_types.CFS_TRANSFER_APPROVAL_DECLINED
								.toString());
				// Fetching the user object for the aligned CFS Transfer Approver.

				ofmObj = messageFacade.loadUserByUserId(transferTO
						.getCreatedStaffId());

				if (logger.isDebugEnabled()) {

					logger.debug("Recipient user [ " + ofmObj.getStaffId()
							+ " ]");
				}
				auditMessage = "CFS CASE Transfer Rejection Notification Message, Recipient user [ "
						+ ofmObj.getStaffId() + " ]";
			}
			// Additional Audit Message...
			auditMessage = auditMessage + ", Current user [ "
					+ user.getStaffId() + " ], Transfer Type ["
					+ transferTO.getTransferType() + " ]";

			if (logger.isDebugEnabled()) {

				logger.debug("Current user=" + user.getStaffId()
						+ ", Transfer Type=" + transferTO.getTransferType());
				logger.debug((null == ofmObj ? "Failed " : "")
						+ " messaging to OFM for case transfer Id="
						+ transferTO.getCaseTransferId());
			}

			// Setting the approver staff id to trigger the message.
			if (null != ofmObj) {

				isOFMPresent = true;

				messageTO.setToStaffId(ofmObj.getStaffId());
				messageTO.setToStaffName(EcmsUtils.getFullName(ofmObj));
				AuditFlowThread.set("Message Created");
				messageTO = messageFacade.saveMessage(messageTO);
				createAudit(messageTO, AuditLogService.UPDATE, auditMessage,
						request, auditLogFacade);
			}
		} catch (Exception e) {
			log.error("Exception saving transfer Message / Audit");
			throw new ServletException(e);
		}
		return isOFMPresent;
	}

	/**
	 * Fetching the approver (AFL/AAFS/OFM) details
	 * 
	 */
	private String fetchApproverStaffId(CaseTransferTO transferTO,
			SessionUser user) throws ServiceException {

		UserObject ofmObj = null;

		String staffId = "";

		if (null != user
				&& (user.isUserLCFS() || user.isUserAntiFraudSpecialist() || user
						.isUserCFS())) {

			if (logger.isDebugEnabled()) {

				logger.debug("User group :"
						+ (user.isNITAFL() ? "NIS" : "NON-NIS") + ",staffId=["
						+ user.getStaffId() + "]");
			}

			if (user.isNITAFL()) {

				ofmObj = messageFacade.loadAFLByTeamCode(user
						.getEmployerOrgCode());
			} else {

				ofmObj = messageFacade.loadOFMByTeamOrOrgCode(
						user.getEmployerOrgCode(), true);
			}

			staffId = (null != ofmObj ? ofmObj.getStaffId() : "");
		}
		if (logger.isInfoEnabled()) {

			logger.info("Approver AFL/OFM StaffId = " + staffId);
		}

		return staffId;
	}

}
