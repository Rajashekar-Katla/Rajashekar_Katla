package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.sanction.AppealOutcome;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.dto.criminalsanction.AppealOutcomeTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalAppealTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SanctionApplied;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CriminalAppealService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.ConvertToDTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;


@Controller
public class CriminalAppealOutcomeFormController extends BaseBinderConfig {

	@Autowired
	private AuditLogService auditLogFacade;
	
	@Autowired
	private CriminalAppealService criminalAppealFacade;
	   

	protected final Log log = LogFactory.getLog(getClass());
	
	private static final String APPEAL_ID_PARAM = "appealId";	

	private static final String APPEAL_DETAILS_LINK = "appealDetails.htm?appealId=";

 

	@RequestMapping(value="/secure/editCriminalAppealOutcome.htm", params = {"!outcomeDate"})
	protected ModelAndView formBackingObject(HttpServletRequest request)
			throws Exception {

		log.info("formBackingObject()."); 
		Long appealIdL = null;
		
		String appealId = request.getParameter(APPEAL_ID_PARAM);

		AppealOutcomeTO dto = new AppealOutcomeTO();

		ModelAndView mAV = new ModelAndView("criminalAppealOutcome");		
		
		if (StringUtils.isNotEmpty(appealId)) {
			
			appealIdL = new Long(appealId);
			dto.setAppealId(appealIdL);
		}
		if (EcmsUtils.onCancel(request)) {
			
			return mAV.addObject("criminalAppealOutcome", dto);
		}
		String action = request.getParameter(CaseUtil.ACTION_TYPE_PARAM);

		if (action != null && action.equalsIgnoreCase(CaseUtil.VIEW_PARAM)) {

			if (StringUtils.isNotEmpty(appealId) && (!EcmsUtils.onCancel(request))) {
				
				AppealOutcome outcome = criminalAppealFacade.loadCriminalAppealOutcome(appealIdL);
				//Populating the appeal details, to retrieve appealed date
				CriminalAppealTO loadCriminalAppeal = criminalAppealFacade.loadCriminalAppeal(appealIdL);
				
				
				if (logger.isDebugEnabled()) {
					
					logger.debug("Criminal appeal OUTCOME Before DTO = " + outcome);
				}
				dto = ConvertToDTO.getInstance().convertToDTO(outcome);
				
				if (logger.isDebugEnabled()) {
					
					logger.debug("Criminal appeal OUTCOME afeter DTO = " + dto);
				}
				//Set the appealed date to AppealOutcome data object
				dto.setAppearedDate(loadCriminalAppeal != null ? loadCriminalAppeal.getAppearedDate() : null);
			}
		}
		
		dto.setCostAwardedAgainstList(getAppellantAndSubject(dto.getAppealId())); 
		  
		return mAV.addObject("criminalAppealOutcome", dto);		
		
	}

	@RequestMapping(value="/secure/editCriminalAppealOutcome.htm", params = {"outcomeDate"})
	public ModelAndView processFormSubmission(@ModelAttribute("criminalAppealOutcome") AppealOutcomeTO dto,
			HttpServletRequest request,
			HttpServletResponse response,  
			BindingResult errors) throws Exception {
		
		log.info("processFormSubmission");
		
		String costsAwardedOther = request.getParameter("costsAwardedOther");
		
		if (StringUtils.isNotEmpty(costsAwardedOther)) {
			dto.setCostsAwardedAgainst(costsAwardedOther);
		} 

		ModelAndView mAV = new ModelAndView("criminalAppealOutcome");
		
		List<OutcomeAppliedSanction> appliedSanctions = new ArrayList<OutcomeAppliedSanction>();
		dto.setOutcomeAppliedSanctions(appliedSanctions);
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		
		if (null == user) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}

		if (EcmsUtils.onCancel(request)) {
			return this.getRedirectView(dto);
		} 
		
		// Check your actions and do the action.
		if (EcmsUtils.onFinish(request)) {
			
			updateSanctionAppliedByStatus(dto, request);
							
			if (null == dto.getOutcomeId()) {
				
				dto.setCreatedStaffId(user.getStaffId());
				dto.setCreatedTime(new Date());
			} 
			
			if (StringUtils.equals(dto.getOutcomeStatus(), 
						CaseUtil.SanctionOutcome.UNSUCCESSFUL.toString()) &&  
					StringUtils.equals(dto.getSentenceImposed(), "NO")) {
				
				dto = updateToParentOutcomeAppliedSanctions(dto); 				
			}
			
			AppealOutcome dao = ConvertFromDTO.getInstance().convertFromDTO(dto);
			
			if (logger.isDebugEnabled()) {
				logger.debug("\n\n\n AppealOutcome=" + dao);
			}
			String currentAudit = "Criminal Appeal OutCome "+
					((null == dao.getOutcomeId() || 0L == dao.getOutcomeId()) ? "Created" : "Updated");
			
			AuditFlowThread.set(currentAudit);
			 
			criminalAppealFacade.saveOutcome(dao);
			createAudit(dto, AuditLogService.UPDATE, currentAudit, request, auditLogFacade);
			
			return this.getRedirectView(dto);
		}
				 
		mAV.addObject("criminalAppealOutcome", dto);
		return mAV;
		
	}
 
	/**
	 * Get all Person Subjects and CPS in the List for a given caseId.
	 * 
	 * @param caseId
	 * 
	 * @return List.
	 * 
	 * @throws ServiceException 
	 */
	private List<String> getAppellantAndSubject(Long appealId) throws ServiceException {

		CriminalAppealTO appealTO = criminalAppealFacade.loadCriminalAppeal(appealId);

		List<String> subjectList = new ArrayList<String>();
		// Check with the criminal appeal view.
		String appealMaker  = appealTO.getAppealMaker();
		String appellantName = appealTO.getAppellantName();
		
		String subjectName = appealTO.getPersonSubjectName();
		String otherSubject = appealTO.getOtherSubject();
		 
		subjectList.add(StringUtils.isNotEmpty(subjectName)? subjectName : otherSubject);		
		subjectList.add(StringUtils.isNotEmpty(appellantName) ? appellantName : appealMaker);
		subjectList.add("Other");		
		return subjectList;
	}
	

	/**
	 * Update the Applied Sanctions based on the parent Appeal or Sanction Id.
	 * @param dto
	 * @return
	 * @throws ServiceException
	 */
	private AppealOutcomeTO updateToParentOutcomeAppliedSanctions(AppealOutcomeTO dto) throws ServiceException {
		
		List<OutcomeAppliedSanction> sanctionList = null;
		List<OutcomeAppliedSanction> appealSanctionList = new ArrayList<OutcomeAppliedSanction>();
		
		if (null != dto.getParentAppealId()) {
		
			AppealOutcome outcome = criminalAppealFacade.loadCriminalAppealOutcome(dto.getParentAppealId());
			sanctionList = outcome.getOutcomeAppliedSanctions();
		
		} else if (null != dto.getParentSanctionId()) {
			
			CriminalSanctionOutcome outcome = criminalAppealFacade.loadCriminalSanctionOutcome(dto.getParentSanctionId());
			sanctionList = outcome.getOutcomeAppliedSanctions();
		}  
		if (null != sanctionList) {
			// Apply the new outcomeId to the Applied Sanctions.			
			for (OutcomeAppliedSanction sanction : sanctionList) {
				
				if (logger.isDebugEnabled()) {
					logger.debug("Applying outcome Ids : " + dto.getOutcomeId());
				}
				OutcomeAppliedSanction appealSanction = new OutcomeAppliedSanction();
				appealSanction.setOutcomeId(dto.getOutcomeId());
				appealSanction.setAppliedSanction(sanction.getAppliedSanction());
				appealSanction.setOtherSanction(sanction.getOtherSanction());
				appealSanction.setSanctionType(CaseUtil.APPLIED_SANCTION_TYPE.CRIMINAL_APPEAL.toString());
				appealSanction.setAppliedSanctionId(null);
				// add to the list of appeal sanction	
				appealSanctionList.add(appealSanction);
			}
			
			dto.setOutcomeAppliedSanctions(appealSanctionList);
		}
		
		return dto;
		
	} 


	/**
	 * Update Sanction Applied details depending on the outcome status
	 * 
	 * @param dto
	 */
	private void updateSanctionAppliedByStatus(AppealOutcomeTO dto, HttpServletRequest request) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Updating Applied sanctions by status, outcomeId=" + dto.getOutcomeId()); 
		}
		// Make sure that its unchecked depending on the outcome status.
		List<OutcomeAppliedSanction> appliedSanctions= dto.getOutcomeAppliedSanctions();
 
		if (appliedSanctions == null) {
			appliedSanctions = new ArrayList<OutcomeAppliedSanction>();
			
			if (logger.isDebugEnabled()) {
				logger.debug("Applied sanctions NULL, creating new list, outcomeId=" + dto.getOutcomeId()); 
			}
		}
		 
		
		if (dto != null && dto.getOutcomeStatus() != null) {
			
			for (SanctionApplied sanctApp : dto.getSanctionsImposedList()) {
				
				if(dto.getOutcomeStatus().indexOf(
						CaseUtil.SanctionOutcome.UNSUCCESSFUL.toString()) != -1  && 
						sanctApp.isChecked()) {
					
					sanctApp.setChecked(false);
				}
				else {
					String param = "_" + sanctApp.getSanctionName();
					String reqParam = request.getParameter(param);	
					if (reqParam != null && reqParam.equalsIgnoreCase("true")) {
						
						sanctApp.setChecked(true);
						appliedSanctions.add(createOutcomeSanction(dto, sanctApp));						
					}					
				}
			}
			for (SanctionApplied sanctApp : dto.getUnsuccessSanctionsImposedList()) {
				
				if(dto.getOutcomeStatus().indexOf(
						CaseUtil.SanctionOutcome.UNSUCCESSFUL.toString()) == -1 && 
						sanctApp.isChecked()) {					
					
					sanctApp.setChecked(false);					
				}
				else {
					String param = "_" + sanctApp.getSanctionName();
					String reqParam = request.getParameter(param);	
					if (reqParam != null && reqParam.equalsIgnoreCase("true")) {
						sanctApp.setChecked(true);
						appliedSanctions.add(createOutcomeSanction(dto, sanctApp));
					}
				}
			}			 				
		} 
		
	}
 
	private OutcomeAppliedSanction createOutcomeSanction(AppealOutcomeTO dto, SanctionApplied sanctApp) {
		
		OutcomeAppliedSanction sanction = new OutcomeAppliedSanction();
		
		for (OutcomeAppliedSanction outcome : dto.getOutcomeAppliedSanctions()){
			if (outcome.getAppliedSanction().equals(sanctApp.getSanctionName())) {
				sanction = outcome;
				break;
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("creating outcome sanction with outcomeId=" + dto.getOutcomeId());
			logger.debug("applying new sanction name =" + sanctApp.getSanctionName());
		}
		sanction.setOutcomeId(dto.getOutcomeId());
		sanction.setSanctionType(CaseUtil.APPLIED_SANCTION_TYPE.CRIMINAL_APPEAL.toString());
		sanction.setAppliedSanction(sanctApp.getSanctionName());
		
		return sanction;
	}

	/**
	 * Redirection to the Criminal Sanction List View...
	 * 
	 * @return ModelAndView
	 */
	private ModelAndView getRedirectView(AppealOutcomeTO dto) {
		
		if (dto != null && dto.getAppealId() != null) {

			return new ModelAndView(new RedirectView(APPEAL_DETAILS_LINK
					+ dto.getAppealId()));
		}
		return CaseUtil.getCriminalSanctionsListView();
	}

	
	/**
	 * SETTERS FOR FACADE
	 * @param criminalAppealFacade
	 */
	public void setCriminalAppealFacade(CriminalAppealService criminalAppealFacade) {
		
		this.criminalAppealFacade = criminalAppealFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		
		this.auditLogFacade = auditLogFacade;
	} 
}
