package uk.nhs.cfsms.ecms.controller;

import static java.util.regex.Pattern.compile;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.dom4j.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.Interview;
import uk.nhs.cfsms.ecms.data.cim.InterviewContent;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CPSDocumentService;
import uk.nhs.cfsms.ecms.service.InterviewService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileExtensions;
import uk.nhs.cfsms.ecms.utility.FileUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * Interview Controller to handle interview requests.
 * 
 */
@Controller
public class InterviewController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	private static final Map<String, byte[]> FILE_BYTES_MAP = new HashMap<String, byte[]>();
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private InterviewService interviewFacade;

	@Autowired
	private CPSDocumentService cpsDocumentsService;

	private CustomDateEditor customDateEditor;

	private static final String INTERVIEW_ID_PARAM = "interviewId";
	private static final String INTERVIEW_PARAM = "interview";
	private static final String INTERVIEWS_SIZE_PARAM = "interviewSize";
	private static final String INTERVIEWS_CASEID_PARAM = "caseID";
	private static final String INTERVIEWS_PARAM = "interviews";
	private static final String INTERVIEW_MAP_PARAM = "interviewMap";
	private static final String INTERVIEWS_UPLOADED_PARAM = "interviewsUploaded";
	private static final String SHOW_UPLOAD_FORM_VIEW = "showUploadForm";
	private static final String EDIT_INTERVIEW_VIEW = "editInterview";
	private static final String SHOW_INTERVIEWS_VIEW = "showInterviews";
	private static final String SHOW_INTERVIEWS_PAGE = "showInterviews.htm?caseId=";

	@Override
	protected Object newCommandObject(Class clazz) throws Exception {

		log.info("** InterviewController.newCommandObject\n");

		if (clazz.getCanonicalName().indexOf("Inteview") != -1) {
			Interview interview = new Interview();
			return interview;
		}

		Interview interview = new Interview();
		return interview;
	}

	/**
	 * Pulls backs all interview objects for the case. Puts the ones added
	 * manually into one map and the ones uploaded into a seperate map. *
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * 
	 */
	@RequestMapping(value = "/secure/showInterviews.htm")
	public ModelAndView showInterviews(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			log.info(e);
		}

		if (StringUtils.isEmpty(caseID)) {
			CaseUtil.logErrorCaseIDNotFound(log);
			return CaseUtil.getCasePortalView();
		}
		Map<String, Object> interviewMap = new HashMap<String, Object>();

		try {
			// This will not load the interview contents i.e the transcipts for
			// the interview
			List<Interview> interviews = interviewFacade
					.getInterviews(new Long(caseID));

			interviewMap.put(INTERVIEWS_SIZE_PARAM, interviews.size());
			interviewMap.put(INTERVIEWS_PARAM, interviews);
			interviewMap.put(INTERVIEWS_CASEID_PARAM, caseID);

			List<Interview> uploadedInterviews = interviewFacade
					.getInterviewsUploaded(new Long(caseID));

			interviewMap.put(INTERVIEWS_UPLOADED_PARAM, uploadedInterviews);

			return new ModelAndView(SHOW_INTERVIEWS_VIEW, INTERVIEW_MAP_PARAM,
					interviewMap);

		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

	}

	/**
	 * Show an interview object. If we have a interview id, then we are in edit
	 * mode and pull it back from the database. If not then simply create a new
	 * object and set the case id for it.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showInterview.htm")
	public ModelAndView showInterview(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String interviewId = request.getParameter(INTERVIEW_ID_PARAM);
		String caseId = request.getParameter(CaseUtil.CASE_ID_PARAM);

		Interview interview = new Interview();
		interview.setDate(new Date(System.currentTimeMillis()));
		interview.setCaseId(new Long(caseId));

		try {
			if (StringUtils.isNotEmpty(interviewId)) {
				interview = interviewFacade
						.loadInterview(new Long(interviewId));
			}
		} catch (NumberFormatException nfe) {
			log.error(nfe);
			new ServletException("Error: Invalid interview Id=" + interviewId);
		}

		return new ModelAndView(EDIT_INTERVIEW_VIEW, INTERVIEW_PARAM, interview);

	}

	/**
	 * Save interview details. This method handles both forms of input, the
	 * manual and file uploaded.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveInterview.htm")
	public ModelAndView saveInterview(HttpServletRequest request,
			HttpServletResponse response, Interview interview)
			throws ServletException {

		BindException errors = null;

		try {
			errors = bindObject(request, interview, new InterviewValidator());
		} catch (Exception e) {
			log.error(e);
			throw new ServletException(e);
		}

		// Create Time and By
		if (interview.getInterviewId() == null) {
			interview.setCreatedStaffId(EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId());
			interview.setCreatedDate(new Timestamp(System.currentTimeMillis()));
			AuditFlowThread.set("Case Interview Created");
		} else {
			AuditFlowThread.set("Case Interview Updated");
		}

		// Manually adding the interview information

		if (interview.getUploaded() == 'N') {

			// go through the multiple rows of person/interview text pairs and
			// create object
			List<InterviewContent> contents = new ArrayList<InterviewContent>();
			String[] persons = request.getParameterValues("personspeaking");
			String[] texts = request.getParameterValues("text");
			String[] ids = request.getParameterValues("icId");
			for (int i = 0; i < persons.length; i++) {
				InterviewContent ic = new InterviewContent();
				ic.setPersonSpeaking(persons[i]);
				ic.setText(texts[i].getBytes());
				String id = ids[i];
				if (id != null && !id.equals("-1") && id.length() != 0) {
					ic.setInterviewContentId(new Long(id));
				}
				contents.add(ic);
			}

			// set the list and save the object
			interview.setInterviewContents(contents);
		}
		// Uploading an mg 16 form.
		else {

			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			MultipartFile multipartFile = multipartRequest.getFile("mg16Form");
			String fileExt = FileUtils.getExtension(multipartFile
					.getOriginalFilename());

			try {
				if (interview.getInterviewId() != null) {
					this.getOriginalInterview(interview);
				}
				interview.setFileName(multipartFile.getOriginalFilename());
				interview.setUploaded('Y');
				interview.setFileType(fileExt);

				EcmsUtils.validateCpsMailDocumentFormat(multipartFile
						.getOriginalFilename());

			} catch (ServiceException se) {
				log.error(se);
				throw new ServletException(se.getMessage());
			} catch (Exception e) {
				return new ModelAndView(SHOW_UPLOAD_FORM_VIEW, INTERVIEW_PARAM,
						interview).addObject("errorMessage", e.getMessage());
			}
		}

		try {
			if (!errors.hasErrors()) {
				interviewFacade.saveObject(interview);
				createAudit(interview, AuditLogService.UPDATE,
						"Case Interview", request, auditLogFacade);
			}
		} catch (ServiceException se) {
			log.error(se);
			throw new ServletException(se.getMessage());
		}

		return new ModelAndView(new RedirectView(SHOW_INTERVIEWS_PAGE
				+ interview.getCaseId()));
	}

	@RequestMapping(value = "/secure/validateInterviewFilename.htm")
	public ModelAndView validateFileName(MultipartHttpServletRequest request,
			HttpServletResponse response,
			@RequestParam("formType") final String formType,
			@RequestParam("dateOfInterview") final String dateOfInterview)
			throws IOException, ServiceException, CaseIDNotFoundException,
			ParseException {

		final HttpSession httpSession = request.getSession();
		final ObjectMapper mapper = new ObjectMapper();
		final String caseID = CaseUtil.getCaseId(request);
		final Iterator<String> itr = request.getFileNames();
		MultipartFile mpf = null;
		String fullFileName = null;
		byte[] fileBytes = null;

		if (itr.hasNext()) {
			mpf = request.getFile(itr.next());
			fullFileName = mpf.getOriginalFilename();
			fileBytes = mpf.getBytes();

			final int id = new RandomNumberGenerator(1000)
					.generateNewRandom(10);
			final String key = id + "-" + formType;
			FILE_BYTES_MAP.put(key, fileBytes);
			httpSession.setAttribute("fileBytesMap", FILE_BYTES_MAP);

			String documentNamingRule = null;

			List<InvalidFileNames> inValidNames = new ArrayList<InvalidFileNames>();

			inValidNames = validateAndSave((HttpServletRequest) request,
					httpSession, caseID, formType, dateOfInterview,
					fullFileName, fileBytes, documentNamingRule, inValidNames,
					id);
			final String invalidFiles = getFilesInJsonFormat(mapper,
					inValidNames);
			FileCopyUtils.copy(invalidFiles, response.getWriter());
		}

		return null;
	}

	@RequestMapping(value = "/secure/updateAndSaveInterviews.htm")
	public ModelAndView updateAndSaveInterviews(HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam("invalidFileNames") final String invalidFileNames,
			@RequestParam("dateOfInterview") final String dateOfInterview)
			throws IOException, ServiceException, CaseIDNotFoundException,
			ParseException {

		final HttpSession httpSession = request.getSession();
		final ObjectMapper mapper = new ObjectMapper();
		final String caseID = CaseUtil.getCaseId(request);
		final String[] fileNames = invalidFileNames.split(",");
		String documentNamingRule = null;
		List<InvalidFileNames> inValidNames = new ArrayList<InvalidFileNames>();

		@SuppressWarnings("unchecked")
		final Map<String, byte[]> fileBytesMap = (HashMap<String, byte[]>) httpSession
				.getAttribute("fileBytesMap");

		for (String fileName : fileNames) {
			final String[] eachFileNames = fileName.split("<>");
			final String id = eachFileNames[0];
			final String formType = eachFileNames[1];
			final String fullFileName = eachFileNames[2];

			final String key = id + "-" + formType;
			final byte[] fileBytes = fileBytesMap.get(key);

			inValidNames = validateAndSave(request, httpSession, caseID,
					formType, dateOfInterview, fullFileName, fileBytes,
					documentNamingRule, inValidNames, Integer.parseInt(id));
		}

		final String invalidFiles = getFilesInJsonFormat(mapper, inValidNames);
		FileCopyUtils.copy(invalidFiles, response.getWriter());
		return null;
	}

	/**
	 * Get Original Interview
	 * 
	 * @param interview
	 * @throws ServiceException
	 */
	private void getOriginalInterview(Interview interview)
			throws ServiceException {

		// Load Interview...
		Interview originalInterview = (Interview) interviewFacade.getObject(
				Interview.class, interview.getInterviewId());

		// If the user has left the document field blank, then load
		// the one from the db, if thats blank, dont matter
		if (interview.getMg16Form().length == 0) {
			interview.setMg16Form(originalInterview.getMg16Form());
			// interview.setFileExtension(originalInterview.getFileExtension());
		}
	}

	/**
	 * Method will download the mg form as a word document for a particular
	 * interview. The browser will try to download a file called file.doc to the
	 * output stream.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/downloadMGForm.htm")
	public ModelAndView downloadMGForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Interview interview = null;

		String interviewID = request.getParameter(INTERVIEW_ID_PARAM);

		if (StringUtils.isNotEmpty(interviewID)) {

			interview = interviewFacade.loadInterview(new Long(interviewID));
		}
		String fileType = interview.getFileType();

		String fileName = interview.getFileName();

		if (StringUtils.isNotEmpty(fileType)
				&& StringUtils.isNotEmpty(fileName)) {

			response.setContentType(FileUtils.getContentTypeByFileExt(fileType,
					"application/msword"));

			response.addHeader("Content-Disposition", "attachment; filename=\""
					+ fileName + "\"");
			try {
				FileCopyUtils.copy(interview.getMg16Form(),
						response.getOutputStream());

			} catch (IOException ioe) {
				log.error(ioe);
				throw new ServletException(ioe);
			}
		} else {
			log.error("\n Interview file is blank for InterviewId= "
					+ interviewID);
		}

		return null;
	}

	/**
	 * Method to show a blank form so the user can upload a document. It simply
	 * initialises an interview and sets the case id which was passed as a
	 * request parameter.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showUploadForm.htm")
	public ModelAndView showUploadForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		if (StringUtils.isEmpty(caseID)) {
			CaseUtil.logErrorCaseIDNotFound(log);
			return CaseUtil.getCasePortalView();
		}

		Interview interview = new Interview();
		interview.setCaseId(new Long(caseID));
		/*
		 * Map<String, Object> interviewMap = new HashMap<String, Object>();
		 * interviewMap.put("interview", interview);
		 */
		return new ModelAndView(SHOW_UPLOAD_FORM_VIEW, INTERVIEW_PARAM,
				interview);

	}

	/**
	 * Deletes a given interview object from the database.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/delete.htm")
	public ModelAndView delete(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String interviewId = request.getParameter(INTERVIEW_ID_PARAM);

		String caseId = request.getParameter(CaseUtil.CASE_ID_PARAM);

		try {
			Interview interview = interviewFacade.loadInterview(new Long(
					interviewId));
			if (null != interview) {
				AuditFlowThread.set("Case Interview Deleted");
				interviewFacade.deleteInterviewById(interview.getInterviewId());
				createAudit(interview, AuditLogService.DELETE,
						"Case Interview", request, auditLogFacade);
			} else {
				log.error("No INTERVIEW Found for interviewId=" + interviewId);
			}
		} catch (ServiceException se) {
			log.error(se);
			throw new ServletException(se.getMessage());
		}

		return new ModelAndView(new RedirectView(SHOW_INTERVIEWS_PAGE + caseId));

	}

	/**
	 * This method will show an interview object as a MG 16 Form using the
	 * specified xslt stylesheet.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showMGForm.htm")
	public ModelAndView showMGForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String interviewID = request.getParameter(INTERVIEW_ID_PARAM);

		Interview intervew = null;

		if (StringUtils.isNotEmpty(interviewID)) {
			intervew = interviewFacade.loadInterview(new Long(interviewID));
		}

		String stylesheetPath = CaseUtil.getInterviewXSLPath(request);

		try {
			Document d = interviewFacade.transform(stylesheetPath, intervew);
			FileCopyUtils
					.copy(d.asXML().getBytes(), response.getOutputStream());

		} catch (IOException ioe) {
			log.error(ioe);
			throw new ServletException(ioe.getMessage());
		} catch (ServiceException se) {
			log.error(se);
			throw new ServletException(se.getMessage());
		}

		return null;

	}

	/**
	 * @param interviewFacade
	 *            The interviewFacade to set.
	 */
	public void setInterviewFacade(InterviewService interviewFacade) {
		this.interviewFacade = interviewFacade;
	}

	/**
	 * @return Returns the customDateEditor.
	 */
	public CustomDateEditor getCustomDateEditor() {
		return customDateEditor;
	}

	/**
	 * @param customDateEditor
	 *            The customDateEditor to set.
	 */
	public void setCustomDateEditor(CustomDateEditor customDateEditor) {
		this.customDateEditor = customDateEditor;
	}

	/**
	 * Interview Validator..
	 * 
	 */
	class InterviewValidator implements Validator {

		public boolean supports(Class arg0) {
			// TODO Auto-generated method stub
			return false;
		}

		public void validate(Object arg0, Errors arg1) {
			// TODO Auto-generated method stub

		}
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	@InitBinder
	protected void initBinder(ServletRequestDataBinder binder)
			throws ServletException {
		// Convert multipart object to byte[]
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());

	}

	private String getFilesInJsonFormat(final ObjectMapper mapper,
			final List<InvalidFileNames> invalidFilesList) {
		String invalidFiles = null;
		try {
			invalidFiles = mapper.writeValueAsString(invalidFilesList);
		} catch (JsonGenerationException e) {
			logger.error("Got JsonGenerationException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (JsonMappingException e) {
			logger.error("Got JsonMappingException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {
			logger.error("Got IOException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		}
		return invalidFiles;
	}

	/**
	 * @param request
	 * @param httpSession
	 * @param caseID
	 * @param formType
	 * @param fullFileName
	 * @param fileBytes
	 * @param documentNamingRule
	 * @param inValidNames
	 * @return
	 * @throws ServiceException
	 * @throws ParseException
	 */
	private List<InvalidFileNames> validateAndSave(HttpServletRequest request,
			final HttpSession httpSession, final String caseID,
			final String formType, final String dateOfInterview,
			final String fullFileName, final byte[] fileBytes,
			String documentNamingRule, List<InvalidFileNames> inValidNames,
			int id) throws ServiceException, ParseException {

		@SuppressWarnings("unchecked")
		Map<String, String> fileNamingRulesMap = (Map<String, String>) httpSession
				.getAttribute("fileNamingRulesMap");

		if (fileNamingRulesMap == null) {
			fileNamingRulesMap = this.cpsDocumentsService
					.getCPSDocumentsNamingRules();
			httpSession.setAttribute("fileNamingRulesMap", fileNamingRulesMap);
		}
		final String key = id + "-" + formType;

		documentNamingRule = getFileNamingRule(documentNamingRule, formType,
				fileNamingRulesMap);

		String fileName = null;

		if (!documentNamingRule.isEmpty()) {
			final Pattern pattern = compile(documentNamingRule);
			final String fileNameWithExt = fullFileName;

			final String extension = FilenameUtils
					.getExtension(fileNameWithExt);

			if (FileExtensions.isValidExtension(extension.toLowerCase())) {
				fileName = fileNameWithExt.substring(0,
						fileNameWithExt.indexOf("." + extension));
			} else {
				fileName = fileNameWithExt;
			}
			final Matcher matcher = pattern.matcher(fileName.trim());

			if (!matcher.matches()) {
				inValidNames = populateInvalidFileNames(formType, fullFileName,
						inValidNames, id);
			} else {
				saveInterview(request, fullFileName, formType, dateOfInterview,
						fileBytes, caseID, key);
			}
		} else {
			saveInterview(request, fullFileName, formType, dateOfInterview,
					fileBytes, caseID, key);
		}
		return inValidNames;
	}

	/**
	 * This method is responsible to get file naming rule for given document
	 * category.
	 * 
	 * @param String
	 *            documentCategory
	 * @param String
	 *            documentNamingRule
	 * @param String
	 *            formType
	 * @param Map
	 *            <String, String> fileNamingRulesMap
	 * 
	 * @return String
	 */

	private String getFileNamingRule(String documentNamingRule,
			final String formType, final Map<String, String> fileNamingRulesMap) {

		documentNamingRule = fileNamingRulesMap.get(formType);

		documentNamingRule = documentNamingRule != null ? documentNamingRule
				.trim() : "";
		return documentNamingRule;
	}

	/**
	 * @param formType
	 * @param fullFileName
	 * @param fileBytes
	 * @param inValidNames
	 * @param id
	 */
	private List<InvalidFileNames> populateInvalidFileNames(
			final String formType, final String fullFileName,
			final List<InvalidFileNames> inValidNames, int id) {
		final InvalidFileNames invalidFileNames = new InvalidFileNames();
		invalidFileNames.setSelectId(id);
		invalidFileNames.setFullFileName(fullFileName);
		invalidFileNames.setFormType(formType);
		inValidNames.add(invalidFileNames);

		return inValidNames;
	}

	private static class RandomNumberGenerator {
		ArrayList<Integer> numbersList = new ArrayList<Integer>();

		public RandomNumberGenerator(int length) {
			for (int x = 1; x <= length; x++)
				numbersList.add(x);
			Collections.shuffle(numbersList);
		}

		public int generateNewRandom(int n) {
			return numbersList.get(n);
		}
	}

	/**
	 * @param request
	 * @param fullFileName
	 * @param mgFormObject
	 * @throws ServiceException
	 * @throws ParseException
	 */
	private void saveInterview(HttpServletRequest request,
			final String fullFileName, final String formType,
			final String dateOfInterview, final byte[] fileBytes,
			final String caseID, final String key) throws ServiceException,
			ParseException {

		final Interview interview = new Interview();
		final SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		final Date date = format.parse(dateOfInterview);
		final String fileExt = FileUtils.getExtension(fullFileName);

		interview.setCreatedStaffId(EcmsUtils.getSessionUserObject(
				request.getSession()).getStaffId());
		interview.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		interview.setFileName(fullFileName);
		interview.setUploaded('Y');
		interview.setFileType(fileExt);
		interview.setCaseId(Long.parseLong(caseID));
		interview.setMg16Form(fileBytes);
		interview.setDate(date);
		AuditFlowThread.set("Case Interview Created");
		interviewFacade.saveObject(interview);
		FILE_BYTES_MAP.remove(key);
	}

	private static class InvalidFileNames {
		private int selectId;
		private String formType;
		// private byte[] filebytes;
		private String fullFileName;

		public int getSelectId() {
			return selectId;
		}

		public void setSelectId(int selectId) {
			this.selectId = selectId;
		}

		public String getFormType() {
			return formType;
		}

		public void setFormType(String formType) {
			this.formType = formType;
		}

		/*
		 * public byte[] getFilebytes() { return filebytes; }
		 * 
		 * public void setFilebytes(byte[] filebytes) { this.filebytes =
		 * filebytes; }
		 */

		public String getFullFileName() {
			return fullFileName;
		}

		public void setFullFileName(String fullFileName) {
			this.fullFileName = fullFileName;
		}

	}

}
