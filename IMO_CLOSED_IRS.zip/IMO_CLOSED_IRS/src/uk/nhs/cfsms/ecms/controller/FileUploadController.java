package uk.nhs.cfsms.ecms.controller;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.actions.DownloadAction.StreamInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.data.common.FileObject;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.FileUploadService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * Provide links(data) to Intelligence Bulletin, Knowledge Database, FCROL
 * Information and Help Library.
 * 
 * @author kolla.venkat
 * 
 */
@Controller
public class FileUploadController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	FileUploadService fileUploadFacade;

	public final static String INTEL_BULLETIN_DOWNLOAD = "VIEW INTEL BULLETIN";
	public final static String DATA_REQUEST_DOWNLOAD = "VIEW DATA REQUEST";
	public final static String KNOWLEDGE_DOWNLOAD = "VIEW KNOWLEDGE";
	public final static String HELP_LIBRARY_DOWNLOAD = "VIEW HELP LIBRARY";
	public final static String MG_FORMS_DOWNLOAD = "MG FORMS";

	public enum UploadCategory {
		MG_FORMS, DATA_REQUEST_FORMS, INTELLIGENCE_BULLETIN, KNOWLEDGE_DATABASE, HELP_LIBRARY, OTHER_FORMS, POLICY_DOCS
	}

	/**
	 * Information Bulletins...
	 * 
	 * @param request
	 * @param response
	 * @return model and view.
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/listInfoBulletins.htm")
	public ModelAndView listInfoBulletins(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Map<String, Object> bulletinMap = new HashMap<String, Object>();
		try {
			// List<FileObject> bulletins =
			// fileUploadFacade.loadFileByFileByDept("CIU");
			List<FileObject> bulletins = fileUploadFacade
					.loadFileByFileByCategory(UploadCategory.INTELLIGENCE_BULLETIN
							.toString());
			bulletinMap.put("bulletinsSize", bulletins.size());
			bulletinMap.put("infobulletins", bulletins);
			String staffId = EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId();
			if (fileUploadFacade.isUserUploadAdmin(
					UploadCategory.INTELLIGENCE_BULLETIN.toString(), staffId)) {
				bulletinMap.put("bulletinAdmin", true);
			} else {
				bulletinMap.put("bulletinAdmin", false);
			}

			return new ModelAndView("listInfoBulletins", "infoBulletinsMap",
					bulletinMap);
		} catch (Exception e) {

			throw e;
		}
	}

	/**
	 * List knowledge base data links.
	 * 
	 * @param request
	 * @param response
	 * @return model and view
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/listKnowledgeBase.htm")
	public ModelAndView listKnowledgeBase(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Map<String, Object> knowledgeBaseMap = new HashMap<String, Object>();
		try {
			// List<FileObject> knowledgeBase =
			// fileUploadFacade.loadFileByFileByDept("SWRT");
			List<FileObject> knowledgeBase = fileUploadFacade
					.loadFileByFileByCategory(UploadCategory.KNOWLEDGE_DATABASE
							.toString());
			knowledgeBaseMap.put("knowledgeSize", knowledgeBase.size());
			knowledgeBaseMap.put("knowledgeBase", knowledgeBase);
			String staffId = EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId();
			if (fileUploadFacade.isUserUploadAdmin(
					UploadCategory.KNOWLEDGE_DATABASE.toString(), staffId)) {
				knowledgeBaseMap.put("knowledgeAdmin", true);
			} else {
				knowledgeBaseMap.put("knowledgeAdmin", false);
			}
			return new ModelAndView("knowledgeBase", "knowledgeBaseMap",
					knowledgeBaseMap);

		} catch (Exception e) {

			throw e;
		}

	}

	/**
	 * Lists Help Library links
	 * 
	 * @param request
	 * @param response
	 * @return model and view
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/listHelpLibrary.htm")
	public ModelAndView listHelpLibrary(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Map<String, Object> helpBaseMap = new HashMap<String, Object>();
		try {
			// List<FileObject> helpBase =
			// fileUploadFacade.loadFileByFileByDept(ECMSConstants.USER_SOP);
			List<FileObject> helpBase = fileUploadFacade
					.loadFileByFileByCategory(UploadCategory.HELP_LIBRARY
							.toString());
			helpBaseMap.put("helpSize", helpBase.size());
			helpBaseMap.put("helpBase", helpBase);
			String staffId = EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId();
			if (fileUploadFacade.isUserUploadAdmin(
					UploadCategory.HELP_LIBRARY.toString(), staffId)) {
				helpBaseMap.put("helpAdmin", true);
			} else {
				helpBaseMap.put("helpAdmin", false);
			}
			return new ModelAndView("helpBase", "helpBaseMap", helpBaseMap);
		} catch (Exception e) {

			throw e;
		}

	}

	/**
	 * Lists MG Form File links
	 * 
	 * @param request
	 * @param response
	 * @return model and view
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/listMGForms.htm")
	public ModelAndView listMGForms(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Map<String, Object> mgFileMap = new HashMap<String, Object>();
		try {
			List<FileObject> mgFiles = fileUploadFacade
					.loadFileByFileByCategory(UploadCategory.MG_FORMS
							.toString());
			mgFileMap.put("mgFileSize", mgFiles.size());
			mgFileMap.put("mgFormList", mgFiles);
			String staffId = EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId();
			if (fileUploadFacade.isUserUploadAdmin(
					UploadCategory.MG_FORMS.toString(), staffId)) {
				mgFileMap.put("mgFormAdmin", true);
			} else {
				mgFileMap.put("mgFormAdmin", false);
			}
			if (log.isInfoEnabled()) {
				log.info("MGForms list size=" + mgFiles.size());
			}
			return new ModelAndView("mgFileBase", "mgFileMap", mgFileMap);
		} catch (Exception e) {

			throw e;
		}

	}

	// TODO
	private void writeFileAsBytes(String fullPath, byte[] bytes)
			throws IOException {
		OutputStream bufferedOutputStream = new BufferedOutputStream(
				new FileOutputStream(fullPath));
		InputStream inputStream = new ByteArrayInputStream(bytes);
		int token = -1;

		while ((token = inputStream.read()) != -1) {
			bufferedOutputStream.write(token);
		}
		bufferedOutputStream.flush();
		bufferedOutputStream.close();
		inputStream.close();
	}

	/**
	 * Lists Other Form File links
	 * 
	 * @param request
	 * @param response
	 * @return model and view
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/listOtherForms.htm")
	public ModelAndView listOtherForms(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String otherForms = UploadCategory.OTHER_FORMS.toString();
		Map<String, Object> otherFormMap = new HashMap<String, Object>();
		try {
			List<FileObject> dRFiles = fileUploadFacade
					.loadFileByFileByCategory(otherForms);
			otherFormMap.put("otherFormSize", dRFiles.size());
			otherFormMap.put("otherFormList", dRFiles);
			String staffId = EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId();
			if (fileUploadFacade.isUserUploadAdmin(otherForms, staffId)) {
				otherFormMap.put("otherFormAdmin", true);
			} else {
				otherFormMap.put("otherFormAdmin", false);
			}
			if (log.isInfoEnabled()) {
				log.info("otherForm list size=" + dRFiles.size());
			}
			return new ModelAndView("otherFormBase", "otherFormMap",
					otherFormMap);
		} catch (Exception e) {

			throw e;
		}

	}

	/**
	 * List policy documents.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/policyDocuments.htm")
	public ModelAndView listPolicyDocuments(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String policyDocs = UploadCategory.POLICY_DOCS.toString();
		Map<String, Object> policyDocsMap = new HashMap<String, Object>();
		try {
			List<FileObject> dRFiles = fileUploadFacade
					.loadFileByFileByCategory(policyDocs);
			policyDocsMap.put("policyDocsSize", dRFiles.size());
			policyDocsMap.put("policyDocsList", dRFiles);
			String staffId = EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId();
			if (fileUploadFacade.isUserUploadAdmin(policyDocs, staffId)) {
				policyDocsMap.put("policyDocsAdmin", true);
			} else {
				policyDocsMap.put("policyDocsAdmin", false);
			}
			if (log.isInfoEnabled()) {
				log.info("policyDocs list size=" + dRFiles.size());
			}
			return new ModelAndView("policyDocsBase", "policyDocsMap",
					policyDocsMap);
		} catch (Exception e) {

			throw e;
		}

	}

	/**
	 * Lists Data Request Form File links
	 * 
	 * @param request
	 * @param response
	 * @return model and view
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/listDataReqForms.htm")
	public ModelAndView listDataRequestForms(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Map<String, Object> dataRequestMap = new HashMap<String, Object>();
		try {
			List<FileObject> dRFiles = fileUploadFacade
					.loadFileByFileByCategory(UploadCategory.DATA_REQUEST_FORMS
							.toString());
			dataRequestMap.put("dataRequestSize", dRFiles.size());
			dataRequestMap.put("dataRequestList", dRFiles);
			String staffId = EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId();
			if (fileUploadFacade.isUserUploadAdmin(
					UploadCategory.DATA_REQUEST_FORMS.toString(), staffId)) {
				dataRequestMap.put("dataRequestAdmin", true);
			} else {
				dataRequestMap.put("dataRequestAdmin", false);
			}
			if (log.isInfoEnabled()) {
				log.info("DATA Request list size=" + dRFiles.size());
			}
			return new ModelAndView("dataRequestBase", "dataRequestMap",
					dataRequestMap);
		} catch (Exception e) {

			throw e;
		}
	}

	/**
	 * Common upload file facility for all the above mentioned links
	 * 
	 * @param request
	 * @param response
	 * @return model and view
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/uploadInfoBulletin.htm")
	public ModelAndView uploadFile(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		String description = request.getParameter("description");
		String department = request.getParameter("department");
		String category = request.getParameter("category");
		FileObject fileObj = new FileObject();
		try {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			ServletRequestDataBinder binder = new ServletRequestDataBinder(
					fileObj);
			binder.registerCustomEditor(byte[].class,
					new ByteArrayMultipartFileEditor());

			MultipartFile multipartFile = multipartRequest
					.getFile("infobulletin");
			// String fileExtension = FileUtils.getExtension(multipartFile
			// .getOriginalFilename());

			binder.bind(request);

			fileObj.setFileName(multipartFile.getOriginalFilename());
			fileObj.setCreateStaffId(user.getStaffId());
			fileObj.setFileDescrption(description);
			fileObj.setCreatedDate(new Date());
			fileObj.setFileType(multipartFile.getContentType());
			fileObj.setUploadedDepartment(department);
			fileObj.setFileData(multipartFile.getBytes());
			fileObj.setCategory(category);

			fileUploadFacade.saveFile(fileObj);
			createAudit(fileObj, AuditLogService.UPLOAD, "DEPARTMENT="
					+ department + ", Category =" + category, request,
					auditLogFacade);
		} catch (Exception e) {
			log.error("ERROR Uploading or saving of file, desc=" + description
					+ ", Category=" + category);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("category", category);

		return new ModelAndView("infobulletinsuccess", "map", map);
	}

	/**
	 * Retrieve the requested file
	 * 
	 * @param request
	 * @param response
	 * @return model and view.
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/viewInfoBulletin.htm")
	public ModelAndView viewFile(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String fileId = request.getParameter("fileId");
		if (log.isDebugEnabled()) {
			log.debug("\n\n *** FILE ID = " + fileId);
		}
		try {

			FileObject file = (FileObject) fileUploadFacade
					.loadFileByFileId(new Long(fileId));

			if (null != file) {

				String viewType = null;

				if (file.getCategory().equalsIgnoreCase(
						UploadCategory.INTELLIGENCE_BULLETIN.toString())) {
					viewType = INTEL_BULLETIN_DOWNLOAD;
				} else if (file.getCategory().equalsIgnoreCase(
						UploadCategory.HELP_LIBRARY.toString())) {
					viewType = HELP_LIBRARY_DOWNLOAD;
				} else if (file.getCategory().equalsIgnoreCase(
						UploadCategory.KNOWLEDGE_DATABASE.toString())) {
					viewType = KNOWLEDGE_DOWNLOAD;
				} else if (file.getCategory().equalsIgnoreCase(
						UploadCategory.MG_FORMS.toString())) {
					viewType = MG_FORMS_DOWNLOAD;
				} else {
					viewType = DATA_REQUEST_DOWNLOAD;
				}

				createAudit(file, file.getFileId(), AuditLogService.DOWNLOAD,
						viewType, request, auditLogFacade);

				response.setContentType(file.getFileType());
				response.setContentLength(file.getFileData().length);
				response.setHeader("Content-Disposition",
						"attachment; filename=" + file.getFileName());
				if (log.isDebugEnabled()) {
					log.debug("Copying file to servlet output stream!!!");
				}
				FileCopyUtils.copy(file.getFileData(),
						response.getOutputStream());
			}
		} catch (IOException ioe) {
			log.error("IO Exception caught while getting inputstream");
			throw new ServletException(ioe);
		} catch (Exception ex) {
			log.error("Exception caught while getting inputstream");
			throw new ServletException(ex);
		}
		log.debug("finished and returning null...");
		return null;
	}

	/**
	 * Delete the requested file.
	 * 
	 * @param request
	 * @param response
	 * @return model and view
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/deleteInfoBulletin.htm")
	public ModelAndView deleteFile(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String fileId = request.getParameter("fileId");
		Long fileIdL = new Long(fileId);
		String category = request.getParameter("category");

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("category", category);
		try {
			fileUploadFacade.deleteFile(fileIdL);
		} catch (Exception e) {
			log.error("ERROR deleting file, fileId=" + fileId + ", Category="
					+ category);
		}
		return new ModelAndView("infobulletindelete", "catMap", map);
	}

	/**
	 * 
	 * ByteArrayStreamInfo
	 * 
	 */
	protected class ByteArrayStreamInfo implements StreamInfo {

		protected String contentType;

		protected byte[] bytes;

		public ByteArrayStreamInfo(String contentType, byte[] bytes) {
			this.contentType = contentType;
			this.bytes = bytes;
		}

		public String getContentType() {
			return contentType;
		}

		public InputStream getInputStream() throws IOException {
			return new ByteArrayInputStream(bytes);
		}
	}

	/**
	 * Setter method for the Audit Facade.
	 * 
	 * @param auditLogFacade
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	/**
	 * Setter method for the FileUpload Facade.
	 * 
	 * @param fileUploadFacade
	 */
	public void setFileUploadFacade(FileUploadService fileUploadFacade) {
		this.fileUploadFacade = fileUploadFacade;
	}
}