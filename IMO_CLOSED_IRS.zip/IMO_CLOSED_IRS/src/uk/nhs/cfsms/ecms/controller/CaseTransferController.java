package uk.nhs.cfsms.ecms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.cim.CaseTransfer;
import uk.nhs.cfsms.ecms.dto.infoGath.InfoTransferHistTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseTransferService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;
@Controller
public class CaseTransferController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CaseTransferService caseTransferFacade;
	
	@RequestMapping(value ="/secure/showtransferlinks.htm")
	public ModelAndView showTransferLinksPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		CaseUtil.removeCaseIdFromSession(request);
		return new ModelAndView("casetransferlinks");

	}
	
	@RequestMapping(value ="/secure/receivedlcfstransferlist.htm")
	public ModelAndView receivedLcfsTransfers(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		List<CaseTransfer> transferList = null;
		try {
			transferList = caseTransferFacade
					.loadReceivedLcfsTransfersByUserId(user.getStaffId());
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		Map<String, Object> lcfsTransferMap = new HashMap<String, Object>();
		lcfsTransferMap.put("lcfsTransferList", transferList);
		lcfsTransferMap.put("viewType", "Received");

		return new ModelAndView("lcfstransferlist", "lcfsTransferMap",
				lcfsTransferMap);

	}

	@RequestMapping(value ="/secure/receivedcfstransferlist.htm")
	public ModelAndView receivedCfsTransfers(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		List<CaseTransfer> transferList = null;
		try {
			transferList = caseTransferFacade
					.loadReceivedCfsTransfersByUserId(user.getStaffId());
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		Map<String, Object> cfsTransferMap = new HashMap<String, Object>();
		cfsTransferMap.put("cfsTransferList", transferList);
		cfsTransferMap.put("viewType", "Received");
		return new ModelAndView("cfstransferlist", "cfsTransferMap",
				cfsTransferMap);

	}

	@RequestMapping(value ="/secure/createdlcfstransferlist.htm")
	public ModelAndView createdLcfsTransfers(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		List<CaseTransfer> transferList = null;
		try {
			transferList = caseTransferFacade
					.loadCreatedLcfsTransfersByUserId(user.getStaffId());
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		Map<String, Object> lcfsTransferMap = new HashMap<String, Object>();
		lcfsTransferMap.put("lcfsTransferList", transferList);
		lcfsTransferMap.put("viewType", "Created");
		return new ModelAndView("lcfstransferlist", "lcfsTransferMap",
				lcfsTransferMap);

	}

	@RequestMapping(value ="/secure/createdcfstransferlist.htm")
	public ModelAndView createdCfsTransfers(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		List<CaseTransfer> transferList = null;
		try {
			transferList = caseTransferFacade
					.loadCreatedCfsTransfersByUserId(user.getStaffId());
		} catch (ServiceException se) {
			throw new ServletException(se);
		}
		Map<String, Object> cfsTransferMap = new HashMap<String, Object>();
		cfsTransferMap.put("cfsTransferList", transferList);
		cfsTransferMap.put("viewType", "Created");
		
		return new ModelAndView("cfstransferlist", "cfsTransferMap",
				cfsTransferMap);
	}

	@RequestMapping(value ="/secure/pendinglcfstransferlist.htm")
	public ModelAndView approvalPendingLcfsTransfers(
			HttpServletRequest request, HttpServletResponse response)
			throws ServletException {
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		List<CaseTransfer> transferList = null;
		try {
			transferList = caseTransferFacade
					.loadApprovalPendingLcfsTransfersByUserId(user.getStaffId());
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		Map<String, Object> lcfsTransferMap = new HashMap<String, Object>();
		lcfsTransferMap.put("lcfsTransferList", transferList);
		lcfsTransferMap.put("viewType", "Approval Pending");
		
		return new ModelAndView("lcfstransferlist", "lcfsTransferMap",
				lcfsTransferMap);
	}

	@RequestMapping(value ="/secure/pendingcfstransferlist.htm")
	public ModelAndView approvalPendingCfsTransfers(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		List<CaseTransfer> transferList = null;
		try {
			transferList = caseTransferFacade
					.loadApprovalPendingCfsTransfersByUserId(user.getStaffId());
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		Map<String, Object> cfsTransferMap = new HashMap<String, Object>();
		cfsTransferMap.put("cfsTransferList", transferList);
		cfsTransferMap.put("viewType", "Approval Pending");
		return new ModelAndView("cfstransferlist", "cfsTransferMap",
				cfsTransferMap);

	}

	@RequestMapping(value ="/secure/casecfstransfers.htm")
	public ModelAndView caseCfsTransfers(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		String caseID = null;

		try {
			caseID = CaseUtil.getCaseId(request);
			
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}

		Long caseIDLong = new Long(caseID);

		List<CaseTransfer> transferList = null;
		try {
			transferList = caseTransferFacade
					.loadCaseCfsTransfersByCaseId(caseIDLong);
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		Map<String, Object> cfsTransferMap = new HashMap<String, Object>();
		cfsTransferMap.put("cfsTransferList", transferList);
		cfsTransferMap.put("caseId", caseID);
		return new ModelAndView("casecfstransfers", "cfsTransferMap",
				cfsTransferMap);

	}

	@RequestMapping(value ="/secure/caselcfstransfers.htm")
	public ModelAndView caseLcfsTransfers(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		String caseID = null;
		List<CaseTransfer> transferList = null;

		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		try {
			Long caseId = new Long(caseID);
			Case caseInfo = caseTransferFacade.loadCaseByCaseId(caseId);
			
			if (null !=caseInfo && "C".equalsIgnoreCase(caseInfo.getAccessFlag())) {
				//throw new ServletException("restrictions.confidential.case.allocation");
				return new ModelAndView("transfermessage", "message", "restrictions.confidential.case.allocation");
				
			}
			transferList = caseTransferFacade
					.loadCaseLcfsTransfersByCaseId(caseId);

		} catch (NumberFormatException nfe) {
			logger.error(nfe);
			throw nfe;
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		Map<String, Object> lcfsTransferMap = new HashMap<String, Object>();
		lcfsTransferMap.put("lcfsTransferList", transferList);
		lcfsTransferMap.put("caseId", caseID);

		return new ModelAndView("caselcfstransfers", "lcfsTransferMap",
				lcfsTransferMap);

	}

	/**
	 * This method is responsible for listing the information transfers waiting for the approvals.
	 * 
	 * @param request
	 * @param response
	 * 
	 * @return ModelAndView
	 * 
	 * */
	@RequestMapping(value ="/secure/pendinginformationtransferlist.htm")
	public ModelAndView approvalPendingInformationTransfers(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		List<InfoTransferHistTO> infoTransferList = null;
		try {
			infoTransferList = caseTransferFacade
					.loadApprovalPendingInformationTransfersByUserId(user.getStaffId());
		} catch (ServiceException se) {
			throw new ServletException(se);
		}

		Map<String, Object> infoTransferMap = new HashMap<String, Object>();
		infoTransferMap.put("infoTransferList", infoTransferList);
		infoTransferMap.put("viewType", "Approval Pending");
		return new ModelAndView("informationtransferlist", "infoTransferMap",
				infoTransferMap);

	}

	public void setCaseTransferFacade(CaseTransferService caseTransferFacade) {
		
		this.caseTransferFacade = caseTransferFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		
		this.auditLogFacade = auditLogFacade;
	}

}
