package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.dto.caseInfo.AppealHearingTO;
import uk.nhs.cfsms.ecms.service.AppealHearingService;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * Common appeal hearing Controller for Criminal and Civil sanction types.
 * 
 * @author sChilukuri
 * 
 */
@Controller
public class AppealHearingFormController extends BaseBinderConfig {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private AuditLogService auditLogFacade;

	@Autowired
	private AppealHearingService appealHearingFacade;

	@Autowired
	private LookupViewService lookupViewFacade;


	private static final String APPEAL_HEARING_LINK = "showAppealHearing.htm";

	private static final String APPEAL_HEARING_URL = "appealHearing";

	//TODO : check for why we are using multiple URL's.. 
	@RequestMapping(value={"/secure/createAppealHearing.htm", "/secure/criminalAppeal.htm"})
	public ModelAndView formBackingObject(HttpServletRequest request) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("formBackingObject()...");
		}

		//APPEAL_URL is mapped to criminalAppeal, should have been appealHearing as per the jsp name.
		ModelAndView mAV = new ModelAndView(APPEAL_HEARING_URL);

		String appealID = request.getParameter(CaseUtil.APPEAL_ID);


		String sanctionType = request.getParameter(CaseUtil.SANCTION_TYPE);

		if (StringUtils.isEmpty(appealID)) {
			logger.error("No " + CaseUtil.APPEAL_ID	+ " param found.");
		}
		if (StringUtils.isEmpty(sanctionType)) {
			logger.error("No " + CaseUtil.SANCTION_TYPE + " param found.");
		}

		AppealHearingTO dto = new AppealHearingTO();

		if (StringUtils.isNotEmpty(appealID)) {
			dto.setAppealId(new Long(appealID));
		}
		if (StringUtils.isNotEmpty(sanctionType)) {
			dto.setSanctionType(sanctionType);
		}

		String action = request.getParameter(CaseUtil.ACTION_TYPE_PARAM);

		if (action != null && action.equalsIgnoreCase(CaseUtil.VIEW_PARAM)) {

			String id = request.getParameter(CaseUtil.APPEARANCE_ID_PARAM);

			if (StringUtils.isNotEmpty(id) && (!EcmsUtils.onCancel(request))) {

				dto = appealHearingFacade.loadCourtAppearanceById(new Long(id)); 
			}
		}

		if (!EcmsUtils.onCancel(request)) {

			this.setupAllLookupDetails( dto);
		}

		mAV.addObject("hearing", dto);
		mAV.addObject("appealId", appealID);

		return mAV;

	}


	@RequestMapping(value="/secure/saveAppealHearing.htm", method = RequestMethod.POST)
	public ModelAndView processFormSubmission(
			HttpServletRequest request,
			HttpServletResponse response, 
			AppealHearingTO appealHearing, 
			BindingResult  errors) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("processFormSubmission");
		}
		ModelAndView mAV = new ModelAndView(APPEAL_HEARING_URL); 

		if (EcmsUtils.onCancel(request)) {
			return this.getRedirectView(appealHearing);
		}

		validateAppealHearing(appealHearing, request, errors);

		if (errors.getErrorCount() < 1) {
			// Check your actions and do the action.
			if (EcmsUtils.onFinish(request)) {
				// To overcome issue with data type, giving '-' as default. 
				if (StringUtils.isEmpty(appealHearing.getOutcomeInfo())) {
					appealHearing.setOutcomeInfo("-");
				}
				if (StringUtils.equalsIgnoreCase(appealHearing.getSanctionType(), 
						CaseUtil.APPLIED_SANCTION_TYPE.CRIMINAL_APPEAL.toString())) {

					appealHearing.setSanctionType(CaseUtil.APPLIED_SANCTION_TYPE.CRIMINAL_APPEAL.toString());
				}
				if (null == appealHearing.getAppearanceId()) {

					String flow = "Criminal Appeal Hearing Created";
					if ("civil_appeal".equalsIgnoreCase(appealHearing.getSanctionType())){
						flow = "Civil Appeal Hearing Created";
					}
					AuditFlowThread.set(flow);
					appealHearingFacade.saveAppealHearing(appealHearing);
					createAudit(appealHearing, AuditLogService.CREATE,
							"Appeal Hearing Created", request, auditLogFacade);
				} else {

					String flow = "Criminal Appeal Hearing Updated";
					if ("civil_appeal".equalsIgnoreCase(appealHearing.getSanctionType())){
						flow = "Civil Appeal Hearing Updated";
					}
					AuditFlowThread.set(flow);
					appealHearingFacade.updateCivilAppealHearing(appealHearing);
					createAudit(appealHearing, AuditLogService.UPDATE,
							"Appeal Hearing Updated", request, auditLogFacade);
				}

				return this.getRedirectView(appealHearing);
			}
			if (EcmsUtils.onDelete(request)) {
				AuditFlowThread.set("Criminal Appeal Hearing Deleted");
				appealHearingFacade.deleteAppealHearing(appealHearing);
				createAudit(appealHearing, AuditLogService.DELETE,
						"Appeal Hearing Deleted", request, auditLogFacade);
				return this.getRedirectView(appealHearing);
			}

		} else { 

			mAV.addObject(errors.getModel());
		}

		mAV.addObject("hearing", appealHearing);
		mAV.addObject("appealId", appealHearing.getAppealId());
		return mAV;
	}

	/**
	 * Validate Contact details.
	 * 
	 * @param contact
	 * @param request
	 * @param errors
	 */
	private void validateAppealHearing(AppealHearingTO appealHearing,
			HttpServletRequest request, BindingResult  errors) {

		log.info("No Validation in validateAppealHearing");

	}

	/**
	 * Redirection View for the Court Appearance.
	 * 
	 * @param dto
	 * @return ModelAndView
	 */
	private ModelAndView getRedirectView(AppealHearingTO dto) {

		StringBuffer param = new StringBuffer();

		if (null != dto && null != dto.getAppealId()) {

			param.append("?");
			param.append(CaseUtil.APPEAL_ID).append("=").append(dto.getAppealId());
			param.append("&").append(CaseUtil.SANCTION_TYPE).append("=").append(dto.getSanctionType());
		}

		return new ModelAndView(new RedirectView(APPEAL_HEARING_LINK + param));

	}

	/**
	 * Setup all lookup details for information.
	 * 
	 * @param Information
	 */
	private void setupAllLookupDetails(AppealHearingTO dto) {

		if (StringUtils.isNotEmpty(dto.getSanctionType())) {

			if (dto.getSanctionType().equalsIgnoreCase("criminal_appeal")) {

				this.setupLookupMap(CaseUtil.getCriminalAppealHearingLookupGroups(), dto);


			} else if (dto.getSanctionType().equalsIgnoreCase("civil_appeal")) {

				this.setupLookupMap(CaseUtil.getCivilAppealHearingLookupGroups(), dto);
			}
		}
	}

	private void setupLookupMap(String[] groupNames, AppealHearingTO dto) {

		for (String groupName : groupNames) {

			List<LookupView> list = new ArrayList<LookupView>();

			if (null != groupName) {

				list = lookupViewFacade.loadByGroupAndOrderByLookupId(groupName);
			}
			if (log.isDebugEnabled()) {

				log.debug("setupLookupMap, adding groupName=" + groupName);
			}

			dto.addLookupViewMap(groupName, list);
		}
	}

	public void setappealHearingFacade(
			AppealHearingService appealHearingFacade) {
		this.appealHearingFacade = appealHearingFacade;
	}

	public void setLookupViewFacade(LookupViewService lookupViewFacade) {
		this.lookupViewFacade = lookupViewFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}


	private static final String COURT_APPEARANCES = "courtAppearances";

	private static final String LIST_MAP = "listMap"; 

	private static final String COURT_APPEARANCES_LIST_VIEW = "showAppealHearing";

	@RequestMapping(value ="/secure/showAppealHearing.htm")
	public ModelAndView showCourtAppearances(
			HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String appealID = request.getParameter(CaseUtil.APPEAL_ID);

		String sanctionType = request.getParameter(CaseUtil.SANCTION_TYPE);

		List<AppealHearingTO> hearingList = null;

		if (log.isDebugEnabled()) {
			log.debug("AppealId =" + appealID + ", SanctionType = " + sanctionType);
		}
		if (StringUtils.isEmpty(appealID)) {

			log.error("No " + CaseUtil.APPEAL_ID  +" found.");
			return CaseUtil.getCriminalSanctionsListView();
		}

		if (StringUtils.isEmpty(sanctionType)) {

			log.error("No " + CaseUtil.SANCTION_TYPE + " found.");
			return CaseUtil.getCriminalSanctionsListView();
		}

		try {
			if(appealID != null){
				hearingList = appealHearingFacade
						.loadCourtAppearancesByType(Long.valueOf(appealID),sanctionType);
			}
		} catch (Exception e) {
			throw new ServletException(e);
		}

		Map<String, Object> listMap = new HashMap<String, Object>();

		listMap.put(COURT_APPEARANCES, hearingList);
		listMap.put(CaseUtil.APPEAL_ID, appealID);
		listMap.put(CaseUtil.SANCTION_TYPE, sanctionType);

		return new ModelAndView(COURT_APPEARANCES_LIST_VIEW, LIST_MAP, listMap);
	}


	public void setAppealHearingFacade(
			AppealHearingService appealHearingFacade) {
		this.appealHearingFacade = appealHearingFacade;
	}

}
