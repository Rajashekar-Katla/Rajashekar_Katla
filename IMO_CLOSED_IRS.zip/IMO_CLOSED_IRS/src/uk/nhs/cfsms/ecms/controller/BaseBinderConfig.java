package uk.nhs.cfsms.ecms.controller;

import java.math.BigDecimal;
import java.text.NumberFormat;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

public class BaseBinderConfig   {
 	
	/** Logger that is available to subclasses */
	protected final Log logger = LogFactory.getLog(getClass());
	
	@InitBinder
	public  void initBinder(HttpServletRequest request,
			ServletRequestDataBinder binder) throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("initBinder()...");
		}
		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, null, true));
		binder
				.registerCustomEditor(String.class, new StringTrimmerEditor(
						true));
		binder.registerCustomEditor(Float.class, new CustomNumberEditor(
				Float.class, nf, true));
		
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null, 
					new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}

	/**
	 * Create Audit for Case
	 * 
	 * @param object
	 * @param state
	 * @param request
	 * @param auditLogFacade
	 */
	protected void createAudit(String object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			auditLogFacade.save(object, state, action, EcmsUtils.getSessionUserObject(
							request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);

		} catch (Exception e) {
			logger.error("ERROR while creating Audit:" + e);
		}
	}
	
	/**
	 * Create Audit for Case
	 * 
	 * @param object
	 * @param state
	 * @param request
	 * @param auditLogFacade
	 */
	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			logger.error(e);
		}
	}	
}
