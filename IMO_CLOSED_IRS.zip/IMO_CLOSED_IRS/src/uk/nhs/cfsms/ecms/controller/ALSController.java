package uk.nhs.cfsms.ecms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import uk.nhs.cfsms.ecms.data.infoGath.Address;
import uk.nhs.cfsms.ecms.utility.AddressVo;

@Controller
public class ALSController extends MultiActionController {
	
	protected final Log log = LogFactory.getLog(getClass());
	private static final String GB_SEARCH_VIEW = "gbSearchView";

	@Autowired
	RestTemplate restTemplate;

	@RequestMapping(value ="/secure/gbSearchView.htm")
	public ModelAndView handleView(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		return new ModelAndView(GB_SEARCH_VIEW);
	}

	/**
	 * Custom handler for GB Search page.
	 * 
	 * @param request
	 *            current HTTP request
	 * @param response
	 *            current HTTP response
	 * @return a ModelAndView to render the response
	 */
	@Value("${als.service.url}") String url;
	@Value("${als.context}") String als;
	@Value("${als.request.mapping}") String alsRequestMapping;
	
	@RequestMapping(value ="/secure/gbSearchResults.htm")
	public ModelAndView handleSearch(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		Address address = new Address();
		Enumeration enums = request.getParameterNames();

		while (enums.hasMoreElements()) {
			String strParam = (String) enums.nextElement();
			String paramValue = request.getParameter(strParam);
			if (strParam.equalsIgnoreCase("address1")) {
				address.setAddress1(paramValue.trim());
			} 
			if (strParam.equalsIgnoreCase("address2")) {
				address.setAddress2(paramValue.trim());
			}
			if (strParam.equalsIgnoreCase("address3")) {
				address.setAddress3(paramValue.trim());
			} 
			if (strParam.equalsIgnoreCase("address4")) {
				address.setAddress4(paramValue.trim());
			} 
			if (strParam.equalsIgnoreCase("postalcode")) {
				address.setPostcode(paramValue.trim());
			}
		}
		ObjectMapper objectMapper = new ObjectMapper(); 
		List<AddressVo> addressVoList = null;

		AddressVo addressVo = new AddressVo();
		addressVo.setAddressLine1(address.getAddress1());
		addressVo.setAddressLine2(address.getAddress2());
		addressVo.setAddressLine3(address.getAddress3());
		addressVo.setAddressLine4(address.getAddress4());
		addressVo.setPostCode(address.getPostcode());
		if(addressVo != null){
			try {
				String returnValue = 
						restTemplate.getForObject(url+als+alsRequestMapping+"{jsonAddressString}", String.class, convertToJson(addressVo));
				addressVoList = objectMapper.readValue(returnValue, objectMapper.getTypeFactory().
						constructCollectionType(List.class, AddressVo.class));
			} catch (JsonParseException e) {
				log.error(e.getMessage());
			} catch (JsonMappingException e) {
				log.error(e.getMessage());
			} catch (RestClientException e) {
				log.error(e.getMessage());
			} catch (IOException e) {
				log.error(e.getMessage());
			}
		}
		return new ModelAndView(GB_SEARCH_VIEW, "addressList", addressVoList != null ? 
				addressVoList : null);
	}

	private String convertToJson(AddressVo object) throws JsonParseException, JsonMappingException, IOException{
		ObjectWriter ow = new ObjectMapper().writer();
		String json = ow.writeValueAsString(object);
		return json;
	}

}
