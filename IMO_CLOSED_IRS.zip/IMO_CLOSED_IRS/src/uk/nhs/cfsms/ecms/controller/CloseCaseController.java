package uk.nhs.cfsms.ecms.controller;

import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseClosureTO;

import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.MessageService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.FileUtils;
@Controller
public class CloseCaseController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CaseService caseFacade;
	@Autowired
	private MessageService messageFacade;

	@RequestMapping(value="/secure/closurereportdownload.htm")
	public ModelAndView downloadReport(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String caseId = CaseUtil.getCaseId(request);
		CaseClosureTO closure = caseFacade.loadCaseClosureByCaseId(new Long(
				caseId));
		
		String fileType=closure.getClosureReportFileType();
		String fileName=closure.getClosureReportFileName();
		
	
		String contentType=FileUtils.getContentTypeByFileExt(fileType,null);
		if(null ==contentType)
		contentType=FileUtils.getContentTypeByFileName(fileType,"application/msword");	
		
		if(null ==fileName)
		{
			
			fileName=FileUtils.getSampleFileNameByContentType(contentType,"closurereport","closurereport.doc");
		}	
		
		
			FileUtils.writeOutputForm(closure.getClosureReport(),fileName,contentType,response);

		
		//writeOutputForm(closure.getClosureReport(), response);

		return null;
	}

	@RequestMapping(value="/secure/closecase.htm")
	public ModelAndView closeCase(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String caseId = CaseUtil.getCaseId(request);
		if (!checkClosureReport(new Long(caseId))) {
			return new ModelAndView("noclosereport");
		}
		try {
			Case caseObj=caseFacade.saveCloseCase(new Long(caseId));
			
			//Triggering the message upon case closure Starts
			MessageTO acceptMsg = createCaseClosureAcceptanceMessage(caseObj,request);//Triggering a message after the case closure.
			String closureReportCreatorStaffID = caseFacade.loadCaseClosureByCaseId(new Long(caseId)).getCreatedStaffId();
			acceptMsg.setToStaffId(closureReportCreatorStaffID);
			acceptMsg.setToStaffName(caseFacade.getUserFullName(closureReportCreatorStaffID));
			if (null != acceptMsg && null != acceptMsg.getCaseId() && 
					acceptMsg.getMessageType().equals(MessageTO.Message_types.CASE_CLOSURE_ACCEPTED.toString())) {
				messageFacade.updateAcceptedCaseClosureMessage(acceptMsg, true);
				createAudit("Case Closure Acceptance", AuditLogService.UPDATE, acceptMsg.getActionDetails(),request, auditLogFacade);
			} 
			//Triggering the message upon case closure Ends
			createAudit(new String("Close Case Id="+caseId), AuditLogService.UPDATE, "Close Case", request,
					auditLogFacade);				
			
		} catch (Exception e) {
			throw new ServletException(e);
		}

		return new ModelAndView("closecasesuccess");
	}

	private boolean checkClosureReport(Long caseId) throws ServletException {
		try {
			CaseClosureTO closeRep = caseFacade.loadCaseClosureByCaseId(caseId);
			if (null != closeRep && closeRep.getCaseClosureId() != null)
				return true;
			else
				return false;
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

	@SuppressWarnings("unused")
	private void writeOutputForm(byte[] file, HttpServletResponse response)
			throws Exception {

		response.setHeader("Content-disposition",
				"attachment; filename=report.doc");
		response.setContentType("application/msword");
		response.setContentLength(file.length);

		ServletOutputStream ouputStream = response.getOutputStream();
		ouputStream.write(file);
		ouputStream.flush();
		ouputStream.close();
	}

	
	/**
	 * Its a accept (almost reply) message from the original message. 
	 * @param origMesg
	 * @param actionDetails
	 * @return MessageTO
	 */
	private MessageTO createCaseClosureAcceptanceMessage(Case caseObj,HttpServletRequest request) throws Exception {

		Long caseId = caseObj.getCaseId();
		if (null == caseId) {
			caseId = new Long(CaseUtil.getCaseId(request));
		}
		SessionUser user=EcmsUtils.getSessionUserObject(request.getSession());
		String message="Case Closure Accepted.";
		MessageTO messageTO=new MessageTO();
		messageTO.setMessage(message);
		messageTO.setCaseRef("Case Id: "+caseId);
		messageTO.setCaseId(caseId);
		messageTO.setMessageType(MessageTO.Message_types.CASE_CLOSURE_ACCEPTED.toString());
		messageTO.setCreatedStaffId(user.getStaffId());
		messageTO.setFromStaffId(user.getStaffId());
		messageTO.setFromStaffName(user.getFullName());
		messageTO.setCreatedTime(new Date());
		messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
		
		return messageTO;
	}
	
	public CaseService getCaseFacade() {
		return caseFacade;
	}

	/**
	 * Setter for the Facade
	 * 
	 * @param messageFacade
	 */
	public void setMessageFacade(MessageService messageFacade) {
		this.messageFacade = messageFacade;
	}

	
	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

	public AuditLogService getAuditLogFacade() {
		return auditLogFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
