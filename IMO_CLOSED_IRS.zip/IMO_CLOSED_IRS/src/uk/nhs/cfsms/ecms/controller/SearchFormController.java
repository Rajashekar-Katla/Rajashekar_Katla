package uk.nhs.cfsms.ecms.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dto.search.CaseSearchFormTO;
import uk.nhs.cfsms.ecms.dto.search.SearchResultsTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.IndexedSearchService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * Indexed Search Case Form Controller based on search type like case or
 * information.
 * 
 * @author sChilukuri
 * 
 */
@Controller
public class SearchFormController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private IndexedSearchService indexedSearchFacade;
	@Autowired	
	private CaseService caseFacade;

	public static final String KEYWORDS_PARAM = "searchKeywords";

	public static final String SEARCH_TYPE_PARAM = "searchType";

	public static final String SEARCH_ID_PARAM = "searchId";

	public static final String CASE_PARAM = "case";

	public static final String INFORMATION_PARAM = "information";

	public static final String STATUS = "status";

	/**
	 * Handle SearchResults
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/searchResults.htm")
	public ModelAndView handleSearchResults(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map searchResultsMap = new HashMap();
		logger.info("** SearchFormController.handleSearchResults().");
		String searchKeywordsParam = request.getParameter(KEYWORDS_PARAM);
		String searchTypeParam = request.getParameter(SEARCH_TYPE_PARAM);
		String status = request.getParameter(STATUS);
		try {
			if(status != null && !status.equals("")){
				return handleGenericSearchResults(request,response);
			}
			SearchResultsTO sto = new SearchResultsTO();

			if (StringUtils.isNotEmpty(searchKeywordsParam)
					&& StringUtils.isNotEmpty(searchTypeParam)) {

				SessionUser user = EcmsUtils.getSessionUserObject(request
						.getSession());
				if (searchTypeParam.equalsIgnoreCase(CASE_PARAM)) {

					sto = indexedSearchFacade.getCaseIndexedSearchResults(
							searchKeywordsParam, user);

				} else if (searchTypeParam.equalsIgnoreCase(INFORMATION_PARAM)) {
					sto = indexedSearchFacade
							.getInformationIndexedSearchResults(
									searchKeywordsParam, user);

				}
			}
			// Case or Information.
			sto.setSearchKeywords(searchKeywordsParam);
			sto.setSearchType(searchTypeParam);
			searchResultsMap.put("searchResults", sto);

			return new ModelAndView("searchResults", "searchResultsMap",
					searchResultsMap);

		} catch (NumberFormatException nfe) {
			logger.error(nfe);
			throw nfe;
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * Handle SearchResults
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	public ModelAndView handleGenericSearchResults(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		logger.info("** handleGenericSearchResults().");
		Map searchResultsMap = new HashMap();

		CaseSearchFormTO sto = new CaseSearchFormTO();
		try {
			String statusStr = request.getParameter("status");
			String caseNumber = request.getParameter(KEYWORDS_PARAM);
			if (StringUtils.isNotEmpty(statusStr)
					&& !statusStr.equalsIgnoreCase("ALL")) {
				if (statusStr.equalsIgnoreCase("OPEN")) {
					sto.setCaseStatus(ECMSConstants.CASE_OPEN);
				} else if (statusStr.equalsIgnoreCase("PENDING")) {
					sto.setCaseStatus(ECMSConstants.CASE_PENDING);
				} else if (statusStr.equalsIgnoreCase("CLOSED")) {
					sto.setCaseStatus(ECMSConstants.CASE_CLOSED);
				} else if (statusStr.equalsIgnoreCase("LCFS-CLOSED")) {
					sto.setCaseStatus(ECMSConstants.CASE_CLOSED);
					sto.setClosedBy(ECMSConstants.LOCAL);
				}else if (statusStr.equalsIgnoreCase("LCFS-PENDING")) {
					sto.setCaseStatus(ECMSConstants.CASE_PENDING);
					sto.setClosedBy(ECMSConstants.LOCAL);
				}else if (statusStr.equalsIgnoreCase("LCFS-OPENED")) {
					sto.setCaseStatus(ECMSConstants.CASE_OPEN);
					sto.setClosedBy(ECMSConstants.LOCAL);
				} else if (statusStr.equalsIgnoreCase("CFS-CLOSED")) {
					sto.setCaseStatus(ECMSConstants.CASE_CLOSED);
					sto.setClosedBy(ECMSConstants.REGIONAL);
				} else if (statusStr.equalsIgnoreCase("CFS-OPENED")) {
					sto.setCaseStatus(ECMSConstants.CASE_OPEN);
					sto.setClosedBy(ECMSConstants.REGIONAL);
				}else if (statusStr.equalsIgnoreCase("CFS-PENDING")) {
					sto.setCaseStatus(ECMSConstants.CASE_PENDING);
					sto.setClosedBy(ECMSConstants.REGIONAL);
				}
			}
			else if (StringUtils.isNotEmpty(statusStr)
					&& statusStr.equalsIgnoreCase("ALL")) {
				sto.setCaseStatus("ALL");
			}
			if (!StringUtils.isEmpty(caseNumber)) {
				sto.setCaseNumber(caseNumber);
			}
			if (!StringUtils.isEmpty(request.getParameter("operationName"))) {
				sto.setOperationName(request.getParameter("operationName"));
			}

			if (sto.getCaseStatus() != null) {
				sto = caseFacade.getGenericCaseSearchResults(sto, EcmsUtils
						.getSessionUserObject(request.getSession()));
				
			}
			
			searchResultsMap.put("searchResults", sto);
			
			return new ModelAndView("lcfsFilterSearchResults", "searchResultsMap",
					searchResultsMap);

		} catch (NumberFormatException nfe) {
			logger.error(nfe);
			throw nfe;
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
	}
	/**
	 * Handle SearchForm
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/search.htm")
	public ModelAndView handleSearchForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		logger.info("** SearchFormController.handleSearchForm().");

		Map searchFormMap = new HashMap();
		String searchKeywordsParam = request.getParameter(KEYWORDS_PARAM);
		String searchTypeParam = request.getParameter(SEARCH_TYPE_PARAM);

		try {
			SearchResultsTO sto = new SearchResultsTO();

			if (StringUtils.isNotEmpty(searchKeywordsParam)) {
				sto.setSearchKeywords(searchKeywordsParam);
			}
			if (StringUtils.isNotEmpty(searchTypeParam)) {
				sto.setSearchType(searchTypeParam);
			}

			searchFormMap.put("searchResults", sto);

			return new ModelAndView("searchIndexForm", "searchFormMap",
					searchFormMap);

		} catch (NumberFormatException nfe) {
			logger.error(nfe);
			throw nfe;
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * Handle Search Results in Detail
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value ="/secure/showSearchDetails.htm")
	public ModelAndView handleSearchResultDetails(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		Map searchResultsMap = new HashMap();
		logger.info("** handleSearchResultDetails().");
		
		String searchKeywordsParam = request.getParameter(KEYWORDS_PARAM);
		String searchTypeParam = request.getParameter(SEARCH_TYPE_PARAM);
		String searchIdParam  = request.getParameter(SEARCH_ID_PARAM);

		try {

			Long curSearchId = new Long(searchIdParam.trim());
			SearchResultsTO sto = new SearchResultsTO();

			if (StringUtils.isNotEmpty(searchTypeParam)
					&& StringUtils.isNotEmpty(searchIdParam)) {

				SessionUser user = EcmsUtils.getSessionUserObject(request
						.getSession());
				if (searchTypeParam.equalsIgnoreCase(CASE_PARAM)) {

					String caseIdParam = request.getParameter("caseId");
					Long lCaseId = new Long(caseIdParam.trim());

					sto = indexedSearchFacade.getCaseSearchResultDetails(
							curSearchId, lCaseId, user);
					if (sto.getDataOwner() == null) {
						sto.setErrorMessage("Invalid TeamCode mapped to the Case Id=" + lCaseId);
					}
					sto.setApplicationId(lCaseId);
				} 
				else if (searchTypeParam.equalsIgnoreCase(INFORMATION_PARAM)) {

					String infoIdParam = request.getParameter("infoId");
					Long lInfoId = new Long(infoIdParam.trim());

					sto = indexedSearchFacade.getInformationSearchDetails(
							curSearchId, lInfoId, user);
					if (sto.getDataOwner() == null) {
						sto.setErrorMessage("Invalid TeamCode mapped to the Information Id=" + lInfoId);
					}
					sto.setApplicationId(lInfoId);
				}
			}
			sto.setSearchKeywords(searchKeywordsParam);
			sto.setNodeId(searchIdParam);
			sto.setSearchType(searchTypeParam);

			searchResultsMap.put("searchResults", sto);

			return new ModelAndView("detailedSearchResults",
					"searchResultsMap", searchResultsMap);

		} catch (NumberFormatException nfe) {
			logger.error(nfe);
			throw nfe;
		} catch (Exception e) {
			logger.error(e);
			throw new ServletException(e);
		}

	}

	/**
	 * Setter method for the Indexed Search Facade.
	 * 
	 * @param indexedSearchFacade
	 */
	public void setIndexedSearchFacade(IndexedSearchService indexedSearchFacade) {
		this.indexedSearchFacade = indexedSearchFacade;
	}
	
	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}
}
