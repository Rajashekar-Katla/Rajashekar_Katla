package uk.nhs.cfsms.ecms.controller;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.NumberFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationProgressTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SourceInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.service.InformationProgressService;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.service.OrganisationService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.InformationUtil;
import uk.nhs.cfsms.ecms.utility.PatientOccupationLookupMap;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * Case Information Controller deals with Information only and not subjects.
 *
 */
@Controller
public class EditCaseInformationController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private LookupViewService lookupViewFacade;
	@Autowired
	private OrganisationService organisationFacade;
	@Autowired
	private InformationGatherService informationGatherFacade;
	@Autowired
	private InformationProgressService informationProgressService;
 
	private static final String CASE_INFO = "CASE_INFORMATION";
     
	@RequestMapping(value="/secure/caseInformation.htm")
	public ModelAndView processFormSubmission(
    			HttpServletRequest request, 
    			HttpServletResponse response, 
    			@ModelAttribute("information") InformationTO info, 
    			BindingResult errors) throws Exception {

		String formView = "editCaseInformation"; 

		if (log.isInfoEnabled()) {
			log.info("processFormSubmission");
		}
		if (EcmsUtils.onCancel(request)) {

			return getCaseListView(info.getCaseId(), request);
		}
		if (onConvertToWitness(request)) {
			
			log.info("@@ onConvertToWitness");
			SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
			String subjectIdToWitness = request.getParameter("subjectId");
			AuditFlowThread.set("Convert Case Subject to Witness");
			informationGatherFacade.updateSubjectToWitness(info, user, subjectIdToWitness);
			createAudit(info, AuditLogService.UPDATE, "Convert Case Subject to Witness", request, auditLogFacade);
			return CaseUtil.getCasePortalView();
		}
		if (EcmsUtils.onFinish(request)) {
			
			if (log.isInfoEnabled()) {
				log.info("@@ finish");
			}
			validateInformation(info, request, errors);

			if (errors.getErrorCount() < 1) {

				SessionUser user = EcmsUtils.getSessionUserObject(request
						.getSession());
				String curDate = EcmsUtils.getDateToddMMyyyy(new Date(System
						.currentTimeMillis()));

				if (null != info.getNewInformation()
						&& StringUtils.isNotEmpty(info.getNewInformation())) {
					
					info.setInformationDetails(info.getInformationDetails()
							+ " (Created By: " + user.getFullName() + ", On: " + curDate + ")");
				}
				else {
					if (log.isInfoEnabled()) {
						log.info("@@ finish, refillMissingInformationInCaseInfo");
					}
					this.refillMissingInformationInCaseInfo(info);
				}
				String otherSource = "";
				if(info.getSourceInformationTO() != null){
				   otherSource = info.getSourceInformationTO().getOtherSource();
				}

				if (otherSource != null && !otherSource.trim().equals("")) {
					info.getSourceInformationTO().setSource("");
				}
				AuditFlowThread.set("Case Information Updated");
				informationGatherFacade.saveCaseInformation(info, user);
				createAudit(info, AuditLogService.UPDATE,
						"Case Information Updated", request, auditLogFacade);
				return this.getCaseListView(info.getCaseId(), request);
			}
			else {
				log.error("ERROR count="+ errors.getErrorCount() + ", back with errors");
			} 
			return new ModelAndView(formView, "information", info);

		} else {
			if (log.isInfoEnabled()) {
				log.info("Loading Information for update !!!");
			}
			info = updateInformationByCaseId(info, CaseUtil.getCaseId(request),
					request.getSession());
			if(info != null){
				final List<InformationProgressTO> infoProgressTOList = informationProgressService
						.loadInformationProgresses(info.getInformationId());
				if (!infoProgressTOList.isEmpty()) {
					info.setInfoProgressJsonString(informationProgressService
							.convertToInformationProgressListToJsonString(infoProgressTOList));
				}
			return new ModelAndView(formView, "information", info);
		}
			else
				return new ModelAndView(formView, "information", new InformationTO());
		}
	} 
	
	
	/**
	 * Update Information using caseId
	 * 
	 * @param infoTO
	 * @param caseId
	 * @param session
	 * @return InformationTO
	 * @throws Exception
	 */
	private InformationTO updateInformationByCaseId(InformationTO infoTO,
			String caseId, HttpSession session) throws Exception {
		
		if (log.isDebugEnabled()) {
			log.debug("updating  Information By CaseId =" + caseId);
		}
		infoTO = informationGatherFacade.loadInformationByCaseId(new Long(
				caseId), true);

		setupRegionAndOrganisations(infoTO, session);

		if (infoTO != null) {

			String srcType = infoTO.getSourceInformationTO().getSourceType();
			String otherSrc = infoTO.getSourceInformationTO().getOtherSource();
			
			if ((srcType == null || StringUtils.isEmpty(srcType))
					&& (otherSrc != null && StringUtils.isNotEmpty(otherSrc))) {
				
				infoTO.getSourceInformationTO().setSourceType(
						ECMSConstants.SOURCE_TYPE_OTHER);
			}

			if (!InformationUtil.hasLookupDetails(infoTO)) {
				setupAllLookupDetails(infoTO);
			}
			// Update Source SubType.
			updateSourceLookupDetails(infoTO);
			updateFruadAreaAndTypesLookupDetails(infoTO);
			if (null != infoTO.getSubjectInfoList()) {
				updateSubjectNHSOccupationTypes(infoTO);
			}
			if (!InformationUtil.hasLookupDetails(infoTO)) {
				setupAllLookupDetails(infoTO);
			}
			session.setAttribute(CASE_INFO, infoTO);
		}
		
		return infoTO;
	}
	
	
	private InformationTO refillMissingInformationInCaseInfo(InformationTO newInfoTO) throws Exception {
		
		Long caseId = newInfoTO.getCaseId();
		
		if (log.isDebugEnabled()) {
			log.debug("Refill Information Details & state, CaseInfo with caseId=" + caseId);
		}
		InformationTO actualInfoTO = informationGatherFacade.loadInformationByCaseId(caseId, true);

		if (null != newInfoTO && null != actualInfoTO) {
			
			newInfoTO.setInformationDetails(actualInfoTO.getInformationDetails());
			newInfoTO.setState(actualInfoTO.getState());
			
		} else {
			throw new Exception("Case Information Refill Failed!!!! NO original Info Details, caseId=" + caseId);
		}
		
		return newInfoTO;
	}

	private void setupRegionAndOrganisations(InformationTO infoTO,
			HttpSession session) {

		if(infoTO == null){
			return;
		}
		
		List<TeamCodes> teamCodes = null;
		SessionUser sessionUser = EcmsUtils.getSessionUserObject(session);

		List<Organisation> orgCodes = null;
		if (session.getAttribute("teamCodesList") != null) {
			teamCodes = (List) session.getAttribute("teamCodesList");
		}
		if (session.getAttribute("orgCodesList") != null) {
			orgCodes = (List) session.getAttribute("orgCodesList");
		}
		if (null == teamCodes) {
			
			teamCodes = organisationFacade.loadAllTeamCodes();
			infoTO.setTeamCodesList(teamCodes);
			session.setAttribute("teamCodesList", teamCodes);
			
			orgCodes = organisationFacade.loadOrganisationsByOrgName("", sessionUser);
			session.setAttribute("orgCodesList", orgCodes);
		}
	}

	/**
	 * Update Lookup source sub type for a source.
	 * 
	 * @param info
	 */
	private void updateSourceLookupDetails(InformationTO info) throws Exception {

		if (null != info && null != info.getSourceInformationTO()) {

			String groupName = ECMSConstants.LOOKUP_SOURCE ;
			
			info.addInfoLookupViewMap(groupName, getLookupDetails(groupName));
			
			SourceInformationTO srcTO = info.getSourceInformationTO();
			
			if (null != srcTO && StringUtils.isNotEmpty(srcTO.getSource())) {

				LookupView view = lookupViewFacade.loadLookupDetailsById(new Integer(srcTO.getSource()));

				if (null != view) {
					
					srcTO.setSourceType(view.getParentId().toString());
					
					info.addInfoLookupViewMap(ECMSConstants.LOOKUP_SOURCE_SUB_TYPE,
							lookupViewFacade.loadActiveLookupDetailsByParentId(view.getParentId()));
					// Make it static
					info.setStaticInfoLookupViewMap();
				}
			}
	
		}
	}
	
	/**
	 * Update Lookup details for LOOKUP_NHS_FRAUD_AREA, LOOKUP_FRAUD_SUB_AREA_1, 
	 *  LOOKUP_FRAUD_SUB_AREA_2 and LOOKUP_AREA_FRAUD_TYPE
	 * 
	 * @param info	 InformationTO.
	 */
	private void updateFruadAreaAndTypesLookupDetails(InformationTO info) {

		if (null != info) {
			
			String groupName = ECMSConstants.LOOKUP_NHS_FRAUD_AREA ;
			
			info.addInfoLookupViewMap(groupName, getLookupDetails(groupName));
			
			if (StringUtils.isNotEmpty(info.getFraudArea())) {
				
				LookupView view = lookupViewFacade.loadLookupDetailsById(new Integer(info.getFraudArea().trim()));
				
				info.addInfoLookupViewMap(ECMSConstants.LOOKUP_FRAUD_SUB_AREA_1, lookupViewFacade.loadActiveLookupDetailsByParentId(new Integer(info.getAreatype()), view.getGroupId()));
			}
			
			if (StringUtils.isNotEmpty(info.getFraudSubArea())) {
				
				LookupView view = lookupViewFacade.loadLookupDetailsById(new Integer(info.getFraudSubArea().trim()));
				
				info.addInfoLookupViewMap(ECMSConstants.LOOKUP_FRAUD_SUB_AREA_2, lookupViewFacade.loadActiveLookupDetailsByParentId(new Integer(info.getFraudArea()), view.getGroupId()));
			}
			
			if (StringUtils.isNotEmpty(info.getNhsFraudType())) {
				
				LookupView view = lookupViewFacade.loadLookupDetailsById(new Integer(info.getNhsFraudType()));
				
				info.addInfoLookupViewMap(ECMSConstants.LOOKUP_AREA_FRAUD_TYPE, lookupViewFacade.loadActiveLookupDetailsByParentId(new Integer(info.getFraudArea()), view.getGroupId()));
			}
			// Adding dynamic list to the static map.
			info.setStaticInfoLookupViewMap();
		}
		
	}
	
	private void updateSubjectNHSOccupationTypes(InformationTO info) {

		log.info("Updating Subject NHS OccupationTypes");
		
		List<SubjectInformationTO> subjectList = info.getSubjectInfoList();
		
		for (int i=0; i < subjectList.size(); i++) {
			
			SubjectInformationTO subj = subjectList.get(i);
			
			if (null != subj && null != subj.getSubjectPersonTO()) {
				
				PersonTO pTO = subj.getSubjectPersonTO();
				
				if (pTO.isPersonWorkingForNHS() && null != pTO.getNhsOccupationType()) {
					
					LookupView view = lookupViewFacade.loadLookupDetailsById(new Integer(pTO.getNhsOccupationType()));
					info.addDynamicInfoLookupViewMap(ECMSConstants.LOOKUP_OCCUPATION_NHS_TYPE + i, lookupViewFacade.loadActiveLookupDetailsByParentId(new Integer(pTO.getNhsCareerArea()), view.getGroupId()));	
				}
/*				if (pTO.isPersonNHSPatient()) {
					info.addDynamicInfoLookupViewMap(ECMSConstants.LOOKUP_OCCUPATION_PATIENT_TYPE, lookupViewFacade.loadActiveLookupDetailsByGroups(ECMSConstants.LOOKUP_OCCUPATION_PATIENT_TYPE));					
				}
*/			}
		}
	}

	/**
	 * LookupView Details given the group name
	 * 
	 * @param groupName
	 * @return List.
	 */
	private List<LookupView> getLookupDetails(String groupName) {

		if (groupName != null) {
			
			return lookupViewFacade.loadActiveLookupDetailsByGroups(groupName);
		}	
		return null;
	}

	/**
	 * Validate Information.
	 * 
	 * @param info
	 * @param request
	 * @param errors
	 */
	private void validateInformation(InformationTO info,
			HttpServletRequest request, BindingResult errors) {

		// Validation orgCode in information
		/*ValidationUtils.rejectIfEmptyOrWhitespace(errors, "orgCode",
				"required.orgCode",
				"Please enter mandatory field 'Org Code' for Information.");*/
	}

	/**
	 * Setup all lookup details for information.
	 * 
	 * @param Information
	 */
	private void setupAllLookupDetails(InformationTO info) {

		String[] lookupGroupNames = InformationUtil.getAllLookupGroups();

		for (String groupName : lookupGroupNames) {
			
			info.addInfoLookupViewMap(groupName, getLookupDetails(groupName));
		}
		info.setStaticInfoLookupViewMap();
		
		setUpPatientOccupationLookupDetails();
	}
	
	/**
	 * LookupView details for patient occupation
	 * 
	 * @return List.
	 */
	private void setUpPatientOccupationLookupDetails() {
		final List<LookupView> lookupList = lookupViewFacade
				.loadPatientOccupationDescriptions();
		for (LookupView view : lookupList) {
			final String lookupId = String.valueOf(view.getLookupId());
			final String description = view.getDescription();
			final Map<String, String> map = PatientOccupationLookupMap
					.getAllPatientOccupationDetailsLookupMap();
			if (!map.containsKey(lookupId)) {
				map.put(lookupId, description);
			}
		}
	}

	/**
	 * Check for whether to convert to Witness.
	 * 
	 * @param request
	 * @return
	 */
	private boolean onConvertToWitness(HttpServletRequest request) {
		if (request.getParameter("convertToWitness") != null) {
			return true;
		}
		return false;
	}

	/**
	 * Helper to redirect to new view.
	 * 
	 * @return ModelAndView
	 */
	private ModelAndView getCaseListView(Long caseId, HttpServletRequest request) {

		String caseID = "";
		if (caseId != null) {
			caseID = caseId.toString();
		} else {
			caseID = CaseUtil.getCurrentCaseInSession(request.getSession());
		}

		return new ModelAndView(new RedirectView(CaseUtil.SHOW_CASE_PAGE
				+ caseID));
	}

	public void setLookupViewFacade(LookupViewService lookupViewFacade) {
		this.lookupViewFacade = lookupViewFacade;
	}

	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public void setOrganisationFacade(OrganisationService organisationFacade) {
		this.organisationFacade = organisationFacade;
	}
	
	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			log.error(e);
		}
	}
	
	@InitBinder
	protected void initBinder(HttpServletRequest servletRequest,
			ServletRequestDataBinder binder) throws Exception {
 
		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, nf, true));
		binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null,
				new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}
	
}