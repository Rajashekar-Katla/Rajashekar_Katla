package uk.nhs.cfsms.ecms.controller;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditDetails;
import uk.nhs.cfsms.ecms.audit.AuditLogsCommand;
import uk.nhs.cfsms.ecms.audit.AuditedPropertyInfo;
import uk.nhs.cfsms.ecms.audit.CustomTrackingRevisionEntity;
import uk.nhs.cfsms.ecms.audit.RevisionedEntityInfo;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.FileUtils;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfFileSpecification;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Controller
public class CaseProgressLogController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private AuditLogService auditLogFacade;

	static final Font boldRedFont = new Font(Font.FontFamily.HELVETICA, 9f,
			Font.BOLD, new BaseColor(255, 0, 0));

	static final Font boldBlueFont = new Font(Font.FontFamily.HELVETICA, 9f,
			Font.BOLD, new BaseColor(0, 0, 255));

	static final Font normalBlackFont = new Font(Font.FontFamily.HELVETICA, 8f,
			Font.NORMAL, new BaseColor(0, 0, 0));

	static final Font boldBlackFont = new Font(Font.FontFamily.HELVETICA, 9f,
			Font.BOLD, new BaseColor(0, 0, 0));

	static final String US_DATE_FORMAT_REG_EXP = "\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}.\\d*";

	static final DateFormat dbFormat = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss.SSS");
 

	/**
	 * Show Progress Logs.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/caseprogresslog.htm")
	public ModelAndView showProgressLogAsPDF(@RequestParam(value="genf", required=false) String output,
			HttpServletRequest request,
			HttpServletResponse response) throws Exception {
 
		AuditLogsCommand command = new AuditLogsCommand();
		bind(request, command);
		
		if (null != output && output.equalsIgnoreCase("pdf")) {

			String contentType = "application/pdf"; 			
			List<CustomTrackingRevisionEntity> revisionList = auditLogFacade
					.getAuditDump(command);
			CaseTO caseTO = CaseUtil.getCaseFromSession(request.getSession());
			String fileName = "";
			byte[] finalFile = null;
			if(caseTO != null && caseTO.getCaseId() != null){
				fileName = "AuitLog_" + caseTO.getCaseId() + "_"
						+ new Date().getTime() + ".pdf";
				finalFile = generatePDF(contentType, fileName, caseTO,
						revisionList);  
			}else{
				fileName = "AuitLog_" + "Info_"
							+ new Date().getTime() + ".pdf";
				finalFile = generatePDFWithOutCase(contentType, fileName, revisionList);	
			}
			
			FileUtils.writeOutputForm(finalFile, fileName, contentType, response);
			
			return null;
		}
		else { 
			
			Map<String, Object> caseProgressLogMap = new HashMap<String, Object>();
  
			List<CustomTrackingRevisionEntity> revisionList = auditLogFacade
					.getLogs(command);
			List<CustomTrackingRevisionEntity> revisionListNew = new ArrayList<CustomTrackingRevisionEntity>();
            for(CustomTrackingRevisionEntity obj:revisionList){
            	if(obj.getFlowName() != null){
            		revisionListNew.add(obj);
            	}
            }
			caseProgressLogMap.put("caseProgressLogs", revisionListNew);
			caseProgressLogMap.put("logType", command.getLogType());// entityId
			caseProgressLogMap.put("entityId", command.getEntityId());

			return new ModelAndView("caseprogresslog", "caseProgressLogMap",
					caseProgressLogMap);
		}
	}

	/**
	 * Show Revision details.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/secure/entitiesChanged.htm")
	public ModelAndView showRevisiondetails(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Map<String, Object> revisionDetailsMap = new HashMap<String, Object>();

		AuditLogsCommand command = new AuditLogsCommand();

		bind(request, command);

		List<RevisionedEntityInfo> revisedEntities = auditLogFacade
				.getAuditInfo(command);

		revisionDetailsMap.put("revisedEntities", revisedEntities);

		return new ModelAndView("entitiesChanged", "revisionListMap",
				revisionDetailsMap);
	}

	/**
	 * Setter Facade.
	 * 
	 * @param auditLogFacade
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {

		this.auditLogFacade = auditLogFacade;
	}

	private byte[] generatePDF(String fileType, String fullName, CaseTO caseTO,
			List<CustomTrackingRevisionEntity> revisionList) throws Exception {

		StringBuilder content = new StringBuilder();
		// step 1
		Document document = new Document();
		// step 2
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, baos);
		// step 3
		document.open();
		// step 4
		if (revisionList != null) {
			String title = "Audit log for Case Number : "
					+ caseTO.getCaseNumber();
			document.addTitle(title);
			document.addCreationDate();
			document.addAuthor("AFL(S) ?");
			document.addSubject("Case Id : " + caseTO.getCaseId());

			Paragraph hearderPara = new Paragraph(title + ", Operation Name : " + 
					caseTO.getOperationName(),	boldRedFont);
			hearderPara.setAlignment(Element.ALIGN_CENTER);
			
			addEmptyLine(hearderPara, 2);
			
			document.add(hearderPara); 
						
			for (CustomTrackingRevisionEntity curr : revisionList) {
				
				prepareFlowPara(curr, document);
			}
		}
		ByteArrayOutputStream txt = new ByteArrayOutputStream();
		PrintStream out = new PrintStream(txt);
		out.println(content);

		out.flush();
		out.close();

		PdfFileSpecification fs = PdfFileSpecification.fileEmbedded(writer,
				null, fullName, txt.toByteArray());
		writer.addFileAttachment(fs);
		// step 5
		document.close();

		return baos.toByteArray();

	}
	
	private byte[] generatePDFWithOutCase(String fileType, String fullName,
			List<CustomTrackingRevisionEntity> revisionList) throws Exception {

		StringBuilder content = new StringBuilder();
		// step 1
		Document document = new Document();
		// step 2
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, baos);
		// step 3
		document.open();
		// step 4
		if (revisionList != null) {
			document.addCreationDate();
			document.addAuthor("AFL(S) ?");

			Paragraph hearderPara = new Paragraph("",	boldRedFont);
			hearderPara.setAlignment(Element.ALIGN_CENTER);
			
			addEmptyLine(hearderPara, 2);
			
			document.add(hearderPara); 
						
			for (CustomTrackingRevisionEntity curr : revisionList) {
				
				prepareFlowPara(curr, document);
			}
		}
		ByteArrayOutputStream txt = new ByteArrayOutputStream();
		PrintStream out = new PrintStream(txt);
		out.println(content);

		out.flush();
		out.close();

		PdfFileSpecification fs = PdfFileSpecification.fileEmbedded(writer,
				null, fullName, txt.toByteArray());
		writer.addFileAttachment(fs);
		// step 5
		document.close();

		return baos.toByteArray();

	}

	private void prepareFlowPara(CustomTrackingRevisionEntity revEntity,
			Document document) throws Exception {

		if (null != revEntity && null != revEntity.getRevisionInfoList()) {

			List<RevisionedEntityInfo> revisedEntitiesList = revEntity
					.getRevisionInfoList();

			for (RevisionedEntityInfo entity : revisedEntitiesList) {
				
				if (null != entity && !entity.getPropertiesList().isEmpty()) {

					AuditDetails audit = ((AuditDetails) revEntity);
					
					Paragraph userPara = new Paragraph("User Name : " + audit.getUserName() 
							+ " , Actioned Date : " 
							+ ECMSConstants.datetimeFormat.format(
									new Date(audit.getCustomTimestamp())), boldBlueFont);

					addEmptyLine(userPara, 1);
					document.add(userPara);

					PdfPTable pdfTable = createEntityTable(entity);
					Paragraph entityPara = new Paragraph();
					entityPara.add(pdfTable);
					addEmptyLine(entityPara, 1);
					document.add(entityPara);
				}
			}
		}
		
	}

	private PdfPTable createEntityTable(RevisionedEntityInfo revisedEntity) {

		List<AuditedPropertyInfo> entityProperties = revisedEntity
				.getPropertiesList();
		PdfPTable table = new PdfPTable(3);

		PdfPCell cell = new PdfPCell(new Paragraph(
				revisedEntity.getEntityName() + "  "
						+ revisedEntity.getOperationType(), boldBlackFont));
		cell.setColspan(3);
		table.addCell(cell);
		table.addCell(new Phrase("Name", boldBlueFont));
		table.addCell(new Phrase("Previous Value", boldBlueFont));
		table.addCell(new Phrase("Modified Value", boldBlueFont));

		if (entityProperties != null) {

			for (AuditedPropertyInfo curr : entityProperties) {

				String name = curr.getPropertyName();

				String previousValue = curr.getPreviousValue();
				String newValue = curr.getModifiedValue();
				// addCell
				table.addCell(new Phrase(name, normalBlackFont));

				if (StringUtils.isNotEmpty(previousValue)
						&& previousValue.matches(US_DATE_FORMAT_REG_EXP)) {

					try {
						previousValue = ECMSConstants.datetimeFormat
								.format(dbFormat.parse(previousValue));

					} catch (Exception e) {

						log.error("ERROR while date conversion [Parsing, Formatting] :"
								+ e.getMessage());
					}
				}
				// addCell
				table.addCell(new Phrase(previousValue, normalBlackFont));

				if (StringUtils.isNotEmpty(newValue)
						&& newValue.matches(US_DATE_FORMAT_REG_EXP)) {

					try {
						newValue = ECMSConstants.datetimeFormat.format(dbFormat
								.parse(newValue));

					} catch (Exception e) {

						log.error("ERROR while date conversion [Parsing, Formatting] :"
								+ e.getMessage());
					}
				}
				// addCell
				table.addCell(new Phrase(newValue, normalBlackFont));
			}
		}

		return table;
	}

	private static void addEmptyLine(Paragraph paragraph, int number) {

		for (int i = 0; i < number; i++) {
			paragraph.add(new Paragraph(" "));
		}
	}
}
