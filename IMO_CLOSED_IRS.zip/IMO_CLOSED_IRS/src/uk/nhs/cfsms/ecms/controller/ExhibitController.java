package uk.nhs.cfsms.ecms.controller;

import static java.util.regex.Pattern.compile;

import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.Exhibit;
import uk.nhs.cfsms.ecms.data.cim.ExhibitDocuments;
import uk.nhs.cfsms.ecms.dto.cps.CPSDocumentsDTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.dto.witness.WitnessTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CPSDocumentService;
import uk.nhs.cfsms.ecms.service.ExhibitService;
import uk.nhs.cfsms.ecms.service.WitnessService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileExtensions;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileTypes;
import uk.nhs.cfsms.ecms.utility.FileUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;
import static uk.nhs.cfsms.ecms.ECMSConstants.EXHIBITS;
import static uk.nhs.cfsms.ecms.ECMSConstants.EXHIBITLABEL;

/**
 * @author rkatla
 *
 */
@Controller
public class ExhibitController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());

	private static final Map<String, byte[]> FILE_BYTES_MAP = new HashMap<String, byte[]>();

	@Autowired
	private AuditLogService auditLogFacade;

	@Autowired
	private ExhibitService exhibitFacade;

	@Autowired
	private CPSDocumentService cpsDocumentsService;

	@Autowired
	private WitnessService witnessFacade;

	/**
	 * Show Exhibits
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showExhibits.htm")
	public ModelAndView showExhibits(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		String caseID = null;
		Long caseIDLong = null;
		Map<String, Object> exhibitsMap = new HashMap<String, Object>();

		try {
			caseID = CaseUtil.getCaseId(request);

		} catch (CaseIDNotFoundException e) {
			logger.warn("Show Exhibits, No CaseId :" + e.getMessage());
			throw new ServletException(e.getMessage());
		}
		try {
			caseIDLong = new Long(caseID);
		} catch (NumberFormatException nfe) {
			log.error("NumberFormatException CaseID=" + caseID);
			throw nfe;
		}
		final List<Exhibit> exhibits = exhibitFacade.loadExhibits(caseIDLong);

		exhibitsMap.put("exhibitsSize", exhibits.size());
		exhibitsMap.put("exhibits", exhibits);
		exhibitsMap.put("caseID", caseID);
		return new ModelAndView("showExhibits", "exhibitsMap", exhibitsMap);
	}

	@RequestMapping(value = "/secure/uploadExhibit.htm", method = RequestMethod.GET)
	public String uploadExhibit(HttpServletRequest request,
			HttpServletResponse response, ModelMap model) throws Exception {

		final String exhibitId = request.getParameter("exhibitId");
		final String exhibit_type = request.getParameter("type");
		final String exhibitReference = request
				.getParameter("exhibitReference");

		logger.info("upload exhibit...");

		model.addAttribute("exhibitId", exhibitId);
		model.addAttribute("exhibitReference", exhibitReference);
		model.addAttribute("exhibit_type", exhibit_type);

		return "uploadExhibit";
	}

	@RequestMapping(value = "/secure/deleteExhibit.htm")
	public ModelAndView deleteExhibit(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		final String exhibitId = request.getParameter("exhibitId");

		try {
			exhibitFacade.deleteExhibit(Long.parseLong(exhibitId));
		} catch (ServiceException se) {
			log.error("Error deleting a case exhibit, id =" + exhibitId);
			throw new ServletException(se);
		}
		return new ModelAndView(new RedirectView("showExhibits.htm"));
	}

	@RequestMapping(value = "/secure/deleteExhibitDocument.htm")
	public ModelAndView deleteExhibitDocument(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		final String id = request.getParameter("docId");
		final String exhibitType = request.getParameter("deleteType");

		try {
			exhibitFacade.deleteExhibitDocument(new Long(id));
			AuditFlowThread.set("Exhibit document deleted");

		} catch (ServiceException se) {
			log.error("Error deleting a case exhibit document, id =" + id);
			throw new ServletException(se);
		}
		return new ModelAndView(new RedirectView(
				"showExhitbitDocuments.htm?type=" + exhibitType));
	}

	@RequestMapping(value = "/secure/editExhibit.htm")
	public ModelAndView showExhibit(HttpServletRequest request,
			HttpServletResponse response) throws NumberFormatException,
			Exception {

		String exhibitID = request.getParameter("exhibitID");
		final String caseId = request.getParameter("caseID");
		final Long caseID = new Long(caseId);

		Exhibit exhibit = new Exhibit();
		exhibit.setCaseId(caseID);

		if (exhibitID != null) {
			exhibit = exhibitFacade.loadExhibit(new Long(exhibitID));
		}

		exhibit.setWitnessList(getAllWitnessesByCaseId(caseID));

		ModelAndView mv = new ModelAndView("editExhibit", "exhibit", exhibit);
		return mv;

	}

	@RequestMapping(value = "/secure/createExhibit.htm")
	public ModelAndView createExhibit(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		final String caseId = request.getParameter("caseID");
		final Exhibit exhibit = new Exhibit();
		try {
			final Long caseID = new Long(caseId);
			exhibit.setCaseId(caseID);
			exhibit.setWitnessList(getAllWitnessesByCaseId(caseID));
		} catch (Exception e) {
			throw new ServletException(e);
		}

		ModelAndView mv = new ModelAndView("editExhibit", "exhibit", exhibit);
		return mv;

	}

	@RequestMapping(value = "/secure/validateExhibitFilename.htm")
	public ModelAndView validateFileName(MultipartHttpServletRequest request,
			HttpServletResponse response) throws IOException, ServiceException,
			CaseIDNotFoundException, ParseException {

		final HttpSession httpSession = request.getSession();
		final ObjectMapper mapper = new ObjectMapper();
		final String caseID = CaseUtil.getCaseId(request);
		final Iterator<String> itr = request.getFileNames();
		final MultipartFile mpf = request.getFile(itr.next());
		final String exhibitID = request.getParameter("exhibitId");
		String formType = request.getParameter("formType");
		final String fullFileName = mpf.getOriginalFilename();
		final byte[] fileBytes = mpf.getBytes();
		final String key = exhibitID + "-" + formType;
		FILE_BYTES_MAP.put(key, fileBytes);

		httpSession.setAttribute("fileBytesMap", FILE_BYTES_MAP);

		String documentNamingRule = null;

		List<InvalidFileNames> inValidNames = new ArrayList<InvalidFileNames>();

		inValidNames = validateAndSave((HttpServletRequest) request,
				httpSession, caseID, formType, fullFileName, fileBytes,
				documentNamingRule, inValidNames, exhibitID);
		final String invalidFiles = getDataInJsonFormat(mapper, inValidNames);
		FileCopyUtils.copy(invalidFiles, response.getWriter());

		return null;
	}

	@RequestMapping(value = "/secure/showExhitbitDocuments.htm")
	public ModelAndView showExhitbitDocuments(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServiceException,
			CaseIDNotFoundException, ParseException {
		final ObjectMapper mapper = new ObjectMapper();
		final Map<String, String> exhibitDocMap = new HashMap<String, String>();

		final String caseID = CaseUtil.getCaseId(request);
		final String exhibitType = request.getParameter("type");

		final List<Exhibit> exhibitList = exhibitFacade
				.loadAllExhibitDocuments(new Long(caseID), exhibitType);

		final String exhibitDocumentsJson = getExhibitsInJsonFormat(mapper,
				exhibitList);

		exhibitDocMap.put("caseID", caseID);
		exhibitDocMap.put("exhibitDocumentsJson", exhibitDocumentsJson);
		exhibitDocMap.put("exhibit_type", exhibitType);

		return new ModelAndView("exhibitDocumentsList", "exhibitDocMap",
				exhibitDocMap);
	}

	@RequestMapping(value = "/secure/downloadExhibitDocument.htm")
	public ModelAndView downloadExhibitDocument(
			final HttpServletRequest request, final HttpServletResponse response)
			throws ServletException {

		ModelAndView modelAndView = null;
		if (request.isRequestedSessionIdValid()) {

			if (logger.isDebugEnabled()) {
				logger.info("**Exhibit document download");
			}

			final String caseID = request.getParameter("caseId");
			final String documentID = request.getParameter("id");

			final CPSDocumentsDTO cpsDocumentsDTO = this.cpsDocumentsService
					.downloadCPSDocument(Long.parseLong(documentID),
							Long.parseLong(caseID), ECMSConstants.EXHIBITS,
							true);

			if (logger.isDebugEnabled()) {

				logger.debug("**Exhibit document download id=" + documentID);

				if (null != cpsDocumentsDTO) {
					logger.debug("**Exhibit document file, type="
							+ cpsDocumentsDTO.getFileType() + ", name="
							+ cpsDocumentsDTO.getFileName());
				}
			}
			try {
				if (null != cpsDocumentsDTO) {

					String fileNameWithExt = cpsDocumentsDTO.getFileName();
					final String fileType = cpsDocumentsDTO.getFileType();

					final String extension = FilenameUtils
							.getExtension(fileNameWithExt);

					if (FileExtensions
							.isValidExtension(extension.toLowerCase())) {
						response.setHeader("Content-Disposition",
								"attachment;filename=\"" + fileNameWithExt
										+ "\"");
					} else {
						if (extension.isEmpty()) {
							if (FileExtensions.isValidExtension(fileType
									.toLowerCase())) {
								fileNameWithExt = fileNameWithExt + "."
										+ fileType;
								response.setHeader("Content-Disposition",
										"attachment;filename=\""
												+ fileNameWithExt + "\"");
							} else {
								final FileTypes fileTypes = FileTypes
										.getExtention(fileType);
								if (fileTypes != null) {
									final String ext = fileTypes.toString();
									fileNameWithExt = fileNameWithExt + "."
											+ ext;
									response.setHeader("Content-Disposition",
											"attachment;filename=\""
													+ fileNameWithExt + "\"");
								}
							}
						}
						if (!extension.isEmpty()
								&& fileNameWithExt.startsWith("Ex.")) {
							if (FileExtensions.isValidExtension(fileType
									.toLowerCase())) {
								fileNameWithExt = fileNameWithExt + "."
										+ fileType;
								response.setHeader("Content-Disposition",
										"attachment;filename=\""
												+ fileNameWithExt + "\"");
							} else {
								final FileTypes fileTypes = FileTypes
										.getExtention(fileType);
								if (fileTypes != null) {
									final String ext = fileTypes.toString();
									fileNameWithExt = fileNameWithExt + "."
											+ ext;
									response.setHeader("Content-Disposition",
											"attachment;filename=\""
													+ fileNameWithExt + "\"");
								}
							}
						}
					}
					response.setContentType(cpsDocumentsDTO.getFileType());

					FileCopyUtils.copy(cpsDocumentsDTO.getFileBlob(),
							response.getOutputStream());
				}
			} catch (IOException e) {
				logger.error(ExceptionUtils.getStackTrace(e));
				throw new ServletException("Exception downloading CPS document");
			}
			modelAndView = null;
		} else {
			final String context = request.getContextPath();
			modelAndView = new ModelAndView(new RedirectView(context
					+ "/secure/welcome.htm"));
		}
		return modelAndView;
	}

	@RequestMapping(value = "/secure/updateAndSaveExhibits.htm")
	public ModelAndView updateAndSaveExhibits(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServiceException,
			CaseIDNotFoundException, ParseException {
		final HttpSession httpSession = request.getSession();
		final ObjectMapper mapper = new ObjectMapper();
		final String caseID = CaseUtil.getCaseId(request);
		final String invalidFileNames = request
				.getParameter("invalidFileNames");

		final String[] fileNames = invalidFileNames.split(",");
		String documentNamingRule = null;
		List<InvalidFileNames> inValidNames = new ArrayList<InvalidFileNames>();

		@SuppressWarnings("unchecked")
		final Map<String, byte[]> fileBytesMap = (HashMap<String, byte[]>) httpSession
				.getAttribute("fileBytesMap");

		for (String fileName : fileNames) {
			final String[] eachFileNames = fileName.split("<>");
			final String exhibitID = eachFileNames[0];
			final String formType = eachFileNames[1];
			final String fullFileName = eachFileNames[2];

			final String key = exhibitID + "-" + formType.toUpperCase();
			final byte[] fileBytes = fileBytesMap.get(key);
			inValidNames = validateAndSave(request, httpSession, caseID,
					formType, fullFileName, fileBytes, documentNamingRule,
					inValidNames, exhibitID);
		}
		final String invalidFiles = getDataInJsonFormat(mapper, inValidNames);
		FileCopyUtils.copy(invalidFiles, response.getWriter());
		return null;
	}

	/**
	 * @param request
	 * @param httpSession
	 * @param caseID
	 * @param formType
	 * @param fullFileName
	 * @param fileBytes
	 * @param documentNamingRule
	 * @param inValidNames
	 * @return
	 * @throws ServiceException
	 * @throws ParseException
	 */
	private List<InvalidFileNames> validateAndSave(HttpServletRequest request,
			final HttpSession httpSession, final String caseID,
			final String formType, final String fullFileName,
			final byte[] fileBytes, String documentNamingRule,
			List<InvalidFileNames> inValidNames, String exhibitID)
			throws ServiceException, ParseException {

		@SuppressWarnings("unchecked")
		Map<String, String> fileNamingRulesMap = (Map<String, String>) httpSession
				.getAttribute("fileNamingRulesMap");

		if (fileNamingRulesMap == null) {
			fileNamingRulesMap = this.cpsDocumentsService
					.getCPSDocumentsNamingRules();
			httpSession.setAttribute("fileNamingRulesMap", fileNamingRulesMap);
		}
		final String key = exhibitID + "-" + formType;
		documentNamingRule = getFileNamingRule(documentNamingRule, formType,
				fileNamingRulesMap);

		String fileName = null;

		if (!documentNamingRule.isEmpty()) {
			final Pattern pattern = compile(documentNamingRule);
			final String fileNameWithExt = fullFileName;

			final String extension = FilenameUtils
					.getExtension(fileNameWithExt);

			if (FileExtensions.isValidExtension(extension.toLowerCase())) {
				fileName = fileNameWithExt.substring(0,
						fileNameWithExt.indexOf("." + extension));
			} else {
				fileName = fileNameWithExt;
			}
			final Matcher matcher = pattern.matcher(fileName.trim());

			if (!matcher.matches()) {
				inValidNames = populateInvalidFileNames(formType, fullFileName,
						inValidNames, exhibitID);
			} else {
				uploadExhibitDocument(request, fullFileName, formType,
						fileBytes, caseID, key, exhibitID);
			}
		} else {
			uploadExhibitDocument(request, fullFileName, formType, fileBytes,
					caseID, key, exhibitID);
		}
		return inValidNames;
	}

	/**
	 * @param request
	 * @param fullFileName
	 * @param mgFormObject
	 * @throws ServiceException
	 * @throws ParseException
	 */
	private void uploadExhibitDocument(HttpServletRequest request,
			final String fullFileName, final String formType,
			final byte[] fileBytes, final String caseID, final String key,
			final String exhibitID) throws ServiceException, ParseException {

		final String fileType = FileUtils.getExtension(fullFileName);
		final Long exhibitId = new Long(exhibitID);

		final Exhibit exhibit = new Exhibit();
		exhibit.setExhibitId(exhibitId);

		if (exhibitID != null && !exhibitID.isEmpty()) {
			final ExhibitDocuments exhibitDocuments = new ExhibitDocuments();
			exhibitDocuments.setExhibitType(formType.toUpperCase());
			exhibitDocuments.setExhibit(exhibit);
			exhibitDocuments.setUploadedOn(new java.sql.Date(new Date()
					.getTime()));
			exhibitDocuments.setFileName(fullFileName);
			exhibitDocuments.setFileExtension(fileType);
			exhibitDocuments.setDocument(fileBytes);

			exhibitFacade.saveExhibitDocuments(exhibitDocuments);

			FILE_BYTES_MAP.remove(key);
		}

	}

	@RequestMapping(value = "/secure/updateExhibit.htm")
	public ModelAndView updateExhibit(HttpServletRequest request)
			throws ServiceException, ParseException, CaseIDNotFoundException {

		final String caseID = CaseUtil.getCaseId(request);
		final String exhibitID = request.getParameter("exhibitId");
		final String referenceNumber = request.getParameter("reference");
		final String description = request.getParameter("description");
		String fromPlacePerson = request.getParameter("fromPlacePerson");
		final String disclosureState = request.getParameter("disclosureState");

		if (exhibitID != null && !exhibitID.isEmpty()) {
			final Exhibit exhibit = (Exhibit) exhibitFacade.getObject(
					Exhibit.class, new Long(exhibitID));

			exhibit.setCreatedDate(new Date());
			SessionUser sesUser = EcmsUtils.getSessionUserObject(request
					.getSession());
			exhibit.setCreatedStaffId(null != sesUser ? sesUser.getStaffId()
					: "");
			exhibit.setReference(referenceNumber);
			exhibit.setDescription(description);
			exhibit.setFromPlacePerson(fromPlacePerson);
			exhibit.setDisclosureState(disclosureState);
			exhibit.setCaseId(Long.parseLong(caseID));
			exhibitFacade.updateExhibit(exhibit);
			AuditFlowThread.set("Exhibit Updated");
		}

		return null;
	}

	@RequestMapping(value = "/secure/saveExhibit.htm")
	public ModelAndView saveExhibit(HttpServletRequest request)
			throws ServiceException, ParseException, CaseIDNotFoundException {

		final String caseID = CaseUtil.getCaseId(request);
		final String referenceNumber = request.getParameter("reference");
		final String description = request.getParameter("description");
		String fromPlacePerson = request.getParameter("fromPlacePerson");
		final String disclosureState = request.getParameter("disclosureState");

		if (fromPlacePerson.isEmpty()) {
			fromPlacePerson = null;
		}

		final Exhibit exhibit = new Exhibit();

		exhibit.setCreatedDate(new Date());
		SessionUser sesUser = EcmsUtils.getSessionUserObject(request
				.getSession());
		exhibit.setCreatedStaffId(null != sesUser ? sesUser.getStaffId() : "");
		exhibit.setReference(referenceNumber);
		exhibit.setDescription(description);
		exhibit.setFromPlacePerson(fromPlacePerson);
		exhibit.setDisclosureState(disclosureState);
		exhibit.setCaseId(Long.parseLong(caseID));

		AuditFlowThread.set("Exhibit Created");
		exhibitFacade.saveObject(exhibit);
		createAudit(exhibit, AuditLogService.CREATE, "Case Exhibit", request,
				auditLogFacade);

		return null;
	}

	/**
	 * @param formType
	 * @param fullFileName
	 * @param fileBytes
	 * @param inValidNames
	 * @param id
	 */
	private List<InvalidFileNames> populateInvalidFileNames(
			final String formType, final String fullFileName,
			final List<InvalidFileNames> inValidNames, String exhibitID) {
		final InvalidFileNames invalidFileNames = new InvalidFileNames(
				exhibitID, formType, fullFileName);
		inValidNames.add(invalidFileNames);
		return inValidNames;
	}

	/**
	 * This method is responsible to get file naming rule for given document
	 * category.
	 * 
	 * @param String
	 *            documentCategory
	 * @param String
	 *            documentNamingRule
	 * @param String
	 *            formType
	 * @param Map
	 *            <String, String> fileNamingRulesMap
	 * 
	 * @return String
	 */

	private String getFileNamingRule(String documentNamingRule,
			final String formType, final Map<String, String> fileNamingRulesMap) {

		if (EXHIBITS.equals(formType)) {
			documentNamingRule = fileNamingRulesMap.get("Exhibits");
		} else if (EXHIBITLABEL.equals(formType)) {
			documentNamingRule = fileNamingRulesMap.get("ExhibitLabel");
		} else {
			documentNamingRule = fileNamingRulesMap.get(formType);
		}

		documentNamingRule = documentNamingRule != null ? documentNamingRule
				.trim() : "";
		return documentNamingRule;
	}

	private String getExhibitsInJsonFormat(final ObjectMapper mapper,
			final List<Exhibit> list) {
		String data = null;
		try {
			data = mapper.writeValueAsString(list);
		} catch (JsonGenerationException e) {
			logger.error("Got JsonGenerationException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (JsonMappingException e) {
			logger.error("Got JsonMappingException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {
			logger.error("Got IOException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		}
		return data;
	}

	private String getDataInJsonFormat(final ObjectMapper mapper,
			final List<InvalidFileNames> list) {
		String data = null;
		try {
			data = mapper.writeValueAsString(list);
		} catch (JsonGenerationException e) {
			logger.error("Got JsonGenerationException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (JsonMappingException e) {
			logger.error("Got JsonMappingException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {
			logger.error("Got IOException while generating Json string from invalidFilesList "
					+ ExceptionUtils.getStackTrace(e));
		}
		return data;
	}

	private List<WitnessTO> getAllWitnessesByCaseId(final Long caseId)
			throws Exception {
		return witnessFacade.loadAllWitnessesByCaseIdForExhibit(caseId);
	}

	private WitnessTO getWitnessesById(final Long witnessId) throws Exception {
		return witnessFacade.loadWitnessesByIdForExhibit(witnessId);
	}

	@SuppressWarnings("unused")
	private static class InvalidFileNames implements Serializable {
		private static final long serialVersionUID = 1L;
		private String exhibitID;
		private String formType;
		private String fullFileName;

		public InvalidFileNames(final String exhibitID, final String formType,
				final String fullFileName) {
			this.exhibitID = exhibitID;
			this.formType = formType;
			this.fullFileName = fullFileName;
		}

		/**
		 * @return the serialversionuid
		 */
		public static long getSerialversionuid() {
			return serialVersionUID;
		}

		/**
		 * @return the exhibitID
		 */
		public String getExhibitID() {
			return exhibitID;
		}

		/**
		 * @return the formType
		 */
		public String getFormType() {
			return formType;
		}

		/**
		 * @return the fullFileName
		 */
		public String getFullFileName() {
			return fullFileName;
		}

	}

	/**
	 * @param exhibitFacade
	 *            The exhibitFacade to set.
	 */
	public void setExhibitFacade(ExhibitService exhibitFacade) {
		this.exhibitFacade = exhibitFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
