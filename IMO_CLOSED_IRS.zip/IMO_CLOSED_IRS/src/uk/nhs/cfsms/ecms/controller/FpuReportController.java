package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.fpureport.FpuReportSubType;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.dto.caseInfo.FpuReportTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.AppealOutcomeTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.FpuReportService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;
@Controller
public class FpuReportController {
	@Autowired
	private FpuReportService fpuReportFacade;
	@Autowired
	private AuditLogService auditLogFacade;
	
	protected final Log logger = LogFactory.getLog(getClass());
	
	@RequestMapping(value="/secure/savefpureport.htm")
	public ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, @ModelAttribute("fpuReportObject") FpuReportTO fpuTO, BindingResult errors)
			throws Exception {

		String caseID = null;

		try {
			caseID = CaseUtil.getCaseId(request);
			
		} catch (CaseIDNotFoundException e) {
			
			logger.error(e);
			return new ModelAndView("casePortal");
		}
		if (EcmsUtils.onSave(request)) {
			
			logger.info("onSubmitSave");
			fpuTO.setCaseId(new Long(caseID));
			fpuTO.setReportSubTypes(getRiskAreaSubTypeList(request, fpuTO));
			fpuTO.setCreatedTime(new Date());
			fpuTO.setCreatedStaffId(EcmsUtils.getSessionUserObject(
					request.getSession()).getStaffId());
			
			if (fpuTO.getFpuReportId() ==  null || fpuTO.getFpuReportId() == 0L){
				
				AuditFlowThread.set("FPU System Weaknesses Report Created");
			} else {
				
				AuditFlowThread.set("FPU System Weaknesses Report Updated");
			}
			try {
				fpuReportFacade.saveFpuReport(fpuTO);
			
				createAudit(fpuTO, AuditLogService.UPDATE, "Adding FPU Report Data", request, auditLogFacade);
				
				fpuTO = fpuReportFacade.loadFpuReportByCaseId(fpuTO.getCaseId());
			
			}catch(Exception e) {
				
				logger.error("ERROR saving FPU report :" + e.getMessage());
				
			}
			if (null != fpuTO.getFpuReportId() ) {
				
				return new ModelAndView("fpureportsuccess");
			}
			
		} else if (EcmsUtils.onCancelPage(request)) {
			
			logger.info("onSubmitCancel");
			
			return new ModelAndView(new RedirectView(CaseUtil.SHOW_CASE_PAGE
					+ caseID));
			
		} else if (EcmsUtils.onClose(request)) {
			
			logger.info("onSubmitClose");
			//TODO:
		}

		return new ModelAndView("fpureport", "fpuReportObject", fpuTO);
	}
	
	

	@RequestMapping(value="/secure/viewfpureport.htm")
	protected ModelAndView formBackingObject(HttpServletRequest request)
			throws ServletException {
		ModelAndView mAV = new ModelAndView("fpureport");
		logger.info("** FormBackingObject().");

		String caseID = null;
		
		FpuReportTO reportTO = null;
		
		try {
			caseID = CaseUtil.getCaseId(request);
			
		} catch (CaseIDNotFoundException e) {
			logger.error(e);
			// TODO-please revisit this block of code.-venkat
			return new ModelAndView("casePortal");
		}
		try {
			reportTO = fpuReportFacade.loadFpuReportByCaseId(new Long(caseID));
			
			if (null == reportTO) {
				
				InformationView info = fpuReportFacade.loadInformationByCaseId(new Long(caseID));
				if(info != null){
				   reportTO = fpuReportFacade.loadFpuReportByInfoId(info.getInformationId());
				}
			}
			if (null == reportTO) {
				
				reportTO = new FpuReportTO();	
			}
			reportTO = fpuReportFacade.loadAllListTypes(reportTO);
			
			if (!EcmsUtils.onSave(request)) {
				
				List<FpuReportSubType> subTypeList = reportTO.getReportSubTypes();
				
				if (null != subTypeList && !subTypeList.isEmpty()) {
					
					setLists(reportTO);
				}
			}

		} catch (ServiceException e) {
			
			throw new ServletException(e);
		}
		return mAV.addObject("fpuReportObject", reportTO);
		//return reportTO;

	}

	
	public List<FpuReportSubType> getRiskAreaSubTypeList(
			HttpServletRequest request, FpuReportTO fpuTO) {

		List<FpuReportSubType> subType = new ArrayList<FpuReportSubType>();

		if (null != fpuTO.getAreaList()) {
			for (int i = 0; i < fpuTO.getAreaList().size(); i++) {
				String param = "checkedarea" + (i);
				String value = "valuearea" + (i);

				if (request.getParameter(param) != null
						&& request.getParameter(param).equalsIgnoreCase("true")) {

					FpuReportSubType report = new FpuReportSubType();
					report.setFpuReportId(fpuTO.getFpuReportId());
					report.setLookupId(new Long(request.getParameter(value)));
					report.setTypeName(ECMSConstants.FPU_AREA_TYPE);
					subType.add(report);
				}
			}
		}

		if (null != fpuTO.getActionList()) {
			for (int i = 0; i < fpuTO.getActionList().size(); i++) {
				String param = "checkedaction" + (i);
				String value = "valueaction" + (i);

				if (request.getParameter(param) != null
						&& request.getParameter(param).equalsIgnoreCase("true")) {

					FpuReportSubType report = new FpuReportSubType();
					report.setFpuReportId(fpuTO.getFpuReportId());
					report.setLookupId(new Long(request.getParameter(value)));
					report.setTypeName(ECMSConstants.FPU_ACTION_TYPE);
					subType.add(report);
				}
			}
		}

		if (null != fpuTO.getWeaknessList()) {
			for (int i = 0; i < fpuTO.getWeaknessList().size(); i++) {
				String param = "checkedweakness" + (i);
				String value = "valueweakness" + (i);

				if (request.getParameter(param) != null
						&& request.getParameter(param).equalsIgnoreCase("true")) {

					FpuReportSubType report = new FpuReportSubType();
					report.setFpuReportId(fpuTO.getFpuReportId());
					report.setLookupId(new Long(request.getParameter(value)));
					report.setTypeName(ECMSConstants.FPU_SYS_WEAKNESS_TYPE);
					subType.add(report);
				}
			}
		}

		if (null != fpuTO.getFraudList()) {
			for (int i = 0; i < fpuTO.getFraudList().size(); i++) {
				String param = "checkedfraud" + (i);
				String value = "valuefraud" + (i);

				if (request.getParameter(param) != null
						&& request.getParameter(param).equalsIgnoreCase("true")) {

					FpuReportSubType report = new FpuReportSubType();
					report.setFpuReportId(fpuTO.getFpuReportId());
					report.setLookupId(new Long(request.getParameter(value)));
					report.setTypeName(ECMSConstants.FPU_FRAUD_TYPE);
					subType.add(report);
				}
			}
		}

		return subType;
	}

	
	private void setLists(FpuReportTO reportTO) {
		
		List<FpuReportSubType> list = reportTO.getReportSubTypes();
		List<FpuReportSubType> actionList = new ArrayList();
		List<FpuReportSubType> weaknessList = new ArrayList();
		List<FpuReportSubType> fraudList = new ArrayList();
		List<FpuReportSubType> areaList = new ArrayList();

		for (FpuReportSubType type : list) {
			if (type.getTypeName() != null
					&& type.getTypeName().equalsIgnoreCase(
							ECMSConstants.FPU_ACTION_TYPE))
				actionList.add(type);
			if (type.getTypeName() != null
					&& type.getTypeName().equalsIgnoreCase(
							ECMSConstants.FPU_AREA_TYPE))
				areaList.add(type);
			if (type.getTypeName() != null
					&& type.getTypeName().equalsIgnoreCase(
							ECMSConstants.FPU_SYS_WEAKNESS_TYPE))
				weaknessList.add(type);
			if (type.getTypeName() != null
					&& type.getTypeName().equalsIgnoreCase(
							ECMSConstants.FPU_FRAUD_TYPE))
				fraudList.add(type);

		}
		if (!actionList.isEmpty()) {
			setReportList(1, actionList, reportTO);
		}
		if (!weaknessList.isEmpty()) {
			setReportList(2, weaknessList, reportTO);
		}
		if (!areaList.isEmpty()) {
			setReportList(3, areaList, reportTO);
		}
		if (!fraudList.isEmpty()) {
			setReportList(4, fraudList, reportTO);
		}
	}
	

	private void setReportList(int type, List<FpuReportSubType> list,
			FpuReportTO reportTO) {

		switch (type) {
			case 1: {
				for (FpuReportSubType type1 : list) {
	
					setSelectedListItem(type1, reportTO.getActionList());
				}
				break;
			}
			case 2: {
				for (FpuReportSubType type2 : list) {
	
					setSelectedListItem(type2, reportTO.getWeaknessList());
				}
				break;
			}
			case 3: {
				for (FpuReportSubType type3 : list) {
	
					setSelectedListItem(type3, reportTO.getAreaList());
				}
				break;
			}
			case 4: {
				for (FpuReportSubType type4 : list) {
	
					setSelectedListItem(type4, reportTO.getFraudList());
				}
				break;
			}
		}

	}

	private void setSelectedListItem(FpuReportSubType type,	List<LookupView> list) {
		
		for (LookupView view : list) {
			
			if (view.getLookupId().intValue() == type.getLookupId().intValue()) {
				
				view.setSelected(true);
				return;
			}
		}
	}

	/**
	 * Setter for FPU Report Facade.
	 * 
	 * @param fpuReportFacade
	 */
	public void setFpuReportFacade(FpuReportService fpuReportFacade) {
		
		this.fpuReportFacade = fpuReportFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		
		this.auditLogFacade = auditLogFacade;
	}
	
	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			logger.error(e);
		}
	}
	
}
