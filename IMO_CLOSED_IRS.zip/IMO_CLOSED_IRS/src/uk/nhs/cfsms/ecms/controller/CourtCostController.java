package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.CaseCourtCosts;
import uk.nhs.cfsms.ecms.data.cim.ExpectedCourtCost;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseCourtCostsTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.AppealOutcomeTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.SoiCostService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;
@Controller
public class CourtCostController {

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	SoiCostService soiCostsFacade;
	@Autowired
	CaseService caseService;
	@Autowired
	private AuditLogService auditLogFacade;

	@RequestMapping(value="/secure/savecourtcosts.htm")
	public ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, @ModelAttribute("courtCostObject") CaseCourtCostsTO costTO, BindingResult errors)
			throws Exception {

		logger.info("onSubmit");

		//CaseCourtCostsTO costTO = (CaseCourtCostsTO) command;
		
		String caseID = CaseUtil.getCaseId(request);

		try {
			CaseTO caseTO = caseService.loadCase(new Long(caseID));

			if (null != caseTO
					&& null != caseTO.getProsecuter()
					&& !caseTO.getProsecuter().equalsIgnoreCase(
							ECMSConstants.SOLP)) {

				return new ModelAndView("courtcostmessage");
			}
		} catch (ServiceException e) {
			throw new ServletException(e);
		}

		if (EcmsUtils.onSave(request)) {

			List<CaseCourtCosts> costList = getCaseCourtList(new Long(caseID), request, costTO.getCostList());
			AuditFlowThread.set("Court Case Costs Updated");
			soiCostsFacade.saveCourtCosts(costList, new Long(caseID));
			

			if (null != costList && !costList.isEmpty()) {
				costTO.setCostList(soiCostsFacade.loadExpectedCourtCosts());
				setSelectedCosts(costList, costTO.getCostList());
			}
			createAudit(costTO, AuditLogService.UPDATE, "Adding Court Case Costs", request, auditLogFacade);

			return new ModelAndView("courtcostssavemessage");
		}
		if (EcmsUtils.onClose(request)) {

		}
		return new ModelAndView("courtcosts", "courtCostObject", costTO);
	}
	
	private List<CaseCourtCosts> getCaseCourtList(Long caseID, HttpServletRequest request, List costList) {

		List<CaseCourtCosts> courtCosts = new ArrayList<CaseCourtCosts>();
		
		java.util.Date createdDate = new java.util.Date();
		
		for (int i = 0; i < costList.size(); i++) {

			String param = "checked" + (i + 1);
			String paramStr = request.getParameter(param);
			
			ExpectedCourtCost expcost = (ExpectedCourtCost) costList.get(i);
			
			if (null != paramStr && paramStr.equalsIgnoreCase("true")) {
				CaseCourtCosts costs = new CaseCourtCosts();
				costs.setCaseId(caseID);
				costs.setExpctCostId(expcost.getExpctCourtCostId());
				costs.setCreatedDate(createdDate);
				courtCosts.add(costs);
			}
		}
		return courtCosts;
	}

	@RequestMapping(value="/secure/viewcourtcosts.htm")
	protected ModelAndView formBackingObject(HttpServletRequest request)
			throws ServletException {
		ModelAndView mAV = new ModelAndView("courtcosts");
		logger.info("formBackingObject().");
		
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		CaseCourtCostsTO costsTO = new CaseCourtCostsTO();

		try {
			List<CaseCourtCosts> costs = soiCostsFacade.loadCourtCaseCostsByCaseId(new Long(caseID));
			
			List<ExpectedCourtCost> exptCosts = soiCostsFacade.loadExpectedCourtCosts();
			
			if (costs != null && costs.size() > 0) {
				setSelectedCosts(costs, exptCosts);
			}
			costsTO.setCostList(exptCosts);
		} catch (ServiceException e) {
			throw new ServletException(e);
		}
	
		return mAV.addObject("courtCostObject", costsTO);
	}
	
	private void setSelectedCosts(List<CaseCourtCosts> costs,
			List<ExpectedCourtCost> exptCosts) {

		for (CaseCourtCosts cost : costs) {
			logger.info("*CaseCourtCosts=" + cost.getCourtCostId());
			for (ExpectedCourtCost expCost : exptCosts) {
				if (expCost.getExpctCourtCostId().intValue() == cost.getExpctCostId().intValue()) {
					expCost.setSelected(true);
					break;
				}
			}
		}
	}

	/**
	 * SETTERS
	 */
	public void setCaseService(CaseService caseService) {
		this.caseService = caseService;
	}

	public void setSoiCostsFacade(SoiCostService soiCostsFacade) {
		this.soiCostsFacade = soiCostsFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
	
	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			logger.error(e);
		}
	}
	
}