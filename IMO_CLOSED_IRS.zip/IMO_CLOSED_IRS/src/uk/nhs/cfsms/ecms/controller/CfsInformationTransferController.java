package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.data.cim.InformationObject;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.InformationPermission;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.MessageService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

@Controller
public class CfsInformationTransferController extends BaseFormController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private CaseService caseFacade;
	@Autowired
	private MessageService messageFacade;

	@RequestMapping(value = "/secure/cfsinfotransfer.htm")
	public ModelAndView processFormSubmission(HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("caseObject") CaseTO caseInfo, BindingResult errors)
			throws Exception {
		if (log.isDebugEnabled()) {
			log.debug("ProcessFormSubmission");
		}
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		String actionType = request.getParameter("actionType");
		String id = request.getParameter("transferInfoId");
		String orgCode = request.getParameter("orgCode");
		String teamCode = request.getParameter("teamCode");

		if (actionType.equalsIgnoreCase("cfsinfotransferview")) {
			CaseTO caseTo = new CaseTO();
			caseTo.setInformationId(new Long(id));
			caseTo.setOrgCode(orgCode);
			caseTo.setTeamCode(teamCode);
			caseTo.setTeamList(caseFacade.listTeamsByTeamCode(new String[] {
					ECMSConstants.TEAM_CIU, ECMSConstants.TEAM_FPU }));
			return new ModelAndView("cfsInfoTransferView", "caseInfo", caseTo);
		}

		if (actionType.equalsIgnoreCase("cfsinfotransfer")) {
			return handleTransferInfoToTeam(request, response, errors,
					caseInfo, user);
		}
		return null;
	}

	private ModelAndView handleTransferInfoToTeam(HttpServletRequest request,
			HttpServletResponse response, BindingResult errors,
			CaseTO caseInfo, SessionUser user) throws Exception {

		//CaseTO caseInfo = (CaseTO) command;
		String transferTeam = caseInfo.getTransferTeam();

		InformationObject infoObj = caseFacade.loadInfoObjectOnly(caseInfo
				.getInformationId());
		infoObj.setState(ECMSConstants.INFO_TRANSFERRED);

		// update information permission to new team.
		InformationPermission permission = caseFacade
				.updateInfoTransferToNewTeam(caseInfo.getTransferTeam(),
						caseInfo.getInformationId(), user);
		caseFacade.updateTransferInformation(caseInfo, true);

		caseFacade.saveInfoOnly(infoObj);

		createAudit(caseInfo, AuditLogService.UPDATE,
				"Transfer Case to new team", request, auditLogFacade);
		String message = request.getParameter("message");

		MessageTO messageTO = new MessageTO();
		messageTO.setMessage(message);
		messageTO.setInformationId(caseInfo.getInformationId());
		messageTO.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER
				.toString());

		if (!setStaffDetails(messageTO, user, transferTeam)) {
			return new ModelAndView("noofmmessage");
		}

		messageTO = messageFacade.saveMessage(messageTO);
		createAudit(messageTO, AuditLogService.UPDATE, "Adding Message",
				request, auditLogFacade);

		if (messageTO.getMessageId() != null) {
			return new ModelAndView("transferInfoSuccess");
		}
		if (permission != null
				&& permission.getPermissionValue().equalsIgnoreCase(
						caseInfo.getTransferTeam())) {
			return new ModelAndView("transferInfoSuccess");
		}
		return new ModelAndView("transferInfoUnsuccess");
	}

	public boolean setStaffDetails(MessageTO messageTO, SessionUser user,
			String teamCode) throws ServiceException {

		messageTO.setFromStaffId(user.getStaffId());
		messageTO.setCreatedStaffId(user.getStaffId());
		messageTO.setCreatedTime(new Date());

		InformationView info = messageFacade.loadInformationViewById(messageTO
				.getInformationId());

		UserObject ofmObj = messageFacade.loadOFMByTeamOrOrgCode(teamCode,
				false);

		if (ofmObj != null) {
			messageTO.setToStaffId(ofmObj.getStaffId());
			messageTO.setToStaffName(EcmsUtils.getFullName(ofmObj));
		} else {
			return false;
		}

		messageTO.setFromStaffName(user.getFullName());
		messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
		messageTO.setInformationRef(info.getCreatedStaffId() + "#"
				+ info.getInformationId());
		messageTO.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER
				.toString());
		return true;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

	public void setMessageFacade(MessageService messageFacade) {
		this.messageFacade = messageFacade;
	}

}
