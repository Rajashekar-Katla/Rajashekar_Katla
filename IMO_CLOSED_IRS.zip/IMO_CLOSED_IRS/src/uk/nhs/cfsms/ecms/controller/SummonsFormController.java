package uk.nhs.cfsms.ecms.controller;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.sanction.ChargeList;
import uk.nhs.cfsms.ecms.data.sanction.Summons;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.SummonsService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
@RequestMapping("/secure/saveSummons.htm")
//public class SummonsFormController extends BaseFormController {
public class SummonsFormController {
	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private SummonsService summonsFacade;

	/*public SummonsFormController() {
		setSessionForm(true);
		setCommandName("summons");
		setCommandClass(Summons.class);
	}*/

	/*protected Object formBackingObject(HttpServletRequest request)
			throws ServletException {*/
	@RequestMapping(method = RequestMethod.GET)
	protected String initForm(ModelMap model, 
							  HttpServletRequest request) 
										throws ServletException {
		String action = request.getParameter(CaseUtil.ACTION_TYPE_PARAM);
		Summons summons = new Summons();
		if (action != null && action.equalsIgnoreCase(CaseUtil.VIEW_PARAM)) {
			String id = request.getParameter("summonsId");
			if (id != null && id.length() != 0) {
				try {
					summons = (Summons) summonsFacade.getObject(Summons.class,
							new Long(id));

				} catch (ServiceException e) {
					log.error("Exception loading summons with id " + id + " @"
							+ e.getMessage());
					log.error(e);
				}
			} else {
				String sanctionID = request
						.getParameter(CaseUtil.SANCTION_ID_PARAM);
				summons = new Summons();
				summons.setCriminalSanctionId(new Long(sanctionID));
			}
		}
		model.addAttribute("summons", summons);
		//return summons;
		return "summons";
	}

	/*@Override
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object object, BindException errors)
			throws Exception {*/
	@RequestMapping(method = RequestMethod.POST)
	protected ModelAndView processSubmit(@ModelAttribute("summons") Summons summons,
			                        HttpServletRequest request)
			                        		throws Exception {

		//Summons summons = (Summons) object;

		summons.setCreatedTime(new Date());
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		summons.setCreatedStaffId(user.getStaffId());
        if(null == summons.getSummonsId() || (summons.getSummonsId() == 0L)){
        	AuditFlowThread.set("Summons Created");
        } else {
        	AuditFlowThread.set("Summons Updated");
        }
		summonsFacade.saveObject(summons);
		createAudit(summons, AuditLogService.CREATE, "Summons Created", request, auditLogFacade);

		String params = CaseUtil.SANCTION_ID_PARAM + "="
				+ summons.getCriminalSanctionId();
		return new ModelAndView(new RedirectView("showSummons.htm?" + params));

	}

	/**
	 * @return Returns the summonsFacade.
	 */
	public SummonsService getSummonsFacade() {
		return summonsFacade;
	}

	/**
	 * @param summonsFacade
	 *            The summonsFacade to set.
	 */
	public void setSummonsFacade(SummonsService summonsFacade) {
		this.summonsFacade = summonsFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	@InitBinder
	protected void initBinder(HttpServletRequest servletRequest,
			ServletRequestDataBinder binder) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("\n initBinder"); 
		}

		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, nf, true));
		binder
				.registerCustomEditor(String.class, new StringTrimmerEditor(
						true));
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null,
				new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}
	
	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			log.error(e);
		}
	}
	
}
