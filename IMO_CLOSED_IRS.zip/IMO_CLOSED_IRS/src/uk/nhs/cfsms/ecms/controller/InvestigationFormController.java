package uk.nhs.cfsms.ecms.controller;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.InvestigationActionPlan;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseCourtCostsTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.InvestigationTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.InvestigationService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.SqlDateEditor;
import uk.nhs.cfsms.ecms.utility.UtilDateEditor;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

/**
 * Case Investigation Controller.
 *
 */
@Controller
public class InvestigationFormController {

	@Autowired
	InvestigationService investigationFacade;

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;

	public InvestigationFormController() {
		/*this.setSessionForm(false);
		this.setCommandName("investigationTO");
		this.setCommandClass(InvestigationTO.class);*/
	}

	@RequestMapping(value="/secure/addCaseInvestigation.htm")
	protected ModelAndView formBackingObject(HttpServletRequest request)
			throws Exception {
		ModelAndView mAV = new ModelAndView("createInvestigation");
		log.info("InvestigationFormController.formBackingObject().");
		String caseID = CaseUtil.getCaseId(request);

		InvestigationTO dto = new InvestigationTO();

		if (StringUtils.isNotEmpty(caseID)) {
			dto.setCaseId(new Long(caseID));
		}

		String id = request.getParameter(CaseUtil.INVESTIGATION_ID_PARAM);

		if (StringUtils.isNotEmpty(id)) {
			if (log.isInfoEnabled()) {
				log.info("Loading Investigation Id =" + id);
			}
			NumberFormat fmt = NumberFormat.getInstance();
			Long invId = null;
			if (id != null) {
				invId = fmt.parse(id).longValue();
			}
			dto = investigationFacade.loadInvestigationById(invId);
		}
		// Check the Investigation Action Plan as well...
		List<InvestigationActionPlan> iAPList = dto
				.getInvestigationActionList();
		if (null == iAPList  || (null != iAPList && iAPList.isEmpty())
				|| EcmsUtils.onNew(request)) {

			log.info("Creating new Action Plan.");

			this.createNewInvestigationActionPlan(dto);
		}

		return mAV.addObject("investigationTO", dto);
	}

	@RequestMapping(value="/secure/caseInvestigation.htm")
	public ModelAndView processFormSubmission(HttpServletRequest request,
			HttpServletResponse response, @ModelAttribute("investigationTO") InvestigationTO dto, BindingResult errors)
			throws Exception {

		log.info("InvestigationFormController.processFormSubmission().");
		String dispatch = request.getParameter("dispatch");
		if(dispatch != null){
			return formBackingObject(request);
		}

		ModelAndView mAV = new ModelAndView("createInvestigation");

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		if (null == user) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}
		if (EcmsUtils.onCancel(request)) {
			return CaseUtil.getInvestigationListView();
		}
		//InvestigationTO dto = (InvestigationTO) command;

		//validateInvestigation(dto, request, errors);

		if (errors.getErrorCount() < 1) {
			// Check your actions.
			if (EcmsUtils.onFinish(request)) {

				if (dto.getInvestigationActionList() != null) {
					this.updateNewActionPlans(dto, user);
				}

				if (dto.getInvestigationId() == null) {

					dto.setCreatedStaffId(user.getStaffId());
					dto.setCreatedDate(EcmsUtils.getCurrentTimeStamp());
					AuditFlowThread.set("Case Investigation Created");
					investigationFacade.saveInvestigation(dto);
					createAudit(dto, AuditLogService.CREATE,
							"Case Investigation Created", request,
							auditLogFacade);
				} else {
					AuditFlowThread.set("Case Investigation Updated");
					investigationFacade.updateInvestigation(dto);
					createAudit(dto, AuditLogService.UPDATE,
							"Case Investigation Updated", request,
							auditLogFacade);
				}

				return CaseUtil.getInvestigationListView();
			}

			if (EcmsUtils.onDelete(request)) {
				AuditFlowThread.set("Case Investigation Deleted");
				investigationFacade.deleteInvestigation(dto);
				createAudit(dto, AuditLogService.DELETE,
						"Case Investigation Deleted", request, auditLogFacade);
				return CaseUtil.getInvestigationListView();
			}

		} else {
			/*return super.processFormSubmission(request, response, command,
					errors);*/
			mAV.addObject(errors.getModel());
		}
		mAV.addObject("investigationTO", dto);
		return mAV;
	}

	/**
	 * Update New Action Plans.
	 * 
	 * @param dto
	 * @param user
	 */
	private void updateNewActionPlans(InvestigationTO dto, SessionUser user) {

		for (InvestigationActionPlan action : dto.getInvestigationActionList()) {

			if (action.getActionPlanId() == null) {

				action.setCreatedStaffId(user.getStaffId());
				action.setCreatedDate(EcmsUtils.getCurrentTimeStamp());
			}
		}
	}

	/**
	 * Validate Investigation details.
	 * 
	 * @param dto
	 * @param request
	 * @param errors
	 */
	private void validateInvestigation(InvestigationTO dto,
			HttpServletRequest request, BindingResult errors) {
		// TODO Auto-generated method stub
		log.info("** InvestigationFormController.validateInvestigation()");

	}

	/**
	 * Create New InvestigationActionPlan
	 * 
	 * @param dto
	 */
	private void createNewInvestigationActionPlan(InvestigationTO dto)
			throws Exception {
		InvestigationActionPlan actionPlan = new InvestigationActionPlan();
		NumberFormat fmt = NumberFormat.getInstance();
		if (dto.getInvestigationId() == null) {
			actionPlan.setInvestigationId(dto.getInvestigationId());
		} else {
			actionPlan.setInvestigationId(fmt.parse(
					dto.getInvestigationId().toString()).longValue());
		}

		dto.getInvestigationActionList().add(actionPlan);
		// dto.setInvestigationActionList(list);
	}

	/**
	 * Setter method for the Investigation Service facade.
	 * 
	 * @param investigationFacade
	 */
	public void setInvestigationFacade(InvestigationService investigationFacade) {
		this.investigationFacade = investigationFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			log.error(e);
		}
	}
	
	@InitBinder
	protected void initBinder(HttpServletRequest servletRequest,
			ServletRequestDataBinder binder) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("\n initBinder"); 
		}

		NumberFormat nf = NumberFormat.getNumberInstance();
		binder.registerCustomEditor(Integer.class, new CustomNumberEditor(
				Integer.class, nf, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(
				Long.class, nf, true));
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(
				BigDecimal.class, nf, true));
		binder
				.registerCustomEditor(String.class, new StringTrimmerEditor(
						true));
		binder.registerCustomEditor(byte[].class,
				new ByteArrayMultipartFileEditor());
		ECMSConstants.dateFormat.setLenient(false);
		binder.registerCustomEditor(java.util.Date.class, null,
				new UtilDateEditor(false));
		binder.registerCustomEditor(java.sql.Date.class, null,
				new SqlDateEditor(false));
	}
	
}
