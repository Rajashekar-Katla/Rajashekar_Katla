package uk.nhs.cfsms.ecms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.data.cim.CaseSummaryInformation;
import uk.nhs.cfsms.ecms.data.cim.InvestigationPlan;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalSanctionTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinarySanctionTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.CivilSanctionService;
import uk.nhs.cfsms.ecms.service.CriminalSanctionService;
import uk.nhs.cfsms.ecms.service.DisciplinarySanctionService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
public class CasePrintReportController extends BaseMultiActionController {
	@Autowired
	private InformationGatherService informationGatherFacade;
	@Autowired
	private CaseService caseFacade;
	@Autowired
	private CivilSanctionService civilSanctionFacade;
	@Autowired
	private CriminalSanctionService criminalSanctionFacade;
	@Autowired
	private DisciplinarySanctionService disciplinarySanctionFacade;
	
	public CaseService getCaseFacade() {
		return caseFacade;
	}


	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

	@RequestMapping(value ="/secure/viewcaseprintreportlinks.htm")
	public ModelAndView viewCasePrintReportLinks(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
				
		return new ModelAndView("caseprintreportlinks");
	
	}
	
	@RequestMapping(value ="/secure/casesubjectreport.htm")
	public ModelAndView viewCaseSubjectReport(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {
		
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		InformationTO infoTO = informationGatherFacade.loadInformationByCaseId(new Long(caseID), true);

		request.setAttribute("caseNumber", CaseUtil.getCaseNumberInSession(request));		
		request.setAttribute("operationName", CaseUtil.getOperationNameInSession(request));

		return new ModelAndView("casesubjectreport","information",infoTO);
	
	}
 	
	@RequestMapping(value ="/secure/casesummaryreport.htm")
	public ModelAndView viewCaseSumamryReport(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,ServiceException {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			logger.info(e);
		}
		CaseTO caseTO = new CaseTO();
		
		caseTO = caseFacade.loadCase(new Long(caseID));
		CaseSummaryInformation information = caseFacade
				.loadCaseSummaryInformation(new Long(caseID));
		
		if (information != null) {
			caseTO.setInformationSummary(information.getInformation());
		}
				
		return new ModelAndView("casesummaryreport","case",caseTO);
	
	}
	
	
	@RequestMapping(value ="/secure/caseinvestigationreport.htm")
	public ModelAndView viewCaseInvestigationReport(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		List<InvestigationPlan> list = new ArrayList<InvestigationPlan>();
		String caseID = CaseUtil.getCurrentCaseInSession(request.getSession());

		if (StringUtils.isEmpty(caseID)) {
			CaseUtil.logErrorCaseIDNotFound(log);
			return CaseUtil.getCasePortalView();
		}

		list = caseFacade.loadFullInvestigationsByCaseId(new Long(caseID));

		Map<String ,List<InvestigationPlan>> listMap = new HashMap<String ,List<InvestigationPlan>>();
		listMap.put("investigations", list);
		request.setAttribute("caseNumber", CaseUtil.getCaseNumberInSession(request));		
		request.setAttribute("operationName", CaseUtil.getOperationNameInSession(request));

		return new ModelAndView("caseinvestigationreport", "invListMap", listMap);

	}
	
	@RequestMapping(value ="/secure/casecriminalsanctionreport.htm")
	public ModelAndView viewCaseCriminalSanctionReport(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, ServiceException{

		List<CriminalSanctionTO> list = new ArrayList<CriminalSanctionTO>();
		String caseID = CaseUtil.getCurrentCaseInSession(request.getSession());

		if (StringUtils.isEmpty(caseID)) {
			CaseUtil.logErrorCaseIDNotFound(log);
			return CaseUtil.getCasePortalView();
		}

		list = criminalSanctionFacade.loadCriminalSanctionsForReport(new Long(caseID));

		Map<String, List<CriminalSanctionTO>> listMap = new HashMap<String, List<CriminalSanctionTO>>();
		listMap.put("sanctions", list);
		request.setAttribute("caseNumber", CaseUtil.getCaseNumberInSession(request));		
		request.setAttribute("operationName", CaseUtil.getOperationNameInSession(request));
		return new ModelAndView("casecriminalsanctionreport", "sanctionsMap", listMap);

	}
	
	@RequestMapping(value ="/secure/casecivilsanctionreport.htm")
	public ModelAndView viewCaseCivilSanctionReport(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, ServiceException{

		List<CivilSanctionTO> list = new ArrayList<CivilSanctionTO>();
		String caseID = CaseUtil.getCurrentCaseInSession(request.getSession());

		if (StringUtils.isEmpty(caseID)) {
			CaseUtil.logErrorCaseIDNotFound(log);
			return CaseUtil.getCasePortalView();
		}

		list = civilSanctionFacade.loadCivilSanctionsForReport(new Long(caseID));

		Map<String ,List<CivilSanctionTO>> listMap = new HashMap<String ,List<CivilSanctionTO>>();
		listMap.put("sanctions", list);
		request.setAttribute("caseNumber", CaseUtil.getCaseNumberInSession(request));		
		request.setAttribute("operationName", CaseUtil.getOperationNameInSession(request));
		return new ModelAndView("casecivilsanctionreport", "sanctionsMap", listMap);

	}
	
	@RequestMapping(value ="/secure/casedisciplinarysanctionreport.htm")
	public ModelAndView viewCaseDisciplnarySanctionReport(HttpServletRequest request,
			HttpServletResponse response) throws ServletException ,ServiceException{

		List<DisciplinarySanctionTO> list = new ArrayList<DisciplinarySanctionTO>();
		String caseID = CaseUtil.getCurrentCaseInSession(request.getSession());

		if (StringUtils.isEmpty(caseID)) {
			CaseUtil.logErrorCaseIDNotFound(log);
			return CaseUtil.getCasePortalView();
		}

		list = disciplinarySanctionFacade.loadSanctionsByCaseId(new Long(caseID));

		Map<String ,List<DisciplinarySanctionTO>> listMap = new HashMap<String ,List<DisciplinarySanctionTO>>();
		listMap.put("sanctions", list);
		request.setAttribute("caseNumber", CaseUtil.getCaseNumberInSession(request));		
		request.setAttribute("operationName", CaseUtil.getOperationNameInSession(request));
		return new ModelAndView("casedisciplinarysanctionreport", "sanctionsMap", listMap);

	}



	/**
	 * Setters for facade.
	 * @param informationGatherFacade
	 */
	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}



	public void setCivilSanctionFacade(CivilSanctionService civilSanctionFacade) {
		this.civilSanctionFacade = civilSanctionFacade;
	}



	public void setCriminalSanctionFacade(
			CriminalSanctionService criminalSanctionFacade) {
		this.criminalSanctionFacade = criminalSanctionFacade;
	}



	public void setDisciplinarySanctionFacade(
			DisciplinarySanctionService disciplinarySanctionFacade) {
		this.disciplinarySanctionFacade = disciplinarySanctionFacade;
	}

}
