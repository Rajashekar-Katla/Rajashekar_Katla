package uk.nhs.cfsms.ecms.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;


@Controller
public class SaveCaseController extends BaseBinderConfig {

	@Autowired
	private CaseService caseFacade;
	@Autowired
	private AuditLogService auditLogFacade;

	protected final Log log = LogFactory.getLog(getClass());

	/**
	 * Update Case Summary.
	 */
	@RequestMapping(value="/secure/saveCase.htm")
	protected ModelAndView onSubmit(
			HttpServletRequest request,
			HttpServletResponse response, 
			@ModelAttribute("case") CaseTO caseTO, 
			BindingResult errors) throws Exception {
		 
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		 
		if (StringUtils.isEmpty(caseTO.getCaseNumber())) {
			
			String caseNumber = caseFacade.generateCaseNumber(caseTO);
			
			if (null == caseNumber) {
				
				String error = "Error generating CaseNumber for caseId=" + 
						caseTO.getCaseId() +" TeamCode=" + caseTO.getTeamCode();
				log.error(error);
				throw new ServletException(error);
			}
			caseTO.setCaseNumber(caseNumber);
		}
		CaseTO caseToDb = caseFacade.loadCase(caseTO.getCaseId());
		caseToDb.setCaseNumber(caseTO.getCaseNumber());
		if(StringUtils.isNotEmpty(caseTO.getAccessFlag())){
		  caseToDb.setAccessFlag(caseTO.getAccessFlag());
		}
		caseToDb.setOperationName(caseTO.getOperationName());
		caseToDb.setCpsURN(caseTO.getCpsURN());
		caseToDb.setProsecuter(caseTO.getProsecuter());
		caseToDb.setInvestigationType(caseTO.getInvestigationType());
		caseToDb.setCaseUpdateDesc(caseTO.getCaseUpdateDesc());
		
		Long acceptanceType = caseTO.getAcceptanceType();
		String otherAcceptanceType = caseTO.getOtherAcceptanceType();
		if(acceptanceType != null){
			caseToDb.setAcceptanceType(acceptanceType);	
			if(StringUtils.isNotEmpty(otherAcceptanceType)){
				caseToDb.setOtherAcceptanceType(otherAcceptanceType);		
			}
		}
		AuditFlowThread.set("Case Summary Updated");
		
		//caseFacade.saveOrUpdate(caseTO, user.getStaffId());
		caseFacade.saveOrUpdate(caseToDb, user.getStaffId());

		createAudit(caseTO, AuditLogService.UPDATE, "Case Summary",	request, auditLogFacade);
 
		return new ModelAndView(new RedirectView("showCase.htm?caseId="	+ caseTO.getCaseId())); 
	}

	/**
	 * Setter Method for the Case Service
	 * 
	 * @param caseFacade
	 */
	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	} 
	
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}
	 

}
