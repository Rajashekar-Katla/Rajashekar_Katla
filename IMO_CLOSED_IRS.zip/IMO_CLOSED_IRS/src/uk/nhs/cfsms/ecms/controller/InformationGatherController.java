package uk.nhs.cfsms.ecms.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.audit.InformationIdThreadLocal;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationDetails;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SourceInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.service.LookupViewService;
import uk.nhs.cfsms.ecms.service.OrganisationService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.InformationUtil;
import uk.nhs.cfsms.ecms.utility.PatientOccupationLookupMap;

/**
 * Process new information details as well as adding new subjects only(pop up)
 * details for the information.
 * 
 * @author schilukuri
 * 
 */
public class InformationGatherController extends BaseWizardFormController {

	protected final Log log = LogFactory
			.getLog(InformationGatherController.class);
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private InformationGatherService informationGatherFacade;
	@Autowired
	private LookupViewService lookupViewFacade;
	@Autowired
	private OrganisationService organisationFacade;

	/// To add new subjects only (using a pop up feature)...
	private static final String SUBJECT_ONLY = "subjectonly";

	public InformationGatherController() {

		setCommandClass(InformationDetails.class);
		setCommandName("infogath");
		setAllowDirtyForward(true);
	}

	@Override
	protected Object formBackingObject(HttpServletRequest request)
			throws Exception {

		log.info("** formBackingObject ");
		InformationDetails info = null;
		HttpSession session = request.getSession();

		try {

			if (EcmsUtils.onCancel(request)) {
				return info;
			}

			Object obj = session
					.getAttribute(ECMSConstants.SESSION_INFO_GATHER);

			if (obj instanceof InformationDetails && (!isSubjectsOnly(request))) {

				info = (InformationDetails) obj;

			} else {

				String informationId = request.getParameter("infoId");

				if (StringUtils.isNotEmpty(informationId)) {
					info = informationGatherFacade
							.loadInformationById(new Long(informationId));
				}
				if (null == info) {
					info = informationGatherFacade.createFraudDetailsTO();
				}

				info.setTeamCodesList(organisationFacade.loadAllTeamCodes());

				if (!isSubjectsOnly(request)) {

					session.setAttribute(ECMSConstants.SESSION_INFO_GATHER,
							info);
				}
			}

			if (null == session.getAttribute("orgs")) {

				session.setAttribute("orgs", this.getOrganisations(request));
			}

		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
		}
		return info;
	}

	@Override
	protected void onBindAndValidate(HttpServletRequest request,
			Object command, BindException errors, int page) throws Exception {

		log.info("** onBindAndValidate, PAGE =" + page);

		if (this.isCancelRequest(request)) {
			return;
		}

		InformationDetails info = (InformationDetails) command;
		String caseID = request.getParameter("caseId");

		if (StringUtils.isEmpty(caseID)) {
			caseID = CaseUtil.getCurrentCaseInSession(request.getSession());
		}

		String subjectType = request.getParameter("subjectType");

		if (subjectType != null) {
			updateInfoSubjectType(info, subjectType);
		}

		if (!hasLookupDetails(info) && (page != 5 || page != 6)) {
			// Set up lookup details..
			setupAllLookupDetails(info);
		}

		switch (page) {

		case 0:
			// CHOOSE SUBJECTS/INFO
		case 1:
			// PERSON
			SubjectInformationTO subInfoTO = info.getSubjectInformationTO();
			Long caseId = subInfoTO.getCaseId();
			if (caseId == null && caseID != null) {
				subInfoTO.setCaseId(new Long(caseID));
			}
			if (subInfoTO != null && subInfoTO.getSubjectPersonTO() != null) {
				EcmsUtils.addNewAddressOrContactToPerson(
						subInfoTO.getSubjectPersonTO(), request);
			}
			updateSourceLookupDetails(info);
			break;
		case 2:
			// NHS
		case 3:
			// NON NHS
		case 4:
			// Information
		case 5:
			if (isSubjectsOnly(request)) {
				// Associate
				if (info.getAssociate() != null
						&& info.getAssociate().getPersonTO() != null) {
					EcmsUtils.addNewAddressOrContactToPerson(info
							.getAssociate().getPersonTO(), request);
				}
			} else {
				// SOURCE
				updateSourceLookupDetails(info);
				SourceInformationTO srcInfoTO = info.getInformationTO()
						.getSourceInformationTO();
				if (srcInfoTO != null && srcInfoTO.getSourcePersonTO() != null) {
					EcmsUtils.addNewAddressOrContactToPerson(
							srcInfoTO.getSourcePersonTO(), request);
				}
			}
			updateAdminLookupDetails(info);
			break;
		case 6:
			// ADMIN
			updateAdminLookupDetails(info);
			break;
		case 7:
			if (!isSubjectsOnly(request)) {
				// ASSOCIATE
				if (info.getAssociate() != null
						&& info.getAssociate().getPersonTO() != null) {
					EcmsUtils.addNewAddressOrContactToPerson(info
							.getAssociate().getPersonTO(), request);
				}
			}
			break;
		case 8:
			// VEHICLE

		default:

			if (!isSubjectsOnly(request)) {
				if (request.getParameter("_target1") != null) {
					// SubjectType.PERSON

				} else if (request.getParameter("_target4") != null) {
					// Information

				} else if (request.getParameter("_target5") != null) {
					// Source
					updateSourceLookupDetails(info);
					updateAdminLookupDetails(info);
				} else if (request.getParameter("_target6") != null) {
					// Source
					updateAdminLookupDetails(info);
				} else if (request.getParameter("_target7") != null) {
					// Associate..
					// info.setTeamCodesList(organisationFacade.loadAllTeamCodes());
				}
			}
			break;
		}
		;

		// Avoid Special pop up feature while adding subjects only.
		if (!isSubjectsOnly(request)) {
			request.getSession().setAttribute(
					ECMSConstants.SESSION_INFO_GATHER, info);
		}
		super.onBindAndValidate(request, command, errors, page);
	}

	@Override
	protected ModelAndView processFinish(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		log.info("** processFinish");

		Long infoId = null;
		InformationTO informationTO = null;

		String[] allPages = getPages();
		String successPage = allPages[allPages.length - 3];
		String failurePage = allPages[allPages.length - 2];

		if (isSubjectsOnly(request)) {
			successPage = allPages[allPages.length - 2];
			failurePage = allPages[allPages.length - 1];
		}

		try {
			InformationDetails info = (InformationDetails) command;

			SessionUser user = EcmsUtils.getSessionUserObject(request
					.getSession());
			if (user == null) {
				return new ModelAndView(EcmsUtils.getLoginView(request));
			}
			if (info.getInformationTO().getInformationId() == null
					|| (info.getInformationTO().getInformationId() == 0L)) {
				info.getInformationTO().setCreatedStaffId(user.getStaffId());
				info.getInformationTO().setCreatedDate(
						new Timestamp(System.currentTimeMillis()));
				AuditFlowThread.set("New Information Created");
			} else {
				AuditFlowThread.set("Information Updated");
				InformationIdThreadLocal.set(info.getInformationTO()
						.getInformationId());
			}
			this.updateSubjectType(info);

			informationTO = informationGatherFacade.saveInformationDetails(
					info, user);
			createInformationAudit(informationTO, AuditLogService.UPDATE,
					"Information", request, auditLogFacade);

			invalidateSessionAttribute(request);

		} catch (Exception e) {
			log.error(e);
			return new ModelAndView(failurePage, "message", e.getMessage());
		}

		return new ModelAndView(successPage, "informationId", infoId);
	}

	/**
	 * Used for Information additions via the popup.
	 * 
	 * @param request
	 * @return boolean
	 */
	private boolean isSubjectsOnly(HttpServletRequest request) {
		if (request.getParameter(SUBJECT_ONLY) != null) {
			return true;
		}
		return false;
	}

	/**
	 * get Organisations.
	 * 
	 * @param request
	 * @return List. List of Organisations
	 */
	private List<Organisation> getOrganisations(HttpServletRequest request) {

		// TODO : provide a valid keyword in future.
		String keyword = "";
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		try {
			if (user != null) {
				return organisationFacade.loadOrganisationsByOrgName(keyword,
						user);
			}
		} catch (Exception e) {
			log.error(e);
		}
		return new ArrayList<Organisation>();
	}

	@Override
	protected void validatePage(Object command, Errors errors, int page,
			boolean finish) {
		log.info("** validatePage");
		InformationDetails info = (InformationDetails) command;

		if (finish) {
			InformationTO infoTO = info.getInformationTO();
			if (infoTO == null) {
				errors.rejectValue("informationTO",
						"required.infogath.informationTO",
						"Valid Information is required.");

			} else if (infoTO != null && infoTO.getInformationId() == null) {

				String infoDetails = infoTO.getInformationDetails();

				if (infoDetails == null
						|| (infoDetails != null && infoDetails.trim().length() < 1)) {

					errors.rejectValue(
							"informationTO",
							"required.infogath.informationTO.informationDetails",
							"Mandatory field Information is required.");
				}
			}
			if (info.getSubjectType() != null
					&& info.getSubjectType().equals(
							InformationDetails.SubjectType.NHS.toString())) {
				ValidationUtils
						.rejectIfEmptyOrWhitespace(
								errors,
								"nhsSubjectInformationTO.orgCode",
								"required.infogath.nhsSubjectInformationTO.orgCode",
								"Mandatory field Org Code for NHS Subject is required or Check with administrator that your responsible organisations are mapped.");
			}
			ValidationUtils.rejectIfEmptyOrWhitespace(errors,
					"informationTO.orgCode",
					"required.infogath.informationTO.orgCode",
					"Mandatory field Org Code for Information is required.");

		}
		super.validatePage(command, errors, page);
	}

	@Override
	protected ModelAndView processCancel(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {

		log.info("** processCancel");

		invalidateSessionAttribute(request);

		if (isSubjectsOnly(request)) {
			// Special case only for popup to close.
			return new ModelAndView("closePopup");
		} else {
			return new ModelAndView(new RedirectView("listInformation.htm"));
		}
	}

	@Override
	protected String getViewName(HttpServletRequest request, Object command,
			int page) {
		log.info("** getViewName, page=" + page);

		InformationDetails info = (InformationDetails) command;

		String pages[] = getPages();
		if (isSubjectsOnly(request) && page < 6 && info != null
				&& info.getSubjectType() != null) {

			if (info.getSubjectType().equals(
					InformationDetails.SubjectType.PERSON.toString())) {

				return pages[1];

			} else if (info.getSubjectType().equals(
					InformationDetails.SubjectType.NHS.toString())) {

				return pages[2];

			} else if (info.getSubjectType().equals(
					InformationDetails.SubjectType.NONNHS.toString())) {

				return pages[3];
			} else if (info.getSubjectType().equals(
					InformationDetails.SubjectType.ASSOCIATE.toString())) {

				return pages[4];
			} else if (info.getSubjectType().equals(
					InformationDetails.SubjectType.VEHICLE.toString())) {

				return pages[5];
			}
		} else if (EcmsUtils.onFinish(request) && !isSubjectsOnly(request)) {
			if (page == 0) {
				return pages[4];
			}
		}
		return pages[page];
	}

	/**
	 * Update Information Subject Type.
	 * 
	 * @param info
	 * @param subType
	 */
	private void updateInfoSubjectType(InformationDetails info, String subType) {
		logger.info("** updateInfoSubjectType for InformationDetails and subtype="
				+ subType);
		if (subType.equalsIgnoreCase("person")) {

			info.setSubjectType(InformationDetails.SubjectType.PERSON
					.toString());

		} else if (subType.equalsIgnoreCase("nhs_org")) {

			info.setSubjectType(InformationDetails.SubjectType.NHS.toString());

		} else if (subType.equalsIgnoreCase("non_nhs_org")) {

			info.setSubjectType(InformationDetails.SubjectType.NONNHS
					.toString());
		} else if (subType.equalsIgnoreCase("associate")) {

			info.setSubjectType(InformationDetails.SubjectType.ASSOCIATE
					.toString());
		} else if (subType.equalsIgnoreCase("vehicle")) {

			info.setSubjectType(InformationDetails.SubjectType.VEHICLE
					.toString());
		}
	}

	/**
	 * Update subject Types to primary.
	 * 
	 * @param info
	 *            InformationDetails.
	 * 
	 */
	private void updateSubjectType(InformationDetails info) {
		logger.info("** updateSubjectType for InformationDetails");
		String primary = "Primary";
		String secondary = "Secondary";

		InformationTO infoTO = info.getInformationTO();

		if (infoTO != null) {
			if (infoTO.getInformationId() == null
					|| (infoTO.getInformationId() != null && !infoTO
							.getHasPrimarySubject())) {

				if (info.getSubjectInformationTO() != null) {
					info.getSubjectInformationTO().setSubjectType(primary);
				} else if (info.getNhsSubjectInformationTO() != null) {
					info.getNhsSubjectInformationTO().setSubjectType(primary);
				} else if (info.getNonNHSSubjectInformationTO() != null) {
					info.getNonNHSSubjectInformationTO()
							.setSubjectType(primary);
				}
			} else if (infoTO.getInformationId() != null
					&& infoTO.getHasPrimarySubject()) {

				if (info.getSubjectInformationTO() != null) {
					info.getSubjectInformationTO().setSubjectType(secondary);
				} else if (info.getNhsSubjectInformationTO() != null) {
					info.getNhsSubjectInformationTO().setSubjectType(secondary);
				} else if (info.getNonNHSSubjectInformationTO() != null) {
					info.getNonNHSSubjectInformationTO().setSubjectType(
							secondary);
				}
			}
		}

	}

	/**
	 * Update all look ups.
	 * 
	 * @param info
	 */
	private void updateAdminLookupDetails(InformationDetails info) {
		logger.info("** updateAdminLookupDetails for InformationDetails");
		/**
		 * As part of restructure the old FRAUD_TYPE is hidden and new
		 * AREA_FRAUD_TYPE's is introduced, contact Mr Pat Nolan
		 **/

		if (!hasLookupDetails(info)) {
			setupAllLookupDetails(info);
		}

		updateFraudAreaAndTypesLookupDetails(info);
	}

	/**
	 * Update Lookup details for LOOKUP_NHS_FRAUD_AREA, LOOKUP_FRAUD_SUB_AREA_1,
	 * LOOKUP_FRAUD_SUB_AREA_2 and LOOKUP_AREA_FRAUD_TYPE
	 * 
	 * @param info
	 *            InformationDetails.
	 */
	private void updateFraudAreaAndTypesLookupDetails(InformationDetails info) {
		logger.info("** updateFraudAreaAndTypesLookupDetails for InformationDetails");

		if (null != info && null != info.getInformationTO()) {

			InformationTO infoTO = info.getInformationTO();

			if (StringUtils.isNotEmpty(infoTO.getFraudArea())) {

				LookupView view = lookupViewFacade
						.loadLookupDetailsById(new Integer(infoTO
								.getFraudArea()));

				info.addDynamicInfoLookupViewMap(
						ECMSConstants.LOOKUP_FRAUD_SUB_AREA_1, lookupViewFacade
								.loadActiveLookupDetailsByParentId(new Integer(
										infoTO.getAreatype()), view
										.getGroupId()));
			}

			if (StringUtils.isNotEmpty(infoTO.getFraudSubArea())) {

				LookupView view = lookupViewFacade
						.loadLookupDetailsById(new Integer(infoTO
								.getFraudSubArea()));

				info.addDynamicInfoLookupViewMap(
						ECMSConstants.LOOKUP_FRAUD_SUB_AREA_2, lookupViewFacade
								.loadActiveLookupDetailsByParentId(new Integer(
										infoTO.getFraudArea()), view
										.getGroupId()));
			}

			if (StringUtils.isNotEmpty(infoTO.getNhsFraudType())) {

				LookupView view = lookupViewFacade
						.loadLookupDetailsById(new Integer(infoTO
								.getNhsFraudType()));

				info.addDynamicInfoLookupViewMap(
						ECMSConstants.LOOKUP_AREA_FRAUD_TYPE, lookupViewFacade
								.loadActiveLookupDetailsByParentId(new Integer(
										infoTO.getFraudArea()), view
										.getGroupId()));
			}
		}
	}

	/**
	 * helper method.
	 * 
	 * @param info
	 */
	private void updateSourceLookupDetails(InformationDetails info)
			throws Exception {

		logger.info("** updateSourceLookupDetails for InformationDetails");

		if (null != info.getInformationTO()) {

			SourceInformationTO srcTO = info.getInformationTO()
					.getSourceInformationTO();

			if (null != srcTO && StringUtils.isNotEmpty(srcTO.getSource())) {

				LookupView view = lookupViewFacade
						.loadLookupDetailsById(new Integer(srcTO.getSource()));

				if (null != view) {

					srcTO.setSourceType(view.getParentId().toString());
					info.addDynamicInfoLookupViewMap(
							ECMSConstants.LOOKUP_SOURCE_SUB_TYPE,
							lookupViewFacade
									.loadActiveLookupDetailsByParentId(view
											.getParentId()));
				}
			}
		}
		updateFraudAreaAndTypesLookupDetails(info);
		updateSubjectNHSOccupationTypes(info);
	}

	/**
	 * HandleInvalidSubmit.
	 */
	protected ModelAndView handleInvalidSubmit(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		return new ModelAndView("invalidSubmit");
	}

	/**
	 * LookupView Details given the group name
	 * 
	 * @param groupName
	 * @return List.
	 */
	private List<LookupView> getLookupDetails(String groupName) {

		logger.info("** getLookupDetails for groupName=" + groupName);

		if (groupName != null) {

			return lookupViewFacade.loadActiveLookupDetailsByGroups(groupName);
		}
		return null;
	}

	private void updateSubjectNHSOccupationTypes(InformationDetails info) {

		log.info("Updating Subject NHS OccupationTypes");

		if (null != info.getInformationTO()) {

			SubjectInformationTO subj = info.getSubjectInformationTO();

			if (null != subj && null != subj.getSubjectPersonTO()) {

				PersonTO pTO = subj.getSubjectPersonTO();

				if (null != pTO && pTO.isPersonWorkingForNHS()
						&& null != pTO.getNhsOccupationType()) {

					log.info("Lookup for Subject NHS OccupationTypes...");
					LookupView view = lookupViewFacade
							.loadLookupDetailsById(new Integer(pTO
									.getNhsOccupationType()));
					info.addDynamicInfoLookupViewMap(
							ECMSConstants.LOOKUP_OCCUPATION_NHS_TYPE,
							lookupViewFacade.loadActiveLookupDetailsByParentId(
									new Integer(pTO.getNhsCareerArea()),
									view.getGroupId()));
				}
			}
		}
	}

	/**
	 * Setup all lookup details for information.
	 * 
	 * @param Information
	 */
	private void setupAllLookupDetails(InformationDetails info) {

		logger.info("** setupAllLookupDetails for InformationDetails.");

		String[] lookupGroupNames = InformationUtil.getAllLookupGroups();

		for (String groupName : lookupGroupNames) {
			info.addInfoLookupViewMap(groupName, getLookupDetails(groupName));
		}
		EcmsUtils.getInstance().setInfoLookupViewMap(
				info.getInfoLookupViewMap());
		setUpPatientOccupationLookupDetails();
	}
	
	/**
	 * LookupView details for patient occupation
	 * 
	 * @return List.
	 */
	private void setUpPatientOccupationLookupDetails() {
		final List<LookupView> lookupList = lookupViewFacade
				.loadPatientOccupationDescriptions();
		for (LookupView view : lookupList) {
			final String lookupId = String.valueOf(view.getLookupId());
			final String description = view.getDescription();
			final Map<String, String> map = PatientOccupationLookupMap
					.getAllPatientOccupationDetailsLookupMap();
			if (!map.containsKey(lookupId)) {
				map.put(lookupId, description);
			}
		}
	}

	/**
	 * Check for lookupDetails are already loaded.
	 * 
	 * @param info
	 * @return
	 */
	private boolean hasLookupDetails(InformationDetails info) {

		logger.info("** hasLookupDetails for InformationDetails.");

		if (null != info) {
			List<LookupView> areaFraudList = info
					.getInfoLookupViewMapByName(ECMSConstants.LOOKUP_NHS_FRAUD_AREA);
			List<LookupView> sourceList = info
					.getInfoLookupViewMapByName(ECMSConstants.LOOKUP_SOURCE);

			if ((areaFraudList != null && !areaFraudList.isEmpty())
					&& (sourceList != null && !sourceList.isEmpty())) {
				return true;
			} else {
				logger.info("No lookup's for source & areaFraud at EcmsUtils.infoLookupViewMap");
			}
		}
		return false;
	}

	/**
	 * Invalidate Session
	 * 
	 * @param informationGatherFacade
	 */
	private void invalidateSessionAttribute(HttpServletRequest request) {

		HttpSession session = request.getSession();
		Object infoObj = session
				.getAttribute(ECMSConstants.SESSION_INFO_GATHER);
		if (infoObj instanceof InformationDetails) {
			session.removeAttribute(ECMSConstants.SESSION_INFO_GATHER);
		}
	}

	/**
	 * Information Facade
	 * 
	 * @param informationGatherFacade
	 */
	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}

	/**
	 * Lookup Facade
	 * 
	 * @param lookupViewFacade
	 */
	public void setLookupViewFacade(LookupViewService lookupViewFacade) {
		this.lookupViewFacade = lookupViewFacade;
	}

	/**
	 * Organisation Facade
	 * 
	 * @param organisationFacade
	 *            The organisationFacade to set.
	 */
	public void setOrganisationFacade(OrganisationService organisationFacade) {
		this.organisationFacade = organisationFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
