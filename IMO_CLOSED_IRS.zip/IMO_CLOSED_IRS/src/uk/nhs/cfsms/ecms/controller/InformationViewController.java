package uk.nhs.cfsms.ecms.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.data.infoGath.ClosedInformationView;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationViewTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

@Controller
public class InformationViewController extends BaseMultiActionController {
	@Autowired
	InformationGatherService informationGatherFacade;

	final static String INFORMATION = "information";

	final static String OTHER_INFORMATION = "otherInformation";
	
	final static String CLOSED_INFORMATION = "closedInformation";

	final static String INFORMATION_TYPE = "info_type";

	final static String FILTER_CREATED_BY = "created_by_filter";

	final static String ALL_INFORMATION_VIEW_PAGE = "allInformationView";

	final static String MY_INFORMATION_VIEW_PAGE = "myInformationView";

	final static String TOP_INFORMATION_VIEW_PAGE = "topInformationView";

	final static String COUNT_PARAM = "_count";

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;

	/**
	 * Handle All Information as a list.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	@RequestMapping(value = "/secure/listInformation.htm")
	public ModelAndView handleAllInformationList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			IllegalAccessException, InvocationTargetException {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		if (user == null) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}
		if (log.isInfoEnabled()) {
			log.info("** handleAllInformationList");
		}

		final List<InformationViewTO> infoList = informationGatherFacade
				.loadAllInformationView(user);

		List<ClosedInformationView> closedInfoList = Collections.emptyList();
		
		if(user.isUserIMO()){
			closedInfoList = informationGatherFacade
					.loadClosedInformationReportsForIMO(user);	
		}
		

		List<InformationViewTO> lcfsOtherinfoList = Collections.emptyList();

		if (user.isUserLCFS()) {
			lcfsOtherinfoList = informationGatherFacade
					.load_LCFS_Other_InformationReports(user);
			lcfsOtherinfoList.removeAll(infoList);
		}

		auditLogFacade.save("Open information list with size"
				+ (null != infoList ? infoList.size() : 0),
				AuditLogService.LOADING, user.getStaffId(), 0);

		Map<String, Object> listMap = new HashMap<String, Object>();
		listMap.put(INFORMATION, infoList);
		listMap.put(CLOSED_INFORMATION, closedInfoList);
		listMap.put(OTHER_INFORMATION, lcfsOtherinfoList);
		listMap.put(INFORMATION_TYPE, "open");

		return new ModelAndView(ALL_INFORMATION_VIEW_PAGE, "infoMap", listMap);
	}

	/**
	 * Handle My Information as a list.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/listMyInformation.htm")
	public ModelAndView handleMyInformationList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (log.isDebugEnabled()) {
			log.debug("** handleMyInformationList");
		}
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		if (null == user) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}
		String staffId = user.getStaffId();

		List<InformationView> infoList = informationGatherFacade
				.loadMyTeamsInformationView(user);

		auditLogFacade.save("Loading " + staffId + "(s) information list",
				AuditLogService.LOADING, staffId, 0);

		Map<String, Object> listMap = new HashMap<String, Object>();
		listMap.put(INFORMATION, infoList);
		listMap.put(INFORMATION_TYPE, "open");

		return new ModelAndView(MY_INFORMATION_VIEW_PAGE, "infoMap", listMap);
	}

	/**
	 * Handle Closed Information as a list.
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/listClosedInformation.htm")
	public ModelAndView handleClosedInformationList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (log.isInfoEnabled()) {
			log.info("** handleClosedInformationList");
		}
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		if (user == null) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}
		String createdByFilter = getFilterCreatedBy(request);

		List<ClosedInformationView> infoList = informationGatherFacade
				.loadClosedInformationView(user, createdByFilter);

		auditLogFacade.save("Open information list with size"
				+ (null != infoList ? infoList.size() : 0),
				AuditLogService.LOADING, user.getStaffId(), 0);

		Map<String, Object> listMap = new HashMap<String, Object>();
		listMap.put(INFORMATION, infoList);
		listMap.put(INFORMATION_TYPE, "closed");
		listMap.put(FILTER_CREATED_BY, createdByFilter);

		return new ModelAndView(ALL_INFORMATION_VIEW_PAGE, "infoMap", listMap);
	}

	private String getFilterCreatedBy(HttpServletRequest request) {

		String actType = request.getParameter("actionType");
		String filterCreatedBy = "All";
		if (null != actType && actType.equals("filterCreatedBy")) {
			String filterType = request.getParameter("createdByFilter");
			if (null != filterType && !filterCreatedBy.equals(filterType)) {
				filterCreatedBy = filterType;
			}
		}
		return filterCreatedBy;
	}

	/**
	 * Handle Top Information with the help of "count" param
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/topListInformation.htm")
	public ModelAndView handleTopInformationList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		if (user == null) {
			return new ModelAndView(EcmsUtils.getLoginView(request));
		}
		String dispCount = request.getParameter(COUNT_PARAM);
		Integer count = 0;
		if (dispCount != null) {
			count = new Integer(dispCount);
		}
		if (log.isInfoEnabled()) {
			log.info("** handleTopInformationList request Count =" + count);
		}
		List<InformationView> infoList = informationGatherFacade
				.loadTopInformationView(user, count);

		if (log.isDebugEnabled()) {
			log.debug("** OUTPUT Record Count ="
					+ ((infoList != null) ? infoList.size() : 0));
		}

		Map<String, Object> listMap = new HashMap<String, Object>();
		listMap.put(INFORMATION, infoList);

		return new ModelAndView(TOP_INFORMATION_VIEW_PAGE, "infoMap", listMap);
	}

	/*
	 * @Override protected ModelAndView handleRequestInternal(HttpServletRequest
	 * request, HttpServletResponse response) throws Exception {
	 * 
	 * SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
	 * if (user == null) { return new
	 * ModelAndView(EcmsUtils.getLoginView(request)); }
	 * 
	 * List<InformationView> infoList = informationGatherFacade
	 * .loadAllInformationView(user);
	 * 
	 * Map listMap = new HashMap(); listMap.put("information", infoList);
	 * 
	 * return new ModelAndView("allInformationView", "infoMap", listMap); }
	 * 
	 */

	public void setInformationGatherFacade(
			InformationGatherService informationGatherFacade) {
		this.informationGatherFacade = informationGatherFacade;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

}
