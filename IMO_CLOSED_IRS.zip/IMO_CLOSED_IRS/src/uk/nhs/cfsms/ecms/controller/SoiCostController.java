package uk.nhs.cfsms.ecms.controller;

import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.SoiCosts;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.AppealOutcomeTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.SoiCostService;
import uk.nhs.cfsms.ecms.utility.AuditLogUtils;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.web.support.CaseIDNotFoundException;

@Controller
public class SoiCostController {

	protected final Log log = LogFactory.getLog(getClass());
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private SoiCostService soiCostsFacade;
	@Autowired
	private CaseService caseService;

	protected final Log logger = LogFactory.getLog(getClass());
	
	private CustomDateEditor customDateEditor;

	@RequestMapping(value="/secure/savesoicosts.htm")
	public ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, @ModelAttribute("soiCostObject") SoiCosts soicost, BindingResult errors)
			throws Exception {

		logger.info("** SOICostController.processFormSubmission().");
		
		String caseID = null;

		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (Exception e)// TODO-please revisit this block of
		// code.-venkat
		{

		}
		SoiCosts costs;

		try {
			CaseTO caseTO=caseService.loadCase(new Long(caseID));
			if(null != caseTO.getProsecuter() &&  !caseTO.getProsecuter().equalsIgnoreCase(ECMSConstants.SOLP))
				return new ModelAndView("soimessage");
		}catch(ServiceException e) {
			throw new ServletException(e);
		}	

		//SoiCosts soicost = (SoiCosts) command;
		
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		
		if (EcmsUtils.onSave(request)) {
			validateSoiCosts(soicost, request, errors);
			if(errors.getErrorCount()>0)
			{
				/*return super.processFormSubmission(request, response,command,
						errors);*/
				
			}
			soicost.setCreatedTime(new Date());
		    soicost.setCreatedStaffId(user.getStaffId());
		    if(null != soicost && (soicost.getSoiCostId() == null || soicost.getSoiCostId() == 0l)){
		    	AuditFlowThread.set("Criminal Court Costs Awarded Created");
		    } else {
		    	AuditFlowThread.set("Criminal Court Costs Awarded Updated");
		    }
		    
			soiCostsFacade.saveSoiCosts(soicost);
			createAudit(soicost, AuditLogService.UPDATE, "Addind Soi Costs",
					request, auditLogFacade);
			if(soicost.getSoiCostId() != null)
				return new ModelAndView("soisavemessage");	
			
		}
		if (EcmsUtils.onClose(request)) {

		}
		return new ModelAndView("soisavemessage");	
		//return new ModelAndView("soicosts", "soiCostObject", soicost);
	}


	@RequestMapping(value="/secure/viewsoicosts.htm")
	protected ModelAndView formBackingObject(HttpServletRequest request)
			throws ServletException {
		ModelAndView mAV = new ModelAndView("soicosts");
		logger.info("** CaseClosureController.formBackingObject().");

		String caseID = null;

		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (Exception e)// TODO-please revisit this block of
		// code.-venkat
		{

		}
		SoiCosts costs;

	try {
			costs =soiCostsFacade.loadSoiCostsByCaseId(new Long(caseID));
		} catch (ServiceException e) {
			throw new ServletException(e);
		}

		if (null == costs)
			costs = new SoiCosts();
		
		mAV.addObject("soiCostObject", costs);
		//return costs;
		return mAV;
	}
	
	
	private void validateSoiCosts(SoiCosts cost,
			HttpServletRequest request, BindingResult errors) {
		
		if (null != cost.getCivilRecoveryAmount() && !EcmsUtils.isValidNumber(cost.getCivilRecoveryAmount().toString())) {
			errors
					.rejectValue("civilRecoveryAmount", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != cost.getCompensationAmount() && !EcmsUtils.isValidNumber(cost.getCompensationAmount().toString())) {
			errors
					.rejectValue("compensationAmount", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != cost.getVoluntaryAmount() && !EcmsUtils.isValidNumber(cost.getVoluntaryAmount().toString())) {
			errors
					.rejectValue("voluntaryAmount", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != cost.getPcoaConfiscationAmount()&& !EcmsUtils.isValidNumber(cost.getPcoaConfiscationAmount().toString())) {
			errors
					.rejectValue("settlementAwardedAmount", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != cost.getInvstCostsAwarded() && !EcmsUtils.isValidNumber(cost.getInvstCostsAwarded().toString())) {
			errors
					.rejectValue("settlementAwardedAmount", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		if (null != cost.getProsCostsAwarded() && !EcmsUtils.isValidNumber(cost.getProsCostsAwarded().toString())) {
			errors
					.rejectValue("prosCostsAwarded", "invalid.amount",
							"Please enter valid Amount(eg.100.25 or 155)");
		}
		
		
	}
	

	
	public CustomDateEditor getCustomDateEditor() {
		return customDateEditor;
	}

	public void setCustomDateEditor(CustomDateEditor customDateEditor) {
		this.customDateEditor = customDateEditor;
	}

	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}


	public CaseService getCaseService() {
		return caseService;
	}


	public void setCaseService(CaseService caseService) {
		this.caseService = caseService;
	}


	public SoiCostService getSoiCostsFacade() {
		return soiCostsFacade;
	}


	public void setSoiCostsFacade(SoiCostService soiCostFacade) {
		this.soiCostsFacade = soiCostFacade;
	}
	
	protected void createAudit(Object object, String state, String action, HttpServletRequest request, AuditLogService auditLogFacade) {
		String caseID = null;
		try {
			caseID = CaseUtil.getCaseId(request);
		} catch (CaseIDNotFoundException e) {
			// logger.info(e);
		}
		try {
			if (object != null ) {
				auditLogFacade.save(object.getClass(), AuditLogUtils.getProperties(object),
						state, action, EcmsUtils.getSessionUserObject(
								request.getSession()).getStaffId(), (null != caseID)? new Long(caseID) : null);
			}

		} catch (Exception e) {
			log.error(e);
		}
	}
	
}

