/**
 * 
 */
package uk.nhs.cfsms.ecms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.data.cim.CaseActionBookAttachment;
import uk.nhs.cfsms.ecms.data.cim.CaseAssigneeTO;
import uk.nhs.cfsms.ecms.data.common.PermissionGroup;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.model.ActionAttachmentFileUpload;
import uk.nhs.cfsms.ecms.model.CaseActionBookAttachmentTO;
import uk.nhs.cfsms.ecms.model.CaseActionBookTO;
import uk.nhs.cfsms.ecms.model.CaseActionFilterCriteria;
import uk.nhs.cfsms.ecms.service.AuditLogService;
import uk.nhs.cfsms.ecms.service.CaseActionBookService;
import uk.nhs.cfsms.ecms.service.CaseAssigneeService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.MessageService;
import uk.nhs.cfsms.ecms.service.TransformService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.FileUtils;
import uk.nhs.cfsms.ecms.xml.ActionBookXMLCreator;

/**
 * This class act as a multi-action controller for the case action Book
 * functionality provides all the methods required to create, update, list and
 * print a case action book.
 * 
 * @author Jshrivastav
 * 
 */
@Controller
public class CaseActionBookController extends BaseMultiActionController {

	protected final Log log = LogFactory.getLog(getClass());

	private final String XSL_PATH = "xsl";
	private final String XSL_FOLDER = "actionBook";
	private final String XSL_FILE = "actionBookList.xsl";
	@Autowired
	private AuditLogService auditLogFacade;
	@Autowired
	private TransformService transformService;
	@Autowired
	private MessageService messageFacade;
	@Autowired
	private CaseAssigneeService caseAssigneeFacade;
	@Autowired
	private CaseService caseFacade;
	@Autowired
	private CaseActionBookService caseActionBookService;

	/**
	 * Show Action book Home
	 * 
	 * @param request
	 * @param response
	 * @param caseActionBook
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/viewCaseActionBook.htm")
	public ModelAndView viewCaseActionBook(HttpServletRequest request,
			HttpServletResponse response, final CaseActionBookTO caseActionBook)
			throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **updateCaseActionBook");
		}

		CaseActionBookTO cab = null;
		String caseID = request.getParameter("caseID");
		String fromFilterResult = request.getParameter("fromFilterResult");
		String messageID = request.getParameter("msgIdForCaseActionBook");

		Map<String, Object> caseActionBookMap = new HashMap<String, Object>();

		String caseActionBookId = request.getParameter("caseActionBookId");

		if (StringUtils.isNotEmpty(caseActionBookId)) {
			try {

				cab = caseActionBookService.loadCaseActionBook(Long
						.parseLong(caseActionBookId));
				if (null != cab && null != cab.getCaseID()) {
					CaseTO caseTo = caseFacade.loadCase(cab.getCaseID());
					request.getSession().setAttribute(
							"FORM.showCase.caseDetails", caseTo);
					CaseUtil.setCurrentCaseInSession(request.getSession(),
							caseTo);
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new ServletException(
						"Service Exception in viewCaseActionBook method");
			}
		}

		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		/*if (isCFSorLCFS(user)) {
			String userId = user.getStaffId();
			// check if neither allocatedTo or allocatedBy
			if (!(userId.equals(cab.getAllocatedTo()) || userId.equals(cab
					.getAllocatedBy()))) {
				caseActionBookMap = setUActionBookList(request);

				String errorMessage = "Access denied for Action Number: "
						+ cab.getActionNumber();
				caseActionBookMap.put("message", errorMessage);
				return new ModelAndView("showCaseActionBookList",
						"caseActionBookMap", caseActionBookMap);
			}

		}*/
		String userId = user.getStaffId();
		String allocateToFieldStatus = "NotReadOnly";
		if (StringUtils.equalsIgnoreCase(userId, cab.getAllocatedBy())) {
			allocateToFieldStatus = "ReadOnly";
		}

		List<CaseActionBookAttachmentTO> attachmentList = null;
		if (cab.getCaseActionBookId() > 0) {
			attachmentList = new ArrayList<CaseActionBookAttachmentTO>(
					caseActionBookService.listAttachmentsWithUserName(Long
							.parseLong(cab.getCaseActionBookId() + "")));
		}
		boolean allowUpdate = isAssigneeOrAssignor(userId,
				cab.getAllocatedTo(), cab.getAllocatedBy(), user);
		caseActionBookMap.put("fromFilterResult", fromFilterResult);
		caseActionBookMap.put("attachmentsList", attachmentList);// caseActionBookMap
		caseActionBookMap.put("allowUpdate", allowUpdate);
		caseActionBookMap.put("caseActionBook", cab);
		caseActionBookMap.put("caseID", caseID);
		caseActionBookMap.put("savingFlag", "UPDATE");
		caseActionBookMap.put("allocateToFieldStatus", allocateToFieldStatus);
		caseActionBookMap.put("messageId", messageID);
		return new ModelAndView("addNewCaseActionBook", caseActionBookMap);

	}

	/**
	 * Show Action book Home
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/showCaseActionBookList.htm")
	public ModelAndView showCaseActionBookList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **showActionbookList");
		}
		Map<String, Object> caseActionBookMap = setUActionBookList(request);
		return new ModelAndView("showCaseActionBookList", "caseActionBookMap",
				caseActionBookMap);

	}

	private Map<String, Object> setUActionBookList(HttpServletRequest request)
			throws ServletException {

		List<CaseActionBookTO> list = null;
		Map<String, Object> caseActionBookMap = new HashMap<String, Object>();
		String caseID = request.getParameter("caseID");

		try {
			list = new ArrayList<CaseActionBookTO>(
					caseActionBookService.loadAllCaseActionBook(caseID));
		} catch (ServiceException e) {
			logger.error(e.getMessage());
			throw new ServletException(
					"Service Exception in showCaseActionBookList method");
		}
		caseActionBookMap.put("caseActionBookList", list);
		caseActionBookMap.put("caseID", caseID);
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());
		List<CaseAssigneeTO> assigneeList = null;
		try {
			assigneeList = caseAssigneeFacade.loadAssigneeByCaseId(new Long(
					caseID));
		} catch (NumberFormatException e) {
			logger.error(e.getMessage());
			throw new ServletException("case iis not Not a number");
		} catch (ServiceException e) {
			logger.error(e.getMessage());
			throw new ServletException(
					"Service Exception in showCaseActionBookList method");
		}
		String assigneeType = getUserAssigneeType(user, assigneeList);
		caseActionBookMap.put("assigneeType", assigneeType);

		return caseActionBookMap;
	}

	private String getUserAssigneeType(SessionUser user,
			List<CaseAssigneeTO> assigneeList) {

		if (user != null && assigneeList != null) {

			for (CaseAssigneeTO assignee : assigneeList) {

				if (user.getStaffId().equals(assignee.getUser().getStaffId())) {

					return assignee.getCasePermission().getPermissionType();
				}
			}
		}
		return null;
	}

	/**
	 * Add New Action book
	 * 
	 * @param request
	 * @param response
	 * @param caseActionBook
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/addNewCaseActionBook.htm")
	public ModelAndView addNewCaseActionBook(HttpServletRequest request,
			HttpServletResponse response, final CaseActionBookTO caseActionBook)
			throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **addNewCaseActionBook");
		}

		final SessionUser user = EcmsUtils.getSessionUserObject(request
				.getSession());

		CaseActionBookTO cab = null;
		String actionBookId = request.getParameter("caseActionBookId");
		String caseID = request.getParameter("caseID");
		if (null == caseID || (null != caseID && StringUtils.isEmpty(caseID))) {
			throw new ServletException(
					"CaseId expected in addNewCaseActionBook.");
		}
		Long caseId = Long.parseLong(caseID);
		Map<String, Object> caseActionBookMap = new HashMap<String, Object>();

		try {
			if (StringUtils.isNotEmpty(actionBookId)) {
				logger.error("\n\n caseActionBookService.loadCaseActionBook !!!");
				cab = caseActionBookService.loadCaseActionBook(Long
						.parseLong(actionBookId));
			} else {
				cab = new CaseActionBookTO();
				cab.setActionStatus("Not Started");
				cab.setCaseActionBookId(Long.parseLong("0"));
				String actionNumber = caseActionBookService
						.generateCaseActionBookNumber(caseId);

				cab.setActionNumber(Long.parseLong(actionNumber));
				cab.setDateRecorded(Calendar.getInstance().getTime());
				cab.setCaseID(caseId);
				cab.setEmpOrgCode(user.getEmployerOrgCode());
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new ServletException("Exception in addCaseActionBook ="
					+ e.getMessage());
		}
		caseActionBookMap.put("caseActionBook", cab);
		caseActionBookMap.put("caseID", caseID);
		caseActionBookMap.put("savingFlag", "SAVE");
		return new ModelAndView("addNewCaseActionBook", caseActionBookMap);
	}

	/**
	 * viewAllCaseActionBookSheets
	 * 
	 * @param request
	 * @param response
	 * @param caseActionBook
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/viewAllCaseActionBookSheets.htm")
	public ModelAndView viewAllCaseActionBookSheets(HttpServletRequest request,
			HttpServletResponse response, final CaseActionBookTO caseActionBook)
			throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **viewAllCaseActionBookSheets");
		}
		String caseID = request.getParameter("caseID");
		String startingActionID = request.getParameter("startingActionID");
		String endingActionID = request.getParameter("endingActionID");
		String viewAllFlag = request.getParameter("viewAllActions");
		String printAsReport = request.getParameter("printAsReport");
		String status = request.getParameter("status");
		List<CaseActionBookTO> list = null;
		Map<String, Object> caseActionBookMap = new HashMap<String, Object>();

		try {
			if (null == printAsReport) {

				if (StringUtils.equalsIgnoreCase(viewAllFlag, "viewAll")) {

					list = new ArrayList<CaseActionBookTO>(
							caseActionBookService.loadAllCaseActionBook(caseID,
									status));
					caseActionBookMap.put("printAsReport", "printAll");
					caseActionBookMap.put("status", status);

				} else {

					list = new ArrayList<CaseActionBookTO>(
							caseActionBookService.loadAllCaseActionBook(caseID,
									startingActionID, endingActionID, status));
					caseActionBookMap.put("printAsReport", startingActionID
							+ ":" + endingActionID);
					caseActionBookMap.put("status", status);
				}
				caseActionBookMap.put("caseActionBookList", list);
				caseActionBookMap.put("caseID", caseID);

				return new ModelAndView("viewAllCaseActionBook",
						"caseActionBookMap", caseActionBookMap);

			} else {
				// This section is responsible for showing the printable view of
				// the Action book list.

				CaseActionFilterCriteria filter = new CaseActionFilterCriteria();
				filter.setCaseId(Long.parseLong(caseID));
				filter.setStatus(status);
				String orderBy = request.getParameter("orderBy");
				if (StringUtils.isNotBlank(orderBy)) {
					if (orderBy.trim().equals("recent")) {
						filter.setOrderBy("actionNumber");
						filter.setAscending(false);
					} else {
						filter.setOrderBy("dateRecorded");
						filter.setAscending(true);
					}
				}
				if (!StringUtils.equalsIgnoreCase(printAsReport, "printAll")) {
					String str[] = printAsReport.split(":");
					filter.setFirstActionNumber(Long.parseLong(str[0]));
					filter.setLastActionNumber(Long.parseLong(str[1]));
				}
				list = new ArrayList<CaseActionBookTO>(
						caseActionBookService.loadCaseActionBook(filter));
				caseActionBookMap.put("caseActionBookList", list);
				caseActionBookMap.put("caseID", caseID);
				caseActionBookMap.put("caseNumber",
						CaseUtil.getCaseNumberInSession(request));
				caseActionBookMap.put("operationName",
						CaseUtil.getOperationNameInSession(request));

				String realPath = request.getSession().getServletContext()
						.getRealPath(this.XSL_PATH);

				String stylesheetPath = realPath + EcmsUtils.getFileSeperator()
						+ this.XSL_FOLDER + EcmsUtils.getFileSeperator()
						+ this.XSL_FILE;
				Document d = transformToXML(stylesheetPath, caseActionBookMap);

				FileCopyUtils.copy(d.asXML().getBytes(),
						response.getOutputStream());
			}
		} catch (Exception e) {
			logger.error(ExceptionUtils.getStackTrace(e));
			throw new ServletException(
					"Exception in viewAllCaseActionBookSheets method");
		}
		return null;
	}

	private boolean isAssigneeOrAssignor(String user, String assignee,
			String assigner, final SessionUser sessionUser) {

		boolean flag = false;

		final boolean isAssigneeIMO = assignee
				.equalsIgnoreCase(ECMSConstants.IMO);
		
		final boolean isAssigneeCIU = assignee
				.equalsIgnoreCase(ECMSConstants.CIU);

		if (isAssigneeIMO
				&& sessionUser.getEmployerOrgCode().equalsIgnoreCase(
						ECMSConstants.IMO)) {
			flag = true;
		}
		
		if (isAssigneeCIU
				&& sessionUser.getEmployerOrgCode().equalsIgnoreCase(
						ECMSConstants.CIU)) {
			flag = true;
		}

		if (StringUtils.equals(user, assignee)
				|| StringUtils.equals(user, assigner)) {
			flag = true;
		}

		return flag;
	}

	/**
	 * Update Action book Home
	 * 
	 * @param request
	 * @param response
	 * @param action
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/updateCaseActionBook.htm")
	public ModelAndView updateCaseActionBook(HttpServletRequest request,
			HttpServletResponse response, final CaseActionBookTO action)
			throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **updateCaseActionBook");
		}

		Map<String, Object> caseActionBookMap = new HashMap<String, Object>();
		CaseActionBookTO cActionBook = null;
		String caseID = null;

		try {
			caseID = request.getParameter("caseID");
			String allocatedTo = request.getParameter("allocatedTo");
			String newStatus = request.getParameter("newStatus");
			String oldStatus = request.getParameter("oldStatus");
			String previousAllocation = request
					.getParameter("originalAllocation");

			action.setAllocatedTo(allocatedTo);

			boolean assigneeChanged = !allocatedTo.equals(previousAllocation);
			boolean isStatusChanged = !newStatus.equals(oldStatus);

			if (assigneeChanged && (null == action.getDateAllocated())) {

				action.setDateAllocated(new Date());
			}
			if (null != action.getCaseActionBookId()) {
				AuditFlowThread.set("Case Action Book Updated");
			} else {
				AuditFlowThread.set("Case Action Book Created");
			}
			cActionBook = caseActionBookService.saveOrUpdate(action);
			SessionUser user = EcmsUtils.getSessionUserObject(request
					.getSession());

			if (logger.isDebugEnabled()) {
				logger.info("CaseActionBook created with ID :"
						+ cActionBook.getCaseActionBookId());
			}
			if (null != action.getFileToUpload()
					&& !action.getFileToUpload().isEmpty()) {

				CaseActionBookAttachment cABA = populateCaseActionBookAttachment(
						action.getAttachmentComment(),
						action.getFileToUpload(),
						cActionBook.getCaseActionBookId() + "",
						user.getStaffId());

				this.caseActionBookService.saveCaseActionBookAttachment(cABA);

				if (logger.isDebugEnabled()) {
					logger.debug("CaseActionBook attachment created for action ID :"
							+ cABA.getActionID()
							+ " with Attachment ID :"
							+ cABA.getActionAttachmentID());
				}
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("CaseActionBook attachment created without attachments.");
				}
			}

			if (!allocatedTo.equals("Unallocated")) {

				final String actionStatus = cActionBook.getActionStatus();
				if (actionStatus.equalsIgnoreCase("2")
						|| actionStatus.equalsIgnoreCase("3")
						|| assigneeChanged) {
					CaseTO caseTo = CaseUtil.getCaseFromSession(request
							.getSession());
					if (null != caseTo) {
						cActionBook.setCaseNumber(caseTo.getCaseNumber());
						cActionBook.setOperationName(caseTo.getOperationName());
					}
					// False flag, once the action is triggered as completed
					checkAllocatedTOIMO(cActionBook, allocatedTo);
					checkAllocatedTOCIU(cActionBook, allocatedTo);
					triggerMessageSystem(cActionBook, assigneeChanged, request,
							actionStatus, isStatusChanged);
				}
			}
			createAudit(cActionBook, AuditLogService.UPDATE,
					"Case Action Book", request, auditLogFacade);

		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new ServletException(
					"Service Exception in updateCaseActionBook method");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("New case Action book updated successfully with ID ="
					+ cActionBook.getCaseActionBookId());
		}

		if (StringUtils.isNotBlank(request.getParameter("fromFilterResult"))) {

			String ffResult = request.getParameter("fromFilterResult");

			if (ffResult.equalsIgnoreCase("true")) {
				return new ModelAndView(new RedirectView(
						"filterActionSearchResults.htm?usePreviousCriteria=true&caseID="
								+ caseID));
			} else {
				String msgID = request.getParameter("msgIdForCaseActionBook");

				return new ModelAndView(new RedirectView(
						"viewmessage.htm?messageId=" + msgID));
			}

		}
		caseActionBookMap.put("caseID", caseID);
		caseActionBookMap.put("savingFlag", "UPDATE");
		return new ModelAndView(new RedirectView("showCaseActionBookList.htm"),
				caseActionBookMap);
	}

	/**
	 * Save Action book Home
	 * 
	 * @param request
	 * @param response
	 * @param caseActionBook
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/saveCaseActionBook.htm")
	public ModelAndView saveCaseActionBook(HttpServletRequest request,
			HttpServletResponse response, final CaseActionBookTO caseActionBook)
			throws ServletException {

		if (logger.isDebugEnabled()) {
			logger.info("saveCaseActionBook");
		}

		CaseActionBookTO cActionBook = null;
		String caseID = null;
		MultipartFile file = null;
		final String allocatedTo = caseActionBook.getAllocatedTo();

		try {
			caseID = request.getParameter("caseID");
			SessionUser user = EcmsUtils.getSessionUserObject(request
					.getSession());

			if (null == caseActionBook.getCaseID()) {

				caseActionBook.setCaseID(Long.parseLong(caseID));
			}
			caseActionBook.setAllocatedBy(user.getStaffId());

			if (caseActionBook.getCaseActionBookId() == null
					|| (caseActionBook.getCaseActionBookId() == 0l)) {

				AuditFlowThread.set("Case ActionBook Created");
			} else {
				AuditFlowThread.set("Case ActionBook Updated");
			}

			cActionBook = caseActionBookService.saveCase(caseActionBook);

			if (logger.isDebugEnabled()) {
				logger.info("CaseActionBook created with ID="
						+ cActionBook.getCaseActionBookId());
			}
			if (null != caseActionBook) {

				file = caseActionBook.getFileToUpload();
			}
			if (null != file && !file.isEmpty()) {

				CaseActionBookAttachment CABA = populateCaseActionBookAttachment(
						caseActionBook.getAttachmentComment(), file,
						cActionBook.getCaseActionBookId() + "",
						user.getStaffId());

				this.caseActionBookService.saveCaseActionBookAttachment(CABA);

				if (logger.isDebugEnabled()) {
					logger.info("\n **CaseActionBook attachment created Successfully for action ID :"
							+ CABA.getActionID()
							+ " with Attachment ID :"
							+ CABA.getActionAttachmentID());
				}
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("\n ** attachments is null or empty !!!");
				}
			}
			final String actionStatus = cActionBook.getActionStatus();

			// true flag is passed as this in new action creation.
			if (!allocatedTo.equals("Unallocated")) {
				checkAllocatedTOIMO(cActionBook, allocatedTo);
				checkAllocatedTOCIU(cActionBook, allocatedTo);
				triggerMessageSystem(cActionBook, true, request, actionStatus,
						false);
			}
			createAudit(cActionBook, AuditLogService.CREATE,
					"Case Action Book", request, auditLogFacade);

		} catch (Exception e) {
			logger.error(ExceptionUtils.getStackTrace(e));
			throw new ServletException("Exception saving CaseActionBook ");
		}

		if (logger.isDebugEnabled()) {
			logger.debug(" New case Action book created with ID="
					+ cActionBook.getCaseActionBookId());

		}

		Map<String, Object> caseActionBookMap = new HashMap<String, Object>();
		caseActionBookMap.put("caseID", caseID);

		return new ModelAndView(new RedirectView("showCaseActionBookList.htm"),
				caseActionBookMap);
	}

	/**
	 * @param request
	 * @param cActionBook
	 * @param allocatedTo
	 * @param actionStatus
	 * @throws Exception
	 */
	private CaseActionBookTO checkAllocatedTOIMO(CaseActionBookTO cActionBook,
			final String allocatedTo) throws Exception {
		if (allocatedTo.equalsIgnoreCase(ECMSConstants.IMO)) {
			final String imoStaffId = caseActionBookService
					.getActiveIMOMessageReceiverStaffId();
			cActionBook.setAllocatedTo(imoStaffId);
			return cActionBook;
		} else {
			return cActionBook;
		}
	}
	
	/**
	 * @param request
	 * @param cActionBook
	 * @param allocatedTo
	 * @param actionStatus
	 * @throws Exception
	 */
	private CaseActionBookTO checkAllocatedTOCIU(CaseActionBookTO cActionBook,
			final String allocatedTo) throws Exception {
		if (allocatedTo.equalsIgnoreCase(ECMSConstants.CIU)) {
			final String ciuStaffId = caseActionBookService
					.getActiveCIUMessagesReceiverStaffId();
			cActionBook.setAllocatedTo(ciuStaffId);
			return cActionBook;
		} else {
			return cActionBook;
		}
	}

	/**
	 * All Attachments Action book Home
	 * 
	 * @param request
	 * @param response
	 * 
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/actionBookAttachments.htm")
	public ModelAndView actionBookAttachments(HttpServletRequest request,
			HttpServletResponse response,
			final CaseActionBookAttachment caseActionBookAttachment)
			throws ServletException {

		String caseID = request.getParameter("caseID");
		String actionID = request.getParameter("actionID");
		List<CaseActionBookAttachment> list = this.caseActionBookService
				.listAttachments(Long.parseLong(actionID));

		Map<String, Object> caseActionBookMap = new HashMap<String, Object>();
		caseActionBookMap.put("caseID", caseID);
		caseActionBookMap.put("actionID", actionID);
		caseActionBookMap.put("attachments", list);

		return new ModelAndView("allCaseActionBookAttachments",
				"caseActionBookMap", caseActionBookMap);
	}

	/**
	 * All Attachments Action book Home
	 * 
	 * @param request
	 * @param response
	 * 
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/addActionBookAttachments.htm")
	public ModelAndView addActionBookAttachments(HttpServletRequest request,
			HttpServletResponse response,
			final ActionAttachmentFileUpload actionAttachmentFileUpload)
			throws ServletException {

		String caseID = request.getParameter("caseID");
		String actionID = request.getParameter("actionID");
		ActionAttachmentFileUpload fileUpload = actionAttachmentFileUpload;
		MultipartFile multipartFile = fileUpload.getFile();
		SessionUser user = EcmsUtils.getSessionUserObject(request.getSession());

		CaseActionBookAttachment CABA = populateCaseActionBookAttachment(
				actionAttachmentFileUpload.getAttachmentDescription(),
				multipartFile, actionID, user.getStaffId());

		this.caseActionBookService.saveCaseActionBookAttachment(CABA);

		Map<String, Object> caseActionBookMap = new HashMap<String, Object>();
		caseActionBookMap.put("caseID", caseID);
		caseActionBookMap.put("actionID", actionID);

		return new ModelAndView("successCaseActionBookAttachments",
				"caseActionBookMap", caseActionBookMap);
	}

	/**
	 * This is a utility method to populate CaseActionBookAttachment Object.
	 * 
	 * @param attachmentDescription
	 * @param multipartFile
	 * @param actionID
	 * @param staffID
	 * 
	 * 
	 * @return CaseActionBookAttachment
	 * @throws ServletException
	 */
	private CaseActionBookAttachment populateCaseActionBookAttachment(
			String attachmentDescription, MultipartFile multipartFile,
			String actionID, String staffID) throws ServletException {

		CaseActionBookAttachment CABA = new CaseActionBookAttachment();
		try {
			CABA.setAttachmentBlob(multipartFile.getBytes());
		} catch (IOException e) {
			logger.error(e.getMessage());
			throw new ServletException(
					"Exception with updating ActionBook Attachment");
		}
		CABA.setActionID(Long.parseLong(actionID));
		CABA.setAttachmentDescription(attachmentDescription);
		CABA.setAttachmentName(multipartFile.getOriginalFilename());
		CABA.setAttachmentNumber(Long.parseLong(this.caseActionBookService
				.getCaseActionBookAttachmentNumber(Long.parseLong(actionID))));
		CABA.setAttachmentType(FileUtils.getExtension(multipartFile
				.getOriginalFilename()));
		CABA.setCreatedBy(staffID);
		CABA.setCreationDateTime(Calendar.getInstance().getTime());
		CABA.setMarkAsDeleted("N");
		CABA.setSensitive("N");

		return CABA;
	}

	/**
	 * Download Attachments Action book Home
	 * 
	 * @param request
	 * @param response
	 * 
	 * 
	 * @return ModelAndView
	 * @throws ServletException
	 */
	@RequestMapping(value = "/secure/downloadActionBookAttachment.htm")
	public ModelAndView downloadActionBookAttachment(
			HttpServletRequest request, HttpServletResponse response)
			throws ServletException {

		String attachmentID = request.getParameter("actionAttachmentID");
		String viewFlag = request.getParameter("viewFlag");
		CaseActionBookAttachment CABA = this.caseActionBookService
				.downloadCaseActionBookAttachment(attachmentID);
		try {
			if (null != viewFlag
					&& StringUtils.equalsIgnoreCase(viewFlag, "view"))
				response.setHeader("Content-Disposition", "inline;filename=\""
						+ CABA.getAttachmentName() + "\"");
			else
				response.setHeader("Content-Disposition",
						"attachment;filename=\"" + CABA.getAttachmentName()
								+ "\"");

			response.setContentType(CABA.getAttachmentType());
			FileCopyUtils.copy(CABA.getAttachmentBlob(),
					response.getOutputStream());
		} catch (IOException e) {
			logger.error(e.getMessage());
			throw new ServletException(
					"IO Exception in downloadActionBookAttachment method");
		}

		return null;
	}

	/**
	 * Injecting the Audit Log Facade.
	 * 
	 * @param auditLogFacade
	 * 
	 * @return
	 * 
	 */
	public void setAuditLogFacade(AuditLogService auditLogFacade) {
		this.auditLogFacade = auditLogFacade;
	}

	/**
	 * Injecting the Case Action Book Facade.
	 * 
	 * @param caseActionBookService
	 * 
	 * @return
	 * 
	 */
	public void setCaseActionBookService(
			CaseActionBookService caseActionBookService) {
		this.caseActionBookService = caseActionBookService;
	}

	public void setCaseAssigneeFacade(CaseAssigneeService caseAssigneeFacade) {
		this.caseAssigneeFacade = caseAssigneeFacade;
	}

	/**
	 * Injecting the Case Action Book Facade.
	 * 
	 * @param caseActionBookService
	 * 
	 * @return
	 * 
	 */
	public void setTransformService(TransformService transformService) {
		this.transformService = transformService;
	}

	/**
	 * This method is responsible for transforming XML document using the given
	 * style sheet.
	 * 
	 * @param stylesheet
	 * @param caseActionList
	 * 
	 * @return Document
	 * @throws ServletException
	 */
	private Document transformToXML(String stylesheet,
			Map<String, Object> caseActionBookMap) throws ServiceException {

		if (logger.isDebugEnabled()) {
			logger.info("\n **Action Book Document transformation to XML Started");
		}

		ActionBookXMLCreator actionBookXML = new ActionBookXMLCreator(
				caseActionBookMap);
		actionBookXML.createDOM();
		Document document = actionBookXML.getDom();
		Document transformedDocument = transformService.transform(stylesheet,
				document);

		if (logger.isDebugEnabled()) {
			logger.info("\n **Action Book Document transformed to XML Successfully.");
		}

		return transformedDocument;
	}

	/**
	 * This method is responsible for triggering the messaging system.
	 * 
	 * @param actionTO
	 * @param saveUpdateFlag
	 * @param request
	 * 
	 * 
	 * @throws Exception
	 */
	private void triggerMessageSystem(CaseActionBookTO actionTO,
			boolean saveUpdateFlag, HttpServletRequest request,
			final String actionStatus, final boolean isStatusChanged)
			throws Exception {

		Long caseId = actionTO.getCaseID();
		if (null == caseId) {
			caseId = new Long(CaseUtil.getCaseId(request));
		}

		MessageTO messageTO = new MessageTO();
		messageTO.setCaseId(caseId);
		messageTO.setCreatedTime(new Date());

		if (saveUpdateFlag) {

			StringBuilder message = new StringBuilder(
					"A new action has been assigned to you and the action number is: ");
			message.append(actionTO.getActionNumber());

			messageTO.setMessage(message.toString());
			messageTO.setCaseId(actionTO.getCaseID());
			messageTO.setActionTitle(actionTO.getSourceReference());
			messageTO.setMessageType("Case Action Allocated");
			messageTO.setCaseRef(actionTO.getCaseActionBookId().toString());
			messageTO.setCreatedStaffId(actionTO.getAllocatedBy());
			messageTO.setFromStaffId(actionTO.getAllocatedBy());
			messageTO.setFromStaffName(this.caseActionBookService
					.getUserFullName(actionTO.getAllocatedBy()));
			messageTO.setToStaffId(actionTO.getAllocatedTo());
			messageTO.setToStaffName(this.caseActionBookService
					.getUserFullName(actionTO.getAllocatedTo()));
		} else {

			if (actionStatus.equalsIgnoreCase("2") && isStatusChanged) {
				StringBuilder message = new StringBuilder(
						"ALERT Message:: Action #");
				message.append(actionTO.getActionNumber());
				message.append(" status has been updated to in progress");

				/*
				 * if (StringUtils.isNotBlank(actionTO.getCaseNumber())) {
				 * 
				 * message.append(", for Case Number : ").append(
				 * actionTO.getCaseNumber()); } else if
				 * (StringUtils.isNotBlank(actionTO.getOperationName())) {
				 * 
				 * message.append(", for Operation Name : ").append(
				 * actionTO.getOperationName()); }
				 */
				messageTO.setMessage(message.toString());
				messageTO.setCaseId(actionTO.getCaseID());
				messageTO.setActionTitle(actionTO.getSourceReference());
				messageTO
						.setActionDetails("Please refer to the in progress action number:"
								+ actionTO.getActionNumber());
				messageTO.setMessageType("Case Action In Progress");

				messageTO.setCaseRef(actionTO.getCaseActionBookId().toString());
				messageTO.setCreatedStaffId(actionTO.getAllocatedTo());
				messageTO.setFromStaffId(actionTO.getAllocatedTo());
				messageTO.setFromStaffName(this.caseActionBookService
						.getUserFullName(actionTO.getAllocatedTo()));

				messageTO.setToStaffId(actionTO.getAllocatedBy());
				messageTO.setToStaffName(this.caseActionBookService
						.getUserFullName(actionTO.getAllocatedBy()));
			}
			if (actionStatus.equalsIgnoreCase("3")) {
				// True when message is being generated for update action.

				// String
				// message="ALERT Message:: Completed Action Number: "+cActionBook.getActionNumber()+" & Case ID :"+cActionBook.getCaseID();
				StringBuilder message = new StringBuilder(
						"ALERT Message:: Action #");
				message.append(actionTO.getActionNumber());
				message.append(" status has been updated to completed");

				/*
				 * if (StringUtils.isNotBlank(actionTO.getCaseNumber())) {
				 * 
				 * message.append(", for Case Number : ").append(
				 * actionTO.getCaseNumber()); } else if
				 * (StringUtils.isNotBlank(actionTO.getOperationName())) {
				 * 
				 * message.append(", for Operation Name : ").append(
				 * actionTO.getOperationName()); }
				 */
				messageTO.setMessage(message.toString());
				messageTO.setCaseId(actionTO.getCaseID());
				messageTO.setActionTitle(actionTO.getSourceReference());
				messageTO
						.setActionDetails("Please refer to the completed action number:"
								+ actionTO.getActionNumber());

				messageTO.setMessageType("Case Action Completed");

				messageTO.setCaseRef(actionTO.getCaseActionBookId().toString());
				messageTO.setCreatedStaffId(actionTO.getAllocatedTo());
				messageTO.setFromStaffId(actionTO.getAllocatedTo());
				messageTO.setFromStaffName(this.caseActionBookService
						.getUserFullName(actionTO.getAllocatedTo()));

				messageTO.setToStaffId(actionTO.getAllocatedBy());
				messageTO.setToStaffName(this.caseActionBookService
						.getUserFullName(actionTO.getAllocatedBy()));
			}

		}
		messageTO.setState(ECMSConstants.MESSAGE_STATE_NEW);
		messageTO = messageFacade.saveMessage(messageTO);
		createAudit(messageTO, AuditLogService.UPDATE, "Adding Message",
				request, auditLogFacade);
	}

	/**
	 * Setter method for injecting the message Service.
	 * 
	 * @param messageFacade
	 * 
	 * */
	public void setmessageFacade(MessageService messageFacade) {
		this.messageFacade = messageFacade;
	}

	public void setCaseFacade(CaseService caseFacade) {
		this.caseFacade = caseFacade;
	}

	/**
	 * Whether the logged in user is a CFS or LCFS
	 * 
	 * @param
	 * 
	 * @return <li><b>true</b> - if user is CFS or LCFS.</li> <li><b>false</b> -
	 *         otherwise.</li>
	 */
	private boolean isCFSorLCFS(SessionUser user) {

		if (user != null) {
			PermissionGroup group = user.getPermissionGroupTopLevel();
			if (null != group
					&& null != group.getName()
					&& (group.getName().equalsIgnoreCase(ECMSConstants.CFS) || group
							.getName().equalsIgnoreCase(ECMSConstants.LCFS))) {
				return true;
			}
		}
		return false;
	}

}