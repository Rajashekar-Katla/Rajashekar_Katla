package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "CASE_TBL")
// @NamedQuery(name = "confidentialproc", query =
// " call case_confidentiality(:caseId) ", hints= {@QueryHint(name="callable"
// ,value="true")})
@Audited
public class Case implements Serializable {

	private static final long serialVersionUID = 4939871235L;

	@Id
	@Column(name = "CASE_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CASE_ID_SQNC") })
	private Long caseId;

	@Column(name = "INFORMATION_ID")
	private Long informationId;

	@Column(name = "CASE_NUMBER")
	private String caseNumber;

	@Column(name = "OPERATION_NAME")
	@DisplayedLoggedProperty(displayName = "Operation Name")
	private String operationName;

	@Column(name = "STATE")
	@DisplayedLoggedProperty(displayName = "State")
	private String state;

	@Column(name = "CREATED_TIME", updatable = false)
	@DisplayedLoggedProperty(displayName = "Creation Time")
	private Date createdTime;

	@Column(name = "PENDING_TIME")
	@DisplayedLoggedProperty(displayName = "Pending Time")
	private Date pendingTime;

	@Column(name = "CLOSED_TIME")
	@DisplayedLoggedProperty(displayName = "Closed Time")
	private Date closedTime;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;

	@Column(name = "TEAM_CODE")
	@DisplayedLoggedProperty(displayName = "Team Code")
	private String teamCode;

	@Column(name = "ORG_CODE")
	@DisplayedLoggedProperty(displayName = "Organisation Code")
	private String orgCode;

	@Column(name = "RESTRICT_TO")
	@DisplayedLoggedProperty(displayName = "Restricted To")
	private String restrictTo;

	@Column(name = "PROSECUTOR")
	private String prosecuter;

	@Column(name = "IS_SUMMARY_ADDED")
	private String isSummaryAdded;

	@Column(name = "IS_OVERLOADED_CASE")
	private String isOverLoadedCase;

	@Column(name = "investigation_type")
	private String investigationType;

	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";

	@Column(name = "ACCESS_FLAG")
	private String accessFlag;

	@Column(name = "AWAITING_TIME")
	@DisplayedLoggedProperty(displayName = "Awaiting Time")
	private Date awaitingTime;

	@Column(name = "REOPENED_TIME")
	@DisplayedLoggedProperty(displayName = "Reopened Time")
	private Date reopenedTime;

	@Column(name = "REOPENED_STAFF_ID")
	@DisplayedLoggedProperty(displayName = "Reopened By Staff(Id)")
	private String reopenedStaffId;

	@Column(name = "OVERLOAD_REASON")
	@DisplayedLoggedProperty(displayName = "OverLoad Reason")
	private String overloadReason;

	@Column(name = "ACCEPTANCE_TYPE")
	@DisplayedLoggedProperty(displayName = "Acceptence Type", isList = true)
	private Long acceptanceType;

	@Column(name = "OTHER_ACCEPTANCE_TYPE")
	@DisplayedLoggedProperty(displayName = "Other Acceptence Type")
	private String otherAcceptanceType;

	@Column(name = "CPS_URN")
	@DisplayedLoggedProperty(displayName = "CPS UPRN")
	private String cpsURN;

	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId
	 *            The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the caseNumber.
	 */
	public String getCaseNumber() {
		return caseNumber;
	}

	/**
	 * @param caseNumber
	 *            The caseNumber to set.
	 */
	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	/**
	 * @return Returns the closedTime.
	 */
	public Date getClosedTime() {
		return closedTime;
	}

	/**
	 * @param closedTime
	 *            The closedTime to set.
	 */
	public void setClosedTime(Date closedTime) {
		this.closedTime = closedTime;
	}

	/**
	 * @return Returns the createdStaffId.
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	/**
	 * @param createdStaffId
	 *            The createdStaffId to set.
	 */
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	/**
	 * @return Returns the createdTime.
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime
	 *            The createdTime to set.
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return Returns the information.
	 */
	public Long getInformationId() {
		return informationId;
	}

	/**
	 * @param information
	 *            The information to set.
	 */
	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	/**
	 * @return Returns the operationName.
	 */
	public String getOperationName() {
		return operationName;
	}

	/**
	 * @param operationName
	 *            The operationName to set.
	 */
	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	/**
	 * @return Returns the orgCode.
	 */
	public String getOrgCode() {
		return orgCode;
	}

	/**
	 * @param orgCode
	 *            The orgCode to set.
	 */
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	/**
	 * @return Returns the pendingTime.
	 */
	public Date getPendingTime() {
		return pendingTime;
	}

	/**
	 * @param pendingTime
	 *            The pendingTime to set.
	 */
	public void setPendingTime(Date pendingTime) {
		this.pendingTime = pendingTime;
	}

	/**
	 * @return Returns the prosecuter.
	 */
	public String getProsecuter() {
		return prosecuter;
	}

	/**
	 * @param prosecuter
	 *            The prosecuter to set.
	 */
	public void setProsecuter(String prosecuter) {
		this.prosecuter = prosecuter;
	}

	/**
	 * @return Returns the restrictTo.
	 */
	public String getRestrictTo() {
		return restrictTo;
	}

	/**
	 * @param restrictTo
	 *            The restrictTo to set.
	 */
	public void setRestrictTo(String restrictTo) {
		this.restrictTo = restrictTo;
	}

	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return Returns the teamCode.
	 */
	public String getTeamCode() {
		return teamCode;
	}

	/**
	 * @param teamCode
	 *            The teamCode to set.
	 */
	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public String getIsSummaryAdded() {
		return isSummaryAdded;
	}

	public void setIsSummaryAdded(String isSummaryAdd) {
		this.isSummaryAdded = isSummaryAdd;
	}

	public String getIsOverLoadedCase() {
		return isOverLoadedCase;
	}

	public void setIsOverLoadedCase(String isOverLoadedCase) {
		this.isOverLoadedCase = isOverLoadedCase;
	}

	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag
	 *            The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		// Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}

	public String getAccessFlag() {
		return accessFlag;
	}

	public void setAccessFlag(String accessFlag) {
		this.accessFlag = accessFlag;
	}

	public String getInvestigationType() {
		return investigationType;
	}

	public void setInvestigationType(String investigationType) {
		this.investigationType = investigationType;
	}

	public Date getAwaitingTime() {
		return awaitingTime;
	}

	public void setAwaitingTime(Date awaitingTime) {
		this.awaitingTime = awaitingTime;
	}

	public Date getReopenedTime() {
		return reopenedTime;
	}

	public void setReopenedTime(Date reopenedTime) {
		this.reopenedTime = reopenedTime;
	}

	public String getReopenedStaffId() {
		return reopenedStaffId;
	}

	public void setReopenedStaffId(String reopenedStaffId) {
		this.reopenedStaffId = reopenedStaffId;
	}

	public String getOverloadReason() {
		return overloadReason;
	}

	public void setOverloadReason(String overloadReason) {
		this.overloadReason = overloadReason;
	}

	public Long getAcceptanceType() {
		return acceptanceType;
	}

	public void setAcceptanceType(Long acceptanceType) {
		this.acceptanceType = acceptanceType;
	}

	public String getOtherAcceptanceType() {
		return otherAcceptanceType;
	}

	public void setOtherAcceptanceType(String otherAcceptanceType) {
		this.otherAcceptanceType = otherAcceptanceType;
	}

	public String getCpsURN() {
		return cpsURN;
	}

	public void setCpsURN(String cpsURN) {
		this.cpsURN = cpsURN;
	}


}
