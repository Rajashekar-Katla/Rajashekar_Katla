package uk.nhs.cfsms.ecms.data.authentication;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="authorities")
public class Authorities implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
    @Basic
	private String username;
	
	@Basic
	private String authority;
	
	
	public String getAuthority() {
		return authority;
	}
	public void setAuthority(String authority) {
		this.authority = authority;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

}
