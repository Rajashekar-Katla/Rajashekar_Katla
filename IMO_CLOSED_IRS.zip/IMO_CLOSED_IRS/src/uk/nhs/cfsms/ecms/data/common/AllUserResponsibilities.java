package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USER_RESPONSIBILITIES_VIEW")
public class AllUserResponsibilities implements Serializable {

	private static final long serialVersionUID = 476534012L;

	@Id
	@Column(name = "RESP_ID")
	private Integer RESP_ID;

	@Column(name = "STAFF_ID")
	private String staffId;

	@Column(name = "ORG_CODE")
	private String respCode;

	@Column(name = "START_DATE")
	private Date startDate;

	@Column(name = "END_DATE")
	private Date endDate;

	@Column(name = "LEAD")
	private String lead;

	/*
	 * @ManyToOne @JoinColumn(name="STAFF_ID", nullable = false, updatable =
	 * false, insertable = false)
	 * 
	 * private UserObject userDetails;
	 * 
	 */

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getLead() {
		return lead;
	}

	public void setLead(String lead) {
		this.lead = lead;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public Integer getRESP_ID() {
		return RESP_ID;
	}

	public void setRESP_ID(Integer resp_id) {
		RESP_ID = resp_id;
	}

}
