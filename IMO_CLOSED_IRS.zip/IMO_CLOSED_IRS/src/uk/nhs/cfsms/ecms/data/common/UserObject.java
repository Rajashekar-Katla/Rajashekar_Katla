package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ALL_USERS_VIEW")
public class UserObject implements Serializable {

	private static final long serialVersionUID = 476534011L;

	@Id
	@Column(name = "STAFF_ID")
	private String staffId;

	@Column(name = "TITLE")
	private String title;

	@Column(name = "FORENAME1")
	private String firstName;

	@Column(name = "FORENAME2")
	private String middleName;

	@Column(name = "SURNAME")
	private String lastName;

	@Column(name = "KNOWN_AS")
	private String knownAs;

	@Column(name = "EMP_ORGCODE")
	private String employerOrgCode;

	@Column(name = "JOB_TITLE")
	private String jobTitle;

	@Column(name = "TELEPHONE1")
	private String phoneNumber;

	@Column(name = "EXT")
	private String phoneExtension;

	@Column(name = "TELEPHONE2")
	private String phoneNumber2;

	@Column(name = "MOBILE")
	private String mobileNumber;

	@Column(name = "HOME")
	private String homeNumber;

	@Column(name = "PAGER")
	private String pager;

	@Column(name = "FAX")
	private String faxNumber;

	@Column(name = "EMAIL_NHS")
	private String nhsEmailAddress;

	@Column(name = "EMAIL_OTHER")
	private String otherEmailAddress;

	@Column(name = "EMAIL_ADDITIONAL")
	private String additionalEmailAddress;

	@Column(name = "C_ADDRESS1")
	private String address1;

	@Column(name = "C_ADDRESS2")
	private String address2;

	@Column(name = "C_ADDRESS3")
	private String address3;

	@Column(name = "C_ADDRESS4")
	private String address4;

	@Column(name = "C_ADDRESS5")
	private String address5;

	@Column(name = "C_POSTCODE")
	private String postCode;

	@Column(name = "GROUP_ID")
	private String groupPermission;

	@Column(name = "TEAM_CODE")
	private String teamCode;

	@Column(name = "DIRECTORATE")
	private String directorate;
	

	@Column(name = "status")
	private String status;

	/*
	 * 
	 * @OneToMany(mappedBy="userdetails",cascade = {CascadeType.ALL}, fetch =
	 * FetchType.EAGER, targetEntity=LcfsResponsibilities.class)
	 * @JoinColumn(name="ID") @org.hibernate.annotations.Cascade( value =
	 * org.hibernate.annotations.CascadeType.DELETE_ORPHAN )
	 * 
	 * private List LcfsResponsibilities = new ArrayList();
	 * 
	 * public List getLcfsResponsibilities() { return LcfsResponsibilities; }
	 * 
	 *  /* private List permissions = new ArrayList();
	 * 
	 * public List getPermissions() { return permissions; } public void
	 * setPermissions(List permissions) { this.permissions = permissions; }
	 */

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAdditionalEmailAddress() {
		return additionalEmailAddress;
	}

	public void setAdditionalEmailAddress(String additionalEmailAddress) {
		this.additionalEmailAddress = additionalEmailAddress;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getAddress5() {
		return address5;
	}

	public void setAddress5(String address5) {
		this.address5 = address5;
	}

	public String getEmployerOrgCode() {
		return employerOrgCode;
	}

	public void setEmployerOrgCode(String employerOrgCode) {
		this.employerOrgCode = employerOrgCode;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getKnownAs() {
		return knownAs;
	}

	public void setKnownAs(String knownAs) {
		this.knownAs = knownAs;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getOtherEmailAddress() {
		return otherEmailAddress;
	}

	public void setOtherEmailAddress(String otherEmailAddress) {
		this.otherEmailAddress = otherEmailAddress;
	}

	public String getPhoneExtension() {
		return phoneExtension;
	}

	public void setPhoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber2() {
		return phoneNumber2;
	}

	public void setPhoneNumber2(String phoneNumber2) {
		this.phoneNumber2 = phoneNumber2;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postalCode) {
		this.postCode = postalCode;
	}

	public String getStaffId() {
		return staffId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getGroupPermission() {
		return groupPermission;
	}

	public void setGroupPermission(String groupPermission) {
		this.groupPermission = groupPermission;
	}

	public String getPager() {
		return pager;
	}

	public void setPager(String pager) {
		this.pager = pager;
	}

	public String getHomeNumber() {
		return homeNumber;
	}

	public void setHomeNumber(String homeNumber) {
		this.homeNumber = homeNumber;
	}

	public String getNhsEmailAddress() {
		return nhsEmailAddress;
	}

	public void setNhsEmailAddress(String nhsEmailAddress) {
		this.nhsEmailAddress = nhsEmailAddress;
	}

	/*
	 * public void setLcfsResponsibilities(List lcfsResponsibilities) {
	 * LcfsResponsibilities = lcfsResponsibilities; }
	 */

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public String getDirectorate() {
		return directorate;
	}

	public void setDirectorate(String directorate) {
		this.directorate = directorate;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

}