package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
@Entity
@Table(name = "temp_conf_case_tbl")
public class TempConfCase implements Serializable {

	private static final long serialVersionUID = 4939871235L;
	
	@Id
	@Column(name = "CONF_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "conf_ID_SQNC") })
	private Long tempConfId;
	
	@Column(name = "case_ID")
	private Long caseId;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getTempConfId() {
		return tempConfId;
	}

	public void setTempConfId(Long tempConfId) {
		this.tempConfId = tempConfId;
	}
	
	
	
}
