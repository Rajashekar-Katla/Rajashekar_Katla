

package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import uk.nhs.cfsms.ecms.data.common.Organisation;

@Entity
@Table(name = "FC_INFORMATION_TBL")
/**
 * Information has details of the fraud allegation details.
 * 
 * @author schilukuri
 * 
 */
public class FcrolInformation implements Serializable {

	private static final long serialVersionUID = 1530234L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "INFORMATION_ID_SQNC") })
	@Column(name = "INFORMATION_ID")
	private Long informationId;

	@Column(name = "INFORMATION_NUM")
	private String informationNum;

	@Column(name = "DESCRIPTION")
	private String comment;

	@Column(name = "TYPE")
	private String type;

	@Column(name = "COST")
	private BigDecimal cost;

	@Column(name = "IS_STILL_FRAUD_OCCURING")
	private String isStillFraudOccuring;

	@Column(name = "START_DATE")
	private Date startDate;

	@Column(name = "IS_START_DATE_CORRECT")
	private String isStartDateCorrect;

	@OneToOne(optional = false)
	@JoinColumn(name = "ORG_CODE", unique = true, nullable = false)
	private Organisation organisation;

	@Column(name = "INFORMATION_DISCARDED")
	private String informationDiscarded;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "INFORMATION_SOURCE_ID")
	private FcrolSourceInformation sourceInformation;

	@Column(name = "CREATED_TIME", updatable = false)
	private Timestamp createdDate;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;

	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "region_override")
	private String  regionOverride;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "INFORMATION_ID", nullable = false, updatable = false)
	@OrderBy("subjectId")
	private List<FcrolSubjectInformation> subjectInformation = new ArrayList<FcrolSubjectInformation>();
	//private Set<SubjectInformation> subjectInformation = new HashSet<SubjectInformation>();
	
	

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "INFORMATION_ID", nullable = false, updatable = false)
	@OrderBy("subjectNonNhsId")
	private List<FcrolNonNHSSubjectInformation> nonNHSsubjectInformation = new ArrayList<FcrolNonNHSSubjectInformation>();
	//private Set<NonNHSSubjectInformation> nonNHSsubjectInformation = new HashSet<NonNHSSubjectInformation>();

	

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "INFO_ID", nullable = false, updatable = false)
	private Set<FcrolVehicle> vehicles = new HashSet<FcrolVehicle>();

	@Column(name = "TITLE")
	private String title;

	@Column(name = "INFORMATION")
	@Type(type="uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch =FetchType.EAGER)
	private String informationDetails;

	@Column(name = "INTELLIGENCE_CONTENT")
	private String intelligenceContent;

	@Column(name = "INTELLIGENCE_URN")
	private String intelligenceURN;

	@Column(name = "INFORMATION_DATE")
	private Date informationDate;

	@Column(name = "TEAM_CODE")
	private String teamCode;
	
	@Column(name = "REJECT_COMMENT")
	private String rejectedComment;
	
	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";
	
	@Column(name = "STATE")
	private String state ;
	
	@Column(name = "data_Cleansed_Flag")
	private String dataCleansedFlag;
	
	@Column(name = "reviewed_Staff_Id")
	private String reviewedStaffId;
	
	@Column(name = "reviewed_date")
	private Timestamp reviewedDate;
	
	
	@Column(name = "reject_reason")
	private String rejectReason;
	
	
	
	@Column(name = "fcrol_id")
	private Long fcrolId;

	public Timestamp getReviewedDate() {
		return reviewedDate;
	}

	public void setReviewedDate(Timestamp reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	public String getReviewedStaffId() {
		return reviewedStaffId;
	}

	public void setReviewedStaffId(String reviewedStaffId) {
		this.reviewedStaffId = reviewedStaffId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public BigDecimal getCost() {
		return cost == null ? cost : cost.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getInformationDiscarded() {
		return informationDiscarded;
	}

	public void setInformationDiscarded(String informationDiscarded) {
		this.informationDiscarded = informationDiscarded;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getInformationNum() {
		return informationNum;
	}

	public void setInformationNum(String informationNum) {
		this.informationNum = informationNum;
	}

	public String getIsStartDateCorrect() {
		return isStartDateCorrect;
	}

	public void setIsStartDateCorrect(String isStartDateCorrect) {
		this.isStartDateCorrect = isStartDateCorrect;
	}

	public String getIsStillFraudOccuring() {
		return isStillFraudOccuring;
	}

	public void setIsStillFraudOccuring(String isStillFraudOccuring) {
		this.isStillFraudOccuring = isStillFraudOccuring;
	}

	public FcrolSourceInformation getSourceInformation() {
		return sourceInformation;
	}

	public void setSourceInformation(FcrolSourceInformation sourceInformation) {
		this.sourceInformation = sourceInformation;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

//	public Set<SubjectInformation> getSubjectInformation() {
//		return subjectInformation;
//	}
//
//	public void setSubjectInformation(Set<SubjectInformation> subjectInformation) {
//		this.subjectInformation = subjectInformation;
//	}
//	
//	public Set<NHSSubjectInformation> getNHSSubjectInformation() {
//		return nHSSubjectInformation;
//	}
//
//	public void setNHSSubjectInformation(
//			Set<NHSSubjectInformation> subjectInformation) {
//		nHSSubjectInformation = subjectInformation;
//	}
//
//	public Set<NonNHSSubjectInformation> getNonNHSsubjectInformation() {
//		return nonNHSsubjectInformation;
//	}
//
//	public void setNonNHSsubjectInformation(
//			Set<NonNHSSubjectInformation> nonNHSsubjectInformation) {
//		this.nonNHSsubjectInformation = nonNHSsubjectInformation;
//	}
	
	public List<FcrolSubjectInformation> getSubjectInformation() {
		return subjectInformation;
	}

	public void setSubjectInformation(List<FcrolSubjectInformation> subjectInformation) {
		this.subjectInformation = subjectInformation;
	}

	
	

	public List<FcrolNonNHSSubjectInformation> getNonNHSsubjectInformation() {
		return nonNHSsubjectInformation;
	}

	public void setNonNHSsubjectInformation(
			List<FcrolNonNHSSubjectInformation> nonNHSsubjectInformation) {
		this.nonNHSsubjectInformation = nonNHSsubjectInformation;
	}

	public Organisation getOrganisation() {
		return organisation;
	}

	public void setOrganisation(Organisation organisation) {
		this.organisation = organisation;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Date getInformationDate() {
		return informationDate;
	}

	public void setInformationDate(Date informationDate) {
		this.informationDate = informationDate;
	}

	public String getInformationDetails() {
		return informationDetails;
	}

	public void setInformationDetails(String informationDetails) {
		this.informationDetails = informationDetails;
	}

	public String getIntelligenceContent() {
		return intelligenceContent;
	}

	public void setIntelligenceContent(String intelligenceContent) {
		this.intelligenceContent = intelligenceContent;
	}

	public String getIntelligenceURN() {
		return intelligenceURN;
	}

	public void setIntelligenceURN(String intelligenceURN) {
		this.intelligenceURN = intelligenceURN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	

	public Set<FcrolVehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(Set<FcrolVehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public String getRejectedComment() {
		return rejectedComment;
	}

	public void setRejectedComment(String rejectedComment) {
		this.rejectedComment = rejectedComment;
	}

	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		//Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}

	public String getRegionOverride() {
		return regionOverride;
	}

	public void setRegionOverride(String regionOverride) {
		this.regionOverride = regionOverride;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDataCleansedFlag() {
		return dataCleansedFlag;
	}

	public void setDataCleansedFlag(String dataCleansedFlag) {
		this.dataCleansedFlag = dataCleansedFlag;
	}

	public Long getFcrolId() {
		return fcrolId;
	}

	public void setFcrolId(Long fcrolId) {
		this.fcrolId = fcrolId;
	}

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

}
