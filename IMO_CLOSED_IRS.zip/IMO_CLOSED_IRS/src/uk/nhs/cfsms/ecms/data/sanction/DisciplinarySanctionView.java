package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DISCIPLINARY_SANCTION_VIEW")
public class DisciplinarySanctionView implements Serializable {

	private static final long serialVersionUID = 502505021L;

	@Id
	@Column(name = "DISCIPLINARY_SANCTION_ID")
	private Long disciplinarySanctionId;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "SUBJECT_ID")
	private Long subjectId;

	@Column(name = "SUBJECT_TYPE")
	private String subjectType;

	@Column(name = "CREATED_STAFF_ID")
	private String createdStaffId;

	@Column(name = "CREATED_TIME")
	private Date createdTime;

	@Column(name = "SANCTION_TYPE")
	private String sanctionType;

	@Column(name = "STATE")
	private String state;

	@Column(name = "HR_CONTACT")
	private String humanResourceContact;

	@Column(name = "INVST_MGR_CONTACT")
	private String investigationManagerContact;

	@Column(name = "PROF_CONTACT")
	private String professionalContact;

	@Column(name = "HB_CONTACT")
	private String healthBodyContact;

	@Column(name = "ORG_NAME")
	private String organisationName;

	@Column(name = "START_DATE")
	private Date startDate;

	@Column(name = "NHS_SUBJECT_NAME")
	private String nhsSubjectName;

	@Column(name = "NON_NHS_SUBJECT_NAME")
	private String nonNhsSubjectName;

	@Column(name = "PERSON_SUBJECT_NAME")
	private String personSubjectName;

	@Column(name = "INTERNAL_ORG_NAME")
	private String internalOrganisationName;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getDisciplinarySanctionId() {
		return disciplinarySanctionId;
	}

	public void setDisciplinarySanctionId(Long disciplinarySanctionId) {
		this.disciplinarySanctionId = disciplinarySanctionId;
	}

	public String getHealthBodyContact() {
		return healthBodyContact;
	}

	public void setHealthBodyContactId(String healthBodyContactId) {
		this.healthBodyContact = healthBodyContact;
	}

	public String getHumanResourceContact() {
		return humanResourceContact;
	}

	public void setHumanResourceContactId(String humanResourceContactId) {
		this.humanResourceContact = humanResourceContact;
	}

	public String getInvestigationManagerContact() {
		return investigationManagerContact;
	}

	public void setInvestigationManagerContact(
			String investigationManagerContact) {
		this.investigationManagerContact = investigationManagerContact;
	}

	public String getNhsSubjectName() {
		return nhsSubjectName;
	}

	public void setNhsSubjectName(String nhsSubjectName) {
		this.nhsSubjectName = nhsSubjectName;
	}

	public String getNonNhsSubjectName() {
		return nonNhsSubjectName;
	}

	public void setNonNhsSubjectName(String nonNhsSubjectName) {
		this.nonNhsSubjectName = nonNhsSubjectName;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getPersonSubjectName() {
		return personSubjectName;
	}

	public void setPersonSubjectName(String personSubjectName) {
		this.personSubjectName = personSubjectName;
	}

	public String getProfessionalContact() {
		return professionalContact;
	}

	public void setProfessionalContact(String professionalContact) {
		this.professionalContact = professionalContact;
	}

	public String getSanctionType() {
		return sanctionType;
	}

	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	/**
	 * @return the internalOrganisationName
	 */
	public String getInternalOrganisationName() {
		return internalOrganisationName;
	}

	/**
	 * @param internalOrganisationName
	 *            the internalOrganisationName to set
	 */
	public void setInternalOrganisationName(String internalOrganisationName) {
		this.internalOrganisationName = internalOrganisationName;
	}

	/**
	 * @param humanResourceContact
	 *            the humanResourceContact to set
	 */
	public void setHumanResourceContact(String humanResourceContact) {
		this.humanResourceContact = humanResourceContact;
	}

	/**
	 * @param healthBodyContact
	 *            the healthBodyContact to set
	 */
	public void setHealthBodyContact(String healthBodyContact) {
		this.healthBodyContact = healthBodyContact;
	}

}
