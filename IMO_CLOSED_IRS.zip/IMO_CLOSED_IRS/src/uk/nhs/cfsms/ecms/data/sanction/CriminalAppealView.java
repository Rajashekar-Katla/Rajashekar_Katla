package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table; 

@Entity
@Table(name = "CRIMINAL_APPEAL_VIEW")
public class CriminalAppealView implements Serializable {

	private static final long serialVersionUID = 888889999L;
	
	@Id
	@Column(name = "APPEAL_ID")
	private Long appealId;
	
	@Column(name = "PARENT_APPEAL_ID")
	private Long parentAppealId;
	
	@Column(name = "SANCTION_ID")
	private Long sanctionId;
	
	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "SUBJECT_ID")
	private Long subjectId;

	@Column(name = "SUBJECT_TYPE")
	private String subjectType;
		
	@Column(name = "CREATED_STAFF_ID" , insertable=true, updatable=false)	
	private String createdStaffId;
		
	@Column(name = "CREATED_TIME" , insertable=true, updatable=false)	
	private Date createdTime;
	
	@Column(name = "APPEARED_DATE")
	private Date appearedDate;
	
	@Column(name = "COURT_MAKING_DEC_NAME")
	private String courtMakingDecName;
	
	@Column(name = "STATE")
	private String state;

	@Column(name = "NHS_SUBJECT_NAME")
	private String nhsSubjectName;
	
	@Column(name = "NON_NHS_SUBJECT_NAME")
	private String nonNhsSubjectName;
	
	@Column(name = "PERSON_SUBJECT_NAME")
	private String personSubjectName;
	
	@Column(name = "APPEAL_MAKER")
	private String appealMaker;
	
	@Column(name = "OTHER_SUBJECT")
	private String otherSubject;
	

	@Column(name = "APPELLANT_NAME")
	private String appellantName;
	
	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the createdStaffId.
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	/**
	 * @param createdStaffId The createdStaffId to set.
	 */
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	/**
	 * @return Returns the createdTime.
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime The createdTime to set.
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return Returns the criminalSanctionId.
	 */
	public Long getAppealId() {
		return appealId;
	}

	/**
	 * @param criminalSanctionId The criminalSanctionId to set.
	 */
	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public Date getAppearedDate() {
		return appearedDate;
	}

	public void setAppearedDate(Date appearedDate) {
		this.appearedDate = appearedDate;
	}

	public String getCourtMakingDecName() {
		return courtMakingDecName;
	}

	public void setCourtMakingDecName(String courtMakingDecName) {
		this.courtMakingDecName = courtMakingDecName;
	}

	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return Returns the subjectId.
	 */
	public Long getSubjectId() {
		return subjectId;
	}

	/**
	 * @param subjectId The subjectId to set.
	 */
	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	/**
	 * @return Returns the subjectType.
	 */
	public String getSubjectType() {
		return subjectType;
	}

	/**
	 * @param subjectType The subjectType to set.
	 */
	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	/**
	 * @return Returns the nhsSubjectName.
	 */
	public String getNhsSubjectName() {
		return nhsSubjectName;
	}

	/**
	 * @param nhsSubjectName The nhsSubjectName to set.
	 */
	public void setNhsSubjectName(String nhsSubjectName) {
		this.nhsSubjectName = nhsSubjectName;
	}

	/**
	 * @return Returns the nonNhsSubjectName.
	 */
	public String getNonNhsSubjectName() {
		return nonNhsSubjectName;
	}

	/**
	 * @param nonNhsSubjectName The nonNhsSubjectName to set.
	 */
	public void setNonNhsSubjectName(String nonNhsSubjectName) {
		this.nonNhsSubjectName = nonNhsSubjectName;
	}

	/**
	 * @return Returns the personSubjectName.
	 */
	public String getPersonSubjectName() {
		return personSubjectName;
	}

	/**
	 * @param personSubjectName The personSubjectName to set.
	 */
	public void setPersonSubjectName(String personSubjectName) {
		this.personSubjectName = personSubjectName;
	}
	
	public String getAppealMaker() {
		return appealMaker;
	}

	public void setAppealMaker(String appealMaker) {
		this.appealMaker = appealMaker;
	}
	
	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}

	public String getOtherSubject() {
		return otherSubject;
	}

	public void setOtherSubject(String otherSubject) {
		this.otherSubject = otherSubject;
	}

	public String getAppellantName() {
		return appellantName;
	}

	public void setAppellantName(String appellantName) {
		this.appellantName = appellantName;
	}

}
