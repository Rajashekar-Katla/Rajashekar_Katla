package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
import uk.nhs.cfsms.ecms.data.common.UserObject;


@Entity
@Table(name="CASE_ACTION_BOOK_TBL")
@Audited
public class CaseActionBook implements Serializable {
	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = @Parameter(name = "sequence", value = "ACTION_ID_SEQ"))
	@Column(name="ACTION_ID")
	private Long caseActionBookId;
	
	@Column(name="ACTION_NUMBER")
	@DisplayedLoggedProperty(displayName = "Action Number")
	private Long actionNumber;
	
	@Column(name="CASE_ID")
    private Long caseID;
	
	@Column(name="RECORDING_DATE", updatable = false)
	@DisplayedLoggedProperty(displayName = "Date Recorded")
	private Date dateRecorded;
	
	@Column(name="ALLOCATED_BY")
	@DisplayedLoggedProperty(displayName = "Allocated By")
	private String allocatedBy;
	
	@Column(name="SOURCE_REFERENCE")
	@DisplayedLoggedProperty(displayName = "Source Reference")
	private String sourceReference;
	
	@Column(name="ACTION_REQUIRED")
	@DisplayedLoggedProperty(displayName = "Action Required")
	private String actionRequired;
	
	@Column(name="ALLOCATION_DATE")
	@DisplayedLoggedProperty(displayName = "Date Alocated")
	private Date dateAllocated;
	
	@Column(name="ALLOCATED_TO")
	@DisplayedLoggedProperty(displayName = "Allocated To")
	private String allocatedTo;
	
	@Column(name="ACTION_RESULT")
	@DisplayedLoggedProperty(displayName = "Result")
	private String result;
	
	@Column(name="SEEN_BY_OFM")
	@DisplayedLoggedProperty(displayName = "Seen By OFM")
	private String seenByOFM;
	
	@Column(name="COMPLETION_DATE")
	@DisplayedLoggedProperty(displayName = "Date Completed")
	private Date dateCompleted;
	
	@Column(name="SENSITIVE")
	@DisplayedLoggedProperty(displayName = "Sensivity")
	private String sentivity;
	
	@Column(name="DUE_DATE")
	@DisplayedLoggedProperty(displayName = "Due Date")
	private Date dueDate;
	
	@Column(name="ACTION_STATUS")
	@DisplayedLoggedProperty(displayName = "Action Status")
	private String actionStatus;
	
	@NotFound(action = NotFoundAction.IGNORE)
	@ManyToOne(targetEntity= UserObject.class, optional = true)
	@JoinColumn(name="ALLOCATED_TO", insertable = false, updatable = false, nullable = true )
	@NotAudited
	private UserObject allocatedToUser;
	
	@NotFound(action = NotFoundAction.IGNORE)
	@ManyToOne(targetEntity= UserObject.class, optional = true)
	@JoinColumn(name="ALLOCATED_BY", insertable = false, updatable = false, nullable = true  )
	@NotAudited
	private UserObject allocatedByUser;
	
	
	public UserObject getAllocatedToUser() {
		return allocatedToUser;
	}

	public void setAllocatedToUser(UserObject allocatedToUser) {
		this.allocatedToUser = allocatedToUser;
	}

	public UserObject getAllocatedByUser() {
		return allocatedByUser;
	}

	public void setAllocatedByUser(UserObject allocatedByUser) {
		this.allocatedByUser = allocatedByUser;
	}

	public Long getCaseActionBookId() {
		return caseActionBookId;
	}

	public void setCaseActionBookId(Long caseActionBookId) {
		this.caseActionBookId = caseActionBookId;
	}

	public Long getCaseID() {
		return caseID;
	}

	public void setCaseID(Long caseID) {
		this.caseID = caseID;
	}

	public Date getDateRecorded() {
		return dateRecorded;
	}

	public void setDateRecorded(Date dateRecorded) {
		this.dateRecorded = dateRecorded;
	}

	public String getAllocatedBy() {
		return allocatedBy;
	}

	public void setAllocatedBy(String allocatedBy) {
		this.allocatedBy = allocatedBy;
	}

	public String getSourceReference() {
		return sourceReference;
	}

	public void setSourceReference(String sourceReference) {
		this.sourceReference = sourceReference;
	}

	public String getActionRequired() {
		return actionRequired;
	}

	public void setActionRequired(String actionRequired) {
		this.actionRequired = actionRequired;
	}

	public Date getDateAllocated() {
		return dateAllocated;
	}

	public void setDateAllocated(Date dateAllocated) {
		this.dateAllocated = dateAllocated;
	}

	public String getAllocatedTo() {
		return allocatedTo;
	}

	public void setAllocatedTo(String allocatedTo) {
		this.allocatedTo = allocatedTo;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getSeenByOFM() {
		return seenByOFM;
	}

	public void setSeenByOFM(String seenByOFM) {
		this.seenByOFM = seenByOFM;
	}

	public Date getDateCompleted() {
		return dateCompleted;
	}

	public void setDateCompleted(Date dateCompleted) {
		this.dateCompleted = dateCompleted;
	}

	public String getSentivity() {
		return sentivity;
	}

	public void setSentivity(String sentivity) {
		this.sentivity = sentivity;
	}

	public Long getActionNumber() {
		return actionNumber;
	}

	public void setActionNumber(Long actionNumber) {
		this.actionNumber = actionNumber;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getActionStatus() {
		return actionStatus;
	}

	public void setActionStatus(String actionStatus) {
		this.actionStatus = actionStatus;
	}

	
	


	
}
