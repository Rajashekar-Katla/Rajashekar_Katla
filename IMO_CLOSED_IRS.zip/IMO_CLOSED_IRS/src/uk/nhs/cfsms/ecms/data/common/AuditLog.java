package uk.nhs.cfsms.ecms.data.common;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.sql.rowset.serial.SerialBlob;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Class represents and audit log entry
 * 
 * @author Sukhraj Matharu
 * 
 */

@Entity
@Table(name = "AUDIT_LOG")
public class AuditLog implements Serializable {

	private static final long serialVersionUID = 503422111L;

	@Transient
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The unique for the table
	 */
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "AUDIT_ID_SQNC") })
	@Column(name = "AUDIT_LOG_ID")
	private long id;

	/**
	 * The id of the object being audited
	 */
	@Column(name = "OBJECT_ID")
	private long objectId;

	/**
	 * A string representation of the properties of the object
	 */
	@Column(name = "PROPERTIES")
	@Basic(fetch=FetchType.EAGER)
	private Blob properties;

	/**
	 * An integer representation the state of the audit
	 * 
	 */
	@Column(name = "STATE")
	private String state;

	/**
	 * The created time of the audit
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_DATE", columnDefinition = "Timestamp default sysdate", nullable = false)
	private Date createdDate;

	/**
	 * The user who actioned the event
	 */
	@Column(name = "USER_ID")
	private String userId;

	@Transient
	private byte[] byteData;

	@Transient
	private Class objectClass = null;

	@Transient
	private String objectDesc;

	/**
	 * Action description. What action is performed
	 */
	@Column(name = "ACTION")
	private String action;

	/**
	 * Action description. What action is performed
	 */
	@Column(name = "TABLE_NAME")
	private String tableName;

	/**
	 * @return Returns the createdDate.
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            The createdDate to set.
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return Returns the id.
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id
	 *            The id to set.
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return Returns the objectId.
	 */
	public long getObjectId() {
		return objectId;
	}

	/**
	 * @param objectId
	 *            The objectId to set.
	 */
	public void setObjectId(long objectId) {
		this.objectId = objectId;
	}

	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return Returns the userId.
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public byte[] getByteData() {
		return byteData;
	}

	/**
	 * reset the dataBlob as it has changed and this is all that hibernate is
	 * interested in
	 * 
	 * @param byteData
	 */
	public void setByteData(byte[] byteData) {
		this.byteData = byteData;
		// properties = Hibernate.createBlob(this.byteData);
	}

	/**
	 * Don't invoke this. Used by Hibernate only.
	 */
	public void setProperties(Blob dataBlob) {
		this.byteData = this.toByteArray(dataBlob);
		// this.properties = dataBlob;
		// this.byteData = this.toByteArray(dataBlob);
	}

	/**
	 * Don't invoke this. Used by Hibernate only.
	 */
	public Blob getProperties() {
		//Hibernate.createBlob(this.byteData);
		try {
			return  new SerialBlob(this.byteData);
		} catch (Exception exc){
			throw new RuntimeException(exc);
		}
		// return properties;
	}

	private byte[] toByteArray(Blob fromBlob) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			return toByteArrayImpl(fromBlob, baos);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			if (baos != null) {
				try {
					baos.close();
				} catch (IOException ex) {
				}
			}
		}
	}

	private byte[] toByteArrayImpl(Blob fromBlob, ByteArrayOutputStream baos)
			throws SQLException, IOException {
		
		byte[] buf = new byte[4000];
		InputStream is = fromBlob.getBinaryStream();
		try {
			for (;;) {
				int dataSize = is.read(buf);
				if (dataSize == -1)
					break;
				baos.write(buf, 0, dataSize);
			}
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException ex) {
				}
			}
		}
		return baos.toByteArray();
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public Class getObjectClass() {
		return objectClass;
	}

	public void setObjectClass(Class objectClass) {
		this.objectClass = objectClass;
	}

	public String getObjectDesc() {
		
		if (null != this.byteData) {
			
			//System.out.println("\n** byteData=" + this.byteData.toString()+ ", length=" + this.byteData.length);
			
			objectDesc = this.byteData.toString();
		}
		else {
			objectDesc = "-";
		}
		
		return objectDesc;
	}

	public void setObjectDesc(String objectDesc) {
		this.objectDesc = objectDesc;
	}

}
