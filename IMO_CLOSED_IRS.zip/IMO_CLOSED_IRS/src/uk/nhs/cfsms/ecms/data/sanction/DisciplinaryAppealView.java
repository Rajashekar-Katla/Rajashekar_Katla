package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DISCIPLINARY_APPEAL_VIEW")
public class DisciplinaryAppealView implements Serializable {
	
	private static final long serialVersionUID = 75465505021L; 
	
	@Id
	@Column(name = "APPEAL_ID")
	private Long appealId;
	
	@Column(name = "SANCTION_ID")
	private Long sanctionId;
	
	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "SUBJECT_ID")
	private Long subjectId;
	
	@Column(name = "SUBJECT_TYPE")
	private String subjectType;
	
	@Column(name = "CREATED_STAFF_ID")	
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME")	
	private Date createdTime;
	
	@Column(name = "SANCTION_TYPE")
	private String sanctionType;
	
	@Column(name = "STATE")
	private String state;

	@Column(name = "HR_CONTACT")
	private String humanResourceContact;
	
	@Column(name = "INVST_MGR_CONTACT")
	private String investigationManagerContact;
	
	@Column(name = "PROF_CONTACT")
	private String professionalContact;
	
	@Column(name = "HB_CONTACT")
	private String healthBodyContact;
	
	@Column(name = "ORG_NAME")
	private String organisationName;

	@Column(name = "START_DATE")
	private Date appealedDate;

	@Column(name = "NHS_SUBJECT_NAME")
	private String nhsSubjectName;
	
	@Column(name = "NON_NHS_SUBJECT_NAME")
	private String nonNhsSubjectName;
	
	@Column(name = "PERSON_SUBJECT_NAME")
	private String personSubjectName;
	
	@Column(name = "ORG_MAK_DEC_NAME")
	private String organisationMakingDecisionName;
	
	@Column(name = "OTHER_SUBJECT")
	private String otherSubject;
	
	@Column(name = "APPEAL_MAKER")
	private String appealMaker;
	
	@Column(name = "PARENT_APPEAL_ID" , insertable=false, updatable =false)
	private Long parentAppealId;
	
/*    @ManyToOne(cascade={CascadeType.ALL})
    @JoinColumn(name="PARENT_APPEAL_ID")
    private DisciplinaryAppealView parentAppeal;
 
    @OneToMany(mappedBy="parentAppeal")
    private Set<DisciplinaryAppealView> childAppeals = new HashSet<DisciplinaryAppealView>();
	
*/	
	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public String getHealthBodyContact() {
		return healthBodyContact;
	}

	public void setHealthBodyContact(String healthBodyContact) {
		this.healthBodyContact = healthBodyContact;
	}

	public String getHumanResourceContact() {
		return humanResourceContact;
	}

	public void setHumanResourceContact(String humanResourceContact) {
		this.humanResourceContact = humanResourceContact;
	}

	public String getInvestigationManagerContact() {
		return investigationManagerContact;
	}

	public void setInvestigationManagerContact(String investigationManagerContact) {
		this.investigationManagerContact = investigationManagerContact;
	}

	public String getNhsSubjectName() {
		return nhsSubjectName;
	}

	public void setNhsSubjectName(String nhsSubjectName) {
		this.nhsSubjectName = nhsSubjectName;
	}

	public String getNonNhsSubjectName() {
		return nonNhsSubjectName;
	}

	public void setNonNhsSubjectName(String nonNhsSubjectName) {
		this.nonNhsSubjectName = nonNhsSubjectName;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getPersonSubjectName() {
		return personSubjectName;
	}

	public void setPersonSubjectName(String personSubjectName) {
		this.personSubjectName = personSubjectName;
	}

	public String getProfessionalContact() {
		return professionalContact;
	}

	public void setProfessionalContact(String professionalContact) {
		this.professionalContact = professionalContact;
	}

	public String getSanctionType() {
		return sanctionType;
	}

	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

	public Date getAppealedDate() {
		return appealedDate;
	}

	public void setAppealedDate(Date appealedDate) {
		this.appealedDate = appealedDate;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}
	
	public String getOrganisationMakingDecisionName() {
		return organisationMakingDecisionName;
	}

	public void setOrganisationMakingDecisionName(
			String organisationMakingDecisionName) {
		this.organisationMakingDecisionName = organisationMakingDecisionName;
	}

	public String getOtherSubject() {
		return otherSubject;
	}

	public void setOtherSubject(String otherSubject) {
		this.otherSubject = otherSubject;
	}

	public String getAppealMaker() {
		return appealMaker;
	}

	public void setAppealMaker(String appealMaker) {
		this.appealMaker = appealMaker;
	}

	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}
 
}
