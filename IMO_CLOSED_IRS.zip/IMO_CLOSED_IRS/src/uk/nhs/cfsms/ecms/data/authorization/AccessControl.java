package uk.nhs.cfsms.ecms.data.authorization;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ACCESS_CONTROL_TBL")
public class AccessControl implements Serializable {

	private static final long serialVersionUID = 4357064L;

	@Id
	@Column(name = "ACCESS_ID")
	private Long accessId;

	@Column(name = "URL_PATH")
	private String path;

	@Column(name = "ACCESS_LEVELS")
	private String accessLevels;

	@Column(name = "ORIGINAL_TABLE")
	private String originTable;

	@Column(name = "PARENT_ACCESS_ID")
	private String parentAccessId;

	@Column(name = "TBL_PRI_COL_NAME")
	private String primaryColumnName;

	@Column(name = "URL_PARAMS")
	private String urlParams;

	public Long getAccessId() {
		return accessId;
	}

	public void setAccessId(Long accessId) {
		this.accessId = accessId;
	}

	public String getAccessLevels() {
		return accessLevels;
	}

	public void setAccessLevels(String accessLevels) {
		this.accessLevels = accessLevels;
	}

	public String getOriginTable() {
		return originTable;
	}

	public void setOriginTable(String originTable) {
		this.originTable = originTable;
	}

	public String getParentAccessId() {
		return parentAccessId;
	}

	public void setParentAccessId(String parentAccessId) {
		this.parentAccessId = parentAccessId;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getPrimaryColumnName() {
		return primaryColumnName;
	}

	public void setPrimaryColumnName(String primaryColumnName) {
		this.primaryColumnName = primaryColumnName;
	}

	public String getUrlParams() {
		return urlParams;
	}

	public void setUrlParams(String urlParams) {
		this.urlParams = urlParams;
	}

	public String[] getAllUrlParams() {

		List<String> urlParamList = new ArrayList<String>();

		if (this.urlParams != null) {
			StringTokenizer strTokens = new StringTokenizer(this.urlParams, ";");

			while (strTokens.hasMoreTokens()) {
				urlParamList.add(strTokens.nextToken());
			}
		}
		return urlParamList.toArray(new String[urlParamList.size()]);
	}
}