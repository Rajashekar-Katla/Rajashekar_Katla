package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "PERSON_TBL")
/**
 * Person contain personal, address and contacts details
 * 
 * @author schilukuri who ?
 * 
 */
@Audited
public class Person implements Serializable {

	private static final long serialVersionUID = 734136195L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "PERSON_ID_SQNC") })
	@Column(name = "PERSON_ID")
	@DisplayedLoggedProperty(displayName = "Person Id")
	private Long personId;

	@Column(name = "TITLE")
	@DisplayedLoggedProperty(displayName = "Title")
	private String title;
	
	@Column(name = "OTHER_TITLE")
	@DisplayedLoggedProperty(displayName = "Other Title")
	private String otherTitle;

	@Column(name = "FIRST_NAME")
	@DisplayedLoggedProperty(displayName = "First Name")
	private String firstName;

	@Column(name = "LAST_NAME")
	@DisplayedLoggedProperty(displayName = "Last Name")
	private String lastName;

	@Column(name = "OTHER_NAME")
	@DisplayedLoggedProperty(displayName = "Other Name")
	private String otherName;

	@Column(name = "OCCUPATION")
	@DisplayedLoggedProperty(displayName = "Occupation")
	private String occupation;

	@Column(name = "ORG_NAME")
	@DisplayedLoggedProperty(displayName = "Organisation Name")
	private String orgName;

	@Column(name = "DOB")
	@DisplayedLoggedProperty(displayName = "Date Of Birth")
	private Date dob;

	@Column(name = "GENDER")
	@DisplayedLoggedProperty(displayName = "Gender")
	private String gender;

	@Column(name = "NI_NUMBER")
	@DisplayedLoggedProperty(displayName = "NI Number")
	private String nINumber;

	@Column(name = "PERSON_TYPE")
	@DisplayedLoggedProperty(displayName = "Person Type")
	private String personType;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "PERSON_DESCRIPTION_ID")
	private PersonDescription personDescription;

	@Column(name = "KNOWN_AS")
	@DisplayedLoggedProperty(displayName = "Known As")
	private String knownAs;
	
	@Column(name = "IS_PERSON_NHS")
	@DisplayedLoggedProperty(displayName = "Is Person NHS")
	private String isPersonNhs;

	@Column(name = "OTHER_OCCUPATION")
	@DisplayedLoggedProperty(displayName = "Other Occupation")
	private String otherOccupation;

	@Column(name = "NATIONALITY")
	@DisplayedLoggedProperty(displayName = "Nationality")
	private String nationality;

	@Column(name = "ETHNIC_CODE")
	@DisplayedLoggedProperty(displayName = "Ethnic Code")
	private String ethnicCode;

	@Column(name = "PASSPORT_NUMBER")
	@DisplayedLoggedProperty(displayName = "Passport Number")
	private String passportNumber;

	@Column(name = "DRIVING_LICENSE_NUMBER")
	@DisplayedLoggedProperty(displayName = "Driving License Number")
	private String drivingLicenseNumber;

	@Column(name = "NHS_NUMBER")
	@DisplayedLoggedProperty(displayName = "NHS Number")
	private String nhsNumber;

	@Column(name = "PAYROLL_NUMBER")
	@DisplayedLoggedProperty(displayName = "Payroll Number")
	private String payrollNumber;

	@Column(name = "RELIGION")
	@DisplayedLoggedProperty(displayName = "Religion")
	private String religion;

	@Column(name = "PLACE_OF_BIRTH")
	@DisplayedLoggedProperty(displayName = "Place Of Birth")
	private String placeOfBirth;
	
	@Column(name = "is_Person_Nhs_Patient")
	@DisplayedLoggedProperty(displayName = "Is NHS Patient")
	private String isPersonNhsPatient;
	
	@Column(name = "treatmant")
	@DisplayedLoggedProperty(displayName = "Treatment")
	private String treatmant;
	
	@Column(name = "patient_Type")
	@DisplayedLoggedProperty(displayName = "Patient Type")
	private String patientType;
	
	@Column(name = "patient_occupation")
	@DisplayedLoggedProperty(displayName = "Occupation")
	private String patientOccupation;
	
	@Column(name = "link_to_nhs")
	@DisplayedLoggedProperty(displayName = "Link To NHS")
	private String linkToNhs;
	
	@Column(name = "other_information")
	@DisplayedLoggedProperty(displayName = "Other Information")
	private String otherInformation;
	
	@Column(name = "patient_Organisation")
	@DisplayedLoggedProperty(displayName = "Patient Organisation")
	private String patientOrganisation;
	
	@Column(name = "professional_Body")
	@DisplayedLoggedProperty(displayName = "Professional Body")
	private String professionalBody;
	
	@Column(name = "registration_Number")
	@DisplayedLoggedProperty(displayName = "Registration Number")
	private String registrationNumber;
	
	@Column(name = "other_Identifier")
	@DisplayedLoggedProperty(displayName = "Other Identitification")
	private String otherIdentifier;
	
	@Column(name = "age")
	@DisplayedLoggedProperty(displayName = "Age")
	private String age;
	
	@Column(name = "NON_NHS_OCCUPATION")
	@DisplayedLoggedProperty(displayName = "Non NHS Occupation")
	private String nonNHSOccupation;
	
	@Column(name = "NON_NHS_EMPLOYER")
	@DisplayedLoggedProperty(displayName = "Non NHS Employer")
	private String nonNHSEmployer;
	
	@OneToMany(cascade ={CascadeType.ALL}, fetch = FetchType.EAGER)
	@JoinColumn(name = "PERSON_ID")
	@org.hibernate.annotations.Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<Address> addressList = new HashSet<Address>();
		
	@OneToMany(cascade ={CascadeType.ALL}, fetch = FetchType.EAGER)
	@JoinColumn(name = "PERSON_ID")
	@org.hibernate.annotations.Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<PersonContacts> contactsList = new HashSet<PersonContacts>();

	@OneToMany(cascade ={CascadeType.ALL}, fetch = FetchType.EAGER)
	@JoinColumn(name = "PERSON_ID")
	@org.hibernate.annotations.Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<PersonAlias> aliasList = new HashSet<PersonAlias>();
	
	@OneToMany(cascade ={CascadeType.ALL}, fetch = FetchType.EAGER)
	@JoinColumn(name = "PERSON_ID")
	@org.hibernate.annotations.Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<BankDetails> bankList = new HashSet<BankDetails>();
	
	/** As part of Restructure from April 2011. NHS career areas and occupation type **/  
	@Column(name = "NHS_CAREER_AREA")
	@DisplayedLoggedProperty(displayName = "NHS Career Area", isList = true)
	private String nhsCareerArea;
	
	@Column(name = "NHS_OCCUPATION_TYPE")
	@DisplayedLoggedProperty(displayName = "NHS Occupation Type", isList = true)
	private String nhsOccupationType;
	
	@Column(name = "OTHER_NHS_OCCUPATION_TYPE")
	@DisplayedLoggedProperty(displayName = "Other NHS Occupation Type")
	private String otherNHSOccupationType; 
	 
	@Column(name = "PATIENT_OCCUP_TYPE")
	@DisplayedLoggedProperty(displayName = "Patient Occupation Type", isList = true)
	private String patientOccupationType;
	
	@Column(name = "NEW_PATIENT_OCCUPATION")
	@DisplayedLoggedProperty(displayName = "Patient Occupation Type", isList = true)
	private String patientOccupationByType;
	
	@Column(name = "OTHER_PATIENT_OCCUPATION")
	@DisplayedLoggedProperty(displayName = "Other Patient Occupation Type")
	private String otherPatientOccupation;
	
	@Column(name = "OTHER_OCCUP_TYPE")
	@DisplayedLoggedProperty(displayName = "Other Occupation Type", isList = true)
	private String otherOccupationType;
	
	@Column(name = "OTHER_NHS_CAREER_AREA")
	@DisplayedLoggedProperty(displayName = "Other NHS Carrer Area")
	private String otherNHSCareerArea;
	
	@Column(name = "OTHER_NHS_PATIENT_TYPE")
	@DisplayedLoggedProperty(displayName = "Other NHS Patient Type")
	private String otherNHSPatientType;
	
	@Column(name = "PERSON_INTEL_REFERENCE")
	@DisplayedLoggedProperty(displayName = "Person Intel Reference")
	private String personIntelReference;
		
	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getNINumber() {
		return nINumber;
	}

	public void setNINumber(String number) {
		nINumber = number;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOtherName() {
		return otherName;
	}

	public void setOtherName(String otherName) {
		this.otherName = otherName;
	}

	public PersonDescription getPersonDescription() {
		return personDescription;
	}

	public void setPersonDescription(PersonDescription personDescription) {
		this.personDescription = personDescription;
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}

	public String getPersonType() {
		return personType;
	}

	public void setPersonType(String personType) {
		this.personType = personType;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDrivingLicenseNumber() {
		return drivingLicenseNumber;
	}

	public void setDrivingLicenseNumber(String drivingLicenseNumber) {
		this.drivingLicenseNumber = drivingLicenseNumber;
	}

	public String getEthnicCode() {
		return ethnicCode;
	}

	public void setEthnicCode(String ethnicCode) {
		this.ethnicCode = ethnicCode;
	}

	public String getIsPersonNhs() {
		return isPersonNhs;
	}

	public void setIsPersonNhs(String isPersonNhs) {
		this.isPersonNhs = isPersonNhs;
	}

	public String getKnownAs() {
		return knownAs;
	}

	public void setKnownAs(String knownAs) {
		this.knownAs = knownAs;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getNhsNumber() {
		return nhsNumber;
	}

	public void setNhsNumber(String nhsNumber) {
		this.nhsNumber = nhsNumber;
	}

	public String getOtherOccupation() {
		return otherOccupation;
	}

	public void setOtherOccupation(String otherOccupation) {
		this.otherOccupation = otherOccupation;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getPayrollNumber() {
		return payrollNumber;
	}

	public void setPayrollNumber(String payrollNumber) {
		this.payrollNumber = payrollNumber;
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getFullName() {
		StringBuffer sb = new StringBuffer("");
		if (this.title != null)
			sb.append(this.title).append(" ");
		if (this.firstName != null)
			sb.append(this.firstName).append(" ");
		if (this.firstName != null)
			sb.append(this.lastName);
		return sb.toString();
	}

	public Set<Address> getAddressList() {
		return addressList;
	}

	public void setAddressList(Set<Address> addressList) {
		this.addressList = addressList;
	}

	public Set<PersonContacts> getContactsList() {
		return contactsList;
	}

	public void setContactsList(Set<PersonContacts> contactsList) {
		this.contactsList = contactsList;
	}
	
	/**
	 * Helper method to get only one address from addressList.
	 * 
	 * @return Address
	 */
	public Address getAddress() {

		Address adrs = new Address();
		
		if (addressList != null && addressList.size() == 1) {
			
			Address[] adrsArray = addressList.toArray(new Address[addressList.size()]);
			
			return adrsArray[0];	
		}
		return adrs;
	}
	
	/**
	 * Helper method to get only one address from addressList.
	 * 
	 * @return Address
	 */
	public PersonContacts getContacts() {

		PersonContacts contacts = new PersonContacts();
		
		if (contactsList != null && contactsList.size() == 1) {
			PersonContacts[] cntsArray = contactsList.toArray(new PersonContacts[contactsList.size()]);
			
			return cntsArray[0];	
		}
		return contacts;
	}

	public Set<PersonAlias> getAliasList() {
		return aliasList;
	}

	public void setAliasList(Set<PersonAlias> aliasList) {
		this.aliasList = aliasList;
	}

	public String getOtherTitle() {
		return otherTitle;
	}

	public void setOtherTitle(String otherTitle) {
		this.otherTitle = otherTitle;
	}

	public String getIsPersonNhsPatient() {
		return isPersonNhsPatient;
	}

	public void setIsPersonNhsPatient(String isPersonNhsPatient) {
		this.isPersonNhsPatient = isPersonNhsPatient;
	}

	public String getLinkToNhs() {
		return linkToNhs;
	}

	public void setLinkToNhs(String linkToNhs) {
		this.linkToNhs = linkToNhs;
	}

	public String getOtherInformation() {
		return otherInformation;
	}

	public void setOtherInformation(String otherInformation) {
		this.otherInformation = otherInformation;
	}

	public String getPatientType() {
		return patientType;
	}

	public void setPatientType(String patientType) {
		this.patientType = patientType;
	}

	public String getTreatmant() {
		return treatmant;
	}

	public void setTreatmant(String treatmant) {
		this.treatmant = treatmant;
	}

	public String getPatientOccupation() {
		return patientOccupation;
	}

	public void setPatientOccupation(String patientOccupation) {
		this.patientOccupation = patientOccupation;
	}

	public String getPatientOrganisation() {
		return patientOrganisation;
	}

	public void setPatientOrganisation(String patientOrganisation) {
		this.patientOrganisation = patientOrganisation;
	}

	public String getOtherIdentifier() {
		return otherIdentifier;
	}

	public void setOtherIdentifier(String otherIdentifier) {
		this.otherIdentifier = otherIdentifier;
	}

	public String getProfessionalBody() {
		return professionalBody;
	}

	public void setProfessionalBody(String professionalBody) {
		this.professionalBody = professionalBody;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getNonNHSOccupation() {
		return nonNHSOccupation;
	}

	public void setNonNHSOccupation(String nonNHSOccupation) {
		this.nonNHSOccupation = nonNHSOccupation;
	}

	public String getNonNHSEmployer() {
		return nonNHSEmployer;
	}

	public void setNonNHSEmployer(String nonNHSEmployer) {
		this.nonNHSEmployer = nonNHSEmployer;
	}

	public Set<BankDetails> getBankList() {
		return bankList;
	}

	public void setBankList(Set<BankDetails> bankList) {
		this.bankList = bankList;
	}

	public String getnINumber() {
		return nINumber;
	}

	public void setnINumber(String nINumber) {
		this.nINumber = nINumber;
	}

	public String getNhsCareerArea() {
		return nhsCareerArea;
	}

	public void setNhsCareerArea(String nhsCareerArea) {
		this.nhsCareerArea = nhsCareerArea;
	}

	public String getNhsOccupationType() {
		return nhsOccupationType;
	}

	public void setNhsOccupationType(String nhsOccupationType) {
		this.nhsOccupationType = nhsOccupationType;
	}

	public String getOtherNHSOccupationType() {
		return otherNHSOccupationType;
	}

	public void setOtherNHSOccupationType(String otherNHSOccupationType) {
		this.otherNHSOccupationType = otherNHSOccupationType;
	}

	public String getPatientOccupationType() {
		return patientOccupationType;
	}

	public void setPatientOccupationType(String patientOccupationType) {
		this.patientOccupationType = patientOccupationType;
	}

	public String getOtherOccupationType() {
		return otherOccupationType;
	}

	public void setOtherOccupationType(String otherOccupationType) {
		this.otherOccupationType = otherOccupationType;
	}

	public String getPatientOccupationByType() {
		return patientOccupationByType;
	}

	public void setPatientOccupationByType(String patientOccupationByType) {
		this.patientOccupationByType = patientOccupationByType;
	}

	public String getOtherPatientOccupation() {
		return otherPatientOccupation;
	}

	public String getOtherNHSCareerArea() {
		return otherNHSCareerArea;
	}

	public void setOtherNHSCareerArea(String otherNHSCareerArea) {
		this.otherNHSCareerArea = otherNHSCareerArea;
	}

	public String getOtherNHSPatientType() {
		return otherNHSPatientType;
	}

	public void setOtherNHSPatientType(String otherNHSPatientType) {
		this.otherNHSPatientType = otherNHSPatientType;
	}

	public void setOtherPatientOccupation(String otherPatientOccupation) {
		this.otherPatientOccupation = otherPatientOccupation;
	}

	public String getPersonIntelReference() {
		return personIntelReference;
	}

	public void setPersonIntelReference(String personIntelReference) {
		this.personIntelReference = personIntelReference;
	}
}