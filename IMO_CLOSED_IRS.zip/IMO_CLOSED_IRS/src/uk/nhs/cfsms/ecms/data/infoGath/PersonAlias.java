package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "PERSON_ALIAS_TBL")
@Audited
public class PersonAlias implements Serializable {
	
	private static final long serialVersionUID = 10917450L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "PERSON_ALIAS_ID_SQNC") })
	@Column(name = "PERSON_ALIAS_ID")
	private Long aliasId;

	@Column(name = "PERSON_ID", nullable=false, insertable=false, updatable=false)
	@DisplayedLoggedProperty(displayName = "Person Id")
	private Long personId;
	
	@Column(name = "ALIAS_FIRST_NAME")
	@DisplayedLoggedProperty(displayName = "First Name")
	private String firstName;

	@Column(name = "ALIAS_LAST_NAME")
	@DisplayedLoggedProperty(displayName = "Last Name")
	private String lastName;
	

	public Long getAliasId() {
		return aliasId;
	}

	public void setAliasId(Long aliasId) {
		this.aliasId = aliasId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}
	
	public boolean isEmpty() {
		if (null == firstName && null == lastName) {
			
			return true;
		}
		return false;
	}
}
