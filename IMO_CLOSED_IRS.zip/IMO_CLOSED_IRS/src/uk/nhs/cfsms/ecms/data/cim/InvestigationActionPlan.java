package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

@Entity
@Table(name = "INVST_ACTION_PLAN_TBL")
@Audited
public class InvestigationActionPlan implements Serializable {

	@Id
	@Column(name = "ACTION_PLAN_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "ACTION_PLAN_ID_SQNC") })
	private Long actionPlanId;

	@Column(name = "INVESTIGATION_ID", insertable=false, updatable=false)
	private Long investigationId;;

	@Column(name = "CHECKED_BY_OFM")
	@DisplayedLoggedProperty(displayName = "Checked By OFM")
	private String checkedByOFM;

	@Column(name = "REASON_FOR_NEW_PLAN")
	@DisplayedLoggedProperty(displayName = "Reason for New Plan")
	private String reasonForNewPlan;
	
	@Column(name="CHECKED_DATE")
	@DisplayedLoggedProperty(displayName = "Checked Date")
	private Date checkedDate;

	@Column(name="ACTION_PLAN")
	@Type(type="uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch =FetchType.EAGER)
	@DisplayedLoggedProperty(displayName = "Action Plan")
	private String actionPlan;
	
	@Column(name = "CREATED_TIME", updatable = false)
	@DisplayedLoggedProperty(displayName = "Create Time")
	private Timestamp createdDate;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	@DisplayedLoggedProperty(displayName = "Created By (Id)")
	private String createdStaffId;

	
	public String getActionPlan() {
		return actionPlan;
	}

	public void setActionPlan(String actionPlan) {
		this.actionPlan = CaseUtil.replaceNewline(actionPlan);
	}

	public Long getActionPlanId() {
		return actionPlanId;
	}

	public void setActionPlanId(Long actionPlanId) {
		this.actionPlanId = actionPlanId;
	}

	public String getCheckedByOFM() {
		return checkedByOFM;
	}

	public void setCheckedByOFM(String checkedByOFM) {
		this.checkedByOFM = checkedByOFM;
	}

	public Date getCheckedDate() {
		return checkedDate;
	}

	public void setCheckedDate(Date checkedDate) {
		this.checkedDate = checkedDate;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Long getInvestigationId() {
		return investigationId;
	}

	public void setInvestigationId(Long investigationId) {
		this.investigationId = investigationId;
	}

	public String getReasonForNewPlan() {
		return reasonForNewPlan;
	}

	public void setReasonForNewPlan(String reasonForNewPlan) {
		this.reasonForNewPlan = reasonForNewPlan;
	}
	
}
