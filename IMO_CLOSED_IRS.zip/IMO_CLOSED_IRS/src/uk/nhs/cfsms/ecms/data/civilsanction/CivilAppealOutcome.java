package uk.nhs.cfsms.ecms.data.civilsanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "CIVIL_APPEAL_OUTCOME_TBL")
@NamedQuery(name = "getOutcomesForCase", query = "from  CivilAppealOutcome where forAppeal.sanction.caseId = :caseID ")
@Audited
public class CivilAppealOutcome implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -402087468880095902L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CVL_APPEAL_OUT_ID_SQNC") })
	@Column(name = "OUTCOME_ID")
	@DisplayedLoggedProperty(displayName="Appeal Outcome ID")
	private Long outcomeId;

	@Column(name = "CREATED_STAFF_ID" , insertable=true, updatable=false)
	@DisplayedLoggedProperty(displayName="Created By Staff ID")
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME" , insertable=true, updatable=false)
	@DisplayedLoggedProperty(displayName="Created Time")
	private Date createdTime;
	
	@Column(name = "DATE_OUTCOME")
	@DisplayedLoggedProperty(displayName="Date Of Outcome")
	private Date dateofOutcome;
	
	@Column(name = "OUTCOME_STATUS")
	@DisplayedLoggedProperty(displayName="Outcome Status")
	private String outcomeStatus;
	
	@Column(name = "SUMMONS_ORDERS_MADE")
	@DisplayedLoggedProperty(displayName="Orders Made")
	private String ordersMade;
	
	@Column(name = "AMT_AWARDED_FOR_THIS")
	@DisplayedLoggedProperty(displayName="Amounts awarded for this")
	private String amountsAwardedForThis;
	
	@Column(name = "TOTAL_COST_CVL_ACT_STLLMT")
	@DisplayedLoggedProperty(displayName="Total cost of settlement")
	private String totalCostSettlement;
	
	@OneToOne()
	@JoinColumn(name = "APPEAL_ID")
	private CivilAppeal forAppeal;
	
	@OneToOne
	@JoinColumn(name = "APPEAL_ID", updatable=false, insertable=false)
	@NotAudited
	private CivilAppealView appealView;

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long id) {
		this.outcomeId = id;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getDateofOutcome() {
		return dateofOutcome;
	}

	public void setDateofOutcome(Date dateofOutcome) {
		this.dateofOutcome = dateofOutcome;
	}

	public String getOutcomeStatus() {
		return outcomeStatus;
	}

	public void setOutcomeStatus(String outcomeStatus) {
		this.outcomeStatus = outcomeStatus;
	}

	public String getOrdersMade() {
		return ordersMade;
	}

	public void setOrdersMade(String ordersMade) {
		this.ordersMade = ordersMade;
	}

	public String getAmountsAwardedForThis() {
		return amountsAwardedForThis;
	}

	public void setAmountsAwardedForThis(String amountsAwardedForThis) {
		this.amountsAwardedForThis = amountsAwardedForThis;
	}

	public String getTotalCostSettlement() {
		return totalCostSettlement;
	}

	public void setTotalCostSettlement(String totalCostSettlement) {
		this.totalCostSettlement = totalCostSettlement;
	}

	public CivilAppeal getForAppeal() {
		return forAppeal;
	}

	public void setForAppeal(CivilAppeal forAppeal) {
		this.forAppeal = forAppeal;
	}

	public CivilAppealView getAppealView() {
		return appealView;
	}

	public void setAppealView(CivilAppealView appealView) {
		this.appealView = appealView;
	}
	
}
