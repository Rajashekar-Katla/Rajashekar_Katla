package uk.nhs.cfsms.ecms.data.cps;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "CPS_MAIL_TBL")
@Audited
public class CpsMail {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EMAIL_ID")
	private long emailID;

	@Column(name = "CASE_ID")
	private Long caseID;

	@Column(name = "INVESTIGATION_STAGE")
	private String investigationStage;

	@Column(name = "SENDER_NAME")
	private String senderName;

	@Column(name = "SENDER_EMAIL_ID")
	private String senderEmailId;

	@Column(name = "EMAIL_TO")
	private String to;

	@Column(name = "CC")
	private String cc;

	@Column(name = "SUBJECT")
	private String subject;

	@Lob
	@Column(name = "MESSAGE")
	private String message;

	@Lob
	@Column(name = "ATTACHED_DOCS")
	private String attachedDocs;

	@Column(name = "EMAIL_DATE")
	private Timestamp emailDate;

	public long getEmailID() {
		return emailID;
	}

	public void setEmailID(long emailID) {
		this.emailID = emailID;
	}

	public Long getCaseID() {
		return caseID;
	}

	public void setCaseID(Long caseID) {
		this.caseID = caseID;
	}

	public String getInvestigationStage() {
		return investigationStage;
	}

	public void setInvestigationStage(String investigationStage) {
		this.investigationStage = investigationStage;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public String getSenderEmailId() {
		return senderEmailId;
	}

	public void setSenderEmailId(String senderEmailId) {
		this.senderEmailId = senderEmailId;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAttachedDocs() {
		return attachedDocs;
	}

	public void setAttachedDocs(String attachedDocs) {
		this.attachedDocs = attachedDocs;
	}

	public Timestamp getEmailDate() {
		return emailDate;
	}

	public void setEmailDate(Timestamp emailDate) {
		this.emailDate = emailDate;
	}

}
