package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "SOI_COST_TBL")
@Audited
public class SoiCosts implements Serializable {

	private static final long serialVersionUID = 4939871235L;

	@Id
	@Column(name = "soi_cost_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "soi_cost_ID_SQNC") })
	private Long soiCostId;
	
	@Column(name = "case_id")
	private Long caseId;
	
	@Column(name = "civil_recovery_amount")
	@DisplayedLoggedProperty(displayName = "Civil Recovery Ammount")
	private BigDecimal civilRecoveryAmount;
	
	@Column(name = "compensation_amount")
	@DisplayedLoggedProperty(displayName = "Compensation Amount")
	private BigDecimal compensationAmount;
	
	@Column(name = "voluntary_amount")
	@DisplayedLoggedProperty(displayName = "Voluntary Amount")
	private BigDecimal voluntaryAmount;
	
	@Column(name = "pcoa_confisc_amount")
	@DisplayedLoggedProperty(displayName = "POCA Confiscation Amount")
	private BigDecimal pcoaConfiscationAmount;
	
	@Column(name = "invst_costs_awarded")
	@DisplayedLoggedProperty(displayName = "POCA Confiscation Amount")
	private BigDecimal invstCostsAwarded;
	
	@Column(name = "pros_costs_awarded")
	@DisplayedLoggedProperty(displayName = "Prosecution Costs Awarded")
	private BigDecimal prosCostsAwarded;

	@Column(name = "CREATED_TIME")
	private Date createdTime;
	
	@Column(name = "CREATED_STAFF_ID")
	private String createdStaffId;
	
	
	
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public BigDecimal getCivilRecoveryAmount() {
		return civilRecoveryAmount == null
				? civilRecoveryAmount
				: civilRecoveryAmount.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCivilRecoveryAmount(BigDecimal civilRecoveryAmount) {
		this.civilRecoveryAmount = civilRecoveryAmount;
	}

	public BigDecimal getCompensationAmount() {
		return compensationAmount == null
				? compensationAmount
				: compensationAmount.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCompensationAmount(BigDecimal compensationAmount) {
		this.compensationAmount = compensationAmount;
	}

	public BigDecimal getInvstCostsAwarded() {
		return invstCostsAwarded == null
				? invstCostsAwarded
				: invstCostsAwarded.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setInvstCostsAwarded(BigDecimal invstCostsAwarded) {
		this.invstCostsAwarded = invstCostsAwarded;
	}

	public BigDecimal getPcoaConfiscationAmount() {
		return pcoaConfiscationAmount == null
				? pcoaConfiscationAmount
				: pcoaConfiscationAmount.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setPcoaConfiscationAmount(BigDecimal pcoaConfiscationAmount) {
		this.pcoaConfiscationAmount = pcoaConfiscationAmount;
	}

	public BigDecimal getProsCostsAwarded() {
		return prosCostsAwarded == null ? prosCostsAwarded : prosCostsAwarded
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setProsCostsAwarded(BigDecimal prosCostsAwarded) {
		this.prosCostsAwarded = prosCostsAwarded;
	}

	public Long getSoiCostId() {
		return soiCostId;
	}

	public void setSoiCostId(Long soiCostId) {
		this.soiCostId = soiCostId;
	}

	public BigDecimal getVoluntaryAmount() {
		return voluntaryAmount == null ? voluntaryAmount : voluntaryAmount
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setVoluntaryAmount(BigDecimal voluntaryAmount) {
		this.voluntaryAmount = voluntaryAmount;
	}

	
	
}
