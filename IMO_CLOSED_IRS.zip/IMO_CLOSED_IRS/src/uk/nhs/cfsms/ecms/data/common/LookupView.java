package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;
import java.sql.Date;
import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "LOOKUP_VIEW")
/**
 * LookupViewDetails contain lookup details of different types/categories.
 * 
 * @author schilukuri
 * 
 */
public class LookupView implements Serializable, Comparator<LookupView> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 493451235L;

	@Id
	@Column(name = "LOOKUP_ID")
	private Integer lookupId;

	@Column(name = "LOOKUP_GROUP_ID")
	private Integer groupId;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "PARENT_ID")
	private Integer parentId;

	@Column(name = "ACTIVE")
	private String active;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "LOOKUP_GROUP_NAME")
	private String groupName;

	@Transient
	private boolean selected;

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public Integer getLookupId() {
		return lookupId;
	}

	public void setLookupId(Integer lookupId) {
		this.lookupId = lookupId;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	
	@Override
	public String toString() {
		return "LookupView [lookupId=" + lookupId + ", groupId=" + groupId
				+ ", description=" + description + ", parentId=" + parentId
				+ ", active=" + active + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", groupName=" + groupName
				+ ", selected=" + selected + "]";
	}

	@Override
	public int compare(LookupView o1, LookupView o2) {
		return extractInt(o1.description) - extractInt(o2.description);
	}

	int extractInt(String s) {
		String num = s.replaceAll("\\D", "");
		return num.isEmpty() ? 0 : Integer.parseInt(num);
	}

}
