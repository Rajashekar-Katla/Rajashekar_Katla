package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "PERSON_CONTACTS_TBL")
@Audited
public class PersonContacts implements Serializable {
	

	private static final long serialVersionUID = 73542485L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "PERSON_CONTACTS_ID_SQNC") })
	@Column(name = "CONTACTS_ID")
	private Long contactsId;

	@Column(name = "PERSON_ID", nullable=false, insertable=false, updatable=false)
	@DisplayedLoggedProperty(displayName = "Person Id")
	private Long personId;

	@Column(name = "TYPE")
	@DisplayedLoggedProperty(displayName = "Type")
	private String type;

	@Column(name = "CONTACT_NO")
	@DisplayedLoggedProperty(displayName = "Contact Number")
	private String contactNo;

	@Column(name = "LOCATION")
	@DisplayedLoggedProperty(displayName = "Location")
	private String location;
	
	public Long getContactsId() {
		return contactsId;
	}

	public void setContactsId(Long contactsId) {
		this.contactsId = contactsId;
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}

	/**
	 * @return Returns the contactNo.
	 */
	public String getContactNo() {
		return contactNo;
	}

	/**
	 * @param contactNo The contactNo to set.
	 */
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	/**
	 * @return Returns the location.
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location The location to set.
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}

	
	public boolean isEmpty() {
		
		if (null == type && null == contactNo && null == location) {
			
			return true;
		}
		
		return false;
	}

}