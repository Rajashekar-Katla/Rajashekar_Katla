package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

/**
 * Address contain address details for a person.
 * 
 */

@Entity
@Table(name = "ADDRESS_TBL")
@Audited
public class Address implements Serializable{

	private static final long serialVersionUID = 305004505L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "ADDRESS_ID_SQNC") })
	@Column(name = "ADDRESS_ID")
	private Long addressId;

	@Column(name = "PERSON_ID", nullable=false, insertable=false, updatable=false)
	private Long personId;

	@Column(name = "ADDRESS_TYPE")
	@DisplayedLoggedProperty(displayName ="Address Type")
	private String addressType;

	@Column(name = "ADDRESS1")
	@DisplayedLoggedProperty(displayName ="Address1")
	private String address1;

	@Column(name = "ADDRESS2")
	@DisplayedLoggedProperty(displayName ="Address2")
	private String address2;

	@Column(name = "ADDRESS3")
	@DisplayedLoggedProperty(displayName ="Address3")
	private String address3;

	@Column(name = "ADDRESS4")
	@DisplayedLoggedProperty(displayName ="Address4")
	private String address4;

	@Column(name = "POSTCODE")
	@DisplayedLoggedProperty(displayName ="Post Code")
	private String postcode;

	@Column(name = "STATUS_CODE")
	private String status;
	

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public Long getAddressId() {
		return addressId;
	}

	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}
	
	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getFullAddress() {
		StringBuffer sb = new StringBuffer("");
		if (this.address1 != null)
			sb.append(this.address1).append(", ");
		if (this.address2 != null)
			sb.append(this.address2).append(", ");
		if (this.address3 != null)
			sb.append(this.address3).append(", ");
		if (this.address4 != null)
			sb.append(this.address4);
		
		return sb.toString();
	}

	public String getFullHomeAddress() {
		return getFullAddress();
	}
	
	public String getFullWorkAddress() {
		return getFullAddress();
	}

	@Override
    public boolean equals(Object anObject) {
        if (null == anObject) {
            return false;
        } else if (this == anObject) {
            return true;
        } else if (anObject instanceof Address) {
            final Address adrs = (Address) anObject;
            Long adrsId = adrs.getAddressId();
            if (null != adrsId) {
                return adrsId.equals(addressId);
            }
        }
        return false;
    }
	
	public boolean isEmpty() {
		if (null == addressType && null == address1 && 
				null == address2 && null == address3 && 
				null == address4 && null == postcode) {
			
			return true;
		}
		return false;
	}
}
