package uk.nhs.cfsms.ecms.data.witness;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "WITNESS_NON_AVAIL_DATES_TBL")
@Audited
public class NonAvailableDate implements Serializable {
 
	private static final long serialVersionUID = -4360077909651260143L;

	@Id
	@Column(name = "NON_AVAIL_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "WITNESS_NON_AVAIL_ID_SQNC") })
	private Long nonAvailableId;

	@Column(name = "WITNESS_ID")
	private Long witnessId;

	@Column(name = "NON_AVAIL_DATE")
	@DisplayedLoggedProperty(displayName = "Non Available Date")
	private Date nonAvailableDate;

	public Date getNonAvailableDate() {
		return nonAvailableDate;
	}

	public void setNonAvailableDate(Date nonAvailableDate) {
		this.nonAvailableDate = nonAvailableDate;
	}

	public Long getNonAvailableId() {
		return nonAvailableId;
	}

	public void setNonAvailableId(Long nonAvailableId) {
		this.nonAvailableId = nonAvailableId;
	}

	public Long getWitnessId() {
		return witnessId;
	}

	public void setWitnessId(Long witnessId) {
		this.witnessId = witnessId;
	}
}
