package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.GenericGenerator; 
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "CRIMINAL_SANCTION_OUTCOME_TBL")
@Audited
@AuditTable("CRMNL_SANCTION_OUTCOME_TBL_A")
public class CriminalSanctionOutcome implements Serializable {

	private static final long serialVersionUID = 20090710L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CRIM_SANCTION_OUTCOME_ID_SQNC") })
	@Column(name = "OUTCOME_ID")
	private Long outcomeId;

	@Column(name = "CRIMINAL_SANCTION_ID")
	private Long criminalSanctionId;

	@Column(name = "OUTCOME_DATE")
	@DisplayedLoggedProperty(displayName = "Outcome Date")
	private Date outcomeDate;

	@Column(name = "APPLIED_INV_COST")
	@DisplayedLoggedProperty(displayName = "Applied Investigation Cost")
	private BigDecimal appliedInvCost;

	@Column(name = "AWARDED_INV_COST")
	@DisplayedLoggedProperty(displayName = "Awarded Investigation Cost")
	private BigDecimal awardedInvCost;

	@Column(name = "APPLIED_PROS_COST")
	@DisplayedLoggedProperty(displayName = "Applied Pros. Cost")
	private BigDecimal appliedProsCost;

	@Column(name = "AWARDED_PROS_COST")
	@DisplayedLoggedProperty(displayName = "Awarded Pros. Cost")
	private BigDecimal awardedProsCost;

	@Column(name = "APPLIED_COMPENSATION")
	@DisplayedLoggedProperty(displayName = "Applied Compensation")
	private BigDecimal appliedCompensation;

	@Column(name = "DESCRIPTION")
	@DisplayedLoggedProperty(displayName = "Description")
	private String description;

	@Column(name = "CONFISCATION_NUMBER")
	@DisplayedLoggedProperty(displayName = "Confiscation Number")
	private String confiscationNumber;

	@Column(name = "CRIMINAL_CONFISCATION_COST")
	@DisplayedLoggedProperty(displayName = "Criminal Confiscation Cost")
	private BigDecimal criminalCofiscationCost;

	@Column(name = "AWARDED_COMPENSATION")
	@DisplayedLoggedProperty(displayName = "Awarded Compensation")
	private BigDecimal awardedCompensation;

	@Column(name = "SENTENCE_IMPOSED")
	@DisplayedLoggedProperty(displayName = "Sentence Imposed")
	private String sentenceImposed;

	@Column(name = "COMPENSATION_PAYEE")
	@DisplayedLoggedProperty(displayName = "Compensation Payee")
	private String compensationPayee;

	@Column(name = "OTHER_SANCTION")
	@DisplayedLoggedProperty(displayName = "Other Sanction")
	private String otherSanction;

	@Column(name = "OUTCOME_STATUS")
	@DisplayedLoggedProperty(displayName = "Outcome Status")
	private String outcomeStatus;

	@Column(name = "CREATED_STAFF_ID", updatable=false)
	@DisplayedLoggedProperty(displayName = "Created By")
	private String createdStaffId;

	@Column(name = "CREATED_TIME", updatable=false)
	@DisplayedLoggedProperty(displayName = "Created Time")
	private Date createdTime;

	@OneToMany
	@JoinColumn(name = "OUTCOME_ID" , updatable=true, insertable=true)
	@Cascade({CascadeType.ALL, CascadeType.DELETE})
	@AuditJoinTable(name ="CRM_SANC_OUT_ORDER_SANC_A")
	private List<OutcomeOrderSanction> outcomeOrders = new ArrayList<OutcomeOrderSanction>();

	@OneToMany
	@JoinColumn(name = "OUTCOME_ID", updatable=true, insertable=true)
	@Cascade({CascadeType.ALL, CascadeType.DELETE})
	@AuditJoinTable(name ="CRM_SANC_OUT_APP_SANC_A")
	private List<OutcomeAppliedSanction> outcomeAppliedSanctions = new ArrayList<OutcomeAppliedSanction>();
 
	
	public BigDecimal getAppliedCompensation() {
		return appliedCompensation == null
				? appliedCompensation
				: appliedCompensation.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAppliedCompensation(BigDecimal appliedCompensation) {
		this.appliedCompensation = appliedCompensation;
	}

	public BigDecimal getAppliedInvCost() {
		return appliedInvCost == null ? appliedInvCost : appliedInvCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAppliedInvCost(BigDecimal appliedInvCost) {
		this.appliedInvCost = appliedInvCost;
	}

	public BigDecimal getAppliedProsCost() {
		return appliedProsCost == null ? appliedProsCost : appliedProsCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAppliedProsCost(BigDecimal appliedProsCost) {
		this.appliedProsCost = appliedProsCost;
	}

	public BigDecimal getAwardedCompensation() {
		return awardedCompensation == null
				? awardedCompensation
				: awardedCompensation.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAwardedCompensation(BigDecimal awardedCompensation) {
		this.awardedCompensation = awardedCompensation;
	}

	public BigDecimal getAwardedInvCost() {
		return awardedInvCost == null ? awardedInvCost : awardedInvCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAwardedInvCost(BigDecimal awardedInvCost) {
		this.awardedInvCost = awardedInvCost;
	}

	public BigDecimal getAwardedProsCost() {
		return awardedProsCost == null ? awardedProsCost : awardedProsCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAwardedProsCost(BigDecimal awardedProsCost) {
		this.awardedProsCost = awardedProsCost;
	}

	public String getCompensationPayee() {
		return compensationPayee;
	}

	public void setCompensationPayee(String compensationPayee) {
		this.compensationPayee = compensationPayee;
	}

	public String getConfiscationNumber() {
		return confiscationNumber;
	}

	public void setConfiscationNumber(String confiscationNumber) {
		this.confiscationNumber = confiscationNumber;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public BigDecimal getCriminalCofiscationCost() {
		return criminalCofiscationCost == null
				? criminalCofiscationCost
				: criminalCofiscationCost.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCriminalCofiscationCost(BigDecimal criminalCofiscationCost) {
		this.criminalCofiscationCost = criminalCofiscationCost;
	}

	public Long getCriminalSanctionId() {
		return criminalSanctionId;
	}

	public void setCriminalSanctionId(Long criminalSanctionId) {
		this.criminalSanctionId = criminalSanctionId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOtherSanction() {
		return otherSanction;
	}

	public void setOtherSanction(String otherSanction) {
		this.otherSanction = otherSanction;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long outcomeId) {
		this.outcomeId = outcomeId;
	}

	public String getOutcomeStatus() {
		return outcomeStatus;
	}

	public void setOutcomeStatus(String outcomeStatus) {
		this.outcomeStatus = outcomeStatus;
	}

	public String getSentenceImposed() {
		return sentenceImposed;
	}

	public void setSentenceImposed(String sentenceImposed) {
		this.sentenceImposed = sentenceImposed;
	}

	public List<OutcomeAppliedSanction> getOutcomeAppliedSanctions() {
		return outcomeAppliedSanctions;
	}

	public void setOutcomeAppliedSanctions(
			List<OutcomeAppliedSanction> outcomeAppliedSanctions) {
		this.outcomeAppliedSanctions = outcomeAppliedSanctions;
	}

	public List<OutcomeOrderSanction> getOutcomeOrders() {
		return outcomeOrders;
	}

	public void setOutcomeOrders(List<OutcomeOrderSanction> outcomeOrders) {
		this.outcomeOrders = outcomeOrders;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
