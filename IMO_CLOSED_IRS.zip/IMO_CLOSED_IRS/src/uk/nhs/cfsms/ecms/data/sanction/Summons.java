package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "SUMMONS_TBL")
@Audited
public class Summons implements Serializable {
	
	private static final long serialVersionUID = 99999L;
	
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SUMMONS_ID_SQNC") })
	@Column(name = "SUMMONS_ID")	
	private Long summonsId;
	
	@Column(name = "CRIMINAL_SANCTION_ID")	
	private Long criminalSanctionId;
	
	@Column(name = "COURT_NAME")
	@DisplayedLoggedProperty(displayName = "Court Name")
	private String courtName;
	
	@Column(name = "ISSUED_DATE")
	@DisplayedLoggedProperty(displayName = "Issue Date")
	private Date issueDate;
	
	@Column(name = "FIRST_APPEARANCE_DATE")
	@DisplayedLoggedProperty(displayName = "First Appearance Date")
	private Date firstAppearanceDate;

	@Column(name = "SUMMONS_ADDRESS1")
	@DisplayedLoggedProperty(displayName = "Address1")
	private String address1;
	
	@Column(name = "SUMMONS_ADDRESS2")
	@DisplayedLoggedProperty(displayName = "Address2")
	private String address2;
	
	@Column(name = "SUMMONS_ADDRESS3")
	@DisplayedLoggedProperty(displayName = "Address3")
	private String address3;
	
	@Column(name = "SUMMONS_ADDRESS4")
	@DisplayedLoggedProperty(displayName = "Address4")
	private String address4;
	
	@Column(name = "SUMMONS_POSTCODE")
	@DisplayedLoggedProperty(displayName = "Postcode")
	private String postCode;
	
	@Column(name = "CREATED_STAFF_ID" , insertable=true, updatable=false)
	@DisplayedLoggedProperty(displayName = "Created By(Id)")
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME" , insertable=true, updatable=false)
	@DisplayedLoggedProperty(displayName = "Created Time")
	private Date createdTime;

	@Column(name = "ARREST_SUMMONS_NO")
	@DisplayedLoggedProperty(displayName = "Arrest Summons Number")
	private String arrestSummonsNumber;
	
	
	/**
	 * @return Returns the address1.
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * @param address1 The address1 to set.
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * @return Returns the address2.
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * @param address2 The address2 to set.
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * @return Returns the address3.
	 */
	public String getAddress3() {
		return address3;
	}

	/**
	 * @param address3 The address3 to set.
	 */
	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	/**
	 * @return Returns the address4.
	 */
	public String getAddress4() {
		return address4;
	}

	/**
	 * @param address4 The address4 to set.
	 */
	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	/**
	 * @return Returns the courtName.
	 */
	public String getCourtName() {
		return courtName;
	}

	/**
	 * @param courtName The courtName to set.
	 */
	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}

	/**
	 * @return Returns the createdStaffId.
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	/**
	 * @param createdStaffId The createdStaffId to set.
	 */
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	/**
	 * @return Returns the createdTime.
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime The createdTime to set.
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return Returns the criminalSanctionId.
	 */
	public Long getCriminalSanctionId() {
		return criminalSanctionId;
	}

	/**
	 * @param criminalSanctionId The criminalSanctionId to set.
	 */
	public void setCriminalSanctionId(Long criminalSanctionId) {
		this.criminalSanctionId = criminalSanctionId;
	}

	/**
	 * @return Returns the firstAppearanceDate.
	 */
	public Date getFirstAppearanceDate() {
		return firstAppearanceDate;
	}

	/**
	 * @param firstAppearanceDate The firstAppearanceDate to set.
	 */
	public void setFirstAppearanceDate(Date firstAppearanceDate) {
		this.firstAppearanceDate = firstAppearanceDate;
	}

	/**
	 * @return Returns the issueDate.
	 */
	public Date getIssueDate() {
		return issueDate;
	}

	/**
	 * @param issueDate The issueDate to set.
	 */
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	/**
	 * @return Returns the postCode.
	 */
	public String getPostCode() {
		return postCode;
	}

	/**
	 * @param postCode The postCode to set.
	 */
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	/**
	 * @return Returns the summonsId.
	 */
	public Long getSummonsId() {
		return summonsId;
	}

	/**
	 * @param summonsId The summonsId to set.
	 */
	public void setSummonsId(Long summonsId) {
		this.summonsId = summonsId;
	}

	/**
	 * @return Returns the arrestSummonsNumber.
	 */
	public String getArrestSummonsNumber() {
		return arrestSummonsNumber;
	}

	/**
	 * @param arrestSummonsNumber The arrestSummonsNumber to set.
	 */
	public void setArrestSummonsNumber(String arrestSummonsNumber) {
		this.arrestSummonsNumber = arrestSummonsNumber;
	}
	
	
	
}

