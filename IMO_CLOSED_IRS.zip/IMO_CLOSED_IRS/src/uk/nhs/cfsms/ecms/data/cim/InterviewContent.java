package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "INTERVIEW_CONTENT_TBL")
@Audited
public class InterviewContent implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "INTERVIEW_CONTENT_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "INTERVIEW_CONTENT_ID_SQNC") })
	private Long interviewContentId;

	@Column(name = "PERSON_SPEAKING")
	@DisplayedLoggedProperty(displayName = "Person Speaking")
	private String personSpeaking;

	@Lob
	@Column(name = "TEXT")
	@DisplayedLoggedProperty(displayName = "Text")
	private byte[] text;

	@Transient
	private String textString;

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "INTERVIEW_ID", unique = false, nullable = false, insertable = false, updatable = false)
	private Interview interview;

	/**
	 * @return Returns the interview.
	 */
	public Interview getInterview() {
		return interview;
	}

	/**
	 * @param interview
	 *            The interview to set.
	 */
	public void setInterview(Interview interview) {
		this.interview = interview;
	}

	/**
	 * @return Returns the interviewContentId.
	 */
	public Long getInterviewContentId() {
		return interviewContentId;
	}

	/**
	 * @param interviewContentId
	 *            The interviewContentId to set.
	 */
	public void setInterviewContentId(Long interviewContentId) {
		this.interviewContentId = interviewContentId;
	}

	/**
	 * @return Returns the personSpeaking.
	 */
	public String getPersonSpeaking() {
		return personSpeaking;
	}

	/**
	 * @param personSpeaking
	 *            The personSpeaking to set.
	 */
	public void setPersonSpeaking(String personSpeaking) {
		this.personSpeaking = personSpeaking;
	}

	/**
	 * @return Returns the text. Also set the string representation of this byte
	 */
	public byte[] getText() {		
		return text;
	}

	/**
	 * @param text
	 *            The text to set.
	 */
	public void setText(byte[] text) {
		this.text = text;
	}

	/**
	 * @return Returns the textString.
	 */
	public String getTextString() {
		return textString;
	}

	/**
	 * @param textString
	 *            The textString to set.
	 */
	public void setTextString(String textString) {
		this.textString = textString;
	}

}
