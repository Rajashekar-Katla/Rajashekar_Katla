package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "DISCIPLINARY_SANCTION_TBL")
@Audited
public class DisciplinarySanction implements Serializable {

	private static final long serialVersionUID = 79030155L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "DISCIPLINARY_SANCTION_ID_SQNC") })
	@Column(name = "DISCIPLINARY_SANCTION_ID")
	private Long disciplinarySanctionId;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "SUBJECT_ID")
	private Long subjectId;

	@Column(name = "SUBJECT_TYPE")
	@DisplayedLoggedProperty(displayName = "Subject Type")
	private String subjectType;

	@Column(name = "CREATED_STAFF_ID", insertable = true, updatable = false)
	private String createdStaffId;

	@Column(name = "CREATED_TIME", insertable = true, updatable = false)
	private Date createdTime;

	@Column(name = "SANCTION_TYPE")
	@DisplayedLoggedProperty(displayName = "Sanction Type")
	private String sanctionType;

	@Column(name = "STATE")
	@DisplayedLoggedProperty(displayName = "State")
	private String state;

	@Column(name = "HR_CONTACT")
	@DisplayedLoggedProperty(displayName = "Human Resource Contact")
	private String humanResourceContact;

	@Column(name = "INVST_MGR_CONTACT")
	@DisplayedLoggedProperty(displayName = "Investigation Manager Contact")
	private String investigationManagerContact;

	@Column(name = "PROF_CONTACT")
	@DisplayedLoggedProperty(displayName = "Professional Contact")
	private String professionalContact;

	@Column(name = "HB_CONTACT")
	@DisplayedLoggedProperty(displayName = "Health Body Contact")
	private String healthBodyContact;

	@Column(name = "ORG_NAME")
	@DisplayedLoggedProperty(displayName = "Organisation Name")
	private String organisationName;

	@Column(name = "START_DATE")
	@DisplayedLoggedProperty(displayName = "Start Date")
	private Date startDate;

	@Column(name = "INTERNAL_ORG_NAME")
	private String internalOrganisationName;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getDisciplinarySanctionId() {
		return disciplinarySanctionId;
	}

	public void setDisciplinarySanctionId(Long disciplinarySanctionId) {
		this.disciplinarySanctionId = disciplinarySanctionId;
	}

	public String getHealthBodyContact() {
		return healthBodyContact;
	}

	public void setHealthBodyContact(String healthBodyContact) {
		this.healthBodyContact = healthBodyContact;
	}

	public String getHumanResourceContact() {
		return humanResourceContact;
	}

	public void setHumanResourceContact(String humanResourceContact) {
		this.humanResourceContact = humanResourceContact;
	}

	public String getInvestigationManagerContact() {
		return investigationManagerContact;
	}

	public void setInvestigationManagerContact(
			String investigationManagerContact) {
		this.investigationManagerContact = investigationManagerContact;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getProfessionalContact() {
		return professionalContact;
	}

	public void setProfessionalContact(String professionalContactId) {
		this.professionalContact = professionalContactId;
	}

	public String getSanctionType() {
		return sanctionType;
	}

	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @return the internalOrganisationName
	 */
	public String getInternalOrganisationName() {
		return internalOrganisationName;
	}

	/**
	 * @param internalOrganisationName the internalOrganisationName to set
	 */
	public void setInternalOrganisationName(String internalOrganisationName) {
		this.internalOrganisationName = internalOrganisationName;
	}
	
}
