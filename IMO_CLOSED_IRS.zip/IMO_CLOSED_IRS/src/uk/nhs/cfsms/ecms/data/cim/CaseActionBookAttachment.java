package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;


import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "ACTION_ATTACHMENT_TABLE")
public class CaseActionBookAttachment implements Serializable {

	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = @Parameter(name = "sequence", value = "ACTION_ATTACHMENT_ID_SEQ"))
	@Column(name = "ACTION_ATTACHMENT_ID")
	private Long actionAttachmentID;

	@Column(name = "ATTACHMENT_NUMBER")
	private Long attachmentNumber;

	@Column(name = "ACTION_ID")
	private Long actionID;

	@Column(name = "ATTACHMENT_NAME")
	private String attachmentName;

	@Column(name = "ATTACHMENT_TYPE")
	private String attachmentType;

	@Column(name = "ATTACHMENT_BLOB")
	@Lob
	private byte[] attachmentBlob;

	@Column(name = "CREATION_TIME")
	private Date creationDateTime;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "SENSITIVE")
	private String sensitive;

	@Column(name = "MARK_AS_DELETED")
	private String markAsDeleted;
	
	@Column(name = "ATTACHMENT_DESCRIPTION")
	private String attachmentDescription;

	
	public Long getActionAttachmentID() {
		return actionAttachmentID;
	}

	public void setActionAttachmentID(Long actionAttachmentID) {
		this.actionAttachmentID = actionAttachmentID;
	}

	public Long getAttachmentNumber() {
		return attachmentNumber;
	}

	public void setAttachmentNumber(Long attachmentNumber) {
		this.attachmentNumber = attachmentNumber;
	}

	public Long getActionID() {
		return actionID;
	}

	public void setActionID(Long actionID) {
		this.actionID = actionID;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public byte[] getAttachmentBlob() {
		return attachmentBlob;
	}

	public void setAttachmentBlob(byte[] attachmentBlob) {
		this.attachmentBlob = attachmentBlob;
	}

	public Date getCreationDateTime() {
		return creationDateTime;
	}

	public void setCreationDateTime(Date creationDateTime) {
		this.creationDateTime = creationDateTime;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getSensitive() {
		return sensitive;
	}

	public void setSensitive(String sensitive) {
		this.sensitive = sensitive;
	}

	public String getMarkAsDeleted() {
		return markAsDeleted;
	}

	public void setMarkAsDeleted(String markAsDeleted) {
		this.markAsDeleted = markAsDeleted;
	}

	public String getAttachmentDescription() {
		return attachmentDescription;
	}

	public void setAttachmentDescription(String attachmentDescription) {
		this.attachmentDescription = attachmentDescription;
	}
}
