package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "USER_INFO_FILE_TBL")
public class FileObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4934512352L;

	@Id
	@Column(name = "FILE_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "USER_FILE_ID_SQNC") })
	private Long fileId;

	@Column(name = "FILE_TYPE")
	private String fileType;

	@Column(name = "FILE_DESCRIPTION")
	private String fileDescrption;

	@Column(name = "FILE_NAME")
	private String fileName;

	@Column(name = "FILE_DATA")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	private byte[] fileData;

	@Column(name = "created_staff_id")
	private String createStaffId;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "last_updated_date")
	private Date lastUpdatedDate;

	@Column(name = "permissions")
	private String permissions;

	@Column(name = "uploaded_dept")
	private String uploadedDepartment;

	@Column(name = "file_meta_data")
	private String fileMetaData;
	
	@Column(name = "file_category")
	private String category;

	public String getFileMetaData() {
		return fileMetaData;
	}

	public void setFileMetaData(String fileMetaData) {
		this.fileMetaData = fileMetaData;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreateStaffId() {
		return createStaffId;
	}

	public void setCreateStaffId(String createStaffId) {
		this.createStaffId = createStaffId;
	}

	public byte[] getFileData() {
		return fileData;
	}

	public void setFileData(byte[] file) {
		this.fileData = file;
	}

	public String getFileDescrption() {
		return fileDescrption;
	}

	public void setFileDescrption(String fileDescrption) {
		this.fileDescrption = fileDescrption;
	}

	public Long getFileId() {
		return fileId;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getPermissions() {
		return permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	public String getUploadedDepartment() {
		return uploadedDepartment;
	}

	public void setUploadedDepartment(String uploadedDepartment) {
		this.uploadedDepartment = uploadedDepartment;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
}
