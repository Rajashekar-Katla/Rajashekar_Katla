package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "FC_PERSON_DESCRIPTION_TBL")
/**
 * PersonDescription contain description details
 * 
 * @author schilukuri
 * 
 */
public class FcrolPersonDescription implements Serializable {

	private static final long serialVersionUID = 156746L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { 
			@Parameter(name = "sequence", value = "PERSON_DESC_ID_SQNC") })
			
	@Column(name = "PERSON_DESCRIPTION_ID")
	private Integer personDescriptionId;

	@Column(name = "HEIGHT")
	private String height;

	@Column(name = "HAIR_COLOUR")
	private String hairColour;

	@Column(name = "HAIR_STYLE")
	private String hairStyle;
	
	@Column(name = "OTHER_HAIR")
	private String otherHair;	

	@Column(name = "FACIAL_HAIR")
	private String facialHair;

	@Column(name = "OTHER_FACIAL_HAIR")
	private String otherFacialHair;

	@Column(name = "BODY_TYPE")
	private String bodyType;

	@Column(name = "OTHER_BODY_TYPE")
	private String otherBodyType;

	@Column(name = "EYE_COLOUR")
	private String eyeColour;

	@Column(name = "OTHER_EYE_COLOUR")
	private String otherEyeColour;

	@Column(name = "HAIR_TYPE")
	private String hairType;

	@Column(name = "OTHER_HAIR_TYPE")
	private String otherHairType;

	@Column(name = "HAIR_DESCRIPTION")
	private String hairDescription;

	@Column(name = "OTHER_HAIR_DESCRIPTION")
	private String otherHairDescription;

	@Column(name = "MARKS")
	private String marks;

	@Column(name = "FEATURES")
	private String features;

	@Column(name = "ADDITIONAL_INFORMATION")
	private String additionalInformation;

	
	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}

	public String getEyeColour() {
		return eyeColour;
	}

	public void setEyeColour(String eyeColour) {
		this.eyeColour = eyeColour;
	}

	public String getFacialHair() {
		return facialHair;
	}

	public void setFacialHair(String facialHair) {
		this.facialHair = facialHair;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	public String getHairColour() {
		return hairColour;
	}

	public void setHairColour(String hairColour) {
		this.hairColour = hairColour;
	}

	public String getHairDescription() {
		return hairDescription;
	}

	public void setHairDescription(String hairDescription) {
		this.hairDescription = hairDescription;
	}

	public String getHairStyle() {
		return hairStyle;
	}

	public void setHairStyle(String hairStyle) {
		this.hairStyle = hairStyle;
	}

	public String getHairType() {
		return hairType;
	}

	public void setHairType(String hairType) {
		this.hairType = hairType;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getMarks() {
		return marks;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}

	public String getOtherBodyType() {
		return otherBodyType;
	}

	public void setOtherBodyType(String otherBodyType) {
		this.otherBodyType = otherBodyType;
	}

	public String getOtherEyeColour() {
		return otherEyeColour;
	}

	public void setOtherEyeColour(String otherEyeColour) {
		this.otherEyeColour = otherEyeColour;
	}

	public String getOtherFacialHair() {
		return otherFacialHair;
	}

	public void setOtherFacialHair(String otherFacialHair) {
		this.otherFacialHair = otherFacialHair;
	}

	public String getOtherHair() {
		return otherHair;
	}

	public void setOtherHair(String otherHair) {
		this.otherHair = otherHair;
	}

	public String getOtherHairDescription() {
		return otherHairDescription;
	}

	public void setOtherHairDescription(String otherHairDescription) {
		this.otherHairDescription = otherHairDescription;
	}

	public String getOtherHairType() {
		return otherHairType;
	}

	public void setOtherHairType(String otherHairType) {
		this.otherHairType = otherHairType;
	}

	public Integer getPersonDescriptionId() {
		return personDescriptionId;
	}

	public void setPersonDescriptionId(Integer personDescriptionId) {
		this.personDescriptionId = personDescriptionId;
	}

	
}
