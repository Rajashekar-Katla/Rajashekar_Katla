package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.cim.CaseProgress;
import uk.nhs.cfsms.ecms.data.cim.InformationProgress;
import uk.nhs.cfsms.ecms.data.cim.Vehicle;
import uk.nhs.cfsms.ecms.data.common.Organisation;

@Entity
@Table(name = "INFORMATION_TBL")
/**
 * Information has details of the fraud allegation details.
 * 
 * @author schilukuri
 * 
 */
@Audited
public class Information implements Serializable {

	private static final long serialVersionUID = 1530234L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "INFORMATION_ID_SQNC") })
	@Column(name = "INFORMATION_ID")
	private Long informationId;

	@Column(name = "INFORMATION_NUM")
	@DisplayedLoggedProperty(displayName = "Information Number")
	private String informationNum;

	@Column(name = "DESCRIPTION")
	@DisplayedLoggedProperty(displayName = "Comment")
	private String comment;

	@Column(name = "TYPE")
	@DisplayedLoggedProperty(displayName = "Type")
	private String type;

	@Column(name = "COST")
	@DisplayedLoggedProperty(displayName = "Cost")
	private BigDecimal cost;

	@Column(name = "IS_STILL_FRAUD_OCCURING")
	@DisplayedLoggedProperty(displayName = "Is Fraud Still Occuring")
	private String isStillFraudOccuring;

	@Column(name = "START_DATE")
	@DisplayedLoggedProperty(displayName = "Start Date")
	private Date startDate;

	@Column(name = "IS_START_DATE_CORRECT")
	@DisplayedLoggedProperty(displayName = "Is Start Date Correct")
	private String isStartDateCorrect;

	@Column(name = "INFORMATION_DISCARDED")
	@DisplayedLoggedProperty(displayName = "Information Discarded")
	private String informationDiscarded;

	@OneToOne(optional = false)
	@JoinColumn(name = "ORG_CODE", unique = true, nullable = false)
	private Organisation organisation;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "INFORMATION_SOURCE_ID")
	private SourceInformation sourceInformation;

	@Column(name = "CREATED_TIME", updatable = false)
	private Timestamp createdDate;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "region_override")
	@DisplayedLoggedProperty(displayName = "Region Override")
	private String regionOverride;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "INFORMATION_ID", nullable = false, updatable = false)
	@OrderBy("subjectId")
	@AuditJoinTable(name = "INFO_SUB_TBL_J_A")
	private List<SubjectInformation> subjectInformation = new ArrayList<SubjectInformation>();
	// private Set<SubjectInformation> subjectInformation = new
	// HashSet<SubjectInformation>();

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "INFORMATION_ID", nullable = false, updatable = false)
	@OrderBy("subjectNHSId")
	@AuditJoinTable(name = "INFO_NHS_SUB_TBL_J_A")
	private List<NHSSubjectInformation> nHSSubjectInformation = new ArrayList<NHSSubjectInformation>();
	// private Set<NHSSubjectInformation> nHSSubjectInformation = new
	// HashSet<NHSSubjectInformation>();

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "INFORMATION_ID", nullable = false, updatable = false)
	@OrderBy("subjectNonNhsId")
	@AuditJoinTable(name = "INFO_SUB_NON_NHS_TBLJ_A")
	private List<NonNHSSubjectInformation> nonNHSsubjectInformation = new ArrayList<NonNHSSubjectInformation>();
	// private Set<NonNHSSubjectInformation> nonNHSsubjectInformation = new
	// HashSet<NonNHSSubjectInformation>();

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "INFO_ID", nullable = false, updatable = false)
	private Set<CaseContact> caseAssociates = new HashSet<CaseContact>();

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "INFO_ID", nullable = false, updatable = false)
	private Set<Vehicle> vehicles = new HashSet<Vehicle>();
	
	@Transient
	private Set<InformationProgress> informationProgressSet = new HashSet<InformationProgress>();

	@Column(name = "TITLE")
	@DisplayedLoggedProperty(displayName = "Title")
	private String title;

	@Column(name = "INFORMATION")
	@Type(type = "uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch = FetchType.EAGER)
	@DisplayedLoggedProperty(displayName = "Information")
	private String informationDetails;

	@Column(name = "INTELLIGENCE_CONTENT")
	@DisplayedLoggedProperty(displayName = "Intelligence Content")
	private String intelligenceContent;

	@Column(name = "INTELLIGENCE_URN")
	@DisplayedLoggedProperty(displayName = "Intelligence URN")
	private String intelligenceURN;

	@Column(name = "INFORMATION_DATE")
	@DisplayedLoggedProperty(displayName = "Information Date")
	private Date informationDate;

	@Column(name = "TEAM_CODE")
	@DisplayedLoggedProperty(displayName = "Team Code")
	private String teamCode;

	@Column(name = "REJECT_COMMENT")
	@DisplayedLoggedProperty(displayName = "Rejected Comment")
	private String rejectedComment;

	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";

	@Column(name = "STATE")
	@DisplayedLoggedProperty(displayName = "State")
	private String state;

	@Column(name = "fcrol_id")
	private Long fcrolId;

	// Restructure (areaType, Area, subArea, NHSFraudTypes)...
	@Column(name = "FRAUD_AREA_TYPE")
	@DisplayedLoggedProperty(displayName = "NHS Fraud Area Type", isList = true)
	private String areatype;

	@Column(name = "FRAUD_AREA")
	@DisplayedLoggedProperty(displayName = "Fraud Area", isList = true)
	private String fraudArea;

	@Column(name = "OTHER_FRAUD_AREA")
	@DisplayedLoggedProperty(displayName = "Other Fraud Area")
	private String otherFraudArea;

	@Column(name = "FRAUD_SUB_AREA")
	@DisplayedLoggedProperty(displayName = "Fraud Sub Area", isList = true)
	private String fraudSubArea;

	@Column(name = "OTHER_FRAUD_SUB_AREA")
	@DisplayedLoggedProperty(displayName = "Other Sub Area")
	private String otherSubArea;

	@Column(name = "NHS_FRAUD_TYPE")
	@DisplayedLoggedProperty(displayName = "NHS Fraud Type", isList = true)
	private String nhsFraudType;

	@Column(name = "OTHER_NHS_FRAUD_TYPE")
	@DisplayedLoggedProperty(displayName = "Other NHS Fraud Type", isList = true)
	private String otherNHSFraudType;

	@Column(name = "CLOSED_TIME")
	private Timestamp closedDate;

	@Column(name = "CLOSED_STAFF_ID")
	private String closedStaffId;

	//Phase-4
	@Column(name = "EVALUATION")
	@DisplayedLoggedProperty(displayName = "Evaluation")
	private String evaluate;

	@Column(name = "INTEL_INFO")
	@DisplayedLoggedProperty(displayName = "Intelligence Information")
	private String intelInfo;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public BigDecimal getCost() {
		return cost == null ? cost : cost.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getInformationDiscarded() {
		return informationDiscarded;
	}

	public void setInformationDiscarded(String informationDiscarded) {
		this.informationDiscarded = informationDiscarded;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getInformationNum() {
		return informationNum;
	}

	public void setInformationNum(String informationNum) {
		this.informationNum = informationNum;
	}

	public String getIsStartDateCorrect() {
		return isStartDateCorrect;
	}

	public void setIsStartDateCorrect(String isStartDateCorrect) {
		this.isStartDateCorrect = isStartDateCorrect;
	}

	public String getIsStillFraudOccuring() {
		return isStillFraudOccuring;
	}

	public void setIsStillFraudOccuring(String isStillFraudOccuring) {
		this.isStillFraudOccuring = isStillFraudOccuring;
	}

	public SourceInformation getSourceInformation() {
		return sourceInformation;
	}

	public void setSourceInformation(SourceInformation sourceInformation) {
		this.sourceInformation = sourceInformation;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<SubjectInformation> getSubjectInformation() {
		return subjectInformation;
	}

	public void setSubjectInformation(
			List<SubjectInformation> subjectInformation) {
		this.subjectInformation = subjectInformation;
	}

	public List<NHSSubjectInformation> getNHSSubjectInformation() {
		return nHSSubjectInformation;
	}

	public void setNHSSubjectInformation(
			List<NHSSubjectInformation> subjectInformation) {
		nHSSubjectInformation = subjectInformation;
	}

	public List<NonNHSSubjectInformation> getNonNHSsubjectInformation() {
		return nonNHSsubjectInformation;
	}

	public void setNonNHSsubjectInformation(
			List<NonNHSSubjectInformation> nonNHSsubjectInformation) {
		this.nonNHSsubjectInformation = nonNHSsubjectInformation;
	}

	public Organisation getOrganisation() {
		return organisation;
	}

	public void setOrganisation(Organisation organisation) {
		this.organisation = organisation;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Date getInformationDate() {
		return informationDate;
	}

	public void setInformationDate(Date informationDate) {
		this.informationDate = informationDate;
	}

	public String getInformationDetails() {
		return informationDetails;
	}

	public void setInformationDetails(String informationDetails) {
		this.informationDetails = informationDetails;
	}

	public String getIntelligenceContent() {
		return intelligenceContent;
	}

	public void setIntelligenceContent(String intelligenceContent) {
		this.intelligenceContent = intelligenceContent;
	}

	public String getIntelligenceURN() {
		return intelligenceURN;
	}

	public void setIntelligenceURN(String intelligenceURN) {
		this.intelligenceURN = intelligenceURN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public Set<CaseContact> getCaseAssociates() {
		return caseAssociates;
	}

	public void setCaseAssociates(Set<CaseContact> caseAssociates) {
		this.caseAssociates = caseAssociates;
	}

	public Set<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(Set<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public Set<InformationProgress> getInformationProgressSet() {
		return informationProgressSet;
	}

	public void setInformationProgressSet(
			Set<InformationProgress> informationProgressSet) {
		this.informationProgressSet = informationProgressSet;
	}

	public String getRejectedComment() {
		return rejectedComment;
	}

	public void setRejectedComment(String rejectedComment) {
		this.rejectedComment = rejectedComment;
	}

	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag
	 *            The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		// Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}

	public String getRegionOverride() {
		return regionOverride;
	}

	public void setRegionOverride(String regionOverride) {
		this.regionOverride = regionOverride;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getFcrolId() {
		return fcrolId;
	}

	public void setFcrolId(Long fcrolId) {
		this.fcrolId = fcrolId;
	}

	public boolean hasRegionOverride() {

		if (null != this.regionOverride && (
				this.regionOverride.indexOf("Y") != -1
				|| this.regionOverride.indexOf("y") != -1)) {
			return true;
		}
		return false;
	}

	public List<NHSSubjectInformation> getnHSSubjectInformation() {
		return nHSSubjectInformation;
	}

	public void setnHSSubjectInformation(
			List<NHSSubjectInformation> nHSSubjectInformation) {
		this.nHSSubjectInformation = nHSSubjectInformation;
	}

	public String getAreatype() {
		return areatype;
	}

	public void setAreatype(String areatype) {
		this.areatype = areatype;
	}

	public String getFraudArea() {
		return fraudArea;
	}

	public void setFraudArea(String fraudArea) {
		this.fraudArea = fraudArea;
	}

	public String getFraudSubArea() {
		return fraudSubArea;
	}

	public void setFraudSubArea(String fraudSubArea) {
		this.fraudSubArea = fraudSubArea;
	}

	public String getNhsFraudType() {
		return nhsFraudType;
	}

	public void setNhsFraudType(String nhsFraudType) {
		this.nhsFraudType = nhsFraudType;
	}

	public String getOtherSubArea() {
		return otherSubArea;
	}

	public void setOtherSubArea(String otherSubArea) {
		this.otherSubArea = otherSubArea;
	}

	public String getOtherNHSFraudType() {
		return otherNHSFraudType;
	}

	public void setOtherNHSFraudType(String otherNHSFraudType) {
		this.otherNHSFraudType = otherNHSFraudType;
	}

	public String getOtherFraudArea() {
		return otherFraudArea;
	}

	public void setOtherFraudArea(String otherFraudArea) {
		this.otherFraudArea = otherFraudArea;
	}

	public Timestamp getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(Timestamp closedDate) {
		this.closedDate = closedDate;
	}

	public String getClosedStaffId() {
		return closedStaffId;
	}

	public void setClosedStaffId(String closedStaffId) {
		this.closedStaffId = closedStaffId;
	}

	public String getEvaluate() {
		return evaluate;
	}

	public void setEvaluate(String evaluate) {
		this.evaluate = evaluate;
	}
	
	public String getIntelInfo() {
		return intelInfo;
	}

	public void setIntelInfo(String intelInfo) {
		this.intelInfo = intelInfo;
	}
 
}
