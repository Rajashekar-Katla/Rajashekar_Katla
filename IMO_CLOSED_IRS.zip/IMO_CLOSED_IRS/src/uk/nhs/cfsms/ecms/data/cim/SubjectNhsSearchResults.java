package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "SUBJECT_NHS_SEARCH_VW")
public class SubjectNhsSearchResults  implements Serializable{
	
	
	
	@Id
	@Column(name = "information_id")
	private Long informationId;
	
	@Column(name = "case_ID")
	private Long caseId;
	
	@Column(name = "case_number")
	private String caseNumber;
	
	@Column(name = "operation_name")
	private String operationName;
	
	@Column(name = "org_name")
	private String orgName;
	
	@Column(name = "org_code")
	private String orgCode;
	
	@Column(name = "created_staff_id")
	private String createdStaffId;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	
	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	
	 


}

