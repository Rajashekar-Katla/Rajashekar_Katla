/**
 * 
 */
package uk.nhs.cfsms.ecms.data.common;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author rkatla
 *
 */

@Entity
@Table(name = "LATEST_USERS_VIEW")
public class CPODLatestUsersView {
	
	@Id
	@Column(name = "PERSON_ID")
	private Long personID;
	
	@Column(name = "USER_REF")
	private String userRef;
	
	@Column(name = "PROPRIETRY_COMPLETE")
	private String proproetryComplete;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "FRAUD_COMPLETE")
	private String fraudComplete;
	
	@Column(name = "SECURITY_COMPLETE")
	private String securityComplete;
	
	@Column(name = "ORG_CODE")
	private String orgCode;
	
	@Column(name = "ORG_NAME")
	private String orgName;
	
	@Column(name = "PERSON_TYPE")
	private String personType;
	
	@Column(name = "MOBILE")
	private String mobile;
	
	@Column(name = "FAX")
	private String fax;
	
	@Column(name = "EXT")
	private String ext;
	
	@Column(name = "TELEPHONE2")
	private String telephone2;
	
	@Column(name = "TELEPHONE")
	private String telephone;
	
	@Column(name = "SURNAME")
	private String surName;
	
	@Column(name = "FORENAME")
	private String foreName;
	
	@Column(name = "KNOWN_AS")
	private String knownAs;
	
	@Column(name = "FORENAME2")
	private String foreName2;
	
	@Column(name = "DEPARTMENT_NAME")
	private String departmentName;
	
	@Column(name = "HOME_ADDR_LINE5")
	private String homeAddressLine5;
	
	@Column(name = "HOME_ADDR_LINE4")
	private String homeAddressLine4;
	
	@Column(name = "HOME_ADDR_LINE3")
	private String homeAddressLine3;
	
	@Column(name = "HOME_ADDR_LINE2")
	private String homeAddressLine2;
	
	@Column(name = "SECTION_NAME")
	private String sectionName;
		
	@Column(name = "CONTACT_ADDR_POSTCODE")
	private String contactAddressPostCode;
	
	@Column(name = "CONTACT_ADDR_LINE5")
	private String contactAddressLine5;
	
	@Column(name = "HOME_ADDR_POSTCODE")
	private String homeAddressPostCode;
	
	@Column(name = "CONTACT_ADDR_LINE1")
	private String contactAddressLine1;
	
	@Column(name = "CONTACT_ADDR_LINE2")
	private String contactAddressLine2;
	
	@Column(name = "CONTACT_ADDR_LINE3")
	private String contactAddressLine3;
	
	@Column(name = "CONTACT_ADDR_LINE4")
	private String contactAddressLine4;
	
	@Column(name = "REASON")
	private String reason;
	
	@Column(name = "TITLE")
	private String title;
	
	@Column(name = "EMAIL_NHS")
	private String emailNhs;
	
	@Column(name = "EMAIL_OTHER")
	private String emailOther;
	
	@Column(name = "JOB_TITLE")
	private String jobTitle;
	
	@Column(name = "HOME_ADDR_LINE1")
	private String homeAddressLine1;
	
	@Column(name = "PERSON_TYPE_ID")
	private Long personTypeID;
	
	@Column(name = "PERSON_ROLE_ID")
	private Long personRoleID;
	
	@Column(name = "HOME_ADDR_ID")
	private Long homeAddressID;
	
	@Column(name = "CONTACT_ADDR_ID")
	private Long contactAddressID;
	
	@Column(name = "DOB")
	private Date dateOfBirth;
	
	@Column(name = "PROPRIETRY_DATE")
	private Date proprietyDate;
	
	@Column(name = "SECURITY_ACCREDITATION_DATE")
	private Date securityAccreditationDate;
	
	@Column(name = "SECURITY_DATE")
	private Date securityDate;
	
	@Column(name = "START_DATE")
	private Date startDate;
	
	@Column(name = "END_DATE")
	private Date endDate;
	
	@Column(name = "FRAUD_ACCREDITATION_DATE")
	private Date fraudAccreditationDate;
	
	@Column(name = "FRAUD_DATE")
	private Date fraudDate;

	public String getProproetryComplete() {
		return proproetryComplete;
	}

	public void setProproetryComplete(String proproetryComplete) {
		this.proproetryComplete = proproetryComplete;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFraudComplete() {
		return fraudComplete;
	}

	public void setFraudComplete(String fraudComplete) {
		this.fraudComplete = fraudComplete;
	}

	public String getSecurityComplete() {
		return securityComplete;
	}

	public void setSecurityComplete(String securityComplete) {
		this.securityComplete = securityComplete;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getPersonType() {
		return personType;
	}

	public void setPersonType(String personType) {
		this.personType = personType;
	}

	public String getUserRef() {
		return userRef;
	}

	public void setUserRef(String userRef) {
		this.userRef = userRef;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}

	public String getTelephone2() {
		return telephone2;
	}

	public void setTelephone2(String telephone2) {
		this.telephone2 = telephone2;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getForeName() {
		return foreName;
	}

	public void setForeName(String foreName) {
		this.foreName = foreName;
	}

	public String getKnownAs() {
		return knownAs;
	}

	public void setKnownAs(String knownAs) {
		this.knownAs = knownAs;
	}

	public String getForeName2() {
		return foreName2;
	}

	public void setForeName2(String foreName2) {
		this.foreName2 = foreName2;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getHomeAddressLine5() {
		return homeAddressLine5;
	}

	public void setHomeAddressLine5(String homeAddressLine5) {
		this.homeAddressLine5 = homeAddressLine5;
	}

	public String getHomeAddressLine4() {
		return homeAddressLine4;
	}

	public void setHomeAddressLine4(String homeAddressLine4) {
		this.homeAddressLine4 = homeAddressLine4;
	}

	public String getHomeAddressLine3() {
		return homeAddressLine3;
	}

	public void setHomeAddressLine3(String homeAddressLine3) {
		this.homeAddressLine3 = homeAddressLine3;
	}

	public String getHomeAddressLine2() {
		return homeAddressLine2;
	}

	public void setHomeAddressLine2(String homeAddressLine2) {
		this.homeAddressLine2 = homeAddressLine2;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public String getContactAddressPostCode() {
		return contactAddressPostCode;
	}

	public void setContactAddressPostCode(String contactAddressPostCode) {
		this.contactAddressPostCode = contactAddressPostCode;
	}

	public String getContactAddressLine5() {
		return contactAddressLine5;
	}

	public void setContactAddressLine5(String contactAddressLine5) {
		this.contactAddressLine5 = contactAddressLine5;
	}

	public String getHomeAddressPostCode() {
		return homeAddressPostCode;
	}

	public void setHomeAddressPostCode(String homeAddressPostCode) {
		this.homeAddressPostCode = homeAddressPostCode;
	}

	public String getContactAddressLine1() {
		return contactAddressLine1;
	}

	public void setContactAddressLine1(String contactAddressLine1) {
		this.contactAddressLine1 = contactAddressLine1;
	}

	public String getContactAddressLine2() {
		return contactAddressLine2;
	}

	public void setContactAddressLine2(String contactAddressLine2) {
		this.contactAddressLine2 = contactAddressLine2;
	}

	public String getContactAddressLine3() {
		return contactAddressLine3;
	}

	public void setContactAddressLine3(String contactAddressLine3) {
		this.contactAddressLine3 = contactAddressLine3;
	}

	public String getContactAddressLine4() {
		return contactAddressLine4;
	}

	public void setContactAddressLine4(String contactAddressLine4) {
		this.contactAddressLine4 = contactAddressLine4;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmailNhs() {
		return emailNhs;
	}

	public void setEmailNhs(String emailNhs) {
		this.emailNhs = emailNhs;
	}

	public String getEmailOther() {
		return emailOther;
	}

	public void setEmailOther(String emailOther) {
		this.emailOther = emailOther;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getHomeAddressLine1() {
		return homeAddressLine1;
	}

	public void setHomeAddressLine1(String homeAddressLine1) {
		this.homeAddressLine1 = homeAddressLine1;
	}

	public Long getPersonTypeID() {
		return personTypeID;
	}

	public void setPersonTypeID(Long personTypeID) {
		this.personTypeID = personTypeID;
	}

	public Long getPersonRoleID() {
		return personRoleID;
	}

	public void setPersonRoleID(Long personRoleID) {
		this.personRoleID = personRoleID;
	}

	public Long getPersonID() {
		return personID;
	}

	public void setPersonID(Long personID) {
		this.personID = personID;
	}

	public Long getHomeAddressID() {
		return homeAddressID;
	}

	public void setHomeAddressID(Long homeAddressID) {
		this.homeAddressID = homeAddressID;
	}

	public Long getContactAddressID() {
		return contactAddressID;
	}

	public void setContactAddressID(Long contactAddressID) {
		this.contactAddressID = contactAddressID;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getProprietyDate() {
		return proprietyDate;
	}

	public void setProprietyDate(Date proprietyDate) {
		this.proprietyDate = proprietyDate;
	}

	public Date getSecurityAccreditationDate() {
		return securityAccreditationDate;
	}

	public void setSecurityAccreditationDate(Date securityAccreditationDate) {
		this.securityAccreditationDate = securityAccreditationDate;
	}

	public Date getSecurityDate() {
		return securityDate;
	}

	public void setSecurityDate(Date securityDate) {
		this.securityDate = securityDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getFraudAccreditationDate() {
		return fraudAccreditationDate;
	}

	public void setFraudAccreditationDate(Date fraudAccreditationDate) {
		this.fraudAccreditationDate = fraudAccreditationDate;
	}

	public Date getFraudDate() {
		return fraudDate;
	}

	public void setFraudDate(Date fraudDate) {
		this.fraudDate = fraudDate;
	}
	
}
