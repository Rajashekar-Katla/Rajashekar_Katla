package uk.nhs.cfsms.ecms.data.cim;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id; 
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;
import org.hibernate.validator.constraints.Length;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name="CASE_UPDATES_TBL")
@Audited
public class CaseUpdate {

	@Id
	@Column(name = "CASE_UPDATE_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", 
			parameters = { @Parameter(name = "sequence", value = "CASE_UPDATES_ID_SQNC") })
	private Long caseUpdateId;
	
	@Column(name="CASE_ID", updatable=false)
	private Long caseId;
	
	@Column(name="DESCRIPTION")
	@Length(max=1500)
	@DisplayedLoggedProperty(displayName = "Description")
	private String description;
	
	@Column(name="CREATED_DATE", updatable=false)
	private Date createdDate;
	
	@Column(name="CREATED_STAFF_ID", updatable=false)
	@DisplayedLoggedProperty(displayName = "Created By(Id)")
	private String createdStaffId;
	

	public Long getCaseUpdateId() {
		return caseUpdateId;
	}

	public void setCaseUpdateId(Long caseUpdateId) {
		this.caseUpdateId = caseUpdateId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}
	
	
}
