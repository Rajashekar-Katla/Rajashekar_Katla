package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

/**
 * NonNHSSubjectInformation has information about NON NHS subject.
 * 
 * @author schilukuri
 * 
 */
@Entity
@Table(name = "INFORMATION_SUBJ_NON_NHS_TBL")
@Audited
public class NonNHSSubjectInformation implements Serializable {

	private static final long serialVersionUID = 43277821L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SUB_NONNHS_INFO_ID_SQNC") })
	@Column(name = "SUBJECT_NON_NHS_ID")
	private Long subjectNonNhsId;

	@Column(name = "INFORMATION_ID", insertable=false, updatable=false)
	private Long information;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "SUBJECT_TYPE")
	@DisplayedLoggedProperty(displayName = "Subject Type")
	private String subjectType;

	@Column(name = "COMPANY_NAME")
	@DisplayedLoggedProperty(displayName = "Company Name")
	private String companyName;

	@Column(name = "NATURE_OF_BUSINESS")
	@DisplayedLoggedProperty(displayName = "Nature Of Business")
	private String natureOfBusiness;

	@Column(name = "SIS_CODE")
	@DisplayedLoggedProperty(displayName = "SIS Code")
	private String sisCode;

	@Column(name = "REG_NUMBER")
	@DisplayedLoggedProperty(displayName = "Registration Nmber")
	private String regNumber;

	@Column(name = "INCORP_NUMBER")
	@DisplayedLoggedProperty(displayName = "Incorporation Number")
	private String incorpNumber;

	@Column(name = "VAT_NUMBER")
	@DisplayedLoggedProperty(displayName = "Vat Number")
	private String vatNumber;
	
	@Column(name = "NON_NHS_INTEL_REFERENCE")
	@DisplayedLoggedProperty(displayName = "Non NHS Intel Reference")
	private String nonNHSIntelReference;

	@Column(name = "TRADING_ADDRESS1")
	@DisplayedLoggedProperty(displayName = "Trading Address1")
	private String tradingAddress1;

	@Column(name = "TRADING_ADDRESS2")
	@DisplayedLoggedProperty(displayName = "Trading Address2")
	private String tradingAddress2;

	@Column(name = "TRADING_ADDRESS3")
	@DisplayedLoggedProperty(displayName = "Trading Address3")
	private String tradingAddress3;

	@Column(name = "TRADING_ADDRESS4")
	@DisplayedLoggedProperty(displayName = "Trading Address4")
	private String tradingAddress4;

	@Column(name = "TRADING_POSTCODE")
	@DisplayedLoggedProperty(displayName = "Trading Post Code")
	private String tradingPostcode;

	@Column(name = "REG_ADDRESS1")
	@DisplayedLoggedProperty(displayName = "Reg Address1")
	private String regAddress1;

	@Column(name = "REG_ADDRESS2")
	@DisplayedLoggedProperty(displayName = "Reg Address2")
	private String regAddress2;

	@Column(name = "REG_ADDRESS3")
	@DisplayedLoggedProperty(displayName = "Reg Address3")
	private String regAddress3;

	@Column(name = "REG_ADDRESS4")
	@DisplayedLoggedProperty(displayName = "Reg Address4")
	private String regAddress4;

	@Column(name = "REG_POSTCODE")
	@DisplayedLoggedProperty(displayName = "Reg PostCode")
	private String regPostcode;
	
	@Column(name = "TRADING_ADDRESS21")
	@DisplayedLoggedProperty(displayName = "Trading Address21")
	private String tradingAddress21;

	@Column(name = "TRADING_ADDRESS22")
	@DisplayedLoggedProperty(displayName = "Trading Address22")
	private String tradingAddress22;

	@Column(name = "TRADING_ADDRESS23")
	@DisplayedLoggedProperty(displayName = "Trading Address23")
	private String tradingAddress23;

	@Column(name = "TRADING_ADDRESS24")
	@DisplayedLoggedProperty(displayName = "Trading Address24")
	private String tradingAddress24;

	@Column(name = "TRADING_POSTCODE2")
	@DisplayedLoggedProperty(displayName = "Trading Post Code2")
	private String tradingPostcode2;

	@Column(name = "REG_ADDRESS21")
	@DisplayedLoggedProperty(displayName = "Reg Address21")
	private String regAddress21;

	@Column(name = "REG_ADDRESS22")
	@DisplayedLoggedProperty(displayName = "Reg Address22")
	private String regAddress22;

	@Column(name = "REG_ADDRESS23")
	@DisplayedLoggedProperty(displayName = "Reg Address23")
	private String regAddress23;

	@Column(name = "REG_ADDRESS24")
	@DisplayedLoggedProperty(displayName = "Reg Address24")
	private String regAddress24;

	@Column(name = "REG_POSTCODE2")
	@DisplayedLoggedProperty(displayName = "Reg Postcode2")
	private String regPostcode2;

	@Column(name = "previous_name2")
	@DisplayedLoggedProperty(displayName = "Previous Name2")
	private String previousName2;

	@Column(name = "previous_Name3")
	@DisplayedLoggedProperty(displayName = "Previous Name3")
	private String previousName3;

	

	@Column(name = "OTHER_IDENTIFICATION")
	@DisplayedLoggedProperty(displayName = "Other Identification")
	private String otherIdentification;

	@Column(name = "COMPANY_STATUS")
	@DisplayedLoggedProperty(displayName = "Company Status")
	private String companyStatus;

	@Column(name = "COMPANY_TYPE")
	@DisplayedLoggedProperty(displayName = "Company Type")
	private String companyType;

	@Column(name = "ADDITIONAL_INFORMATION")
	@DisplayedLoggedProperty(displayName = "Additional Information")
	private String additionalInformation;
	
	@Column(name = "DATE_OF_CHANGE")
	@DisplayedLoggedProperty(displayName = "Date Of Change")
	private Date dateOfChange;
	
	@Column(name = "PREVIOUS_NAME")
	@DisplayedLoggedProperty(displayName = "Previous Name")
	private String previousName;
	
	@Column(name = "INCORPARATION_DATE")
	@DisplayedLoggedProperty(displayName = "Incorporation Date")
	private Date incorprationDate;
	
	@Column(name = "TELEPHONE")
	@DisplayedLoggedProperty(displayName = "Comapny Tel.")
	private String companyTel;
	
	@Column(name = "FAX")
	@DisplayedLoggedProperty(displayName = "FAX Number")
	private String faxNumber;
	
	@Column(name = "WEB_ADDRESS")
	@DisplayedLoggedProperty(displayName = "Web Address")
	private String webAddress;
	
	@Column(name = "OTHER_COMPANY_TYPE")
	@DisplayedLoggedProperty(displayName = "Other Company Type")
	private String otherCompanyType;
	
	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyStatus() {
		return companyStatus;
	}

	public void setCompanyStatus(String companyStatus) {
		this.companyStatus = companyStatus;
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public String getIncorpNumber() {
		return incorpNumber;
	}

	public void setIncorpNumber(String incorpNumber) {
		this.incorpNumber = incorpNumber;
	}

	public Long getInformation() {
		return information;
	}

	public void setInformation(Long information) {
		this.information = information;
	}

	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}

	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}

	public String getOtherIdentification() {
		return otherIdentification;
	}

	public void setOtherIdentification(String otherIdentification) {
		this.otherIdentification = otherIdentification;
	}

	public String getRegAddress1() {
		return regAddress1;
	}

	public void setRegAddress1(String regAddress1) {
		this.regAddress1 = regAddress1;
	}

	public String getRegAddress2() {
		return regAddress2;
	}

	public void setRegAddress2(String regAddress2) {
		this.regAddress2 = regAddress2;
	}

	public String getRegAddress3() {
		return regAddress3;
	}

	public void setRegAddress3(String regAddress3) {
		this.regAddress3 = regAddress3;
	}

	public String getRegAddress4() {
		return regAddress4;
	}

	public void setRegAddress4(String regAddress4) {
		this.regAddress4 = regAddress4;
	}

	public String getRegNumber() {
		return regNumber;
	}

	public void setRegNumber(String regNumber) {
		this.regNumber = regNumber;
	}

	public String getRegPostcode() {
		return regPostcode;
	}

	public void setRegPostcode(String regPostcode) {
		this.regPostcode = regPostcode;
	}

	public String getSisCode() {
		return sisCode;
	}

	public void setSisCode(String sisCode) {
		this.sisCode = sisCode;
	}

	public Long getSubjectNonNhsId() {
		return subjectNonNhsId;
	}

	public void setSubjectNonNhsId(Long subjectNonNhsId) {
		this.subjectNonNhsId = subjectNonNhsId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	public String getTradingAddress1() {
		return tradingAddress1;
	}

	public void setTradingAddress1(String tradingAddress1) {
		this.tradingAddress1 = tradingAddress1;
	}

	public String getTradingAddress2() {
		return tradingAddress2;
	}

	public void setTradingAddress2(String tradingAddress2) {
		this.tradingAddress2 = tradingAddress2;
	}

	public String getTradingAddress3() {
		return tradingAddress3;
	}

	public void setTradingAddress3(String tradingAddress3) {
		this.tradingAddress3 = tradingAddress3;
	}

	public String getTradingAddress4() {
		return tradingAddress4;
	}

	public void setTradingAddress4(String tradingAddress4) {
		this.tradingAddress4 = tradingAddress4;
	}

	public String getTradingPostcode() {
		return tradingPostcode;
	}

	public void setTradingPostcode(String tradingPostcode) {
		this.tradingPostcode = tradingPostcode;
	}

	public String getVatNumber() {
		return vatNumber;
	}

	public void setVatNumber(String vatNumber) {
		this.vatNumber = vatNumber;
	}
	
	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		//Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}

	public String getRegAddress21() {
		return regAddress21;
	}

	public void setRegAddress21(String regAddress21) {
		this.regAddress21 = regAddress21;
	}

	public String getRegAddress22() {
		return regAddress22;
	}

	public void setRegAddress22(String regAddress22) {
		this.regAddress22 = regAddress22;
	}

	public String getRegAddress23() {
		return regAddress23;
	}

	public void setRegAddress23(String regAddress23) {
		this.regAddress23 = regAddress23;
	}

	public String getRegAddress24() {
		return regAddress24;
	}

	public void setRegAddress24(String regAddress24) {
		this.regAddress24 = regAddress24;
	}

	

	

	

	

	public String getRegPostcode2() {
		return regPostcode2;
	}

	public void setRegPostcode2(String regPostcode2) {
		this.regPostcode2 = regPostcode2;
	}

	

	public String getTradingAddress21() {
		return tradingAddress21;
	}

	public void setTradingAddress21(String tradingAddress21) {
		this.tradingAddress21 = tradingAddress21;
	}

	public String getTradingAddress22() {
		return tradingAddress22;
	}

	public void setTradingAddress22(String tradingAddress22) {
		this.tradingAddress22 = tradingAddress22;
	}

	public String getTradingAddress23() {
		return tradingAddress23;
	}

	public void setTradingAddress23(String tradingAddress23) {
		this.tradingAddress23 = tradingAddress23;
	}

	public String getTradingAddress24() {
		return tradingAddress24;
	}

	public void setTradingAddress24(String tradingAddress24) {
		this.tradingAddress24 = tradingAddress24;
	}

	

	

	

	

	public String getTradingPostcode2() {
		return tradingPostcode2;
	}

	public void setTradingPostcode2(String tradingPostcode2) {
		this.tradingPostcode2 = tradingPostcode2;
	}

	
	public String getCompanyTel() {
		return companyTel;
	}

	public void setCompanyTel(String companyTel) {
		this.companyTel = companyTel;
	}

	public Date getDateOfChange() {
		return dateOfChange;
	}

	public void setDateOfChange(Date dateOfChange) {
		this.dateOfChange = dateOfChange;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public Date getIncorprationDate() {
		return incorprationDate;
	}

	public void setIncorprationDate(Date incorprationDate) {
		this.incorprationDate = incorprationDate;
	}

	public String getPreviousName() {
		return previousName;
	}

	public void setPreviousName(String previousName) {
		this.previousName = previousName;
	}

	public String getWebAddress() {
		return webAddress;
	}

	public void setWebAddress(String webAddress) {
		this.webAddress = webAddress;
	}

	public String getOtherCompanyType() {
		return otherCompanyType;
	}

	public void setOtherCompanyType(String otherCompanyType) {
		this.otherCompanyType = otherCompanyType;
	}

	public String getPreviousName3() {
		return previousName3;
	}

	public void setPreviousName3(String previous_name3) {
		this.previousName3 = previous_name3;
	}

	public String getPreviousName2() {
		return previousName2;
	}

	public void setPreviousName2(String prevoiusName2) {
		this.previousName2 = prevoiusName2;
	}

	public String getNonNHSIntelReference() {
		return nonNHSIntelReference;
	}

	public void setNonNHSIntelReference(String nonNHSIntelReference) {
		this.nonNHSIntelReference = nonNHSIntelReference;
	}

}
