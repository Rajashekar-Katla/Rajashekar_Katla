package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name="TEAM_ORGS_TBL")
public class OrganisationTeamCode implements Serializable{
	
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ORG_CODE")
	private String orgCode;
	
	@Column(name="TEAM_CODE")
	private String teamCode;
	
	@Column(name="REGION_CODE")
	private String regCode;

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getRegCode() {
		return regCode;
	}

	public void setRegCode(String regCode) {
		this.regCode = regCode;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}
	
	
	

}
