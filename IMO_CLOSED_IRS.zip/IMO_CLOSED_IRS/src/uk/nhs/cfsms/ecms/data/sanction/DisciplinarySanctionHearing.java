package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

/**
 *	Disciplinary Sanction Hearing Details.
 *
 */
@Entity
@Table(name = "DISCIPLINARY_HEARING_TBL")
@Audited
public class DisciplinarySanctionHearing implements Serializable {
			
	private static final long serialVersionUID = 5003092L;
	
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "DISCIPLINARY_HEARING_ID_SQNC") })
	@Column(name = "HEARING_ID")
	private Long hearingId;
	
	@Column(name = "DISCIPLINARY_SANCTION_ID")
	private Long disciplinarySanctionId;
		
	@Column(name = "HEARING_TYPE")
	@DisplayedLoggedProperty(displayName = "Hearing Type")
	private String hearingType;
	
	@Column(name = "HEARING_OUTCOME")
	@DisplayedLoggedProperty(displayName = "Hearing Outcome")
	private String hearingOutcome;
	
	@Column(name = "HEARING_DATE")
	@DisplayedLoggedProperty(displayName = "Hearing Date")
	private Date hearingDate;
	
	@Column(name = "HEARING_ORG_NAME")
	@DisplayedLoggedProperty(displayName = "Hearing Organisation Name")
	private String orgName;
	
	@Column(name = "HEARING_ADDRESS1")
	@DisplayedLoggedProperty(displayName = "Address 1")
	private String address1;
	
	@Column(name = "HEARING_ADDRESS2")
	@DisplayedLoggedProperty(displayName = "Address 2")
	private String address2;
	
	@Column(name = "HEARING_ADDRESS3")
	@DisplayedLoggedProperty(displayName = "Address 3")
	private String address3;
	
	@Column(name = "HEARING_ADDRESS4")
	@DisplayedLoggedProperty(displayName = "Address 4")
	private String address4;
	
	@Column(name = "HEARING_POSTCODE")
	@DisplayedLoggedProperty(displayName = "PostCode")
	private String postcode;	
	
	@Column(name = "CREATED_STAFF_ID" , insertable=true, updatable=false)	
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME" , insertable=true, updatable=false)	
	private Date createdTime;

	
	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getDisciplinarySanctionId() {
		return disciplinarySanctionId;
	}

	public void setDisciplinarySanctionId(Long disciplinarySanctionId) {
		this.disciplinarySanctionId = disciplinarySanctionId;
	}

	public Date getHearingDate() {
		return hearingDate;
	}

	public void setHearingDate(Date hearingDate) {
		this.hearingDate = hearingDate;
	}

	public Long getHearingId() {
		return hearingId;
	}

	public void setHearingId(Long hearingId) {
		this.hearingId = hearingId;
	}

	public String getHearingOutcome() {
		return hearingOutcome;
	}

	public void setHearingOutcome(String hearingOutcome) {
		this.hearingOutcome = hearingOutcome;
	}

	public String getHearingType() {
		return hearingType;
	}

	public void setHearingType(String hearingType) {
		this.hearingType = hearingType;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}		
}
