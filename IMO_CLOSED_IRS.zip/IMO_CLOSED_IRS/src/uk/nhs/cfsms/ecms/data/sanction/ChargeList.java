package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "CHARGE_LIST_TBL")
@Audited
public class ChargeList implements Serializable {

private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CHARGE_LIST_ID_SQNC") })
	@Column(name = "CHARGE_LIST_ID")
	private Long chargeListId;

	@Column(name = "CRIMINAL_SANCTION_ID")	
	private Long criminalSanctionId;
	
	@Column(name = "OFFENCE_DETAILS")
	@Type(type="uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch =FetchType.EAGER)
	@DisplayedLoggedProperty(displayName = "Offence Details")
	private String offenceDetails;
	
	@Column(name = "COURT_PLEA")
	@DisplayedLoggedProperty(displayName = "Court Plea")
	private String courtPlea;
	
	@Column(name = "RESPONSE_CHARGE")
	@DisplayedLoggedProperty(displayName = "Response Charge")
	private String responseCharge;
	
	@Column(name = "CREATED_STAFF_ID" , insertable=true, updatable=false)
	@DisplayedLoggedProperty(displayName = "Created By Staff(Id)")
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME" , insertable=true, updatable=false)	
	private Date createdTime;
	
	
	@Column(name = "LEGISLATION")
	@DisplayedLoggedProperty(displayName = "Legislation")
	private String legislation;

	/**
	 * @return Returns the chargeListId.
	 */
	public Long getChargeListId() {
		return chargeListId;
	}

	/**
	 * @param chargeListId The chargeListId to set.
	 */
	public void setChargeListId(Long chargeListId) {
		this.chargeListId = chargeListId;
	}

	/**
	 * @return Returns the courtPlea.
	 */
	public String getCourtPlea() {
		return courtPlea;
	}

	/**
	 * @param courtPlea The courtPlea to set.
	 */
	public void setCourtPlea(String courtPlea) {
		this.courtPlea = courtPlea;
	}

	/**
	 * @return Returns the createdStaffId.
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	/**
	 * @param createdStaffId The createdStaffId to set.
	 */
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	/**
	 * @return Returns the createdTime.
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime The createdTime to set.
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return Returns the criminalSanctionId.
	 */
	public Long getCriminalSanctionId() {
		return criminalSanctionId;
	}

	/**
	 * @param criminalSanctionId The criminalSanctionId to set.
	 */
	public void setCriminalSanctionId(Long criminalSanctionId) {
		this.criminalSanctionId = criminalSanctionId;
	}

	/**
	 * @return Returns the offenceDetails.
	 */
	public String getOffenceDetails() {
		return offenceDetails;
	}

	/**
	 * @param offenceDetails The offenceDetails to set.
	 */
	public void setOffenceDetails(String offenceDetails) {
		this.offenceDetails = offenceDetails;
	}

	/**
	 * @return Returns the responseCharge.
	 */
	public String getResponseCharge() {
		return responseCharge;
	}

	/**
	 * @param responseCharge The responseCharge to set.
	 */
	public void setResponseCharge(String responseCharge) {
		this.responseCharge = responseCharge;
	}

	public String getLegislation() {
		return legislation;
	}

	public void setLegislation(String legislation) {
		this.legislation = legislation;
	}
	
	
	
}
