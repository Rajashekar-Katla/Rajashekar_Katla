package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name="VEHICLE_TBL")
@Audited
public class VehicleStandalone implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="VEHICLE_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "VEHICLE_ID_SQNC") })	
	private Long vehicleId;

	@Column(name="MAKE")
	@DisplayedLoggedProperty(displayName = "Make")
	private String make;
	
	@Column(name="MODEL")
	@DisplayedLoggedProperty(displayName = "Model")
	private String model;
	
	@Column(name="COLOUR")
	@DisplayedLoggedProperty(displayName = "Colour")
	private String colour;
	
	@Column(name="LICENSE_PLATE")
	@DisplayedLoggedProperty(displayName = "License Plate")
	private String licensePlate;
	
	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "INFO_ID")
	private Long infoId;
	
	@Column(name = "COMMENTS")
	@DisplayedLoggedProperty(displayName = "Comments")
	private String comments;
	
	@Column(name = "REG_KEEPER_NAME")
	@DisplayedLoggedProperty(displayName = "Registered Keeper Name")
	private String registeredKeeperName;
	
	@Column(name = "REG_ADDRESS1")
	@DisplayedLoggedProperty(displayName = "Registered Address Line 1")
	private String registeredAddress1;
	
	@Column(name = "REG_ADDRESS2")
	@DisplayedLoggedProperty(displayName = "Registered Address Line 2")
	private String registeredAddress2;
	
	@Column(name = "REG_ADDRESS3")
	@DisplayedLoggedProperty(displayName = "Registered Address Line 3")
	private String registeredAddress3;
	
	@Column(name = "REG_ADDRESS4")
	@DisplayedLoggedProperty(displayName = "Registered Address Line 4")
	private String registeredAddress4;
	
	@Column(name = "POSTCODE")
	@DisplayedLoggedProperty(displayName = "Registered Postcode")
	private String postcode;
	
	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";
	
	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the colour.
	 */
	public String getColour() {
		return colour;
	}

	/**
	 * @param colour The colour to set.
	 */
	public void setColour(String colour) {
		this.colour = colour;
	}

	/**
	 * @return Returns the licensePlate.
	 */
	public String getLicensePlate() {
		return licensePlate;
	}

	/**
	 * @param licensePlate The licensePlate to set.
	 */
	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}

	/**
	 * @return Returns the make.
	 */
	public String getMake() {
		return make;
	}

	/**
	 * @param make The make to set.
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * @return Returns the model.
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model The model to set.
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return Returns the vehicleId.
	 */
	public Long getVehicleId() {
		return vehicleId;
	}

	/**
	 * @param vehicleId The vehicleId to set.
	 */
	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	/**
	 * @return Returns the infoId.
	 */
	public Long getInfoId() {
		return infoId;
	}

	/**
	 * @param infoId The infoId to set.
	 */
	public void setInfoId(Long infoId) {
		this.infoId = infoId;
	}
	

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return Returns the postcode.
	 */
	public String getPostcode() {
		return postcode;
	}

	/**
	 * @param postcode The postcode to set.
	 */
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	/**
	 * @return Returns the registeredAddress1.
	 */
	public String getRegisteredAddress1() {
		return registeredAddress1;
	}

	/**
	 * @param registeredAddress1 The registeredAddress1 to set.
	 */
	public void setRegisteredAddress1(String registeredAddress1) {
		this.registeredAddress1 = registeredAddress1;
	}

	/**
	 * @return Returns the registeredAddress2.
	 */
	public String getRegisteredAddress2() {
		return registeredAddress2;
	}

	/**
	 * @param registeredAddress2 The registeredAddress2 to set.
	 */
	public void setRegisteredAddress2(String registeredAddress2) {
		this.registeredAddress2 = registeredAddress2;
	}

	/**
	 * @return Returns the registeredAddress3.
	 */
	public String getRegisteredAddress3() {
		return registeredAddress3;
	}

	/**
	 * @param registeredAddress3 The registeredAddress3 to set.
	 */
	public void setRegisteredAddress3(String registeredAddress3) {
		this.registeredAddress3 = registeredAddress3;
	}

	/**
	 * @return Returns the registeredAddress4.
	 */
	public String getRegisteredAddress4() {
		return registeredAddress4;
	}

	/**
	 * @param registeredAddress4 The registeredAddress4 to set.
	 */
	public void setRegisteredAddress4(String registeredAddress4) {
		this.registeredAddress4 = registeredAddress4;
	}

	/**
	 * @return Returns the registeredKeeperName.
	 */
	public String getRegisteredKeeperName() {
		return registeredKeeperName;
	}

	/**
	 * @param registeredKeeperName The registeredKeeperName to set.
	 */
	public void setRegisteredKeeperName(String registeredKeeperName) {
		this.registeredKeeperName = registeredKeeperName;
	}
	
	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {		
		this.updatedFlag = updatedFlag;
	}
	
}
