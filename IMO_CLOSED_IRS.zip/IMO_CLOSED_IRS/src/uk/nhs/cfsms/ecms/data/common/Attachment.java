package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

/**
 * Class represents and ATTACHMENT_TBL entry 
 * @author Ronan Tobin
 *
 */

@Entity
@Table(name="ATTACHMENT_TBL")
@Audited
public class Attachment implements Serializable{
	
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * The unique key for the table
	 */
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "ATTACHMENT_ID_SQNC") })
	@Column(name="ATTACHMENT_ID")
	private Long id;
	
	/**
	 * case identifier
	 */
	
	@Column(name="CASE_ID")
	private Long caseId;
	
	/**
	 * file type/mime type
	 */
	@Column(name="FILE_TYPE")
	@DisplayedLoggedProperty(displayName = "File Type")
	private String fileType;
	
	/**
	 * Attachement blob
	 */
		
	@Column(name="ATTACHMENT_BLOB")	
	@Lob
	private byte[] attachment;
		
	
	/**
	 * The attachment time of the attachment record
	 */
	@Temporal( TemporalType.TIMESTAMP ) 
	@Column( name="CREATED_TIME" ,columnDefinition="Timestamp default sysdate", nullable=false )
	@DisplayedLoggedProperty(displayName = "Created Time")
	private Date createdTime;
	
	/**
	 * Created staff id
	 */
	@Column(name="CREATED_STAFF_ID")
	@DisplayedLoggedProperty(displayName = "Created By Staff(Id)")
	private String createdStaffId;
	
	
	/**
	 * Attachment description
	 */
	@Column(name="DESCRIPTION")
	@DisplayedLoggedProperty(displayName = "Description")
	private String description;
	
	
	/**
	 * file name
	 */
	@Column(name="NAME")
	@DisplayedLoggedProperty(displayName = "Name")
	private String name;
	
	
	@Column(name="INFO_ID")
	private Long infoId;
	


	

	public Long getCaseId() {
		return caseId;
	}


	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}


	public String getCreatedStaffId() {
		return createdStaffId;
	}


	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}


	public Date getCreatedTime() {
		return createdTime;
	}


	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getFileType() {
		return fileType;
	}


	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	//@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ATTACHMENT_ID_SQNC")
	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public byte[] getAttachment() {
		return attachment;
	}


	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}


	public Long getInfoId() {
		return infoId;
	}


	public void setInfoId(Long infoId) {
		this.infoId = infoId;
	}
	
	

	

}
