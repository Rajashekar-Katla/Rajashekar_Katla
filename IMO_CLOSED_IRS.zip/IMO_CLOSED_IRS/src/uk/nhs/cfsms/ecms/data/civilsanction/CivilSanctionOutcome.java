package uk.nhs.cfsms.ecms.data.civilsanction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

import uk.nhs.cfsms.ecms.utility.CaseUtil;

@Entity
@Table(name = "CIVIL_SANCTION_OUTCOME_TBL")
@NamedQuery(name = "getSanctionOutcomesForCase", query = "Select co  from  CivilSanctionOutcome co,  CivilSanction cs where " +
		"co.civilSanctionId = cs.civilSanctionId and cs.caseId = :caseID ")
@Audited
public class CivilSanctionOutcome implements Serializable {

	private static final long serialVersionUID = 9999999L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CIVIL_SANCTION_OUTCOME_ID_SQNC") })
	@Column(name = "OUTCOME_ID")
	private Long civilSanctionOutcomeId;

	@Column(name = "CIVIL_SANCTION_ID")
	private Long civilSanctionId;

	@Column(name = "OUTCOME_DATE")
	@DisplayedLoggedProperty(displayName="Outcome Date")
	private Date outcomeDate;

	@Column(name = "OUTCOME_DETAILS")
	@DisplayedLoggedProperty(displayName="Outcome Details")
	private String outcomeDetails;

	@Column(name = "AWARDED_COST")
	@DisplayedLoggedProperty(displayName="Awarded Cost") 
	private BigDecimal awardedCost;

	@Column(name = "SETTLED_AWARDED_AMT")
	@DisplayedLoggedProperty(displayName="Settled Awarded Amount") 
	private BigDecimal settledAwardedAmount;

	@Column(name = "NEGOTIATED_SETTLEMENT_AMT")
	@DisplayedLoggedProperty(displayName="Negotiated Settlement Amount")
	private BigDecimal negotiatedSettlementAmount;

	@Column(name = "INVESTIGATION_COST")
	@DisplayedLoggedProperty(displayName="Investigation Costs")
	private BigDecimal investigationCosts;

	@Column(name = "OUTCOME_STATUS")
	@DisplayedLoggedProperty(displayName="Outcome Status")
	private String outcomeStatus;

	@Column(name = "VOLUNTARY_REPAYMENT_AMT")
	@DisplayedLoggedProperty(displayName="Voluntary Repayment Amount")
	private BigDecimal voluntaryRepaymentAmount;

	@Column(name = "VOLUNTARY_REPAYMENT_INV_AMT")
	@DisplayedLoggedProperty(displayName="Voluntary Repayment Investigation Amount")
	private BigDecimal voluntaryInvestigationAmount;

	@Column(name = "NEGOTIATED_SETTLEMENT")
	@DisplayedLoggedProperty(displayName="Negotiated Settlement")
	private String negotiatedSettlement;

	@Column(name = "APPLIED_SANCTIONS")
	@DisplayedLoggedProperty(displayName="Applied Sanctions")
	private String appliedSanctions;

	@Column(name = "CREATED_DATE", updatable=false)
	@DisplayedLoggedProperty(displayName="Created Date")
	private Date createdDate;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CIVIL_SANCTION_ID", updatable=false, insertable=false)
	@NotAudited
	private CivilSanctionView sanctionView;
	/**
	 * @return Returns the appliedSanctions.
	 */
	public String getAppliedSanctions() {
		return appliedSanctions;
	}

	/**
	 * @param appliedSanctions
	 *            The appliedSanctions to set.
	 */
	public void setAppliedSanctions(String appliedSanctions) {
		this.appliedSanctions = appliedSanctions;
	}

	/**
	 * @return Returns the awardedCost.
	 */
	public BigDecimal getAwardedCost() {
		return awardedCost == null ? awardedCost : awardedCost.setScale(2,
				BigDecimal.ROUND_DOWN);
	}

	/**
	 * @param awardedCost
	 *            The awardedCost to set.
	 */
	public void setAwardedCost(BigDecimal awardedCost) {
		this.awardedCost = awardedCost;
	}

	/**
	 * @return Returns the civilSanctionOutcomeId.
	 */
	public Long getCivilSanctionOutcomeId() {
		return civilSanctionOutcomeId;
	}

	/**
	 * @param civilSanctionOutcomeId
	 *            The civilSanctionOutcomeId to set.
	 */
	public void setCivilSanctionOutcomeId(Long civilSanctionOutcomeId) {
		this.civilSanctionOutcomeId = civilSanctionOutcomeId;
	}

	/**
	 * @return Returns the civilSanctionId.
	 */
	public Long getCivilSanctionId() {
		return civilSanctionId;
	}

	/**
	 * @param civilSanctionId
	 *            The civilSanctionId to set.
	 */
	public void setCivilSanctionId(Long civilSanctionId) {
		this.civilSanctionId = civilSanctionId;
	}

	/**
	 * @return Returns the investigationCosts.
	 */
	public BigDecimal getInvestigationCosts() {
		return investigationCosts == null ? investigationCosts
				: investigationCosts.setScale(2, BigDecimal.ROUND_DOWN);
	}

	/**
	 * @param investigationCosts
	 *            The investigationCosts to set.
	 */
	public void setInvestigationCosts(BigDecimal investigationCosts) {
		this.investigationCosts = investigationCosts;
	}

	/**
	 * @return Returns the negotiatedSettlementAmount.
	 */
	public BigDecimal getNegotiatedSettlementAmount() {
		return negotiatedSettlementAmount == null ? negotiatedSettlementAmount
				: negotiatedSettlementAmount.setScale(2, BigDecimal.ROUND_DOWN);
	}

	/**
	 * @param negotiatedSettlementAmount
	 *            The negotiatedSettlementAmount to set.
	 */
	public void setNegotiatedSettlementAmount(
			BigDecimal negotiatedSettlementAmount) {
		this.negotiatedSettlementAmount = negotiatedSettlementAmount;
	}

	/**
	 * @return Returns the outcomeDate.
	 */
	public Date getOutcomeDate() {
		return outcomeDate;
	}

	/**
	 * @param outcomeDate
	 *            The outcomeDate to set.
	 */
	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	/**
	 * @return Returns the outcomeDetails.
	 */
	public String getOutcomeDetails() {
		return outcomeDetails;
	}

	/**
	 * @param outcomeDetails
	 *            The outcomeDetails to set.
	 */
	public void setOutcomeDetails(String outcomeDetails) {
		this.outcomeDetails = outcomeDetails;
	}

	/**
	 * @return Returns the outcomeStatus.
	 */
	public String getOutcomeStatus() {
		return outcomeStatus;
	}

	/**
	 * @param outcomeStatus
	 *            The outcomeStatus to set.
	 */
	public void setOutcomeStatus(String outcomeStatus) {
		this.outcomeStatus = outcomeStatus;
	}

	/**
	 * @return Returns the settledAwardedAmount.
	 */
	public BigDecimal getSettledAwardedAmount() {
		return settledAwardedAmount == null ? settledAwardedAmount
				: settledAwardedAmount.setScale(2, BigDecimal.ROUND_DOWN);
	}

	/**
	 * @param settledAwardedAmount
	 *            The settledAwardedAmount to set.
	 */
	public void setSettledAwardedAmount(BigDecimal settledAwardedAmount) {
		this.settledAwardedAmount = settledAwardedAmount;
	}

	/**
	 * @return Returns the voluntaryRepaymentAmount.
	 */
	public BigDecimal getVoluntaryRepaymentAmount() {
		return voluntaryRepaymentAmount == null ? voluntaryRepaymentAmount
				: voluntaryRepaymentAmount.setScale(2, BigDecimal.ROUND_DOWN);
	}

	/**
	 * @param voluntaryRepaymentAmount
	 *            The voluntaryRepaymentAmount to set.
	 */
	public void setVoluntaryRepaymentAmount(BigDecimal voluntaryRepaymentAmount) {
		this.voluntaryRepaymentAmount = voluntaryRepaymentAmount;
	}

	/**
	 * @return Returns the voluntaryRepaymentInvestigationAmount.
	 */
	public BigDecimal getVoluntaryInvestigationAmount() {

		return voluntaryInvestigationAmount == null ? voluntaryInvestigationAmount
				: voluntaryInvestigationAmount.setScale(2,
						BigDecimal.ROUND_DOWN);
	}

	/**
	 * @param voluntaryInvestigationAmount
	 *            The voluntaryRepaymentInvestigationAmount to set.
	 */
	public void setVoluntaryInvestigationAmount(
			BigDecimal voluntaryInvestigationAmount) {
		this.voluntaryInvestigationAmount = voluntaryInvestigationAmount;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getNegotiatedSettlement() {
		return negotiatedSettlement;
	}

	public void setNegotiatedSettlement(String negotiatedSettlement) {
		this.negotiatedSettlement = negotiatedSettlement;
	}
	
	public String getSubjectName(){
		String subjectName = "";
		String subType = sanctionView.getSubjectType();
		if(CaseUtil.SubjectType.PERSON.toString().equals(subType)) {
			subjectName =  sanctionView.getPersonSubjectName();
		} else if(CaseUtil.SubjectType.NHS.toString().equals(subType)) {
			subjectName = sanctionView.getNhsSubjectName();
		} else if(CaseUtil.SubjectType.NON_NHS.toString().equals(subType)) {
			subjectName =  sanctionView.getNonNhsSubjectName();
		} 
		return subjectName;
	}
}