package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MESSAGE_VIEW")
public class MessageView implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -37478477363454L;

	@Id
	@Column(name = "MESSAGE_ID")
	private Long messageId;
	
	@Column(name = "information_Id")
	private Long informationId;
	
	@Column(name = "from_Staff_Id")
	private String fromStaffId;
	
	@Column(name = "to_Staff_Id")
	private String toStaffId;
	
	@Column(name = "MESSAGE")
	private String message;
	
	@Column(name = "STATE")
	private String state;
	
	@Column(name = "CREATED_STAFF_ID")
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME")
	private Date createdTime;
	
	@Column(name = "READ_TIME")
	private Date readTime;
	
	@Column(name = "DELETED_TIME")
	private Date deletedTime;
	
	@Column(name = "from_Staff_name")
	private String fromStaffName;
	
	@Column(name = "to_Staff_name")
	private String toStaffName;
	
	@Column(name = "information_ref")
	private String informationRef;
	
	@Column(name = "case_ref")
	private String caseRef;
	
	@Column(name = "case_id")
	private Long caseId;
	
	@Column(name = "nits_lead_state")
	private String nitsLeadState;

	@Column(name = "nitn_lead_state")
	private String nitnLeadState;

	@Column(name = "action_details")
	private String actionDetails;
	
	@Column(name = "message_type")
	private String messageType;
	
	@Column(name = "case_number")
	private String caseNumber;
	
	@Column(name = "operation_name")
	private String operationName;

	@Column(name = "parent_id")
	private Long parentMessageId;
	
	@Column(name = "case_state")
	private String caseState;
	
	
	/**
	 * Fields introduced to track the deletion status for the various users.
	 * Deletion status changes starts.
	 * **/
	
	@Column(name = "DELETE_FROM")
	private String deleteFrom;
	
	@Column(name = "DELETE_TO")
	private String deleteTo;
	
	@Column(name = "DELETE_NITS")
	private String deleteNits;
	
	@Column(name = "DELETE_NITN")
	private String deleteNitn;
	
	@Column(name = "MARK_AS_UNREAD")
	private String markAsUnread;

	@Column(name = "ACTION_TITLE")
	private String actionTitle;
	
	/**
	 * Deletion status Changes Ends.
	 * 
	 * **/
	
	public String getFromStaffName() {
		return fromStaffName;
	}

	public void setFromStaffName(String fromStaffName) {
		this.fromStaffName = fromStaffName;
	}

	public String getInformationRef() {
		return informationRef;
	}

	public void setInformationRef(String informationRef) {
		this.informationRef = informationRef;
	}

	public String getToStaffName() {
		return toStaffName;
	}

	public void setToStaffName(String toStaffName) {
		this.toStaffName = toStaffName;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getDeletedTime() {
		return deletedTime;
	}

	public void setDeletedTime(Date deletedTime) {
		this.deletedTime = deletedTime;
	}

	public String getFromStaffId() {
		return fromStaffId;
	}

	public void setFromStaffId(String fromStaffId) {
		this.fromStaffId = fromStaffId;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public Date getReadTime() {
		return readTime;
	}

	public void setReadTime(Date readTime) {
		this.readTime = readTime;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getToStaffId() {
		return toStaffId;
	}

	public void setToStaffId(String toStaffId) {
		this.toStaffId = toStaffId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCaseRef() {
		return caseRef;
	}

	public void setCaseRef(String caseRef) {
		this.caseRef = caseRef;
	}

	public String getNitsLeadState() {
		return nitsLeadState;
	}

	public void setNitsLeadState(String nitsLeadState) {
		this.nitsLeadState = nitsLeadState;
	}

	public String getNitnLeadState() {
		return nitnLeadState;
	}

	public void setNitnLeadState(String nitnLeadState) {
		this.nitnLeadState = nitnLeadState;
	}

	public String getActionDetails() {
		return actionDetails;
	}

	public void setActionDetails(String actionDetails) {
		this.actionDetails = actionDetails;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}
	
	public Long getParentMessageId() {
		return parentMessageId;
	}

	public void setParentMessageId(Long parentMessageId) {
		this.parentMessageId = parentMessageId;
	}

	public String getCaseState() {
		return caseState;
	}

	public void setCaseState(String caseState) {
		this.caseState = caseState;
	}
	
	public String getDeleteFrom() {
		return deleteFrom;
	}

	public void setDeleteFrom(String deleteFrom) {
		this.deleteFrom = deleteFrom;
	}

	public String getDeleteTo() {
		return deleteTo;
	}

	public void setDeleteTo(String deleteTo) {
		this.deleteTo = deleteTo;
	}

	public String getDeleteNits() {
		return deleteNits;
	}

	public void setDeleteNits(String deleteNits) {
		this.deleteNits = deleteNits;
	}

	public String getDeleteNitn() {
		return deleteNitn;
	}

	public void setDeleteNitn(String deleteNitn) {
		this.deleteNitn = deleteNitn;
	}
	
	public String getMarkAsUnread() {
		return markAsUnread;
	}

	public void setMarkAsUnread(String markAsUnread) {
		this.markAsUnread = markAsUnread;
	}

	public String getActionTitle() {
		return actionTitle;
	}

	public void setActionTitle(String actionTitle) {
		this.actionTitle = actionTitle;
	}

}