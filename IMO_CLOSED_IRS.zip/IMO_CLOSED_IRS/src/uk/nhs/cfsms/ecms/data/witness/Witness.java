package uk.nhs.cfsms.ecms.data.witness;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
import uk.nhs.cfsms.ecms.data.infoGath.Person;

@Entity
@Table(name = "WITNESS_TBL")
@Audited
@DisplayedLoggedProperty(detailsMethod="getAssociatedID")
public class Witness implements Serializable {

	@Id
	@Column(name = "WITNESS_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "WITNESS_ID_SQNC") })
	private Long witnessId;

	@Column(name = "CASE_ID")
	private Long caseId;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "PERSON_ID")
	private Person person;

	@Column(name = "CONTACT_POINT")
	@DisplayedLoggedProperty(displayName = "Contact Point")
	private String contactPoint;

	@Column(name = "CONTACT_ADDRESS1")
	@DisplayedLoggedProperty(displayName = "Contact Address1")
	private String contactAddress1;

	@Column(name = "CONTACT_ADDRESS2")
	@DisplayedLoggedProperty(displayName = "Contact Address2")
	private String contactAddress2;

	@Column(name = "CONTACT_ADDRESS3")
	@DisplayedLoggedProperty(displayName = "Contact Address3")
	private String contactAddress3;

	@Column(name = "CONTACT_ADDRESS4")
	@DisplayedLoggedProperty(displayName = "Contact Address4")
	private String contactAddress4;

	@Column(name = "CONTACT_POSTCODE")
	@DisplayedLoggedProperty(displayName = "Contact PostCode")
	private String contactPostCode;

	@Column(name = "CONTACT_PHONE")
	@DisplayedLoggedProperty(displayName = "Contact Phone")
	private String contactPhone;

	@Column(name = "STATE")
	@DisplayedLoggedProperty(displayName = "State")
	private String state;

	@Column(name = "CREATED_TIME", updatable = false)
	private Date createdTime;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;

	@Column(name = "CONTACT_TIME")
	@DisplayedLoggedProperty(displayName = "Contact Time")
	private String contactTime;

	@Column(name = "ATTEND_COURT")
	private String attendCourt;

	@Column(name = "ANY_PARTICULAR_NEEDS ")
	private String anyParticularNeeds;

	@Column(name = "PARTICULAR_NEEDS_DESCRIPTION")
	private String particularNeedsDescription;

	@Column(name = "LEAFLET_CONSENT")
	private String leafLetConsent;

	@Column(name = "MEDICAL_RECORDS_CONSENT")
	private String medicalRecordsConsent;

	@Column(name = "DEFENCE_RECORDS_CONSENT")
	private String defenceRecordsConsent;

	@Column(name = "MG2_FORM")
	@Lob
	private byte[] mg2Form;

	@Column(name = "MG6_FORM")
	@Lob
	private byte[] mg6Form;

	@Column(name = "WITNESS_SIGNATURE")
	@DisplayedLoggedProperty(displayName = "Witness Signature")
	private String witnessSignature;

	@Column(name = "PARENT_GUARDIAN_NAME")
	@DisplayedLoggedProperty(displayName = "Parent Guardian Name")
	private String parentGuardianName;

	@Column(name = "PARENT_SIGNATURE")
	@DisplayedLoggedProperty(displayName = "Parent Signature")
	private String parentSignature;

	@Column(name = "SERIAL_NUMBER")
	private String serialNumber;

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "WITNESS_ID")
	@org.hibernate.annotations.Cascade(value = org.hibernate.annotations.CascadeType.ALL)
	//@OrderBy(value="nonAvailableId") 
	private List<NonAvailableDate> nonAvailableDates = new ArrayList<NonAvailableDate>();
	
	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";
	
	@Column(name = "mg2form_name")
	@DisplayedLoggedProperty(displayName = "MG2Form File Name")
	private String mg2FormFileName;
	
	@Column(name = "mg2form_file_type")
	@DisplayedLoggedProperty(displayName = "MG2Form File Type")
	private String mg2FormFileType;
	
	@Column(name = "mg6form_name")
	@DisplayedLoggedProperty(displayName = "MG6Form File Name")
	private String mg6FormFileName;
	
	@Column(name = "mg6form_file_type")
	@DisplayedLoggedProperty(displayName = "MG6Form File Type")
	private String mg6FormFileType;
	

	public Witness() {
		person = new Person();

	}

	public String getAnyParticularNeeds() {
		return anyParticularNeeds;
	}

	public void setAnyParticularNeeds(String anyParticularNeeds) {
		this.anyParticularNeeds = anyParticularNeeds;
	}

	public String getAttendCourt() {
		return attendCourt;
	}

	public void setAttendCourt(String attendCourt) {
		this.attendCourt = attendCourt;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getContactAddress1() {
		return contactAddress1;
	}

	public void setContactAddress1(String contactAddress1) {
		this.contactAddress1 = contactAddress1;
	}

	public String getContactAddress2() {
		return contactAddress2;
	}

	public void setContactAddress2(String contactAddress2) {
		this.contactAddress2 = contactAddress2;
	}

	public String getContactAddress3() {
		return contactAddress3;
	}

	public void setContactAddress3(String contactAddress3) {
		this.contactAddress3 = contactAddress3;
	}

	public String getContactAddress4() {
		return contactAddress4;
	}

	public void setContactAddress4(String contactAddress4) {
		this.contactAddress4 = contactAddress4;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getContactPoint() {
		return contactPoint;
	}

	public void setContactPoint(String contactPoint) {
		this.contactPoint = contactPoint;
	}

	public String getContactPostCode() {
		return contactPostCode;
	}

	public void setContactPostCode(String contactPostCode) {
		this.contactPostCode = contactPostCode;
	}

	public String getContactTime() {
		return contactTime;
	}

	public void setContactTime(String contactTime) {
		this.contactTime = contactTime;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getDefenceRecordsConsent() {
		return defenceRecordsConsent;
	}

	public void setDefenceRecordsConsent(String defenceRecordsConsent) {
		this.defenceRecordsConsent = defenceRecordsConsent;
	}

	public String getLeafLetConsent() {
		return leafLetConsent;
	}

	public void setLeafLetConsent(String leafLetConsent) {
		this.leafLetConsent = leafLetConsent;
	}

	public String getMedicalRecordsConsent() {
		return medicalRecordsConsent;
	}

	public void setMedicalRecordsConsent(String medicalRecordsConsent) {
		this.medicalRecordsConsent = medicalRecordsConsent;
	}

	public byte[] getMg2Form() {
		return mg2Form;
	}

	public void setMg2Form(byte[] mg2Form) {
		this.mg2Form = mg2Form;
	}

	public byte[] getMg6Form() {
		return mg6Form;
	}

	public void setMg6Form(byte[] mg6Form) {
		this.mg6Form = mg6Form;
	}

	public String getParentGuardianName() {
		return parentGuardianName;
	}

	public void setParentGuardianName(String parentGuardianName) {
		this.parentGuardianName = parentGuardianName;
	}

	public String getParentSignature() {
		return parentSignature;
	}

	public void setParentSignature(String parentSignature) {
		this.parentSignature = parentSignature;
	}

	public String getParticularNeedsDescription() {
		return particularNeedsDescription;
	}

	public void setParticularNeedsDescription(String particularNeedsDescription) {
		this.particularNeedsDescription = particularNeedsDescription;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getWitnessId() {
		return witnessId;
	}

	public void setWitnessId(Long witnessId) {
		this.witnessId = witnessId;
	}

	public String getWitnessSignature() {
		return witnessSignature;
	}

	public void setWitnessSignature(String witnessSignature) {
		this.witnessSignature = witnessSignature;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public List<NonAvailableDate> getNonAvailableDates() {
		nonAvailableDates = new ArrayList(new HashSet(nonAvailableDates));
		return nonAvailableDates;
	}

	public void setNonAvailableDates(List<NonAvailableDate> nonAvailableDates) {
		this.nonAvailableDates = new ArrayList(new HashSet(nonAvailableDates));
	}
	
	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		//Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}

	public String getMg2FormFileName() {
		return mg2FormFileName;
	}

	public void setMg2FormFileName(String mg2FormFileName) {
		this.mg2FormFileName = mg2FormFileName;
	}

	public String getMg2FormFileType() {
		return mg2FormFileType;
	}

	public void setMg2FormFileType(String mg2FormFileType) {
		this.mg2FormFileType = mg2FormFileType;
	}

	public String getMg6FormFileName() {
		return mg6FormFileName;
	}

	public void setMg6FormFileName(String mg6FormFileName) {
		this.mg6FormFileName = mg6FormFileName;
	}

	public String getMg6FormFileType() {
		return mg6FormFileType;
	}

	public void setMg6FormFileType(String mg6FormFileType) {
		this.mg6FormFileType = mg6FormFileType;
	}
	public String getAssociatedID(){
		if(null != getPerson()){
			return StringUtils.isNotBlank(getPerson().getFullName()) ? "Name : " + getPerson().getFullName() : StringUtils.EMPTY;
		}
		return StringUtils.EMPTY;
	}
}
