package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
@Entity
@Table(name = "INFORMATION_TBL")
@Audited
public class CaseSummaryInformation implements Serializable {
	
	@Id
	@Column(name = "INFORMATION_ID")
	private Long informationId;
	
	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "INFORMATION")
	@Type(type="uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch =FetchType.EAGER)
	@DisplayedLoggedProperty(displayName = "Information")
	private String information;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getInformation() {
		return information;
	}

	public void setInformation(String information) {
		this.information = information;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

}
