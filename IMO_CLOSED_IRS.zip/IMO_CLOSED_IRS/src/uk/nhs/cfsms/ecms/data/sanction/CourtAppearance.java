package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "COURT_APPEARANCE_TBL")
@Audited
@NamedQuery(query = "Select o from CourtAppearance o where o.sanctionId = :sanctionId", name = "getLatestBySanctionId")
public class CourtAppearance implements Serializable {

	private static final long serialVersionUID = 1809665L;
		
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "APPEARANCE_ID_SQNC") })
	@Column(name = "APPEARANCE_ID")
	private Long appearanceId;
	
	@Column(name = "SANCTION_ID")
	private Long sanctionId;
	
	@Column(name = "SANCTION_TYPE")
	@DisplayedLoggedProperty(displayName = "Sanction Team")
	private String sanctionType;
	
	@Column(name = "COURT_NAME")
	@DisplayedLoggedProperty(displayName = "Court Name")
	private String courtName;
	
	@Column(name = "APPEARANCE_DATE")
	@DisplayedLoggedProperty(displayName = "Appearance Date")
	private Date appearanceDate;
	
	@Column(name = "APPEARANCE_TIME")
	@DisplayedLoggedProperty(displayName = "Appearance Time")
	private String appearanceTime;
	
	@Column(name = "COURT_TYPE")
	@DisplayedLoggedProperty(displayName = "Court Type")
	private String courtType;
	
	@Column(name = "APPEARANCE_TYPE")
	@DisplayedLoggedProperty(displayName = "Appearance Type")
	private String appearanceType;
	
	@Column(name = "OUTCOME_INFO")
	@Type(type="uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch=FetchType.EAGER)
	@DisplayedLoggedProperty(displayName = "Outcome")
	private String outcome;
	
	
	@Transient
	private Long caseId;
	
	
	public Date getAppearanceDate() {
		return appearanceDate;
	}

	public void setAppearanceDate(Date appearanceDate) {
		this.appearanceDate = appearanceDate;
	}

	public Long getAppearanceId() {
		return appearanceId;
	}

	public void setAppearanceId(Long appearanceId) {
		this.appearanceId = appearanceId;
	}

	public String getAppearanceTime() {
		return appearanceTime;
	}

	public void setAppearanceTime(String appearanceTime) {
		this.appearanceTime = appearanceTime;
	}

	public String getAppearanceType() {
		return appearanceType;
	}

	public void setAppearanceType(String appearanceType) {
		this.appearanceType = appearanceType;
	}

	public String getCourtName() {
		return courtName;
	}

	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}

	public String getCourtType() {
		return courtType;
	}

	public void setCourtType(String courtType) {
		this.courtType = courtType;
	}


	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public String getSanctionType() {
		return sanctionType;
	}

	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getOutcome() {
		return outcome;
	}

	public void setOutcome(String outcome) {
		this.outcome = outcome;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}
}
