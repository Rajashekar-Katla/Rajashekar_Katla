package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

/**
 * Disciplinary Sanction Offence
 * 
 */
@Entity
@Table(name = "DISCIPLINARY_OFFENCES_TBL")
@Audited
public class DisciplinarySanctionOffence implements Serializable {

	private static final long serialVersionUID = 295800917L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "DISCIPLINARY_OFFENCE_ID_SQNC") })
	@Column(name = "OFFENCE_ID")
	private Long offenceId;

	@Column(name = "DISCIPLINARY_SANCTION_ID")
	private Long disciplinarySanctionId;

	@Column(name = "OFFENCE_DETAILS")
	@Type(type="uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch =FetchType.EAGER)
	@DisplayedLoggedProperty(displayName = "Offence Details")
	private  String offenceDetails;

	@Column(name = "CREATED_STAFF_ID", insertable = true, updatable = false)
	private String createdStaffId;

	@Column(name = "CREATED_TIME", insertable = true, updatable = false)
	private Date createdTime;

	
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getDisciplinarySanctionId() {
		return disciplinarySanctionId;
	}

	public void setDisciplinarySanctionId(Long disciplinarySanctionId) {
		this.disciplinarySanctionId = disciplinarySanctionId;
	}

	public String  getOffenceDetails() {
		return offenceDetails;
	}

	public void setOffenceDetails(String  offenceDetails) {
		this.offenceDetails = offenceDetails;
	}

	public Long getOffenceId() {
		return offenceId;
	}

	public void setOffenceId(Long offenceId) {
		this.offenceId = offenceId;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}	
}
