package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "INFORMATION_SOURCE_TBL")
/**
 * SourceInformation has details of the source/caller.
 * 
 * @author schilukuri
 * 
 */
@Audited
public class SourceInformation implements Serializable {

	private static final long serialVersionUID = 1412343L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SOURCE_INFO_ID_SQNC") })
	@Column(name = "SOURCE_ID")
	private Integer sourceId;

	@Column(name = "SOURCE")
	@DisplayedLoggedProperty(displayName = "Source", isList = true)
	private String source;

	@Column(name = "METHOD")
	@DisplayedLoggedProperty(displayName = "Method")
	private String method;

	@Column(name = "OTHER_METHOD")
	@DisplayedLoggedProperty(displayName = "Other Method")
	private String otherMethod;

	@Column(name = "RECEIVED_BY")
	@DisplayedLoggedProperty(displayName = "Recieved By")
	private String receivedBy;

	@Column(name = "RECEIVED_LOCATION")
	@DisplayedLoggedProperty(displayName = "Received Location")
	private String receivedLocation;

	@Column(name = "RECEIVED_DATE")
	@DisplayedLoggedProperty(displayName = "Received Date")
	private Date receivedDate;

	@Column(name = "IS_SOURCE_IDENTIFIED")
	@DisplayedLoggedProperty(displayName = "Is Source Identified")
	private String isSourceIdentified;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "SOURCE_PERSON_ID")
	private Person sourcePerson;
	
	public static final String PERSON_TYPE = "SOURCE";
	
	@Column(name = "OTHER_SOURCE")
	@DisplayedLoggedProperty(displayName = "Other Source")
	private String otherSource;
	
	@Column(name = "IS_OFFICIAL_CAPACITY")
	@DisplayedLoggedProperty(displayName = "Is Official Capacity")
	private String isOfficialCapacity;
	
	@Column(name = "JOB_TITLE")
	@DisplayedLoggedProperty(displayName = "Job Title")
	private String jobTitle;
	
	@Column(name = "OTHER_DETAILS")
	@DisplayedLoggedProperty(displayName = "Other Details")
	private String otherDetails;
	
	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";

	@Column(name = "IS_SOURCE_ANONYMOUS")
	@DisplayedLoggedProperty(displayName = "Is Source Anonymous")
	private String isSourceAnonymous;

	public String getIsSourceAnonymous() {
		return isSourceAnonymous;
	}

	public void setIsSourceAnonymous(String isSourceAnonymous) {
		this.isSourceAnonymous = isSourceAnonymous;
	}

	public String getIsSourceIdentified() {
		return isSourceIdentified;
	}

	public void setIsSourceIdentified(String isSourceIdentified) {
		this.isSourceIdentified = isSourceIdentified;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getOtherMethod() {
		return otherMethod;
	}

	public void setOtherMethod(String otherMethod) {
		this.otherMethod = otherMethod;
	}

	public String getReceivedBy() {
		return receivedBy;
	}

	public void setReceivedBy(String receivedBy) {
		this.receivedBy = receivedBy;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getReceivedLocation() {
		return receivedLocation;
	}

	public void setReceivedLocation(String receivedLocation) {
		this.receivedLocation = receivedLocation;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Integer getSourceId() {
		return sourceId;
	}

	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}

	public Person getSourcePerson() {
		return sourcePerson;
	}

	public void setSourcePerson(Person sourcePerson) {
		this.sourcePerson = sourcePerson;
		this.sourcePerson.setPersonType(PERSON_TYPE);
	}

	public String getIsOfficialCapacity() {
		return isOfficialCapacity;
	}

	public void setIsOfficialCapacity(String isOfficialCapacity) {
		this.isOfficialCapacity = isOfficialCapacity;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getOtherDetails() {
		return otherDetails;
	}

	public void setOtherDetails(String otherDetails) {
		this.otherDetails = otherDetails;
	}

	public String getOtherSource() {
		return otherSource;
	}

	public void setOtherSource(String otherSource) {
		this.otherSource = otherSource;
	}
	
	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		//Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}
	
}
