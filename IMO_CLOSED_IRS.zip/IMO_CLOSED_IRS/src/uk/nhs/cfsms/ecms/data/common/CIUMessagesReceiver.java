package uk.nhs.cfsms.ecms.data.common;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CIU_MESSAGES_RECEIVER_TBL")
public class CIUMessagesReceiver {
	@Id
	private Long id;

	@Column(name = "CIU_STAFF_ID")
	private String ciuStaffId;

	@Column(name = "STATUS")
	private String status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCiuStaffId() {
		return ciuStaffId;
	}

	public void setCiuStaffId(String ciuStaffId) {
		this.ciuStaffId = ciuStaffId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "CIUMessagesReceiver [id=" + id + ", ciuStaffId=" + ciuStaffId
				+ ", status=" + status + "]";
	}
	
}
