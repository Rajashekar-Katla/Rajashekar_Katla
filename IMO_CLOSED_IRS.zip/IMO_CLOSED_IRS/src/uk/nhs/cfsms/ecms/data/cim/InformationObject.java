package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;





/**
 * Information has details of the fraud allegation details.
 * 
 * @author schilukuri
 * 
 */
@Entity
@Table(name = "INFORMATION_TBL")
public class InformationObject implements Serializable {

	private static final long serialVersionUID = 1530234L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "INFORMATION_ID_SQNC") })
	@Column(name = "INFORMATION_ID")
	private Long informationId;

	@Column(name = "INFORMATION_NUM")
	@DisplayedLoggedProperty(displayName = "Information Number")
	private String informationNum;

	@Column(name = "DESCRIPTION")
	@DisplayedLoggedProperty(displayName = "Comment")
	private String comment;

	@Column(name = "TYPE")
	@DisplayedLoggedProperty(displayName = "Type")
	private String type;

	@Column(name = "COST")
	@DisplayedLoggedProperty(displayName = "Cost")
	private BigDecimal cost;

	@Column(name = "IS_STILL_FRAUD_OCCURING")
	@DisplayedLoggedProperty(displayName = "Is Fraud Still Occuring")
	private String isStillFraudOccuring;

	@Column(name = "START_DATE")
	@DisplayedLoggedProperty(displayName = "Start Date")
	private Date startDate;

	@Column(name = "IS_START_DATE_CORRECT")
	@DisplayedLoggedProperty(displayName = "Is Start Date Correct")
	private String isStartDateCorrect;

	@Column(name = "ORG_CODE")
	@DisplayedLoggedProperty(displayName = "Organisation Code")
	private String orgCode;

	@Column(name = "INFORMATION_DISCARDED")
	@DisplayedLoggedProperty(displayName = "Information Discarded")
	private String informationDiscarded;

	
	@Column(name = "INFORMATION_SOURCE_ID")
	private Long informationSourceId;

	@Column(name = "CREATED_TIME", updatable = false)
	private Timestamp createdDate;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;

	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "region_override")
	@DisplayedLoggedProperty(displayName = "Region Override")
	private String  regionOverride;

	@Column(name = "TITLE")
	@DisplayedLoggedProperty(displayName = "Title")
	private String title;

	@Column(name = "INTELLIGENCE_CONTENT")
	@DisplayedLoggedProperty(displayName = "Inteligent Content")
	private String intelligenceContent;

	@Column(name = "INTELLIGENCE_URN")
	@DisplayedLoggedProperty(displayName = "Intelligent URN")
	private String intelligenceURN;

	@Column(name = "INFORMATION_DATE")
	@DisplayedLoggedProperty(displayName = "Information Date")
	private Date informationDate;

	@Column(name = "TEAM_CODE")
	@DisplayedLoggedProperty(displayName = "Team Code")
	private String teamCode;
	
	@Column(name = "REJECT_COMMENT")
	@DisplayedLoggedProperty(displayName = "Rejected Comment")
	private String rejectedComment;
	
	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";
	
	@Column(name = "STATE")
	@DisplayedLoggedProperty(displayName = "State")
	private String state ;
	
	@Column(name = "INFO_APPROVAL_STATUS")
	@DisplayedLoggedProperty(displayName = "Approval Status")
	private String infoApprovalStatus ;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public BigDecimal getCost() {
		return cost == null ? cost : cost.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getInformationDiscarded() {
		return informationDiscarded;
	}

	public void setInformationDiscarded(String informationDiscarded) {
		this.informationDiscarded = informationDiscarded;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getInformationNum() {
		return informationNum;
	}

	public void setInformationNum(String informationNum) {
		this.informationNum = informationNum;
	}

	public String getIsStartDateCorrect() {
		return isStartDateCorrect;
	}

	public void setIsStartDateCorrect(String isStartDateCorrect) {
		this.isStartDateCorrect = isStartDateCorrect;
	}

	public String getIsStillFraudOccuring() {
		return isStillFraudOccuring;
	}

	public void setIsStillFraudOccuring(String isStillFraudOccuring) {
		this.isStillFraudOccuring = isStillFraudOccuring;
	}

	
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Date getInformationDate() {
		return informationDate;
	}

	public void setInformationDate(Date informationDate) {
		this.informationDate = informationDate;
	}

	

	public String getIntelligenceContent() {
		return intelligenceContent;
	}

	public void setIntelligenceContent(String intelligenceContent) {
		this.intelligenceContent = intelligenceContent;
	}

	public String getIntelligenceURN() {
		return intelligenceURN;
	}

	public void setIntelligenceURN(String intelligenceURN) {
		this.intelligenceURN = intelligenceURN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	

	public String getRejectedComment() {
		return rejectedComment;
	}

	public void setRejectedComment(String rejectedComment) {
		this.rejectedComment = rejectedComment;
	}

	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		//Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}

	public String getRegionOverride() {
		return regionOverride;
	}

	public void setRegionOverride(String regionOverride) {
		this.regionOverride = regionOverride;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getInformationSourceId() {
		return informationSourceId;
	}

	public void setInformationSourceId(Long informationSourceId) {
		this.informationSourceId = informationSourceId;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getInfoApprovalStatus() {
		return infoApprovalStatus;
	}

	public void setInfoApprovalStatus(String infoApprovalStatus) {
		this.infoApprovalStatus = infoApprovalStatus;
	}

}
