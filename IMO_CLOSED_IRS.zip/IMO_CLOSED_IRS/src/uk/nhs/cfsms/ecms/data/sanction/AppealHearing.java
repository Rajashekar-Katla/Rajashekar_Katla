package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "APPEAL_HEARING_TBL")
@Audited
public class AppealHearing implements Serializable {

	private static final long serialVersionUID = 1809665L;
		
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "APPEARANCE_ID_SQNC") })
	@Column(name = "APPEARANCE_ID")
	private Long appearanceId;
	
	@Column(name = "APPEAL_ID")
	private Long appealId;
	
	@Column(name = "SANCTION_TYPE")
	@DisplayedLoggedProperty(displayName = "Sanction Type")
	private String sanctionType;
	
	@Column(name = "COURT_NAME")
	@DisplayedLoggedProperty(displayName = "Court Name")
	private String courtName;
	
	@Column(name = "HEARING_DATE")
	@DisplayedLoggedProperty(displayName = "Hearing Date")
	private Date hearingDate;
	
	@Column(name = "HEARING_TIME")
	@DisplayedLoggedProperty(displayName = "Hearing Time")
	private String hearingTime;
	
	@Column(name = "COURT_TYPE")
	@DisplayedLoggedProperty(displayName = "Court Type")
	private String courtType;
	
	@Column(name = "APPEARANCE_TYPE")
	@DisplayedLoggedProperty(displayName = "Appearance Type")
	private String appearanceType;
	
	@Column(name = "OUTCOME_INFO")
	@Type(type="uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch =FetchType.EAGER)
	@DisplayedLoggedProperty(displayName = "Outcome")
	private String outcome;
	

	public Long getAppearanceId() {
		return appearanceId;
	}

	public void setAppearanceId(Long appearanceId) {
		this.appearanceId = appearanceId;
	}

	public Date getHearingDate() {
		return hearingDate;
	}

	public void setHearingDate(Date hearingDate) {
		this.hearingDate = hearingDate;
	}

	public String getHearingTime() {
		return hearingTime;
	}

	public void setHearingTime(String hearingTime) {
		this.hearingTime = hearingTime;
	}

	public String getAppearanceType() {
		return appearanceType;
	}

	public void setAppearanceType(String appearanceType) {
		this.appearanceType = appearanceType;
	}

	public String getCourtName() {
		return courtName;
	}

	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}

	public String getCourtType() {
		return courtType;
	}

	public void setCourtType(String courtType) {
		this.courtType = courtType;
	}


	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public String getSanctionType() {
		return sanctionType;
	}

	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getOutcome() {
		return outcome;
	}

	public void setOutcome(String outcome) {
		this.outcome = outcome;
	}
}
