package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;


@Entity
@Table(name="CASE_PROGRESS_NO_TBL")

public class CaseProgressNumber implements Serializable {
	
	private static final long serialVersionUID = 2348789L;

	@Id
	@Column(name = "CASE_PROGRESS_NO_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CASE_PROGRESS_NO_ID_SQNC") })	
	private Long caseProgressNumberId;
	
	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "SEQUENCE")
	private String sequence;
	
	@Column(name = "DECISION_SEQUENCE")
	private String sequenceDecision;
	
	@Column(name = "LEGAL_SEQUENCE")
	private String sequenceLegal;

	

	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the caseProgressNumberId.
	 */
	public Long getCaseProgressNumberId() {
		return caseProgressNumberId;
	}

	/**
	 * @param caseProgressNumberId The caseProgressNumberId to set.
	 */
	public void setCaseProgressNumberId(Long caseProgressNumberId) {
		this.caseProgressNumberId = caseProgressNumberId;
	}

	/**
	 * @return Returns the sequence.
	 */
	public String getSequence() {
		return sequence;
	}

	/**
	 * @param sequence The sequence to set.
	 */
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	
	public String getSequenceDecision() {
		return sequenceDecision;
	}

	public void setSequenceDecision(String sequenceDecision) {
		this.sequenceDecision = sequenceDecision;
	}

	public String getSequenceLegal() {
		return sequenceLegal;
	}

	public void setSequenceLegal(String sequenceLegal) {
		this.sequenceLegal = sequenceLegal;
	}
}
