package uk.nhs.cfsms.ecms.data.civilsanction;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

@Entity
@Table(name = "CIVIL_APPEAL_VIEW")
@NamedQuery(name = "getAppealsByParentSanctionId", query = "from CivilAppealView where sanction.civilSanctionId = :sanctionId ")
public class CivilAppealView implements Serializable {
  
	private static final long serialVersionUID = -6254473326429837029L;

	@Id
	@Column(name = "APPEAL_ID")
	private Long appealId;

	@ManyToOne
	@JoinColumn(name = "SANCTION_ID")
	private CivilSanction sanction;

	@Column(name = "APPEALED_OUTCOME_ID")
	private Long appealedId;

	@Column(name = "APPEALED_OUTCOME_TYPE")
	private String appealedOutcomeType;

	@OneToOne(mappedBy = "forAppeal")
	private CivilAppealOutcome outcome;

	@Column(name = "SUBJECT_ID")
	private Long subjectId;

	@Column(name = "SUBJECT_TYPE")
	private String subjectType;

	@Column(name = "OTHERSUBJECTS")
	private String otherSubjects;

	@Column(name = "LEGAL_CONTACT")
	private String legalContact;

	@Column(name = "CREATED_STAFF_ID", insertable = true, updatable = false)
	private String createdStaffId;

	@Column(name = "CREATED_TIME", insertable = true, updatable = false)
	private Date createdTime;

	@Column(name = "APPEAL_DATE")
	private Date dateOfAppeal;

	@Column(name = "STATE")
	private String state;

	@Column(name = "COURT_ORG_DECISION")
	private String nameOfCourtMakingOriginalDecision;

	@Column(name = "DATE_OF_ORG_DECS")
	private Date dateOfOriginalDecision;

	@OneToMany(targetEntity = CourtAppearance.class)
	@JoinTable(name = "CVL_APPL_CRT_APPRNCE_TBL", joinColumns = @JoinColumn(name = "APPEAL_ID", referencedColumnName = "APPEAL_ID"), inverseJoinColumns = @JoinColumn(name = "APPEARANCE_ID", referencedColumnName = "APPEARANCE_ID"))
	private Set<CourtAppearance> courtAppearances;

	@Column(name = "DECISION_APPEAL_AGAINST")
	private String decisionAppealAgainst;

	@Column(name = "APPELLANT")
	private String appellant;	

	@Column(name = "CASE_ID")
	@DisplayedLoggedProperty(displayName = "Case ID")
	private Long caseId;

	@Column(name = "PARENT_APPEAL_ID")
	@DisplayedLoggedProperty(displayName = "Parent Appeal ID")
	private Long parentAppealId;

	@Column(name = "APPELLANT_TYPE")
	private String appellantType;	
	
	public CivilSanction getSanction() {
		return sanction;
	}

	public void setSanction(CivilSanction sanction) {
		this.sanction = sanction;
	}

	public CivilAppealOutcome getOutcome() {
		return outcome;
	}

	public void setOutcome(CivilAppealOutcome outcome) {
		this.outcome = outcome;
	}

	public String getLegalContact() {
		return legalContact;
	}

	public void setLegalContact(String legalContact) {
		this.legalContact = legalContact;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getDateOfAppeal() {
		return dateOfAppeal;
	}

	public void setDateOfAppeal(Date dateOfAppeal) {
		this.dateOfAppeal = dateOfAppeal;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getNameOfCourtMakingOriginalDecision() {
		return nameOfCourtMakingOriginalDecision;
	}

	public void setNameOfCourtMakingOriginalDecision(
			String nameOfCourtMakingOriginalDecision) {
		this.nameOfCourtMakingOriginalDecision = nameOfCourtMakingOriginalDecision;
	}

	public Date getDateOfOriginalDecision() {
		return dateOfOriginalDecision;
	}

	public void setDateOfOriginalDecision(Date dateOfOriginalDecision) {
		this.dateOfOriginalDecision = dateOfOriginalDecision;
	}

	public String getDecisionAppealAgainst() {
		return decisionAppealAgainst;
	}

	public void setDecisionAppealAgainst(String decisionAppealAgainst) {
		this.decisionAppealAgainst = decisionAppealAgainst;
	}

	public String getAppellant() {
		return appellant;
	}

	public void setAppellant(String appellant) {
		this.appellant = appellant;
	}

	public Long getAppealId() {
		return appealId;
	}
	
	public void setAppealId(Long id) {
		this.appealId = id;
	}

	public Set<CourtAppearance> getCourtAppearances() {
		return courtAppearances;
	}

	public void setCourtAppearances(Set<CourtAppearance> courtAppearances) {
		this.courtAppearances = courtAppearances;
	}


	@Column(name = "NHS_SUBJECT_NAME")
	private String nhsSubjectName;

	@Column(name = "NON_NHS_SUBJECT_NAME")
	private String nonNhsSubjectName;

	@Column(name = "PERSON_SUBJECT_NAME")
	private String personSubjectName;

	public String getNhsSubjectName() {
		return nhsSubjectName;
	}

	public void setNhsSubjectName(String nhsSubjectName) {
		this.nhsSubjectName = nhsSubjectName;
	}

	public String getNonNhsSubjectName() {
		return nonNhsSubjectName;
	}

	public void setNonNhsSubjectName(String nonNhsSubjectName) {
		this.nonNhsSubjectName = nonNhsSubjectName;
	}

	public String getPersonSubjectName() {
		return personSubjectName;
	}

	public void setPersonSubjectName(String personSubjectName) {
		this.personSubjectName = personSubjectName;
	}

	public Long getAppealedId() {
		return appealedId;
	}

	public void setAppealedId(Long appealedId) {
		this.appealedId = appealedId;
	}

	public String getAppealedOutcomeType() {
		return appealedOutcomeType;
	}

	public void setAppealedOutcomeType(String appealedOutcomeType) {
		this.appealedOutcomeType = appealedOutcomeType;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	public String getSubjectName() {
		String subjectName = "";
		if (CaseUtil.SubjectType.PERSON.toString().equals(getSubjectType())) {
			subjectName = getPersonSubjectName();
		} else if (CaseUtil.SubjectType.NHS.toString().equals(getSubjectType())) {
			subjectName = getNhsSubjectName();
		} else if (CaseUtil.SubjectType.NON_NHS.toString().equals(
				getSubjectType())) {
			subjectName = getNonNhsSubjectName();
		} else if ("Other".equalsIgnoreCase(getSubjectType())) {
			subjectName = otherSubjects;
		}
		return subjectName;
	}

	public String getOtherSubjects() {
		return otherSubjects;
	}

	public void setOtherSubjects(String otherSubjects) {
		this.otherSubjects = otherSubjects;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}
	
	public String getAppellantType() {
		return appellantType;
	}

	public void setAppellantType(String appellantType) {
		this.appellantType = appellantType;
	}

}
