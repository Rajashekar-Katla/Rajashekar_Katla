package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
import uk.nhs.cfsms.ecms.data.infoGath.Person;

@Entity
@Table(name = "CASE_CONTACT_TBL")

public class CaseContactStandalone implements Serializable {

	private static final long serialVersionUID = 28000344L;

	@Id
	@Column(name = "CONTACT_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CASE_CONTACT_ID_SQNC") })
	private Long contactId;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "CONTACT_TYPE")
	@DisplayedLoggedProperty(displayName = "Contact Type")
	private String contactType;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "CONTACT_PERSON_ID")
	private Person person;

	@Column(name = "ISWITNESS")
	@DisplayedLoggedProperty(displayName = "Is Witness")
	private String isWitness;

	@Column(name = "ISSUBJECT")
	@DisplayedLoggedProperty(displayName = "Is Subject")
	private String isSubject;

	@Column(name = "STATE")
	@DisplayedLoggedProperty(displayName = "State")
	private String state;

	@Column(name = "CREATED_TIME", updatable = false)
	private Timestamp createdDate;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;
	
	@Column(name = "INFO_ID")
	private Long infoId;

	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";
	
	public CaseContactStandalone() {
		this.person = new Person();
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getContactId() {
		return contactId;
	}

	public void setContactId(Long contactId) {
		this.contactId = contactId;
	}

	public String getContactType() {
		return contactType;
	}

	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getIsSubject() {
		return isSubject;
	}

	public void setIsSubject(String isSubject) {
		this.isSubject = isSubject;
	}

	public String getIsWitness() {
		return isWitness;
	}

	public void setIsWitness(String isWitness) {
		this.isWitness = isWitness;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	public Long getInfoId() {
		return infoId;
	}
	
	public void setInfoId(Long infoId) {
		this.infoId = infoId;
	}
	
	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		//Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}

}
