package uk.nhs.cfsms.ecms.data.cim;

import uk.nhs.cfsms.ecms.data.common.UserObject;

public class CaseAssigneeTO {
	
	CasePermission casePermission;
	
	UserObject user;
	
	String assigneeLevel;

	public String getAssigneeLevel() {
		return assigneeLevel;
	}

	public void setAssigneeLevel(String assigneeLevel) {
		this.assigneeLevel = assigneeLevel;
	}

	public CasePermission getCasePermission() {
		if(casePermission == null)
			return new CasePermission();
		return casePermission;
	}

	public void setCasePermission(CasePermission casePermission) {
		this.casePermission = casePermission;
	}

	public UserObject getUser() {
		if(user == null)
			return new UserObject();
		return user;
	}

	public void setUser(UserObject user) {
		this.user = user;
	}

}
