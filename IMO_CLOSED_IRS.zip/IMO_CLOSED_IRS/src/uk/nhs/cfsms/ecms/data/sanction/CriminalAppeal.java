package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;


@Entity
@Table(name = "CRIMINAL_APPEAL_TBL")
@Audited
public class CriminalAppeal implements Serializable {
	
	private static final long serialVersionUID = 254309864544L;
	
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CRIMINAL_APPEAL_ID_SQNC") })
	@Column(name = "APPEAL_ID")
	private Long appealId;
	
	@Column(name = "PARENT_APPEAL_ID")
	private Long parentAppealId;
	
	@Column(name = "SANCTION_ID")
	private Long sanctionId;
	
	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "APPEAL_MAKER")
	@DisplayedLoggedProperty(displayName = "Name of the Appellant")
	private String appealMaker;
	
	@Column(name = "SUBJECT_ID")
	@DisplayedLoggedProperty(displayName = "Name of the Respondent")
	private Long subjectId;
	
	@Column(name = "SUBJECT_TYPE")
	@DisplayedLoggedProperty(displayName = "Subject Type" )
	private String subjectType;
	
	@Column(name = "CREATED_STAFF_ID" , insertable=true, updatable=false)	
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME" , insertable=true, updatable=false)	
	private Date createdTime;
	
	@Column(name = "APPEARED_DATE")
	@DisplayedLoggedProperty(displayName = "Date of Sentence Appealed")
	private Date appearedDate;
	
	@Column(name = "COURT_MAKING_DEC_NAME")
	@DisplayedLoggedProperty(displayName = "Name of court making decision")
	private String courtMakingDecName;
	
	@Column(name = "OTHER_SUBJECT")
	@DisplayedLoggedProperty(displayName = "Name of convicted person in respect to whom this appeal is made")
	private String otherSubject; 

//	@Column(name = "APPELLANT_NAME")
//	@DisplayedLoggedProperty(displayName = "Name of Person or Organisation making the Appeal")
	@Transient
	private String appellantName;
	
	
	public Date getAppearedDate() {
		return appearedDate;
	}

	public String getOtherSubject() {
		return otherSubject;
	}

	public String getCourtMakingDecName() {
		return courtMakingDecName;
	}

	public void setCourtMakingDecName(String courtMakingDecName) {
		this.courtMakingDecName = courtMakingDecName;
	}

	@Column(name = "STATE")
	//@DisplayedLoggedProperty(displayName = "State")
	private String state;

	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the createdStaffId.
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	/**
	 * @param createdStaffId The createdStaffId to set.
	 */
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	/**
	 * @return Returns the createdTime.
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime The createdTime to set.
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return Returns the criminalSanctionId.
	 */
	public Long getAppealId() {
		return appealId;
	}

	/**
	 * @param criminalSanctionId The criminalSanctionId to set.
	 */
	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return Returns the subjectId.
	 */
	public Long getSubjectId() {
		return subjectId;
	}

	/**
	 * @param subjectId The subjectId to set.
	 */
	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	/**
	 * @return Returns the subjectType.
	 */
	public String getSubjectType() {
		return subjectType;
	}

	/**
	 * @param subjectType The subjectType to set.
	 */
	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}
	

	public String getAppealMaker() {
		return appealMaker;
	}

	public void setAppealMaker(String appealMaker) {
		this.appealMaker = appealMaker;
	}
	
	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}

	public void setOtherSubject(String otherSubject) {
		this.otherSubject = otherSubject;
	}

	public void setAppearedDate(Date appearedDate) {
		this.appearedDate = appearedDate;
	}

	public String getAppellantName() {
		return appellantName;
	}

	public void setAppellantName(String appellantName) {
		this.appellantName = appellantName;
	}
 
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
