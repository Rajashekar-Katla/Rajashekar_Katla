package uk.nhs.cfsms.ecms.data.cim;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "CASE_NUMBERS_TBL")
public class CaseNumber {

	@Id
	@Column(name = "CASE_NUMBER_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CASE_NUMBER_ID_SQNC") })
	private Long id;

	@Column(name = "NEXT_SEQUENCE")
	private String nextSequence;

	@Column(name = "YEAR")
	private String year;

	@Column(name = "TEAM_CODE")
	private String teamCode;

	/**
	 * @return Returns the nextSequence.
	 */
	public String getNextSequence() {
		return nextSequence;
	}

	/**
	 * @param nextSequence
	 *            The nextSequence to set.
	 */
	public void setNextSequence(String nextSequence) {
		this.nextSequence = nextSequence;
	}

	/**
	 * @return Returns the teamCode.
	 */
	public String getTeamCode() {
		return teamCode;
	}

	/**
	 * @param teamCode
	 *            The teamCode to set.
	 */
	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	/**
	 * @return Returns the year.
	 */
	public String getYear() {
		return year;
	}

	/**
	 * @param year
	 *            The year to set.
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * @return Returns the id.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            The id to set.
	 */
	public void setId(Long id) {
		this.id = id;
	}

}
