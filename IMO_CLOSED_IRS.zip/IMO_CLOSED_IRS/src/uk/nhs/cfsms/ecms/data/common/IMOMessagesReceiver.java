package uk.nhs.cfsms.ecms.data.common;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMO_MESSAGES_RECEIVER_TBL")
public class IMOMessagesReceiver {

	@Id
	private Long id;

	@Column(name = "IMO_STAFF_ID")
	private String imoStaffId;

	@Column(name = "STATUS")
	private String status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getImoStaffId() {
		return imoStaffId;
	}

	public void setImoStaffId(String imoStaffId) {
		this.imoStaffId = imoStaffId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "IMOMessagesReceiver [id=" + id + ", imoStaffId=" + imoStaffId
				+ ", status=" + status + "]";
	}

}
