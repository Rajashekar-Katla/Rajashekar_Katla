package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="org_map_hist_tbl")
public class MergingOrganisation implements Serializable{
	
	
	@Id
	@Column(name = "map_ID")
	private Long mapId;
	
	@Column(name = "old_org_code")
	private String oldOrgCode;
	
	@Column(name = "current_org_code")
	private String newOrgCode;
	
	@Column(name = "status")
	private String status;

	public Long getMapId() {
		return mapId;
	}

	public void setMapId(Long mapId) {
		this.mapId = mapId;
	}

	public String getNewOrgCode() {
		return newOrgCode;
	}

	public void setNewOrgCode(String newOrgCode) {
		this.newOrgCode = newOrgCode;
	}

	public String getOldOrgCode() {
		return oldOrgCode;
	}

	public void setOldOrgCode(String oldOrgCode) {
		this.oldOrgCode = oldOrgCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	

}
