package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="PERMISSION_GROUP_TBL")
public class PermissionGroup implements Serializable, Comparable  {
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * The unique for the table
	 */
	@Id
	@Column(name="PERMISSION_GROUP_ID")
	private Long id;

	@Column(name="NAME")
	private String name;

	@Column(name="LVL")
	private int level;
	
	@ManyToMany(			
	        targetEntity=Permission.class,
	        cascade={CascadeType.ALL}
	        //,fetch=FetchType.EAGER
	)
    @JoinTable(
        name="PERMISSION_GROUP_LNK_TBL",
        joinColumns={@JoinColumn(name="GROUP_ID")},
        inverseJoinColumns={@JoinColumn(name="PERM_ID")}
    )	
	private List<Permission> permissions;			
	
	/**
	 * @return Returns the id.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id The id to set.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return Returns the permissions.
	 */
	public List<Permission> getPermissions() {
		return permissions;
	}

	/**
	 * @param permissions The permissions to set.
	 */
	public void setPermissions(List<Permission> permissions) {
		this.permissions = permissions;
	}	

	/**
	 * @return Returns the level.
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * @param level The level to set.
	 */
	public void setLevel(int level) {
		this.level = level;
	}

	public int compareTo(Object o) {
		
		if (o instanceof PermissionGroup) {
			PermissionGroup pg = (PermissionGroup)o;
			int pgLevel = pg.getLevel();

			if (pgLevel > this.getLevel()) {
				return 1;
			} else if (pgLevel < this.getLevel()) {
				return -1;
			}
			return 0;
			
		} else {
			return 0;
		}		
	}

	
	
	
	
}
