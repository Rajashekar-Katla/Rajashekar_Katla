package uk.nhs.cfsms.ecms.data.cim;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ALL_CASE_VIEW")
public class CaseObject {
	

	private static final long serialVersionUID = 4939871235L;
	
	@Column(name = "INFORMATION_ID")
	private Long informationId;
	
	@Id
	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "TYPE")
	private String type;
	
	@Column(name = "CASE_NUMBER")
	private String caseNumber;
	
	@Column(name = "OPERATION_NAME")
	private String operationName;
	
	@Column(name = "CREATED_TIME")
	private Date createdTime;
	
	@Column(name = "CREATED_STAFF_ID")
	private String createdStaffId;
	
	@Column(name = "TEAM_CODE")
	private String teamCode;
	
	@Column(name = "STATE")
	private String state;
	
	@Column(name = "SUMMARY_ADDED")
	private String summaryAdded;
	
	@Column(name = "ACCESS_FLAG")
	private String accessFlag;
	
	@Column(name = "ORG_NAME")
	private String orgName;
	
	@Column(name = "ORG_CODE")
	private String orgCode;
	
	@Column(name = "SUBJECT_NAME")
	private String subjectName;
	
	@Column(name = "LEAD_ASSIGNEE_FIRSTNAME")
	private String assigneeFirstName;
	
	@Column(name = "LEAD_ASSIGNEE_LASTNAME")
	private String assigneeLastName;
	
	@Column(name = "LEAD_ASSIGNEE")
	private String leadAssignee;
	
	@Column(name = "restrict_to")
	private String restrictTo;
		
	@Column(name = "OVERLOADED_CASE")
	private String isOverLoadedCase;

	@Column(name ="REOPENED_TIME")
	private String reopenedTime;
	
	@Column(name = "CLOSED_TIME")
	private Date closedTime;
	
	public String getAccessFlag() {
		return accessFlag;
	}

	public void setAccessFlag(String accessFlag) {
		this.accessFlag = accessFlag;
	}
	
	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCase_number(String case_number) {
		this.caseNumber = case_number;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getLeadAssignee() {
		return leadAssignee;
	}

	public void setLeadAssignee(String leadAssignee) {
		this.leadAssignee = leadAssignee;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getState() {
		if(state != null && state.indexOf("_") > 1)
		{
			String str=state.substring(0,state.indexOf("_"))+"\n"+state.substring(state.indexOf("_"));
			return str;
			
		}
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getSummaryAdded() {
		return summaryAdded;
	}

	public void setSummaryAdded(String summaryAdded) {
		this.summaryAdded = summaryAdded;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public String getAssigneeFirstName() {
		return assigneeFirstName;
	}

	public void setAssigneeFirstName(String assigneeFirstName) {
		this.assigneeFirstName = assigneeFirstName;
	}

	public String getAssigneeLastName() {
		return assigneeLastName;
	}

	public void setAssigneeLastName(String assigneeLastName) {
		this.assigneeLastName = assigneeLastName;
	}

	public String getRestrictTo() {
		return restrictTo;
	}

	public void setRestrictTo(String restrictTo) {
		this.restrictTo = restrictTo;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public String getIsOverLoadedCase() {
		return isOverLoadedCase;
	}

	public void setIsOverLoadedCase(String isOverLoadedCase) {
		this.isOverLoadedCase = isOverLoadedCase;
	}

	public String getReopenedTime() {
		return reopenedTime;
	}

	public void setReopenedTime(String reopenedTime) {
		this.reopenedTime = reopenedTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public Date getClosedTime() {
		return closedTime;
	}

	public void setClosedTime(Date closedTime) {
		this.closedTime = closedTime;
	}

}


