package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "CASE_COURT_COST_TBL")
@Audited
@DisplayedLoggedProperty(detailsMethod = "Helper.getCaseCourtExpectedCost")
public class CaseCourtCosts implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6821428483781825102L;

	@Id
	@Column(name = "COURT_COST_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CASE_COURT_COST_ID_SQNC") })
	private Long courtCostId;
	
	@Column(name = "EXPCT_COST_ID")
	@DisplayedLoggedProperty(displayName = "Expected Cost")
	private Long expctCostId;
	
	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "CREATED_DATE", updatable = false)
	private Date createdDate;
	
	@Transient
	private List<ExpectedCourtCost> costList;
	

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getCourtCostId() {
		return courtCostId;
	}

	public void setCourtCostId(Long courtCostId) {
		this.courtCostId = courtCostId;
	}

	public Long getExpctCostId() {
		return expctCostId;
	}

	public void setExpctCostId(Long expctCostId) {
		this.expctCostId = expctCostId;
	}

	public List<ExpectedCourtCost> getCostList() {
		return costList;
	}

	public void setCostList(List<ExpectedCourtCost> costList) {
		this.costList = costList;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
}
