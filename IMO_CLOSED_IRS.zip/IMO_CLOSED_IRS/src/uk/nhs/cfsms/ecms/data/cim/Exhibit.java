package uk.nhs.cfsms.ecms.data.cim;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
import uk.nhs.cfsms.ecms.dto.witness.WitnessTO;

@Entity
@Table(name = "EXHIBIT_TBL")
@Audited
public class Exhibit {

	@Transient
	protected final Log logger = LogFactory.getLog(getClass());

	@Id
	@Column(name = "EXHIBIT_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "EXHIBIT_ID_SQNC") })
	private Long exhibitId;

	@Column(name = "REFERENCE")
	@DisplayedLoggedProperty(displayName = "Reference")
	private String reference;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "PRODUCED_ON")
	@DisplayedLoggedProperty(displayName = "Produced On")
	private Date producedOn;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "PRODUCED_BY")
	private Date producedBy;

	@Column(name = "LOCATION")
	@DisplayedLoggedProperty(displayName = "Location")
	private String location;

	@Column(name = "DESCRIPTION")
	@DisplayedLoggedProperty(displayName = "Description")
	private String description;

	@Column(name = "PRIOR_REFERENCE")
	@DisplayedLoggedProperty(displayName = "Prior Reference")
	private String priorReference;

	@Column(name = "DISCLOSURE_STATE")
	@DisplayedLoggedProperty(displayName = "Disclosure State")
	private String disclosureState;

	@Column(name = "TAKEN_BY")
	@DisplayedLoggedProperty(displayName = "Taken By")
	private String takenBy;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "FROM_PLACE_PRSN")
	@DisplayedLoggedProperty(displayName = "From Place Person")
	private String fromPlacePerson;

	@Column(name = "MOVEMENT")
	@DisplayedLoggedProperty(displayName = "Movement")
	private String movement;

	@Column(name = "CREATED_TIME", updatable = false)
	private Date createdDate;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;

	@OneToMany(mappedBy = "exhibit", fetch = FetchType.LAZY)
	private List<ExhibitDocuments> exhibitDocumentsList = new ArrayList<ExhibitDocuments>();

	@Transient
	private List<WitnessTO> witnessList;

	public Exhibit() {
	}

	public Exhibit(final Long exhibitId, final String reference,
			final String description, final String disclosureState,
			final Long caseId, final Date createdDate,
			final String fromPlacePerson) {
		this.exhibitId = exhibitId;
		this.reference = reference;
		this.description = description;
		this.disclosureState = disclosureState;
		this.caseId = caseId;
		this.createdDate = createdDate;
		this.fromPlacePerson = fromPlacePerson;
	}

	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            The description to set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return Returns the disclosureState.
	 */
	public String getDisclosureState() {
		return disclosureState;
	}

	/**
	 * @param disclosureState
	 *            The disclosureState to set.
	 */
	public void setDisclosureState(String disclosureState) {
		this.disclosureState = disclosureState;
	}

	/**
	 * @return Returns the location.
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location
	 *            The location to set.
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return Returns the priorReference.
	 */
	public String getPriorReference() {
		return priorReference;
	}

	/**
	 * @param priorReference
	 *            The priorReference to set.
	 */
	public void setPriorReference(String priorReference) {
		this.priorReference = priorReference;
	}

	/**
	 * @return Returns the producedOn.
	 */
	public Date getProducedOn() {
		return producedOn;
	}

	/**
	 * @param producedOn
	 *            The producedOn to set.
	 */
	public void setProducedOn(Date producedOn) {
		this.producedOn = producedOn;
	}

	/**
	 * @return Returns the reference.
	 */
	public String getReference() {
		return reference;
	}

	/**
	 * @param reference
	 *            The reference to set.
	 */
	public void setReference(String reference) {
		this.reference = reference;
	}

	/**
	 * @return Returns the exhibitId.
	 */
	public Long getExhibitId() {
		return exhibitId;
	}

	/**
	 * @param exhibitId
	 *            The exhibitId to set.
	 */
	public void setExhibitId(Long exhibitId) {
		this.exhibitId = exhibitId;
	}

	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId
	 *            The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the movement.
	 */
	public String getMovement() {
		return movement;
	}

	/**
	 * @param movement
	 *            The movement to set.
	 */
	public void setMovement(String movement) {
		this.movement = movement;
	}

	/**
	 * @return Returns the fromPlacePerson.
	 */
	public String getFromPlacePerson() {
		return fromPlacePerson;
	}

	/**
	 * @param fromPlacePerson
	 *            The fromPlacePerson to set.
	 */
	public void setFromPlacePerson(String fromPlacePerson) {
		this.fromPlacePerson = fromPlacePerson;
	}

	/**
	 * @return Returns the producedBy.
	 */
	public Date getProducedBy() {
		return producedBy;
	}

	/**
	 * @param producedBy
	 *            The producedBy to set.
	 */
	public void setProducedBy(Date producedBy) {
		this.producedBy = producedBy;
	}

	/**
	 * @return Returns the takenBy.
	 */
	public String getTakenBy() {
		return takenBy;
	}

	/**
	 * @param takenBy
	 *            The takenBy to set.
	 */
	public void setTakenBy(String takenBy) {
		this.takenBy = takenBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public List<WitnessTO> getWitnessList() {
		return witnessList;
	}

	public void setWitnessList(List<WitnessTO> witnessList) {
		this.witnessList = witnessList;
	}

	/**
	 * @return the exhibitDocumentsList
	 */
	public List<ExhibitDocuments> getExhibitDocumentsList() {
		return exhibitDocumentsList;
	}

	/**
	 * @param exhibitDocumentsList
	 *            the exhibitDocumentsList to set
	 */
	public void setExhibitDocumentsList(
			List<ExhibitDocuments> exhibitDocumentsList) {
		this.exhibitDocumentsList = exhibitDocumentsList;
	}

}
