package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "INVESTIGATION_PLAN_TBL")
@Audited
public class InvestigationPlan implements Serializable {

	@Id
	@Column(name = "INVESTIGATION_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "INVESTIGATION_PLAN_ID_SQNC") })
	private Long investigationId;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "ALLEGATION_DATE")
	@DisplayedLoggedProperty(displayName="Allegation Date")
	private Date allegationDate;

	@Column(name="ALLEGATION_SUMMARY")
	@Type(type="uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch =FetchType.EAGER)
	@DisplayedLoggedProperty(displayName="Allegation Summary")
	private String allegationSummary;

	@Column(name="ALLEGATION_OFFENCES")
	@Type(type="uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch =FetchType.EAGER)
	@DisplayedLoggedProperty(displayName="Allegation Offences")
	private String allegationOffences;
	
	@Column(name = "CREATED_TIME", updatable = false)
	@DisplayedLoggedProperty(displayName="Created Time")
	private Timestamp createdDate;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	@DisplayedLoggedProperty(displayName="Created By(Id)")
	private String createdStaffId;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn( name="INVESTIGATION_ID", nullable=false, updatable=false)
	@AuditJoinTable(name = "INEVESTIGATION_ACTION_PLAN_A")
	private Set<InvestigationActionPlan> investigationActionPlans = new HashSet<InvestigationActionPlan>();	
	
	
	public Date getAllegationDate() {
		return allegationDate;
	}

	public void setAllegationDate(Date allegationDate) {
		this.allegationDate = allegationDate;
	}

	public String getAllegationOffences() {
		return allegationOffences;
	}

	public void setAllegationOffences(String allegationOffences) {
		this.allegationOffences = allegationOffences;
	}

	public String getAllegationSummary() {
		return allegationSummary;
	}

	public void setAllegationSummary(String allegationSummary) {
		this.allegationSummary = allegationSummary;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Long getInvestigationId() {
		return investigationId;
	}

	public void setInvestigationId(Long investigationId) {
		this.investigationId = investigationId;
	}

	public Set<InvestigationActionPlan> getInvestigationActionPlans() {
		return investigationActionPlans;
	}

	public void setInvestigationActionPlans(
			Set<InvestigationActionPlan> investigationActionPlans) {
		this.investigationActionPlans = investigationActionPlans;
	}

}
