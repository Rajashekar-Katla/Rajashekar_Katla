package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "DISCIPLINARY_APPEAL_TBL")
@Audited
public class DisciplinaryAppeal implements Serializable {

	private static final long serialVersionUID = 79030155L;
	
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "DISCIPLINARY_APPEAL_ID_SQNC") })
	@Column(name = "APPEAL_ID")
	private Long appealId;
	
	@Column(name = "PARENT_APPEAL_ID")
	private Long parentAppealId;
	
	@Column(name = "SANCTION_ID")
	private Long sanctionId;
	
	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "SUBJECT_ID")
	private Long subjectId;
	
	@Column(name = "APPEAL_MAKER")
	@DisplayedLoggedProperty(displayName = "Appeal Maker")
	private String appealMaker;
	
	@Column(name = "SUBJECT_TYPE")
	@DisplayedLoggedProperty(displayName = "Subject Type")
	private String subjectType;
	
	@Column(name = "CREATED_STAFF_ID" , insertable=true, updatable=false)	
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME" , insertable=true, updatable=false)	
	private Date createdTime;
	
	@Column(name = "SANCTION_TYPE")
	@DisplayedLoggedProperty(displayName = "Sanction Type")
	private String sanctionType;
	
	@Column(name = "STATE")
	@DisplayedLoggedProperty(displayName = "State")
	private String state;

	@Column(name = "HR_CONTACT")
	@DisplayedLoggedProperty(displayName = "Human Resource Contact")
	private String humanResourceContact;
	
	@Column(name = "INVST_MGR_CONTACT")
	@DisplayedLoggedProperty(displayName = "Investigation Manager Contact")
	private String investigationManagerContact;
	
	@Column(name = "PROF_CONTACT")
	@DisplayedLoggedProperty(displayName = "Professional Contact")
	private String professionalContact;
	
	@Column(name = "HB_CONTACT")
	@DisplayedLoggedProperty(displayName = "Health Body Contact")
	private String healthBodyContact;
	
	@Column(name = "ORG_NAME")
	@DisplayedLoggedProperty(displayName = "Organisation Name")
	private String organisationName;
	
	@Column(name = "ORG_MAK_DEC_NAME")
	@DisplayedLoggedProperty(displayName = "Organisation Making Decision Name")
	private String organisationMakingDecisionName;

	@Column(name = "START_DATE")
	@DisplayedLoggedProperty(displayName = "Date of Appeal Application")
	private Date appealedDate;

	@Column(name = "OTHER_SUBJECT")
	@DisplayedLoggedProperty(displayName = "Name of original organisation against who the appeal is against")
	private String otherSubject;
	
	@Column(name = "APPELLANT_TYPE")
	@DisplayedLoggedProperty(displayName = "AppellantType")
	private String appellantType;
	
	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public String getHealthBodyContact() {
		return healthBodyContact;
	}

	public void setHealthBodyContact(String healthBodyContact) {
		this.healthBodyContact = healthBodyContact;
	}

	public String getHumanResourceContact() {
		return humanResourceContact;
	}

	public void setHumanResourceContact(String humanResourceContact) {
		this.humanResourceContact= humanResourceContact;
	}

	public String getInvestigationManagerContact() {
		return investigationManagerContact;
	}

	public void setInvestigationManagerContact(String investigationManagerContact) {
		this.investigationManagerContact = investigationManagerContact;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getProfessionalContact() {
		return professionalContact;
	}

	public void setProfessionalContact(String professionalContactId) {
		this.professionalContact = professionalContactId;
	}

	public String getSanctionType() {
		return sanctionType;
	}

	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

	public Date getAppealedDate() {
		return appealedDate;
	}

	public void setAppealedDate(Date appealedDate) {
		this.appealedDate = appealedDate;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}	
	
	public String getOrganisationMakingDecisionName() {
		return organisationMakingDecisionName;
	}

	public void setOrganisationMakingDecisionName(
			String organisationMakingDecisionName) {
		this.organisationMakingDecisionName = organisationMakingDecisionName;
	}

	public String getAppealMaker() {
		return appealMaker;
	}

	public void setAppealMaker(String appealMaker) {
		this.appealMaker = appealMaker;
	}
	
	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}
	
	public String getOtherSubject() {
		return otherSubject;
	}

	public void setOtherSubject(String otherSubject) {
		this.otherSubject = otherSubject;
	}
	
	public String getAppellantType() {
		return appellantType;
	}

	public void setAppellantType(String appellantType) {
		this.appellantType = appellantType;
	}

}
