package uk.nhs.cfsms.ecms.data.cps;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "CPS_REQUEST_DOC_TBL")
@Audited
public class CPSRequestDocTbl implements Serializable {

	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = @Parameter(name = "sequence", value = "CPS_DOC_ID_SEQ"))
	@Column(name = "CPS_DOC_REQ_ID")
	private Long id;

	@Column(name = "APPROVER_RESPONSE_TIME")
	private Timestamp approverResponseTime;

	@Column(name = "DOCUMENT_ID")
	private Long documentID;

	@Column(name = "REQUEST_STATUS")
	private String requestStatus;

	@Column(name = "DOCUMENT_TYPE")
	private String documentType;

	@Column(name = "APPROVER_MESSAGE")
	private String approverMessage;

	@Column(name = "APPROVER_STAFF_ID")
	private String approverStaffId;

	@Column(name = "APPROVER_STAFF_NAME")
	private String approverStaffName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Timestamp getApproverResponseTime() {
		return approverResponseTime;
	}

	public void setApproverResponseTime(Timestamp approverResponseTime) {
		this.approverResponseTime = approverResponseTime;
	}

	public Long getDocumentID() {
		return documentID;
	}

	public void setDocumentID(Long documentID) {
		this.documentID = documentID;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getApproverMessage() {
		return approverMessage;
	}

	public void setApproverMessage(String approverMessage) {
		this.approverMessage = approverMessage;
	}

	public String getApproverStaffId() {
		return approverStaffId;
	}

	public void setApproverStaffId(String approverStaffId) {
		this.approverStaffId = approverStaffId;
	}

	public String getApproverStaffName() {
		return approverStaffName;
	}

	public void setApproverStaffName(String approverStaffName) {
		this.approverStaffName = approverStaffName;
	}

}
