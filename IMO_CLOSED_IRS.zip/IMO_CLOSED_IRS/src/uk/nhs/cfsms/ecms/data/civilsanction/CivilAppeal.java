package uk.nhs.cfsms.ecms.data.civilsanction;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;

@Entity
@Table(name = "CIVIL_APPEAL_TBL")
@Audited
public class CivilAppeal implements Serializable {

	private static final long serialVersionUID = 800610072376L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CIVIL_APPEAL_ID_SQNC") })
	@Column(name = "APPEAL_ID")
	@DisplayedLoggedProperty(displayName = "Appeal ID")
	private Long appealId;

	@Column(name = "CASE_ID")
	@DisplayedLoggedProperty(displayName = "Case ID")
	private Long caseId;

	@Column(name = "PARENT_APPEAL_ID")
	@DisplayedLoggedProperty(displayName = "Parent Appeal ID")
	private Long parentAppealId;

	@ManyToOne
	@JoinColumn(name = "SANCTION_ID")
	@NotAudited
	private CivilSanction sanction;

	@Column(name = "APPEALED_OUTCOME_ID")
	private Long appealedId;

	@Column(name = "APPEALED_OUTCOME_TYPE")
	@DisplayedLoggedProperty(displayName = "Appealed Outcome Type")
	private String appealedOutcomeType;

	@Column(name = "OTHERSUBJECTS")
	@DisplayedLoggedProperty(displayName = "Subjects(Other)")
	private String otherSubjects;

	@OneToOne(mappedBy = "forAppeal")
	private CivilAppealOutcome outcome;

	@Column(name = "SUBJECT_ID")
	private Long subjectId;

	@Column(name = "SUBJECT_TYPE")
	@DisplayedLoggedProperty(displayName = "Subject Type")
	private String subjectType;

	@Column(name = "LEGAL_CONTACT")
	@DisplayedLoggedProperty(displayName = "Legal Contact")
	private String legalContact;

	@Column(name = "CREATED_STAFF_ID", insertable = true, updatable = false)
	@DisplayedLoggedProperty(displayName = "Created Staff Id")
	private String createdStaffId;

	@Column(name = "CREATED_TIME", insertable = true, updatable = false)
	@DisplayedLoggedProperty(displayName = "Created Time")
	private Date createdTime;

	@Column(name = "APPEAL_DATE")
	@DisplayedLoggedProperty(displayName = "Date Of Appeal")
	private Date dateOfAppeal;

	@Column(name = "STATE")
	@DisplayedLoggedProperty(displayName = "State")
	private String state;

	@Column(name = "COURT_ORG_DECISION")
	@DisplayedLoggedProperty(displayName = "Name of Court (Org. decision)")
	private String nameOfCourtMakingOriginalDecision;

	@Column(name = "DATE_OF_ORG_DECS")
	@DisplayedLoggedProperty(displayName = "Date of iriginal Decision")
	private Date dateOfOriginalDecision;

	@OneToMany(targetEntity = CourtAppearance.class)
	@JoinTable(name = "CVL_APPL_CRT_APPRNCE_TBL", joinColumns = @JoinColumn(name = "APPEAL_ID", referencedColumnName = "APPEAL_ID"), inverseJoinColumns = @JoinColumn(name = "APPEARANCE_ID", referencedColumnName = "APPEARANCE_ID"))
	@NotAudited
	private Set<CourtAppearance> courtAppearances;

	@Column(name = "DECISION_APPEAL_AGAINST")
	@DisplayedLoggedProperty(displayName = "Decision Appealed")
	private String decisionAppealAgainst;

	@Column(name = "APPELLANT")
	@DisplayedLoggedProperty(displayName = "Appellant")
	private String appellant;
	
	@Column(name = "APPELLANT_TYPE")
	@DisplayedLoggedProperty(displayName = "AppellantType")
	private String appellantType;

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long id) {
		this.appealId = id;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}

	public CivilSanction getSanction() {
		return sanction;
	}

	public void setSanction(CivilSanction sanction) {
		this.sanction = sanction;
	}

	public CivilAppealOutcome getOutcome() {
		return outcome;
	}

	public void setOutcome(CivilAppealOutcome outcome) {
		this.outcome = outcome;
	}

	public String getLegalContact() {
		return legalContact;
	}

	public void setLegalContact(String legalContact) {
		this.legalContact = legalContact;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getDateOfAppeal() {
		return dateOfAppeal;
	}

	public void setDateOfAppeal(Date dateOfAppeal) {
		this.dateOfAppeal = dateOfAppeal;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getNameOfCourtMakingOriginalDecision() {
		return nameOfCourtMakingOriginalDecision;
	}

	public void setNameOfCourtMakingOriginalDecision(
			String nameOfCourtMakingOriginalDecision) {
		this.nameOfCourtMakingOriginalDecision = nameOfCourtMakingOriginalDecision;
	}

	public Date getDateOfOriginalDecision() {
		return dateOfOriginalDecision;
	}

	public void setDateOfOriginalDecision(Date dateOfOriginalDecision) {
		this.dateOfOriginalDecision = dateOfOriginalDecision;
	}

	public String getDecisionAppealAgainst() {
		return decisionAppealAgainst;
	}

	public void setDecisionAppealAgainst(String decisionAppealAgainst) {
		this.decisionAppealAgainst = decisionAppealAgainst;
	}

	public String getAppellant() {
		return appellant;
	}

	public void setAppellant(String appellant) {
		this.appellant = appellant;
	}

	public Set<CourtAppearance> getCourtAppearances() {
		return courtAppearances;
	}

	public void setCourtAppearances(Set<CourtAppearance> courtAppearances) {
		this.courtAppearances = courtAppearances;
	}

	public String getOtherSubjects() {
		return otherSubjects;
	}

	public void setOtherSubjects(String otherSubjects) {
		this.otherSubjects = otherSubjects;
	}

	public Long getAppealedId() {
		return appealedId;
	}

	public void setAppealedId(Long appealedId) {
		this.appealedId = appealedId;
	}

	public String getAppealedOutcomeType() {
		return appealedOutcomeType;
	}

	public void setAppealedOutcomeType(String appealedOutcomeType) {
		this.appealedOutcomeType = appealedOutcomeType;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}
	
	public String getAppellantType() {
		return appellantType;
	}

	public void setAppellantType(String appellantType) {
		this.appellantType = appellantType;
	}

}
