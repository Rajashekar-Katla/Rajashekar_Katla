package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "FC_Information_SUBJECT_TBL")
/**
 * SubjectInformation has details of the subject.
 * 
 * @author schilukuri
 * 
 */
public class FcrolSubjectInformation implements Serializable {

	private static final long serialVersionUID = 1074653L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SUBJECT_INFO_ID_SQNC") })
	@Column(name = "SUBJECT_ID")
	private Long subjectId;

	@Column(name = "INFORMATION_ID", insertable=false, updatable=false)
	private Long information;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "SUBJECT_TYPE")
	private String subjectType;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "SUBJECT_PERSON_ID")
	private FcrolPerson subjectPerson;

	public static final String PERSON_TYPE = "SUBJECT";
	
	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getInformation() {
		return information;
	}

	public void setInformation(Long information) {
		this.information = information;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public FcrolPerson getSubjectPerson() {
		return subjectPerson;
	}

	public void setSubjectPerson(FcrolPerson subjectPerson) {
		this.subjectPerson = subjectPerson;
		if (subjectPerson != null)
			this.subjectPerson.setPersonType(PERSON_TYPE);
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}
	
	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		//Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}

}
