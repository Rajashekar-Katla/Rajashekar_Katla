package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity to map to view for helping with search 
 * actions
 * @author 
 *
 */
@Entity
@Table(name = "CASE_ACTION_SEARCH_VIEW")
public class CaseActionSearchObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6479571151021959476L;

	@Id
	@Column(name="ACTION_ID")
	private Long caseActionBookId;
	
	@Column(name="ACTION_NUMBER")
	private Long actionNumber;
	
	@Column(name="CASE_ID")
	private Long caseID;
	
	@Column(name="ALLOCATED_TO_STAFF_ID")
	private String allocatedTo;
	
	@Column(name="ALLOCATED_BY_STAFF_ID")
	private String allocatedBy;
	
	
	@Column(name="RECORDING_DATE", updatable = false)
	private Date dateRecorded;
	
	@Column(name="ALLOCATED_BY_FORNAME")
	private String allocatedByForename;
	
	@Column(name="ALLOCATED_BY_SURNAME")
	private String allocatedBySurname;
	
	@Column(name="ALLOCATED_TO_FORNAME")
	private String allocatedToForename;
	
	@Column(name="ALLOCATED_TO_SURNAME")
	private String allocatedToSurname;
		
	@Column(name="CASE_STATE")
	private String caseState;
	
	@Column(name="COMPLETION_DATE")
	private Date dateCompleted;
	
	@Column(name="DUE_DATE")
	private Date dueDate;
	
	@Column(name="ACTION_STATUS")
	private String actionStatus;
	
	@Column(name="CASE_NUMBER")
	private String caseNumber;
	
	@Column(name="OPERATION_NAME")
	private String caseOperationName;

	public Long getCaseActionBookId() {
		return caseActionBookId;
	}

	public void setCaseActionBookId(Long caseActionBookId) {
		this.caseActionBookId = caseActionBookId;
	}

	public Long getActionNumber() {
		return actionNumber;
	}

	public void setActionNumber(Long actionNumber) {
		this.actionNumber = actionNumber;
	}

	public Long getCaseID() {
		return caseID;
	}

	public void setCaseID(Long caseID) {
		this.caseID = caseID;
	}

	public Date getDateRecorded() {
		return dateRecorded;
	}

	public void setDateRecorded(Date dateRecorded) {
		this.dateRecorded = dateRecorded;
	}

	public String getAllocatedByForename() {
		return allocatedByForename;
	}

	public void setAllocatedByForename(String allocatedByForename) {
		this.allocatedByForename = allocatedByForename;
	}

	public String getAllocatedBySurname() {
		return allocatedBySurname;
	}

	public void setAllocatedBySurname(String allocatedBySurname) {
		this.allocatedBySurname = allocatedBySurname;
	}

	public String getAllocatedToForename() {
		return allocatedToForename;
	}

	public void setAllocatedToForename(String allocatedToForename) {
		this.allocatedToForename = allocatedToForename;
	}

	public String getAllocatedToSurname() {
		return allocatedToSurname;
	}

	public void setAllocatedToSurname(String allocatedToSurname) {
		this.allocatedToSurname = allocatedToSurname;
	}

	public String getCaseState() {
		return caseState;
	}

	public void setCaseState(String caseState) {
		this.caseState = caseState;
	}

	public Date getDateCompleted() {
		return dateCompleted;
	}

	public void setDateCompleted(Date dateCompleted) {
		this.dateCompleted = dateCompleted;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getActionStatus() {
		return actionStatus;
	}

	public void setActionStatus(String actionStatus) {
		this.actionStatus = actionStatus;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public String getCaseOperationName() {
		return caseOperationName;
	}

	public void setCaseOperationName(String caseOperationName) {
		this.caseOperationName = caseOperationName;
	}

	public String getAllocatedTo() {
		return allocatedTo;
	}

	public void setAllocatedTo(String allocatedTo) {
		this.allocatedTo = allocatedTo;
	}

	public String getAllocatedBy() {
		return allocatedBy;
	}

	public void setAllocatedBy(String allocatedBy) {
		this.allocatedBy = allocatedBy;
	}
	
	
}
