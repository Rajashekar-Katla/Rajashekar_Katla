package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
@Entity
@Table(name = "INFO_TRANS_TEAM_HIST_TBL")
public class InfoTransferHistory implements Serializable {

	private static final long serialVersionUID = 1305234L;
	
	@Id
	@Column(name = "TRANS_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "INFO_TRANSFER_ID_SQNC") })
	private Long transId;
	
	@Column(name = "INFO_ID")
	private Long infoId;
	
	@Column(name = "TEAM_CODE")
	private String teamCode;
	
	@Column(name = "CREATED_STAFF_ID")
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME ")
	private Date createdTime;
	
	@Column(name = "TRANSFER_TEAM_CODE")
	private String transferTeamCode;
	
	@Column(name = "TRANSFER_DATE")
	private Date transferDate;
	
	@Column(name = "TRANS_STAFF_ID")
	private String transferStaffId;
	
	@Column(name="state")
	private String state;
	
	@Column(name="APPROVER_STAFF_ID")
	private String approverStaffID;
	
	@Column(name="TRANSFER_COMMENTS")
	private String transferComments;
	
	@Column(name="APPROVAL_COMMENTS")
	private String approvalComments;

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getInfoId() {
		return infoId;
	}

	public void setInfoId(Long infoId) {
		this.infoId = infoId;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public Date getTransferDate() {
		return transferDate;
	}

	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}

	public String getTransferStaffId() {
		return transferStaffId;
	}

	public void setTransferStaffId(String transferStaffId) {
		this.transferStaffId = transferStaffId;
	}

	public String getTransferTeamCode() {
		return transferTeamCode;
	}

	public void setTransferTeamCode(String transferTeamCode) {
		this.transferTeamCode = transferTeamCode;
	}

	public Long getTransId() {
		return transId;
	}

	public void setTransId(Long transId) {
		this.transId = transId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getApproverStaffID() {
		return approverStaffID;
	}

	public void setApproverStaffID(String approverStaffID) {
		this.approverStaffID = approverStaffID;
	}

	public String getTransferComments() {
		return transferComments;
	}

	public void setTransferComments(String transferComments) {
		this.transferComments = transferComments;
	}

	public String getApprovalComments() {
		return approvalComments;
	}

	public void setApprovalComments(String approvalComments) {
		this.approvalComments = approvalComments;
	}
}