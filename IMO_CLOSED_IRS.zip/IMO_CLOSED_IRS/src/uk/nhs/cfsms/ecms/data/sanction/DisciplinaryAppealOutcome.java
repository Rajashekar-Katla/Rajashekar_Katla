package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

/**
 * Disciplinary Sanction Outcome
 *
 */
@Entity
@Table(name = "DISP_APPEAL_OUTCOME_TBL")
@Audited
public class DisciplinaryAppealOutcome implements Serializable {
	
	private static final long serialVersionUID = 85620906L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "DISC_APP_OUTCOME_ID_SQNC") })
	@Column(name = "OUTCOME_ID")
	private Long outcomeId;

	@Column(name = "APPEAL_ID")
	private Long appealId;

	@Column(name = "OUTCOME_DATE")
	@DisplayedLoggedProperty(displayName = "Outcome Date")
	private Date outcomeDate;
	
	@Column(name = "OUTCOME_STATUS")
	@DisplayedLoggedProperty(displayName = "Status")
	private String status;

	@Column(name = "CREATED_STAFF_ID", insertable = true, updatable = false)
	private String createdStaffId;

	@Column(name = "CREATED_TIME", insertable = true, updatable = false)
	private Date createdTime;

	//@Column(name = "SANCTIONS_IMPOSED")
	//private String sanctionsImposed;
	
	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "OUTCOME_ID", updatable=true, insertable=true)
	@Cascade({org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE})
	@AuditJoinTable(name ="DISP_SANC_OUT_APP_SANC_A")
	private List<OutcomeAppliedSanction> outcomeAppliedSanctions = new ArrayList<OutcomeAppliedSanction>();
	
	@Column(name = "OTHER_SANCTION_IMPOSED")
	@DisplayedLoggedProperty(displayName = "Other Sanction Imposed")
	private String otherSanctionImposed;
	
	@Column(name = "WAS_SANCTION_VARIED")
	@DisplayedLoggedProperty(displayName = "Was Sanction Varied")
	private String wasSanctionVaried;
	
	@Column(name = "SUM_DETAILS_OF_OUTCOME")
	@DisplayedLoggedProperty(displayName = "Summarised Details Of Outcome")
	private String summarisedDetailsOfOutcome;
	
	
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	} 

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long outcomeId) {
		this.outcomeId = outcomeId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOtherSanctionImposed() {
		return otherSanctionImposed;
	}

	public void setOtherSanctionImposed(String otherSanctionImposed) {
		this.otherSanctionImposed = otherSanctionImposed;
	}

	public List<OutcomeAppliedSanction> getOutcomeAppliedSanctions() {
		return outcomeAppliedSanctions;
	}

	public void setOutcomeAppliedSanctions(
			List<OutcomeAppliedSanction> outcomeAppliedSanctions) {
		this.outcomeAppliedSanctions = outcomeAppliedSanctions;
	}

	public String getWasSanctionVaried() {
		return wasSanctionVaried;
	}

	public void setWasSanctionVaried(String wasSanctionVaried) {
		this.wasSanctionVaried = wasSanctionVaried;
	}

	public String getSummarisedDetailsOfOutcome() {
		return summarisedDetailsOfOutcome;
	}

	public void setSummarisedDetailsOfOutcome(String summarisedDetailsOfOutcome) {
		this.summarisedDetailsOfOutcome = summarisedDetailsOfOutcome;
	}
}
