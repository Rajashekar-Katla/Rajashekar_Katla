package uk.nhs.cfsms.ecms.data.cps;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "CPS_REQUEST_TBL")
@Audited
public class CPSRequestTbl implements Serializable {

	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = @Parameter(name = "sequence", value = "CPS_REQ_ID_SQNC"))
	@Column(name = "CPS_REQ_ID")
	private Long cpsReqId;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "CPS_REQ_ID", nullable = false, updatable = false)
	@AuditJoinTable(name = "CPS_REQUEST_DOC_TBL_J_A")
	private List<CPSRequestDocTbl> cpsRequestDocTbls = new ArrayList<CPSRequestDocTbl>();

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "CREATED_STAFF_ID")
	private String createdStaffId;

	@Column(name = "CREATED_TIME")
	private Timestamp createdTime;

	@Column(name = "REQUESTER_MESSAGE")
	private String requesterMessage;

	@Column(name = "SUBMISSION_TYPE")
	private String submissionType;

	@Column(name = "CREATED_STAFF_NAME")
	private String createdStaffName;

	public Long getCpsReqId() {
		return cpsReqId;
	}

	public void setCpsReqId(Long cpsReqId) {
		this.cpsReqId = cpsReqId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	public String getRequesterMessage() {
		return requesterMessage;
	}

	public void setRequesterMessage(String requesterMessage) {
		this.requesterMessage = requesterMessage;
	}

	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public String getCreatedStaffName() {
		return createdStaffName;
	}

	public void setCreatedStaffName(String createdStaffName) {
		this.createdStaffName = createdStaffName;
	}

	public List<CPSRequestDocTbl> getCpsRequestDocTbls() {
		return cpsRequestDocTbls;
	}

	public void setCpsRequestDocTbls(List<CPSRequestDocTbl> cpsRequestDocTbls) {
		this.cpsRequestDocTbls = cpsRequestDocTbls;
	}

}
