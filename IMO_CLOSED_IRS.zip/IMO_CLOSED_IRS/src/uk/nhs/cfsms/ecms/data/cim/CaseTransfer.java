package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "CASE_TRANSFER_TBL")
@Audited
public class CaseTransfer implements Serializable{
	
	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = -1330102910322434783L;

	@Id
	@Column(name = "CASE_TRANSFER_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CASE_TRANSFER_ID_SQNC") })
	private Long caseTransferId;
	
	@OneToOne()
    @JoinColumn(name="case_id", updatable = false)
	private Case caseObject;
	
	@Column(name = "CREATED_STAFF_ID")
	@DisplayedLoggedProperty(displayName = "Created By Id")
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME" ,updatable = false)
	@DisplayedLoggedProperty(displayName = "Created Time")
	private Date createdTime;
	
	@Column(name = "TRANSFER_TIME" )
	@DisplayedLoggedProperty(displayName = "Transfer Time")
	private Date transferTime;
	
	@Column(name = "ACCEPTED_TIME")
	@DisplayedLoggedProperty(displayName = "Accepted Time")
	private Date acceptedTime;
	
	@Column(name = "REJECTED_TIME")
	@DisplayedLoggedProperty(displayName = "Rejected Time")
	private Date rejectedTime;
	
	@Column(name = "CANCELLED_TIME")
	@DisplayedLoggedProperty(displayName = "Cancelled Time")
	private Date cancelledTime;
	
	@Column(name = "STATE")
	@DisplayedLoggedProperty(displayName = "State")
	private String state;
	
	@Column(name = "RECIPIENT_LCFS")
	@DisplayedLoggedProperty(displayName = "State")
	private String receipentLcfs;
	
	@Column(name = "TRANSFER_TYPE")
	@DisplayedLoggedProperty(displayName = "Transfer Type")
	private String transferType;
	
	@Column(name = "RECIPIENT_TEAM")
	@DisplayedLoggedProperty(displayName = "Recipient Code")
	private String recipientTeamCode;
	
	@Column(name = "ORIGIN_TEAM")
	@DisplayedLoggedProperty(displayName = "Origin Team Code")
	private String originTeamCode;
	
	@Column(name = "TRANSFER_COMMENT")
	@DisplayedLoggedProperty(displayName = "Transfer Comment")
	private String transferComment;
	
	@Column(name = "REJECTED_COMMENT")
	@DisplayedLoggedProperty(displayName = "Rejected Comment")
	private String rejectedComment;
	
	@Column(name = "APPROVER_STAFF_ID")
	@DisplayedLoggedProperty(displayName = "CFS Approver Id")
	private String cfsTransferApproverStaffID;
	
	@Column(name = "APPROVAL_STATUS")
	@DisplayedLoggedProperty(displayName = "Transfer Approval Status")
	private String transferApprovalStatus;
	
	@Column(name = "APPROVAL_TIME")
	@DisplayedLoggedProperty(displayName = "Approval Time")
	private Date transferApprovalTime;
	
	@Column(name = "APPROVER_COMMENTS")
	@DisplayedLoggedProperty(displayName = "Transfer Approver Comments")
	private String transferApproverComments;

	public Date getAcceptedTime() {
		return acceptedTime;
	}

	public void setAcceptedTime(Date acceptedTime) {
		this.acceptedTime = acceptedTime;
	}

	public Date getCancelledTime() {
		return cancelledTime;
	}

	public void setCancelledTime(Date cancelledTime) {
		this.cancelledTime = cancelledTime;
	}

	public Case getcaseObject() {
		return caseObject;
	}

	public void setcaseObject(Case caseObject) {
		this.caseObject = caseObject;
	}

	public Long getCaseTransferId() {
		return caseTransferId;
	}

	public void setCaseTransferId(Long caseTransferId) {
		this.caseTransferId = caseTransferId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getReceipentLcfs() {
		return receipentLcfs;
	}

	public void setReceipentLcfs(String receipentLcfs) {
		this.receipentLcfs = receipentLcfs;
	}

	

	public Date getRejectedTime() {
		return rejectedTime;
	}

	public void setRejectedTime(Date rejectedTime) {
		this.rejectedTime = rejectedTime;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getTransferTime() {
		return transferTime;
	}

	public void setTransferTime(Date transferTime) {
		this.transferTime = transferTime;
	}

	public String getTransferType() {
		return transferType;
	}

	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	public Case getCaseObject() {
		return caseObject;
	}

	public void setCaseObject(Case caseObject) {
		this.caseObject = caseObject;
	}

	public String getRecipientTeamCode() {
		return recipientTeamCode;
	}

	public void setRecipientTeamCode(String recipientTeam) {
		this.recipientTeamCode = recipientTeam;
	}

	public String getTransferComment() {
		return transferComment;
	}

	public void setTransferComment(String transferComment) {
		this.transferComment = transferComment;
	}

	public String getRejectedComment() {
		return rejectedComment;
	}

	public void setRejectedComment(String rejectedComment) {
		this.rejectedComment = rejectedComment;
	}

	public String getOriginTeamCode() {
		return originTeamCode;
	}

	public void setOriginTeamCode(String originTeamCode) {
		this.originTeamCode = originTeamCode;
	}

	public String getCfsTransferApproverStaffID() {
		return cfsTransferApproverStaffID;
	}

	public void setCfsTransferApproverStaffID(String cfsTransferApproverStaffID) {
		this.cfsTransferApproverStaffID = cfsTransferApproverStaffID;
	}

	public String getTransferApprovalStatus() {
		return transferApprovalStatus;
	}

	public void setTransferApprovalStatus(String transferApprovalStatus) {
		this.transferApprovalStatus = transferApprovalStatus;
	}

	public Date getTransferApprovalTime() {
		return transferApprovalTime;
	}

	public void setTransferApprovalTime(Date transferApprovalTime) {
		this.transferApprovalTime = transferApprovalTime;
	}

	public String getTransferApproverComments() {
		return transferApproverComments;
	}

	public void setTransferApproverComments(String transferApproverComments) {
		this.transferApproverComments = transferApproverComments;
	}

}
