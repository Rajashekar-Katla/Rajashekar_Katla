package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
import uk.nhs.cfsms.ecms.data.common.Organisation;

/**
 * NHSSubjectInformation has details of the NHS ORGANISATION.
 * 
 * @author schilukuri
 * 
 */
@Entity
@Table(name = "INFORMATION_SUBJECT_NHS_TBL")
@Audited
public class NHSSubjectInformation implements Serializable {

	private static final long serialVersionUID = 2654991L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SUBJECT_NHS_INFO_ID_SQNC") })
	@Column(name = "SUBJECT_NHS_ID")
	private Long subjectNHSId;

	@Column(name = "INFORMATION_ID", insertable=false, updatable=false)
	private Long information;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "SUBJECT_TYPE")
	@DisplayedLoggedProperty(displayName = "Subject Type")
	private String subjectType;

	@OneToOne(optional=false)
	@JoinColumn(name = "ORG_CODE", unique=true, nullable=false, updatable=false)
	private Organisation organisation;

	@Column(name = "LOCATION")
	@DisplayedLoggedProperty(displayName = "Location")
	private String location;

	@Column(name = "PLACE")
	@DisplayedLoggedProperty(displayName = "Place")
	private String place;

	@Column(name = "ADDITIONAL_INFORMATION")
	@DisplayedLoggedProperty(displayName = "Additional Information")
	private String additionalInformation;
	
	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getInformation() {
		return information;
	}

	public void setInformation(Long information) {
		this.information = information;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	
	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public Long getSubjectNHSId() {
		return subjectNHSId;
	}

	public void setSubjectNHSId(Long subjectNHSId) {
		this.subjectNHSId = subjectNHSId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	public Organisation getOrganisation() {
		return organisation;
	}

	public void setOrganisation(Organisation organisation) {
		this.organisation = organisation;
	}
	
	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		//Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}

}
