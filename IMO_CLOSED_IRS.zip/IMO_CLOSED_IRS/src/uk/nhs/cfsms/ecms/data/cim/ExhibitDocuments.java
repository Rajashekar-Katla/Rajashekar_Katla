package uk.nhs.cfsms.ecms.data.cim;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "EXHIBIT_DOCUMENTS_TBL")
@Audited
public class ExhibitDocuments {

	@Transient
	protected final Log logger = LogFactory.getLog(getClass());

	@Id
	@Column(name = "ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "EXHIBIT_DOCUMENTS_SQNC ") })
	private Long id;

	@Column(name = "DOCUMENT")
	@Lob
	private byte[] document;

	@Column(name = "FILE_EXTENSION")
	private String fileExtension;

	@Column(name = "FILE_NAME")
	private String fileName;

	@Column(name = "EXHIBIT_TYPE")
	private String exhibitType;

	@Column(name = "UPLOADED_ON")
	private Date uploadedOn;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EXHIBIT_ID")
	private Exhibit exhibit;

	@Transient
	private String documentSize;

	public ExhibitDocuments() {
	}

	public ExhibitDocuments(final Long id, final String fileName,
			final String exhibitType, final String documentSize) {
		this.id = id;
		this.fileName = fileName;
		this.exhibitType = exhibitType;
		this.documentSize = documentSize;
	}

	public ExhibitDocuments(final Long id, final String fileName,
			final String exhibitType) {
		this.id = id;
		this.fileName = fileName;
		this.exhibitType = exhibitType;
	}

	/**
	 * @return the fileExtension
	 */
	public String getFileExtension() {
		return fileExtension;
	}

	/**
	 * @param fileExtension
	 *            the fileExtension to set
	 */
	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName
	 *            the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the exhibitType
	 */
	public String getExhibitType() {
		return exhibitType;
	}

	/**
	 * @param exhibitType
	 *            the exhibitType to set
	 */
	public void setExhibitType(String exhibitType) {
		this.exhibitType = exhibitType;
	}

	/**
	 * @return the document
	 */
	public byte[] getDocument() {
		return document;
	}

	/**
	 * @param document
	 *            the document to set
	 */
	public void setDocument(byte[] document) {
		this.document = document;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the exhibit
	 */
	public Exhibit getExhibit() {
		return exhibit;
	}

	/**
	 * @param exhibit
	 *            the exhibit to set
	 */
	public void setExhibit(Exhibit exhibit) {
		this.exhibit = exhibit;
	}

	/**
	 * @return the uploadedOn
	 */
	public Date getUploadedOn() {
		return uploadedOn;
	}

	/**
	 * @param uploadedOn
	 *            the uploadedOn to set
	 */
	public void setUploadedOn(Date uploadedOn) {
		this.uploadedOn = uploadedOn;
	}

	/**
	 * @return the documentSize
	 */
	public String getDocumentSize() {
		return documentSize;
	}

	/**
	 * @param documentSize
	 *            the documentSize to set
	 */
	public void setDocumentSize(String documentSize) {
		this.documentSize = documentSize;
	}

}
