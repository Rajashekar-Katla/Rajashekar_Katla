package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "APPLIED_SANCTION_TBL")
@Audited
@AuditTable(value="OUTCOME_APPLIED_SANCTION_TBL_A")
public class OutcomeAppliedSanction implements Serializable {

	private static final long serialVersionUID = 60979123L;
	
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "APPLIED_SANCTION_ID_SQNC") })
	@Column(name = "APPLIED_SANCTION_ID")
	private Long appliedSanctionId;
	
	//@Column(name = "OUTCOME_ID", nullable=false,insertable=false, updatable=false)
	@Column(name = "OUTCOME_ID")
	private Long outcomeId;
	
	@Column(name = "SANCTION_TYPE")
	@DisplayedLoggedProperty(displayName = "Sanction Type")
	private String sanctionType;
	
	@Column(name = "APPLIED_SANCTION")
	@DisplayedLoggedProperty(displayName = "Applied Sanction")
	private String appliedSanction;	
	
	@Column(name = "OTHER_SANCTION")
	@DisplayedLoggedProperty(displayName = "Other Sanction")
	private String otherSanction;

	public String getAppliedSanction() {
		return appliedSanction;
	}

	public void setAppliedSanction(String appliedSanction) {
		this.appliedSanction = appliedSanction;
	}

	public Long getAppliedSanctionId() {
		return appliedSanctionId;
	}

	public void setAppliedSanctionId(Long appliedSanctionId) {
		this.appliedSanctionId = appliedSanctionId;
	}

	public String getOtherSanction() {
		return otherSanction;
	}

	public void setOtherSanction(String otherSanction) {
		this.otherSanction = otherSanction;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long outcomeId) {
		this.outcomeId = outcomeId;
	}

	public String getSanctionType() {
		return sanctionType;
	}

	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}	
}
