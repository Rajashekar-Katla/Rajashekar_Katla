package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "CAUTION_SANCTION_TBL")
@Audited
public class OutcomeOrderSanction implements Serializable {

	private static final long serialVersionUID = 93740201L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CAUTION_SANCTION_ID_SQNC") })
	@Column(name = "CAUTION_SANCTION_ID")
	private Long cautionSanctionId;

	@Column(name = "OUTCOME_ID", nullable = false, insertable = false, updatable = false)
	private Long outcomeId;

	@Column(name = "SANCTION_CAUTION")
	@DisplayedLoggedProperty(displayName = "Sanction Condition")
	private String sanctionCondition;

	@Column(name = "SANCTION_ORDER")
	@DisplayedLoggedProperty(displayName = "Sanction Order")
	private String sanctionOrder;

	public Long getCautionSanctionId() {
		return cautionSanctionId;
	}

	public void setCautionSanctionId(Long cautionSanctionId) {
		this.cautionSanctionId = cautionSanctionId;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long outcomeId) {
		this.outcomeId = outcomeId;
	}

	public String getSanctionCondition() {
		return sanctionCondition;
	}

	public void setSanctionCondition(String sanctionCondition) {
		this.sanctionCondition = sanctionCondition;
	}

	public String getSanctionOrder() {
		return sanctionOrder;
	}

	public void setSanctionOrder(String sanctionOrder) {
		this.sanctionOrder = sanctionOrder;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}