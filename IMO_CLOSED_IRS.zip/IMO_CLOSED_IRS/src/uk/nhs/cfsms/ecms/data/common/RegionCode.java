package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name="REGIONS_TBL")
/**
 * RegionCode contain region code detials.
 * 
 * @author schilukuri
 * 
 */
public class RegionCode implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4561234L;

	@Id
	@Column(name="REGION_CODE")
	private String regionCode;
	
	@Column(name="REGION")
	private String region;

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	
}
