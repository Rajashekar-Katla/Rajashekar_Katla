package uk.nhs.cfsms.ecms.data.infoGath;



import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ALL_FC_INFORMATION_VIEW")
/**
 * InformationView has details to view information.
 * 
 * @author schilukuri
 * 
 */
public class FcrolInformationView implements Serializable {

	private static final long serialVersionUID = 1305234L;

	@Id
	@Column(name = "INFORMATION_ID")
	private Long informationId;

	@Column(name = "TYPE")
	private String type;

	@Column(name = "COST")
	private BigDecimal cost;

	@Column(name = "ORG_NAME")
	private String orgName;

	@Column(name = "ORG_CODE")
	private String orgCode;
	
	@Column(name = "CASE_ID")
	private Long caseId;
		
	@Column(name = "CREATED_TIME")
	private Timestamp createdDate;

	@Column(name = "CREATED_STAFF_ID")
	private String createdStaffId;

	@Column(name = "SUBJECT_NAME")
	private String subjectName;

	@Column(name = "REGION_OVERRIDE")
	private String regionOverride;
	
	@Column(name = "TEAM_CODE")
	private String teamCode;
	
	@Column(name = "STATE")
	private String state;
	
	@Column(name = "data_Cleansed_Flag")
	private String dataCleansedFlag;
	
	
	
	public BigDecimal getCost() {
		return cost == null ? cost : cost.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getRegionOverride() {
		return regionOverride;
	}

	public void setRegionOverride(String regionOverride) {
		this.regionOverride = regionOverride;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDataCleanFlag() {
		return dataCleansedFlag;
	}

	public void setDataCleanFlag(String dataCleanFlag) {
		this.dataCleansedFlag = dataCleanFlag;
	}

	

}
