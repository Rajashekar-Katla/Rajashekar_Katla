package uk.nhs.cfsms.ecms.data.civilsanction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "CIVIL_SANCTION_VIEW")

public class CivilSanctionView implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "CIVIL_SANCTION_ID")
	private Long civilSanctionId;
	
	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "SUBJECT_ID")
	private Long subjectId;

	@Column(name = "SUBJECT_TYPE")
	private String subjectType;
	
	@Column(name = "LEGAL_CONTACT")
	private String legalContact;
	
	@Column(name = "CREATED_STAFF_ID" , insertable=true, updatable=false)	
	private String createdStaffId;
	
	@Column(name = "CREATED_TIME" , insertable=true, updatable=false)	
	private Date createdTime;
	
	@Column(name = "CLAIM_AMOUNT")		
	private BigDecimal claimAmount;
	
	@Column(name = "CLAIM_SUBMIT_DATE")		
	private Date claimSubmitDate;
	
	@Column(name = "STATE")		
	private String state;
	
	@Column(name = "NHS_SUBJECT_NAME")		
	private String nhsSubjectName;
	
	@Column(name = "NON_NHS_SUBJECT_NAME")		
	private String nonNhsSubjectName;

	@Column(name = "PERSON_SUBJECT_NAME")
	private String personSubjectName;
	
	

	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the civilSanctionId.
	 */
	public Long getCivilSanctionId() {
		return civilSanctionId;
	}

	/**
	 * @param civilSanctionId The civilSanctionId to set.
	 */
	public void setCivilSanctionId(Long civilSanctionId) {
		this.civilSanctionId = civilSanctionId;
	}

	/**
	 * @return Returns the claimAmount.
	 */
	public BigDecimal getClaimAmount() {
		return claimAmount == null ? claimAmount : claimAmount.setScale(2,
				BigDecimal.ROUND_DOWN);
	}

	/**
	 * @param claimAmount The claimAmount to set.
	 */
	public void setClaimAmount(BigDecimal claimAmount) {
		this.claimAmount = claimAmount;
	}

	/**
	 * @return Returns the claimSubmitDate.
	 */
	public Date getClaimSubmitDate() {
		return claimSubmitDate;
	}

	/**
	 * @param claimSubmitDate The claimSubmitDate to set.
	 */
	public void setClaimSubmitDate(Date claimSubmitDate) {
		this.claimSubmitDate = claimSubmitDate;
	}

	/**
	 * @return Returns the createdStaffId.
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	/**
	 * @param createdStaffId The createdStaffId to set.
	 */
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	/**
	 * @return Returns the createdTime.
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime The createdTime to set.
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return Returns the legalContact.
	 */
	public String getLegalContact() {
		return legalContact;
	}

	/**
	 * @param legalContact The legalContact to set.
	 */
	public void setLegalContact(String legalContact) {
		this.legalContact = legalContact;
	}


	/**
	 * @return Returns the nhsSubjectName.
	 */
	public String getNhsSubjectName() {
		return nhsSubjectName;
	}

	/**
	 * @param nhsSubjectName The nhsSubjectName to set.
	 */
	public void setNhsSubjectName(String nhsSubjectName) {
		this.nhsSubjectName = nhsSubjectName;
	}

	/**
	 * @return Returns the nonNhsSubjectName.
	 */
	public String getNonNhsSubjectName() {
		return nonNhsSubjectName;
	}

	/**
	 * @param nonNhsSubjectName The nonNhsSubjectName to set.
	 */
	public void setNonNhsSubjectName(String nonNhsSubjectName) {
		this.nonNhsSubjectName = nonNhsSubjectName;
	}

	/**
	 * @return Returns the personSubjectName.
	 */
	public String getPersonSubjectName() {
		return personSubjectName;
	}

	/**
	 * @param personSubjectName The personSubjectName to set.
	 */
	public void setPersonSubjectName(String personSubjectName) {
		this.personSubjectName = personSubjectName;
	}

	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return Returns the subjectId.
	 */
	public Long getSubjectId() {
		return subjectId;
	}

	/**
	 * @param subjectId The subjectId to set.
	 */
	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	/**
	 * @return Returns the subjectType.
	 */
	public String getSubjectType() {
		return subjectType;
	}

	/**
	 * @param subjectType The subjectType to set.
	 */
	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}
	

	
	
}
