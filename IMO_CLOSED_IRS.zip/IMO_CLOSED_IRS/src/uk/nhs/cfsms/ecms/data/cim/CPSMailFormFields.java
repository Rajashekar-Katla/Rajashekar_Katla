package uk.nhs.cfsms.ecms.data.cim;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CPS_MAIL_FORM_FIELDS_TBL")
public class CPSMailFormFields {

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "INVESTIGATION_STAGE")
	private String investigationStage;

	@Column(name = "ACTION")
	private String action;

	@Column(name = "SUBJECT_HEADER")
	private String subjectHeader;

	@Column(name = "REQUIRED_INFO")
	private String requiredInfo;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getInvestigationStage() {
		return investigationStage;
	}

	public void setInvestigationStage(String investigationStage) {
		this.investigationStage = investigationStage;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getSubjectHeader() {
		return subjectHeader;
	}

	public void setSubjectHeader(String subjectHeader) {
		this.subjectHeader = subjectHeader;
	}

	public String getRequiredInfo() {
		return requiredInfo;
	}

	public void setRequiredInfo(String requiredInfo) {
		this.requiredInfo = requiredInfo;
	}

}
