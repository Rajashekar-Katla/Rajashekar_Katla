package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "INDEXED_INFORMATION_SEARCH_TBL")
@NamedNativeQuery(name = "getIndexedInformationSearchResults", query = "select * from INDEXED_CASE_SEARCH_TBL WHERE CONTAINS(description_values , :vKeywords, 1) > 0", resultClass=uk.nhs.cfsms.ecms.data.infoGath.InformationIndexSearch.class)
public class InformationIndexSearch implements Serializable {
	private static final long serialVersionUID = 309970404L;

	@Id
	@Column(name = "SEARCH_ID")
	private Long searchId;

	@Column(name = "INFORMATION_ID")
	private Long informationId;
	
	@Column(name = "DESCRIPTION_VALUES")
	@Type(type = "uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	private String description;

	@Column(name = "ORIGIN_TABLE")
	private String originTable;

	@Column(name = "ORIGIN_ID")
	private Long originId;

	@Column(name = "CREATED_DATE")
	private Date createdTime;
	
	@Column(name = "IS_DELETED")
	private String deleted;
	
	private Integer keywordCount;
	
	public Long getSearchId() {
		return searchId;
	}

	public void setSearchId(Long searchId) {
		this.searchId = searchId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getOriginId() {
		return originId;
	}

	public void setOriginId(Long originId) {
		this.originId = originId;
	}

	public String getOriginTable() {
		return originTable;
	}

	public void setOriginTable(String originTable) {
		this.originTable = originTable;
	}

	public String getDeleted() {
		return deleted;
	}

	public void setDeleted(String deleted) {
		this.deleted = deleted;
	}

	public Integer getKeywordCount() {
		return keywordCount;
	}

	public void setKeywordCount(Integer keywordCount) {
		this.keywordCount = keywordCount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
