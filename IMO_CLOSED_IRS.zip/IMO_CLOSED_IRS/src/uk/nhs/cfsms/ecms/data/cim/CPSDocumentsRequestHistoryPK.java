package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CPSDocumentsRequestHistoryPK implements Serializable {

	private static final long serialVersionUID = 3686950547855931594L;

	@Column(name = "CPS_DOC_REQ_ID")
	private long cpsDocReqID;

	@Column(name = "REV")
	private long rev;

	public long getCpsDocReqID() {
		return cpsDocReqID;
	}

	public void setCpsDocReqID(long cpsDocReqID) {
		this.cpsDocReqID = cpsDocReqID;
	}

	public long getRev() {
		return rev;
	}

	public void setRev(long rev) {
		this.rev = rev;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (cpsDocReqID ^ (cpsDocReqID >>> 32));
		result = prime * result + (int) (rev ^ (rev >>> 32));
		return result;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null || this.getClass() != obj.getClass()) {
			return false;
		}

		CPSDocumentsRequestHistoryPK other = (CPSDocumentsRequestHistoryPK) obj;

		return this.cpsDocReqID == other.cpsDocReqID && this.rev == other.rev;

	}
}
