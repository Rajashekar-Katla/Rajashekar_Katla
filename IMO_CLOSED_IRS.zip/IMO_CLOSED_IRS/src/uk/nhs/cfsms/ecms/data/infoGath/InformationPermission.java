package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "INFORMATION_PERMISSION_TBL")
/**
 * InformationPermission has details of the information permission details.
 * 
 * @author schilukuri
 * 
 */
public class InformationPermission implements Serializable {

	private static final long serialVersionUID = 30089674L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "INFO_PERMISSION_ID_SQNC") })
	@Column(name = "PERMISSION_ID")
	private Long permissionId;

	@Column(name = "INFORMATION_ID")
	private Long informationId;

	@Column(name = "PERMISSION_TYPE")
	private String permissionType;

	@Column(name = "PERMISSION")
	private String permissionValue;

	@Column(name = "CREATED_TIME", updatable = false)
	private Date createdDate;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;

	@Column(name = "END_DATE")
	private Date endDate;

	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public Long getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(Long permissionId) {
		this.permissionId = permissionId;
	}

	public String getPermissionType() {
		return permissionType;
	}

	public void setPermissionType(String permissionType) {
		this.permissionType = permissionType;
	}

	public String getPermissionValue() {
		return permissionValue;
	}

	public void setPermissionValue(String permissionValue) {
		this.permissionValue = permissionValue;
	}

	
}
