package uk.nhs.cfsms.ecms.data.fpureport;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
@Entity
@Table(name = "FPU_REPORT_TBL")
@Audited
public class FpuReport implements Serializable{
	
	@Id
	@Column(name = "FPU_REPORT_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "FPU_REPORT_ID_SQNC") })
	private Long fpuReportId;
	
	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "INFORMATION_ID")
	private Long informationId;
	
		
	@Column(name = "system_weakness_identified")
	@DisplayedLoggedProperty(displayName = "System weakness(es) identified")
	private String systemWeaknessIdentified ;
	
	@Column(name = "health_body_type")
	@DisplayedLoggedProperty(displayName = "Type of health body")
	private String healthBodyType;
	
	@Column(name = "other_risk_area")
	@DisplayedLoggedProperty(displayName = "Other Risk Area")
	private String otherriskArea;
	
	@Column(name = "system_weakness_details")
	@DisplayedLoggedProperty(displayName = "System Weakness Details")
	private String systemWeaknessDetails;
	
	@Column(name = "fraud_proven")
	@DisplayedLoggedProperty(displayName = "Fraud Proven")
	private String fraudProven;
	
	@Column(name = "other_fraud_type")
	@DisplayedLoggedProperty(displayName = "Other Fraud Type")
	private String otherFraudType;
	
	
	@Column(name = "other_system_weakness")
	@DisplayedLoggedProperty(displayName = "Other System Weakness")
	private String otherSystemWeakness;
	
	@Column(name = "losses")
	@DisplayedLoggedProperty(displayName = "Losses Identified")
	private String lossesIdentified;
	
	@Column(name = "local_action_taken")
	@DisplayedLoggedProperty(displayName = "Local Action Taken")
	private String localActionTaken;
	
	@Column(name = "other_action_taken")
	@DisplayedLoggedProperty(displayName = "Other Action Taken")
	private String otherActionTaken;
	
	@Column(name = "action_details")
	@DisplayedLoggedProperty(displayName = "Action Details")
	private String actionDetails;
	
	@Column(name = "suggestions")
	@DisplayedLoggedProperty(displayName = "Suggestions")
	private String suggestions;
	
	
	@Column(name = "risk_Assmnt_rating")
	@DisplayedLoggedProperty(displayName = "Risk Assessment Rating")
	private String riskAssesmentRating;
	
	@Column(name = "other_health_body_type")
	@DisplayedLoggedProperty(displayName = "Other Health Body Type")
	private String otherHealthBodyType;
	
	
	@Column(name = "CREATED_TIME")
	private Date createdTime;
	
	@Column(name = "CREATED_STAFF_ID")
	private String createdStaffId;
		
	
	@OneToMany(cascade=CascadeType.ALL,  fetch=FetchType.EAGER)
    @JoinColumn(name="FPU_REPORT_ID")
	@AuditJoinTable(name="FPU_FPU_SUB_REPORT_TYPE_A")
   	private List<FpuReportSubType> reportSubTypes;
	
	// Phase-5 April-2011 changes
	@Column(name = "LOSS_IDENTIFIED")
	@DisplayedLoggedProperty(displayName = "Loss Identified")
	private String lossIdentified;
	
	@Column(name = "PREVENTIVE_ACTION")
	@DisplayedLoggedProperty(displayName = "Rec. Prevention Action")
	private String recPreventiveAction;

	public String getHealthBodyType() {
		return healthBodyType;
	}

	public void setHealthBodyType(String healthBodyType) {
		this.healthBodyType = healthBodyType;
	}

	public String getLocalActionTaken() {
		return localActionTaken;
	}

	public void setLocalActionTaken(String localActionTaken) {
		this.localActionTaken = localActionTaken;
	}

	public String getOtherriskArea() {
		return otherriskArea;
	}

	public void setOtherriskArea(String otherriskArea) {
		this.otherriskArea = otherriskArea;
	}

	public String getRiskAssesmentRating() {
		return riskAssesmentRating;
	}

	public void setRiskAssesmentRating(String riskAssesmentRating) {
		this.riskAssesmentRating = riskAssesmentRating;
	}

	public String getSystemWeaknessDetails() {
		return systemWeaknessDetails;
	}

	public void setSystemWeaknessDetails(String systemWeaknessDetails) {
		this.systemWeaknessDetails = systemWeaknessDetails;
	}

	public String getSystemWeaknessIdentified() {
		return systemWeaknessIdentified;
	}

	public void setSystemWeaknessIdentified(String systemWeaknessIdentified) {
		this.systemWeaknessIdentified = systemWeaknessIdentified;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}



	public Long getFpuReportId() {
		return fpuReportId;
	}

	public void setFpuReportId(Long fpuReportId) {
		this.fpuReportId = fpuReportId;
	}

	

	public String getOtherActionTaken() {
		return otherActionTaken;
	}

	public void setOtherActionTaken(String otherActionTaken) {
		this.otherActionTaken = otherActionTaken;
	}

	

	public String getOtherFraudType() {
		return otherFraudType;
	}

	public void setOtherFraudType(String otherFraudType) {
		this.otherFraudType = otherFraudType;
	}

	
	public String getLossesIdentified() {
		return lossesIdentified;
	}

	public void setLossesIdentified(String lossesIdentified) {
		this.lossesIdentified = lossesIdentified;
	}

	public String getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}

	public String getActionDetails() {
		return actionDetails;
	}

	public void setActionDetails(String actionDetails) {
		this.actionDetails = actionDetails;
	}

	public String getFraudProven() {
		return fraudProven;
	}

	public void setFraudProven(String fraudProven) {
		this.fraudProven = fraudProven;
	}

	

	public List<FpuReportSubType> getReportSubTypes() {
		return reportSubTypes;
	}

	public void setReportSubTypes(List<FpuReportSubType> reportSubTypes) {
		this.reportSubTypes = reportSubTypes;
	}

	public String getOtherHealthBodyType() {
		return otherHealthBodyType;
	}

	public void setOtherHealthBodyType(String otherHealthBodyType) {
		this.otherHealthBodyType = otherHealthBodyType;
	}

	public String getOtherSystemWeakness() {
		return otherSystemWeakness;
	}

	public void setOtherSystemWeakness(String otherSystemWeakness) {
		this.otherSystemWeakness = otherSystemWeakness;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getLossIdentified() {
		return lossIdentified;
	}

	public void setLossIdentified(String lossIdentified) {
		this.lossIdentified = lossIdentified;
	}

	public String getRecPreventiveAction() {
		return recPreventiveAction;
	}

	public void setRecPreventiveAction(String recPreventiveAction) {
		this.recPreventiveAction = recPreventiveAction;
	}
	
}
