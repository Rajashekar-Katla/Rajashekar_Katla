package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="STAFF_DIRECTORATE_TBL")
public class UserDirectorate implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="STAFF_DIRECTORATE_ID")
	private Long staffDirectorateId;
	
	@Column(name="STAFF_ID")
	private String staffId;

	@Column(name="DIRECTORATE")
	private String directorate;
	
	@Column(name="DIRECTORATE_LEVEL")
	private String directorateLevel;

	/**
	 * @return Returns the directorate.
	 */
	public String getDirectorate() {
		return directorate;
	}

	/**
	 * @param directorate The directorate to set.
	 */
	public void setDirectorate(String directorate) {
		this.directorate = directorate;
	}

	/**
	 * @return Returns the directorateLevel.
	 */
	public String getDirectorateLevel() {
		return directorateLevel;
	}

	/**
	 * @param directorateLevel The directorateLevel to set.
	 */
	public void setDirectorateLevel(String directorateLevel) {
		this.directorateLevel = directorateLevel;
	}

	/**
	 * @return Returns the staffDirectorateId.
	 */
	public Long getStaffDirectorateId() {
		return staffDirectorateId;
	}

	/**
	 * @param staffDirectorateId The staffDirectorateId to set.
	 */
	public void setStaffDirectorateId(Long staffDirectorateId) {
		this.staffDirectorateId = staffDirectorateId;
	}

	/**
	 * @return Returns the staffId.
	 */
	public String getStaffId() {
		return staffId;
	}

	/**
	 * @param staffId The staffId to set.
	 */
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	
	
	
}
