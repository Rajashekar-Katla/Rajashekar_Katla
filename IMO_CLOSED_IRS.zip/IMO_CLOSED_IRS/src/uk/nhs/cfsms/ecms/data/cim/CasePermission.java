package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name="CASE_PERM_TBL")
@Audited
@DisplayedLoggedProperty(detailsMethod = "getAssignee")
public class CasePermission implements Serializable {
	
	@Transient
	private static final long serialVersionUID = 4938871235L;
	
	@Id
	@Column(name="CASE_PERM_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CASE_PERM_ID_SQNC") })
	private Long casePermissionId;	
	
	@Column(name="CASE_ID")
	private Long caseId;

	
	@Column(name="PERM_TYPE")
	@DisplayedLoggedProperty(displayName = "Permission Type")
	private String permissionType;
	
	@Column(name="VALUE")
	@DisplayedLoggedProperty(displayName = "Value")
	private String value;
	
	
	@Column(name="CREATED_STAFF_ID")
	private String createdStaffId;
	
	@Column(name="STATUS")
	@DisplayedLoggedProperty(displayName = "Status")
	private String status;
	
	@Column(name="CREATED_TIME")
	private Date createdTime;
	
	@Column(name="ACCESS_FLAG")
	@DisplayedLoggedProperty(displayName = "Access Flag")
	private String accessFlag;

	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	

	/**
	 * @return Returns the permissionType.
	 */
	public String getPermissionType() {
		return permissionType;
	}

	/**
	 * @param permissionType The permissionType to set.
	 */
	public void setPermissionType(String permissionType) {
		this.permissionType = permissionType;
	}

	/**
	 * @return Returns the value.
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value The value to set.
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return Returns the casePermissionId.
	 */
	public Long getCasePermissionId() {
		return casePermissionId;
	}

	/**
	 * @param casePermissionId The casePermissionId to set.
	 */
	public void setCasePermissionId(Long casePermissionId) {
		this.casePermissionId = casePermissionId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAccessFlag() {
		return accessFlag;
	}

	public void setAccessFlag(String accessFlag) {
		this.accessFlag = accessFlag;
	}
	
	public String getAssignee(){
		return StringUtils.isNotBlank(value) ? "Assignee: " + value : StringUtils.EMPTY;
	}
	
}
