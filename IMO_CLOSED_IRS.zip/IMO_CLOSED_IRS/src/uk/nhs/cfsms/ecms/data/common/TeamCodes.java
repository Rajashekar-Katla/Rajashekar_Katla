package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@Entity
@Table(name="TEAM_CODES_TBL")
public class TeamCodes implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6668459003229855912L;

	@Transient
	protected final Log logger = LogFactory.getLog(getClass());
	
	@Id
	@Column(name="team_code")
	private String teamCode;
	
	@Column(name="ORG_CODE")
	private String orgCode;
	
	@Column(name="REGION_CODE")
	private String regionCode;
	
	@Column(name="DIRECTORATE")
	private String directorate;
	
	@Column(name="TEAM_TYPE")
	private String teamType;
	
	@Column(name="TEAM_NAME")
	private String teamName;
	
	@Column(name="status")
	private String status;
	/**
	 * New_Team_Code came to existence, because of restructuring (31MAR2011). 
	 * Means not to delete old teams and to organise old teams into new teams.
	 */
	@Column(name="new_team_code")
	private String newTeamCode;
	

	public String getDirectorate() {
		return directorate;
	}

	public void setDirectorate(String directorate) {
		this.directorate = directorate;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getTeamType() {
		return teamType;
	}

	public void setTeamType(String teamType) {
		this.teamType = teamType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	

	public String getNewTeamCode() {
		return newTeamCode;
	}

	public void setNewTeamCode(String newTeamCode) {
		this.newTeamCode = newTeamCode;
	}

}
