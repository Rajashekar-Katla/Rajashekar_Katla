package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "EXPECTED_COURT_COST_TBL")
@Audited
public class ExpectedCourtCost implements Serializable {

	private static final long serialVersionUID = 4939871235L;

	@Id
	@Column(name = "EXPCT_COURT_COST_ID")
	private Long expctCourtCostId;
	
	@Column(name = "DESCRIPTION")
	@DisplayedLoggedProperty(displayName = "Description")
	private String  description;
	
	@Column(name = "COST")
	@DisplayedLoggedProperty(displayName = "Cost")
	private BigDecimal cost;

	@Transient
	private boolean selected;
	
	@Transient
	private String indexId;

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public BigDecimal getCost() {
		return cost == null ? cost : cost.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getExpctCourtCostId() {
		return expctCourtCostId;
	}

	public void setExpctCourtCostId(Long expctCourtCostId) {
		this.expctCourtCostId = expctCourtCostId;
	}

	public String getIndexId() {
		if(expctCourtCostId != null)
		return expctCourtCostId.toString() ;
		else
			return "";
	}

	public void setIndexId(String indexId) {
		this.indexId = indexId;
	}
	
	
	
	}
