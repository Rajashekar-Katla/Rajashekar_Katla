package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "CASE_CLOSURE_TBL")
@Audited
public class CaseClosure implements Serializable {

	private static final long serialVersionUID = 4672996674215118851L;

	@Id
	@Column(name = "CASE_CLOSURE_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CASE_CLOSURE_ID_SQNC") })
	private Long caseClosureId;

	@Column(name = "DESCRIPTION")
	@Type(type = "uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch = FetchType.EAGER)
	@DisplayedLoggedProperty(displayName = "Description")
	private String description;

	@Column(name = "CLOSURE_CATEGORY")
	@DisplayedLoggedProperty(displayName = "Closure Category")
	private String closureCategory;

	@Column(name = "COMMENTS")
	@Type(type = "uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch = FetchType.EAGER)
	@DisplayedLoggedProperty(displayName = "Comments")
	private String comments;

	@Column(name = "SYSTEM_WEAKNESS")
	private String systemWeakness;

	@Column(name = "CLOSURE_REPORT")
	@Lob
	private byte[] closureReport;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;

	@Column(name = "CLOSURE_DATE")
	@DisplayedLoggedProperty(displayName = "Closure Date")
	private Date closureDate;

	@Column(name = "CREATED_DATE", updatable = false)
	private Date createdDate;

	@Column(name = "DESTRUCTION_DATE")
	@DisplayedLoggedProperty(displayName = "Destruction Date")
	private Date destructionDate;

	@Column(name = "CASE_ID", updatable = false)
	private Long caseId;

	@Column(name = "RECOVERED_AMOUNT")
	@DisplayedLoggedProperty(displayName = "Recovered Amount")
	private BigDecimal recoveredAmount;

	@Column(name = "FRAUD_AMOUNT")
	@DisplayedLoggedProperty(displayName = "Fraud Amount")
	private BigDecimal fraudAmount;

	@Column(name = "FRAUD_AMOUNT_LOSS")
	@DisplayedLoggedProperty(displayName = "Fraud Amount Loss")
	private BigDecimal fraudAmountLoss;

	@Column(name = "NON_FRAUD_AMOUNT_LOSS")
	@DisplayedLoggedProperty(displayName = "Non Fraud Amount Loss")
	private BigDecimal nonFraudAmountLoss;

	@Column(name = "closure_Report_File_Type")
	@DisplayedLoggedProperty(displayName = "Closure Report File Type")
	private String closureReportFileType;

	@Column(name = "closure_Report_File_Name")
	@DisplayedLoggedProperty(displayName = "Closure Report File Name")
	private String closureReportFileName;

	@Column(name = "NO_OF_ADD_POWERS_USED")
	@DisplayedLoggedProperty(displayName = "No of times additional powers used")
	private Long noOfAddPowersUsed;

	@Column(name = "NEW_CLOSURE_CATEGORY_PART1")
	@DisplayedLoggedProperty(displayName = "New Clousre Category Part-1")
	private String newClosureCategoryPart1;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_21")
	@DisplayedLoggedProperty(displayName = "Number of successful sanctions applied - civil ")
	private Integer noOfSanctionsCateg2_1;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_22")
	@DisplayedLoggedProperty(displayName = "Number of successful sanctions applied - criminal")
	private Integer noOfSanctionsCateg2_2;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_23")
	@DisplayedLoggedProperty(displayName = "Number of successful sanctions applied - disciplinary")
	private Integer noOfSanctionsCateg2_3;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_24")
	@DisplayedLoggedProperty(displayName = "Number of successful sanctions applied - external agency")
	private Integer noOfSanctionsCateg2_4;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_25")
	@DisplayedLoggedProperty(displayName = "Number of system weaknesses identified and recorded")
	private Integer noOfSanctionsCateg2_5;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_26")
	@DisplayedLoggedProperty(displayName = "Number of unsuccessful sanctions applied - civil")
	private Integer noOfSanctionsCateg2_6;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_27")
	@DisplayedLoggedProperty(displayName = "Number of unsuccessful sanctions applied - criminal")
	private Integer noOfSanctionsCateg2_7;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_28")
	@DisplayedLoggedProperty(displayName = "Number of unsuccessful sanctions applied - disciplinary")
	private Integer noOfSanctionsCateg2_8;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_29")
	@DisplayedLoggedProperty(displayName = "Number of unsuccessful sanctions applied - external agency")
	private Integer noOfSanctionsCateg2_9;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_210")
	private Integer noOfSanctionsCateg2_10;

	@Column(name = "NO_OF_SANCTIONS_CATEGORY_211")
	private Integer noOfSanctionsCateg2_11;

	@Column(name = "NO_OF_CRIMINAL_SANCTIONS")
	@DisplayedLoggedProperty(displayName = "No of criminal sanctions applied")
	private Integer criminalSanctionsNo;

	@Column(name = "NO_OF_CIVIL_SANCTIONS")
	@DisplayedLoggedProperty(displayName = "No of civil sanctions applied")
	private Integer civilSanctionsNo;

	@Column(name = "NO_OF_INT_DISP_SANCTIONS")
	@DisplayedLoggedProperty(displayName = "No of internal disciplinary sanctions applied")
	private Integer internalDispSanctionsNo;

	@Column(name = "NO_OF_EXT_DISP_SANCTIONS")
	@DisplayedLoggedProperty(displayName = "No of external disciplinary sanctions applied")
	private Integer externalDispSanctionsNo;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getCaseClosureId() {
		return caseClosureId;
	}

	public void setCaseClosureId(Long caseClosureId) {
		this.caseClosureId = caseClosureId;
	}

	public String getClosureCategory() {
		return closureCategory;
	}

	public void setClosureCategory(String closureCategory) {
		this.closureCategory = closureCategory;
	}

	public Date getClosureDate() {
		return closureDate;
	}

	public void setClosureDate(Date closureDate) {
		this.closureDate = closureDate;
	}

	public byte[] getClosureReport() {
		return closureReport;
	}

	public void setClosureReport(byte[] closureReport) {
		this.closureReport = closureReport;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSystemWeakness() {
		return systemWeakness;
	}

	public void setSystemWeakness(String systemWeakness) {
		this.systemWeakness = systemWeakness;
	}

	public BigDecimal getRecoveredAmount() {
		return recoveredAmount == null ? recoveredAmount : recoveredAmount
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setRecoveredAmount(BigDecimal recoveredAmount) {
		this.recoveredAmount = recoveredAmount;
	}

	public BigDecimal getFraudAmount() {
		return fraudAmount == null ? fraudAmount : fraudAmount.setScale(2,
				BigDecimal.ROUND_DOWN);
	}

	public void setFraudAmount(BigDecimal fraudAmount) {
		this.fraudAmount = fraudAmount;
	}

	public String getClosureReportFileName() {
		return closureReportFileName;
	}

	public void setClosureReportFileName(String closureReportFileName) {
		this.closureReportFileName = closureReportFileName;
	}

	public String getClosureReportFileType() {
		return closureReportFileType;
	}

	public void setClosureReportFileType(String closureReportFileType) {
		this.closureReportFileType = closureReportFileType;
	}

	public Long getNoOfAddPowersUsed() {
		return noOfAddPowersUsed;
	}

	public void setNoOfAddPowersUsed(Long noOfAddPowersUsed) {
		this.noOfAddPowersUsed = noOfAddPowersUsed;
	}

	public Date getDestructionDate() {
		return destructionDate;
	}

	public void setDestructionDate(Date destructionDate) {
		this.destructionDate = destructionDate;
	}

	public String getNewClosureCategoryPart1() {
		return newClosureCategoryPart1;
	}

	public void setNewClosureCategoryPart1(String newClosureCategoryPart1) {
		this.newClosureCategoryPart1 = newClosureCategoryPart1;
	}

	public Integer getNoOfSanctionsCateg2_1() {
		return noOfSanctionsCateg2_1;
	}

	public void setNoOfSanctionsCateg2_1(Integer noOfSanctionsCateg2_1) {
		this.noOfSanctionsCateg2_1 = noOfSanctionsCateg2_1;
	}

	public Integer getNoOfSanctionsCateg2_2() {
		return noOfSanctionsCateg2_2;
	}

	public void setNoOfSanctionsCateg2_2(Integer noOfSanctionsCateg2_2) {
		this.noOfSanctionsCateg2_2 = noOfSanctionsCateg2_2;
	}

	public Integer getNoOfSanctionsCateg2_3() {
		return noOfSanctionsCateg2_3;
	}

	public void setNoOfSanctionsCateg2_3(Integer noOfSanctionsCateg2_3) {
		this.noOfSanctionsCateg2_3 = noOfSanctionsCateg2_3;
	}

	public Integer getNoOfSanctionsCateg2_4() {
		return noOfSanctionsCateg2_4;
	}

	public void setNoOfSanctionsCateg2_4(Integer noOfSanctionsCateg2_4) {
		this.noOfSanctionsCateg2_4 = noOfSanctionsCateg2_4;
	}

	public Integer getNoOfSanctionsCateg2_5() {
		return noOfSanctionsCateg2_5;
	}

	public void setNoOfSanctionsCateg2_5(Integer noOfSanctionsCateg2_5) {
		this.noOfSanctionsCateg2_5 = noOfSanctionsCateg2_5;
	}

	public Integer getNoOfSanctionsCateg2_6() {
		return noOfSanctionsCateg2_6;
	}

	public void setNoOfSanctionsCateg2_6(Integer noOfSanctionsCateg2_6) {
		this.noOfSanctionsCateg2_6 = noOfSanctionsCateg2_6;
	}

	public Integer getNoOfSanctionsCateg2_7() {
		return noOfSanctionsCateg2_7;
	}

	public void setNoOfSanctionsCateg2_7(Integer noOfSanctionsCateg2_7) {
		this.noOfSanctionsCateg2_7 = noOfSanctionsCateg2_7;
	}

	public Integer getNoOfSanctionsCateg2_8() {
		return noOfSanctionsCateg2_8;
	}

	public void setNoOfSanctionsCateg2_8(Integer noOfSanctionsCateg2_8) {
		this.noOfSanctionsCateg2_8 = noOfSanctionsCateg2_8;
	}

	public Integer getNoOfSanctionsCateg2_9() {
		return noOfSanctionsCateg2_9;
	}

	public void setNoOfSanctionsCateg2_9(Integer noOfSanctionsCateg2_9) {
		this.noOfSanctionsCateg2_9 = noOfSanctionsCateg2_9;
	}

	public Integer getCriminalSanctionsNo() {
		return criminalSanctionsNo;
	}

	public void setCriminalSanctionsNo(Integer criminalSanctionsNo) {
		this.criminalSanctionsNo = criminalSanctionsNo;
	}

	public Integer getCivilSanctionsNo() {
		return civilSanctionsNo;
	}

	public void setCivilSanctionsNo(Integer civilSanctionsNo) {
		this.civilSanctionsNo = civilSanctionsNo;
	}

	public Integer getInternalDispSanctionsNo() {
		return internalDispSanctionsNo;
	}

	public void setInternalDispSanctionsNo(Integer internalDispSanctionsNo) {
		this.internalDispSanctionsNo = internalDispSanctionsNo;
	}

	public Integer getExternalDispSanctionsNo() {
		return externalDispSanctionsNo;
	}

	public void setExternalDispSanctionsNo(Integer externalDispSanctionsNo) {
		this.externalDispSanctionsNo = externalDispSanctionsNo;
	}

	public Integer getNoOfSanctionsCateg2_10() {
		return noOfSanctionsCateg2_10;
	}

	public void setNoOfSanctionsCateg2_10(Integer noOfSanctionsCateg2_10) {
		this.noOfSanctionsCateg2_10 = noOfSanctionsCateg2_10;
	}

	public Integer getNoOfSanctionsCateg2_11() {
		return noOfSanctionsCateg2_11;
	}

	public void setNoOfSanctionsCateg2_11(Integer noOfSanctionsCateg2_11) {
		this.noOfSanctionsCateg2_11 = noOfSanctionsCateg2_11;
	}

	public BigDecimal getFraudAmountLoss() {
		return fraudAmountLoss == null ? fraudAmountLoss : fraudAmountLoss
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setFraudAmountLoss(BigDecimal fraudAmountLoss) {
		this.fraudAmountLoss = fraudAmountLoss;
	}

	/**
	 * @return the nonFraudAmountLoss
	 */
	public BigDecimal getNonFraudAmountLoss() {
		return nonFraudAmountLoss;
	}

	/**
	 * @param nonFraudAmountLoss
	 *            the nonFraudAmountLoss to set
	 */
	public void setNonFraudAmountLoss(BigDecimal nonFraudAmountLoss) {
		this.nonFraudAmountLoss = nonFraudAmountLoss;
	}

}
