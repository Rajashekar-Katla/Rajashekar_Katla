package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class CPSDocumentsView implements Serializable {

	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CPS_DOC_REQ_ID")
	private Long cpsDocRequestId;

	@Column(name = "CPS_REQ_ID")
	private Long cpsReqId;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "CREATED_STAFF_ID")
	private String createdStaffId;

	@Column(name = "CREATED_TIME")
	private Timestamp createdTime;

	@Column(name = "REQUESTER_MESSAGE")
	private String requesterMessage;

	@Column(name = "APPROVER_STAFF_ID")
	private String approverStaffId;

	@Column(name = "APPROVER_RESPONSE_TIME")
	private Timestamp approverResponseTime;

	@Column(name = "APPROVER_MESSAGE")
	private String approverMessage;

	@Column(name = "REQUEST_STATUS")
	private String requestStatus;

	@Column(name = "SUBMISSION_TYPE")
	private String submissionType;

	@Column(name = "DOCUMENT_TYPE")
	private String documentType;

	@Column(name = "DOCUMENT_ID")
	private Long documentID;

	@Column(name = "CREATED_STAFF_NAME")
	private String createdStaffName;

	@Column(name = "APPROVER_STAFF_NAME")
	private String approverStaffName;

	public Long getCpsReqId() {
		return cpsReqId;
	}

	public void setCpsReqId(Long cpsReqId) {
		this.cpsReqId = cpsReqId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	public String getRequesterMessage() {
		return requesterMessage;
	}

	public void setRequesterMessage(String requesterMessage) {
		this.requesterMessage = requesterMessage;
	}

	public String getApproverStaffId() {
		return approverStaffId;
	}

	public void setApproverStaffId(String approverStaffId) {
		this.approverStaffId = approverStaffId;
	}

	public Timestamp getApproverResponseTime() {
		return approverResponseTime;
	}

	public void setApproverResponseTime(Timestamp approverResponseTime) {
		this.approverResponseTime = approverResponseTime;
	}

	public String getApproverMessage() {
		return approverMessage;
	}

	public void setApproverMessage(String approverMessage) {
		this.approverMessage = approverMessage;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public Long getDocumentID() {
		return documentID;
	}

	public void setDocumentID(Long documentID) {
		this.documentID = documentID;
	}

	public Long getCpsDocRequestId() {
		return cpsDocRequestId;
	}

	public void setCpsDocRequestId(Long cpsDocRequestId) {
		this.cpsDocRequestId = cpsDocRequestId;
	}

	public String getCreatedStaffName() {
		return createdStaffName;
	}

	public void setCreatedStaffName(String createdStaffName) {
		this.createdStaffName = createdStaffName;
	}

	public String getApproverStaffName() {
		return approverStaffName;
	}

	public void setApproverStaffName(String approverStaffName) {
		this.approverStaffName = approverStaffName;
	}

}
