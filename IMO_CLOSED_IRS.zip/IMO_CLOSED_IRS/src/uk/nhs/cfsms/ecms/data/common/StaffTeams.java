package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
@Entity

@Table(name="STAFF_TEAMS_TBL")
public class StaffTeams  implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 45612341L;
	
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "STAFF_TEAM_ID_SQNC") })
	@Column(name="STAFF_TEAM_ID")
	private Long staffTeamId;
	
	@Column(name="STAFF_ID")
	private String staffId;
	
	@Column(name="TEAM")
	private String teamCode;
	
	@Column(name="READ_WRITE")
	private String readWrite;

	
	public String getReadWrite() {
		return readWrite;
	}

	public void setReadWrite(String readWrite) {
		this.readWrite = readWrite;
	}

	public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public Long getStaffTeamId() {
		return staffTeamId;
	}

	public void setStaffTeamId(Long staffTeamId) {
		this.staffTeamId = staffTeamId;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}
	
	
	

}
