package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
@Entity
@Table(name = "MGFORMS_TBL")
@Audited
public class MGForm implements Serializable {
	
	
	private static final long serialVersionUID = 4939871235L;

	@Id
	@Column(name = "mgform_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "MGFORM_ID_SQNC") })
	private Long mgFormId;
	
	@Column(name = "case_id")
	private Long caseId;

	@Column(name = "mgform_type")
	@DisplayedLoggedProperty(displayName = "MG Form Type")
	private String mgFormType;
	
	@Lob
	@Column(name = "mgform")
	private   byte[] mgForm;
	
	@Column(name = "CREATED_TIME")
	@DisplayedLoggedProperty(displayName = "Created Time")
	private Date createdTime;
	
	@Column(name = "CREATED_STAFF_ID")
	@DisplayedLoggedProperty(displayName = "Created By")
	private String createdStaffId;
	
	@Column(name = "FILE_NAME")
	@DisplayedLoggedProperty(displayName = "File Name")
	private String fileName;
	
	@Column(name = "FILE_TYPE")
	@DisplayedLoggedProperty(displayName = "File Type")
	private String fileType;
	
	

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public byte[] getMgForm() {
		
		return mgForm;
	}

	public void setMgForm(byte[] mgForm) {
		this.mgForm = mgForm;
		
	}

	public Long getMgFormId() {
		return mgFormId;
	}

	public void setMgFormId(Long mgFormId) {
		this.mgFormId = mgFormId;
	}

	public String getMgFormType() {
		
		return mgFormType;
	}

	public void setMgFormType(String mgFormType) {
		this.mgFormType = mgFormType;
	}

	
	


}
