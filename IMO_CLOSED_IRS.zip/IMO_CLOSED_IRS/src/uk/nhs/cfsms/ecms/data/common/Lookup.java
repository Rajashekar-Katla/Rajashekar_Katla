package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name = "LOOKUP_TBL")
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region = "LookupCodes")
public class Lookup implements Serializable {

	private static final long serialVersionUID = 493451235L;

	@Id
	@Column(name = "LOOKUP_ID")
	private Integer lookupId;

	@Column(name = "LOOKUP_GROUP_ID")
	private Integer groupId;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "PARENT_ID")
	private Integer parentId;

	@Column(name = "ACTIVE")
	private String active;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public Integer getLookupId() {
		return lookupId;
	}

	public void setLookupId(Integer lookupId) {
		this.lookupId = lookupId;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Lookup) {
			Lookup c = (Lookup) obj;
			return c.getLookupId() == this.getLookupId();
		}
		return false;
	}

	@Override
	public int hashCode() {
		return 17 + lookupId.hashCode();
	}

}
