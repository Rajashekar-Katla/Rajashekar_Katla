package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "FC_PERSON_TBL")
/**
 * Person contain personal, address and contacts details
 * 
 * @author Venkat.Kolla 
 * 
 */
public class FcrolPerson implements Serializable {

	private static final long serialVersionUID = 734136195L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "PERSON_ID_SQNC") })
	@Column(name = "PERSON_ID")
	private Long personId;

	@Column(name = "TITLE")
	private String title;
	
	@Column(name = "OTHER_TITLE")
	private String otherTitle;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "LAST_NAME")
	private String lastName;

	@Column(name = "OTHER_NAME")
	private String otherName;

	@Column(name = "OCCUPATION")
	private String occupation;

	@Column(name = "ORG_NAME")
	private String orgName;

	@Column(name = "DOB")
	private Date dob;

	@Column(name = "GENDER")
	private String gender;

	@Column(name = "NI_NUMBER")
	private String nINumber;

	@Column(name = "PERSON_TYPE")
	private String personType;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "PERSON_DESCRIPTION_ID")
	private FcrolPersonDescription personDescription;

	@Column(name = "KNOWN_AS")
	private String knownAs;
	
	@Column(name = "IS_PERSON_NHS")
	private String isPersonNhs;

	@Column(name = "OTHER_OCCUPATION")
	private String otherOccupation;

	@Column(name = "NATIONALITY")
	private String nationality;

	@Column(name = "ETHNIC_CODE")
	private String ethnicCode;

	@Column(name = "PASSPORT_NUMBER")
	private String passportNumber;

	@Column(name = "DRIVING_LICENSE_NUMBER")
	private String drivingLicenseNumber;

	@Column(name = "NHS_NUMBER")
	private String nhsNumber;

	@Column(name = "PAYROLL_NUMBER")
	private String payrollNumber;

	@Column(name = "RELIGION")
	private String religion;

	@Column(name = "PLACE_OF_BIRTH")
	private String placeOfBirth;
	
	@Column(name = "is_Person_Nhs_Patient")
	private String isPersonNhsPatient;
	
	@Column(name = "treatmant")
	private String treatmant;
	
	@Column(name = "patient_Type")
	private String patientType;
	
	@Column(name = "patient_occupation")
	private String patientOccupation;
	
	@Column(name = "link_to_nhs")
	private String linkToNhs;
	
	@Column(name = "other_information")
	private String otherInformation;
	
	@Column(name = "patient_Organisation")
	private String patientOrganisation;
	
	@Column(name = "professional_Body")
	private String professionalBody;
	
	@Column(name = "registration_Number")
	private String registrationNumber;
	
	@Column(name = "other_Identifier")
	private String otherIdentifier;
	
	@Column(name = "age")
	private String age;
	
	
	@OneToMany(cascade ={CascadeType.ALL}, fetch = FetchType.EAGER)
	@JoinColumn(name = "PERSON_ID")
	@org.hibernate.annotations.Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<FcrolAddress> addressList = new HashSet<FcrolAddress>();
		
	@OneToMany(cascade ={CascadeType.ALL}, fetch = FetchType.EAGER)
	@JoinColumn(name = "PERSON_ID")
	@org.hibernate.annotations.Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<FcrolPersonContacts> contactsList = new HashSet<FcrolPersonContacts>();

	
	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	/*
	 * public String getEmail() { return email; }
	 * 
	 * public void setEmail(String email) { this.email = email; }
	 * 
	 * public String getFaxNumber() { return faxNumber; }
	 * 
	 * public void setFaxNumber(String faxNumber) { this.faxNumber = faxNumber; }
	 */
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getNINumber() {
		return nINumber;
	}

	public void setNINumber(String number) {
		nINumber = number;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOtherName() {
		return otherName;
	}

	public void setOtherName(String otherName) {
		this.otherName = otherName;
	}

	public FcrolPersonDescription getPersonDescription() {
		return personDescription;
	}

	public void setPersonDescription(FcrolPersonDescription personDescription) {
		this.personDescription = personDescription;
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}

	public String getPersonType() {
		return personType;
	}

	public void setPersonType(String personType) {
		this.personType = personType;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDrivingLicenseNumber() {
		return drivingLicenseNumber;
	}

	public void setDrivingLicenseNumber(String drivingLicenseNumber) {
		this.drivingLicenseNumber = drivingLicenseNumber;
	}

	public String getEthnicCode() {
		return ethnicCode;
	}

	public void setEthnicCode(String ethnicCode) {
		this.ethnicCode = ethnicCode;
	}

	public String getIsPersonNhs() {
		return isPersonNhs;
	}

	public void setIsPersonNhs(String isPersonNhs) {
		this.isPersonNhs = isPersonNhs;
	}

	public String getKnownAs() {
		return knownAs;
	}

	public void setKnownAs(String knownAs) {
		this.knownAs = knownAs;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getNhsNumber() {
		return nhsNumber;
	}

	public void setNhsNumber(String nhsNumber) {
		this.nhsNumber = nhsNumber;
	}

	public String getOtherOccupation() {
		return otherOccupation;
	}

	public void setOtherOccupation(String otherOccupation) {
		this.otherOccupation = otherOccupation;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getPayrollNumber() {
		return payrollNumber;
	}

	public void setPayrollNumber(String payrollNumber) {
		this.payrollNumber = payrollNumber;
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getFullName() {
		StringBuffer sb = new StringBuffer("");
		if (this.title != null)
			sb.append(this.title).append(" ");
		if (this.firstName != null)
			sb.append(this.firstName).append(" ");
		if (this.firstName != null)
			sb.append(this.lastName);
		return sb.toString();
	}

	public Set<FcrolAddress> getAddressList() {
		return addressList;
	}

	public void setAddressList(Set<FcrolAddress> addressList) {
		this.addressList = addressList;
	}

	public Set<FcrolPersonContacts> getContactsList() {
		return contactsList;
	}

	public void setContactsList(Set<FcrolPersonContacts> contactsList) {
		this.contactsList = contactsList;
	}
	
	/**
	 * Helper method to get only one address from addressList.
	 * 
	 * @return Address
	 */
	public Address getAddress() {

		Address adrs = new Address();
		
		if (addressList != null && addressList.size() == 1) {
			
			Address[] adrsArray = addressList.toArray(new Address[addressList.size()]);
			
			return adrsArray[0];	
		}
		return adrs;
	}
	
	/**
	 * Helper method to get only one address from addressList.
	 * 
	 * @return Address
	 */
	public PersonContacts getContacts() {

		PersonContacts contacts = new PersonContacts();
		
		if (contactsList != null && contactsList.size() == 1) {
			PersonContacts[] cntsArray = contactsList.toArray(new PersonContacts[contactsList.size()]);
			
			return cntsArray[0];	
		}
		return contacts;
	}

	

	public String getOtherTitle() {
		return otherTitle;
	}

	public void setOtherTitle(String otherTitle) {
		this.otherTitle = otherTitle;
	}

	public String getIsPersonNhsPatient() {
		return isPersonNhsPatient;
	}

	public void setIsPersonNhsPatient(String isPersonNhsPatient) {
		this.isPersonNhsPatient = isPersonNhsPatient;
	}

	public String getLinkToNhs() {
		return linkToNhs;
	}

	public void setLinkToNhs(String linkToNhs) {
		this.linkToNhs = linkToNhs;
	}

	public String getOtherInformation() {
		return otherInformation;
	}

	public void setOtherInformation(String otherInformation) {
		this.otherInformation = otherInformation;
	}

	public String getPatientType() {
		return patientType;
	}

	public void setPatientType(String patientType) {
		this.patientType = patientType;
	}

	public String getTreatmant() {
		return treatmant;
	}

	public void setTreatmant(String treatmant) {
		this.treatmant = treatmant;
	}

	public String getPatientOccupation() {
		return patientOccupation;
	}

	public void setPatientOccupation(String patientOccupation) {
		this.patientOccupation = patientOccupation;
	}

	public String getPatientOrganisation() {
		return patientOrganisation;
	}

	public void setPatientOrganisation(String patientOrganisation) {
		this.patientOrganisation = patientOrganisation;
	}

	public String getOtherIdentifier() {
		return otherIdentifier;
	}

	public void setOtherIdentifier(String otherIdentifier) {
		this.otherIdentifier = otherIdentifier;
	}

	public String getProfessionalBody() {
		return professionalBody;
	}

	public void setProfessionalBody(String professionalBody) {
		this.professionalBody = professionalBody;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}
	
}