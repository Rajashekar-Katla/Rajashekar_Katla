package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USER_PREFERENCES")
public class UserPreference  implements Serializable {

	private static final long serialVersionUID = 346564051L;

	@Id
	@Column(name = "STAFF_ID")
	private String staffId;

	@Column(name = "FONT_SIZE")
	private String fontSize;

	@Column(name = "CREATED_DATE",updatable=false)
	private Date createdTime;
	
	@Column(name = "MODIFIED_DATE")
	private Date modifiedTime;
	
	
	public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public String getFontSize() {
		return fontSize;
	}

	public void setFontSize(String fontSize) {
		this.fontSize = fontSize;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	
}