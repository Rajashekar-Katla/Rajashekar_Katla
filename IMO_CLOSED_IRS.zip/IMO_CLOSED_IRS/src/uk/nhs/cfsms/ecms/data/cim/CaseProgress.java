package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
@Entity
@Table(name="CASE_PROGRESS_TBL")
@Audited
public class CaseProgress implements Serializable {

	@Transient
	private static final long serialVersionUID = 4938871235L;
	
	@Id
	@Column(name="CASE_PROGRESS_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "CASE_PROGRESS_ID_SQNC") })
	private Long caseProgressId;	
	
	@Column(name="TYPE")
	@DisplayedLoggedProperty(displayName = "Type")
	private String type;
	
	@Column(name="MINUTE_REF")
	@DisplayedLoggedProperty(displayName = "Minuter Number CrossReferenced")
	private String minuteNumberCrossRefered;
	
	@Column(name="DESCRIPTION")
	@Type(type="uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch =FetchType.EAGER)
	@DisplayedLoggedProperty(displayName = "Description")
	private String description;
	
	@Column(name="RECORDED_BY")
	private String recordedBy;
	
	@Column(name="DATE_OF_EVENT")
	@DisplayedLoggedProperty(displayName = "Date of Event")
	private Date dateOfEvent;

	@Column(name="DATE_RECORDED")
	private Date dateRecorded;
	
	@Column(name="TIME")
	private String time;

	@Column(name="MINUTE_NO")
	@DisplayedLoggedProperty(displayName = "Minute Number")
	private String minuteNumber;
	
	@Column(name="CASE_ID")
	private Long caseId;
	
	@Column(name = "CREATED_TIME" , insertable=true, updatable=false)
	private Date createdTime;
	
	@Column(name = "CREATED_STAFF_ID" , insertable=true, updatable=false)
	private String createdStaffId;
	
	@Transient
	private String descriptionString;
	
	@Column(name="UPDATED_FLAG")
	@DisplayedLoggedProperty(displayName = "Updated Flag")
	private String updatedFlag="Y";
	
	@Column(name="SENSITIVE")
	@DisplayedLoggedProperty(displayName = "Sensitive")
	private String sensitive="N";


	@Transient
	private boolean isModify = true;
	
	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		this.updatedFlag = updatedFlag;
	}

	/**
	 * @return Returns the caseProgressId.
	 */
	public Long getCaseProgressId() {
		return caseProgressId;
	}

	/**
	 * @param caseProgressId The caseProgressId to set.
	 */
	public void setCaseProgressId(Long caseProgressId) {
		this.caseProgressId = caseProgressId;
	}

	/**
	 * @return Returns the dateOfEvent.
	 */
	public Date getDateOfEvent() {
		return dateOfEvent;
	}

	/**
	 * @param dateOfEvent The dateOfEvent to set.
	 */
	public void setDateOfEvent(Date dateOfEvent) {
		this.dateOfEvent = dateOfEvent;
	}

	/**
	 * @return Returns the dateRecorded.
	 */
	public Date getDateRecorded() {
		return dateRecorded;
	}

	/**
	 * @param dateRecorded The dateRecorded to set.
	 */
	public void setDateRecorded(Date dateRecorded) {
		this.dateRecorded = dateRecorded;
	}

	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description The description to set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return Returns the minuteNumberCrossReferenced.
	 */
	public String getMinuteNumberCrossRefered() {
		return minuteNumberCrossRefered;
	}

	/**
	 * @param minuteNumberCrossReferenced The minuteNumberCrossReferenced to set.
	 */
	public void setMinuteNumberCrossRefered(String minuteNumberCrossReferenced) {
		this.minuteNumberCrossRefered = minuteNumberCrossReferenced;
	}

	/**
	 * @return Returns the recordedBy.
	 */
	public String getRecordedBy() {
		return recordedBy;
	}

	/**
	 * @param recordedBy The recordedBy to set.
	 */
	public void setRecordedBy(String recordedBy) {
		this.recordedBy = recordedBy;
	}

	/**
	 * @return Returns the time.
	 */
	public String getTime() {
		return time;
	}

	/**
	 * @param time The time to set.
	 */
	public void setTime(String time) {
		this.time = time;
	}

	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the minuteNumber.
	 */
	public String getMinuteNumber() {
		return minuteNumber;
	}

	/**
	 * @param minuteNumber The minuteNumber to set.
	 */
	public void setMinuteNumber(String minuteNumber) {
		this.minuteNumber = minuteNumber;
	}	

	/**
	 * @return Returns the createdStaffId.
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	/**
	 * @param createdStaffId The createdStaffId to set.
	 */
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	/**
	 * @return Returns the createdTime.
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime The createdTime to set.
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getDescriptionString() {
		
		ByteArrayMultipartFileEditor editor = new ByteArrayMultipartFileEditor() ;
		if (description != null)  {
			editor.setValue(description);
			return editor.getAsText();
		} 
		return "";
			
	}

	public void setDescriptionString(String descriptionString) {
		this.descriptionString = descriptionString;
	}

	public boolean getIsModify() {
		return isModify;
	}

	public void setIsModify(boolean isModify) {
		this.isModify = isModify;
	}

	public String getSensitive() {
		return sensitive;
	}

	public void setSensitive(String sensitive) {
		this.sensitive = sensitive;
	}
	
}
