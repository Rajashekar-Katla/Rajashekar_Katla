package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

/**
 * Bank Details of the Subject(individual).
 * 
 */

@Entity
@Table(name = "SUBJECT_BANK_DETAILS_TBL")
@Audited
public class BankDetails implements Serializable {

	private static final long serialVersionUID = 653463345801L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SUB_BANK_ID_SQNC") })
	@Column(name = "BANK_DETAILS_ID")
	private Long subjectBDId;

	@Column(name = "PERSON_ID", nullable = false, insertable = false, updatable = false)
	@DisplayedLoggedProperty(displayName = "Person Id")
	private Long personId;
	
	@Column(name = "BANK_NAME")
	@DisplayedLoggedProperty(displayName = "Bank Name")
	private String bankName;

	@Column(name = "ADDRESS1")
	@DisplayedLoggedProperty(displayName = "Address1")
	private String address1;

	@Column(name = "ADDRESS2")
	@DisplayedLoggedProperty(displayName = "Address2")
	private String address2;

	@Column(name = "ADDRESS3")
	@DisplayedLoggedProperty(displayName = "Address3")
	private String address3;

	@Column(name = "ADDRESS4")
	@DisplayedLoggedProperty(displayName = "Address4")
	private String address4;

	@Column(name = "POSTCODE")
	@DisplayedLoggedProperty(displayName = "Post Code")
	private String postcode;

	@Column(name = "SORT_CODE")
	@DisplayedLoggedProperty(displayName = "Sort Code")
	private String sortCode;

	@Column(name = "ACCOUNT_NUMBER")
	@DisplayedLoggedProperty(displayName = "Account Number")
	private String accountNumber;

	@Column(name = "PHONE_NUMBER")
	@DisplayedLoggedProperty(displayName = "Phone Number")
	private String phoneNumber;

	
	public Long getSubjectBDId() {
		return subjectBDId;
	}

	public void setSubjectBDId(Long subjectBDId) {
		this.subjectBDId = subjectBDId;
	}
	
	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getSortCode() {
		return sortCode;
	}

	public void setSortCode(String sortCode) {
		this.sortCode = sortCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFullAddress() {
		StringBuffer sb = new StringBuffer("");
		if (this.address1 != null)
			sb.append(this.address1).append(", ");
		if (this.address2 != null)
			sb.append(this.address2).append(", ");
		if (this.address3 != null)
			sb.append(this.address3).append(", ");
		if (this.address4 != null)
			sb.append(this.address4);

		return sb.toString();
	}
}