package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "INDEXED_CASE_SEARCH_TBL")
//@NamedNativeQuery(name = "getIndexedCaseSearchResults", query = "select * from INDEXED_CASE_SEARCH_TBL WHERE CONTAINS(description_values , :vKeywords, 1) > 0", resultClass=uk.nhs.cfsms.ecms.data.cim.CaseIndexSearch.class)
// TODO : Implement bBest approach possible especially dealing with the clob data.
/* @NamedNativeQuery(name = "getIndexedCaseSearchResults", query = "call sp_getIndexedCaseSearchResults(?, :vKeywords)", callable = true, resultClass = uk.nhs.cfsms.ecms.data.cim.CaseIndexSearch.class)*/
/* @NamedNativeQuery(name = "getIndexedCaseSearchResults", query = "SELECT * FROM indexed_case_search_tbl WHERE CONTAINS(description_values , :vKeywords, 1) > 0", resultClass = uk.nhs.cfsms.ecms.data.cim.CaseIndexSearch.class) */
/* @NamedNativeQuery(name = "getIndexedCaseSearchResults", query = "select search_id,case_id,origin_table,origin_id,confidential,confidential_search,restricted_search,created_date from indexed_case_search_tbl WHERE origin_table like :vKeywords", resultClass=uk.nhs.cfsms.ecms.data.cim.CaseIndexSearch.class)*/ 
/* @javax.persistence.NamedNativeQuery(name = "getIndexedInformationSearchResults", query = "{ ? = call sp_getIndexedInformationSearchResults(:vKeywords, :vStaffId, :vTeamCode, :vOrgCode) }", resultClass = CaseIndexSearch.class, hints = { @javax.persistence.QueryHint(name = "org.hibernate.callable", value = "true") })*/
/* @javax.persistence.NamedNativeQuery(name = "getIndexedCaseSearchResults", query = "{ ? = call sp_getIndexedCaseSearchResults(:vKeywords) }", resultClass = uk.nhs.cfsms.ecms.data.cim.CaseIndexSearch.class, hints = { @javax.persistence.QueryHint(name = "org.hibernate.callable", value = "true") }) **/

public class CaseIndexSearch implements Serializable {

	private static final long serialVersionUID = 309970404L;

	@Id
	@Column(name = "SEARCH_ID")
	private Long searchId;

	@Column(name = "CASE_ID")
	private Long caseId;
	
	@Column(name = "CASE_NUMBER")
	private String caseNumber;	

	@Column(name = "DESCRIPTION_VALUES")
	@Type(type = "uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@Basic(fetch = FetchType.EAGER)
	private String description;
	
	@Column(name = "ORIGIN_TABLE")
	private String originTable;

	@Column(name = "ORIGIN_ID")
	private Long originId;
	/*
	@Column(name = "CONFIDNETIAL")
	private String isConfidential;*/

	@Column(name = "CONFIDENTIAL_SEARCH")
	private String isConfidentialSearch;

	@Column(name = "RESTRICTED_SEARCH")
	private String isRestrictedSearch;

	@Column(name = "CREATED_DATE")
	private Date createdTime;
	
	@Column(name = "IS_DELETED")
	private String deleted;
	
	private Integer keywordCount;
	
	public Long getSearchId() {
		return searchId;
	}

	public void setSearchId(Long searchId) {
		this.searchId = searchId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/*public String isConfidential() {
		return isConfidential;
	}

	public void setConfidential(String isConfidential) {
		this.isConfidential = isConfidential;
	}*/

	public String isConfidentialSearch() {
		return isConfidentialSearch;
	}

	public void setConfidentialSearch(String isConfidentialSearch) {
		this.isConfidentialSearch = isConfidentialSearch;
	}

	public String isRestrictedSearch() {
		return isRestrictedSearch;
	}

	public void setRestrictedSearch(String isRestrictedSearch) {
		this.isRestrictedSearch = isRestrictedSearch;
	}

	public Long getOriginId() {
		return originId;
	}

	public void setOriginId(Long originId) {
		this.originId = originId;
	}

	public String getOriginTable() {
		return originTable;
	}

	public void setOriginTable(String originTable) {
		this.originTable = originTable;
	}

	public String getDeleted() {
		return deleted;
	}

	public void setDeleted(String deleted) {
		this.deleted = deleted;
	}

	public Integer getKeywordCount() {
		return keywordCount;
	}

	public void setKeywordCount(Integer keywordCount) {
		this.keywordCount = keywordCount;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
