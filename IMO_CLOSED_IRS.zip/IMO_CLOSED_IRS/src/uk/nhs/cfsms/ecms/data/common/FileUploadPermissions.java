package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FILE_UPLOAD_PERM_TBL")
public class FileUploadPermissions implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7421438634364207259L;

	@Id
	@Column(name = "CATEGORY")
	private String category;
	
	@Column(name = "PERMISSIONS")
	private String permissions;
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getPermissions() {
		return permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

}
