package uk.nhs.cfsms.ecms.data.sanction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "POLICE_CHARGE_TBL")
@Audited
public class PoliceCharge implements Serializable {

	private static final long serialVersionUID = 7460215L;
	
	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "POLICE_CHARGE_ID_SQNC") })
	@Column(name = "POLICE_CHARGE_ID")
	private Long chargeId;
	
	@Column(name = "CRIMINAL_SANCTION_ID")
	private Long sanctionId;
	
	@Column(name = "CHARGING_OFFICER")
	@DisplayedLoggedProperty(displayName = "Charging Officer")
	private String chargingOfficer;
	
	@Column(name = "CHARGING_DATE")
	@DisplayedLoggedProperty(displayName = "Charged Date")
	private Date chargingDate;
	
	@Column(name = "CHARGING_ADDRESS1")
	@DisplayedLoggedProperty(displayName = "Address 1")
	private String address1;

	@Column(name = "CHARGING_ADDRESS2")
	@DisplayedLoggedProperty(displayName = "Address 2")
	private String address2;

	@Column(name = "CHARGING_ADDRESS3")
	@DisplayedLoggedProperty(displayName = "Address 3")
	private String address3;

	@Column(name = "CHARGING_ADDRESS4")
	@DisplayedLoggedProperty(displayName = "Address 4")
	private String address4;

	@Column(name = "CHARGING_POSTCODE")
	@DisplayedLoggedProperty(displayName = "Post code")
	private String postcode;
	
	@Column(name = "CREATED_STAFF_ID")
	private String createStaffId;
	
	@Column(name = "CREATED_TIME")
	private Date createdTime;

	@Column(name = "ARREST_SUMMONS_NO")
	@DisplayedLoggedProperty(displayName = "Arrest Summons Number")
	private String arrestSummonsNumber;
	
	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public Long getChargeId() {
		return chargeId;
	}

	public void setChargeId(Long chargeId) {
		this.chargeId = chargeId;
	}

	public Date getChargingDate() {
		return chargingDate;
	}

	public void setChargingDate(Date chargingDate) {
		this.chargingDate = chargingDate;
	}

	public String getChargingOfficer() {
		return chargingOfficer;
	}

	public void setChargingOfficer(String chargingOfficer) {
		this.chargingOfficer = chargingOfficer;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getCreateStaffId() {
		return createStaffId;
	}

	public void setCreateStaffId(String createStaffId) {
		this.createStaffId = createStaffId;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public String getArrestSummonsNumber() {
		return arrestSummonsNumber;
	}

	public void setArrestSummonsNumber(String arrestSummonsNumber) {
		this.arrestSummonsNumber = arrestSummonsNumber;
	}
	
}
