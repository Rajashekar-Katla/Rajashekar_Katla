package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="PERMISSION_TBL")
public class Permission implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/**
	 * The unique for the table
	 */
	@Id
	@Column(name="PERMISSION_ID")
	private long id;
	
	
	@Column(name="NAME")
	private String name;
	
	

	
	@ManyToMany(
	        cascade={CascadeType.ALL},	        
	        mappedBy="permissions",
	        targetEntity=PermissionGroup.class
	    )
	List<PermissionGroup> permissionGroups;

	/**
	 * @return Returns the id.
	 */
	public long getId() {
		return id;
	}


	/**
	 * @param id The id to set.
	 */
	public void setId(long id) {
		this.id = id;
	}


	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}


	/**
	 * @param name The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}

	@Column(name="TOKEN")
	private char token;
	
	public char getToken() {
		return token;
	}


	public void setToken(char token) {
		this.token = token;
	}
	
	
	
}
