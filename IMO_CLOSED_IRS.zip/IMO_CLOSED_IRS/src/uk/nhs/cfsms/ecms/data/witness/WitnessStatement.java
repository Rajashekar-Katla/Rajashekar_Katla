package uk.nhs.cfsms.ecms.data.witness;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "WITNESS_STATEMENT_TBL")
public class WitnessStatement implements Serializable {

	private static final long serialVersionUID = 4939871235L;

	@Id
	@Column(name = "STATEMENT_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "STATEMENT_ID_SQNC") })
	private Long statementId;

	@OneToOne
	@JoinColumn(name = "WITNESS_ID")
	private Witness witness;

	@Column(name = "CREATED_TIME", updatable = false)
	private Date createdTime;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;

	@Column(name = "STATEMENT_DATE_TIME")
	private Date statementDateTime;

	@Column(name = "STATEMENT_DESCRIPTION")
	private String statementDescription;

	@Column(name = "STATEMENT_FILE")
	@Lob
	private byte[] statementFile;

	@Column(name = "STATEMENT_FILE_TYPE")
	private String statementFileType;

	@Column(name = "URN1")
	private String urn1;

	@Column(name = "URN2")
	private String urn2;

	@Column(name = "URN3")
	private String urn3;

	@Column(name = "URN4")
	private String urn4;

	@Column(name = "STATEMENT_SIGNATURE")
	private String statementSignature;

	@Column(name = "AGE")
	private String age;

	@Column(name = "STATEMENT_OF")
	private String statementOf;

	@Column(name = "OCCUPATION")
	private String occupation;

	@Column(name = "NO_OF_PAGES")
	private String noofPages;

	@Column(name = "SIGNATURE")
	private String signature;

	@Column(name = "WITNESSED_BY")
	private String witnessedBy;

	@Column(name = "WITNESS_SIGNATURE")
	private String witnessSignature;

	@Column(name = "IS_UPLOADED_STATEMENT")
	private String isUploadedStatment;

	@Column(name = "VISUALLY_RECORDED")
	private String visuallyRecorded;
	
	@Column(name = "UPDATED_FLAG")
	private String updatedFlag = "Y";
	
	@Column(name = "STATEMENT_FILE_NAME")
	private String fileName;
	
	@Column(name="PART_NO")
	private int partNumber;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getVisuallyRecorded() {
		return visuallyRecorded;
	}

	public void setVisuallyRecorded(String visuallyRecorded) {
		this.visuallyRecorded = visuallyRecorded;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getIsUploadedStatment() {
		return isUploadedStatment;
	}

	public void setIsUploadedStatment(String isUploadedStatment) {
		this.isUploadedStatment = isUploadedStatment;
	}

	public String getNoofPages() {
		return noofPages;
	}

	public void setNoofPages(String noofPages) {
		this.noofPages = noofPages;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getStatementDescription() {
		return statementDescription;
	}

	public void setStatementDescription(String statement) {
		this.statementDescription = statement;
	}

	public Date getStatementDateTime() {
		return statementDateTime;
	}

	public void setStatementDateTime(Date statementDateTime) {
		this.statementDateTime = statementDateTime;
	}

	public byte[] getStatementFile() {
		return statementFile;
	}

	public void setStatementFile(byte[] statementFile) {
		this.statementFile = statementFile;
	}

	public String getStatementFileType() {
		return statementFileType;
	}

	public void setStatementFileType(String statementFileType) {
		this.statementFileType = statementFileType;
	}

	public Long getStatementId() {
		return statementId;
	}

	public void setStatementId(Long statementId) {
		this.statementId = statementId;
	}

	public String getStatementOf() {
		return statementOf;
	}

	public void setStatementOf(String statementOf) {
		this.statementOf = statementOf;
	}

	public Witness getWitness() {
		return witness;
	}

	public void setWitness(Witness witness) {
		this.witness = witness;
	}

	public String getWitnessedBy() {
		return witnessedBy;
	}

	public void setWitnessedBy(String witnessedBy) {
		this.witnessedBy = witnessedBy;
	}

	public String getWitnessSignature() {
		return witnessSignature;
	}

	public void setWitnessSignature(String witnessSignature) {
		this.witnessSignature = witnessSignature;
	}

	public String getUrn1() {
		return urn1;
	}

	public void setUrn1(String urn1) {
		this.urn1 = urn1;
	}

	public String getUrn2() {
		return urn2;
	}

	public void setUrn2(String urn2) {
		this.urn2 = urn2;
	}

	public String getUrn3() {
		return urn3;
	}

	public void setUrn3(String urn3) {
		this.urn3 = urn3;
	}

	public String getUrn4() {
		return urn4;
	}

	public void setUrn4(String urn4) {
		this.urn4 = urn4;
	}

	public String getStatementSignature() {
		return statementSignature;
	}

	public void setStatementSignature(String statementSignature) {
		this.statementSignature = statementSignature;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}
	
	/**
	 * @return Returns the updatedFlag.
	 */
	public String getUpdatedFlag() {
		return updatedFlag;
	}

	/**
	 * @param updatedFlag The updatedFlag to set.
	 */
	public void setUpdatedFlag(String updatedFlag) {
		//Defaulting to Yes always
		this.updatedFlag = updatedFlag;
	}

	public int getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(int partNumber) {
		this.partNumber = partNumber;
	}

}
