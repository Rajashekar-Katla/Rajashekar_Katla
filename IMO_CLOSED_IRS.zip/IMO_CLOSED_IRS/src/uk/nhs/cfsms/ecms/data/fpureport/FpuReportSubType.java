package uk.nhs.cfsms.ecms.data.fpureport;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
@Entity
@Table(name = "FPU_REPORT_SUB_TYPE_TBL")
@Audited
public class FpuReportSubType implements Serializable{
	
	@Id
	@Column(name = "SUB_TYPE_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "FPU_REPORT_SUB_TYPE_ID_SQNC") })
	private Long subTypeId;
	
	@Column(name = "FPU_REPORT_ID")
	private Long fpuReportId;
	
	@Column(name = "lookup_id")
	@DisplayedLoggedProperty(displayName = "Description", isList = true)
	private Long lookupId;
	
	@Column(name = "TYPE_NAME")
	@DisplayedLoggedProperty(displayName = "Type")
	private String typeName;

	
	public Long getLookupId() {
		return lookupId;
	}

	public void setLookupId(Long lookupId) {
		this.lookupId = lookupId;
	}

	public Long getFpuReportId() {
		return fpuReportId;
	}

	public void setFpuReportId(Long fpuReportId) {
		this.fpuReportId = fpuReportId;
	}

	public Long getSubTypeId() {
		return subTypeId;
	}

	public void setSubTypeId(Long subTypeId) {
		this.subTypeId = subTypeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	
	
	
	

}
