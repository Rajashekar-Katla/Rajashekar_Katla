package uk.nhs.cfsms.ecms.data.infoGath;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "PERSON_DESCRIPTION_TBL")
/**
 * PersonDescription contain description details
 * 
 * @author schilukuri
 * 
 */
@Audited
public class PersonDescription implements Serializable {

	private static final long serialVersionUID = 156746L;

	@Id
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { 
			@Parameter(name = "sequence", value = "PERSON_DESC_ID_SQNC") })
			
	@Column(name = "PERSON_DESCRIPTION_ID")
	private Integer personDescriptionId;

	@Column(name = "HEIGHT")
	@DisplayedLoggedProperty(displayName="Height")
	private String height;

	@Column(name = "HAIR_COLOUR")
	@DisplayedLoggedProperty(displayName="Hair Colour")
	private String hairColour;

	@Column(name = "HAIR_STYLE")
	@DisplayedLoggedProperty(displayName="Hair Style")
	private String hairStyle;
	
	@Column(name = "OTHER_HAIR")
	@DisplayedLoggedProperty(displayName="Other Hair")
	private String otherHair;	

	@Column(name = "FACIAL_HAIR")
	@DisplayedLoggedProperty(displayName="Facial Hair")
	private String facialHair;

	@Column(name = "OTHER_FACIAL_HAIR")
	@DisplayedLoggedProperty(displayName="Other Facial Hair")
	private String otherFacialHair;

	@Column(name = "BODY_TYPE")
	@DisplayedLoggedProperty(displayName="Body Type")
	private String bodyType;

	@Column(name = "OTHER_BODY_TYPE")
	@DisplayedLoggedProperty(displayName="Other Body Type")
	private String otherBodyType;

	@Column(name = "EYE_COLOUR")
	@DisplayedLoggedProperty(displayName="Eye Colour")
	private String eyeColour;

	@Column(name = "OTHER_EYE_COLOUR")
	@DisplayedLoggedProperty(displayName="Other Eye Colour")
	private String otherEyeColour;

	@Column(name = "HAIR_TYPE")
	@DisplayedLoggedProperty(displayName="Hair Type")
	private String hairType;

	@Column(name = "OTHER_HAIR_TYPE")
	@DisplayedLoggedProperty(displayName="Other Hair Type")
	private String otherHairType;

	@Column(name = "HAIR_DESCRIPTION")
	@DisplayedLoggedProperty(displayName="Hair Description")
	private String hairDescription;

	@Column(name = "OTHER_HAIR_DESCRIPTION")
	@DisplayedLoggedProperty(displayName="Other Hair Description")
	private String otherHairDescription;

	@Column(name = "MARKS")
	@DisplayedLoggedProperty(displayName="Marks")
	private String marks;

	@Column(name = "FEATURES")
	@DisplayedLoggedProperty(displayName="Features")
	private String features;

	@Column(name = "ADDITIONAL_INFORMATION")
	@DisplayedLoggedProperty(displayName="Addiotional Information")
	private String additionalInformation;

	
	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}

	public String getEyeColour() {
		return eyeColour;
	}

	public void setEyeColour(String eyeColour) {
		this.eyeColour = eyeColour;
	}

	public String getFacialHair() {
		return facialHair;
	}

	public void setFacialHair(String facialHair) {
		this.facialHair = facialHair;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	public String getHairColour() {
		return hairColour;
	}

	public void setHairColour(String hairColour) {
		this.hairColour = hairColour;
	}

	public String getHairDescription() {
		return hairDescription;
	}

	public void setHairDescription(String hairDescription) {
		this.hairDescription = hairDescription;
	}

	public String getHairStyle() {
		return hairStyle;
	}

	public void setHairStyle(String hairStyle) {
		this.hairStyle = hairStyle;
	}

	public String getHairType() {
		return hairType;
	}

	public void setHairType(String hairType) {
		this.hairType = hairType;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getMarks() {
		return marks;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}

	public String getOtherBodyType() {
		return otherBodyType;
	}

	public void setOtherBodyType(String otherBodyType) {
		this.otherBodyType = otherBodyType;
	}

	public String getOtherEyeColour() {
		return otherEyeColour;
	}

	public void setOtherEyeColour(String otherEyeColour) {
		this.otherEyeColour = otherEyeColour;
	}

	public String getOtherFacialHair() {
		return otherFacialHair;
	}

	public void setOtherFacialHair(String otherFacialHair) {
		this.otherFacialHair = otherFacialHair;
	}

	public String getOtherHair() {
		return otherHair;
	}

	public void setOtherHair(String otherHair) {
		this.otherHair = otherHair;
	}

	public String getOtherHairDescription() {
		return otherHairDescription;
	}

	public void setOtherHairDescription(String otherHairDescription) {
		this.otherHairDescription = otherHairDescription;
	}

	public String getOtherHairType() {
		return otherHairType;
	}

	public void setOtherHairType(String otherHairType) {
		this.otherHairType = otherHairType;
	}

	public Integer getPersonDescriptionId() {
		return personDescriptionId;
	}

	public void setPersonDescriptionId(Integer personDescriptionId) {
		this.personDescriptionId = personDescriptionId;
	}

	
}
