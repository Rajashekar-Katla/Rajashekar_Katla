package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity

@Table(name="ORGANISATIONS_TBL")

/**
 * Organisation contain organisation and region code details
 * 
 * @author schilukuri
 * 
 */
@Audited
public class Organisation implements Serializable {
	
	private static final long serialVersionUID = 476534001L;

	@Id
	@Column(name="ORG_CODE")
	private String orgCode;	
	
	@Column(name="REGION_CODE")
	@DisplayedLoggedProperty(displayName = "Region Code")
	private String regionCode;
	
	@Column(name="ORG_NAME")
	@DisplayedLoggedProperty(displayName = "Organisation Name")
	private String orgName;
	
	@Column(name="ADDRESS1")
	@DisplayedLoggedProperty(displayName = "Address1")
	private String address1;
	
	@Column(name="ADDRESS2")
	@DisplayedLoggedProperty(displayName = "Address2")
	private String address2;
	
	@Column(name="ADDRESS3")
	@DisplayedLoggedProperty(displayName = "Address3")
	private String address3;
	
	@Column(name="ADDRESS4")
	@DisplayedLoggedProperty(displayName = "Address4")
	private String address4;
	
	@Column(name="ADDRESS5")
	@DisplayedLoggedProperty(displayName = "Address5")
	private String address5;
	
	@Column(name="POSTCODE")
	@DisplayedLoggedProperty(displayName = "Postcode")
	private String postCode;
	
	@Column(name="OPEN_DATE")
	@DisplayedLoggedProperty(displayName = "Open Date")
	private String openDate;
	
	@Column(name="CLOSE_DATE")
	@DisplayedLoggedProperty(displayName = "Close Date")
	private String closeDate;
	
	@Column(name="STATUS_CODE")
	private String statusCode;

	
	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getAddress5() {
		return address5;
	}

	public void setAddress5(String address5) {
		this.address5 = address5;
	}

	public String getCloseDate() {
		return closeDate;
	}

	public void setCloseDate(String closeDate) {
		this.closeDate = closeDate;
	}

	public String getOpenDate() {
		return openDate;
	}

	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
}
