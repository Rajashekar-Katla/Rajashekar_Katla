package uk.nhs.cfsms.ecms.data.common;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USER_HISTORY_TBL")
public class UserHistory implements Serializable {

	private static final long serialVersionUID = 805191705984L;

	@Id
	@Column(name = "STAFF_ID")
	private String staffId;

	@Column(name = "PREV_PASSWORD_UPDATE")
	private Date passwordUpdatedOn;

	@Column(name = "LAST_LOGGED_IN")
	private Date currentLoggedOn;

	@Column(name = "PREVIOUS_LOGGED_IN")
	private Date lastLoggedOn;


	public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public Date getPasswordUpdatedOn() {
		return passwordUpdatedOn;
	}

	public void setPasswordUpdatedOn(Date passwordUpdatedOn) {
		this.passwordUpdatedOn = passwordUpdatedOn;
	}

	public Date getCurrentLoggedOn() {
		return currentLoggedOn;
	}

	public void setCurrentLoggedOn(Date currentLoggedOn) {
		this.currentLoggedOn = currentLoggedOn;
	}

	public Date getLastLoggedOn() {
		return lastLoggedOn;
	}

	public void setLastLoggedOn(Date lastLoggedOn) {
		this.lastLoggedOn = lastLoggedOn;
	}
}
