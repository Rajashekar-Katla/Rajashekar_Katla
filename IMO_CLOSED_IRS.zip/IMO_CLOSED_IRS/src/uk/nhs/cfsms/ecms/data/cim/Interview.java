package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.Filters;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.IndexColumn;
import org.hibernate.annotations.ParamDef;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;


@Entity
@Table(name = "INTERVIEW_TBL")
@FilterDef(name="forCases", parameters=@ParamDef( name="caseIDParam", type="long" ) )
@Filters( {
    @Filter(name="forCases", condition=":caseIDParam = case_id")
} )
@Audited
public class Interview implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="INTERVIEW_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "INTERVIEW_ID_SQNC") })		
	private Long interviewId;
	
	@Column(name="CASE_ID")
	private Long caseId;
	
	@Column(name="INTERVIEWEE")
	@DisplayedLoggedProperty(displayName = "Interviewee")
	private String interviewee;
	
	@Column(name="PLACE")
	@DisplayedLoggedProperty(displayName = "Place")
	private String place;
	
	@Column(name="DATE_OF_INTERVIEW")
	@DisplayedLoggedProperty(displayName = "Date Of Interview")
	private Date date;
	
	@Column(name="TIME_OF_INTERVIEW")
	@DisplayedLoggedProperty(displayName = "Time Of Interview")
	private String time;
	
	@Column(name="DURATION")	
	@DisplayedLoggedProperty(displayName = "Duration")
	private String duration;
	
	@Column(name="AUDIO_TAPE_REF")
	@DisplayedLoggedProperty(displayName = "Audio Tape Reference Number")
	private String audioTapeReferenceNumber;
	
	@Column(name="INTERVIEWERS")
	@DisplayedLoggedProperty(displayName = "Interviewers")
	private String interviewers;
	
	@Column(name="OTHER_PERSONS_PRESENT")
	@DisplayedLoggedProperty(displayName = "Other Persons Present")
	private String otherPersonsPresent;
	
	@Column(name="EXHIBIT_NO")
	@DisplayedLoggedProperty(displayName = "Exhibit Number")
	private String exhibitNumber;
	
	@Column(name="TIME_CONCLUDED")	
	@DisplayedLoggedProperty(displayName = "Time Concluded")
	private String timeConcluded;
	
	@Column(name="VISUAL_IMG_REF")	
	private String visualImageReferenceNumber;
	   
	@IndexColumn(name="INTERVIEW_CONTENT_ID")
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="INTERVIEW_ID", insertable = true, updatable = true)
	private List<InterviewContent> interviewContents;
	
	@Column(name="MG_16_FORM")
	@Lob
	private byte[] mg16Form;
	
	@Column(name="UPLOADED")
	private char uploaded = 'N';
	
	@Column(name = "CREATED_TIME", updatable = false)
	private Timestamp createdDate;

	@Column(name = "CREATED_STAFF_ID", updatable = false)
	private String createdStaffId;
	
	@Column(name="FILE_TYPE")
	@DisplayedLoggedProperty(displayName = "File Type")
	private String fileType;
	
	@Column(name="FILE_NAME")
	@DisplayedLoggedProperty(displayName = "File Name")
	private String fileName;
	
	/**
	 * @return Returns the interviewId.
	 */
	public Long getInterviewId() {
		return interviewId;
	}

	/**
	 * @param interviewId The interviewId to set.
	 */
	public void setInterviewId(Long interviewId) {
		this.interviewId = interviewId;
	}

	/**
	 * @return Returns the audioTapeReferenceNumber.
	 */
	public String getAudioTapeReferenceNumber() {
		return audioTapeReferenceNumber;
	}

	/**
	 * @param audioTapeReferenceNumber The audioTapeReferenceNumber to set.
	 */
	public void setAudioTapeReferenceNumber(String audioTapeReferenceNumber) {
		this.audioTapeReferenceNumber = audioTapeReferenceNumber;
	}

	/**
	 * @return Returns the date.
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param date The date to set.
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return Returns the duration.
	 */
	public String getDuration() {
		return duration;
	}

	/**
	 * @param duration The duration to set.
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}

	/**
	 * @return Returns the exhibitNumber.
	 */
	public String getExhibitNumber() {
		return exhibitNumber;
	}

	/**
	 * @param exhibitNumber The exhibitNumber to set.
	 */
	public void setExhibitNumber(String exhibitNumber) {
		this.exhibitNumber = exhibitNumber;
	}

	/**
	 * @return Returns the interviewee.
	 */
	public String getInterviewee() {
		return interviewee;
	}

	/**
	 * @param interviewee The interviewee to set.
	 */
	public void setInterviewee(String interviewee) {
		this.interviewee = interviewee;
	}

	/**
	 * @return Returns the interviewers.
	 */
	public String getInterviewers() {
		return interviewers;
	}

	/**
	 * @param interviewers The interviewers to set.
	 */
	public void setInterviewers(String interviewers) {
		this.interviewers = interviewers;
	}

	/**
	 * @return Returns the otherPersonsPresent.
	 */
	public String getOtherPersonsPresent() {
		return otherPersonsPresent;
	}

	/**
	 * @param otherPersonsPresent The otherPersonsPresent to set.
	 */
	public void setOtherPersonsPresent(String otherPersonsPresent) {
		this.otherPersonsPresent = otherPersonsPresent;
	}

	/**
	 * @return Returns the place.
	 */
	public String getPlace() {
		return place;
	}

	/**
	 * @param place The place to set.
	 */
	public void setPlace(String place) {
		this.place = place;
	}

	/**
	 * @return Returns the time.
	 */
	public String getTime() {
		return time;
	}

	/**
	 * @param time The time to set.
	 */
	public void setTime(String time) {
		this.time = time;
	}

	/**
	 * @return Returns the timeConcluded.
	 */
	public String getTimeConcluded() {
		return timeConcluded;
	}

	/**
	 * @param timeConcluded The timeConcluded to set.
	 */
	public void setTimeConcluded(String timeConcluded) {
		this.timeConcluded = timeConcluded;
	}

	/**
	 * @return Returns the visualImageReferenceNumber.
	 */
	public String getVisualImageReferenceNumber() {
		return visualImageReferenceNumber;
	}

	/**
	 * @param visualImageReferenceNumber The visualImageReferenceNumber to set.
	 */
	public void setVisualImageReferenceNumber(String visualImageReferenceNumber) {
		this.visualImageReferenceNumber = visualImageReferenceNumber;
	}

	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the interviewContents.
	 */
	public List<InterviewContent> getInterviewContents() {
		return interviewContents;
	}

	/**
	 * @param interviewContents The interviewContents to set.
	 */
	public void setInterviewContents(List<InterviewContent> interviewContents) {
		this.interviewContents = interviewContents;
	}

	/**
	 * @return Returns the mg16Form.
	 */
	public byte[] getMg16Form() {
		return mg16Form;
	}

	/**
	 * @param mg16Form The mg16Form to set.
	 */
	public void setMg16Form(byte[] mg16Form) {
		this.mg16Form = mg16Form;
	}

	/**
	 * @return Returns the uploaded.
	 */
	public char getUploaded() {
		return uploaded;
	}

	/**
	 * @param uploaded The uploaded to set.
	 */
	public void setUploaded(char uploaded) {
		this.uploaded = uploaded;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
		
	
}
