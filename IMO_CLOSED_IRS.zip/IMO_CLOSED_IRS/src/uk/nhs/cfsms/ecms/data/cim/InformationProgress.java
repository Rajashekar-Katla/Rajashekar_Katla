package uk.nhs.cfsms.ecms.data.cim;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Formula;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;

@Entity
@Table(name = "INFORMATION_PROGRESS_TBL")
@Audited
public class InformationProgress implements Serializable {

	@Transient
	private static final long serialVersionUID = 4938871235L;

	@Id
	@Column(name = "INFORMATION_PROGRESS_ID")
	@GeneratedValue(generator = "sequence")
	@GenericGenerator(name = "sequence", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "INFORMATION_PROGRESS_ID_SQNC") })
	private Long informationProgressId;

	@Column(name = "TYPE")
	@DisplayedLoggedProperty(displayName = "Type")
	private String type;

	@Column(name = "DESCRIPTION")
	@Type(type = "uk.nhs.cfsms.ecms.userdatatype.StringClobType")
	@DisplayedLoggedProperty(displayName = "Description")
	private String description;

	@Column(name = "RECORDED_BY")
	private String recordedBy;

	@Column(name = "DATE_OF_EVENT")
	@DisplayedLoggedProperty(displayName = "Date of Event")
	private Date dateOfEvent;

	@Column(name = "DATE_RECORDED")
	private Date dateRecorded;

	@Column(name = "MINUTE_NO")
	@DisplayedLoggedProperty(displayName = "Minute Number")
	private Long minuteNumber;

	@Column(name = "INFORMATION_ID")
	private Long informationId;

	@Column(name = "CREATED_TIME", insertable = true, updatable = false)
	private Date createdTime;

	@Column(name = "CREATED_STAFF_ID", insertable = true, updatable = false)
	private String createdStaffId;

	/**
	 * @return the informationProgressId
	 */
	public Long getInformationProgressId() {
		return informationProgressId;
	}

	/**
	 * @param informationProgressId
	 *            the informationProgressId to set
	 */
	public void setInformationProgressId(Long informationProgressId) {
		this.informationProgressId = informationProgressId;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the recordedBy
	 */
	public String getRecordedBy() {
		return recordedBy;
	}

	/**
	 * @param recordedBy
	 *            the recordedBy to set
	 */
	public void setRecordedBy(String recordedBy) {
		this.recordedBy = recordedBy;
	}

	/**
	 * @return the dateOfEvent
	 */
	public Date getDateOfEvent() {
		return dateOfEvent;
	}

	/**
	 * @param dateOfEvent
	 *            the dateOfEvent to set
	 */
	public void setDateOfEvent(Date dateOfEvent) {
		this.dateOfEvent = dateOfEvent;
	}

	/**
	 * @return the dateRecorded
	 */
	public Date getDateRecorded() {
		return dateRecorded;
	}

	/**
	 * @param dateRecorded
	 *            the dateRecorded to set
	 */
	public void setDateRecorded(Date dateRecorded) {
		this.dateRecorded = dateRecorded;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	/**
	 * @return the createdTime
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime
	 *            the createdTime to set
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return the createdStaffId
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public Long getMinuteNumber() {
		return minuteNumber;
	}

	public void setMinuteNumber(Long minuteNumber) {
		this.minuteNumber = minuteNumber;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

}
