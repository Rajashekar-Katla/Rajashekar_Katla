package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.CIUMessagesReceiverDao;
import uk.nhs.cfsms.ecms.data.common.CIUMessagesReceiver;
import uk.nhs.cfsms.ecms.service.CIUMessagesReceiverService;

@Service(value = "ciuMessagesReceiverService")
@Transactional
public class CIUMessagesReceiverServiceImpl implements
		CIUMessagesReceiverService {

	@Autowired
	CIUMessagesReceiverDao ciuMessageReceiverRepository;

	@Override
	public String getActiveStaffId() {
		return ciuMessageReceiverRepository.getActiveStaffId();
	}

	@Override
	public void activateUserToReceiveMessages(String staffId) {
		ciuMessageReceiverRepository.activateUserToReceiveMessages(staffId);

	}

	@Override
	public Map<String, String> getAllCIUMessagesReceivers() {
		final List<CIUMessagesReceiver> list = ciuMessageReceiverRepository
				.getAllCIUMessageReceivers();

		final Map<String, String> map = new HashMap<String, String>();

		for (final CIUMessagesReceiver imo : list) {
			final String staffId = imo.getCiuStaffId();
			final String status = imo.getStatus();
			map.put(staffId, status);
		}
		return map;
	}

}
