package uk.nhs.cfsms.ecms.serviceimpl;

import java.lang.reflect.InvocationTargetException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.AppealHearingDao;
import uk.nhs.cfsms.ecms.dao.CivilAppealDao;
import uk.nhs.cfsms.ecms.dao.CivilSanctionDao;
import uk.nhs.cfsms.ecms.dao.CourtAppearanceDao;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppeal;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppealOutcome;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppealView;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanction;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionOutcome;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionTO;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionView;
import uk.nhs.cfsms.ecms.data.sanction.AppealHearing;
import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealOutcomeTO;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealAndSanctionOutcome;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealTO;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealsAndOutcomes;
import uk.nhs.cfsms.ecms.dto.civilsanction.LatestOutComeComaprator;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.CivilSanctionService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;


@Service(value = "civilSanctionFacade")
@Transactional
public class CivilSanctionServiceImpl extends BaseServiceImpl implements
		CivilSanctionService {

	@Autowired
	private CivilSanctionDao civilSanctionDao;
	@Autowired
	private CourtAppearanceDao courtAppearanceDao;
	@Autowired
	private CivilAppealDao civilAppealDAO;
	@Autowired
	private CivilSanctionDao sanctionDAO;
	@Autowired
	private AppealHearingDao appealHearingDAO;

	public void setSanctionDAO(CivilSanctionDao sanctionDAO) {
		this.sanctionDAO = sanctionDAO;
	}

 	public void setAppealHearingDAO(AppealHearingDao appealHearingDAO) {
		this.appealHearingDAO = appealHearingDAO;
	}

 	public void setCivilAppealDAO(CivilAppealDao civilAppealDAO) {
		this.civilAppealDAO = civilAppealDAO;
	}

	public List<CivilSanctionTO> loadCivilSanctions(Long caseId)
			throws ServiceException {

		List<CivilSanctionView> views = civilSanctionDao.loadCivilSanctions(caseId);
		 
		List<CivilSanctionTO> res = new ArrayList<CivilSanctionTO>();
		try {
			for (CivilSanctionView view : views) {
				
				CivilSanctionTO csTO = convertToTransferObject(view);
				res.add(csTO);
			}
		} catch (ServiceException se) {
			throw se;
		}
		return res;
	}

	public List<CivilSanctionTO> loadCivilSanctionsForReport(Long caseId)
			throws ServiceException {

		List<CivilSanctionView> views = civilSanctionDao
				.loadCivilSanctions(caseId);
		
		List<CivilSanctionTO> res = new ArrayList<CivilSanctionTO>();
		try {
			for (CivilSanctionView view : views) {
				
				CivilSanctionTO csTO = convertToTransferObject(view);
				csTO.setCourtAppearanceList(courtAppearanceDao
						.loadCourtAppearancesByType(csTO.getCivilSanctionId(),
								"civll"));
				csTO.setOutcome(loadCivilSanctionOutcome(csTO
						.getCivilSanctionId()));
				
				res.add(csTO);
			}
		} catch (ServiceException se) {
			throw se;
		}
		return res;

	}

	@Override
	public void deleteObject(Object o) throws ServiceException {
		if (o.getClass().isAssignableFrom(CivilSanctionView.class)) {
			CivilSanctionView c = (CivilSanctionView) o;
			try {
				super.deleteObject(c);
			} catch (ServiceException se) {
				throw se;
			}
		}
		if (o.getClass().isAssignableFrom(CivilSanctionTO.class)) {
			CivilSanctionTO c = (CivilSanctionTO) o;
			CivilSanction cs = convertToDataObject(c);
			super.deleteObject(cs);
		} else {
			super.deleteObject(o);
		}
	}

	@Override
	public void evictObject(Object o) throws ServiceException {
		CivilSanctionTO csto = (CivilSanctionTO) o;
		try {
			CivilSanction csdo = convertToDataObject(csto);
			super.evictObject(csdo);
		} catch (ServiceException se) {
			throw se;
		}

	}

	@Override
	public Object getObject(Class thisClass, Long id) throws ServiceException {

		if (thisClass.isAssignableFrom(CivilSanctionView.class)) {
			CivilSanctionView view = (CivilSanctionView) civilSanctionDao
					.getObject(CivilSanctionView.class, id);
			CivilSanctionTO csto = convertToTransferObject(view);
			return csto;
		}
		if (thisClass.isAssignableFrom(CivilSanctionTO.class)) {

			CivilSanction cs = (CivilSanction) civilSanctionDao.getObject(
					CivilSanction.class, id);
			CivilSanctionTO csto = convertToTransferObject(cs);
			return csto;

		} else {

			return civilSanctionDao.getObject(thisClass, id);
		}

	}

	@Override
	public List getObjects(Class thisClass) throws ServiceException {

		List<CivilSanctionView> views = super.getObjects(CivilSanctionView.class);

		List<CivilSanctionTO> sanctionList = new ArrayList<CivilSanctionTO>();

		for (CivilSanctionView csview : views) {

			sanctionList.add(convertToTransferObject(csview));
		}

		return sanctionList;

	}

	@Override
	public void saveObject(Object o) throws ServiceException {
		Object obj = o;
		if (o instanceof CivilSanctionTO) {
			CivilSanctionTO to = (CivilSanctionTO) o;
			obj = convertToDataObject(to);
		} else if (o instanceof CivilAppealTO) {
			obj = convertAppealTO((CivilAppealTO) o);
		} else if (o instanceof CivilAppealOutcomeTO) {
			obj = saveAppealOutcome((CivilAppealOutcomeTO) o);
		}
		super.saveObject(obj);
	}

	private CivilAppealOutcome saveAppealOutcome(CivilAppealOutcomeTO outcomeTO) {

		CivilAppealOutcome outcome = new CivilAppealOutcome();

		try {
			BeanUtils.copyProperties(outcome, outcomeTO);

			CivilAppeal appeal = (CivilAppeal) super.getObject(
					CivilAppeal.class, outcomeTO.getAppealID());
			appeal.setState(outcomeTO.getOutcomeStatus());
			outcome.setForAppeal(appeal);

			if (outcome.getOutcomeId() == null || outcome.getOutcomeId() == 0) {

				outcome.setCreatedTime(new Date());
				outcome.setCreatedStaffId(EcmsUtils.getPrincipal()
						.getUsername());
			} else {

				CivilAppealOutcome appOutcome = (CivilAppealOutcome) super
						.getObject(CivilAppealOutcome.class,
								outcomeTO.getOutcomeId());
				outcome.setCreatedTime(appOutcome.getCreatedTime());
				outcome.setCreatedStaffId(appOutcome.getCreatedStaffId());
			}

			return outcome;

		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}

	}

	private CivilAppeal convertAppealTO(CivilAppealTO appealTO) {
		
		CivilAppeal appeal = new CivilAppeal();
		try {
			BeanUtils.copyProperties(appeal, appealTO);
			
			if (appeal.getAppealId() == null) {
				
				appeal.setCreatedTime(new java.sql.Date(new Date().getTime()));
				appeal.setCreatedStaffId(EcmsUtils.getPrincipal()
						.getUsername());
			}
			appeal.setSanction((CivilSanction) sanctionDAO.getObject(
					CivilSanction.class, appealTO.getSanctionId()));
			
		} catch (IllegalAccessException e) {

			e.printStackTrace();
		} catch (InvocationTargetException e) {

			e.printStackTrace();
		}
		return appeal;
	}

	@Override
	public void saveObjects(List objects) throws ServiceException {

		List<CivilSanction> list = new ArrayList<CivilSanction>();
		
		Iterator it = objects.iterator();
		
		while (it.hasNext()) {
		
			CivilSanctionTO csto = (CivilSanctionTO) it.next();
			
			CivilSanction csdo = convertToDataObject(csto);
			list.add(csdo);
		}

		super.saveObjects(list);
	}

	public CivilSanctionOutcome loadCivilSanctionOutcome(Long civilSanctionId) {

		return civilSanctionDao.loadCivilSanctionOutcome(civilSanctionId);

	}

	private CivilSanctionTO convertToTransferObject(
			CivilSanction civilSanctionDO) throws ServiceException {

		CivilSanctionTO csTO = new CivilSanctionTO();
		if (civilSanctionDO.getClaimAmount() == null) {
			civilSanctionDO.setClaimAmount(new BigDecimal(0));
		}
		try {
			BeanUtils.copyProperties(csTO, civilSanctionDO);
			if (civilSanctionDO.getCaseId() == null) {
				csTO.setCaseId(null);
			}
			if (civilSanctionDO.getCivilSanctionId() == null) {
				csTO.setCivilSanctionId(null);
			}
			if (civilSanctionDO.getSubjectId() == null) {
				csTO.setSubjectId(null);
			}

		} catch (InvocationTargetException iae) {
			throw new ServiceException(iae);
		} catch (IllegalAccessException e) {
			throw new ServiceException(e);
		}

		return csTO;

	}

	private CivilAppealTO convertAppealtoTO(Object appeal) {
	
		CivilAppealTO to = null;
		
		try {
		
			if (appeal != null) {
			
				to = new CivilAppealTO();
				
				BeanUtils.copyProperties(to, appeal);
				
				if (appeal instanceof CivilAppealView) {
					to.setSanctionId(((CivilAppealView) appeal).getSanction()
							.getCivilSanctionId());
				} else if (appeal instanceof CivilAppeal) {
					to.setSanctionId(((CivilAppeal) appeal).getSanction()
							.getCivilSanctionId());
				}
				Long appealedID = to.getAppealedId();
				String appealedOutcomeType = to.getAppealedOutcomeType();
				CivilAppealAndSanctionOutcome previousOutcome = retrieveOutcome(
						appealedID, appealedOutcomeType);
				to.setPreviousOutcome(previousOutcome);
			}
		} catch (IllegalAccessException e) {

			e.printStackTrace();
		} catch (InvocationTargetException e) {

			e.printStackTrace();
		}

		return to;
	}

	private CivilSanctionTO convertToTransferObject(CivilSanctionView view)
			throws ServiceException {
		
		CivilSanctionTO csTO = new CivilSanctionTO();
		try {
			BeanUtils.copyProperties(csTO, view);
			if (view.getCaseId() == null) {
				csTO.setCaseId(null);
			}
			if (view.getCivilSanctionId() == null) {
				csTO.setCivilSanctionId(null);
			}
			if (view.getSubjectId() == null) {
				csTO.setSubjectId(null);
			}

		} catch (InvocationTargetException iae) {
			throw new ServiceException(iae);
		} catch (IllegalAccessException e) {
			throw new ServiceException(e);
		}

		return csTO;

	}

	private CivilSanction convertToDataObject(CivilSanctionTO civilSanctionTO)
			throws ServiceException {

		CivilSanction csDO = new CivilSanction();
		try {
			if (civilSanctionTO.getClaimAmount() == null) {
				civilSanctionTO.setClaimAmount(new BigDecimal(0));
			}
			BeanUtils.copyProperties(csDO, civilSanctionTO);
			if (civilSanctionTO.getCaseId() == null) {
				csDO.setCaseId(null);
			}
			if (civilSanctionTO.getCivilSanctionId() == null) {
				csDO.setCivilSanctionId(null);
			}
			if (civilSanctionTO.getSubjectId() == null) {
				csDO.setSubjectId(null);
			}

		} catch (InvocationTargetException iae) {
			throw new ServiceException(iae);
		} catch (IllegalAccessException e) {
			throw new ServiceException(e);
		}

		return csDO;

	}

	public CourtAppearanceDao getCourtAppearanceDao() {
		return courtAppearanceDao;
	}

	public void setCourtAppearanceDao(CourtAppearanceDao courtAppearanceDao) {
		this.courtAppearanceDao = courtAppearanceDao;
	}

	public List<CivilAppealTO> loadAppealsForCase(Long caseId) {

		List<CivilAppealTO> res = null;
		List<CivilAppealView> views = civilAppealDAO
				.loadCivilAppealsByCaseId(caseId);
		if (views != null) {

			res = new ArrayList<CivilAppealTO>();

			for (CivilAppealView appealView : views) {

				res.add(convertAppealtoTO(appealView));
			}
		}
		return res;
	}

	@Override
	public Map<String, List> loadSanctionsAndAppeals(Long caseId) {

		Map<String, List> resultMap = new HashMap<String, List>();
		try {
			List<CivilSanctionTO> sanctionList = loadCivilSanctions(caseId);
			List<CivilAppealTO> appealsList = loadAppealsForCase(caseId);
			resultMap.put("sanctions", sanctionList);
			resultMap.put("appeals", appealsList);

		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return resultMap;
	}

	public List<CivilSanctionOutcome> loadSanctionOutComesForCase(Long caseId) {
		return sanctionDAO.loadCivilSanctionOutcomeForCase(caseId);
	}

	public List<CivilAppealOutcome> loadAppealOutcomesForCase(Long caseID) {
		return civilAppealDAO.loadAppealOuctomesForCaseID(caseID);
	}

	@Override
	public CivilAppealsAndOutcomes getAppealsAndOuctomesForCase(Long caseID)
			throws IllegalAccessException, InvocationTargetException {

		CivilAppealsAndOutcomes allOutcomes = new CivilAppealsAndOutcomes();
		List<CivilAppealOutcome> appealOutcomes = loadAppealOutcomesForCase(caseID);
		List<CivilSanctionOutcome> sanctionOutcomes = loadSanctionOutComesForCase(caseID);
		
		
		List<CivilAppealAndSanctionOutcome> outcomeList = allOutcomes.getOutcomeList();

		if (appealOutcomes != null && !appealOutcomes.isEmpty()) {

			for (CivilAppealOutcome curr : appealOutcomes) {
				
				CivilAppealOutcomeTO to = appealOutcomeToTO(curr);
				to.setCaseID(caseID);
				List list = civilAppealDAO.loadAppealsByParentAppealId(to
						.getAppealID());
				to.setAppealsExist((null != list && list.size() > 0) ? true
						: false);
				outcomeList.add(convertAppealTOAppealAndSanctionTO(to));
			}
		}
		
		if (sanctionOutcomes != null && !sanctionOutcomes.isEmpty()) {
			
			for (CivilSanctionOutcome curr : sanctionOutcomes) {
				
				CivilAppealAndSanctionOutcome outcome = convertSanctionTOAppealAndSanctionTO(curr);
				List list = sanctionDAO.loadAppealsByParentSanctionId(outcome
						.getSanctionId());
				
				outcome.setAppealsExist((null != list && list.size() > 0) ? true : false);
				
				outcomeList.add(outcome);
			}
		}
		Collections.sort(outcomeList, new LatestOutComeComaprator());
		Collections.reverse(outcomeList);

		List<CivilAppealTO> appeals = loadAppealsForCase(caseID);
		
		// Update setAppealExists to allow deletion of new appeals (leaf or child nodes).
		for (CivilAppealTO appealTO : appeals) {
			
			List list = civilAppealDAO.loadAppealsByParentAppealId(appealTO.getAppealId());
			
			appealTO.setAppealExists((null != list && list.size() > 0) ? true : false);
		}

		allOutcomes.setAppealsList(appeals);

		return allOutcomes;
	}
	

	private CivilAppealOutcomeTO appealOutcomeToTO(CivilAppealOutcome curr)
			throws IllegalAccessException, InvocationTargetException {
		
		CivilAppealOutcomeTO to = null;
		if (curr != null) {
			to = new CivilAppealOutcomeTO();
			BeanUtils.copyProperties(to, curr);
			to.setSanctionID(curr.getForAppeal().getSanction()
					.getCivilSanctionId());
			to.setSubjectName(curr.getAppealView().getSubjectName());
			to.setAppealID(curr.getForAppeal().getAppealId());
		}
		return to;
	}

	@Override
	public List<CivilAppealTO> loadCivilAppealsForCase(Long caseId) {
		return loadAppealsForCase(caseId);
	}


	@Override
	public CivilAppealTO loadCivilAppeal(Long appealID) throws Exception {
		
		CivilAppealView appealObj = (CivilAppealView) sanctionDAO.getObject(
				CivilAppealView.class, appealID);
		CivilAppealTO appealTO = convertAppealtoTO(appealObj);
		
		if (null == appealTO) {
			
			appealTO = new CivilAppealTO();
		}
		return appealTO;
	}

	@Override
	public CivilAppealTO loadCivilAppeal(CivilAppealTO appealTO)
			throws Exception {

		if (appealTO.getAppealId() == null || appealTO.getAppealId() == 0) {

			// Here try loading previous outcome
			Long appealedId = appealTO.getAppealedId();
			String appealedOutcomeType = appealTO.getAppealedOutcomeType();
			CivilAppealAndSanctionOutcome prevOutcome = retrieveOutcome(
					appealedId, appealedOutcomeType);
			appealTO.setPreviousOutcome(prevOutcome);
		} else {
			appealTO = loadCivilAppeal(appealTO.getAppealId());
		}
		return appealTO;
	}
	
	private CivilAppeal loadAppealByAppealId(Long appealId) throws ServiceException {
		
		CivilAppeal appeal = (CivilAppeal)sanctionDAO.getObject(CivilAppeal.class, appealId);
		
		return appeal;
	}

	private CivilAppealAndSanctionOutcome retrieveOutcome(Long appealedId,
			String appealedOutcomeType) throws IllegalAccessException,
			InvocationTargetException {
		
		CivilAppealAndSanctionOutcome prevOutcome = null;
		if (appealedId != null
				&& "APPEAL".equalsIgnoreCase(appealedOutcomeType)) {
			CivilAppealOutcome outcome = (CivilAppealOutcome) sanctionDAO
					.getObject(CivilAppealOutcome.class, appealedId);
			if (outcome != null) {
				prevOutcome = convertAppealTOAppealAndSanctionTO(appealOutcomeToTO(outcome));
			}
		} else if (appealedId != null
				&& "SANCTION".equalsIgnoreCase(appealedOutcomeType)) {
			CivilSanctionOutcome outcome = (CivilSanctionOutcome) sanctionDAO
					.getObject(CivilSanctionOutcome.class, appealedId);
			if (outcome != null) {
				prevOutcome = convertSanctionTOAppealAndSanctionTO(outcome);
			}
		}
		return prevOutcome;
	}

	private CivilAppealAndSanctionOutcome convertAppealTOAppealAndSanctionTO(
			CivilAppealOutcomeTO outcomeTO) {

		CivilAppealAndSanctionOutcome outcome = new CivilAppealAndSanctionOutcome();
		Long appealId = outcomeTO.getAppealID();
		outcome.setCaseId(outcomeTO.getCaseID());
		outcome.setDetailsOfOutcome(outcomeTO.getOrdersMade());
		outcome.setOutcomeStatus(outcomeTO.getOutcomeStatus());
		outcome.setOutcomeId(outcomeTO.getOutcomeId());
		outcome.setOutcomeDate(outcomeTO.getDateofOutcome());
		outcome.setSanctionId(outcomeTO.getSanctionID());
		outcome.setSubjectName(outcomeTO.getSubjectName());
		outcome.setOrdersMade(outcomeTO.getOrdersMade());
		
		outcome.setAppealId(appealId);
		// has child appeals ???
		outcome.setAppealsExist(outcomeTO.isAppealsExist());
		
		// work out the latest court name from the list of hearings
		AppealHearing latestHearing = appealHearingDAO.getLatestHearingByType(
				appealId, CaseUtil.APPLIED_SANCTION_TYPE.CIVIL_APPEAL.toString());

		if (null != latestHearing) {

			outcome.setFinalHearingCourtname(latestHearing.getCourtName());
		}

		outcome.setType("APPEAL");

		return outcome;
	}

	private CivilAppealAndSanctionOutcome convertSanctionTOAppealAndSanctionTO(CivilSanctionOutcome outcome) {

		CivilAppealAndSanctionOutcome out = new CivilAppealAndSanctionOutcome();

		out.setDetailsOfOutcome(outcome.getAppliedSanctions());
		out.setOutcomeId(outcome.getCivilSanctionOutcomeId());
		out.setOutcomeDate(outcome.getOutcomeDate());
		out.setOutcomeStatus(outcome.getOutcomeStatus());
		out.setSanctionId(outcome.getCivilSanctionId());
		out.setSubjectName(outcome.getSubjectName());
		out.setOrdersMade(outcome.getOutcomeDetails()); 

		CourtAppearance appearance = courtAppearanceDao
				.loadLatestCourtAppearanceBySanctionId(outcome
						.getCivilSanctionId());

		if (appearance != null) {

			out.setFinalHearingCourtname(appearance.getCourtName());
		}
		out.setType("SANCTION");

		return out;
	}

	@Override
	public CivilAppealOutcomeTO loadCivilAppealOutcome(Long appealID)
			throws Exception {
		
		CivilAppealOutcomeTO outcomeTO = new CivilAppealOutcomeTO();
		CivilAppealOutcome outcome = civilAppealDAO
				.loadAppealOutcomeForAppealID(appealID);
		
		if (null != outcome) {
			BeanUtils.copyProperties(outcomeTO, outcome);
			outcomeTO.setAppealID(outcome.getForAppeal().getAppealId());
		} else {
			CivilAppeal appeal = (CivilAppeal) getObject(CivilAppeal.class,
					appealID);
			outcomeTO.setSanctionID(appeal.getSanction().getCivilSanctionId());
			outcomeTO.setAppealID(appeal.getAppealId());
			outcomeTO.setCaseID(appeal.getSanction().getCaseId());
		}
		return outcomeTO;
	}

	@Override
	public List<CivilAppealOutcomeTO> loadAppealOutcomeForCivilSanctionId(
			Long civilSanctionId) throws Exception {
		
		CivilAppealOutcomeTO outcomeTO = new CivilAppealOutcomeTO();
		
		List<CivilAppealOutcomeTO> outcomeTOList = new ArrayList<CivilAppealOutcomeTO>();
		
		List<CivilAppealOutcome> outcomeBOList = civilAppealDAO
				.loadAppealOutcomeForCivilSanctionId(civilSanctionId);
		
		for (CivilAppealOutcome outcome : outcomeBOList) {
			
			if (null != outcome) {
				
				BeanUtils.copyProperties(outcomeTO, outcome);
				
				outcomeTO.setAppealID((null != outcome.getForAppeal()) ? outcome.getForAppeal().getAppealId() : null);
				
				outcomeTOList.add(outcomeTO);
			}
		}
		return outcomeTOList;
	}


	@Override
	public void saveAppeal(CivilAppealTO appealTO) throws Exception {
			
		CivilAppeal appeal = ConvertFromDTO.getInstance().convertFromDTO(appealTO);
		
		if (null != appealTO.getSanctionId()) {
		
			CivilSanction details = (CivilSanction)civilSanctionDao.getObject(CivilSanction.class, appealTO.getSanctionId());
			
			appeal.setSanction(details);
		}
		
		super.saveObject(appeal);
	}

	@Override
	public void deleteCivilAppeal(Long appealId) throws ServiceException {
		
		CivilAppealOutcome outcome = civilAppealDAO.loadAppealOutcomeForAppealID(appealId);
		
		List<AppealHearing> hearings =  appealHearingDAO.loadAppealHearingsByAppealId(appealId);
		
		CivilAppeal appeal =  this.loadAppealByAppealId(appealId);
		if(outcome != null){
			super.deleteObject(outcome);
		}
		if(hearings != null){
			super.deleteObjects(hearings);
		}
		super.deleteObject(appeal);
	}

}
