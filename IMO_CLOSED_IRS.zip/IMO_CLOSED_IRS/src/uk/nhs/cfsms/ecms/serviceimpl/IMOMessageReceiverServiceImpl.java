package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.IMOMessagesReceiverDao;
import uk.nhs.cfsms.ecms.data.common.IMOMessagesReceiver;
import uk.nhs.cfsms.ecms.service.IMOMessageReceiverService;

@Service(value = "imoMessagereceiverService")
@Transactional
public class IMOMessageReceiverServiceImpl implements IMOMessageReceiverService {

	@Autowired
	private IMOMessagesReceiverDao imoMessageReceiverRepository;
	
	@Override
	public String getActiveStaffId() {
		return imoMessageReceiverRepository.getActiveStaffId();
	}

	@Override
	public void activateUserToReceiveMessages(final String staffId) {
		imoMessageReceiverRepository.activateUserToReceiveMessages(staffId);

	}

	@Override
	public Map<String, String> getAllIMOMessageReceivers() {
		final List<IMOMessagesReceiver> list = imoMessageReceiverRepository
				.getAllIMOMessageReceivers();

		final Map<String, String> map = new HashMap<String, String>();

		for (final IMOMessagesReceiver imo : list) {
			final String staffId = imo.getImoStaffId();
			final String status = imo.getStatus();
			map.put(staffId, status);
		}
		return map;
	}

}
