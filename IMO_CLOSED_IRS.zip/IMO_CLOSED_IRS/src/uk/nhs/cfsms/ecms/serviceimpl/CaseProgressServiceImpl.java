package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.CaseProgressDao;
import uk.nhs.cfsms.ecms.data.cim.CaseProgress;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.CaseProgressService;

@Service(value="caseProgressFacade")
@Transactional
public class CaseProgressServiceImpl extends BaseServiceImpl implements
		CaseProgressService {

	@Autowired
	private CaseProgressDao caseProgressDao;
	
	@Override
	public Long generateMinuteNumber(Long caseId) throws ServiceException {
		return caseProgressDao.generateMinuteNumber(caseId);
	}
	
	@Override
	public Long generateMinuteNumber(Long caseId, String caseType) throws ServiceException {
		return caseProgressDao.generateMinuteNumber(caseId, caseType);
	}

	@Override
	public List<CaseProgress> loadCaseProgresses(Long caseId) throws ServiceException {

		return caseProgressDao.loadCaseProgresses(caseId);
	}

	@Override
	public List<CaseProgress> loadCaseProgressesByCaseByMinutes(Long caseId,
			String type, int startMin, int endMin) throws ServiceException {

		return caseProgressDao
				.loadCaseProgressesByCaseByMinutes(caseId, type, startMin,
						endMin);
	}

	@Override
	public List<CaseProgress> loadCaseProgresses(Long caseId, String type) throws ServiceException {

		return caseProgressDao
				.loadCaseProgresses(caseId, type);
	}

	@Override
	public List<CaseProgress> loadCaseProgresses(Long caseId,
			String progressSheetType, String sensitivity)
			throws ServiceException {
		
		return caseProgressDao.loadCaseProgresses(caseId, progressSheetType, sensitivity);
	}

	@Override
	public CaseProgress loadCaseProgressById(Long caseProgressId)
			throws ServiceException {
		
		return caseProgressDao.loadCaseProgressById(caseProgressId);
	}

	@Override
	public void deleteCaseProgress(Long caseProgressId) throws ServiceException {
		
		CaseProgress caseProgress = loadCaseProgressById(caseProgressId);
		this.deleteObject(caseProgress);
	} 

}
