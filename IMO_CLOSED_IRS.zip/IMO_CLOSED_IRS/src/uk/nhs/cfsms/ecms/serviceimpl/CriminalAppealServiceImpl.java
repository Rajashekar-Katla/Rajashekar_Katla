package uk.nhs.cfsms.ecms.serviceimpl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.AppealHearingDao;
import uk.nhs.cfsms.ecms.dao.CourtAppearanceDao;
import uk.nhs.cfsms.ecms.dao.CriminalAppealDao;
import uk.nhs.cfsms.ecms.data.sanction.AppealHearing;
import uk.nhs.cfsms.ecms.data.sanction.AppealOutcome;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppeal;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppealView;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.data.sanction.PoliceCharge;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalAppealTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.CriminalAppealService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;


@Service(value="criminalAppealFacade")
@Transactional
public class CriminalAppealServiceImpl extends BaseServiceImpl implements
		CriminalAppealService {

	@Autowired
	private CriminalAppealDao criminalAppealDao;
	
	@Autowired
	private AppealHearingDao appealHearingDao;
	
	@Autowired
	private CourtAppearanceDao courtAppearanceDao;

	
	public void setCourtAppearanceDao(CourtAppearanceDao courtAppearanceDao) {
		
		this.courtAppearanceDao = courtAppearanceDao;
	}
	

	public List<CriminalAppealTO> loadCriminalAppeals(Long caseId)
			throws ServiceException {

		List<CriminalAppealTO> list = new ArrayList<CriminalAppealTO>();
		try {
			List<CriminalAppealView> viewList = criminalAppealDao.loadCriminalAppealsByCaseId(caseId);

			for (CriminalAppealView view : viewList) {
				
				CriminalAppealTO csTO = convertToAppealTO(view);

				List<CriminalAppeal> appList = criminalAppealDao.loadAppealsByParentAppealId(csTO.getAppealId());
			
				csTO.setAppealExist((null != appList && appList.size() > 0) ? true : false);

				list.add(csTO);
			}
		} catch (ServiceException se) {
			throw se;
		}
		return list;
	}

	
	public List<CriminalAppealTO> loadCriminalSanctionsForReport(Long caseId)
			throws ServiceException {
		
		List<CriminalAppealTO> appealList = new ArrayList<CriminalAppealTO>();
		 
		List<CriminalAppealView> viewList = criminalAppealDao.loadCriminalAppealsByCaseId(caseId);
		
		for (CriminalAppealView view : viewList) {
			
			CriminalAppealTO csTO = convertToAppealTO(view);
			csTO.setCourtAppearanceList(courtAppearanceDao.loadCourtAppearancesByType(
							csTO.getAppealId(), "criminal"));
			csTO.setOutcome(loadCriminalAppealOutcome(csTO.getAppealId()));
			
			appealList.add(csTO);
		}
 
		return appealList;
	}
 

	@Override
	public List<CriminalAppeal> loadAppealsByParentSanctionId(Long sanctionId)
			throws ServiceException { 
		 
		return  criminalAppealDao.loadAppealsByParentSanctionId(sanctionId);
	 
	}
	   
	
	
	@Override
	public void deleteObject(Object o) throws ServiceException {

		CriminalAppealTO csto = (CriminalAppealTO) o;
		try {
			CriminalAppeal csdo = convertToCriminalAppeal(csto);
			super.deleteObject(csdo);
		} catch (ServiceException se) {
			throw se;
		}
	}

	@Override
	public void evictObject(Object o) throws ServiceException {
		
		CriminalAppealTO csto = (CriminalAppealTO) o;
		try {
			CriminalAppeal csdo = convertToCriminalAppeal(csto);
		
			super.evictObject(csdo);
		} catch (ServiceException se) {
			throw se;
		}

	}

	
	private CriminalAppealTO getCriminalAppeal(Long appealId) throws ServiceException {
		
		CriminalAppealView view = criminalAppealDao.loadCriminalAppealView(appealId);
		
		if (null != view) {
			 
			return convertToAppealTO(view);
		}
		
		return new CriminalAppealTO();
	}
	

	private CriminalAppeal convertToCriminalAppeal(CriminalAppealTO dto)
			throws ServiceException {

		CriminalAppeal appeal = new CriminalAppeal();
		try {
			BeanUtils.copyProperties(appeal, dto);
			
			if (null == dto.getCaseId()) {
				appeal.setCaseId(null);
			}
			if (null == dto.getAppealId()) {
				appeal.setAppealId(null);
			}
			if (null == dto.getSubjectId()) {
				appeal.setSubjectId(null);
			}

		} catch (InvocationTargetException iae) {
			throw new ServiceException(iae);
		} catch (IllegalAccessException e) {
			throw new ServiceException(e);
		}
		return appeal;
	}
	
	

	private CriminalAppealTO convertToAppealTO(
			CriminalAppealView view) throws ServiceException {

		CriminalAppealTO csTO = new CriminalAppealTO();
		try {
			BeanUtils.copyProperties(csTO, view);
			
			if (view.getCaseId() == null) {
				csTO.setCaseId(null);
			}
			if (view.getAppealId() == null) {
				csTO.setAppealId(null);
			}
			if (view.getSubjectId() == null) {
				csTO.setSubjectId(null);
			}
		} catch (InvocationTargetException iae) {
			throw new ServiceException(iae);
		} catch (IllegalAccessException e) {
			throw new ServiceException(e);
		}

		return csTO;
	}

	
	public PoliceCharge loadPoliceCharge(Long sanctionId) throws ServiceException {

		try {
			List<PoliceCharge> ps = criminalAppealDao.loadPoliceCharge(sanctionId);
			
			if (ps != null && !ps.isEmpty()) {
				
				return ps.get(0);
			}
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		return null;
	}

	
	public PoliceCharge savePoliceCharge(PoliceCharge charge) throws ServiceException {

		return criminalAppealDao.savePoliceCharge(charge);
	}

	
	public AppealOutcome loadCriminalAppealOutcome(Long appealId) throws ServiceException {

		try {
			List<AppealOutcome> list = criminalAppealDao.loadCriminalAppealsOutcome(appealId);
			
			if (null != list && !list.isEmpty()) {
				
				AppealOutcome outcome = (AppealOutcome)list.get(0); 
 		
				List<OutcomeAppliedSanction> appSanctions =  outcome.getOutcomeAppliedSanctions();
				CopyOnWriteArrayList<OutcomeAppliedSanction> sancList = new CopyOnWriteArrayList<OutcomeAppliedSanction>(appSanctions);
				
				for (OutcomeAppliedSanction sanction : sancList) {
					
					if (!sanction.getSanctionType().equals(CaseUtil.APPLIED_SANCTION_TYPE.CRIMINAL_APPEAL.toString())) {
						
						sancList.remove(sanction);	
					}
				} 
				
				outcome.setOutcomeAppliedSanctions(sancList);
				
				return outcome;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e);
		}
		
		AppealOutcome outcome = new AppealOutcome();
		outcome.setAppealId(appealId);
		return outcome;
	}
	
	/**
	 * Get criminal sanction outcome from appeals.
	 */
	public CriminalSanctionOutcome loadCriminalSanctionOutcome(Long sanctionId) throws ServiceException {

		try {
			List<CriminalSanctionOutcome> list = criminalAppealDao.loadCriminalSanctionOutcome(sanctionId);
			
			if (list != null && !list.isEmpty()) {
				
				CriminalSanctionOutcome outcome = (CriminalSanctionOutcome)list.get(0);
				
				outcome.setOutcomeAppliedSanctions(
						criminalAppealDao.loadAppliedSanctions(outcome.getOutcomeId(), 
								CaseUtil.APPLIED_SANCTION_TYPE.CRIMINAL.toString()));
				
				return outcome;
			}
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		
		return null;
	}

	
	public AppealOutcome saveOutcome(AppealOutcome dto) throws ServiceException {
		
		AppealOutcome outcome = criminalAppealDao.saveCriminalAppealOutcome(dto);
		
		CriminalAppealTO sanction = getCriminalAppeal(outcome.getAppealId());
		sanction.setState(outcome.getOutcomeStatus());
		 
		saveObject(convertToCriminalAppeal(sanction));
		
		return outcome;
	}

	
	public CriminalAppealTO loadCriminalAppeal(Long appealId) throws ServiceException {
		
		return getCriminalAppeal(appealId);
		
	}

	
	public void saveAppeal(CriminalAppealTO dto) throws ServiceException {
		
		Long appealId = dto.getAppealId();
		
		if (null != appealId) {
		
			CriminalAppealTO current = loadCriminalAppeal(dto.getAppealId());
			
			if (null != current) {
				// As Court Making Decisions comes from the hearing, rather than created from the screen.
				dto.setCourtMakingDecName(current.getCourtMakingDecName());
			}
		}	 
		super.saveObject(convertToCriminalAppeal(dto));		
	}
	 
	@Override
	public void deleteAppeal(Long appealId) throws ServiceException {
		
		AppealOutcome outcome = this.loadCriminalAppealOutcome(appealId);
		List<AppealHearing> hearings =  appealHearingDao.loadAppealHearingsByAppealId(appealId);
		CriminalAppeal appeal =  criminalAppealDao.loadCriminalAppeal(appealId);
		
		super.deleteObject(outcome);
		super.deleteObjects(hearings);
		super.deleteObject(appeal);
		
	}
}
