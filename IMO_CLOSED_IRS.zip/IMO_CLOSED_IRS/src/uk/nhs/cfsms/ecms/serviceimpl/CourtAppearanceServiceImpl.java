package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.CourtAppearanceDao;
import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;
import uk.nhs.cfsms.ecms.dto.caseInfo.CourtAppearanceTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.CourtAppearanceService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

/**
 * Court Appearance Service Implementation.
 * 
 */
@Service(value="courtAppearanceFacade")
@Transactional
public class CourtAppearanceServiceImpl extends BaseServiceImpl implements
		CourtAppearanceService {

	@Autowired
	private CourtAppearanceDao courtAppearanceDAO;
	
	public List<CourtAppearance> loadCourtAppearancesBySanctionId(
			Long sanctionId) throws ServiceException {

		return getAppearanceDao().loadCourtAppearancesBySanctionId(sanctionId);
	}

	public List<CourtAppearance> loadCourtAppearancesByType(Long sanctionId,
			String sanctionType) throws ServiceException {

		return getAppearanceDao().loadCourtAppearancesByType(sanctionId,
				sanctionType);
	}

	public CourtAppearanceTO loadCourtAppearanceById(Long appearanceId)
			throws ServiceException {

		return CaseUtil.convertToCourtAppearanceTO((CourtAppearance) courtAppearanceDAO
				.getObject(CourtAppearance.class, appearanceId));
	}

	public CourtAppearanceTO saveCourtAppearance(CourtAppearanceTO dto)
			throws ServiceException {

		CourtAppearance hibernate = CaseUtil.convertToCourtAppearance(dto);
		this.courtAppearanceDAO.saveObject(hibernate);

		return CaseUtil.convertToCourtAppearanceTO(hibernate);
	}

	public CourtAppearanceTO updateCourtAppearance(
			CourtAppearanceTO courtAppearance) throws ServiceException {

		CourtAppearance hibernate = CaseUtil
				.convertToCourtAppearance(courtAppearance);

		this.courtAppearanceDAO.saveObject(hibernate);

		return CaseUtil.convertToCourtAppearanceTO(hibernate);
	}

	public void deleteCourtAppearance(CourtAppearanceTO appearance)
			throws ServiceException {

		CourtAppearance hibernate = (CourtAppearance) getAppearanceDao()
				.getObject(CourtAppearance.class, appearance.getAppearanceId());

		getAppearanceDao().deleteObject(hibernate);
	}

	private CourtAppearanceDao getAppearanceDao() {

		return  this.courtAppearanceDAO;
	}
}
