package uk.nhs.cfsms.ecms.serviceimpl;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.converters.BigDecimalConverter;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditFlowThread;
import uk.nhs.cfsms.ecms.dao.FpuReportDao;
import uk.nhs.cfsms.ecms.dao.InformationDao;
import uk.nhs.cfsms.ecms.dao.UserDetailsDao;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.fpureport.FpuReport;
import uk.nhs.cfsms.ecms.data.infoGath.ClosedInformationView;
import uk.nhs.cfsms.ecms.data.infoGath.FcrolInformationView;
import uk.nhs.cfsms.ecms.data.infoGath.InfoTransferHistory;
import uk.nhs.cfsms.ecms.data.infoGath.Information;
import uk.nhs.cfsms.ecms.data.infoGath.InformationPermission;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.data.witness.Witness;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SubjectName;
import uk.nhs.cfsms.ecms.dto.infoGath.InfoTransferHistTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationDetails;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationProgressTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationViewTO;
import uk.nhs.cfsms.ecms.dto.infoGath.NHSSubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.NonNHSSubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonDescriptionTO;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SourceInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.VehicleTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.InformationGatherService;
import uk.nhs.cfsms.ecms.service.InformationProgressService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.ConvertToDTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.InformationUtil;

/**
 * Service Implementation for the Information Gathering
 * 
 * @author schilukuri
 * 
 */
@Service(value = "informationGatherFacade")
@Transactional
public class InformationGatherServiceImpl implements InformationGatherService {

	@Autowired
	private InformationDao informationDao;

	@Autowired
	private InformationProgressService informationProgressService;

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private FpuReportDao fpuReportDao;

	@Autowired
	private UserDetailsDao userDetailsDao;

	/**
	 * Save fraud details like subject contacts, subject, fraud and source
	 */
	public InformationTO saveInformationDetails(InformationDetails info,
			SessionUser user) {

		InformationTO informationTO = info.getInformationTO();

		if (log.isDebugEnabled()) {
			log.debug("**Information Subject Type =" + info.getSubjectType());
		}
		if (info.getSubjectType() != null) {
			if (info.getSubjectType().equals(
					InformationDetails.SubjectType.PERSON.toString())) {

				List<SubjectInformationTO> infoList = new ArrayList<SubjectInformationTO>();
				infoList.add(info.getSubjectInformationTO());
				if (log.isDebugEnabled()) {
					log.debug("SubjectInformation  subjectType ="
							+ info.getSubjectInformationTO().getSubjectType());
				}
				informationTO.setSubjectInfoList(infoList);

			} else if (info.getSubjectType().equals(
					InformationDetails.SubjectType.NHS.toString())) {

				List<NHSSubjectInformationTO> infoList = new ArrayList<NHSSubjectInformationTO>();
				infoList.add(info.getNhsSubjectInformationTO());
				if (log.isDebugEnabled()) {
					log.debug("NHSSubjectInformation  subjectType ="
							+ info.getNhsSubjectInformationTO()
									.getSubjectType());
				}
				informationTO.setNhsSubjectInfoList(infoList);

			} else if (info.getSubjectType().equals(
					InformationDetails.SubjectType.NONNHS.toString())) {

				List<NonNHSSubjectInformationTO> infoList = new ArrayList<NonNHSSubjectInformationTO>();
				infoList.add(info.getNonNHSSubjectInformationTO());
				if (log.isDebugEnabled()) {
					log.debug("NonNHSSubjectInformation  subjectType ="
							+ info.getNonNHSSubjectInformationTO()
									.getSubjectType());
				}
				informationTO.setNonNHSSubjectInfoList(infoList);

			} else if (info.getSubjectType().equals(
					InformationDetails.SubjectType.ASSOCIATE.toString())) {

				List<CaseContactTO> associateList = new ArrayList<CaseContactTO>();
				if (info.getAssociate() != null) {
					if (log.isDebugEnabled()) {
						log.debug("SET Associate CASEID="
								+ informationTO.getCaseId());
					}
					info.getAssociate().setContactType(info.getSubjectType());
					if (info.getAssociate().getPersonTO() != null)
						info.getAssociate().getPersonTO()
								.setPersonType(info.getSubjectType());
					info.getAssociate().setCaseId(informationTO.getCaseId());
				}
				associateList.add(info.getAssociate());

				informationTO.setCaseAssociates(associateList);

			} else if (info.getSubjectType().equals(
					InformationDetails.SubjectType.VEHICLE.toString())) {

				List<VehicleTO> vehicleList = new ArrayList<VehicleTO>();
				if (info.getVehicle() != null) {
					if (log.isDebugEnabled()) {
						log.debug("SET Vehicle CASEID="
								+ informationTO.getCaseId());
					}
					info.getVehicle().setCaseId(informationTO.getCaseId());
				}
				vehicleList.add(info.getVehicle());

				informationTO.setVehicles(vehicleList);
			}

		}
		if (informationTO.getInformationId() == null) {
			AuditFlowThread.set("Information Created");
			informationTO = informationDao.saveInformation(informationTO, user);
		} else {
			AuditFlowThread.set("Information Updated");
			informationDao.updateInformation(informationTO, true, user);
		}
		if (log.isDebugEnabled()) {
			log.debug("**Information ID = " + informationTO.getInformationId());
		}
		//return informationTO.getInformationId();
		return informationTO;
	}

	/**
	 * Create new Information details..
	 * 
	 * @return InformationDetails.
	 */
	public InformationDetails createFraudDetailsTO() {

		InformationDetails infoDetails = new InformationDetails();

		SourceInformationTO sourceInfoTO = new SourceInformationTO();

		PersonTO sourcePersonTO = new PersonTO();
		sourcePersonTO.setPersonDescriptionTO(new PersonDescriptionTO());
		this.updatePersonDetails(sourcePersonTO);

		sourceInfoTO.setSourcePersonTO(sourcePersonTO);

		InformationTO informationTO = new InformationTO();
		informationTO.setIntelligenceContent("No");
		informationTO.setInformationDate(new Date(System.currentTimeMillis()));
		informationTO.setHasPrimarySubject(false);
		informationTO.setSourceInformationTO(sourceInfoTO);

		infoDetails = createNewSubjects(infoDetails, informationTO);

		return infoDetails;
	}

	/**
	 * Redundant but still helps especially for the front end.
	 * 
	 * @param info
	 *            InformationDetails
	 * @param informationTO
	 *            InformationTO
	 * @return InformationDetails
	 */
	private InformationDetails createNewSubjects(InformationDetails info,
			InformationTO informationTO) {

		info.setInformationTO(informationTO);

		SubjectInformationTO subjectInfoTO = new SubjectInformationTO();
		NHSSubjectInformationTO nHSSubjectInfoTO = new NHSSubjectInformationTO();
		NonNHSSubjectInformationTO nonNHSSubjectInfoTO = new NonNHSSubjectInformationTO();

		subjectInfoTO.setInformationTO(informationTO.getInformationId());
		PersonTO subjectPersonTO = new PersonTO();
		subjectPersonTO.setPersonDescriptionTO(new PersonDescriptionTO());
		// Check this one for redundant
		this.updatePersonDetails(subjectPersonTO);

		subjectInfoTO.setSubjectPersonTO(subjectPersonTO);
		nHSSubjectInfoTO.setInformationTO(informationTO.getInformationId());
		nonNHSSubjectInfoTO.setInformationTO(informationTO.getInformationId());

		info.setSubjectInformationTO(subjectInfoTO);
		info.setNhsSubjectInformationTO(nHSSubjectInfoTO);
		info.setNonNHSSubjectInformationTO(nonNHSSubjectInfoTO);

		CaseContactTO associateTO = new CaseContactTO();
		VehicleTO vehicleTO = new VehicleTO();

		PersonTO pto = new PersonTO();
		pto.setPersonDescriptionTO(new PersonDescriptionTO());
		// Check this one
		this.updatePersonDetails(pto);

		associateTO.setPersonTO(pto);

		info.setAssociate(associateTO);
		info.setVehicle(vehicleTO);

		return info;
	}

	public InformationDetails loadInformationById(Long informationId)
			throws IllegalAccessException, InvocationTargetException,
			ServiceException, IOException {

		InformationDetails infoDetails = null;

		InformationTO infoTO = informationDao
				.loadInformationById(informationId);

		if (infoTO != null) {
			final List<InformationProgressTO> infoProgressTOList = informationProgressService
					.loadInformationProgresses(informationId);
			if (!infoProgressTOList.isEmpty()) {
				infoTO.setInfoProgressJsonString(informationProgressService
						.convertToInformationProgressListToJsonString(infoProgressTOList));
			}
		}

		if (infoTO != null) {
			infoDetails = new InformationDetails();

			if (null != infoTO.getSourceInformationTO()) {
				this.updatePersonDetails(infoTO.getSourceInformationTO()
						.getSourcePersonTO());
			}
			List<SubjectInformationTO> subList = infoTO.getSubjectInfoList();
			for (SubjectInformationTO subjInfo : subList) {
				this.updatePersonDetails(subjInfo.getSubjectPersonTO());
			}

			infoDetails = createNewSubjects(infoDetails, infoTO);
			List<InformationPermission> permList = getInformationPersmissions(informationId);
			infoTO.setInfoPermissionList(permList);
		}
		return infoDetails;
	}

	public InformationTO loadInformationTOById(Long informationId) {

		return informationDao.loadInformationById(informationId);
	}

	public InformationDetails loadFcrolInformationById(Long informationId) {

		InformationDetails infoDetails = null;

		InformationTO infoTO = informationDao
				.loadFcrolInformationById(informationId);

		if (infoTO != null) {
			infoDetails = new InformationDetails();

			this.updatePersonDetails(infoTO.getSourceInformationTO()
					.getSourcePersonTO());

			List<SubjectInformationTO> subList = infoTO.getSubjectInfoList();
			for (SubjectInformationTO subjInfo : subList) {
				this.updatePersonDetails(subjInfo.getSubjectPersonTO());
			}

			infoDetails = createNewSubjects(infoDetails, infoTO);
			List<InformationPermission> permList = getInformationPersmissions(informationId);
			infoTO.setInfoPermissionList(permList);
		}
		return infoDetails;

	}

	public void saveFcrolInformation(String userId, String teamCode,
			Long infoId, String regOverride, String orgCode) {

		List<InformationPermission> list = new ArrayList<InformationPermission>();

		InformationPermission assigneePerm = InformationUtil
				.createInfoPermission(infoId,
						ECMSConstants.INFO_ASSIGNEE_PERMISSION, userId, userId);

		InformationPermission orgPerm = InformationUtil.createInfoPermission(
				infoId, ECMSConstants.ORGANISATIONAL_PERMISSION, orgCode,
				userId);

		String teamPermValue = regOverride.equalsIgnoreCase("Y") ? teamCode
				: informationDao.getTeamCode(orgCode);

		InformationPermission teamPerm = InformationUtil.createInfoPermission(
				infoId, ECMSConstants.TEAM_PERMISSION, teamPermValue, userId);

		list.add(assigneePerm);
		list.add(teamPerm);
		list.add(orgPerm);

		informationDao.saveFcrolInformationPermission(list);
		informationDao.saveFcrolInformationDiscard(infoId, "Y", userId, "",
				regOverride);
	}

	public void rejectFcrolInformation(Long infoId, String staffId,
			String rejectInfo) {

		informationDao.saveFcrolInformationDiscard(infoId, "R", staffId,
				rejectInfo, "");
	}

	public List<FcrolInformationView> loadFcrolInformationView() {

		return informationDao.loadFcrolInformationView();
	}

	public void saveInformation(InformationTO info, SessionUser user) {

		informationDao.save(info, user);
	}

	public List<InformationViewTO> loadAllInformationView(SessionUser user)
			throws IllegalAccessException, InvocationTargetException {
		this.debugSessionUser(user);
		return populateDTO(informationDao.loadAllInformationView(user, false));
	}

	public List<InformationViewTO> load_LCFS_Other_InformationReports(
			final SessionUser user) throws IllegalAccessException,
			InvocationTargetException {
		this.debugSessionUser(user);
		return populateDTO(informationDao.loadLCFS_Other_InformationView(user));

	}

	private List<InformationViewTO> populateDTO(List<InformationView> list)
			throws IllegalAccessException, InvocationTargetException {
		BeanUtilsBean.getInstance().getConvertUtils().register(new BigDecimalConverter(),BigDecimal.class);
		final ArrayList<InformationViewTO> informationViewTOList = new ArrayList<InformationViewTO>();
		for (InformationView view : list) {
			final InformationViewTO dto = new InformationViewTO();
			BeanUtils.copyProperties(dto, view);
			informationViewTOList.add(dto);
		}
		return informationViewTOList;

	}

	/**
	 * Information Permissions.
	 * 
	 * @param informationId
	 * @return List.
	 */
	private List<InformationPermission> getInformationPersmissions(
			Long informationId) {

		return informationDao.getInformationPersmissions(informationId);
	}

	/**
	 * Load information by CaseId.
	 * 
	 * @param caseId
	 * @return InformationTO.
	 */
	public InformationTO loadInformationByCaseId(Long caseId,
			boolean isCasePersonsOnly) {

		ConvertToDTO cToDTO = ConvertToDTO.getInstance();

		Information information = informationDao.loadInformationByCaseId(
				caseId, isCasePersonsOnly);
		InformationTO dto = null;
		if (information != null) {
			dto = cToDTO.convertToDTO(information);
		}

		if (dto == null)
			return dto;

		if (dto.getSourceInformationTO() != null) {

			this.updatePersonDetails(dto.getSourceInformationTO()
					.getSourcePersonTO());
		}
		if (dto.getSubjectInfoList() != null) {
			for (SubjectInformationTO subjTO : dto.getSubjectInfoList()) {
				this.updatePersonDetails(subjTO.getSubjectPersonTO());
			}
		}
		if (dto.getCaseAssociates() != null) {
			for (CaseContactTO assoc : dto.getCaseAssociates()) {
				this.updatePersonDetails(assoc.getPersonTO());
			}
		}
		return dto;
	}

	/**
	 * Load information by CaseId.
	 * 
	 * @param caseId
	 * @return InformationTO.
	 */
	public InformationTO loadInformationByCaseId(Long caseId) {
		InformationTO dto = null;
		ConvertToDTO cToDTO = ConvertToDTO.getInstance();
		Information information = informationDao
				.loadInformationByCaseId(caseId);
		if (information != null) {
			dto = cToDTO.convertToDTO(information);
		}
		if (dto != null) {
			if (dto.getSourceInformationTO() != null) {
				this.updatePersonDetails(dto.getSourceInformationTO()
						.getSourcePersonTO());
			}
			if (dto.getSubjectInfoList() != null) {
				for (SubjectInformationTO subjTO : dto.getSubjectInfoList()) {
					this.updatePersonDetails(subjTO.getSubjectPersonTO());
				}
			}
			if (dto.getCaseAssociates() != null) {
				for (CaseContactTO assoc : dto.getCaseAssociates()) {
					this.updatePersonDetails(assoc.getPersonTO());
				}
			}
		}
		return dto;
	}

	private void updatePersonDetails(PersonTO personTO) {

		if (personTO != null) {
			personTO.updateAllPersonListDetails();
		}
	}

	public InformationTO saveCaseInformation(InformationTO info,
			SessionUser user) {
		// TODO:
		if (info.getInformationId() != null) {
			informationDao.updateInformation(info, false, user);
		}
		return info;
	}

	public List<InformationView> loadTopInformationView(SessionUser user,
			Integer rowCount) {

		return informationDao.loadTopInformationView(user, rowCount, false);
	}

	public boolean isFPUSystemWeakness(Long informationId) {

		FpuReport report = fpuReportDao.loadFpuReportByInfoId(informationId);

		if (report != null && report.getFpuReportId() != null) {
			return true;
		}
		return false;
	}

	public FpuReportDao getFpuReportDao() {

		return fpuReportDao;
	}

	public void setFpuReportDao(FpuReportDao fpuReportDao) {

		this.fpuReportDao = fpuReportDao;
	}

	public boolean checkAccessToInformation(Long infoId, SessionUser user,
			boolean state) {

		return informationDao.isUserAuthorizedToAccessInformation(infoId, user,
				state);
	}

	public UserObject getOwnerDetailsByInfoId(Long infoId) {

		List<InformationPermission> infoPerm = informationDao
				.getInformationPersmissions(infoId);

		UserObject infoOFM = informationDao.getOFMDetailsByInfoId(infoId);

		for (InformationPermission perm : infoPerm) {

			if (null != perm
					&& ECMSConstants.TEAM_PERMISSION.equals(perm
							.getPermissionType())
					&& null != perm.getPermissionValue()
					&& null != infoOFM
					&& !perm.getPermissionValue().equals(
							infoOFM.getEmployerOrgCode())) {

				return informationDao.getOFMByTeamCode(perm
						.getPermissionValue());
			}
		}
		return infoOFM;
	}

	public void updateSubjectToWitness(InformationTO info, SessionUser user,
			String subjectId) {

		SubjectInformationTO subject = null;
		List<SubjectInformationTO> subjectList = null;
		int subjectInListIndex = -1;

		if (null != info && info.getSubjectInfoList() != null) {
			subjectList = info.getSubjectInfoList();
		}

		for (int i = 0; i < subjectList.size(); i++) {
			SubjectInformationTO tempSubject = subjectList.get(i);

			if (tempSubject.getSubjectId().toString().equals(subjectId.trim())) {
				subject = tempSubject;
				subjectInListIndex = i;
			}
		}
		// Create new Witness
		Witness witness = new Witness();
		witness.setCreatedStaffId(user.getStaffId());

		if (info != null) {
			witness.setCaseId(info.getCaseId());
			witness.setPerson(ConvertFromDTO.getInstance().convertFromDTO(
					subject.getSubjectPersonTO(), null, false));
			witness.setState(ECMSConstants.WITNESS_USED);

			// Update subject type to Witness..
			if (subjectInListIndex != -1) {
				info.getSubjectInfoList().get(subjectInListIndex)
						.setIsWitness("Y");
				this.saveCaseInformation(info, user);
			}
		}
		informationDao.updateSubjectToWitness(witness);
	}

	@Override
	public List<ClosedInformationView> loadClosedInformationView(
			SessionUser user, String createdByFilter) {

		this.debugSessionUser(user);
		return informationDao.loadClosedInformationView(user, createdByFilter);
	}

	public List<InformationView> loadMyTeamsInformationView(SessionUser user) {

		this.debugSessionUser(user);

		if (user.isUserFCRL()) {
			return informationDao.loadMyTeamsInformation(user);
		} else {
			return informationDao.loadAllInformationView(user, false);
		}
	}

	private void debugSessionUser(SessionUser user) {

		if (log.isDebugEnabled()) {
			log.debug("Loading Session User =" + user.getStaffId());
			log.debug("User GROUP permission =" + user.getGroupPermission());
			log.debug("User Responsibilities ="
					+ EcmsUtils.getCommaSeperatedValues(user
							.getOrgOrTeamResponsibilities()));
		}
	}

	/**
	 * Service method responsible for loading information history and returning
	 * the transfer Object
	 * */

	public InfoTransferHistTO loadInformationHistory(Long InfoId)
			throws ServiceException {

		InfoTransferHistory history = informationDao
				.loadCurrentInfoTransferHistoryByInfoId(InfoId);

		if (null != history) {

			InfoTransferHistTO infoHistory = CaseUtil
					.convertToInfoTransferHistory(history);
			infoHistory.setCreatedStaffName(this.getFullName(history
					.getCreatedStaffId()));
			infoHistory.setApproverStaffName(this.getFullName(history
					.getApproverStaffID()));
			return infoHistory;
		}
		return null;
	}

	/**
	 * Load user by staffId
	 * 
	 * @param staffId
	 * 
	 * @return fullName
	 */
	private String getFullName(String staffId) {

		if (StringUtils.isNotEmpty(staffId)) {

			return EcmsUtils.getFullName(userDetailsDao.loadUser(staffId));
		}
		return "";
	}

	public void setUserDetailsDao(UserDetailsDao userDetailsDao) {

		this.userDetailsDao = userDetailsDao;
	}

	public void setInformationDao(InformationDao informationDao) {

		this.informationDao = informationDao;
	}

	@Override
	public InfoTransferHistTO loadInformationHistoryByApprover(Long infoId,
			String staffId) throws ServiceException {

		InfoTransferHistory history = informationDao
				.loadNewInfoTransferHistoryByApprover(infoId, staffId);

		if (null != history) {

			InfoTransferHistTO infoHistory = CaseUtil
					.convertToInfoTransferHistory(history);
			infoHistory.setCreatedStaffName(this.getFullName(history
					.getCreatedStaffId()));
			infoHistory.setApproverStaffName(this.getFullName(history
					.getApproverStaffID()));
			return infoHistory;
		}
		return null;
	}

	@Override
	public List<SubjectName> getAllSubjects(String caseId) {
		InformationTO infoTO = loadInformationByCaseId(new Long(caseId));
		return CaseUtil.getAllSubjectList(infoTO);
	}

	@Override
	@Cacheable(key = "#root.methodName", value = "loadClosedInformationReportsForIMO")
	public List<ClosedInformationView> loadClosedInformationReportsForIMO(SessionUser user) throws IllegalAccessException, InvocationTargetException{
		return informationDao.loadClosedInformationReportsForIMO(user);
	}
	
	/*public void deleteThreeYearsOldClosedInformation(){
		informationDao.deleteThreeYearsOldClosedInformation();
	}*/
}
