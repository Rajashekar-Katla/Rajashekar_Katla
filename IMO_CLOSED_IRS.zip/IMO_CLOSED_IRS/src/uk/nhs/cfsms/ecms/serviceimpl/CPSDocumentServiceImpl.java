package uk.nhs.cfsms.ecms.serviceimpl;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;
import static uk.nhs.cfsms.ecms.ECMSConstants.ACTION_BOOK;
import static uk.nhs.cfsms.ecms.ECMSConstants.EXHIBITLABEL;
import static uk.nhs.cfsms.ecms.ECMSConstants.EXHIBITS;
import static uk.nhs.cfsms.ecms.ECMSConstants.INTERVIEWS;
import static uk.nhs.cfsms.ecms.ECMSConstants.MGFORMS;
import static uk.nhs.cfsms.ecms.ECMSConstants.UPLOADED_STATEMENT;
import static uk.nhs.cfsms.ecms.ECMSConstants.WITNESS;
import static uk.nhs.cfsms.ecms.utility.EcmsUtils.escapeSPChars;

import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import uk.nhs.cfsms.ecms.dao.CPSDocumentsDao;
import uk.nhs.cfsms.ecms.dao.CaseDao;
import uk.nhs.cfsms.ecms.data.cim.CPSDocumentsNamingRules;
import uk.nhs.cfsms.ecms.data.cim.CPSDocumentsView;
import uk.nhs.cfsms.ecms.data.cim.CPSFileNamingRulesDocument;
import uk.nhs.cfsms.ecms.data.cim.CPSMailFormFields;
import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.cim.CaseActionBookAttachment;
import uk.nhs.cfsms.ecms.data.cim.ExhibitDocuments;
import uk.nhs.cfsms.ecms.data.cim.Interview;
import uk.nhs.cfsms.ecms.data.cim.MGForm;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.cps.CPSRequestDocTbl;
import uk.nhs.cfsms.ecms.data.cps.CPSRequestTbl;
import uk.nhs.cfsms.ecms.data.infoGath.Person;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSDocumentsDTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSDocumentsViewDTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSFileNamingRulesDocumentDTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSMailFormFieldsDTO;
import uk.nhs.cfsms.ecms.dto.exhibit.ExhibitViewTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.dto.witness.WitnessStatementTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AttachmentService;
import uk.nhs.cfsms.ecms.service.CPSDocumentService;
import uk.nhs.cfsms.ecms.service.CaseActionBookService;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.service.CpsMailService;
import uk.nhs.cfsms.ecms.service.ExhibitService;
import uk.nhs.cfsms.ecms.service.InterviewService;
import uk.nhs.cfsms.ecms.service.MGFormService;
import uk.nhs.cfsms.ecms.service.SubjectService;
import uk.nhs.cfsms.ecms.service.UserInformationService;
import uk.nhs.cfsms.ecms.service.WitnessStatementService;

/**
 * This is the service layer implementation for the CPS document listing and
 * approval process. This service layer uses other services and provide the
 * updated transfer objects to the controller. Similarly it also interacts with
 * DAO layer to Create/Update the Database for each case.
 * 
 * */
@Service(value = "cpsDocumentsService")
@Transactional
public class CPSDocumentServiceImpl implements CPSDocumentService {

	private final Log logger = LogFactory.getLog(getClass());

	@Autowired
	private CPSDocumentsDao cpsDocumentsDao;
	@Autowired
	private AttachmentService attachmentService;
	@Autowired
	private CaseActionBookService caseActionBookService;
	@Autowired
	private ExhibitService exhibitService;
	@Autowired
	private InterviewService interviewService;
	@Autowired
	private MGFormService mgFormService;
	@Autowired
	private CaseService caseService;
	@Autowired
	private WitnessStatementService witnessStatementService;
	@Autowired
	private UserInformationService userInformationService;
	@Autowired
	private SubjectService subjectSearchFacade;

	@Autowired
	private CpsMailService cpsMailService;

	@Autowired
	private CaseDao caseDao;

	/**
	 * This service method is responsible for triggering the DAO layer to save
	 * the requested documents list.
	 * 
	 * @param CPSDocumentsRequestDTO
	 * 
	 * @return CPSDocumentsRequestDTO
	 * 
	 * */
	@Override
	public CPSDocumentsViewDTO createApprovalRequest(
			final CPSDocumentsViewDTO cpsDocumentsViewDTO) {

		final String approverStaffID = this.caseService
				.getApproverStaffIdForCPSDocsRequest();

		cpsDocumentsViewDTO.setApproverStaffId(approverStaffID);

		final CPSDocumentsViewDTO requestedCPSDocuments = populateDTOFromEntity(cpsDocumentsDao
				.save(populateCPSRequestTblFromCPSDocumentsViewDTO(cpsDocumentsViewDTO)));

		return requestedCPSDocuments;
	}

	public CaseTO loadCase(Long caseID) throws ServiceException {

		Case caseDO = caseDao.loadCase(caseID);
		return createCaseTO(caseDO);
	}

	private CaseTO createCaseTO(Case hibernate) throws ServiceException {

		CaseTO caseTO = new CaseTO();
		try {
			BeanUtils.copyProperties(caseTO, hibernate);
		} catch (IllegalAccessException iae) {
			throw new ServiceException(iae);
		} catch (IllegalArgumentException iae) {
			throw new ServiceException(iae);
		} catch (InvocationTargetException ite) {
			throw new ServiceException(ite);
		}
		return caseTO;
	}

	/**
	 * This service method is responsible for triggering the DAO layer to save
	 * the CPS File Naming Rules Document.
	 * 
	 * @param CPSFileNamingRulesDocumentDTO
	 * 
	 * */

	@Override
	public void saveCPSFileNamingRulesDocument(
			final CPSFileNamingRulesDocumentDTO cpsFileNamingRulesDocumentDTO) {
		cpsDocumentsDao
				.saveCPSFileNamingRulesDocument(populateCPSFileNamingRulesDocumentFromCPSFileNamingDocumentDTO(cpsFileNamingRulesDocumentDTO));
	}

	/**
	 * This service method is responsible to get CPS documents naming rules from
	 * DAO layer.
	 * 
	 * @return Map<String, String> - <document form type, regular expression>
	 * 
	 * */

	@Override
	@Cacheable(key = "#root.methodName", value = "getCPSDocumentsNamingRulesCache")
	public Map<String, String> getCPSDocumentsNamingRules() {
		final Map<String, String> namingRulesMap = new HashMap<String, String>();
		final List<CPSDocumentsNamingRules> rulesList = cpsDocumentsDao
				.getCPSDocumentsNamingRules();

		for (CPSDocumentsNamingRules namingRule : rulesList) {
			namingRulesMap.put(namingRule.getFormType(), namingRule.getRegEx());
		}
		return namingRulesMap;
	}

	/**
	 * This service method is responsible for triggering the DAO layer to update
	 * file names.
	 * 
	 * @param String
	 *            category
	 * @param String
	 *            fileName
	 * @param String
	 *            docID
	 * @throws ServiceException
	 * 
	 * */

	@Override
	public void updateCPSDocumentFileName(final String category,
			final String fileName, final String docID) throws ServiceException {
		final long docPK = Long.parseLong(docID);

		try {
			if (EXHIBITS.equalsIgnoreCase(category)
					|| EXHIBITLABEL.equalsIgnoreCase(category)) {
				exhibitService.updateExhibitFileName(docPK, fileName);
			}
			if (WITNESS.equalsIgnoreCase(category)) {
				witnessStatementService.updateWitnessStatementFileName(docPK,
						fileName);
			}
			if (INTERVIEWS.equalsIgnoreCase(category)) {
				interviewService.updateInterviewFileName(docPK, fileName);
			}
			if (MGFORMS.equalsIgnoreCase(category)) {
				mgFormService.updateMGFormFileName(docPK, fileName);
			}
		} catch (Exception ex) {
			logger.error("Got ServiceException while updating file names "
					+ ExceptionUtils.getStackTrace(ex));
			throw new ServiceException(
					"Got ServiceException while updating file names "
							+ ExceptionUtils.getStackTrace(ex));
		}

	}

	@Override
	public List<CPSDocumentsViewDTO> createApprovalResponse(
			final CPSDocumentsViewDTO cpsDocumentsViewDTO) {

		final String[] requestedData = cpsDocumentsViewDTO.getRequestedData()
				.split(",");

		final List<CPSDocumentsView> cpsDocumentsViewList = cpsDocumentsDao
				.loadAllCPSDocsRequestsByNativeSql_ToApprove(
						cpsDocumentsViewDTO.getApproverStaffId(),
						cpsDocumentsViewDTO.getCaseId());

		final List<CPSRequestDocTbl> cpsRequestDocTbls = new CopyOnWriteArrayList<CPSRequestDocTbl>();

		final List<CPSRequestTbl> cpsRequestTblList = new CopyOnWriteArrayList<CPSRequestTbl>();

		final List<CPSDocumentsViewDTO> updatedCpsDocumentsViewDTOList = new CopyOnWriteArrayList<CPSDocumentsViewDTO>();

		for (final CPSDocumentsView documentsView : cpsDocumentsViewList) {

			final long documentID = documentsView.getDocumentID();

			for (final String reqData : requestedData) {
				final String[] hypenData = reqData.split("-");

				//final String grpName = hypenData[0];
				final String docID = hypenData[1];
				final String id = hypenData[2];
				final String cpsReqID = hypenData[3];

				if (documentID == Long.valueOf(docID)) {
					final CPSRequestTbl cpsRequestTbl = populateCpsRequestTblFromDTO(
							documentsView, cpsReqID);

					//cpsRequestTbl.setApproverStaffId(cpsDocumentsViewDTO.getApproverStaffId());

					final CPSRequestDocTbl cpsRequestDocTbl = new CPSRequestDocTbl();

					cpsRequestDocTbl.setApproverMessage(cpsDocumentsViewDTO
							.getApproverMessage());
					cpsRequestDocTbl
							.setApproverResponseTime(cpsDocumentsViewDTO
									.getApproverResponseTime());
					cpsRequestDocTbl.setDocumentID(documentsView
							.getDocumentID());
					cpsRequestDocTbl.setDocumentType(documentsView
							.getDocumentType());
					cpsRequestDocTbl.setRequestStatus(cpsDocumentsViewDTO
							.getRequestStatus());
					cpsRequestDocTbl.setId(Long.valueOf(id));
					cpsRequestDocTbl.setApproverStaffId(cpsDocumentsViewDTO
							.getApproverStaffId());
					cpsRequestDocTbl
							.setApproverStaffName(getUserFullName(cpsDocumentsViewDTO
									.getApproverStaffId()));

					cpsRequestDocTbls.add(cpsRequestDocTbl);

					cpsRequestTbl.setCpsRequestDocTbls(cpsRequestDocTbls);
					cpsRequestTblList.add(cpsRequestTbl);
				}
			}
		}

		for (final CPSRequestTbl cpsRequestTbl : cpsRequestTblList) {
			updatedCpsDocumentsViewDTOList
					.add(populateDTOFromEntity(cpsDocumentsDao
							.update(cpsRequestTbl)));
		}

		return updatedCpsDocumentsViewDTOList;
	}

	/**
	 * This service method is responsible for loading the current request, for
	 * the given case ID and current logged in user.
	 * 
	 * @param String
	 *            staffID
	 * @param long caseID
	 * 
	 * @return CPSDocsSubmitTO
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 * 
	 * */
	@Override
	public List<CPSDocumentsViewDTO> loadAllRequests(final long caseID)
			throws IllegalAccessException, InvocationTargetException {

		final List<CPSDocumentsView> cpsDocumentsViews = cpsDocumentsDao
				.loadAllCPSDocsRequestsByNativeSql(caseID);

		return populateViewDTO(cpsDocumentsViews);

	}

	@Override
	public List<CPSMailFormFieldsDTO> getCPSFormFields(
			final SessionUser sessionUser, final String caseID,
			final String caseNumber) throws ServiceException {
		return  populateCPSMailFormFieldsDTO(cpsDocumentsDao.getCPSFormFields(), sessionUser, caseID, caseNumber);
	}

	@Override
	public String getCPSDocsRequestorStaffID(final long caseID) {
		return cpsDocumentsDao.getCPSDocsRequestorStaffID(caseID);
	}

	/**
	 * This service method is responsible for loading all CPS document
	 * submission history, for the given case ID and current logged in user.
	 * 
	 * @param String
	 *            staffID
	 * @param long caseID
	 * 
	 * @return CPSDocsSubmitTO
	 * 
	 * */
	@Override
	public List<CPSDocumentsViewDTO> loadAllRequestsHistory(
			final String staffID, final long caseID) {
		return populateCPSDocumentsRequestsHistory(cpsDocumentsDao
				.loadAllRequestsHistory(staffID, caseID));
	}

	/**
	 * This service method is responsible for downloading the requested
	 * document.
	 * 
	 * @param Long
	 *            documentID - Primary key of the respective document.
	 * @param Long
	 *            caseID - Case ID
	 * @param String
	 *            category - Document category ( e.g. Attachment, Interview,
	 *            Exhibit etc.)
	 * 
	 * @param boolean isFileBlobRequired
	 *
	 * @return CPSDocumentsTO
	 **/
	@Override
	public CPSDocumentsDTO downloadCPSDocument(final Long documentID,
			final Long caseID, final String category,
			final boolean isFileBlobRequired) {

		CPSDocumentsDTO cpsDocumentsDTO = null;

		if (StringUtils.endsWithIgnoreCase(category, EXHIBITS)) {
			if (isFileBlobRequired) {
				cpsDocumentsDTO = convertExhibit(
						exhibitService.downloadExhibitDocument(documentID),
						EXHIBITS);
			} else {
				cpsDocumentsDTO = convertExhibit(
						exhibitService.downloadExhibit(documentID, category),
						EXHIBITS);
				cpsDocumentsDTO.setPrimaryKey(documentID + "");
			}
		}

		if (StringUtils.endsWithIgnoreCase(category, EXHIBITLABEL)) {
			if (isFileBlobRequired) {
				cpsDocumentsDTO = convertExhibit(
						exhibitService.downloadExhibitDocument(documentID),
						EXHIBITLABEL);
			} else {
				cpsDocumentsDTO = convertExhibit(
						exhibitService.downloadExhibit(documentID, category),
						EXHIBITLABEL);

				cpsDocumentsDTO.setPrimaryKey(documentID + "");
			}
		}

		if (StringUtils.endsWithIgnoreCase(category, INTERVIEWS)) {
			cpsDocumentsDTO = convertInterviewForDownload(interviewService
					.downloadInterviewsForCPS(documentID, isFileBlobRequired));
		}
		try {
			if (StringUtils.endsWithIgnoreCase(category, MGFORMS)) {
				cpsDocumentsDTO = convertMgformForDownload(mgFormService
						.downloadMgForm(documentID, isFileBlobRequired));
			}
			/*
			 * if (StringUtils.endsWithIgnoreCase(category,
			 * ECMSConstants.CLOSURE_REPORT)) { cpsDocumentsDTO =
			 * convertClosureReportForDownload(
			 * caseService.downloadCaseClosureByCaseId(caseID),
			 * isFileBlobRequired); }
			 */
			if (StringUtils.endsWithIgnoreCase(category, WITNESS)) {
				cpsDocumentsDTO = convertWitnessStatmentForDownload(witnessStatementService
						.downloadWitnessStatementById(documentID,
								isFileBlobRequired));
			}
		} catch (Exception ex) {
			logger.error("Got Exception while downloading CPS documents: "
					+ getStackTrace(ex));
		}
		return cpsDocumentsDTO;
	}

	/**
	 * This service method is responsible for loading CPS File Naming Rules
	 * Document.
	 * 
	 * @return CPSFileNamingRulesDocumentDTO
	 * 
	 * */

	@Override
	@Cacheable(key = "#root.methodName", value = "downloadCPSFileNamingRulesDocumentCache")
	public CPSFileNamingRulesDocumentDTO downloadCPSFileNamingRulesDocument()
			throws ServiceException {
		return populateCPSFileNamingDocumentDTOFromEntity(cpsDocumentsDao
				.loadCPSFileNamingRulesDocument());
	}

	/**
	 * This service method is responsible for loading all the documents
	 * associated with the given case ID.
	 * 
	 * @param Long
	 *            caseID
	 * 
	 * @return List<CPSDocumentsTO>
	 * 
	 * */
	@SuppressWarnings("unchecked")
	@Override
	public List<CPSDocumentsDTO> loadAllDocuments(final Long caseID) {

		final ArrayList<CPSDocumentsDTO> cpsDocumentsList = new ArrayList<CPSDocumentsDTO>();

		// Loading Exhibits
		try {
			cpsDocumentsList.addAll(convertExhibits(exhibitService
					.loadExhibitsForCPS(caseID)));

			// Loading Interviews

			cpsDocumentsList.addAll(convertInterviews(interviewService
					.getInterviewsForCPS(caseID)));

			// Loading MG Forms

			cpsDocumentsList.addAll(convertMGForms(mgFormService
					.listMGFormsForCPS(caseID)));

			// Loading Interviews

			cpsDocumentsList.addAll(convertWitness(witnessStatementService
					.loadCPSWitnesseStatementsByCaseID(caseID,
							UPLOADED_STATEMENT), caseID));

		} catch (ServiceException se) {
			logger.error("Got ServiceException while loading all CPS documents "
					+ getStackTrace(se));

		} catch (Exception e) {
			logger.error("Got Exception while loading all CPS documents "
					+ getStackTrace(e));
		}

		return cpsDocumentsList;
	}

	/**
	 * This converter is responsible for populating the exhibits in CPS Document
	 * Listings.
	 * 
	 * @param List
	 *            <WitnessStatementTO> witnessStatements
	 * @param Long
	 *            caseID
	 * 
	 * @return List<CPSDocumentsTO>
	 * 
	 * */
	private List<CPSDocumentsDTO> convertWitness(
			List<WitnessStatementTO> witnessStatements, Long caseID) {

		ArrayList<CPSDocumentsDTO> cpsDocList = new ArrayList<CPSDocumentsDTO>();

		for (WitnessStatementTO witnessStatementTO : witnessStatements) {
			CPSDocumentsDTO cpsDocTO = convertWitnessStatment(witnessStatementTO);
			if (null != cpsDocTO) {
				cpsDocList.add(cpsDocTO);
			}
		}
		return cpsDocList;
	}

	/**
	 * This converter is responsible for populating the MGForm in CPS Document
	 * Listings.
	 * 
	 * @param MGForm
	 *            mgForm
	 * @return CPSDocumentsTO
	 * */
	private CPSDocumentsDTO convertMgform(final MGForm mgForm) {

		final long fileSize = mgFormService.getMGFormFileSize(mgForm
				.getMgFormId());

		if (null != mgForm && fileSize > 0) {
			final CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();
			cpsDocTO.setFormId(mgForm.getMgFormId());
			cpsDocTO.setCaseID(mgForm.getCaseId() + "");
			cpsDocTO.setFileName(escapeSPChars(mgForm.getFileName()));
			cpsDocTO.setFileType(escapeSPChars(mgForm.getFileType()));
			cpsDocTO.setGroupName("MGFORMS");
			cpsDocTO.setPrimaryKey(mgForm.getMgFormId() + "");
			cpsDocTO.setFormType(mgForm.getMgFormType());
			cpsDocTO.setSize(Long.parseLong(fileSize + ""));
			cpsDocTO.setTableName("MGFORMS_TBL");
			return cpsDocTO;
		}
		return null;

	}

	private CPSDocumentsDTO convertExhibit(final ExhibitViewTO exhibitViewTO,
			final String groupName) {

		if (null != exhibitViewTO) {
			final CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();
			cpsDocTO.setFileName(escapeSPChars(exhibitViewTO.getFileName()));
			cpsDocTO.setFileType(exhibitViewTO.getFileExtension());
			cpsDocTO.setGroupName(groupName);
			return cpsDocTO;
		}
		return null;
	}

	private CPSDocumentsDTO convertExhibit(final ExhibitDocuments documents,
			final String groupName) {

		if (null != documents) {
			final CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();
			cpsDocTO.setFileName(escapeSPChars(documents.getFileName()));
			cpsDocTO.setFileType(documents.getFileExtension());
			cpsDocTO.setFileBlob(documents.getDocument());
			cpsDocTO.setGroupName(groupName);
			cpsDocTO.setPrimaryKey(documents.getId() + "");
			return cpsDocTO;
		}
		return null;
	}

	private CPSDocumentsDTO convertInterviewForDownload(
			final Interview interview) {

		if (null != interview) {
			CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();
			cpsDocTO.setFileName(escapeSPChars(interview.getFileName()));
			cpsDocTO.setFileType(interview.getFileType());
			cpsDocTO.setFileBlob(interview.getMg16Form());
			cpsDocTO.setGroupName(INTERVIEWS);
			cpsDocTO.setPrimaryKey(interview.getInterviewId() + "");
			return cpsDocTO;
		}
		return null;

	}

	private CPSDocumentsDTO convertMgformForDownload(final MGForm mgForm) {

		if (null != mgForm) {

			final CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();
			cpsDocTO.setFileName(escapeSPChars(mgForm.getFileName()));
			cpsDocTO.setFileType(mgForm.getFileType());
			cpsDocTO.setFormType(mgForm.getMgFormType());
			cpsDocTO.setFileBlob(mgForm.getMgForm());
			cpsDocTO.setGroupName(MGFORMS);
			cpsDocTO.setPrimaryKey(mgForm.getMgFormId() + "");
			return cpsDocTO;
		}
		return null;

	}

	private CPSDocumentsDTO convertWitnessStatmentForDownload(
			final WitnessStatementTO witnessStatementTO) {

		if (null != witnessStatementTO) {

			final CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();
			cpsDocTO.setFileName(escapeSPChars(witnessStatementTO.getFileName()));
			cpsDocTO.setFileType(witnessStatementTO.getStatementFileType());
			cpsDocTO.setFileBlob(witnessStatementTO.getStatementFile());
			cpsDocTO.setGroupName(WITNESS);
			cpsDocTO.setPrimaryKey(witnessStatementTO.getStatementId() + "");
			return cpsDocTO;
		}
		return null;

	}

	/**
	 * This converter is responsible for populating the MG Forms in CPS Document
	 * Listings.
	 * 
	 * @param List
	 *            <MGForm> mgForms;
	 * @return List<CPSDocumentsTO>;
	 * */
	private List<CPSDocumentsDTO> convertMGForms(final List<MGForm> mgForms) {
		final ArrayList<CPSDocumentsDTO> cpsDocList = new ArrayList<CPSDocumentsDTO>();

		for (MGForm mgForm : mgForms) {
			final CPSDocumentsDTO cpsDocTO = convertMgform(mgForm);
			if (null != cpsDocTO) {
				cpsDocList.add(cpsDocTO);
			}
		}
		return cpsDocList;
	}

	/**
	 * This converter is responsible for downloading the interview document.
	 * 
	 * @param Interview
	 *            interview
	 * @return CPSDocumentsTO
	 * */
	private CPSDocumentsDTO convertInterview(final Interview interview) {

		final long fileSize = interviewService.getInterviewFileSize(interview
				.getInterviewId());

		if (null != interview && fileSize > 0) {
			final CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();
			cpsDocTO.setFormId(interview.getInterviewId());
			cpsDocTO.setCaseID(interview.getCaseId() + "");
			cpsDocTO.setFileName(escapeSPChars(interview.getFileName()));
			cpsDocTO.setFileType(escapeSPChars(interview.getFileType()));
			cpsDocTO.setGroupName("INTERVIEWS");
			cpsDocTO.setPrimaryKey(interview.getInterviewId() + "");
			cpsDocTO.setSize(fileSize);
			cpsDocTO.setTableName("INTERVIEW_TBL");
			return cpsDocTO;
		}
		return null;

	}

	/**
	 * This converter is responsible for populating the exhibits in CPS Document
	 * Listings.
	 * 
	 * @param List
	 *            <Interview> interviews
	 * @return List<CPSDocumentsTO>
	 * */
	private List<CPSDocumentsDTO> convertInterviews(
			final List<Interview> interviews) {

		final ArrayList<CPSDocumentsDTO> cpsDocList = new ArrayList<CPSDocumentsDTO>();

		for (Interview interview : interviews) {
			final CPSDocumentsDTO cpsDocTO = convertInterview(interview);
			if (null != cpsDocTO) {
				cpsDocList.add(cpsDocTO);
			}
		}
		return cpsDocList;
	}

	/**
	 * This converter is responsible for populating the exhibits in CPS Document
	 * Listings.
	 * 
	 * @param Exhibit
	 *            exhibit
	 * @return CPSDocumentsTO
	 * */
	private CPSDocumentsDTO convertExhibit(
			final ExhibitDocuments exhibitDocuments) {

		final long id = exhibitDocuments.getId();

		final long fileSize = exhibitService.getExhibitFileSize(id);

		if (null != exhibitDocuments && fileSize > 0) {
			final CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();
			cpsDocTO.setFormId(id);
			cpsDocTO.setGroupName(exhibitDocuments.getExhibitType());
			cpsDocTO.setFileName(escapeSPChars(exhibitDocuments.getFileName()));
			cpsDocTO.setPrimaryKey(id + "");
			cpsDocTO.setSize(fileSize);
			cpsDocTO.setTableName("EXHIBIT_TBL");
			return cpsDocTO;
		}
		return null;
	}

	/**
	 * This converter is responsible for populating the exhibits in CPS Document
	 * Listings.
	 * 
	 * @param List
	 *            <Exhibit> exhibits
	 * @return List<CPSDocumentsTO>
	 * */
	private List<CPSDocumentsDTO> convertExhibits(
			final List<ExhibitDocuments> documents) {

		final ArrayList<CPSDocumentsDTO> cpsDocList = new ArrayList<CPSDocumentsDTO>();

		for (ExhibitDocuments document : documents) {
			final CPSDocumentsDTO cpsDocTO = convertExhibit(document);
			if (null != cpsDocTO) {
				cpsDocList.add(cpsDocTO);
			}
		}
		return cpsDocList;
	}

	/**
	 * This converter is responsible for populating the CASE ACTION BOOK
	 * attachment in CPS Document Listings.
	 * 
	 * @param Attachment
	 *            attach
	 * @return CPSDocumentsTO
	 * 
	 * */
	@SuppressWarnings("unused")
	private CPSDocumentsDTO convertActionBookAttachmentForDownload(
			CaseActionBookAttachment attach, final boolean isFileBlobRequired) {
		CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();
		cpsDocTO.setFileName(attach.getAttachmentName());
		cpsDocTO.setFileType(attach.getAttachmentType());
		if (isFileBlobRequired) {
			cpsDocTO.setFileBlob(attach.getAttachmentBlob());
		}
		cpsDocTO.setGroupName(ACTION_BOOK);
		cpsDocTO.setPrimaryKey(attach.getActionAttachmentID() + "");
		return cpsDocTO;
	}

	/**
	 * This converter is responsible for populating the attachments in CPS
	 * Document Listings.
	 * 
	 * @param List
	 *            <Attachment> attachments
	 * @return List<CPSDocumentsTO>
	 * */
	@SuppressWarnings("unused")
	private List<CPSDocumentsDTO> convertActionBookAttachments(
			List<CaseActionBookAttachment> attachments, long caseId) {

		ArrayList<CPSDocumentsDTO> cpsDocList = new ArrayList<CPSDocumentsDTO>();

		if (attachments.size() > 0) {

			for (CaseActionBookAttachment attach : attachments) {

				CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();
				cpsDocTO.setCaseID(caseId + "");
				cpsDocTO.setCreatedBy(attach.getCreatedBy());
				if (null != attach.getCreationDateTime()) {
					cpsDocTO.setCreatedDate(attach.getCreationDateTime()
							.toString());
				}
				cpsDocTO.setDescription(attach.getAttachmentDescription());
				cpsDocTO.setFileName(attach.getAttachmentName());
				cpsDocTO.setFileType(attach.getAttachmentType());
				cpsDocTO.setFileBlob(attach.getAttachmentBlob());

				cpsDocTO.setGroupName("ACTION BOOK");
				cpsDocTO.setPrimaryKey(attach.getActionAttachmentID() + "");
				if (null != attach.getAttachmentBlob()) {
					cpsDocTO.setSize(Long.parseLong(attach.getAttachmentBlob().length
							+ ""));
				}
				cpsDocTO.setTableName("ACTION_ATTACHMENT_TABLE");
				cpsDocList.add(cpsDocTO);
			}
		}
		return cpsDocList;
	}

	/**
	 * Converter method for the CPSDpcsSubmit TO to Hibernate DO.
	 * 
	 * @param CPSDocumentsRequestDTO
	 *            cPSDocsSubmitTO
	 * @return CPSDocsSubmit
	 * */
	private CPSRequestTbl populateCPSRequestTblFromCPSDocumentsViewDTO(
			final CPSDocumentsViewDTO cpsDocumentsViewDTO) {

		String createdStaffName = null;
		String approverStaffName = null;

		final CPSRequestTbl cpsRequestTbl = new CPSRequestTbl();
		final List<CPSRequestDocTbl> cpsRequestDocTblList = new ArrayList<CPSRequestDocTbl>();

		final String createdStaffID = cpsDocumentsViewDTO.getCreatedStaffId();
		final String approverStaffID = cpsDocumentsViewDTO.getApproverStaffId();

		if (createdStaffID != null && !(createdStaffID.isEmpty())) {
			createdStaffName = getUserFullName(createdStaffID);
		}

		if (approverStaffID != null && !(approverStaffID.isEmpty())) {
			approverStaffName = getUserFullName(approverStaffID);
		}

		cpsRequestTbl.setCaseId(cpsDocumentsViewDTO.getCaseId());
		cpsRequestTbl
				.setSubmissionType(cpsDocumentsViewDTO.getSubmissionType());

		// Requester details
		cpsRequestTbl.setCreatedStaffId(createdStaffID);
		cpsRequestTbl.setCreatedTime(cpsDocumentsViewDTO.getCreatedTime());
		cpsRequestTbl.setRequesterMessage(cpsDocumentsViewDTO
				.getRequesterMessage());
		cpsRequestTbl.setCreatedStaffName(createdStaffName);

		final String requestedData = cpsDocumentsViewDTO.getRequestedData();
		final String[] dataArray = requestedData.split(",");

		for (final String data : dataArray) {
			final CPSRequestDocTbl docTbl = new CPSRequestDocTbl();
			final String[] grpDocID = data.split("-");
			String grp = grpDocID[0];
			String docID = grpDocID[1];

			docTbl.setDocumentID(Long.valueOf(docID));
			docTbl.setDocumentType(grp);
			docTbl.setApproverStaffId(approverStaffID);
			docTbl.setApproverStaffName(approverStaffName);
			docTbl.setApproverResponseTime(cpsDocumentsViewDTO
					.getApproverResponseTime());
			docTbl.setApproverMessage(cpsDocumentsViewDTO.getApproverMessage());
			docTbl.setRequestStatus(cpsDocumentsViewDTO.getRequestStatus());
			cpsRequestDocTblList.add(docTbl);
		}
		cpsRequestTbl.setCpsRequestDocTbls(cpsRequestDocTblList);

		return cpsRequestTbl;
	}

	/**
	 * Converter method for the CPSDpcsSubmit DO to Hibernate TO.
	 * 
	 * @param CPSDocuments
	 *            cPSDocsSubmit
	 * @return CPSDocsSubmitTO
	 * */
	private List<CPSDocumentsViewDTO> populateCPSDocumentsRequestsHistory(
			final List<CPSRequestTbl> cpsRequestTbls) {

		if (null == cpsRequestTbls) {
			return null;
		}

		final List<CPSDocumentsViewDTO> cpsDocumentsViewDTOList = new CopyOnWriteArrayList<CPSDocumentsViewDTO>();

		for (CPSRequestTbl cpsRequestTbl : cpsRequestTbls) {
			cpsDocumentsViewDTOList
					.addAll(populateCPSDocumentsRequestDTOFromCPSDocumentsReqHistory(cpsRequestTbl));
		}

		return cpsDocumentsViewDTOList;
	}

	/**
	 * Converter method populates CPSDocumentsRequestDTO from CPSDocuments.
	 * 
	 * @param CPSDocuments
	 *            cpsDocument
	 * @return CPSDocumentsRequestDTO
	 * */
	private CPSDocumentsViewDTO populateDTOFromEntity(
			final CPSRequestTbl cpsRequestTbl) {

		if (null == cpsRequestTbl) {
			return null;
		}
		String approverName = null;
		String approverStaffId = null;
		String requestStatus = null;

		final CPSRequestDocTbl cpsReqDoc = cpsRequestTbl.getCpsRequestDocTbls()
				.get(0);

		if (cpsReqDoc != null) {
			approverName = cpsReqDoc.getApproverStaffName();
			approverStaffId = cpsReqDoc.getApproverStaffId();
			requestStatus = cpsReqDoc.getRequestStatus();
		}

		final CPSDocumentsViewDTO cpsDocumentsViewDTO = new CPSDocumentsViewDTO();

		// Requester details
		cpsDocumentsViewDTO
				.setCreatedStaffId(cpsRequestTbl.getCreatedStaffId());
		cpsDocumentsViewDTO.setCreatedTime(cpsRequestTbl.getCreatedTime());
		cpsDocumentsViewDTO.setRequesterMessage(escapeSPChars(cpsRequestTbl
				.getRequesterMessage()));
		cpsDocumentsViewDTO.setCreatedStaffName(escapeSPChars(cpsRequestTbl
				.getCreatedStaffName()));

		// Approver details
		cpsDocumentsViewDTO.setApproverStaffId(approverStaffId);
		cpsDocumentsViewDTO.setApproverStaffName(escapeSPChars(approverName));

		// Request details
		cpsDocumentsViewDTO.setCpsReqId(String.valueOf(cpsRequestTbl
				.getCpsReqId()));
		cpsDocumentsViewDTO.setCaseId(cpsRequestTbl.getCaseId());
		cpsDocumentsViewDTO
				.setSubmissionType(cpsRequestTbl.getSubmissionType());
		cpsDocumentsViewDTO.setRequestStatus(requestStatus);

		return cpsDocumentsViewDTO;
	}

	private CPSDocumentsViewDTO populateCPSDocViewDTO(
			final CPSDocumentsView cpsDocumentView) {

		if (null == cpsDocumentView) {
			return null;
		}
		final CPSDocumentsViewDTO cpsDocumentsViewDTO = new CPSDocumentsViewDTO();

		// Requester details
		cpsDocumentsViewDTO.setCreatedStaffId(cpsDocumentView
				.getCreatedStaffId());
		cpsDocumentsViewDTO.setCreatedTime(cpsDocumentView.getCreatedTime());
		cpsDocumentsViewDTO.setRequesterMessage(escapeSPChars(cpsDocumentView
				.getRequesterMessage()));
		cpsDocumentsViewDTO.setCreatedStaffName(escapeSPChars(cpsDocumentView
				.getCreatedStaffName()));

		// Approver details
		cpsDocumentsViewDTO.setApproverStaffId(cpsDocumentView
				.getApproverStaffId());
		cpsDocumentsViewDTO.setApproverResponseTime(cpsDocumentView
				.getApproverResponseTime());
		cpsDocumentsViewDTO.setApproverMessage(escapeSPChars(cpsDocumentView
				.getApproverMessage()));
		cpsDocumentsViewDTO.setApproverStaffName(escapeSPChars(cpsDocumentView
				.getApproverStaffName()));

		// Request details
		cpsDocumentsViewDTO.setCpsReqId(String.valueOf(cpsDocumentView
				.getCpsReqId()));
		cpsDocumentsViewDTO.setCaseId(cpsDocumentView.getCaseId());
		cpsDocumentsViewDTO
				.setRequestStatus(cpsDocumentView.getRequestStatus());
		cpsDocumentsViewDTO.setSubmissionType(cpsDocumentView
				.getSubmissionType());
		cpsDocumentsViewDTO.setDocumentType(cpsDocumentView.getDocumentType());
		cpsDocumentsViewDTO.setDocumentID(cpsDocumentView.getDocumentID());
		cpsDocumentsViewDTO.setCpsDocReqId(String.valueOf(cpsDocumentView
				.getCpsDocRequestId()));

		return cpsDocumentsViewDTO;
	}

	/**
	 * Converter method populates CPSDocumentsRequestDTO from CPSDocuments.
	 * 
	 * @param CPSDocuments
	 *            cpsDocument
	 * @return CPSDocumentsRequestDTO
	 * */
	private List<CPSDocumentsViewDTO> populateCPSDocumentsRequestDTOFromCPSDocumentsReqHistory(
			final CPSRequestTbl cpsRequestTbl) {

		if (null == cpsRequestTbl) {
			return null;
		}

		final List<CPSDocumentsViewDTO> cpsDocumentsViewDTOList = new CopyOnWriteArrayList<CPSDocumentsViewDTO>();

		final List<CPSRequestDocTbl> cpsRequestDocTblList = cpsRequestTbl
				.getCpsRequestDocTbls();
		for (CPSRequestDocTbl cpsRequestDocTbl : cpsRequestDocTblList) {
			final CPSDocumentsViewDTO cpsDocumentsViewDTO = new CPSDocumentsViewDTO();

			// Requester details
			cpsDocumentsViewDTO.setCreatedStaffId(cpsRequestTbl
					.getCreatedStaffId());
			cpsDocumentsViewDTO.setCreatedTime(cpsRequestTbl.getCreatedTime());
			cpsDocumentsViewDTO.setRequesterMessage(escapeSPChars(cpsRequestTbl
					.getRequesterMessage()));
			cpsDocumentsViewDTO.setCreatedStaffName(escapeSPChars(cpsRequestTbl
					.getCreatedStaffName()));

			// Approver details
			cpsDocumentsViewDTO.setApproverStaffId(cpsRequestDocTbl
					.getApproverStaffId());
			cpsDocumentsViewDTO
					.setApproverStaffName(escapeSPChars(cpsRequestDocTbl
							.getApproverStaffName()));

			// Request details
			cpsDocumentsViewDTO.setCaseId(cpsRequestTbl.getCaseId());
			cpsDocumentsViewDTO.setSubmissionType(cpsRequestTbl
					.getSubmissionType());
			cpsDocumentsViewDTO.setCpsReqId(String.valueOf(cpsRequestTbl
					.getCpsReqId()));

			cpsDocumentsViewDTO.setApproverResponseTime(cpsRequestDocTbl
					.getApproverResponseTime());
			cpsDocumentsViewDTO.setRequestStatus(cpsRequestDocTbl
					.getRequestStatus());
			cpsDocumentsViewDTO.setDocumentType(cpsRequestDocTbl
					.getDocumentType());
			cpsDocumentsViewDTO.setDocumentID(cpsRequestDocTbl.getDocumentID());
			cpsDocumentsViewDTO.setApproverMessage(escapeSPChars(cpsRequestDocTbl
					.getApproverMessage()));

			cpsDocumentsViewDTOList.add(cpsDocumentsViewDTO);
		}

		return cpsDocumentsViewDTOList;
	}

	/**
	 * Fetching the user name through the user facade layer and decorating the
	 * view object.
	 * 
	 * @param String
	 *            userID
	 * @return String
	 * */

	@Override
	public String getUserFullName(final String staffID) {

		final UserObject uObject = this.userInformationService
				.loadUserByUserIdForCPS(staffID);
		if (null != uObject) {
			return (uObject.getTitle()+" "+uObject.getFirstName() + " " + uObject.getLastName());
		}
		return null;
	}

	/**
	 * @param String
	 *            userID
	 * @return String
	 * */
	@Override
	public String getStaffNHSEmailAddress(final String staffID) {
		return staffID != null ? this.userInformationService
				.getStaffNHSEmailAddress(staffID) : "";

	}

	/**
	 * @param String
	 *            userID
	 * @return String
	 * */
	@Override
	public String getStaffNHSEmailAddressFromCPOD(final String staffID) {
		return staffID != null ? this.userInformationService
				.getStaffNHSEmailAddressFromCPOD(staffID) : "";
	}

	/**
	 * @return the cpsDocumentDao
	 */
	public CPSDocumentsDao getCPSDocumentDao() {
		return cpsDocumentsDao;
	}

	/**
	 * @param cpsDocumentDao
	 *            the cpsDocumentDao to set
	 */
	public void setCPSDocumentDao(CPSDocumentsDao cPSDocumentDao) {
		this.cpsDocumentsDao = cPSDocumentDao;
	}

	/**
	 * @return the attachmentService
	 */
	public AttachmentService getAttachmentService() {
		return attachmentService;
	}

	/**
	 * @param attachmentService
	 *            the attachmentService to set
	 */
	public void setAttachmentService(AttachmentService attachmentService) {
		this.attachmentService = attachmentService;
	}

	/**
	 * @return the exhibitService
	 */
	public ExhibitService getExhibitService() {
		return exhibitService;
	}

	/**
	 * @param exhibitService
	 *            the exhibitService to set
	 */
	public void setExhibitService(ExhibitService exhibitService) {
		this.exhibitService = exhibitService;
	}

	/**
	 * @return the interviewService
	 */
	public InterviewService getInterviewService() {
		return interviewService;
	}

	/**
	 * @param interviewService
	 *            the interviewService to set
	 */
	public void setInterviewService(InterviewService interviewService) {
		this.interviewService = interviewService;
	}

	/**
	 * @return the mgFormService
	 */
	public MGFormService getMgFormService() {
		return mgFormService;
	}

	/**
	 * @param mgFormService
	 *            the mgFormService to set
	 */
	public void setMgFormService(MGFormService mgFormService) {
		this.mgFormService = mgFormService;
	}

	/**
	 * @param userInformationService
	 *            the userInformationService to set
	 */
	public void setUserInformationService(
			UserInformationService userInformationService) {
		this.userInformationService = userInformationService;
	}

	/**
	 * @return the caseService
	 */
	public CaseService getCaseService() {
		return caseService;
	}

	/**
	 * @param caseService
	 *            the caseService to set
	 */
	public void setCaseService(CaseService caseService) {
		this.caseService = caseService;
	}

	/**
	 * @return the witnessStatementService
	 */
	public WitnessStatementService getWitnessStatementService() {
		return witnessStatementService;
	}

	/**
	 * @param witnessStatementService
	 *            the witnessStatementService to set
	 */
	public void setWitnessStatementService(
			WitnessStatementService witnessStatementService) {
		this.witnessStatementService = witnessStatementService;
	}

	/**
	 * @return the caseActionBookService
	 */
	public CaseActionBookService getCaseActionBookService() {
		return caseActionBookService;
	}

	/**
	 * @param caseActionBookService
	 *            the caseActionBookService to set
	 */
	public void setCaseActionBookService(
			CaseActionBookService caseActionBookService) {
		this.caseActionBookService = caseActionBookService;
	}

	@Override
	public List<CPSDocumentsDTO> loadAllCPSApprovedDocumentsByNativeSQL(
			String staffID, long caseID) throws ServiceException {

		final List<CPSDocumentsView> cpsDocumentsViews = cpsDocumentsDao
				.loadAllApprovedCPSDocsByNativeSql(staffID, caseID);

		final List<CPSDocumentsDTO> aprDocList = new ArrayList<CPSDocumentsDTO>();

		for (final CPSDocumentsView cpsDocumentsView : cpsDocumentsViews) {

			final String group = cpsDocumentsView.getDocumentType();
			final Long pk = cpsDocumentsView.getDocumentID();

			final CPSDocumentsDTO cpsDocumentsDTO = downloadCPSDocument(pk,
					Long.valueOf(caseID), group, false);

			final Long fileSize = cpsMailService.getFileSize(pk, group);

			if (cpsDocumentsDTO != null) {

				final Timestamp latestEmailedDate = cpsMailService
						.isDocumentSent(group + "-" + pk);

				String emailStatus = null;

				if (latestEmailedDate != null) {
					emailStatus = "Sent";
				}

				cpsDocumentsDTO.setSize(fileSize);
				cpsDocumentsDTO.setMailDate(latestEmailedDate);
				cpsDocumentsDTO.setSubmissionType(cpsDocumentsView
						.getSubmissionType());
				cpsDocumentsDTO.setApproverResponseTime(cpsDocumentsView
						.getApproverResponseTime());
				cpsDocumentsDTO.setMailStatus(emailStatus);
				cpsDocumentsDTO.setCaseID(String.valueOf(cpsDocumentsView
						.getCaseId()));
				aprDocList.add(cpsDocumentsDTO);
			}
		}

		return aprDocList;
	}

	/**
	 * This service method is responsible to populate CPSFileNamingRulesDocument
	 * from CPSFileNamingRulesDocumentDTO.
	 * 
	 * @param CPSFileNamingRulesDocumentDTO
	 * 
	 * @return CPSFileNamingRulesDocument
	 * 
	 * */

	private CPSFileNamingRulesDocument populateCPSFileNamingRulesDocumentFromCPSFileNamingDocumentDTO(
			final CPSFileNamingRulesDocumentDTO cpsFileNamingRulesDocumentDTO) {
		final CPSFileNamingRulesDocument cpsFileNamingRulesDocument = new CPSFileNamingRulesDocument();

		cpsFileNamingRulesDocument.setDocument(cpsFileNamingRulesDocumentDTO
				.getDocument());
		cpsFileNamingRulesDocument.setCreatedTime(cpsFileNamingRulesDocumentDTO
				.getCreatedTime());

		cpsFileNamingRulesDocument
				.setDocumentName(cpsFileNamingRulesDocumentDTO
						.getDocumentName());
		return cpsFileNamingRulesDocument;
	}

	/**
	 * This service method is responsible to populate
	 * CPSFileNamingRulesDocumentDTO from CPSFileNamingRulesDocument.
	 * 
	 * @param CPSFileNamingRulesDocument
	 * 
	 * @return CPSFileNamingRulesDocumentDTO
	 * 
	 * */

	private CPSFileNamingRulesDocumentDTO populateCPSFileNamingDocumentDTOFromEntity(
			final CPSFileNamingRulesDocument cpsFileNamingRulesDocument) {
		final CPSFileNamingRulesDocumentDTO cpsFileNamingRulesDocumentDTO = new CPSFileNamingRulesDocumentDTO();

		cpsFileNamingRulesDocumentDTO.setDocument(cpsFileNamingRulesDocument
				.getDocument());
		cpsFileNamingRulesDocumentDTO
				.setDocumentName(cpsFileNamingRulesDocument.getDocumentName());

		return cpsFileNamingRulesDocumentDTO;
	}

	private List<CPSDocumentsViewDTO> populateViewDTO(
			final List<CPSDocumentsView> cpsDocumentsViews) {

		if (null == cpsDocumentsViews) {
			return null;
		}

		final List<CPSDocumentsViewDTO> cpsDocumentsViewDTOList = new CopyOnWriteArrayList<CPSDocumentsViewDTO>();

		for (final CPSDocumentsView cpsDocumentView : cpsDocumentsViews) {
			cpsDocumentsViewDTOList.add(populateCPSDocViewDTO(cpsDocumentView));
		}

		return cpsDocumentsViewDTOList;
	}

	private CPSRequestTbl populateCpsRequestTblFromDTO(
			final CPSDocumentsView documentsView, final String cpsReqID) {

		final CPSRequestTbl cpsRequestTbl = new CPSRequestTbl();

		cpsRequestTbl.setCaseId(documentsView.getCaseId());
		cpsRequestTbl.setCpsReqId(Long.valueOf(cpsReqID));
		cpsRequestTbl.setCreatedStaffId(documentsView.getCreatedStaffId());
		cpsRequestTbl.setCreatedStaffName(documentsView.getCreatedStaffName());
		cpsRequestTbl.setRequesterMessage(documentsView.getRequesterMessage());
		cpsRequestTbl.setCreatedTime(documentsView.getCreatedTime());
		cpsRequestTbl.setSubmissionType(documentsView.getSubmissionType());

		return cpsRequestTbl;
	}

	private List<CPSMailFormFieldsDTO> populateCPSMailFormFieldsDTO(
			final List<CPSMailFormFields> cpsMailFormFields,
			final SessionUser sessionUser, final String caseID,
			final String caseNumber) throws ServiceException {

		String firstName = "";
		String lastName = "";

		final List<CPSMailFormFieldsDTO> cpsMailFormFieldsDTOs = new ArrayList<CPSMailFormFieldsDTO>();

		final String cpsURN = caseService.loadCPSURN(Long.parseLong(caseID));
		final Person person = caseService.loadSubjectsByCaseIdForCps(Long
				.valueOf(caseID));

		if (person != null) {
			lastName = person.getLastName().toUpperCase();
			firstName = person.getFirstName();
		}

		for (CPSMailFormFields fields : cpsMailFormFields) {
			final CPSMailFormFieldsDTO cpsMailFormFieldsDTO = new CPSMailFormFieldsDTO();

			cpsMailFormFieldsDTO.setInvestigationStage(fields
					.getInvestigationStage());

			cpsMailFormFieldsDTO.setAction(fields.getAction());

			String requiredInfo = fields.getRequiredInfo();
			String subject = fields.getSubjectHeader();

			requiredInfo = requiredInfo.replace("{SURNAME}", lastName).replace(
					"{Firstname}", firstName);
			cpsMailFormFieldsDTO.setRequiredInfo(requiredInfo);

			if (subject.contains("{CPS_URN}")) {
				if (cpsURN != null) {
					subject = subject.replace("{CPS_URN}", cpsURN);
				} else {
					subject = subject.replace("{CPS_URN}", "");
				}
			}

			subject = subject.replace("{SURNAME}", lastName)
					.replace("{Firstname}", firstName)
					.replace("{CASE_REF}", caseNumber);

			cpsMailFormFieldsDTO.setSubjectHeader(subject);
			cpsMailFormFieldsDTOs.add(cpsMailFormFieldsDTO);

		}

		return cpsMailFormFieldsDTOs;
	}

	/**
	 * This converter is responsible for populating the exhibits in CPS Document
	 * Listings.
	 * 
	 * @param WitnessStatementTO
	 *            witnessStatementTO
	 * @return CPSDocumentsTO
	 * 
	 * */
	private CPSDocumentsDTO convertWitnessStatment(
			final WitnessStatementTO witnessStatementTO) {

		final long fileSize = witnessStatementService
				.getWitnessStatementFileSize(witnessStatementTO
						.getStatementId());

		if (null != witnessStatementTO && fileSize > 0) {

			CPSDocumentsDTO cpsDocTO = new CPSDocumentsDTO();

			if (null != witnessStatementTO.getWitness()
					&& null != witnessStatementTO.getWitness().getCaseId()) {

				cpsDocTO.setCaseID(witnessStatementTO.getWitness().getCaseId()
						.toString());
			}
			cpsDocTO.setFormId(witnessStatementTO.getStatementId());
			cpsDocTO.setFileName(escapeSPChars(witnessStatementTO.getFileName()));
			cpsDocTO.setFileType(escapeSPChars(witnessStatementTO
					.getStatementFileType()));
			cpsDocTO.setGroupName("WITNESS");
			cpsDocTO.setPrimaryKey(witnessStatementTO.getStatementId() + "");
			cpsDocTO.setSize(fileSize);
			cpsDocTO.setTableName("WITNESS_STATEMENT_TBL");
			return cpsDocTO;
		}
		return null;

	}
}
