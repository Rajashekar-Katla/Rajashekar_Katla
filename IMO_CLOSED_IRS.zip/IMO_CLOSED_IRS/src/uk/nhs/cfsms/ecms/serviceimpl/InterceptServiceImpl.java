package uk.nhs.cfsms.ecms.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.InterceptDao;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.InterceptService;

@Service(value="interceptFacade")
@Transactional
public class InterceptServiceImpl implements InterceptService {

	@Autowired
	private InterceptDao interceptDao;
	
	public boolean authorizeUserByACL(SessionUser user, Long interceptId) {
		
		return interceptDao.authorizeUserByACL(user, interceptId);
	}
	
	/**
	 * Setter for Intercept DAO.
	 * 
	 * @param interceptDao
	 */
	public void setInterceptDao(InterceptDao interceptDao) {
		this.interceptDao = interceptDao;
	}

	
}
