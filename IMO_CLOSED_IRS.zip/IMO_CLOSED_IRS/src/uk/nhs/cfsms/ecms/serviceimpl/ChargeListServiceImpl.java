package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.ChargeListDao;
import uk.nhs.cfsms.ecms.data.sanction.ChargeList;
import uk.nhs.cfsms.ecms.service.ChargeListService;


@Service(value="chargeListFacade")
@Transactional
public class ChargeListServiceImpl extends BaseServiceImpl implements ChargeListService {
	
	@Autowired
	private ChargeListDao chargeListDAO;
	public List<ChargeList> getChargeLists(Long criminalSanctionId) {
		return chargeListDAO.getChargeLists(criminalSanctionId);
	}
}
