package uk.nhs.cfsms.ecms.serviceimpl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.CourtAppearanceDao;
import uk.nhs.cfsms.ecms.dao.CriminalSanctionDao;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppealView;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanction;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionView;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.data.sanction.PoliceCharge;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalSanctionTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.CriminalSanctionService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

@Service(value = "criminalSanctionFacade")
@Transactional
public class CriminalSanctionServiceImpl extends BaseServiceImpl implements
		CriminalSanctionService {

	@Autowired
	private CourtAppearanceDao courtAppearanceDao;

	@Autowired
	private CriminalSanctionDao criminalSanctionDao;

	/**
	 * Setters for the DAO.
	 * 
	 * @param courtAppearanceDao
	 */
	public void setCourtAppearanceDao(CourtAppearanceDao courtAppearanceDao) {
		this.courtAppearanceDao = courtAppearanceDao;
	}

	public void setCriminalSanctionDao(CriminalSanctionDao criminalSanctionDao) {
		this.criminalSanctionDao = criminalSanctionDao;
	}

	public List<CriminalSanctionTO> loadCriminalSanctions(Long caseId)
			throws ServiceException {

		List<CriminalSanctionView> cs = criminalSanctionDao
				.loadCriminalSanctions(caseId);
		List<CriminalSanctionTO> res = new ArrayList<CriminalSanctionTO>();
		try {
			for (CriminalSanctionView tmp: cs) {
				
				CriminalSanctionTO csTO = convertToTransferObject(tmp);
				
				List<CriminalAppealView> appList = criminalSanctionDao.loadAppealsByParentSanctionId(csTO.getCriminalSanctionId());
			
				csTO.setAppealExists((null != appList && appList.size() > 0) ? true : false);
					
				res.add(csTO);
			}
		} catch (ServiceException se) {
			throw se;
		}
		return res;
	}

	public List<CriminalSanctionTO> loadCriminalSanctionsForReport(Long caseId)
			throws ServiceException {

		List<CriminalSanctionView> cs = criminalSanctionDao
				.loadCriminalSanctions(caseId);
		
		List<CriminalSanctionTO> res = new ArrayList<CriminalSanctionTO>();
		try {
			for (CriminalSanctionView tmp: cs) {
				CriminalSanctionTO csTO = convertToTransferObject(tmp);
				csTO.setCourtAppearanceList(courtAppearanceDao
						.loadCourtAppearancesByType(
								csTO.getCriminalSanctionId(), "criminal"));
				csTO.setOutcome(loadCriminalSanctionOutcome(csTO
						.getCriminalSanctionId()));
				res.add(csTO);
			}
		} catch (ServiceException se) {
			throw se;
		}

		return res;
	}

	@Override
	public void deleteObject(Object o) throws ServiceException {

		CriminalSanctionTO csto = (CriminalSanctionTO) o;
		try {
			CriminalSanction csdo = convertToDataObject(csto);
			super.deleteObject(csdo);
		} catch (ServiceException se) {
			throw se;
		}
	}

	@Override
	public void evictObject(Object o) throws ServiceException {
		CriminalSanctionTO csto = (CriminalSanctionTO) o;
		try {
			CriminalSanction csdo = convertToDataObject(csto);
			super.evictObject(csdo);
		} catch (ServiceException se) {
			throw se;
		}

	}

	public CriminalSanctionTO getCriminalSanction(Long sanctionId)
			throws ServiceException {

		CriminalSanctionTO csto = null;
		CriminalSanctionView view = criminalSanctionDao
				.loadCriminalSanctionView(sanctionId);

		if (null != view) {

			csto = convertToTransferObject(view);

		} else {
			csto = new CriminalSanctionTO();
		}
		return csto;
	}

	@Override
	public Object getObject(Class thisClass, Long id) throws ServiceException {
		
		CriminalSanctionView view = (CriminalSanctionView) criminalSanctionDao.getObject(
				CriminalSanctionView.class, id);

		if (null != view) { 
			CriminalSanctionTO csto = convertToTransferObject(view);
			return csto;
		}
		CriminalSanctionTO csto = new CriminalSanctionTO();
		return csto;
	}

	@Override
	public List getObjects(Class thisClass) throws ServiceException {
		
		List<CriminalSanctionTO> tos = new ArrayList<CriminalSanctionTO>();
		// load all the views
		List<CriminalSanctionView> views = super.getObjects(CriminalSanctionView.class);
		
		for (CriminalSanctionView csview: views) {
			
			CriminalSanctionTO to = convertToTransferObject(csview);
			tos.add(to);
		}

		return tos;

	}

	@Override
	public void saveObject(Object o) throws ServiceException {

		if (o instanceof CriminalSanctionTO) {
			CriminalSanctionTO to = (CriminalSanctionTO) o;
			CriminalSanction csdo = convertToDataObject(to);
			super.saveObject(csdo);
		} else {
			throw new ServiceException(new IllegalArgumentException(
					"Parameter must be of type CriminalSanctionTO"));
		}

	}

	@Override
	public void saveObjects(List objects) throws ServiceException {

		Iterator it = objects.iterator();
		List list = new ArrayList();

		while (it.hasNext()) {
			CriminalSanctionTO csto = (CriminalSanctionTO) it.next();
			CriminalSanction csdo = convertToDataObject(csto);
			list.add(csdo);
		}

		super.saveObjects(list);
	}

	private CriminalSanction convertToDataObject(
			CriminalSanctionTO criminalSanctionTO) throws ServiceException {

		CriminalSanction csDO = new CriminalSanction();
		try {
			BeanUtils.copyProperties(csDO, criminalSanctionTO);
			if (criminalSanctionTO.getCaseId() == null) {
				csDO.setCaseId(null);
			}
			if (criminalSanctionTO.getCriminalSanctionId() == null) {
				csDO.setCriminalSanctionId(null);
			}
			if (criminalSanctionTO.getSubjectId() == null) {
				csDO.setSubjectId(null);
			}

		} catch (InvocationTargetException iae) {
			throw new ServiceException(iae);
		} catch (IllegalAccessException e) {
			throw new ServiceException(e);
		}

		return csDO;

	}

	private CriminalSanctionTO convertToTransferObject(
			CriminalSanctionView criminalSanctionDO) throws ServiceException {

		CriminalSanctionTO csTO = new CriminalSanctionTO();
		try {
			BeanUtils.copyProperties(csTO, criminalSanctionDO);
			if (criminalSanctionDO.getCaseId() == null) {
				csTO.setCaseId(null);
			}
			if (criminalSanctionDO.getCriminalSanctionId() == null) {
				csTO.setCriminalSanctionId(null);
			}
			if (criminalSanctionDO.getSubjectId() == null) {
				csTO.setSubjectId(null);
			}
		} catch (InvocationTargetException iae) {
			throw new ServiceException(iae);
		} catch (IllegalAccessException e) {
			throw new ServiceException(e);
		}

		return csTO;

	}

	public PoliceCharge loadPoliceCharge(Long sanctionId)
			throws ServiceException {

		try {
			List<PoliceCharge> ps = criminalSanctionDao
					.loadPoliceCharge(sanctionId);

			if (ps != null && !ps.isEmpty()) {
				return ps.get(0);
			}
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		return null;
	}

	public PoliceCharge savePoliceCharge(PoliceCharge charge)
			throws ServiceException {

		return criminalSanctionDao.savePoliceCharge(charge);
	}

	public CriminalSanctionOutcome loadCriminalSanctionOutcome(Long sanctionId)
			throws ServiceException {

		CriminalSanctionOutcome outcome = null;
		try {
			List<CriminalSanctionOutcome> list = criminalSanctionDao
					.loadCriminalSanctionOutcome(sanctionId);
			if (list != null && !list.isEmpty()) {

				outcome = list.get(0);
				Long outcomeId = outcome.getOutcomeId();
				// just to load it lazily as part of transaction
				Hibernate.initialize(outcome.getOutcomeOrders());
				// loading Applied sanctions as a add on.
				outcome.setOutcomeAppliedSanctions(loadCriminalAppliedSanctions(outcomeId));
				Hibernate.initialize(outcome.getOutcomeAppliedSanctions());
			}
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		if (outcome == null) {
			outcome = new CriminalSanctionOutcome();
			outcome.setCriminalSanctionId(sanctionId);
		}
		return outcome;
	}

	private List<OutcomeAppliedSanction> loadCriminalAppliedSanctions(
			Long outcomeId) {

		return criminalSanctionDao.loadAppliedSanctions(outcomeId,
				CaseUtil.APPLIED_SANCTION_TYPE.CRIMINAL.toString());
	}

	public CriminalSanctionOutcome saveOutcome(CriminalSanctionOutcome dto)
			throws ServiceException {

		CriminalSanctionOutcome outcome = criminalSanctionDao
				.saveCriminalSanctionOutcome(dto);

		CriminalSanctionTO sanction = this.getCriminalSanction(dto
				.getCriminalSanctionId());
		sanction.setState(outcome.getOutcomeStatus());

		this.saveObject(sanction);

		return outcome;
	}

	@Override
	public void deleteCriminalSanctionById(Long sanctionId)
			throws ServiceException {

		CriminalSanction sanction = null;
		Object obj = criminalSanctionDao.getObject(CriminalSanction.class,
				sanctionId);

		List<CriminalSanctionOutcome> outcomeList = criminalSanctionDao
				.loadCriminalSanctionOutcome(sanctionId);
		criminalSanctionDao.deleteObjects(outcomeList);

		if (obj instanceof CriminalSanction) {
			sanction = (CriminalSanction) obj;
		} else if (obj instanceof ArrayList) {
			List list = (ArrayList) obj;
			sanction = (CriminalSanction) list.get(0);
		}
		criminalSanctionDao.deleteObject(sanction);
	}

}
