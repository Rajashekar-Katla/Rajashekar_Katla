package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.FileUploadDao;
import uk.nhs.cfsms.ecms.data.common.FileObject;
import uk.nhs.cfsms.ecms.service.FileUploadService;

@Service(value="fileUploadFacade")
@Transactional
public class FileUploadServiceImpl implements FileUploadService {

	@Autowired
	private FileUploadDao fileUploadDao;

	public FileObject saveFile(FileObject file) {

		return fileUploadDao.saveFile(file);
	}

	public FileObject updateFile(FileObject file) {

		return fileUploadDao.updateFile(file);
	}

	public void deleteFile(Long fileId) {
		FileObject file = fileUploadDao.loadFileByFileId(fileId);

		fileUploadDao.deleteFile(file);
	}

	public FileObject loadFileByFileId(Long fileId) {

		return fileUploadDao.loadFileByFileId(fileId);
	}

	public List<FileObject> loadFileByFileByDept(String dept) {

		return fileUploadDao.loadFileByFileByDept(dept);
	}

	public FileUploadDao getFileUploadDao() {

		return fileUploadDao;
	}

	public void setFileUploadDao(FileUploadDao fileUploadDao) {

		this.fileUploadDao = fileUploadDao;
	}

	@Override
	public List<FileObject> loadFileByFileByCategory(String category) {

		return fileUploadDao.loadFileByFileByCategory(category);
	}
	
	public Boolean isUserUploadAdmin(String category, String staffId) {
		
		return fileUploadDao.isUserUploadAdmin(category, staffId);
	}
}