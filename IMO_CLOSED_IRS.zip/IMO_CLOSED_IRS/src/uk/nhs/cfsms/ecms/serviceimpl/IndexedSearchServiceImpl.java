package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.IndexedSearchDao;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;
import uk.nhs.cfsms.ecms.dto.search.SearchResultsTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.IndexedSearchService;
@Service(value="indexedSearchFacade")
@Transactional
public class IndexedSearchServiceImpl implements IndexedSearchService {

	@Autowired
	private IndexedSearchDao indexedSearchDao;

	public SearchResultsTO getCaseIndexedSearchResults(String keywords,
			SessionUser user) {

		return indexedSearchDao.getCaseIndexedSearchResults(keywords, user);
	}

	public List<SearchResultsTO> getInformationIndexedSearchResults(
			String keywords, String staffId, boolean regionalCode,
			boolean orgCode, List<UserDirectorate> directorates,
			String[] responsibilites) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setIndexedSearchDao(IndexedSearchDao indexedSearchDao) {
		this.indexedSearchDao = indexedSearchDao;
	}

	public SearchResultsTO getCaseSearchResultDetails(Long searchId,
			Long caseId, SessionUser user) {

		return indexedSearchDao.getCaseSearchResultDetails(searchId, caseId,
				user);
	}

	public SearchResultsTO getInformationIndexedSearchResults(String keywords,
			SessionUser user) {
		return indexedSearchDao.getInformationIndexedSearchResults(keywords,
				user);
	}

	public SearchResultsTO getInformationSearchDetails(Long searchId,
			Long caseId, SessionUser user) {
		return indexedSearchDao.getInformationResultDetails(searchId, caseId,
				user);
	}

}
