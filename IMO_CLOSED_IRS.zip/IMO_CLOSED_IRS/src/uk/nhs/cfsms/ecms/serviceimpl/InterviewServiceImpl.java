package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.List;

import org.dom4j.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.InterviewDao;
import uk.nhs.cfsms.ecms.data.cim.Interview;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.InterviewService;
import uk.nhs.cfsms.ecms.service.TransformService;

@Service(value = "interviewFacade")
@Transactional
public class InterviewServiceImpl extends BaseServiceImpl implements
		InterviewService {

	@Autowired
	private TransformService transformService;

	@Autowired
	private InterviewDao interviewDAO;

	public List getInterviewsUploaded(Long caseId) {
		return interviewDAO.getInterviewsUploaded(caseId);
	}
	
	public List<Interview> getInterviewsForCPS(final Long caseId) {
		return interviewDAO.getInterviewsForCPS(caseId);
	}

	public Interview downloadInterviewsForCPS(final Long interviewId,
			final boolean isFileBlobRequired) {
		return interviewDAO.downloadInterviewForCps(interviewId,
				isFileBlobRequired);
	}

	public Long getInterviewFileSize(final long interviewId) {
		return interviewDAO.getInterviewFileSize(interviewId);
	}

	public List getInterviews(Long caseId) {
		return interviewDAO.getInterviews(caseId);

	}

	public Interview loadInterview(Long interviewId) {
		Interview i = interviewDAO.loadInterview(interviewId);
		return i;
	}

	public Interview updateInterviewFileName(final Long interviewId,
			final String fileName) {
		Interview interview = interviewDAO.updateInterviewFileName(interviewId,
				fileName);
		return interview;
	}

	public Document transform(String stylesheet, Interview interview)
			throws ServiceException {

		uk.nhs.cfsms.ecms.xml.Interview interviewXML = new uk.nhs.cfsms.ecms.xml.Interview();
		interviewXML.execute(interview);
		Document document = interviewXML.getInterviewDocument();
		Document transformedDocument = transformService.transform(stylesheet,
				document);

		return transformedDocument;

	}

	public TransformService getTransformService() {
		return transformService;
	}

	public void setTransformService(TransformService transformService) {
		this.transformService = transformService;
	}

	@Override
	public void deleteInterviewById(Long interviewId) throws ServiceException {
		Interview interview = interviewDAO.loadInterview(interviewId);
		this.deleteObject(interview);
	}

}
