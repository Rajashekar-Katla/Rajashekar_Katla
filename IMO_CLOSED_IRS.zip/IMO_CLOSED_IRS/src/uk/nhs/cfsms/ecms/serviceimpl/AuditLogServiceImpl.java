package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.audit.AuditLogsCommand;
import uk.nhs.cfsms.ecms.audit.CustomTrackingRevisionEntity;
import uk.nhs.cfsms.ecms.audit.RevisionedEntityInfo;
import uk.nhs.cfsms.ecms.dao.AuditLogDao;
import uk.nhs.cfsms.ecms.data.common.AuditLog;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AuditLogService;

@Service(value="auditLogFacade")
@Transactional
public class AuditLogServiceImpl implements AuditLogService {

	@Autowired
	private AuditLogDao auditLogDao; 
	
	public void save(AuditLog auditLog) {
		auditLogDao.save(auditLog);
	}

	public AuditLogDao getAuditLogDao() {
		return auditLogDao;
	}
	
	public void setAuditLogDao(AuditLogDao auditLogDao) {
		this.auditLogDao = auditLogDao;
	}		
   
    public AuditLog setPropertiesData(byte[] data) {
        AuditLog auditLog;
        auditLog = new AuditLog();
        auditLog.setByteData(data);                    
        return auditLog;
    }
    
    public void save(String properties, String state, String staffId,  long objectId) {
    	save(properties, state, "general", staffId,  objectId);  	
    }    
	  
    public void save(String properties, String state, String action, String staffId,  long objectId) {
    	AuditLog auditLog = setProperties(properties);
    	auditLog.setCreatedDate(new Date());
    	auditLog.setState(state);
    	auditLog.setUserId(staffId);
    	auditLog.setObjectId(objectId);
    	auditLog.setAction(action);
    	save(auditLog);
    }
    
    public void save(Class objectClass, String properties, String state, String action, String staffId,  long objectId) {
    	AuditLog auditLog = setProperties(properties);
    	auditLog.setCreatedDate(new Date());
    	auditLog.setState(state);
    	auditLog.setUserId(staffId);
	    	auditLog.setObjectId(objectId);
    	
    	if (action == null) 
    		auditLog.setAction("general");
    	
    	auditLog.setAction(action);
    	auditLog.setObjectClass(objectClass);
    	save(auditLog);
    }    
    
   
    private AuditLog setProperties(String properties) {
        return setPropertiesData(properties.getBytes());
    }
    

	@Override
	public List<AuditLog> getCaseLogsByCaseId(String caseId) throws ServiceException {
	
		return auditLogDao.getCaseLogsByCaseId(new Long(caseId));
	}

	@Override
	public List<CustomTrackingRevisionEntity> getCaseLogsById(String caseId) {
		
		return auditLogDao.getCaseLogsById(caseId);
	}
	
	
	@Override
	public List<RevisionedEntityInfo> getAuditInfoForCaseAndRevision(Integer revId, Long caseId) {
		
		return auditLogDao.getAuditInfoForCaseAndRevision(revId, caseId);
	}

	@Override
	public List<CustomTrackingRevisionEntity> getLogs(
			AuditLogsCommand command) {
		
		List<CustomTrackingRevisionEntity> result = null;
		
		if(null != command){
			
			if("Information".equalsIgnoreCase(command.getLogType())) {
				
				result = auditLogDao.getInfoLogsById(command.getEntityId());
				
			} else if("Case".equalsIgnoreCase(command.getLogType())) {
				
				result = auditLogDao.getCaseLogsById(command.getEntityId().toString());
			}
		}
		
		return result;
	}

	@Override
	public List<RevisionedEntityInfo> getAuditInfo(AuditLogsCommand command) {
		
		List<RevisionedEntityInfo> result = null;
		
		if (null != command) {
			
			if ("Information".equalsIgnoreCase(command.getLogType())) {
				
				result = auditLogDao.getAuditInfoForInformationRevision(command.getRevisionID(), command.getEntityId());
				
			} else if("Case".equalsIgnoreCase(command.getLogType())){
				
				result = auditLogDao.getAuditInfoForCaseAndRevision(command.getRevisionID(), command.getEntityId());
			}
		}
		
		return result;
	}
	
	@Override
	public List<CustomTrackingRevisionEntity> getAuditDump(AuditLogsCommand command) {
		List<CustomTrackingRevisionEntity> result = null;
		if(null != command){
			boolean isCase = true;
			if("Information".equalsIgnoreCase(command.getLogType())){
				isCase = false;
			}
			result = auditLogDao.retrieveAudit(isCase, command.getEntityId());
		}
		return result;
	}
	
}
