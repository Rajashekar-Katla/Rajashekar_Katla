package uk.nhs.cfsms.ecms.serviceimpl;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.BaseDao;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.BaseService;

@Service(value="baseFacade")
@Transactional
public class BaseServiceImpl implements BaseService {
	
	
	@Qualifier(value="baseDAO")
	@Autowired
	protected BaseDao baseDao = null;

	/**
	 * @return Returns the baseDao.
	 */
	public BaseDao getBaseDao() {
		return baseDao;
	}

	/**
	 * @param baseDao The baseDao to set.
	 */
	public void setBaseDao(BaseDao baseDao) {
		this.baseDao = baseDao;
	}

	public void setDao(BaseDao baseDao) {
        this.baseDao = baseDao;
    }

    public List getObjects(Class thisClass) throws ServiceException {
        return this.baseDao.getObjects(thisClass);
    }

    public Object getObject(Class thisClass, Long id) throws ServiceException {
        return this.baseDao.getObject(thisClass, id);
    }

    public void saveObject(Object o) throws ServiceException {
        this.baseDao.saveObject(o);
    }
    
    public void saveObjects(List objects) throws ServiceException {
    	this.baseDao.saveObjects(objects);
    }

    public void deleteObject(Object o) throws ServiceException  {      
        this.baseDao.deleteObject(o);
    }

    public void evictObject(Object o) throws ServiceException {
        this.baseDao.evictObject(o);
    }

	public void deleteObjects(List objects) {
		this.baseDao.deleteObjects(objects);
	}

}
