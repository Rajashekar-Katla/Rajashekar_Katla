package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.CaseDao;
import uk.nhs.cfsms.ecms.dao.CasePermissionDao;
import uk.nhs.cfsms.ecms.dao.CaseTransferDao;
import uk.nhs.cfsms.ecms.dao.InformationDao;
import uk.nhs.cfsms.ecms.dao.OrganisationDao;
import uk.nhs.cfsms.ecms.dao.RegionCodeDao;
import uk.nhs.cfsms.ecms.dao.UserDetailsDao;
import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.cim.CasePermission;
import uk.nhs.cfsms.ecms.data.cim.CaseTransfer;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.RegionCode;
import uk.nhs.cfsms.ecms.data.common.StaffTeams;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.InfoTransferHistory;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTransferTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InfoTransferHistTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.CaseTransferService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

@Service(value="caseTransferFacade")
@Transactional
public class CaseTransferServiceImpl implements CaseTransferService {

	protected final Log logger = LogFactory.getLog(getClass());
	
	@Autowired
	private CaseDao caseDao;
	@Autowired
	private CasePermissionDao casePermissionDao;
	@Autowired
	private CaseTransferDao caseTransferDao;
	@Autowired
	private OrganisationDao organisationDao;
	@Autowired
	private RegionCodeDao regionCodeDao;
	@Autowired
	private UserDetailsDao userDetailsDao;
	@Autowired
	private InformationDao informationDao;

	public CaseTransferTO saveCaseTransfer(CaseTransferTO caseTransferTO) throws ServiceException {
		
		CaseTransfer caseTransfer = CaseUtil.convertToCaseTransferDO(caseTransferTO);

		caseTransfer = caseTransferDao.saveCaseTransfer(caseTransfer);
		
		caseTransferTO.setCaseTransferId(caseTransfer.getCaseTransferId());

		return caseTransferTO;
	}

	public CaseTransferTO loadCaseTransfersById(Long transferId) throws ServiceException {

		CaseTransfer caseTransfer = caseTransferDao.loadCaseTransferById(transferId);
		return CaseUtil.convertToCaseTransferTO(caseTransfer);
	}

	public CaseTransferTO updateCaseTransfer(CaseTransferTO caseTransferTO) throws ServiceException {
		
		CaseTransfer caseTransfer = CaseUtil.convertToCaseTransferDO(caseTransferTO);
		caseTransferDao.updateCaseTransfer(caseTransfer);
		return caseTransferTO;
	}

	public void deleteLcfsTransfer(CaseTransferTO caseTransfer) {

	}

	public CaseTransferTO loadCaseTransferById(Long transferId) throws ServiceException {
		
		CaseTransfer caseTransfer = caseTransferDao.loadCaseTransferById(transferId);

		CaseTransferTO caseTransferTO = CaseUtil.convertToCaseTransferTO(caseTransfer);

		caseTransferTO.setCaseOrgName(organisationDao.loadOrganisationByOrgCode(
					caseTransferTO.getCaseObject().getOrgCode()).getOrgName());

		UserObject createdUser = userDetailsDao.loadUserByUserId(caseTransferTO.getCreatedStaffId());

		caseTransferTO.setCaseCreatedStaffName(createdUser.getTitle() + " " + createdUser.getFirstName() + " " + createdUser.getLastName());

		if (caseTransferTO.getTransferType().equalsIgnoreCase(ECMSConstants.TRANSFER_LCFS)) {
			
			UserObject recipientUser = userDetailsDao.loadUserByUserId(caseTransferTO.getReceipentLcfs());
			
			caseTransferTO.setReceipentLcfsName(recipientUser.getTitle() + " " + recipientUser.getFirstName() + " " + recipientUser.getLastName());
		}

		return caseTransferTO;
	}

	public List<CaseTransfer> loadReceivedLcfsTransfersByUserId(String staffId) throws ServiceException {

		String[] state = { ECMSConstants.TRANSFER_REFERRED };
		List<CaseTransfer> transferList = caseTransferDao.loadLcfsTransfers(staffId, state, true);

		return transferList;
	}

	public List<CaseTransfer> loadReceivedCfsTransfersByUserId(String staffId) throws ServiceException {

		String[] state = { ECMSConstants.TRANSFER_REFERRED };
		
		List<CaseTransfer> transferList = null;
		
		List<StaffTeams> teamsList = userDetailsDao.loadTeamsByStaffId(staffId);
		
		String[] teams = getTeamsFromStaffTeamList(teamsList);
		
		if (!teamsList.isEmpty()) {
			transferList = caseTransferDao.loadCfsTransfers(teams, null, state,
					true);
		}
		return transferList;
	}

	public List<CaseTransfer> loadCreatedLcfsTransfersByUserId(String staffId) throws ServiceException {
		
		String[] state = { ECMSConstants.TRANSFER_APPROVAL_PENDING, 
				ECMSConstants.TRANSFER_REFERRED,
				ECMSConstants.TRANSFER_REJECTED,
				ECMSConstants.TRANSFER_CANCELLED };
		List<CaseTransfer> transferList = caseTransferDao.loadLcfsTransfers(staffId, state, false);
		
		return transferList;
	}

	public List<CaseTransfer> loadCreatedCfsTransfersByUserId(String staffId) throws ServiceException {

		String[] state = { ECMSConstants.TRANSFER_APPROVAL_PENDING,
				ECMSConstants.TRANSFER_REFERRED,
				ECMSConstants.TRANSFER_REJECTED,
				ECMSConstants.TRANSFER_CANCELLED };
		
		List<CaseTransfer> transferList = caseTransferDao.loadCfsTransfers(null, staffId, state, false);
		
		return transferList;
	}

	public List<CaseTransfer> loadApprovalPendingLcfsTransfersByUserId(String staffId) throws ServiceException {

		List<CaseTransfer> transferList = null;
		
		List<StaffTeams> teamsList = userDetailsDao.loadTeamsByStaffId(staffId);
		
		String[] teams = getTeamsFromStaffTeamList(teamsList);
		
		if (!teamsList.isEmpty()) {
			transferList = caseTransferDao.loadPendingApprovalLcfsTransfers(teams);
		}
		return transferList;
	}

	public List<CaseTransfer> loadApprovalPendingCfsTransfersByUserId(String staffId) throws ServiceException {

		List<CaseTransfer> transferList = null;
		
		List<StaffTeams> teamsList = userDetailsDao.loadTeamsByStaffId(staffId);
		
		String[] teams = this.getTeamsFromStaffTeamList(teamsList);
		
		if (!teamsList.isEmpty()) {
			transferList = caseTransferDao.loadPendingApprovalCfsTransfers(teams);
		}
		return transferList;
	}
	
	/**
	 * Get the Team names from the staff team list.
	 * 
	 * @param teamsList
	 * 
	 * @return string array of teams.
	 */
	private String[] getTeamsFromStaffTeamList(List<StaffTeams> teamsList) {
		
		String[] teams = new String[teamsList.size()];
		int i = 0;
		for (StaffTeams staffTeam : teamsList) {
			teams[i] = staffTeam.getTeamCode();
			i += 1;
		}
		return teams;
	}

	public CaseTransferTO saveAcceptCaseTransfer(CaseTransferTO caseTransferTO, SessionUser user) throws ServiceException {

		CaseTransfer caseTransfer = CaseUtil.convertToCaseTransferDO(caseTransferTO);
		
		caseTransferDao.updateCaseTransfer(caseTransfer);

		updateCasePermission(caseTransferTO, user);

		updateCaseRestrictTO(caseTransferTO, user);

		return caseTransferTO;
	}

	public void updateCasePermission(CaseTransferTO caseTransferTO, SessionUser sUser) throws ServiceException {

		if (caseTransferTO.getTransferType().equalsIgnoreCase(ECMSConstants.TRANSFER_CFS)) {
			
			// update the case permissions after the CFS transfer.
			 
			resetCasePermissionsAfterCFSTransfer(caseTransferTO, sUser);
 
		}

		if (caseTransferTO.getTransferType().equalsIgnoreCase(ECMSConstants.TRANSFER_LCFS)) {
		
			casePermissionDao.deleteAllExcptTeamCasePermissionsByCaseId(caseTransferTO.getCaseObject().getCaseId());

			List<CasePermission> casePermissionlist = getPermissionsForLcfsTransfer(caseTransferTO, sUser);
			
			casePermissionDao.saveCasePermissions(casePermissionlist);
		}
	}

	/**
	 * This method is responsible for updating the case permission after the CFS case transfer.
	 * This will marked all permissions as deleted and introduce new Team permissions.
	 * 
	 * @param transferTO
	 * @return boolean
	 * 
	 * */
	private boolean resetCasePermissionsAfterCFSTransfer(CaseTransferTO transferTO, SessionUser user){
		boolean status = true;
		
		@SuppressWarnings("unchecked")
		List<CasePermission> permisionsList = casePermissionDao.loadCasePermissionsByCaseId(transferTO.getCaseObject().getCaseId());
		
		for (CasePermission permission : permisionsList ) {
			
			if (!StringUtils.contains(permission.getPermissionType(), ECMSConstants.DELETE_SUFFIX)) {
				
				permission.setPermissionType(permission.getPermissionType() + ECMSConstants.DELETE_SUFFIX);
				casePermissionDao.updateCasePermission(permission);
			}
		}
		// Adding new Team permission.
		CasePermission cPermission = new CasePermission();
		cPermission.setCaseId(transferTO.getCaseObject().getCaseId());
		cPermission.setCreatedStaffId(user.getStaffId());
		cPermission.setCreatedTime(Calendar.getInstance().getTime());
		cPermission.setPermissionType(ECMSConstants.TEAM_PERMISSION);
		cPermission.setValue(transferTO.getRecipientTeamCode());
		cPermission.setStatus("Y");
		casePermissionDao.saveCasePermission(cPermission);
		
		return status;
	}
	
	public void updateCaseRestrictTO(CaseTransferTO transferTO, SessionUser user) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Updating case restrict to case access on transfer.");
		}
		Case caseObj = caseDao.loadCase(transferTO.getCaseObject().getCaseId());

		if (transferTO.getTransferType() != null && 
				transferTO.getTransferType().equalsIgnoreCase(ECMSConstants.TRANSFER_CFS)) {
			
			caseObj.setTeamCode(transferTO.getRecipientTeamCode());
		}
			
		if (user.isUserLocal()) {
			
			caseObj.setRestrictTo(ECMSConstants.LOCAL);
			if (logger.isDebugEnabled()) {
				logger.debug("*** GRANT LOCAL access to case=" + caseObj.getCaseId() + " for LOC User=" + user.getStaffId());
			}
		}
		else if (user.isUserRegional()) {
			
			if (user.isUserAntiFraudSpecialist() && !user.isUserWARO()) {

				caseObj.setRestrictTo(ECMSConstants.LOCAL);
				
				if (logger.isDebugEnabled()) {
					logger.debug("*** GRANT LOCAL access to case=" + caseObj.getCaseId() + " for REG User=" + user.getStaffId());
				}
			} else {
				
				caseObj.setRestrictTo(ECMSConstants.REGIONAL);
				
				if (logger.isDebugEnabled()) {
					logger.debug("*** GRANT REGIONAL access to case=" + caseObj.getCaseId() + " for REG User=" + user.getStaffId());
				}
			}
		}
		else if (user.isUserDirectorate()) {
			
			caseObj.setRestrictTo(ECMSConstants.NATIONAL);
			
			if (logger.isDebugEnabled()) {
				logger.debug("*** GRANT NATIONAL access to case=" + caseObj.getCaseId() + " for NAT User=" + user.getStaffId());
			}
		}
		
		caseDao.saveOrUpdate(caseObj);
	}

	/**
	 * Permissions for CFS transfers ??? 
	 * @param transferTO
	 * @param user
	 * @return
	 
	private List getPermissionsForCfsTransfer(CaseTransferTO transferTO, SessionUser user) {

		List<CasePermission> permissionList = new ArrayList<CasePermission>();
		CasePermission permission = new CasePermission();
		setCasePermission(permission, ECMSConstants.TEAM_PERMISSION, transferTO
				.getRecipientTeamCode(),
				transferTO.getCaseObject().getCaseId(), user.getStaffId());
		permissionList.add(permission);
		return permissionList;
	}
	*/

	private List getPermissionsForLcfsTransfer(CaseTransferTO transferTO, SessionUser user) {

		List<CasePermission> permissionList = new ArrayList<CasePermission>();
		CasePermission permission = new CasePermission();
		setCasePermission(permission, ECMSConstants.ASSIGNEE_PERMISSION,
				transferTO.getReceipentLcfs(), transferTO.getCaseObject(),
				user.getStaffId());
		permissionList.add(permission);
		return permissionList;
	}

	private CasePermission setCasePermission(CasePermission casePermission,
			String permType, String permValue, Case caseObj,
			String sesssionUserId) {

		casePermission.setCaseId(caseObj.getCaseId());
		casePermission.setPermissionType(permType);
		casePermission.setValue(permValue);
		casePermission.setCreatedTime(new Date());
		casePermission.setStatus("Y");
		casePermission.setCreatedStaffId(sesssionUserId);
		//TODO : ?? Controlled by DB ?? 
		casePermission.setAccessFlag(caseObj.getAccessFlag());
		return casePermission;
	}

	public List<CaseTransfer> loadPendingTransfersByCaseId(Long caseId)
			throws ServiceException {

		return caseTransferDao.loadPendingTransfersByCaseId(caseId);
	}

	public List<CaseTransfer> loadCaseLcfsTransfersByCaseId(Long caseIDLong) {

		return caseTransferDao.loadCaseLcfsTransfersByCaseId(caseIDLong);
	}

	public List<CaseTransfer> loadCaseCfsTransfersByCaseId(Long caseIDLong) {

		return caseTransferDao.loadCaseCfsTransfersByCaseId(caseIDLong);
	}

	public Case loadCaseByCaseId(Long caseId) {

		return caseDao.loadCase(caseId);
	}

	public List<Organisation> loadTeams() throws ServiceException {

		return organisationDao.loadAllTeams();
	}

	public List<UserObject> loadLcfsUsers(String teamCode) {

		String userGroup[] = { ECMSConstants.LCFS_LEVEL };
		
		List<UserObject> list = userDetailsDao.loadUsersByTeamCode(teamCode, userGroup);
		
		return list;
	}

	/**
	 * This method is responsible returning a list of transfer approvals pending for the given User ID.
	 * 
	 * @param staffId
	 * 
	 * @return List<infoTransferHistTO>
	 * */
	public List<InfoTransferHistTO> loadApprovalPendingInformationTransfersByUserId(String staffId) throws ServiceException {
		List<InfoTransferHistTO> infoTransferList = null;
		infoTransferList = convertAll(informationDao.loadPendingInformationTransfersForUser(staffId));
		return infoTransferList;
	}

	public List<RegionCode> loadRegionCodes() {

		return regionCodeDao.loadAllRegionCode();
	}

	/**
	 * Setters for the DAO
	 * 
	 * @param caseTransferDao
	 */
	public void setCaseTransferDao(CaseTransferDao caseTransferDao) {

		this.caseTransferDao = caseTransferDao;
	}

	public void setOrganisationDao(OrganisationDao organisationDao) {
		this.organisationDao = organisationDao;
	}

	public void setUserDetailsDao(UserDetailsDao userDetailsDao) {
		this.userDetailsDao = userDetailsDao;
	}

	public void setCaseDao(CaseDao caseDao) {
		this.caseDao = caseDao;
	}

	public void setCasePermissionDao(CasePermissionDao casePermissionDao) {
		this.casePermissionDao = casePermissionDao;
	}

	public void setRegionCodeDao(RegionCodeDao regionCodeDao) {
		this.regionCodeDao = regionCodeDao;
	}

	/** Getter setter for injecting information DAO Layer.*/
	public InformationDao getInformationDao() {
		return informationDao;
	}

	public void setInformationDao(InformationDao informationDao) {
		this.informationDao = informationDao;
	}
	
	/**
	 * This method is responsible for converting a DAO list object in to presentation TOList Objects.
	 * 
	 * @param infoTransferHistTO
	 * @return List<InfoTransferHistTO>
	 * 
	 * */
	
	private List<InfoTransferHistTO> convertAll(List<InfoTransferHistory> infoTransferHistTO){
		ArrayList<InfoTransferHistTO> list= null;
		
		if(null!=infoTransferHistTO){
			list= new ArrayList<InfoTransferHistTO>();
			for(InfoTransferHistory infoHist:infoTransferHistTO){
				list.add(convert(infoHist));
			}
		}
		return list;
	}
	
	/**
	 * This method is responsible for converting a DAO object in to presentation Transfer Objects.
	 * 
	 * @param infoTransferHistTO InfoTransferHistory
	 * @return InfoTransferHistTO
	 * 
	 * */
	private InfoTransferHistTO convert(InfoTransferHistory infoTransferHistTO){
		InfoTransferHistTO infoHistTo=null;
		if (null!= infoTransferHistTO) {
		
			infoHistTo=new InfoTransferHistTO();
			infoHistTo.setApproverStaffID(infoTransferHistTO.getApproverStaffID());
			infoHistTo.setCreatedStaffId(infoTransferHistTO.getCreatedStaffId());
			infoHistTo.setCreatedTime(infoTransferHistTO.getCreatedTime());
			infoHistTo.setInfoId(infoTransferHistTO.getInfoId());
			infoHistTo.setApprovalComments(infoTransferHistTO.getApprovalComments());
			infoHistTo.setState(infoTransferHistTO.getState());
			infoHistTo.setTeamCode(infoTransferHistTO.getTeamCode());
			infoHistTo.setTransferComments(infoTransferHistTO.getTransferComments());
			infoHistTo.setTransferDate(infoTransferHistTO.getTransferDate());
			infoHistTo.setTransferStaffId(infoTransferHistTO.getTransferStaffId());
			infoHistTo.setTransferTeamCode(infoTransferHistTO.getTransferTeamCode());
			infoHistTo.setTransId(infoTransferHistTO.getTransId());
			infoHistTo.setCreatedStaffName(EcmsUtils.getFullName(userDetailsDao.loadUser(infoTransferHistTO.getCreatedStaffId())));
			infoHistTo.setApproverStaffName(EcmsUtils.getFullName(userDetailsDao.loadUser(infoTransferHistTO.getApproverStaffID())));
		}
		return infoHistTo;
	}
}