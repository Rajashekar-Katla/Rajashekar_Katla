package uk.nhs.cfsms.ecms.serviceimpl;

import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.ECMSConstants.NIT_TEAMS;
import uk.nhs.cfsms.ecms.dao.CaseDao;
import uk.nhs.cfsms.ecms.dao.CasePermissionDao;
import uk.nhs.cfsms.ecms.dao.FpuReportDao;
import uk.nhs.cfsms.ecms.dao.InformationDao;
import uk.nhs.cfsms.ecms.dao.LookupViewDao;
import uk.nhs.cfsms.ecms.dao.MessageDao;
import uk.nhs.cfsms.ecms.dao.RegionCodeDao;
import uk.nhs.cfsms.ecms.dao.UserDetailsDao;
import uk.nhs.cfsms.ecms.dao.UserResponsibilitiesViewDao;
import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.cim.CaseClosure;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.cim.CaseObject;
import uk.nhs.cfsms.ecms.data.cim.CasePermission;
import uk.nhs.cfsms.ecms.data.cim.CaseSummaryInformation;
import uk.nhs.cfsms.ecms.data.cim.CaseUpdate;
import uk.nhs.cfsms.ecms.data.cim.InformationObject;
import uk.nhs.cfsms.ecms.data.cim.InvestigationPlan;
import uk.nhs.cfsms.ecms.data.cim.Message;
import uk.nhs.cfsms.ecms.data.cim.TempConfCase;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.OrganisationTeamCode;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.fpureport.FpuReport;
import uk.nhs.cfsms.ecms.data.infoGath.InfoTransferHistory;
import uk.nhs.cfsms.ecms.data.infoGath.Information;
import uk.nhs.cfsms.ecms.data.infoGath.InformationPermission;
import uk.nhs.cfsms.ecms.data.infoGath.Person;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseClosureTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.search.CaseSearchFormTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.CaseService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.InformationUtil;

@Service(value = "caseFacade")
@Transactional
public class CaseServiceImpl implements CaseService {

	@Autowired
	private CaseDao caseDao;

	@Autowired
	private CasePermissionDao casePermissionDao;

	@Autowired
	private InformationDao informationDao;

	@Autowired
	private RegionCodeDao regionCodeDao;

	@Autowired
	private LookupViewDao lookupViewDao;

	@Autowired
	private UserDetailsDao userDetailsDao;

	@Autowired
	private UserResponsibilitiesViewDao userResponsibilitiesViewDao;

	@Autowired
	private FpuReportDao fpuReportDao;

	@Autowired
	private MessageDao messageDao;

	Logger logger = Logger.getLogger(CaseServiceImpl.class);

	/**
	 * Generate Case Numbers for new cases.
	 */
	public String generateCaseNumber(CaseTO caseTo) throws ServiceException {

		try {
			return caseDao.getCaseNumber(loadCase(caseTo.getCaseId()));

		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	public List<CaseObject> loadCases(boolean regionalCode, boolean overLoaded,
			String[] responsibilites) {

		return caseDao.loadCases(regionalCode, overLoaded, responsibilites);
	}

	public CaseTO loadCase(Long id) throws ServiceException {

		Case caseDO = caseDao.loadCase(id);
		return createCaseTO(caseDO);
	}

	public String loadCaseNumber(final Long caseID) throws ServiceException {
		return caseDao.loadCaseNumber(caseID);
	}

	public String loadCPSURN(final Long caseID) throws ServiceException {
		final String cpsURN = caseDao.loadCPSURN(caseID);
		return cpsURN;
	}

	public List<CaseObject> loadCases(boolean regionalCode, boolean orgCode,
			List<UserDirectorate> directorates, String[] responsibilites) {

		return caseDao.loadCases(regionalCode, orgCode, directorates,
				responsibilites);
	}

	public List<CaseObject> loadRegionalCases(
			List<UserDirectorate> directorates, String[] responsibilites) {

		return caseDao.loadRegionalCases(directorates, responsibilites);
	}

	public List<CaseObject> loadAssignedCases(SessionUser user) {

		return caseDao.loadAssignedCases(user, user.getDirectorates());
	}

	// helper method to set a dummy directorate
	private List<UserDirectorate> getDirectorate(String level) {

		UserDirectorate userDir = new UserDirectorate();
		userDir.setDirectorateLevel(level);
		List<UserDirectorate> list = new ArrayList<UserDirectorate>();
		list.add(userDir);

		return list;
	}

	public List<CaseObject> loadCases() {

		return caseDao.loadCases();
	}

	/**
	 * Copy data from CaseTo to Case data object,then set remaining data into
	 * Case. Save the Case object then set permissions and save the permissions
	 * 
	 * @param caseTO
	 *            Case transfer object
	 * @param sessionUserId
	 *            -User id in sessionuser object.
	 * @return Case.
	 * @deprecated
	 */

	public CaseTO saveCase(CaseTO caseTO, String sessionUserId)
			throws ServiceException {

		Case caseDo = createCaseDO(caseTO);
		caseDo.setCreatedStaffId(caseTO.getAllocatedUser());
		caseDo.setCreatedTime(new Date());
		caseDo.setState("OPEN");// case is in open state initially

		// get the assigned user details and set restrict to.
		SessionUser allocatedUser = getAssignedUserDetails(caseTO
				.getAllocatedUser());
		caseDo.setCreatedStaffId(allocatedUser.getStaffId());
		// if LCFS does not have directorate list, set restrict to CFS_LOC
		caseDo.setRestrictTo(this.getRestrictToByUser(allocatedUser));
		caseDo.setIsSummaryAdded("N");

		OrganisationTeamCode orgTeamCode = caseDao.loadTeamCodeByOrgCode(caseDo
				.getOrgCode());
		if (null == orgTeamCode) {
			// TODO:
			// throw new ServiceException("TEAM CODE IS NULL");
		}
		if (orgTeamCode != null && orgTeamCode.getTeamCode() != null) {

			caseDo.setTeamCode(orgTeamCode.getTeamCode());
			caseDo.setIsOverLoadedCase("N");
			// insert the case and then insert permissions.
			caseDo = caseDao.saveCase(caseDo);

			List<CasePermission> casePermissionlist = getPermissionListByUserGroup(
					caseDo, sessionUserId, allocatedUser.getGroupPermission(),
					orgTeamCode.getTeamCode());

			// insert all the permissions.
			casePermissionDao.saveCasePermissions(casePermissionlist);

			// update case id in information object.
			Information info = informationDao.loadInformationByIdData(caseDo
					.getInformationId());
			info.setCaseId(new Long(caseDo.getCaseId().toString()));
			informationDao.updateInformationData(info);

			caseTO.setCaseId(caseDo.getCaseId());
		}
		return caseTO;

	}

	private String getRestrictToByUser(SessionUser user) {

		if (user.isUserLocal()) {
			return ECMSConstants.LOCAL;
		}
		if (user.isUserRegional()) {
			return ECMSConstants.REGIONAL;
		}
		if (user.isUserDirectorate()) {
			return ECMSConstants.NATIONAL;
		}
		return null;
	}

	/**
	 * Copy data from CaseTo to Case data object, then set isOverloaeded to Y ,
	 * Save the Case object then save the region permission. Case saved as on
	 * hold case.
	 * 
	 * @param caseTo
	 *            Case transfer object
	 * @param sessionUser
	 *            sessionuser object.
	 * @return Case.
	 * 
	 */

	public CaseTO saveHoldCase(CaseTO caseTo, SessionUser user)
			throws ServiceException {

		Case caseDo = createCaseDO(caseTo);
		caseDo.setCreatedStaffId(user.getStaffId());
		caseDo.setCreatedTime(new Date());
		caseDo.setState("OPEN");// case is in open state initially

		/*
		 * OrganisationTeamCode orgTeamCode =
		 * caseDao.loadTeamCodeByOrgCode(caseDao.getOrgCode()); if (orgTeamCode
		 * != null && orgTeamCode.getTeamCode() != null) {
		 * caseDo.setTeamCode(orgTeamCode.getTeamCode()); }
		 */
		caseDo.setIsSummaryAdded("N");
		caseDo.setIsOverLoadedCase("Y");
		caseDo.setRestrictTo(this.getRestrictToByUser(user));

		// insert the case and then insert permissions.
		caseDo = caseDao.saveCase(caseDo);

		List<CasePermission> casePermissionlist = getOnHoldPermissionList(
				caseDo, user.getStaffId());

		// insert all the permissions.
		casePermissionDao.saveCasePermissions(casePermissionlist);
		// update case id in information_tbl
		Information info = informationDao.loadInformationByIdData(caseDo
				.getInformationId());
		info.setCaseId(new Long(caseDo.getCaseId().toString()));
		informationDao.updateInformationData(info);
		caseTo.setCaseId(caseDo.getCaseId());
		// }
		return caseTo;

	}

	/**
	 * This method is nothing to do with case object, just set
	 * informationDiscarded to Y in information object and save to DB.
	 * 
	 * @param caseTo
	 *            Case transfer object
	 * @return Information
	 * 
	 */

	public Information updateTransferInformation(CaseTO caseTo,
			boolean discarded) {

		Information info = informationDao.loadInformationByIdData(caseTo
				.getInformationId());

		if (discarded) {
			info.setInformationDiscarded(ECMSConstants.INFO_DISCARD_HOLD);
			info.setRejectedComment(caseTo.getRejectedComment());
		} else {
			info.setInformationDiscarded(ECMSConstants.INFO_DISCARD_OPEN);
		}

		informationDao.updateInformationData(info);
		return info;
	}

	/**
	 * This method is nothing to do with case object, just set
	 * informationDiscarded to Y in information object and save to DB.
	 * 
	 * @param caseTo
	 *            Case transfer object
	 * @return InformationTO.
	 * 
	 */

	public Information saveTransferInfoFromCIU(CaseTO caseTo) {

		// update case id in information_tbl
		Information info = informationDao.loadInformationByIdData(caseTo
				.getInformationId());
		info.setInformationDiscarded("N");

		informationDao.updateInformationData(info);
		return info;
	}

	/**
	 * update information permissions
	 * 
	 */

	public InformationPermission updateInfoTransferToNewTeam(String newTeam,
			Long infoId, SessionUser user) throws ServiceException {

		String oldTeam = null;
		try {
			InformationPermission teamPermmision = this
					.getTeamPermission(infoId);
			if (null != teamPermmision) {

				oldTeam = teamPermmision.getPermissionValue();
			}
			// Delete Assignee, Organisation and Team permissions
			this.deleteAssigneeOrgAndTeamPermissions(infoId, newTeam);

			/*
			 * Create Read-only permissions for OFM/AFL/AAFS. if (null !=
			 * oldTeam) {
			 * 
			 * UserObject manager = informationDao.getOFMByTeamCode(oldTeam); if
			 * (null != manager) { this.createReadOnlyPermissions(infoId,
			 * manager.getStaffId()); } }
			 */
			InformationPermission teamPerm = InformationUtil
					.createInfoPermission(infoId,
							ECMSConstants.TEAM_PERMISSION, newTeam,
							user.getStaffId());

			return informationDao.updatePermission(teamPerm);

		} catch (Exception e) {

			logger.error("ERROR creating permissions: " + e.getMessage());
			throw new ServiceException(e);
		}
	}

	private InformationPermission getTeamPermission(Long infoId) {

		InformationPermission teamPermission = this.getInformationPermission(
				infoId, ECMSConstants.TEAM_PERMISSION);

		return teamPermission;
	}

	private void deleteAssigneeOrgAndTeamPermissions(Long infoId, String newTeam) {

		// INFO ASSIGNEE PERMISSION
		List<InformationPermission> assigneePermissions = this
				.getInfoPermissionList(infoId,
						ECMSConstants.INFO_ASSIGNEE_PERMISSION);
		// Updating assignee permission to delete state
		for (InformationPermission assigneePermission : assigneePermissions) {

			if (null != assigneePermission) {

				assigneePermission
						.setPermissionType(ECMSConstants.INFO_ASSIGNEE_PERMISSION_DELETE);
				informationDao.updatePermission(assigneePermission);
			}
		}
		// READ ONLY PERMISSIONS.
		List<InformationPermission> readOnlyPermissions = this
				.getInfoPermissionList(infoId,
						ECMSConstants.INFO_PERMISSION_READ_ONLY);

		for (InformationPermission readPermission : readOnlyPermissions) {

			if (null != readPermission) {

				readPermission
						.setPermissionType(ECMSConstants.INFO_PERMISSION_READ_ONLY_DELETE);
				informationDao.updatePermission(readPermission);
			}
		}
		// ORGANISATION PERMISSION.
		InformationPermission orgPermission = this.getInformationPermission(
				infoId, ECMSConstants.ORGANISATIONAL_PERMISSION);

		InformationPermission teamPermission = this.getTeamPermission(infoId);

		if (null != orgPermission) {

			orgPermission
					.setPermissionType(ECMSConstants.ORGANISATIONAL_PERMISSION_DELETE);
			informationDao.updatePermission(orgPermission);
		} else {
			// If information is created by LCFS and is transferred back to
			// same team give access to same LCFS.
			OrganisationTeamCode teamOrgCode = null;
			InformationPermission deletedOrgPerms = this
					.getInformationPermission(infoId,
							ECMSConstants.ORGANISATIONAL_PERMISSION_DELETE);

			if (null != deletedOrgPerms
					&& null != deletedOrgPerms.getPermissionValue()) {

				teamOrgCode = caseDao.loadTeamCodeByOrgCode(deletedOrgPerms
						.getPermissionValue());
			}
			if (null != teamOrgCode && null != teamOrgCode.getTeamCode()
					&& teamOrgCode.getTeamCode().equalsIgnoreCase(newTeam)) {

				deletedOrgPerms
						.setPermissionType(ECMSConstants.ORGANISATIONAL_PERMISSION);

				informationDao.updatePermission(deletedOrgPerms);
			}
		}
		// TEAM PERMISSION.
		if (null != teamPermission) {

			teamPermission
					.setPermissionType(ECMSConstants.TEAM_PERMISSION_DELETE);
			informationDao.updatePermission(teamPermission);
		}
	}

	private InformationPermission getInformationPermission(Long infoId,
			String permission) {

		return informationDao.loadPermissionByInfoIdAndPermType(infoId,
				permission);
	}

	private List<InformationPermission> getInfoPermissionList(Long infoId,
			String permission) {

		return informationDao.loadPermissionsByInfoIdAndPermType(infoId,
				permission);
	}

	public InformationPermission updateInfoPermissionToLCFS(String staffId,
			CaseTO caseInfo, SessionUser user) {

		InformationPermission assigneePermissions = informationDao
				.loadPermissionByInfoIdAndPermTypeAndValue(
						caseInfo.getInformationId(),
						ECMSConstants.INFO_ASSIGNEE_PERMISSION, staffId);

		if (null != assigneePermissions) {
			return assigneePermissions;
		} else {
			InformationPermission newPermissions = null;

			// create new info assignee permission.
			InformationPermission newAssigneePermissions = InformationUtil
					.createInfoPermission(caseInfo.getInformationId(),
							ECMSConstants.INFO_ASSIGNEE_PERMISSION, staffId,
							user.getStaffId());

			newPermissions = informationDao
					.saveInformationPermission(newAssigneePermissions);

			InformationPermission orgPermission = informationDao
					.loadPermissionByInfoIdAndPermTypeAndValue(
							caseInfo.getInformationId(),
							ECMSConstants.ORGANISATIONAL_PERMISSION,
							caseInfo.getOrgCode());

			if (null != orgPermission) {
				return newPermissions;
			} else {
				InformationPermission newOrgPermissions = null;

				InformationPermission orgCodeInfoPerm = InformationUtil
						.createInfoOrgPermissionForLcfs(
								caseInfo.getInformationId(),
								ECMSConstants.ORGANISATIONAL_PERMISSION,
								caseInfo.getOrgCode(), user.getStaffId());

				newOrgPermissions = informationDao
						.saveInformationPermission(orgCodeInfoPerm);
				return newOrgPermissions;
			}

		}
	}

	public Case saveOrUpdate(CaseTO caseTO) throws ServiceException {

		return this.saveOrUpdate(caseTO, "");
	}

	private boolean isDescriptionNewInCaseUpdate(String desc, Long caseId) {

		List<CaseUpdate> list = caseDao.loadCaseUpdatesByCaseId(caseId);

		if (null != desc
				&& (null == list || (null != list && list.isEmpty()) || (null != list
						&& !list.isEmpty() && (!list.get(list.size() - 1)
						.getDescription().equals(desc))))) {

			return true;
		}

		return false;
	}

	public CaseTO saveUserAllocatedHoldCase(CaseTO caseTo, String sessionUserId)
			throws ServiceException {

		Case caseDO = new Case();
		caseDO = caseDao.loadCase(caseTo.getCaseId());
		caseDO.setCreatedStaffId(caseTo.getAllocatedUser());
		// caseDo.setCreatedTime(new Date());
		caseDO.setState(ECMSConstants.CASE_OPEN);
		// Get assigned user details and apply restrictions.
		SessionUser allocatedUser = getAssignedUserDetails(caseTo
				.getAllocatedUser());
		caseDO.setCreatedStaffId(allocatedUser.getStaffId());
		caseDO.setIsSummaryAdded("N");

		// LCFS do not have directorate's, just set restrict to CFS_LOC
		if (allocatedUser.isUserLCFS()) {
			caseDO.setRestrictTo(ECMSConstants.LOCAL);
		} else {
			caseDO.setRestrictTo(getRestrictTo(allocatedUser.getDirectorates()));
		}

		// OrganisationTeamCode regCode =
		// caseDao.loadTeamCodeByOrgCode(caseDo.getOrgCode());
		// caseDo.setTeamCode(regCode.getTeamCode());

		caseDO.setIsOverLoadedCase("N");
		// Insert the case
		caseDO = caseDao.saveOrUpdate(caseDO);
		// Get current permissions.
		List<CasePermission> casePermissons = casePermissionDao
				.loadCasePermissionsByCaseId(caseDO.getCaseId());
		// Insert permissions.
		updateOldPermissions(casePermissons);
		casePermissionDao.saveCasePermissions(casePermissons);

		List<CasePermission> casePermslist = getPermissionListByUserGroup(
				caseDO, sessionUserId, allocatedUser.getGroupPermission(),
				caseDO.getTeamCode());

		// insert new the permissions.
		casePermissionDao.saveCasePermissions(casePermslist);

		caseTo.setCaseId(caseDO.getCaseId());

		return caseTo;

	}

	public List<CaseObject> loadClosedCases(boolean regionalCode,
			boolean orgCode, List<UserDirectorate> directorates,
			String[] responsibilites) {
		return caseDao.loadClosedCases(regionalCode, orgCode, directorates,
				responsibilites);
	}

	private List<CasePermission> getPermissionListByUserGroup(Case caseDO,
			String allocatedStaffId, String userGroupPermId, String teamCode) {

		List<CasePermission> permissionList = new ArrayList<CasePermission>();

		Long caseId = caseDO.getCaseId();
		Long usrPermId = new Long(userGroupPermId);

		String actionedBy = caseDO.getCreatedStaffId();

		if (caseDO.getState().equals(ECMSConstants.CASE_REOPENED)) {
			actionedBy = caseDO.getReopenedStaffId();
		}
		// Assignee permission... LCFS/CFS/OFM/AFL/AAFS/AAFSS
		CasePermission caseAssigneePerm = new CasePermission();
		setCasePermission(caseAssigneePerm, usrPermId,
				ECMSConstants.ASSIGNEE_PERMISSION, allocatedStaffId, caseId,
				actionedBy);
		permissionList.add(caseAssigneePerm);

		// Organisation permission. TODO: CHECK ORG_CODE for NIS CASES ?
		CasePermission orgTypePerm = new CasePermission();
		setCasePermission(orgTypePerm, usrPermId,
				ECMSConstants.ORGANISATIONAL_PERMISSION, caseDO.getOrgCode(),
				caseId, actionedBy);
		permissionList.add(orgTypePerm);

		// Region code permission.
		CasePermission regCodePerm = new CasePermission();
		setCasePermission(regCodePerm, usrPermId,
				ECMSConstants.TEAM_PERMISSION, teamCode, caseId, actionedBy);
		// OrganisationTeamCode regCode =
		// caseDao.loadTeamCodeByOrgCode(caseDo.getOrgCode());
		permissionList.add(regCodePerm);

		return permissionList;
	}

	private List<CasePermission> getOnHoldPermissionList(Case caseDo,
			String sessionUserId) {

		List<CasePermission> permissionList = new ArrayList<CasePermission>();

		CasePermission regCodePerm = new CasePermission();
		// permission.
		setCasePermission(regCodePerm, new Long(ECMSConstants.OFM_LEVEL),
				ECMSConstants.TEAM_PERMISSION, caseDo.getTeamCode(),
				caseDo.getCaseId(), sessionUserId);
		permissionList.add(regCodePerm);

		return permissionList;

	}

	public SessionUser getAssignedUserDetails(String assignedUserId)
			throws ServiceException {

		UserObject assignedUserObject = userDetailsDao.loadUser(assignedUserId);
		SessionUser sessionUser = createSessionUser(assignedUserObject);

		List userResponsibilitiesList = userResponsibilitiesViewDao
				.loadResponsibilitiesById(assignedUserId);
		sessionUser.setUserResponsibilities(userResponsibilitiesList);
		List<UserDirectorate> directorates = userResponsibilitiesViewDao
				.getDirectorates(sessionUser.getStaffId());
		sessionUser.setDirectorates(directorates);
		return sessionUser;
	}

	public List loadUsersByGroups(String[] userGroup) {

		return userDetailsDao.loadUsersByGroups(userGroup);
	}

	/**
	 * Load LCFS AND CFS users by team code and their group levels.
	 * 
	 * @param team
	 *            codes.
	 * @return Map<LORT_CFS, List<UserObject>>
	 */
	public Map<String, List<UserObject>> loadUsersByTeamCodeAndGroups(
			String teamCode) {
		Map<String, List<UserObject>> userMapByTeamCode = new HashMap<String, List<UserObject>>();
		// LCFS
		String[] groupLevel = new String[] { ECMSConstants.LCFS_LEVEL };
		// Part of New Structure changes new Team Codes are applied.
		// List<UserObject> list = userDetailsDao.loadUsersByTeamCode(teamCode,
		// groupLevel);
		List<UserObject> list = userDetailsDao.loadUsersByNewTeamCode(teamCode,
				groupLevel);
		userMapByTeamCode.put("LCFS", list);
		// CFS
		// CFS modified by venkat 27/10/09-listing cfs users query differs.
		// groupLevel = new String[] { ECMSConstants.CFS_LEVEL };
		String[] teamCodes = new String[] { teamCode };
		// Part of New Structure changes new Team Codes are applied.
		// list = userDetailsDao.loadCFSUsersByTeamCodes(teamCodes);
		list = userDetailsDao.loadCFSUsersByNewTeamCodes(teamCodes);
		userMapByTeamCode.put("CFS", list);
		return userMapByTeamCode;
	}

	public OrganisationTeamCode loadTeamCodeByOrgCode(String org_code) {
		return caseDao.loadTeamCodeByOrgCode(org_code);

	}

	public List listTeamCodes() {
		return regionCodeDao.loadAllTeamCodes();
	}

	public List<TeamCodes> listTeamsByTeamCode(String[] teams) {
		return regionCodeDao.listTeamsByTeamCode(teams);

	}

	private CasePermission setCasePermission(CasePermission casePermission,
			Long userGroup, String permType, String permValue, Long caseId,
			String sesssionUserId) {
		casePermission.setCaseId(caseId);
		casePermission.setPermissionType(permType);
		casePermission.setValue(permValue);
		casePermission.setCreatedTime(new Date());
		casePermission.setStatus("Y");
		casePermission.setCreatedStaffId(sesssionUserId);
		return casePermission;

	}

	private void updateOldPermissions(List<CasePermission> casePermList) {

		for (CasePermission casePermission : casePermList) {
			// TODO: Check this status later.
			// casePermission.setStatus("N");

			String permType = casePermission.getPermissionType();

			if (!ECMSConstants.TEAM_PERMISSION.equals(permType)
					&& checkCasePermissions(permType)) {

				casePermission.setPermissionType(casePermission
						.getPermissionType() + ECMSConstants.DELETE_SUFFIX);
			}
		}
	}

	private boolean checkCasePermissions(String permissionType) {

		if (StringUtils.isEmpty(permissionType)) {
			return false;
		}
		if (permissionType.equals(ECMSConstants.ASSIGNEE_PERMISSION)
				|| permissionType
						.equals(ECMSConstants.CASE_ASSIGNEE_PERMISSION)
				|| permissionType.equals(ECMSConstants.TEAM_PERMISSION)
				|| permissionType
						.equals(ECMSConstants.ORGANISATIONAL_PERMISSION)
				|| permissionType
						.equals(ECMSConstants.SENIOR_INVESTIGATING_OFFICER_PERMISSION)
				|| permissionType
						.equals(ECMSConstants.DISCLOSURE_OFFICER_PERMISSION)
				|| permissionType
						.equals(ECMSConstants.FINANCIAL_INVESTIGATOR_PERMISSION)
				|| permissionType
						.equals(ECMSConstants.FORENSIC_COMPUTING_SPECIALIST_PERMISSION)) {

			return true;
		}
		return false;
	}

	public String getRestrictTo(List<UserDirectorate> directories) {

		String restrictTo = null;
		boolean reg = false;

		for (UserDirectorate dir : directories) {

			if ("NAT".equalsIgnoreCase(dir.getDirectorateLevel())) {

				return ECMSConstants.NATIONAL;

			} else if ("REG".equalsIgnoreCase(dir.getDirectorateLevel())) {

				restrictTo = ECMSConstants.REGIONAL;
				reg = true;

			} else if ("LOC".equalsIgnoreCase(dir.getDirectorateLevel())) {

				restrictTo = ECMSConstants.LOCAL;
			}
		}
		if (reg) {

			return ECMSConstants.REGIONAL;

		} else {

			return restrictTo;
		}
	}

	public CaseTO loadCaseByCaseNumber(String caseNum) throws ServiceException {

		Case hibernate = caseDao.loadCaseByCaseNumber(caseNum);

		return createCaseTO(hibernate);
	}

	private Case createCaseDO(CaseTO caseTO) throws ServiceException {
		Case hibernate = new Case();
		try {
			BeanUtils.copyProperties(hibernate, caseTO);
		} catch (IllegalAccessException e) {
			throw new ServiceException(e);
		} catch (InvocationTargetException e) {
			throw new ServiceException(e);
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		return hibernate;
	}

	private CaseTO createCaseTO(Case hibernate) throws ServiceException {

		CaseTO caseTO = new CaseTO();
		try {
			BeanUtils.copyProperties(caseTO, hibernate);
		} catch (IllegalAccessException iae) {
			throw new ServiceException(iae);
		} catch (IllegalArgumentException iae) {
			throw new ServiceException(iae);
		} catch (InvocationTargetException ite) {
			throw new ServiceException(ite);
		}
		return caseTO;
	}

	private SessionUser createSessionUser(UserObject assignedUserObject)
			throws ServiceException {

		SessionUser sessionUser = new SessionUser();
		try {
			BeanUtils.copyProperties(sessionUser, assignedUserObject);
		} catch (IllegalAccessException e) {
			throw new ServiceException(e);
		} catch (InvocationTargetException e) {
			throw new ServiceException(e);
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		return sessionUser;
	}

	public CaseClosureTO saveCaseClosure(CaseClosureTO caseClosureTO)
			throws ServiceException {

		CaseClosure closure = CaseUtil.convertToCaseClosure(caseClosureTO);
		if (null == closure.getClosureReport()
				|| closure.getClosureReport().length < 1) {
			CaseClosure oldRep = caseDao.loadCaseClosure(closure.getCaseId());

			if (oldRep != null && oldRep.getClosureReport() != null) {
				byte[] rep = oldRep.getClosureReport();
				String fileName = oldRep.getClosureReportFileName();
				String filetype = oldRep.getClosureReportFileType();
				CaseUtil.convertToCaseClosure(caseClosureTO, oldRep);
				oldRep.setClosureReportFileName(fileName);
				oldRep.setClosureReportFileType(filetype);
				oldRep.setClosureReport(rep);
				caseDao.saveCaseClosure(oldRep);
			} else
				caseDao.saveCaseClosure(closure);

		} else {
			caseDao.saveCaseClosure(closure);
		}

		Case caseObj = caseDao.loadCase(caseClosureTO.getCaseId());
		caseObj.setState(ECMSConstants.CASE_PENDING);
		caseObj.setPendingTime(new Date());
		caseDao.saveOrUpdate(caseObj);
		caseClosureTO.setCaseClosureId(closure.getCaseClosureId());
		return caseClosureTO;
	}

	public CaseClosureTO saveCaseClosureOnly(CaseClosureTO caseClosureTO)
			throws ServiceException {

		CaseClosure closure = CaseUtil.convertToCaseClosure(caseClosureTO);

		if (null == closure.getClosureReport()
				|| closure.getClosureReport().length < 1) {

			CaseClosure oldRep = caseDao.loadCaseClosure(closure.getCaseId());

			if (oldRep != null && oldRep.getClosureReport() != null) {
				byte[] rep = oldRep.getClosureReport();
				String fileName = oldRep.getClosureReportFileName();
				String filetype = oldRep.getClosureReportFileType();
				CaseUtil.convertToCaseClosure(caseClosureTO, oldRep);
				oldRep.setClosureReportFileName(fileName);
				oldRep.setClosureReportFileType(filetype);
				oldRep.setClosureReport(rep);

				caseDao.saveCaseClosure(oldRep);
			} else
				caseDao.saveCaseClosure(closure);

		} else {
			caseDao.saveCaseClosure(closure);
		}
		caseClosureTO.setCaseClosureId(closure.getCaseClosureId());

		return caseClosureTO;

	}

	public CaseClosureTO loadCaseClosureByCaseId(Long caseId)
			throws ServiceException {

		CaseClosure closure = caseDao.loadCaseClosure(caseId);

		if (null != closure) {
			return CaseUtil.convertToCaseClosureTO(closure);
		} else {
			CaseClosureTO closureTO = new CaseClosureTO();
			closureTO.setCaseId(caseId);
			return closureTO;
		}
	}

	public CaseClosureTO loadCaseClosureByCaseIdForCPS(final Long caseId)
			throws ServiceException {
		CaseClosure closure = caseDao.loadCaseClosureForCPS(caseId);

		if (null != closure) {
			return CaseUtil.convertToCaseClosureTO(closure);
		} else {
			CaseClosureTO closureTO = new CaseClosureTO();
			closureTO.setCaseId(caseId);
			return closureTO;
		}
	}

	public CaseClosureTO downloadCaseClosureByCaseId(Long caseId)
			throws ServiceException {

		CaseClosure closure = caseDao.downloadCaseClosure(caseId);

		if (null != closure) {
			return CaseUtil.convertToCaseClosureTO(closure);
		} else {
			CaseClosureTO closureTO = new CaseClosureTO();
			closureTO.setCaseId(caseId);
			return closureTO;
		}
	}

	public CaseClosureTO updateCaseClosure(CaseClosureTO caseClosureTO)
			throws ServiceException {

		CaseClosure closure = CaseUtil.convertToCaseClosure(caseClosureTO);
		caseDao.updateCaseClosure(closure);

		return CaseUtil.convertToCaseClosureTO(closure);
	}

	public Case saveCloseCase(Long caseId) throws ServiceException {

		Case caseObj = caseDao.loadCase(caseId);
		caseObj.setState(ECMSConstants.CASE_CLOSED);
		caseObj.setClosedTime(new Date());
		caseDao.saveCase(caseObj);
		return caseObj;
	}

	public List<LookupView> loadCaseClosureTypes() throws ServiceException {

		return lookupViewDao
				.loadActiveLookupDetailsByGroups(ECMSConstants.LOOKUP_CASE_CLOSURE_TYPE);
	}

	public FpuReport loadFpuReportByCaseId(Long caseId) throws ServiceException {

		return fpuReportDao.loadFpuReportByCaseId(caseId);
	}

	/**
	 * Load Case Contacts.
	 * 
	 * @param caseId
	 * @return List<CaseContact> .
	 */
	public List<CaseContact> loadContactsByCaseId(Long caseId) {

		return caseDao.loadContactsByCaseId(caseId);
	}

	/**
	 * Load Case Investigations.
	 * 
	 * @param caseId
	 * @return List<InvestigationPlan>
	 */
	public List<InvestigationPlan> loadInvestigationsByCaseId(Long caseId) {

		return caseDao.loadInvestigationsByCaseId(caseId);
	}

	public List<InvestigationPlan> loadFullInvestigationsByCaseId(Long caseId) {

		return caseDao.loadFullInvestigationsByCaseId(caseId);
	}

	/**
	 * Setter method for the Case DAO
	 * 
	 * @param caseDao
	 */
	public void setCaseDao(CaseDao caseDao) {
		this.caseDao = caseDao;
	}

	public void setInformationDao(InformationDao informationDao) {
		this.informationDao = informationDao;
	}

	public void setRegionCodeDao(RegionCodeDao regionCodeDao) {
		this.regionCodeDao = regionCodeDao;
	}

	public void setUserDetailsDao(UserDetailsDao userDetailsDao) {
		this.userDetailsDao = userDetailsDao;
	}

	public void setUserResponsibilitiesViewDao(
			UserResponsibilitiesViewDao userResponsibilitiesViewDao) {
		this.userResponsibilitiesViewDao = userResponsibilitiesViewDao;
	}

	public void setCasePermissionDao(CasePermissionDao casePermissionDao) {
		this.casePermissionDao = casePermissionDao;
	}

	public void setLookupViewDao(LookupViewDao lookupViewDao) {
		this.lookupViewDao = lookupViewDao;
	}

	public void setFpuReportDao(FpuReportDao fpuReportDao) {
		this.fpuReportDao = fpuReportDao;
	}

	public void setMessageDao(MessageDao messageDao) {
		this.messageDao = messageDao;
	}

	/**
	 * Filter search form.
	 * 
	 */
	public CaseSearchFormTO getCaseSearchResults(CaseSearchFormTO searchTO,
			SessionUser user) throws ServiceException {

		return caseDao.getCaseSearchResults(searchTO, user);
	}

	/**
	 * Generic Case search Results.
	 * 
	 */
	public CaseSearchFormTO getGenericCaseSearchResults(
			CaseSearchFormTO searchTO, SessionUser user)
			throws ServiceException {

		return caseDao.getGenericCaseSearchResults(searchTO, user);
	}

	public CaseTO saveCase(CaseTO caseTO, SessionUser actionedBy,
			String teamCode, String allocatedStaffId) throws ServiceException {

		Case caseDo = createCaseDO(caseTO);
		caseDo.setCreatedStaffId(actionedBy.getStaffId());
		caseDo.setCreatedTime(new Date());
		caseDo.setState("OPEN");// case is in open state initially

		// get the assigned user details and set restrict to.
		SessionUser allocatedUser = getAssignedUserDetails(allocatedStaffId);
		caseDo.setCreatedStaffId(allocatedUser.getStaffId());
		// set restrictions.
		this.updateCaseRestrictions(allocatedUser, caseDo);

		caseDo.setTeamCode(teamCode);
		caseDo.setIsSummaryAdded("N");
		caseDo.setIsOverLoadedCase("N");
		// Insert the case
		caseDo = caseDao.saveCase(caseDo);

		List<CasePermission> casePermissionlist = getPermissionListByUserGroup(
				caseDo, allocatedStaffId, allocatedUser.getGroupPermission(),
				teamCode);

		// insert all the permissions.
		casePermissionDao.saveCasePermissions(casePermissionlist);

		// update case id in information object.
		Information info = informationDao.loadInformationByIdData(caseDo
				.getInformationId());
		info.setCaseId(caseDo.getCaseId());
		informationDao.updateInformationData(info);

		caseTO.setCaseId(caseDo.getCaseId());
		TempConfCase conf = new TempConfCase();
		conf.setCaseId(caseDo.getCaseId());

		caseDao.saveTempConfCase(conf);
		return caseTO;
	}

	public Information rejectInformation(CaseTO caseTo, SessionUser user) {

		Information info = informationDao.loadInformationByIdData(caseTo
				.getInformationId());

		info.setInformationDiscarded(ECMSConstants.INFO_DISCARD_REJECT);
		info.setState(ECMSConstants.INFO_STATE_CLOSED);
		info.setRejectedComment(caseTo.getRejectedComment());
		info.setClosedDate(new Timestamp(System.currentTimeMillis()));
		info.setClosedStaffId(user.getStaffId());
		informationDao.updateInformationData(info);
		return info;
	}

	public CaseSummaryInformation loadCaseSummaryInformation(Long caseId)
			throws ServiceException {
		return caseDao.loadCaseSummaryInformation(caseId);
	}

	public void updateCaseSummaryInformation(CaseSummaryInformation summary)
			throws ServiceException {
		caseDao.updateCaseSummaryInformation(summary);
	}

	public InfoTransferHistory updateOldAndAddNewInfoTransferHistory(
			Long infoId, String newTeamCode, SessionUser user)
			throws ServiceException {

		if (newTeamCode.equals(user.getEmployerOrgCode())) {

			throw new ServiceException(
					"ERROR: Its ridiculous to transfer information to the same team !!!");
		}

		return informationDao.updateOldAndAddNewInfoTransferHistory(infoId,
				newTeamCode, user);

	}

	/**
	 * This method will be responsible for storing the information transfer
	 * data.
	 * */
	public InfoTransferHistory updateInformationTransferHistory(Long infoId,
			String oldTeamCode, String newTeamCode, String staffId,
			MessageTO messageTo) throws ServiceException {
		return informationDao.updateInfoTransferHistory(infoId, oldTeamCode,
				newTeamCode, staffId, messageTo);
	}

	public boolean checkAccessToCase(Long caseId, SessionUser user) {
		return caseDao.isUserAuthorizedToAccessCase(caseId, user);
	}

	public UserObject getOwnerDetailsBycaseId(Long caseId) {
		return caseDao.getOFMDetailsByCaseId(caseId);
	}

	public void saveInfoOnly(InformationObject dto) {

		informationDao.saveInfoOnly(dto);
	}

	public InformationObject loadInfoObjectOnly(Long infoId) {

		return informationDao.loadInfoObjectOnly(infoId);
	}

	public void saveChangeCasePCT(String userId, String newPCT,
			boolean removeOldLCFS, String newLCFSAssignee, Long caseId)
			throws ServiceException {

		Case caseObj = caseDao.loadCase(caseId);
		InformationObject info = informationDao.loadInfoObjectOnly(caseObj
				.getInformationId());
		String oldPCT = caseObj.getOrgCode();

		List<CasePermission> permissions = casePermissionDao
				.loadCasePermissionsByCaseId(caseId);

		if (StringUtils.isNotEmpty(oldPCT) && StringUtils.isNotEmpty(newPCT)
				&& !oldPCT.equalsIgnoreCase(newPCT)) {

			caseObj.setOrgCode(newPCT);
			setNewPCTPermission(userId, permissions, newPCT, caseId,
					caseObj.getAccessFlag());
			info.setOrgCode(newPCT);
		}
		if (removeOldLCFS) {

			removeOldLCFSPermission(permissions);
		}
		if (newLCFSAssignee != null) {

			addNewAssigneePermission(permissions, caseId, userId,
					newLCFSAssignee, caseObj.getAccessFlag());
		}
		casePermissionDao.saveCasePermissions(permissions);
		caseDao.saveCase(caseObj);
		informationDao.saveInfoOnly(info);

	}

	/**
	 * Update ORG_CODE Permissions by deleting the old PCT and creating a new
	 * one.
	 * 
	 * @param userId
	 * @param permissions
	 * @param newPCT
	 * @param caseId
	 * @param accessFlag
	 */
	private void setNewPCTPermission(String userId,
			List<CasePermission> permissions, String newPCT, Long caseId,
			String accessFlag) {

		for (CasePermission perm : permissions) {

			String permType = perm.getPermissionType();

			if (null != permType
					&& permType
							.equalsIgnoreCase(ECMSConstants.ORGANISATIONAL_PERMISSION)) {

				perm.setPermissionType(ECMSConstants.ORGANISATIONAL_PERMISSION_DELETE);
			}
		}

		CasePermission orgCodePerm = new CasePermission();
		orgCodePerm.setCaseId(caseId);
		orgCodePerm.setPermissionType(ECMSConstants.ORGANISATIONAL_PERMISSION);
		orgCodePerm.setValue(newPCT);
		orgCodePerm.setCreatedStaffId(userId);
		orgCodePerm.setCreatedTime(new Date());
		orgCodePerm.setStatus("Y");
		orgCodePerm.setAccessFlag(accessFlag);

		permissions.add(orgCodePerm);
	}

	private void addNewAssigneePermission(List<CasePermission> permissions,
			Long caseId, String userId, String assigneeId, String flag) {

		CasePermission newPerm = new CasePermission();
		newPerm.setCaseId(caseId);
		newPerm.setPermissionType(ECMSConstants.CASE_ASSIGNEE_PERMISSION);
		newPerm.setValue(assigneeId);
		newPerm.setAccessFlag(flag);
		newPerm.setCreatedStaffId(userId);
		newPerm.setCreatedTime(new Date());

		permissions.add(newPerm);
	}

	private void removeOldLCFSPermission(List<CasePermission> permissions) {

		for (CasePermission perm : permissions) {

			String permType = perm.getPermissionType();

			if (null != permType
					&& (CaseUtil.isPermTypeInCasePermissions(permType))
					&& null != perm.getValue()
					&& perm.getValue().indexOf("lcfs") != -1) {

				// Set DELETE Case Permission Type.
				perm.setPermissionType(CaseUtil.getDeleteCasePermType(permType));
			}
		}
	}

	public void saveRejectTransferInfo(SessionUser user,
			InformationObject info, String messageStr) throws ServiceException {
		// save information with RejectTransfer state
		saveInfoOnly(info);
		// Transfer information to CIU
		updateInfoTransferToNewTeam(ECMSConstants.TEAM_CIU,
				info.getInformationId(), user);

		final UserObject userObject = userDetailsDao
				.loadOFMByTeamCode(ECMSConstants.TEAM_CIU);

		// Send message to CIU.
		Message message = new Message();
		message.setCreatedStaffId(user.getStaffId());
		message.setCreatedTime(new Date());
		message.setFromStaffId(user.getStaffId());
		message.setInformationId(info.getInformationId());
		message.setMessageType(MessageTO.Message_types.INFO_CLOSURE.toString());

		message.setToStaffId(userObject.getStaffId());
		message.setToStaffName(userObject.getTitle() + " "
				+ userObject.getFirstName() + " " + userObject.getLastName());

		message.setFromStaffName(user.getTitle() + " " + user.getFirstName()
				+ " " + user.getLastName());
		message.setState(ECMSConstants.MESSAGE_STATE_NEW);
		message.setInformationRef(info.getCreatedStaffId() + "#"
				+ info.getInformationId());
		message.setMessage(messageStr);
		messageDao.saveMessage(message);
	}

	public List<String> loadSubjectsByCaseId(Long caseId) {

		Information caseInfo = informationDao.loadInformationByCaseId(caseId);

		return CaseUtil.getSubjectListFromInformation(caseInfo);
	}

	public Person loadSubjectsByCaseIdForCps(final Long caseId) {

		final Person person = informationDao
				.loadInformationByCaseIdForCps(caseId);

		return person;
	}

	public List<LookupView> loadNewCaseClosurePart1Types()
			throws ServiceException {

		return lookupViewDao
				.loadActiveLookupDetailsByGroups(ECMSConstants.LOOKUP_CASE_CLOSURE_PART1_TYPE);
	}

	public List<LookupView> loadNewCaseClosurePart2Types()
			throws ServiceException {

		return lookupViewDao
				.loadActiveLookupDetailsByGroups(ECMSConstants.LOOKUP_CASE_CLOSURE_PART2_TYPE);
	}

	/**
	 * Load NIT LCFS AND AFS users by their group levels.
	 * 
	 * @return Map<LORT_CFS, List<UserObject>>
	 */
	public Map<String, List<UserObject>> loadNITUsersByGroups() {

		Map<String, List<UserObject>> userMapByTeams = new HashMap<String, List<UserObject>>();

		List<String> teamList = new ArrayList<String>();

		for (NIT_TEAMS team : ECMSConstants.NIT_TEAMS.values()) {
			teamList.add(team.toString());
		}
		String[] nITTems = teamList.toArray(new String[teamList.size()]);
		// LCFS
		userMapByTeams.put("LCFS",
				userDetailsDao.loadLcfsStaffByNewTeamCodes(nITTems));
		// CFS / AFS
		userMapByTeams.put("CFS",
				userDetailsDao.loadCFSUsersByNewTeamCodes(nITTems));

		return userMapByTeams;
	}

	public List<CaseObject> loadNITNCases(List<UserDirectorate> directorates) {

		return caseDao
				.loadNITCasesByTeam(directorates, ECMSConstants.NIT_NORTH);

	}

	public List<CaseObject> loadNITSCases(List<UserDirectorate> directorates) {

		return caseDao
				.loadNITCasesByTeam(directorates, ECMSConstants.NIT_SOUTH);
	}

	public List<CaseObject> loadAwaitCases(List<UserDirectorate> directorate,
			String[] responsibilites) {

		return caseDao.loadAwaitCases(directorate, responsibilites);
	}

	@Override
	public CaseTO reopenClosedCase(CaseTO caseTO, SessionUser actionedBy,
			String teamCode, String allocatedStaffId, Boolean isClosedCase)
			throws ServiceException {

		Case caseObj = createCaseDO(caseTO);

		if (isClosedCase) {

			caseObj.setState(ECMSConstants.CASE_REOPENED);
			caseObj.setReopenedStaffId(actionedBy.getStaffId());
			caseObj.setReopenedTime(new Date());
		} else if (null != caseObj.getState()
				&& !ECMSConstants.CASE_OPEN.equals(caseObj.getState())) {

			caseObj.setState(ECMSConstants.CASE_OPEN);

			if (null == caseObj.getCreatedStaffId()) {

				caseObj.setCreatedStaffId(actionedBy.getStaffId());
				caseObj.setCreatedTime(new Date());
			}
		}

		// Get current permissions.
		List<CasePermission> casePermissons = casePermissionDao
				.loadCasePermissionsByCaseId(caseObj.getCaseId());
		// Insert permissions.
		updateOldPermissions(casePermissons);
		casePermissionDao.saveCasePermissions(casePermissons);

		SessionUser allocatedUser = getAssignedUserDetails(allocatedStaffId);
		// set restrictions
		updateCaseRestrictions(allocatedUser, caseObj);

		OrganisationTeamCode orgTeam = caseDao
				.loadTeamCodeByOrgCode(null == teamCode ? caseObj.getOrgCode()
						: teamCode);

		if (null != orgTeam && null != orgTeam.getTeamCode()) {

			caseObj.setTeamCode(orgTeam.getTeamCode());
			caseObj.setIsOverLoadedCase("N");
			// Insert the case and then insert permissions.
			caseObj = caseDao.saveOrUpdate(caseObj);

			List<CasePermission> casePermissionList = getPermissionListByUserGroup(
					caseObj, allocatedStaffId,
					allocatedUser.getGroupPermission(), orgTeam.getTeamCode());

			// Insert all the permissions.
			casePermissionDao.saveCasePermissions(casePermissionList);
		}

		return caseTO;
	}

	private void updateCaseRestrictions(SessionUser user, Case caseDo) {

		if (user.isUserLCFS() || user.isUserLocal()) {

			caseDo.setRestrictTo(ECMSConstants.LOCAL);

		} else if (user.isUserRegional()) {

			if (user.isUserAntiFraudSpecialist()) {

				caseDo.setRestrictTo(ECMSConstants.LOCAL);

			} else {
				caseDo.setRestrictTo(ECMSConstants.REGIONAL);
			}
		} else if (user.isUserDirectorate()) {

			caseDo.setRestrictTo(ECMSConstants.NATIONAL);

		} else {
			caseDo.setRestrictTo(ECMSConstants.REGIONAL);
		}
	}

	@Override
	public List<CaseUpdate> loadAllCaseUpdates(Long caseId)
			throws ServiceException {

		return caseDao.loadCaseUpdatesByCaseId(caseId);
	}

	@Override
	public Case saveOrUpdate(CaseTO caseTO, String staffId)
			throws ServiceException {

		Case caseDO = createCaseDO(caseTO);

		if (ECMSConstants.ACCESS_FLAG_CONFIDENTIAL.equals(caseDO
				.getAccessFlag())
				&& !ECMSConstants.TEAM_WARO.equals(caseDO.getTeamCode())) {

			caseDO.setRestrictTo(ECMSConstants.NATIONAL);
		}
		if (ECMSConstants.ACCESS_FLAG_CONFIDENTIAL.equals(caseDO
				.getAccessFlag())
				&& ECMSConstants.TEAM_WARO.equals(caseDO.getTeamCode())) {

			caseDO.setRestrictTo(ECMSConstants.REGIONAL);
		} else if (ECMSConstants.ACCESS_FLAG_RESTRICTED.equals(caseDO
				.getAccessFlag())) {

			caseDO.setRestrictTo(ECMSConstants.LOCAL);
		}

		caseDO.setIsSummaryAdded("Y");

		caseDO = caseDao.saveOrUpdate(caseDO);

		String updateDesc = caseTO.getCaseUpdateDesc();

		if (isDescriptionNewInCaseUpdate(updateDesc, caseDO.getCaseId())
				&& StringUtils.isNotEmpty(staffId)) {

			caseDao.saveCaseUpdate(createCaseUpdate(updateDesc, caseDO, staffId));
		}

		TempConfCase conf = new TempConfCase();
		conf.setCaseId(caseDO.getCaseId());

		caseDao.saveTempConfCase(conf);
		// Update Case Summary,
		if (StringUtils.isNotEmpty(caseTO.getInformationSummary())) {

			CaseSummaryInformation summary = new CaseSummaryInformation();
			summary.setCaseId(caseTO.getCaseId());
			summary.setInformationId(caseTO.getInformationId());
			summary.setInformation(caseTO.getInformationSummary());
			this.updateCaseSummaryInformation(summary);
		}

		return caseDO;
	}

	private CaseUpdate createCaseUpdate(String update, Case caseObj,
			String staffId) {

		CaseUpdate caseUpdate = new CaseUpdate();
		caseUpdate.setDescription(update);
		caseUpdate.setCaseId(caseObj.getCaseId());
		caseUpdate.setCreatedDate(new Date());
		caseUpdate.setCreatedStaffId(staffId);

		return caseUpdate;

	}

	public String getUserFullName(String userID) {

		UserObject user = this.userDetailsDao.loadUser(userID);

		if (null != user) {

			return user.getFirstName() + " " + user.getLastName();
		}
		return "";
	}

	// ---------------------------Information
	// Transfer-------------------------------------------------

	/**
	 * Updating the information history table and triggering the various access
	 * flags.
	 */
	public Long updateInformationTransfer(Long infoID, String approvalStatus,
			String comments) throws ServiceException {

		Long transferId = null;

		logger.info(" updateInformationTransfer :" + infoID);
		InfoTransferHistory history = informationDao
				.loadCurrentInfoTransferHistoryByInfoId(infoID);
		InformationObject infoObj = loadInfoObjectOnly(infoID);

		if (null == history) {
			String errorMsg = "Information Transfer history is NULL";
			logger.error(errorMsg);
			throw new ServiceException(errorMsg);
		}
		transferId = history.getTransId();

		// Setting the information object state as "TRANSFERRED"
		if (StringUtils.equalsIgnoreCase(approvalStatus, "approvalAccepted")) {

			infoObj.setState(ECMSConstants.INFO_TRANSFERRED);
			infoObj.setInfoApprovalStatus(ECMSConstants.INFO_APPROVAL_STATUS_APPROVED);

			// Permissions created with new team and remove old permissions,
			// only on approval
			transferInfoPermissionsToNewTeam(infoID,
					history.getApproverStaffID());

			// If information is transferred to CIU or FPU set information state
			// as REJECTED else ACTIVE
			if (checkTransferTOCIUorFPU(history.getTransferTeamCode())) {

				infoObj.setInformationDiscarded(ECMSConstants.INFO_DISCARD_HOLD);
			} else {

				infoObj.setInformationDiscarded(ECMSConstants.INFO_DISCARD_OPEN);
			}
		} else if (StringUtils.equalsIgnoreCase(approvalStatus,
				"approvalRejected")) {

			infoObj.setInfoApprovalStatus(ECMSConstants.INFO_APPROVAL_STATUS_REJECTED);
			infoObj.setRejectedComment(comments);
		}

		// Saving information
		this.saveInfoOnly(infoObj);

		// Saving information history, Updating the transfer history, this
		// information will be used to provide
		// a consolidated view of approval requests pending and upon approval to
		// trigger require messages.
		history.setTransferDate(Calendar.getInstance().getTime());

		history.setState(ECMSConstants.INFO_TEAM_STATE_PROCESSED);
		history.setApprovalComments(comments);

		informationDao.updateInfoTransferHistory(history);

		// If transfer is from LCFS, then create Transfer History for other team
		// AAFS/AFL.
		String createdStaff = history.getCreatedStaffId();

		if (StringUtils.equalsIgnoreCase(approvalStatus, "approvalAccepted")
				&& StringUtils.isNotEmpty(createdStaff)
				&& createdStaff.indexOf("lcfs") != -1
				&& ECMSConstants.INFO_TEAM_STATE_PROCESSED.equals(history
						.getState())) {

			createTrasferHistoryForLeadApproval(history);
		}
		return transferId;
	}

	/**
	 * Create Info Transfer Team History.
	 * 
	 * @param history
	 */
	private void createTrasferHistoryForLeadApproval(InfoTransferHistory history) {

		InfoTransferHistory transfer = new InfoTransferHistory();
		transfer.setInfoId(history.getInfoId());
		transfer.setTeamCode(history.getTeamCode());
		transfer.setCreatedStaffId(history.getTransferStaffId());
		transfer.setTransferStaffId(history.getTransferStaffId());
		transfer.setCreatedTime(new Date());
		String transferTeamCode = history.getTransferTeamCode();
		transfer.setTransferTeamCode(transferTeamCode);
		UserObject user = informationDao.getOFMByTeamCode(transferTeamCode);
		transfer.setApproverStaffID(null != user ? user.getStaffId() : "");
		transfer.setState(ECMSConstants.INFO_TEAM_STATE_NEW);
		transfer.setTransferComments(history.getTransferComments());
		transfer.setApprovalComments("");

		informationDao.saveInfoTransferHistory(transfer);
	}

	/**
	 * This method is responsible for triggering the message b/w sender and
	 * receiver, to update about acceptance and rejection of information
	 * transfer.
	 * 
	 * */
	public boolean prepareInformationTransferResponses(String approvalStatus,
			Long transId) throws ServiceException {

		boolean success = true;

		try {
			if (logger.isDebugEnabled()) {

				logger.debug("APPROVAL STATUS=" + approvalStatus + ", transId="
						+ transId);
			}
			InfoTransferHistory infoTransfer = informationDao
					.loadInfoTransferHistoryById(transId);

			if (null == infoTransfer) {

				return false;
			}
			Message mes = CaseUtil.convertToMessage(createReplyMessage(
					approvalStatus, infoTransfer));

			messageDao.saveMessage(mes);

		} catch (Exception e) {
			logger.error("Error while saving message." + e.getMessage());
			success = false;
			throw new ServiceException("Exception saving message"
					+ e.getMessage());
		}

		return success;
	}

	private MessageTO createReplyMessage(String approvalStatus,
			InfoTransferHistory infoTrans) throws Exception {

		MessageTO message = new MessageTO();
		message.setMessage(infoTrans.getApprovalComments());
		message.setInformationId(infoTrans.getInfoId());
		message.setCreatedTime(new Date());
		message.setCreatedStaffId(infoTrans.getApproverStaffID());

		if (StringUtils.equalsIgnoreCase(approvalStatus, "approvalAccepted")) {

			message.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER_APPROVED
					.toString());
		} else if (StringUtils.equalsIgnoreCase(approvalStatus,
				"approvalRejected")) {

			message.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER_REJECTED
					.toString());
		}

		message.setFromStaffId(infoTrans.getApproverStaffID());
		if (logger.isDebugEnabled()) {
			logger.debug("Approver (from)StaffId:"
					+ infoTrans.getApproverStaffID());
		}
		UserObject user = userDetailsDao.loadUserByUserId(infoTrans
				.getApproverStaffID());
		message.setFromStaffName(EcmsUtils.getFullName(user));

		message.setToStaffId(infoTrans.getCreatedStaffId());
		if (logger.isDebugEnabled()) {
			logger.debug("Created (to)StaffId:" + infoTrans.getCreatedStaffId());
		}
		user = userDetailsDao.loadUserByUserId(infoTrans.getCreatedStaffId());
		message.setToStaffName(EcmsUtils.getFullName(user));

		message.setState(ECMSConstants.MESSAGE_STATE_NEW);
		message.setInformationRef(infoTrans.getCreatedStaffId() + "#"
				+ infoTrans.getInfoId());

		return message;
	}

	/**
	 * To be used to enable information transfer through messaging.
	 * 
	 * This method is responsible for triggering the message b/w sender and
	 * receiver, to update about acceptance and rejection of information
	 * transfer.
	 * 
	 * */
	public boolean prepareReplyMessages(MessageTO messageTO,
			String approvalStatus, Long infoTransId) throws ServiceException {

		boolean success = true;
		try {
			InfoTransferHistory infoTransfer = informationDao
					.loadInfoTransferHistoryById(infoTransId);

			if (null == infoTransfer) {

				return false;
			}
			if (!StringUtils.equals(messageTO.getToStaffId(),
					messageTO.getFromStaffId())) {

				MessageTO replyMessage = new MessageTO();
				replyMessage.setMessage(infoTransfer.getApprovalComments());
				replyMessage.setInformationId(infoTransfer.getInfoId());
				replyMessage.setCreatedTime(new Date());
				replyMessage.setCreatedStaffId(messageTO.getToStaffId());
				replyMessage.setFromStaffId(messageTO.getToStaffId());
				replyMessage.setFromStaffName(messageTO.getToStaffName());
				replyMessage.setToStaffId(messageTO.getFromStaffId());
				replyMessage.setToStaffName(messageTO.getFromStaffName());
				replyMessage.setState(ECMSConstants.MESSAGE_STATE_NEW);
				replyMessage.setInformationRef(infoTransfer.getCreatedStaffId()
						+ "#" + infoTransfer.getInfoId());

				if (StringUtils.equalsIgnoreCase(approvalStatus,
						"approvalAccepted")) {

					replyMessage
							.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER_APPROVED
									.toString());

				} else if (StringUtils.equalsIgnoreCase(approvalStatus,
						"approvalRejected")) {

					replyMessage
							.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER_REJECTED
									.toString());
				}

				Message mes = CaseUtil.convertToMessage(replyMessage);

				messageDao.saveMessage(mes);
			}

		} catch (Exception e) {
			logger.error("Error while saving message:" + e.getMessage());
			success = false;
			throw new ServiceException("Exception saving message"
					+ e.getMessage());
		}

		return success;
	}

	/**
	 * This method is responsible for triggering system notification to the end
	 * user.
	 * 
	 */
	public boolean triggerTransferNotification(Long infoTransferId)
			throws ServiceException {

		try {

			InfoTransferHistory infoTransfer = informationDao
					.loadInfoTransferHistoryById(infoTransferId);

			if (null == infoTransfer) {

				return false;
			}
			String teamCode = infoTransfer.getTransferTeamCode();
			UserObject userObject = userDetailsDao.loadOFMByTeamCode(teamCode);

			if (null == userObject) {

				String errorStr = "ERROR: No OFM/AFL/IMO for TeamCode="
						+ teamCode;
				logger.error(errorStr);
				throw new ServiceException(errorStr);
			}
			final UserObject user = userDetailsDao
					.loadUserByUserId(infoTransfer.getApproverStaffID());

			if (!StringUtils.equals(user.getStaffId(), userObject.getStaffId())) {

				final Message replyMsg = new Message();
				replyMsg.setMessage(infoTransfer.getApprovalComments());
				replyMsg.setInformationId(infoTransfer.getInfoId());
				replyMsg.setCreatedStaffId(user.getStaffId());
				replyMsg.setFromStaffId(user.getStaffId());
				replyMsg.setFromStaffName(EcmsUtils.getFullName(user));
				replyMsg.setCreatedTime(new Date());
				replyMsg.setState(ECMSConstants.MESSAGE_STATE_NEW);
				replyMsg.setInformationRef(infoTransfer.getCreatedStaffId()
						+ "#" + infoTransfer.getInfoId());
				replyMsg.setToStaffId(userObject.getStaffId());
				replyMsg.setToStaffName(EcmsUtils.getFullName(userObject));

				if (checkTransferTOCIUorFPU(teamCode)) {

					replyMsg.setMessageType(MessageTO.Message_types.IIU_IMO_REFERRAL
							.toString());

				} else {

					replyMsg.setMessageType(MessageTO.Message_types.INFORMATION_TRANSFER
							.toString());
				}
				messageDao.saveMessage(replyMsg);
			}

		} catch (Exception e) {
			logger.error("Error while saving message." + e.getMessage());
			throw new ServiceException(e);
		}

		return true;
	}

	/**
	 * This method is responsible for transferring the information permission of
	 * Team Code permission type set new team in the information permission then
	 * updated the information permission. Check previous versions to create
	 * READ_ONLY permissions.
	 * 
	 * @param caseTo
	 *            Case transfer object
	 * @return InformationTO.
	 * 
	 */

	public InformationPermission transferInfoPermissionsToNewTeam(Long infoId,
			String createrStaffID) throws ServiceException {

		InfoTransferHistory infoTransferHistory = informationDao
				.loadCurrentInfoTransferHistoryByInfoId(infoId);

		String newTeam = infoTransferHistory.getTransferTeamCode();

		if (StringUtils.isEmpty(newTeam)) {

			String errorMsg = "Transfer Failed ! NewTeam code is NULL or Empty";
			logger.error(errorMsg);
			throw new ServiceException(errorMsg);
		}
		// Delete Assignee, Organisation and Team permissions
		this.deleteAssigneeOrgAndTeamPermissions(infoId, newTeam);

		InformationPermission teamPerm = InformationUtil.createInfoPermission(
				infoId, ECMSConstants.TEAM_PERMISSION, newTeam, createrStaffID);

		return informationDao.updatePermission(teamPerm);
	}

	/**
	 * Create Information READ ONLY Permissions.
	 * 
	 * @param infoId
	 * @param staffId
	 * 
	 *            private void createReadOnlyPermissions(Long infoId, String
	 *            staffId) {
	 * 
	 *            InformationPermission readOnlyPerms =
	 *            InformationUtil.createInfoPermission(infoId,
	 *            ECMSConstants.INFO_PERMISSION_READ_ONLY, staffId, staffId);
	 * 
	 *            informationDao.updatePermission(readOnlyPerms); }
	 */

	private boolean checkTransferTOCIUorFPU(String transfer) {

		if (transfer != null
				&& (transfer.equalsIgnoreCase(ECMSConstants.TEAM_CIU) || transfer
						.equalsIgnoreCase(ECMSConstants.TEAM_FPU))) {
			return true;
		}
		return false;
	}

	/**
	 * This method is responsible for providing the OFM details for the given
	 * case ID using the CAST DAO layer. This service method is being used in
	 * CPS Document Service layer as well.
	 * */
	public UserObject getOFMDetailsByCaseId(Long caseId) {
		return this.caseDao.getOFMDetailsByCaseId(caseId);
	}

	public String getApproverStaffIdForCPSDocsRequest() {
		return this.caseDao.getApproverStaffIdForCPSDocsRequest();
	}
}