package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.AttachmentDao;
import uk.nhs.cfsms.ecms.data.common.Attachment;
import uk.nhs.cfsms.ecms.service.AttachmentService;

@Service(value="attachmentFacade")
@Transactional
public class AttachmentServiceImpl extends BaseServiceImpl implements
		AttachmentService {

	@Autowired
	private AttachmentDao attachmentDao;
	
	public Attachment loadAttachment(Long AttachmentId) {

		return attachmentDao.loadAttachment(AttachmentId);
	}

	public List<Attachment> listAttachments(Long caseId) {

		return attachmentDao.listAttachments(caseId);
	}
	

	public List<Attachment> listInfoAttachments(Long infoId) {

		return attachmentDao.listInfoAttachments(infoId);
	}

	public void saveAttachment(Attachment attachment) {

		attachmentDao.saveAttachment(attachment);

	}

	public void deleteAttachment(Long attachmentId) {

		Attachment attachment = (this.attachmentDao)
				.loadAttachment(attachmentId);

		if (null != attachment) {

			attachmentDao.deleteAttachment(attachment);
		}
	}

}
