package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.DisciplinarySanctionDao;
import uk.nhs.cfsms.ecms.dao.LookupViewDao;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppeal;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealOutcome;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealView;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanction;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionOffence;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionView;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealHearingTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealOutcomeTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealSanctionComparator;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealSanctionTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryCourtNameComparator;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryHearingComparator;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryHearingTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryOffenceTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryOutcomeTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinarySanctionTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.DisciplinarySanctionService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

/**
 * Disciplinary Sanction Service Implementation.
 * 
 */
@Service(value = "disciplinarySanctionFacade")
@Transactional
public class DisciplinarySanctionServiceImpl extends BaseServiceImpl implements
		DisciplinarySanctionService {

	@Autowired
	private LookupViewDao lookupViewDao;
	@Autowired
	private DisciplinarySanctionDao dispSanctionDao;

	/**
	 * Load all Disciplinary Sanctions View by caseId.
	 */
	public List<DisciplinarySanctionView> loadSanctionViewListByCaseId(
			Long caseId) throws ServiceException {
		try {
			List<DisciplinarySanctionView> list = dispSanctionDao
					.loadDisciplinarySanctions(caseId);
			return list;
		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	/**
	 * Load all Disciplinary Appeals View by caseId.
	 */
	public List<DisciplinaryAppealView> loadAppealViewListByCaseId(Long caseId)
			throws ServiceException {
		try {
			List<DisciplinaryAppealView> list = dispSanctionDao
					.loadAppealsByCaseIdOrderByAppealedDate(caseId);

			return list;
		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	public DisciplinaryAppealView loadAppealViewByAppealId(Long appealId)
			throws ServiceException {
		try {
			DisciplinaryAppealView disciplinaryAppealView = dispSanctionDao
					.loadDisciplinaryAppeal(appealId);
			return disciplinaryAppealView;
		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	public DisciplinarySanctionTO loadDisciplinarySanction(Long sanctionId)
			throws ServiceException {

		DisciplinarySanction sanction = dispSanctionDao
				.loadDisciplinarySanctionById(sanctionId);

		if (null != sanction) {

			DisciplinarySanctionTO dto = CaseUtil
					.convertToDisciplinarySanctionTO(sanction);

			return dto;
		}

		return null;
	}

	public DisciplinarySanctionTO loadDisciplinarySanctionView(Long sanctionId)
			throws ServiceException {

		DisciplinarySanctionView sanction = dispSanctionDao
				.loadDisciplinarySanctionViewById(sanctionId);

		if (null != sanction) {

			DisciplinarySanctionTO dto = CaseUtil
					.convertToDisciplinarySanctionTO(sanction);

			return dto;
		}

		return null;
	}

	public DisciplinaryAppealTO loadDisciplinaryAppeal(Long id)
			throws ServiceException {

		DisciplinaryAppeal view = dispSanctionDao
				.getDisciplinaryAppealDetails(id);

		if (view != null) {

			Long parentAppealId = view.getParentAppealId();

			Long sanctionId = view.getSanctionId();

			DisciplinaryAppealTO dto = CaseUtil
					.convertToDisciplinaryAppealTO(view);

			// Load and update parent appeal or sanction details 
			if (null != parentAppealId && parentAppealId != 0) {

				DisciplinaryAppealTO appealTO = this
						.loadDisciplinaryAppealByParentAppealId(parentAppealId);

				dto.setParentSubjectId(appealTO.getSubjectId());
				dto.setParentSanctionType(appealTO.getSanctionType());

				DisciplinaryAppealOutcomeTO appealOutcome = this
						.loadAppealOutcomeByAppealId(parentAppealId);

				if (null != appealOutcome
						&& null != appealOutcome.getOutcomeDate()) {

					dto.setOutcomeDate(appealOutcome.getOutcomeDate());

					updateAppealTOWithAppliedSanctions(dto, appealOutcome);
				}

				dto.setParentAppealTO(appealTO);

			} else if (null != sanctionId && sanctionId > 0) {

				DisciplinarySanctionTO currentSanction = this
						.loadDisciplinarySanctionView(sanctionId);

				if (null != currentSanction) {

					if (null != currentSanction.getSubjectId()) {

						dto.setParentSubjectId(currentSanction.getSubjectId());
					}
					dto.setParentSanctionType(currentSanction.getSanctionType());
				}

				DisciplinaryOutcomeTO outcomeTO = loadDisciplinaryOutcomeBySanctionId(sanctionId);

				if (null != outcomeTO) {

					dto.setOutcomeDate(outcomeTO.getOutcomeDate());

					updateAppealTOWithAppliedSanctions(dto, outcomeTO);
				}

				dto.setParentSanctionTO(currentSanction);
			}

			return dto;
		}

		return null;

	}

	private void updateAppealTOWithAppliedSanctions(DisciplinaryAppealTO dto,
			DisciplinaryAppealOutcomeTO appealOutcome) {

		List<OutcomeAppliedSanction> appliedSanctions = appealOutcome
				.getOutcomeAppliedSanctions();

		if (!appliedSanctions.isEmpty()) {

			dto.setSelectedSanctions(sanctionsToCommaDelimitedString(appliedSanctions));
		}
	}

	private void updateAppealTOWithAppliedSanctions(DisciplinaryAppealTO dto,
			DisciplinaryOutcomeTO sanctonOutcome) {

		List<OutcomeAppliedSanction> appliedSanctions = sanctonOutcome
				.getOutcomeAppliedSanctions();

		if (!appliedSanctions.isEmpty()) {

			dto.setSelectedSanctions(sanctionsToCommaDelimitedString(appliedSanctions));
		}
	}

	private String sanctionsToCommaDelimitedString(
			List<OutcomeAppliedSanction> outcomeAppliedSanctions) {

		String str = "";

		for (OutcomeAppliedSanction appliedSanction : outcomeAppliedSanctions) {

			str = str + appliedSanction.getAppliedSanction() + ",";
		}
		if (StringUtils.isNotEmpty(str)) {

			str = str.substring(0, str.lastIndexOf(','));
		}

		return str;
	}

	/**
	 * TODO : This code here is very fishy, needs re-factoring.
	 */
	public DisciplinaryAppealTO loadDisciplinaryAppealByParentAppealId(
			Long parentId) throws ServiceException {

		DisciplinaryAppealTO parentTO = null;

		DisciplinaryAppealView appealView = dispSanctionDao
				.loadDisciplinaryAppeal(parentId);

		if (null != appealView) {

			Long appealId = appealView.getAppealId();

			parentTO = CaseUtil.convertToDisciplinaryAppealTO(appealView);

			if (null != appealId && appealId > 0) {

				DisciplinaryAppealOutcomeTO appealOutcomeTO = loadAppealOutcomeByAppealId(appealId);

				if (null != appealOutcomeTO) {

					parentTO.setOutcomeDate(appealOutcomeTO.getOutcomeDate());

					updateAppealTOWithAppliedSanctions(parentTO,
							appealOutcomeTO);
				}

			}
		}
		return parentTO;
	}

	public List<DisciplinarySanctionTO> loadDisciplinarySanctionList()
			throws ServiceException {

		List views = dispSanctionDao.getObjects(DisciplinarySanctionView.class);

		List<DisciplinarySanctionTO> tos = new ArrayList<DisciplinarySanctionTO>();
		Iterator it = views.iterator();
		while (it.hasNext()) {
			DisciplinarySanction view = (DisciplinarySanction) it.next();
			DisciplinarySanctionTO dto = CaseUtil
					.convertToDisciplinarySanctionTO(view);
			tos.add(dto);
		}

		return tos;

	}

	public List<DisciplinarySanctionTO> loadSanctionsByCaseId(Long caseId)
			throws ServiceException {

		List<DisciplinarySanctionTO> sanctionList = new ArrayList<DisciplinarySanctionTO>();

		List<DisciplinarySanctionView> views = dispSanctionDao
				.loadDisciplinarySanctions(caseId);

		for (DisciplinarySanctionView view : views) {

			DisciplinarySanctionTO dto = CaseUtil
					.convertToDisciplinarySanctionTO(view);

			long sanctionId = dto.getDisciplinarySanctionId();

			List<DisciplinaryAppeal> appList = dispSanctionDao
					.loadAppealsByParentSanctionId(sanctionId);

			dto.setAppealExist((null != appList && appList.size() > 0) ? true
					: false);

			dto.setHearings(loadDisciplinaryHearingList(sanctionId));
			dto.setOffences(loadDisciplinaryOffenceList(sanctionId));
			dto.setOutcomes(dispSanctionDao
					.loadDisciplinaryOutcomeList(sanctionId));

			sanctionList.add(dto);
		}

		return sanctionList;

	}

	public List<DisciplinaryAppealTO> loadAppealsListByCaseId(Long caseId)
			throws ServiceException {

		List<DisciplinaryAppealTO> list = new ArrayList<DisciplinaryAppealTO>();

		List<DisciplinaryAppealView> views = dispSanctionDao
				.loadAppealsByCaseIdOrderByAppealedDate(caseId);

		for (DisciplinaryAppealView view : views) {

			long appealId = view.getAppealId();

			DisciplinaryAppealTO dto = CaseUtil
					.convertToDisciplinaryAppealTO(view);

			List<DisciplinaryAppeal> dispList = dispSanctionDao
					.loadAppealsByParentAppealId(appealId);

			dto.setAppealExist(dispList != null && dispList.size() > 0 ? true
					: false);

			dto.setHearings(loadDisciplinaryAppealHearingList(appealId));

			dto.setOutcomes(dispSanctionDao.loadAppealOutcomeList(appealId));

			list.add(dto);
		}

		return list;

	}

	@Override
	public void evictObject(Object o) throws ServiceException {
		DisciplinarySanctionTO dto = (DisciplinarySanctionTO) o;
		try {
			DisciplinarySanction hibernate = CaseUtil
					.convertToDisciplinarySanction(dto);
			dispSanctionDao.evictObject(hibernate);
		} catch (ServiceException se) {
			throw se;
		}

	}

	/**
	 * Load Case Contacts.
	 * 
	 * @param caseId
	 * @return List<CaseContact> .
	 */
	public List<CaseContact> loadContactsByCaseId(Long caseId) {
		return dispSanctionDao.loadContactsByCaseId(caseId);
	}

	/**
	 * Save Disciplinary Sanction
	 * 
	 */
	public void saveDisciplinarySanction(DisciplinarySanctionTO dto)
			throws ServiceException {

		try {
			DisciplinarySanction hibernate = CaseUtil
					.convertToDisciplinarySanction(dto);
			dispSanctionDao.saveObject(hibernate);

		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	/**
	 * Save Disciplinary Appeal
	 * 
	 */
	public void saveDisciplinaryAppeal(DisciplinaryAppealTO dto)
			throws ServiceException {

		try {
			DisciplinaryAppeal hibernate = CaseUtil
					.convertToDisciplinaryAppeal(dto);
			dispSanctionDao.saveObject(hibernate);

		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	public List<DisciplinarySanctionHearing> loadDisciplinaryHearingList(Long id)
			throws ServiceException {
		return dispSanctionDao.loadDisciplinaryHearingList(id);
	}

	public List<DisciplinaryAppealHearing> loadDisciplinaryAppealHearingList(
			Long id) throws ServiceException {
		return dispSanctionDao.loadDisciplinaryAppealHearingList(id);
	}

	public List<DisciplinarySanctionOffence> loadDisciplinaryOffenceList(Long id)
			throws ServiceException {
		return dispSanctionDao.loadDisciplinaryOffenceList(id);
	}

	public List<DisciplinarySanctionOutcome> loadDisciplinaryOutcomeList(Long id)
			throws ServiceException {
		return dispSanctionDao.loadDisciplinaryOutcomeList(id);
	}

	public DisciplinaryHearingTO loadDisciplinaryHearing(Long hearingId)
			throws ServiceException {

		DisciplinarySanctionHearing hearing = dispSanctionDao
				.loadDisciplinaryHearing(hearingId);

		if (hearing != null) {
			return CaseUtil.convertToDisciplinaryHearingTO(hearing);
		}
		return null;
	}

	public DisciplinaryAppealHearingTO loadDisciplinaryAppealHearing(
			Long hearingId) throws ServiceException {

		DisciplinaryAppealHearing hearing = dispSanctionDao
				.loadDisciplinaryAppealHearing(hearingId);

		if (hearing != null) {
			return CaseUtil.convertToDisciplinaryAppealHearingTO(hearing);
		}
		return null;
	}

	public DisciplinaryOffenceTO loadDisciplinaryOffence(Long sanctionId)
			throws ServiceException {
		DisciplinarySanctionOffence offence = dispSanctionDao
				.loadDisciplinaryOffence(sanctionId);

		if (offence != null) {
			return CaseUtil.convertToDisciplinaryOffenceTO(offence);
		}
		return null;
	}

	public DisciplinaryOutcomeTO loadDisciplinaryOutcomeBySanctionId(
			Long sanctionId) throws ServiceException {

		List outcomeList = dispSanctionDao
				.loadDisciplinaryOutcomeList(sanctionId);

		if (null != outcomeList && !outcomeList.isEmpty()) {
			DisciplinarySanctionOutcome outcome = (DisciplinarySanctionOutcome) outcomeList
					.get(0);

			return CaseUtil.convertToDisciplinaryOutcomeTO(outcome);
		}

		return null;
	}

	public DisciplinaryAppealOutcomeTO loadAppealOutcomeByAppealId(Long appealId)
			throws ServiceException {

		List list = dispSanctionDao.loadAppealOutcomeList(appealId);

		if (null != list && !list.isEmpty()) {

			DisciplinaryAppealOutcome outcome = (DisciplinaryAppealOutcome) list
					.get(0);

			return CaseUtil.convertToDisciplinaryAppealOutcomeTO(outcome);
		}

		return null;
	}

	public DisciplinaryOutcomeTO loadDisciplinaryOutcome(Long outcomeId)
			throws ServiceException {
		DisciplinarySanctionOutcome outcome = dispSanctionDao
				.loadDisciplinaryOutcome(outcomeId);

		if (outcome != null) {
			return CaseUtil.convertToDisciplinaryOutcomeTO(outcome);
		}
		return null;
	}

	public void saveDisciplinaryHearing(DisciplinaryHearingTO dto)
			throws ServiceException {
		try {

			dispSanctionDao.saveObject(CaseUtil
					.convertToDisciplinarySanctionHearing(dto));

		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	public void saveDisciplinaryAppealHearing(DisciplinaryAppealHearingTO dto)
			throws ServiceException {
		try {

			dispSanctionDao.saveObject(CaseUtil
					.convertToDisciplinaryAppealHearing(dto));

		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	public void saveDisciplinaryOffence(DisciplinaryOffenceTO dto)
			throws ServiceException {
		try {
			dispSanctionDao.saveObject(CaseUtil
					.convertToDisciplinarySanctionOffence(dto));

		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	public void saveDisciplinaryOutcome(DisciplinaryOutcomeTO dto)
			throws ServiceException {

		try {
			if (dto.getOutcomeId() != null) {
				List<OutcomeAppliedSanction> sanctionList = dispSanctionDao
						.loadAppliedSanctions(dto.getOutcomeId());

				if (null != sanctionList && !sanctionList.isEmpty()) {

					dispSanctionDao.deleteAppliedSanctions(sanctionList);
				}
			}
			dispSanctionDao.saveDisciplinarySanctionOutcome(CaseUtil
					.convertToDisciplinarySanctionOutcome(dto));

			DisciplinarySanction sanction = dispSanctionDao
					.loadDisciplinarySanctionById(dto
							.getDisciplinarySanctionId());

			if (null != sanction) {
				sanction.setState(dto.getStatus());

				dispSanctionDao.saveObject(sanction);
			}

		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	public void saveDisciplinaryAppealOutcome(DisciplinaryAppealOutcomeTO dto)
			throws ServiceException {

		try {
			dispSanctionDao.saveDisciplinaryAppealOutcome(CaseUtil
					.convertToDisciplinaryAppealOutcome(dto));

			DisciplinaryAppeal appeal = dispSanctionDao
					.getDisciplinaryAppealDetails(dto.getAppealId());

			if (null != appeal) {
				appeal.setState(dto.getStatus());

				dispSanctionDao.saveObject(appeal);
			}

		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	public void deleteDisciplinarySanction(Long id) throws ServiceException {

		try {
			DisciplinarySanction sanction = dispSanctionDao
					.loadDisciplinarySanctionById(id);

			if (null != sanction
					&& null != sanction.getDisciplinarySanctionId()) {

				Long sanctionId = sanction.getDisciplinarySanctionId();

				dispSanctionDao.deleteObjects(dispSanctionDao
						.loadDisciplinaryHearingList(sanctionId));

				dispSanctionDao.deleteObjects(dispSanctionDao
						.loadDisciplinaryOffenceList(sanctionId));

				dispSanctionDao.deleteObjects(dispSanctionDao
						.loadDisciplinaryOutcomeList(sanctionId));
			}
			dispSanctionDao.deleteObject(sanction);

		} catch (Exception se) {
			throw new ServiceException(se);
		}
	}

	public void deleteDisciplinaryAppeal(Long id) throws ServiceException {

		try {
			DisciplinaryAppeal disciplinaryAppeal = dispSanctionDao
					.getDisciplinaryAppealDetails(id);

			if (disciplinaryAppeal != null
					&& disciplinaryAppeal.getAppealId() != null) {

				Long appealId = disciplinaryAppeal.getAppealId();

				List<DisciplinaryAppealHearing> deciplinAppealHearings = dispSanctionDao
						.loadDisciplinaryAppealHearingList(appealId);

				if (deciplinAppealHearings != null
						&& !deciplinAppealHearings.isEmpty()) {
					dispSanctionDao.deleteObjects(deciplinAppealHearings);
				}

				List<DisciplinaryAppealOutcome> appealOutcomes = dispSanctionDao
						.loadAppealOutcomeList(appealId);

				if (appealOutcomes != null && !appealOutcomes.isEmpty()) {
					dispSanctionDao.deleteObjects(appealOutcomes);
				}
			}
			dispSanctionDao.deleteObject(disciplinaryAppeal);

		} catch (Exception se) {
			throw new ServiceException(se);
		}
	}

	public void deleteDisciplinaryHearing(Long id) throws ServiceException {
		try {
			DisciplinarySanctionHearing hearing = dispSanctionDao
					.loadDisciplinaryHearing(id);

			dispSanctionDao.deleteObject(hearing);
		} catch (Exception se) {
			throw new ServiceException(se);
		}
	}

	public void deleteDisciplinaryAppealHearing(Long id)
			throws ServiceException {
		try {
			DisciplinaryAppealHearing hearing = dispSanctionDao
					.loadDisciplinaryAppealHearing(id);
			dispSanctionDao.deleteObject(hearing);
		} catch (Exception se) {
			throw new ServiceException(se);
		}
	}

	public void deleteDisciplinaryOutcome(Long id) throws ServiceException {
		try {
			DisciplinarySanctionOutcome outcome = dispSanctionDao
					.loadDisciplinaryOutcome(id);
			dispSanctionDao.deleteObject(outcome);
		} catch (Exception se) {
			throw new ServiceException(se);
		}
	}

	public List<LookupView> loadSanctionImposedTypes(final String sanctionType)
			throws ServiceException {

		List<LookupView> lookupViews = null;

		if ("EXTERNAL".equalsIgnoreCase(sanctionType)) {
			lookupViews = lookupViewDao
					.loadActiveLookupDetailsByGroupForExternal(ECMSConstants.DISCIP_SANCTION_TYPE);
		} else {
			lookupViews = lookupViewDao
					.loadActiveLookupDetailsByGroupForInternal(ECMSConstants.DISCIP_SANCTION_TYPE);
		}
		return lookupViews;

	}

	public List<DisciplinaryAppeal> loadAppealsByParentSanctionId(
			Long sanctionId) {
		return dispSanctionDao.loadAppealsByParentSanctionId(sanctionId);
	}

	@Override
	public List<DisciplinaryAppeal> loadAppealsByParentAppealId(Long appealId)
			throws ServiceException {

		return dispSanctionDao.loadAppealsByParentAppealId(appealId);
	}

	/**
	 * Setters from the old versions.
	 * 
	 * @param lookupViewDao
	 */

	public void setLookupViewDao(LookupViewDao lookupViewDao) {
		this.lookupViewDao = lookupViewDao;
	}

	public void setDispSanctionDao(DisciplinarySanctionDao dispSanctionDao) {
		this.dispSanctionDao = dispSanctionDao;
	}

	@Override
	public List<DisciplinaryAppealSanctionTO> getAppealAndSanctionList(
			Long caseIdL) throws ServiceException {

		List<DisciplinaryAppealSanctionTO> appealSanctionList = new ArrayList<DisciplinaryAppealSanctionTO>();

		String orgName = "";

		List<DisciplinarySanctionTO> sanctionsList = this
				.loadSanctionsByCaseId(caseIdL);

		List<DisciplinaryAppealTO> appealList = this
				.loadAppealsListByCaseId(caseIdL);

		for (DisciplinaryAppealTO appealTO : appealList) {

			Long appealId = appealTO.getAppealId();

			DisciplinaryAppealView view = this
					.loadAppealViewByAppealId(appealId);

			if (appealTO.getOutcomes() != null) {

				DisciplinaryAppealSanctionTO aAndSTO = new DisciplinaryAppealSanctionTO();

				aAndSTO.setAppealId(appealId);
				aAndSTO.setAppealedDate(appealTO.getAppealedDate());
				aAndSTO.setOrganisationName(appealTO.getOrganisationName());
				aAndSTO.setAppealExistsForTheCurrent(appealTO.isAppealExist());
				aAndSTO.setSanctionType(appealTO.getSanctionType());

				aAndSTO.setSubjectName(getSubjectNameFromView(view));

				for (DisciplinaryAppealOutcome outcome : appealTO.getOutcomes()) {

					if (null != outcome.getOutcomeAppliedSanctions()) {

						String selectedSanctions = getCamaSepeatedVales(outcome
								.getOutcomeAppliedSanctions());

						appealTO.setSelectedSanctions(selectedSanctions);
						aAndSTO.setSelectedSanctions(selectedSanctions);

						aAndSTO.setOutcomeDate(outcome.getOutcomeDate());

						aAndSTO.setOutcomeStatus(getOutcomeStatus(outcome
								.getStatus()));

					}
				}

				if (null != appealTO.getHearings()) {

					List<DisciplinaryAppealHearing> hearingList = appealTO
							.getHearings();
					Collections.sort(hearingList,
							new DisciplinaryCourtNameComparator());

					if (hearingList.size() > 0) {

						aAndSTO.setCourtName(hearingList.get(0).getOrgName());
					}
				}

				if (null != aAndSTO.getOutcomeDate()) {

					appealSanctionList.add(aAndSTO);
				}
			}

		}

		for (DisciplinarySanctionTO sancTO : sanctionsList) {

			List<DisciplinarySanctionHearing> hearingList = sancTO
					.getHearings();

			if (null != hearingList && !hearingList.isEmpty()) {

				Collections.sort(hearingList,
						new DisciplinaryHearingComparator());

				// Get the top Organisation or court Name from the hearing List. 
				orgName = hearingList.get(0).getOrgName();
			}

			if (sancTO.getOutcomes() != null) {

				DisciplinaryAppealSanctionTO aAndSTO = new DisciplinaryAppealSanctionTO();
				aAndSTO.setOrganisationName("INTERNAL".equalsIgnoreCase(sancTO
						.getSanctionType()) ? sancTO
						.getInternalOrganisationName() : sancTO
						.getOrganisationName());
				aAndSTO.setSanctionType(sancTO.getSanctionType());
				aAndSTO.setSanctionId(sancTO.getDisciplinarySanctionId());
				aAndSTO.setAppealedDate(sancTO.getStartDate());
				aAndSTO.setAppealExistsForTheCurrent(sancTO.isAppealExist());

				aAndSTO.setSubjectName(getSubjectNameFromTo(sancTO));

				aAndSTO.setCourtName(orgName);

				for (DisciplinarySanctionOutcome outcome : sancTO.getOutcomes()) {

					if (null != outcome.getOutcomeAppliedSanctions()) {

						String selectedSanctions = getCamaSepeatedVales(outcome
								.getOutcomeAppliedSanctions());

						sancTO.setSelectedSanctions(selectedSanctions);

						aAndSTO.setSelectedSanctions(selectedSanctions);
						aAndSTO.setOutcomeDate(outcome.getOutcomeDate());
						aAndSTO.setOutcomeStatus(outcome.getStatus());
					}
				}
				// && StringUtils.isNotEmpty(aAndSTO.getSelectedSanctions())
				if (null != aAndSTO.getOutcomeDate()) {

					appealSanctionList.add(aAndSTO);
				}
			}
		}

		Collections.sort(appealSanctionList,
				new DisciplinaryAppealSanctionComparator());

		return appealSanctionList;
	}

	private String getCamaSepeatedVales(List<OutcomeAppliedSanction> list) {

		String sanctionsString = "";

		for (OutcomeAppliedSanction sanctions : list) {

			sanctionsString = sanctionsString + sanctions.getAppliedSanction()
					+ ",";
		}
		if (StringUtils.isNotEmpty(sanctionsString)) {

			sanctionsString = sanctionsString.substring(0,
					sanctionsString.lastIndexOf(','));
		}

		return sanctionsString;
	}

	private String getOutcomeStatus(String outcome) {

		String status = "";
		if (outcome.equals("SUCCESSFUL")) {
			status = "DECISION NOT UPHELD";
		} else if (outcome.equals("UNSUCCESSFUL")) {
			status = "DECISION UPHELD";
		} else if (outcome.equals("WITHDRAWN")) {
			status = "WITHDRAWN";
		}
		return status;
	}

	private String getSubjectNameFromView(DisciplinaryAppealView view) {

		String subjectName = "";

		if (view.getNhsSubjectName() != null) {
			subjectName = view.getNhsSubjectName();
		} else if (view.getNonNhsSubjectName() != null) {
			subjectName = view.getNonNhsSubjectName();
		} else if (view.getPersonSubjectName() != null) {
			subjectName = view.getPersonSubjectName();
		} else if (view.getOtherSubject() != null) {
			subjectName = view.getOtherSubject();
		}
		return subjectName;
	}

	private String getSubjectNameFromTo(DisciplinarySanctionTO view) {

		String subjectName = "";

		if (view.getNhsSubjectName() != null) {
			subjectName = view.getNhsSubjectName();
		} else if (view.getNonNhsSubjectName() != null) {
			subjectName = view.getNonNhsSubjectName();
		} else if (view.getPersonSubjectName() != null) {
			subjectName = view.getPersonSubjectName();
		}
		return subjectName;
	}

	/**
	 * TODO: Needs revisiting split to multiple methods.
	 */
	public DisciplinaryAppealTO loadDisciplinaryAppealByParentSanctionId(
			Long sanctionId) throws ServiceException {

		DisciplinaryAppealTO dto = new DisciplinaryAppealTO();

		dto.setAppealId(new Long(0));
		dto.setParentAppealId(new Long(0));

		DisciplinarySanctionTO sanctionTO = this
				.loadDisciplinarySanctionView(sanctionId);

		if (null != sanctionTO) {
			dto.setSubjectId(sanctionTO.getSubjectId());
			dto.setSanctionType(sanctionTO.getSanctionType());
			dto.setOrganisationName("INTERNAL".equalsIgnoreCase(sanctionTO
					.getSanctionType()) ? sanctionTO
					.getInternalOrganisationName() : sanctionTO
					.getOrganisationName());
		}

		DisciplinaryOutcomeTO sanctionOutcomeTO = loadDisciplinaryOutcomeBySanctionId(sanctionId);

		if (null != sanctionOutcomeTO) {

			dto.setOutcomeDate(sanctionOutcomeTO.getOutcomeDate());

			updateAppealTOWithAppliedSanctions(dto, sanctionOutcomeTO);
		}

		dto.setParentSanctionTO(sanctionTO);

		return dto;
	}

}
