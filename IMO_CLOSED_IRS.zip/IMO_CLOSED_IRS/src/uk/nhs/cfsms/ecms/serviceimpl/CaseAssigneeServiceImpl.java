package uk.nhs.cfsms.ecms.serviceimpl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.CasePermissionDao;
import uk.nhs.cfsms.ecms.dao.UserDetailsDao;
import uk.nhs.cfsms.ecms.data.cim.CaseAssigneeTO;
import uk.nhs.cfsms.ecms.data.cim.CasePermission;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.dto.user.UserObjectTo;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.CaseAssigneeService;

@Service(value = "caseAssigneeFacade")
@Transactional
public class CaseAssigneeServiceImpl implements CaseAssigneeService {

	@Autowired
	UserDetailsDao userDetailsDao;
	@Autowired
	CasePermissionDao casePermissionDao;

	public List<UserObject> loadUsers(Long caseId, String orgCode) {

		List<UserObject> users = userDetailsDao
				.loadLcfsStaffByCaseTeamCodeByCaseId(caseId);
		List<UserObject> cfs = userDetailsDao
				.listUserDetailsByAccessLevelAndOrgCode(ECMSConstants.ACL_CFS,
						orgCode);
		users.addAll(cfs);
		return users;
	}

	public List<UserObjectTo> loadUsersByTeamCodes(String[] teamCodes, Long caseId) throws IllegalAccessException, InvocationTargetException {

		List<UserObject> users = userDetailsDao
				.loadLcfsStaffByCaseTeamCodeByCaseId(caseId);
		List<UserObject> cfs = userDetailsDao
				.loadCFSUsersByTeamCodes(teamCodes);
		users.addAll(cfs);
		
		return convertModelToDTO(users);
	}

	public List<CaseAssigneeTO> loadAssigneeByCaseId(Long caseId)
			throws ServiceException {
		List<CasePermission> permissions = casePermissionDao
				.loadAllCaseAssigneesByCaseId(caseId);

		List<CaseAssigneeTO> assignees = new ArrayList();

		for (CasePermission perm : permissions) {
			CaseAssigneeTO assignee = new CaseAssigneeTO();

			assignee.setUser(userDetailsDao.loadUser(perm.getValue()));
			assignee.setAssigneeLevel(perm.getPermissionType());
			assignee.setCasePermission(perm);
			assignees.add(assignee);
		}
		return assignees;
	}

	public CaseAssigneeTO loadAssigneeByPermissionId(Long permissionId)
			throws ServiceException {
		CasePermission perm = casePermissionDao
				.loadCasePermissionByPermissionId(permissionId);

		CaseAssigneeTO assignee = new CaseAssigneeTO();

		assignee.setUser(userDetailsDao.loadUser(perm.getValue()));
		assignee.setAssigneeLevel(perm.getPermissionType());
		assignee.setCasePermission(perm);

		return assignee;
	}

	public void deletCaseAssignee(Long permissionId) throws ServiceException {

		casePermissionDao.deleteCasePermissionsByPermissionId(permissionId);
	}

	public CasePermission loadCasePermission(Long permissionId)
			throws ServiceException {

		return casePermissionDao.loadCasePermissionByPermissionId(permissionId);
	}

	public CasePermission upddateCasePermission(CasePermission permission)
			throws ServiceException {

		return casePermissionDao.updateCasePermission(permission);
	}

	public CaseAssigneeTO saveCaseAssignee(CaseAssigneeTO assignee)
			throws ServiceException {

		casePermissionDao.saveCasePermission(assignee.getCasePermission());
		return assignee;
	}

	/** Setters for the DAO */
	public void setCasePermissionDao(CasePermissionDao casePermissionDao) {
		this.casePermissionDao = casePermissionDao;
	}

	public void setUserDetailsDao(UserDetailsDao userDetailsDao) {

		this.userDetailsDao = userDetailsDao;
	}

	@Override
	public List<UserObjectTo> loadNewAssigneesByCaseOrgCode(Long caseId,
			List<String> currentAssignees) throws IllegalAccessException,
			InvocationTargetException {

		List<UserObject> users = userDetailsDao.loadNewLCFSByCaseOrgCode(
				caseId, currentAssignees);
		return convertModelToDTO(users);
	}

	private List<UserObjectTo> convertModelToDTO(
			final List<UserObject> usersList) throws IllegalAccessException,
			InvocationTargetException {
		final List<UserObjectTo> userObjectTOList = new ArrayList<UserObjectTo>();

		for (final UserObject user : usersList) {
			final UserObjectTo usrObjectTo = new UserObjectTo();
			BeanUtils.copyProperties(usrObjectTo, user);
			userObjectTOList.add(usrObjectTo);
		}

		return userObjectTOList;
	}
}