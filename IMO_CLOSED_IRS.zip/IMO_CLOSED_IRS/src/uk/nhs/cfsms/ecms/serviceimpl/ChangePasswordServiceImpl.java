package uk.nhs.cfsms.ecms.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.ChangePasswordDao;
import uk.nhs.cfsms.ecms.data.authentication.Users;
import uk.nhs.cfsms.ecms.data.common.UserHistory;
import uk.nhs.cfsms.ecms.service.ChangePasswordService;

/**
 * @author SKavali
 * Service implementation class for Change password
 */

@Service(value="changePasswordFacade")
@Transactional
public class ChangePasswordServiceImpl implements ChangePasswordService {
	@Autowired
	private ChangePasswordDao changePasswordDao;
	/**
	 * Service method for change password 
	 */
	public boolean changePassword(String userId, String pwd) {
		return changePasswordDao.changePassword(userId, pwd);
	}
	/**
	 * @param changePasswordDao
	 *            The changePasswordDao to set.
	 */
	public void setChangePasswordDao(ChangePasswordDao changePasswordDao) {
		this.changePasswordDao = changePasswordDao;
	}
	
	public Users loadUser(String userId) {
		
		return changePasswordDao.loadUser(userId);
	}
	
	public void updateUserHistory(UserHistory history) {
		
		changePasswordDao.updateUserHistory(history);
	}
	
	@Override
	public UserHistory loadUserHistory(String staffId) {
		
		return changePasswordDao.loadUserHistory(staffId);
	}

}
