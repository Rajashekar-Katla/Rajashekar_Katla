package uk.nhs.cfsms.ecms.serviceimpl;

import static org.apache.commons.beanutils.BeanUtils.copyProperties;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.InformationProgressDao;
import uk.nhs.cfsms.ecms.data.cim.InformationProgress;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationProgressTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.InformationProgressService;
import uk.nhs.cfsms.ecms.utility.HTMLCharacterEscapes;

@Service(value = "informationProgressService")
@Transactional
public class InformationProgressServiceImpl extends BaseServiceImpl implements
		InformationProgressService {

	private final Log log = LogFactory.getLog(getClass());

	@Autowired
	private InformationProgressDao informationProgressDao;

	@Override
	public Long generateMinuteNumber(final Long informationId)
			throws ServiceException {
		return informationProgressDao.generateMinuteNumber(informationId);
	}

	@Override
	public List<InformationProgressTO> loadInformationProgresses(
			final Long informationId) throws ServiceException,
			IllegalAccessException, InvocationTargetException {
		final List<InformationProgress> informationProgressesList = informationProgressDao
				.loadInformationProgresses(informationId);
		List<InformationProgressTO> progressTOList = new ArrayList<InformationProgressTO>();
		for (InformationProgress progress : informationProgressesList) {
			InformationProgressTO progressTO = new InformationProgressTO();
			BeanUtils.copyProperties(progressTO, progress);
			progressTOList.add(progressTO);
		}
		return progressTOList;
	}

	@Override
	public void saveInformationProgress(
			final InformationProgressTO informationProgressTO)
			throws ServiceException, IllegalAccessException,
			InvocationTargetException {
		final InformationProgress informationProgress = new InformationProgress();
		copyProperties(informationProgress, informationProgressTO);
		informationProgressDao.saveInformationProgress(informationProgress);
	}

	@Override
	public String convertToInformationProgressListToJsonString(
			List<InformationProgressTO> informationProgressTOList)
			throws IOException {

		final String singleBackSlash = "\\\\";
		final String doubleBackSlash = "\\\\\\\\";
		final String doubleQuotesUnicode = "\\u0022";
		final String doubleQuotes = "\\\\\"";

		final HTMLCharacterEscapes characterEscapes = new HTMLCharacterEscapes();
		final ObjectMapper mapper = characterEscapes.getEscapingMapper();

		String informationProgressJson = null;
		try {
			informationProgressJson = mapper
					.writeValueAsString(informationProgressTOList);

			informationProgressJson = informationProgressJson.replace(
					singleBackSlash, doubleBackSlash).replace(
					doubleQuotesUnicode, doubleQuotes);

		} catch (JsonGenerationException e) {
			log.error("Got JsonGenerationException while generating Json string from submittedAllCPSDocumentsList "
					+ e.getStackTrace());
			throw e;
		} catch (JsonMappingException e) {
			log.error("Got JsonMappingException while generating Json string from submittedAllCPSDocumentsList "
					+ e.getStackTrace());
			throw e;
		} catch (IOException e) {
			log.error("Got IOException while generating Json string from submittedAllCPSDocumentsList "
					+ e.getStackTrace());
			throw e;
		}

		return informationProgressJson;
	}

}
