package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.AppealHearingDao;
import uk.nhs.cfsms.ecms.dao.CriminalAppealDao;
import uk.nhs.cfsms.ecms.data.sanction.AppealHearing;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppeal;
import uk.nhs.cfsms.ecms.dto.caseInfo.AppealHearingTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.AppealHearingService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

/**
 * Court Appearance Service Implementation.
 * 
 */
@Service(value = "appealHearingFacade")
@Transactional
public class AppealHearingServiceImpl extends BaseServiceImpl implements
		AppealHearingService {

	@Autowired
	private AppealHearingDao appealHearingDao;
	
	@Autowired
	private CriminalAppealDao criminalAppealDao;

	public List<AppealHearingTO> loadCourtAppearancesByType(Long sanctionId,
			String sanctionType) throws ServiceException {

		List list = appealHearingDao.loadCourtHearingsByTypeAndAppealId(sanctionId,
				sanctionType);
		
		List<AppealHearingTO> appealHearingTOList  = new ArrayList<AppealHearingTO>();
		
		if (null != list && !list.isEmpty()) {
			
			for(int i=0; i< list.size(); i++) {
				
				appealHearingTOList.add(CaseUtil.convertToAppealHearingTO((AppealHearing)list.get(i)));
			}
		}
		
		return appealHearingTOList;
	}
	

	public AppealHearingTO loadCourtAppearanceById(Long appearanceId)
			throws ServiceException {

		AppealHearing hearing = appealHearingDao
				.loadAppealHearing(appearanceId);

		return CaseUtil.convertToAppealHearingTO(hearing);

	}

	public AppealHearingTO saveAppealHearing(AppealHearingTO dto)
			throws ServiceException {

		AppealHearing hibernate = CaseUtil.convertToAppealHearing(dto);
		appealHearingDao.saveObject(hibernate);

		Long appealId = hibernate.getAppealId();

		this.updateCriminalAppealWithCourtName(appealId,
				getLatestHearingCourtName(appealId));

		return CaseUtil.convertToAppealHearingTO(hibernate);
	}

	private String getLatestHearingCourtName(Long appealId) {

		return appealHearingDao.loadLatestAppealHearingCourtName(appealId);

	}

	/**
	 * Update the court name in criminal appeal.
	 * 
	 * @param appealId
	 */
	private void updateCriminalAppealWithCourtName(Long appealId,
			String courtName) {

		CriminalAppeal appeal = criminalAppealDao.loadCriminalAppeal(appealId);

		if (null != appeal) {

			appeal.setCourtMakingDecName(courtName);

			criminalAppealDao.mergeObject(appeal);
		}

	}

	public AppealHearingTO updateAppealHearing(AppealHearingTO appealHearing)
			throws ServiceException {

		AppealHearing hibernate = CaseUtil
				.convertToAppealHearing(appealHearing);

		appealHearingDao.mergeObject(hibernate);

		Long appealId = hibernate.getAppealId();

		this.updateCriminalAppealWithCourtName(appealId,
				getLatestHearingCourtName(appealId));

		return CaseUtil.convertToAppealHearingTO(hibernate);

	}

	public void deleteAppealHearing(AppealHearingTO dto)
			throws ServiceException {

		AppealHearing hibernate = CaseUtil.convertToAppealHearing(dto);

		appealHearingDao.deleteObject(hibernate);
	}

	@Override
	public AppealHearingTO updateCivilAppealHearing(AppealHearingTO dto)
			throws ServiceException {

		AppealHearing hibernate = CaseUtil.convertToAppealHearing(dto);

		appealHearingDao.saveObject(hibernate);
/*
		Long appealId = hibernate.getSanctionId();
		this.updateCivilAppealWithCourtName(appealId,
		 getLatestHearingCourtName(appealId));*/
		 
		return CaseUtil.convertToAppealHearingTO(hibernate);

	}

}
