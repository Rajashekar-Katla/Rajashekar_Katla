package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.ExhibitDao;
import uk.nhs.cfsms.ecms.data.cim.Exhibit;
import uk.nhs.cfsms.ecms.data.cim.ExhibitDocuments;
import uk.nhs.cfsms.ecms.dto.exhibit.ExhibitViewTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.ExhibitService;

@Service(value = "exhibitFacade")
@Transactional
public class ExhibitServiceImpl extends BaseServiceImpl implements
		ExhibitService {

	@Autowired
	private ExhibitDao exibhitDao;

	public List<Exhibit> loadExhibits(Long caseId) {
		return exibhitDao.loadExhibits(caseId);
	}

	public List<ExhibitDocuments> loadExhibitsForCPS(final Long caseId) {
		return exibhitDao.loadExhibitsForCPS(caseId);
	}

	public Long getExhibitFileSize(final Long id) {
		return exibhitDao.getExhibitFileSize(id);
	}

	/**
	 * This service method is responsible for loading the case Exhibit for the
	 * given exhibit ID Which is basically in turn calling the exhibit DAO layer
	 * to get the results.
	 * 
	 * */
	public Exhibit loadExhibit(Long exhibitId) {
		return exibhitDao.loadExhibit(exhibitId);
	}

	public void deleteExhibit(Long exhibitId) throws ServiceException {
		exibhitDao.deleteExhibit(exhibitId);
	}

	public ExhibitViewTO downloadExhibit(final Long exhibitId,
			final String exhibitType) {
		return exibhitDao.downloadExhibit(exhibitId, exhibitType);

	}

	public ExhibitDocuments downloadExhibitDocument(final Long id) {
		return exibhitDao.downloadExhibitDocument(id);
	}

	public void deleteExhibitDocument(final Long id) throws ServiceException {
		exibhitDao.deleteExhibitDocument(id);
	}

	/**
	 * This service method is responsible for loading the case Exhibit for the
	 * given exhibit ID Which is basically in turn calling the exhibit DAO layer
	 * to get the results.
	 * 
	 * */
	public boolean updateExhibitFileName(final Long exhibitId,
			final String fileName) {
		return exibhitDao.updateExhibitFileName(exhibitId, fileName);
	}

	public void updateExhibit(final Exhibit exhibit) {
		exibhitDao.updateExhibit(exhibit);
	}

	public void saveExhibitDocuments(final ExhibitDocuments exhibitDocuments) {
		exibhitDao.saveExhibitDocuments(exhibitDocuments);
	}

	@Override
	public List<Exhibit> loadAllExhibitDocuments(final long caseId,
			final String exhibitType) {
		return exibhitDao.loadAllExhibitDocuments(caseId, exhibitType);
	}

}
