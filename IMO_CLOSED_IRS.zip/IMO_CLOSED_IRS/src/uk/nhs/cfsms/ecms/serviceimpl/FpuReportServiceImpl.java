package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.FpuReportDao;
import uk.nhs.cfsms.ecms.dao.InformationDao;
import uk.nhs.cfsms.ecms.dao.LookupViewDao;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.fpureport.FpuReport;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.dto.caseInfo.FpuReportTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.service.FpuReportService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

@Service(value="fpuReportFacade")
@Transactional
public class FpuReportServiceImpl implements FpuReportService{
	
	@Autowired
	private LookupViewDao lookupViewDao;
	@Autowired
	private FpuReportDao fpuReportDao;
	@Autowired
	private InformationDao informationDao;
	
	public FpuReportTO saveFpuReport(FpuReportTO reportTO) throws ServiceException
	{
		FpuReport report=CaseUtil.convertToFpuReport(reportTO);
		if(reportTO.getFpuReportId()!= null)
			fpuReportDao.deleteAllFpuSubTypes(reportTO.getFpuReportId());
		fpuReportDao.saveFpuReport(report);
		reportTO.setFpuReportId(report.getFpuReportId());
		return reportTO;
		
	}
	public FpuReportTO loadFpuReportByCaseId(Long caseId) throws ServiceException
	{
		FpuReport report= fpuReportDao.loadFpuReportByCaseId(caseId);
		
		if(report != null)
			return CaseUtil.convertToFpuReportTO(report);
		
		return null;
	}
	
	
	public InformationView loadInformationByCaseId(Long caseId)
	{
		return informationDao.loadInformationViewByCaseId(caseId);
		
		
	}
	public FpuReportTO loadFpuReportByInfoId(Long infoId) throws ServiceException
	{
		FpuReport report= fpuReportDao.loadFpuReportByInfoId(infoId);
		
		if(report != null)
			return CaseUtil.convertToFpuReportTO(report);
		
		return null;
	}
	
	public FpuReportTO updateFpuReport(FpuReportTO reportTO) throws ServiceException
	{
		FpuReport report=CaseUtil.convertToFpuReport(reportTO);
		fpuReportDao.updateFpuReport(report);
		reportTO.setFpuReportId(report.getFpuReportId());
		return reportTO;
		
	}
	
	public List<LookupView> loadFpuFraudTypes() throws ServiceException
	{
		return lookupViewDao.loadActiveLookupDetailsByGroups(ECMSConstants.FPU_FRAUD_TYPE);
		
	}
	
	public List<LookupView> loadFpuSystemWeaknessTypes() throws ServiceException
	{
		
		return lookupViewDao.loadActiveLookupDetailsByGroups(ECMSConstants.FPU_SYS_WEAKNESS_TYPE);
	}
	
	public List<LookupView> loadFpuAreaTypes() throws ServiceException
	{
		return lookupViewDao.loadActiveLookupDetailsByGroups(ECMSConstants.FPU_AREA_TYPE);
		
	}
	
	public List<LookupView> loadFpuActionTakenTypes() throws ServiceException
	{
		return lookupViewDao.loadActiveLookupDetailsByGroups(ECMSConstants.FPU_ACTION_TYPE);
	}
	
	public List<LookupView> loadFpuGroupTypes() throws ServiceException
	{
		return lookupViewDao.loadActiveLookupDetailsByGroups(ECMSConstants.FPU_GROUP_TYPE);
		
	}
	
	public void setFpuReportDao(FpuReportDao fpuReportDao) {
		
		this.fpuReportDao = fpuReportDao;
	}
	
	public void setLookupViewDao(LookupViewDao lookupViewDao) {
		
		this.lookupViewDao = lookupViewDao;
	}
	
	public void setInformationDao(InformationDao informationDao) {
		
		this.informationDao = informationDao;
	}
	
	@Override
	public FpuReportTO loadAllListTypes(FpuReportTO reportTO) throws ServiceException {

		reportTO.setActionList(this.loadFpuActionTakenTypes());
		reportTO.setAreaList(this.loadFpuAreaTypes());
		reportTO.setFraudList(this.loadFpuFraudTypes());
		reportTO.setGroupList(this.loadFpuGroupTypes());
		reportTO.setWeaknessList(this.loadFpuSystemWeaknessTypes());

		return reportTO;
	}
	

}
