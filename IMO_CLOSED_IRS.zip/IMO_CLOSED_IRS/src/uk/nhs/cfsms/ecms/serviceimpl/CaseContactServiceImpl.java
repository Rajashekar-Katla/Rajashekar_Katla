package uk.nhs.cfsms.ecms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.CaseContactDao;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.infoGath.SubjectInformation;
import uk.nhs.cfsms.ecms.data.witness.Witness;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;
import uk.nhs.cfsms.ecms.service.CaseContactService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.InformationUtil;

/**
 * Case Contact Service Implementation.
 * 
 * @author sChilukuri
 * 
 */
@Service(value = "caseContactFacade")
@Transactional
public class CaseContactServiceImpl implements CaseContactService {

	@Autowired
	private CaseContactDao caseContactDao;

	public CaseContactTO loadContactById(Long contactId) {

		CaseContactTO dto = caseContactDao.loadContactById(contactId);

		if (dto != null && dto.getPersonTO() != null) {
			// If empty list create a blank one.
			dto.getPersonTO().updateAllPersonListDetails();
		}
		return dto;

	}

	public CaseContact findContactByIdForWitnessLookupUser(
			final Long contactId) {
		return caseContactDao
				.findContactByIdForWitnessLookupUser(contactId);

	}

	public List<CaseContactTO> loadContactsByInformation(Long informationId) {
		return caseContactDao.loadContactsByInformation(informationId);
	}

	public CaseContactTO saveContact(CaseContactTO contact) {

		if (contact.getContactId() == null) {
			return caseContactDao.saveContact(contact);
		} else {
			caseContactDao.updateContact(contact);
			return contact;
		}
	}

	public void updateContact(CaseContactTO contact) {
		caseContactDao.updateContact(contact);
	}

	public void deleteContact(CaseContactTO contact) {
		caseContactDao.deleteContact(contact);
	}

	public void updateCaseContactToSubject(CaseContactTO contactTO) {

		SubjectInformation subject = new SubjectInformation();
		if (contactTO != null) {
			subject.setCaseId(contactTO.getCaseId());
			subject.setSubjectPerson(ConvertFromDTO.getInstance()
					.convertFromDTO(contactTO.getPersonTO(), null, false));
			subject.setSubjectType(InformationUtil.SECONDARY_SUBJECT);
			subject.setInformation(new Long("0"));
			// Update Contact State and set Is Subject
			contactTO.setIsSubject(CaseUtil.CONSTANT_YES);
			contactTO.setState(CaseUtil.CASE_CONTACT_SUBJECT_STATE);
			caseContactDao.mergeContact(contactTO);
		}
		caseContactDao.updateCaseContactToSubject(subject);
	}

	public void updateCaseContactToWitness(CaseContactTO contactTO,
			String staffId) {
		Witness witness = new Witness();
		witness.setCreatedStaffId(staffId);
		if (contactTO != null) {
			witness.setCaseId(contactTO.getCaseId());
			witness.setState(ECMSConstants.WITNESS_USED);
			witness.setPerson(ConvertFromDTO.getInstance().convertFromDTO(
					contactTO.getPersonTO(), null, false));
			// Update Contact State and set Is Witness
			contactTO.setIsWitness(CaseUtil.CONSTANT_YES);
			contactTO.setState(CaseUtil.CASE_CONTACT_WITNESS_STATE);
			caseContactDao.mergeContact(contactTO);
		}
		caseContactDao.updateCaseContactToWitness(witness);
	}

	/**
	 * Setter method
	 * 
	 * @param caseContactDao
	 */

	public void setCaseContactDao(CaseContactDao caseContactDao) {
		this.caseContactDao = caseContactDao;
	}

}