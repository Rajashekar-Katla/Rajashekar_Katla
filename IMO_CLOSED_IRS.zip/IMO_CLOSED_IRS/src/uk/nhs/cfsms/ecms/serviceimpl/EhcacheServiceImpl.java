package uk.nhs.cfsms.ecms.serviceimpl;

import net.sf.ehcache.CacheManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import uk.nhs.cfsms.ecms.service.EhcacheService;

@Service("ehcacheService")
public class EhcacheServiceImpl implements EhcacheService {

	@Autowired
	CacheManager cacheManager;

	@Override
	public void clearAllCacheEntries() {
		resetDownloadCPSFileNamingRulesDocumentCache();
		resetGetCPSDocumentsNamingRulesCache();
		resetLoadClosedInformationReportsForIMO();

	}

	@Override
	public void resetDownloadCPSFileNamingRulesDocumentCache() {
		cacheManager.getCache("downloadCPSFileNamingRulesDocumentCache")
				.removeAll();
	}

	@Override
	public void resetGetCPSDocumentsNamingRulesCache() {
		cacheManager.getCache("getCPSDocumentsNamingRulesCache").removeAll();
	}

	@Override
	public void resetLoadClosedInformationReportsForIMO() {
		cacheManager.getCache("loadClosedInformationReportsForIMO").removeAll();
	}
}
