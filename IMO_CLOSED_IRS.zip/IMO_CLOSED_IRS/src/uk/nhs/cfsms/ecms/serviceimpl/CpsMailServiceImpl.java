package uk.nhs.cfsms.ecms.serviceimpl;

import static uk.nhs.cfsms.ecms.ECMSConstants.EXHIBITS;
import static uk.nhs.cfsms.ecms.ECMSConstants.INTERVIEWS;
import static uk.nhs.cfsms.ecms.ECMSConstants.MGFORMS;
import static uk.nhs.cfsms.ecms.ECMSConstants.WITNESS;
import static uk.nhs.cfsms.ecms.utility.EcmsUtils.escapeSPChars;

import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.CpsMailDao;
import uk.nhs.cfsms.ecms.data.cps.CpsMail;
import uk.nhs.cfsms.ecms.dto.cps.CpsMailDto;
import uk.nhs.cfsms.ecms.service.CpsMailService;
import uk.nhs.cfsms.ecms.service.ExhibitService;
import uk.nhs.cfsms.ecms.service.InterviewService;
import uk.nhs.cfsms.ecms.service.MGFormService;
import uk.nhs.cfsms.ecms.service.WitnessStatementService;

@Service
@Transactional
public class CpsMailServiceImpl implements CpsMailService {

	@Autowired
	CpsMailDao cpsMailDao;

	@Autowired
	private ExhibitService exhibitService;

	@Autowired
	private InterviewService interviewService;

	@Autowired
	private MGFormService mgFormService;

	@Autowired
	private WitnessStatementService witnessStatementService;

	@Override
	public List<CpsMailDto> getCpsMailDetails(final long caseID) {
		final List<CpsMail> cpsMailList = cpsMailDao.getCpsMailDetails(caseID);

		final List<CpsMailDto> cpsMailDtoList = new ArrayList<CpsMailDto>();

		for (CpsMail cpsMail : cpsMailList) {
			final CpsMailDto cpsMailDto = populateCPSMailDTO(cpsMail);
			cpsMailDtoList.add(cpsMailDto);
		}

		return cpsMailDtoList;
	}

	private CpsMailDto populateCPSMailDTO(final CpsMail cpsMail) {
		final CpsMailDto mailDTO = new CpsMailDto();

		mailDTO.setAttachedDocs(cpsMail.getAttachedDocs());
		mailDTO.setCaseID(cpsMail.getCaseID());
		mailDTO.setCc(escapeSPChars(cpsMail.getCc()));
		mailDTO.setEmailDate(cpsMail.getEmailDate());
		mailDTO.setInvestigationStage(escapeSPChars(cpsMail
				.getInvestigationStage()));
		mailDTO.setMessage(escapeSPChars(cpsMail.getMessage()));
		mailDTO.setSenderName(escapeSPChars(cpsMail.getSenderName()));
		mailDTO.setSenderEmailId(escapeSPChars(cpsMail.getSenderEmailId()));
		mailDTO.setSubject(escapeSPChars(cpsMail.getSubject()));
		mailDTO.setTo(escapeSPChars(cpsMail.getTo()));

		return mailDTO;
	}

	@Override
	public CpsMailDto getCpsMailDetailsByDate(Date fromDate, Date toDate) {
		return null;
	}

	@Override
	public Long save(final CpsMailDto cpsMailDto)
			throws IllegalAccessException, InvocationTargetException {
		final CpsMail cpsMail = new CpsMail();
		BeanUtils.copyProperties(cpsMail, cpsMailDto);
		return cpsMailDao.save(cpsMail);
	}

	@Override
	public void delete(final Long cpsMailID) {
		cpsMailDao.delete(cpsMailID);
	}

	public Timestamp isDocumentSent(final String docGrpID) {
		return cpsMailDao.isDocumentSent(docGrpID);
	}

	public Long getFileSize(final long documentID, final String category) {

		Long fileSize = null;

		if (StringUtils.endsWithIgnoreCase(category, EXHIBITS)) {
			fileSize = exhibitService.getExhibitFileSize(documentID);
		}

		if (StringUtils
				.endsWithIgnoreCase(category, ECMSConstants.EXHIBITLABEL)) {
			fileSize = exhibitService.getExhibitFileSize(documentID);
		}

		if (StringUtils.endsWithIgnoreCase(category, INTERVIEWS)) {
			fileSize = interviewService.getInterviewFileSize(documentID);
		}
		if (StringUtils.endsWithIgnoreCase(category, MGFORMS)) {
			fileSize = mgFormService.getMGFormFileSize(documentID);
		}
		if (StringUtils.endsWithIgnoreCase(category, WITNESS)) {
			fileSize = witnessStatementService
					.getWitnessStatementFileSize(documentID);
		}

		return fileSize;
	}
}
