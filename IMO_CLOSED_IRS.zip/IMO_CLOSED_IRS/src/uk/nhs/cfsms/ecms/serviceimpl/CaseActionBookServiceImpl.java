package uk.nhs.cfsms.ecms.serviceimpl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.cfsms.ecms.dao.CaseActionBookDao;
import uk.nhs.cfsms.ecms.data.cim.CaseActionBook;
import uk.nhs.cfsms.ecms.data.cim.CaseActionBookAttachment;
import uk.nhs.cfsms.ecms.data.cim.CaseActionSearchObject;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.dto.search.ActionSearchTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.model.CaseActionBookAttachmentTO;
import uk.nhs.cfsms.ecms.model.CaseActionBookTO;
import uk.nhs.cfsms.ecms.model.CaseActionFilterCriteria;
import uk.nhs.cfsms.ecms.service.CIUMessagesReceiverService;
import uk.nhs.cfsms.ecms.service.CaseActionBookService;
import uk.nhs.cfsms.ecms.service.IMOMessageReceiverService;
import uk.nhs.cfsms.ecms.service.UserInformationService;

/**
 * @author Jshrivastav
 * 
 * */

@Service(value = "caseActionBookFacade")
@Transactional
public class CaseActionBookServiceImpl implements CaseActionBookService {

	@Autowired
	private CaseActionBookDao caseActionBookDao;

	@Autowired
	private IMOMessageReceiverService imoMessagereceiverService;
	
	@Autowired
	private CIUMessagesReceiverService ciuMessagesReceiverService;

	@Autowired
	private UserInformationService userInformationService;

	// private UserDetailsDao userDetailsDao;
	/**
	 * This method is responsible for saving the state of object by calling DAO
	 * layer of ActionBook.
	 * 
	 * @param caseActionBook
	 * 
	 * @return CaseActionBook
	 * @throws ServiceException
	 * 
	 * */
	public CaseActionBookTO saveCase(CaseActionBookTO caseActionBook)
			throws ServiceException {
		return this.convert(caseActionBookDao.saveCaseActionBook(this
				.convert(caseActionBook)));
	}

	/**
	 * This method is responsible for loading a list of all case action Books
	 * for the given case ID by calling DAO layer of ActionBook.
	 * 
	 * @param caseID
	 * 
	 * @return CaseActionBook
	 * @throws ServiceException
	 * */
	public Collection<CaseActionBookTO> loadAllCaseActionBook(String caseID)
			throws ServiceException {
		return this.convert(caseActionBookDao.loadCaseActionBookByCaseId(Long
				.parseLong(caseID)));
	}

	/**
	 * This method is responsible for loading a list of object, with in the
	 * given starting and ending range of action Book Number for a given case
	 * ID, by calling DAO layer of ActionBook.
	 * 
	 * @param caseID
	 * @param startingActionID
	 * @param endingActionID
	 * 
	 * @return Collection<CaseActionBook>
	 * @throws ServiceException
	 * */
	public Collection<CaseActionBookTO> loadAllCaseActionBook(String caseID,
			String startingActionID, String endingActionID)
			throws ServiceException {
		return this.convert(caseActionBookDao.loadCaseActionBookByCaseId(
				Long.parseLong(caseID), Long.parseLong(startingActionID),
				Long.parseLong(endingActionID)));
	}

	/**
	 * This method is responsible for loading a list of all case action Books
	 * for the given case ID by calling DAO layer of ActionBook.
	 * 
	 * @param caseID
	 * 
	 * @return CaseActionBook
	 * @throws ServiceException
	 * */
	public Collection<CaseActionBookTO> loadAllCaseActionBook(String caseID,
			String actionStatus) throws ServiceException {
		return this.convert(caseActionBookDao.loadCaseActionBookByCaseId(
				Long.parseLong(caseID), actionStatus));
	}

	/**
	 * This method is responsible for loading a list of object, with in the
	 * given starting and ending range of action Book Number for a given case
	 * ID, by calling DAO layer of ActionBook.
	 * 
	 * @param caseID
	 * @param startingActionID
	 * @param endingActionID
	 * 
	 * @return Collection<CaseActionBook>
	 * @throws ServiceException
	 * */
	public Collection<CaseActionBookTO> loadAllCaseActionBook(String caseID,
			String startingActionID, String endingActionID, String actionStatus)
			throws ServiceException {
		return this.convert(caseActionBookDao.loadCaseActionBookByCaseId(
				Long.parseLong(caseID), Long.parseLong(startingActionID),
				Long.parseLong(endingActionID), actionStatus));
	}

	/**
	 * This method is responsible for loading the state of object by calling DAO
	 * layer of ActionBook.
	 * 
	 * @param actionID
	 * 
	 * @return CaseActionBook
	 * @throws ServiceException
	 * */
	public CaseActionBookTO loadCaseActionBook(Long actionID)
			throws ServiceException {
		return this.convert(caseActionBookDao.loadCaseActionBook(actionID));
	}

	/**
	 * This method is responsible for updating the state of object by calling
	 * DAO layer of ActionBook.
	 * 
	 * @param caseActionBook
	 * 
	 * @return CaseActionBook
	 * @throws ServiceException
	 * */
	public CaseActionBookTO saveOrUpdate(CaseActionBookTO caseActionBook)
			throws ServiceException {
		return this.convert(caseActionBookDao.updateCaseActionBook(this
				.convert(caseActionBook)));
	}

	/**
	 * This method is responsible for for fetching a new Action Number for a
	 * given case ID by calling DAO layer of ActionBook.
	 * 
	 * @param caseActionBook
	 * @param caseID
	 * 
	 * @return String
	 * @throws ServiceException
	 * */
	public String generateCaseActionBookNumber(Long caseID)
			throws ServiceException {

		try {
			return caseActionBookDao.getCaseActionBookNumber(caseID);

		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	/**
	 * This is setter method for injecting DAO layer of ActionBook.
	 * 
	 * */
	public void setCaseActionBookDao(CaseActionBookDao caseActionBookDao) {
		this.caseActionBookDao = caseActionBookDao;
	}

	/**
	 * This is setter method for injecting DAO layer of UserInformationFacade.
	 * 
	 * */
	public void setUserInformationService(
			UserInformationService userInformationFacade) {
		this.userInformationService = userInformationFacade;
	}

	/**
	 * This is converter method responsible for converting view model into DAO
	 * model.
	 * 
	 * @param cabModel
	 * 
	 * @return CaseActionBook
	 * 
	 * */

	private CaseActionBook convert(CaseActionBookTO cabModel) {

		CaseActionBook cab = new CaseActionBook();
		final String actionStatus = cabModel.getActionStatus();

		cab.setCaseActionBookId(cabModel.getCaseActionBookId());
		cab.setCaseID(cabModel.getCaseID());
		cab.setDateRecorded(cabModel.getDateRecorded());
		cab.setAllocatedBy(cabModel.getAllocatedBy());
		cab.setSourceReference(cabModel.getSourceReference());
		cab.setActionRequired(cabModel.getActionRequired());
		cab.setDateAllocated(cabModel.getDateAllocated());

		if (StringUtils.isNotEmpty(cabModel.getAllocatedTo())) {
			cab.setAllocatedTo(cabModel.getAllocatedTo());
		}
		cab.setResult(cabModel.getResult());
		cab.setSeenByOFM(cabModel.getSeenByOFM());

		if (actionStatus.equals("3")) {
			if (cabModel.getDateCompleted() == null) {
				cab.setDateCompleted(new Date());
			} else {
				cab.setDateCompleted(cabModel.getDateCompleted());
			}
		} else {
			cab.setDateCompleted(cabModel.getDateCompleted());
		}
		cab.setSentivity(cabModel.getSentivity());
		cab.setActionNumber(cabModel.getActionNumber());
		cab.setActionStatus(cabModel.getActionStatus());
		cab.setDueDate(cabModel.getDueDate());

		return cab;
	}

	/**
	 * This is converter method responsible for converting DAO model into VIEW
	 * model.
	 * 
	 * @param cab
	 * 
	 * @return CaseActionBookModel
	 * 
	 * */
	private CaseActionBookTO convert(CaseActionBook cab) {

		CaseActionBookTO actionTO = new CaseActionBookTO();
		final String allocatedTO = cab.getAllocatedTo();

		actionTO.setCaseActionBookId(cab.getCaseActionBookId());
		actionTO.setCaseID(cab.getCaseID());
		actionTO.setDateRecorded(cab.getDateRecorded());
		actionTO.setAllocatedBy(cab.getAllocatedBy());
		actionTO.setSourceReference(cab.getSourceReference());
		actionTO.setActionRequired(cab.getActionRequired());
		actionTO.setDateAllocated(cab.getDateAllocated());

		actionTO.setAllocatedTo(allocatedTO);
		actionTO.setResult(cab.getResult());
		actionTO.setSeenByOFM(cab.getSeenByOFM());
		actionTO.setDateCompleted(cab.getDateCompleted());
		actionTO.setSentivity(cab.getSentivity());
		actionTO.setActionNumber(cab.getActionNumber());

		actionTO.setActionStatus(cab.getActionStatus());
		actionTO.setDueDate(cab.getDueDate());

		if (allocatedTO != null && !allocatedTO.equals("Unallocated")) {
			if (null != cab.getAllocatedToUser()) {
				actionTO.setAllocatedToStaffName(cab.getAllocatedToUser()
						.getFirstName()
						+ " "
						+ cab.getAllocatedToUser().getLastName());
			}
		} else {
			actionTO.setAllocatedToStaffName("Unallocated");
		}

		if (null != cab.getAllocatedByUser()) {

			actionTO.setAllocatedByStaffName(cab.getAllocatedByUser()
					.getFirstName()
					+ " "
					+ cab.getAllocatedByUser().getLastName());
		}

		return actionTO;
	}

	/**
	 * This is converter method responsible for converting DAO model into VIEW
	 * model.
	 * 
	 * @param cab
	 * 
	 * @return CaseActionBookModel
	 * 
	 * */
	private CaseActionBookTO convertSearch(CaseActionSearchObject cab) {

		CaseActionBookTO actionTO = new CaseActionBookTO();
		actionTO.setCaseActionBookId(cab.getCaseActionBookId());
		actionTO.setCaseID(cab.getCaseID());
		actionTO.setDateRecorded(cab.getDateRecorded());
		actionTO.setAllocatedBy(cab.getAllocatedBy());
		actionTO.setAllocatedTo(cab.getAllocatedTo());
		actionTO.setDateCompleted(cab.getDateCompleted());
		actionTO.setActionNumber(cab.getActionNumber());
		actionTO.setOperationName(cab.getCaseOperationName());
		actionTO.setCaseNumber(cab.getCaseNumber());
		actionTO.setAllocatedByStaffName(getFullName(
				cab.getAllocatedByForename(), cab.getAllocatedBySurname()));
		actionTO.setAllocatedToStaffName(getFullName(
				cab.getAllocatedToForename(), cab.getAllocatedToSurname()));
		actionTO.setActionStatus(cab.getActionStatus());
		actionTO.setDueDate(cab.getDueDate());

		return actionTO;
	}

	private String getFullName(String foreName, String surname) {

		String fullName = "";

		if (StringUtils.isNotBlank(foreName)) {

			fullName = foreName;
		}
		if (StringUtils.isNotBlank(surname)) {

			if (StringUtils.isBlank(foreName)) {

				fullName = surname;
			} else {

				fullName = foreName.concat(" " + surname);
			}
		}

		return fullName;
	}

	private Collection<CaseActionBookTO> convert(Collection<CaseActionBook> cab) {

		ArrayList<CaseActionBookTO> listConverted = new ArrayList<CaseActionBookTO>();

		ArrayList<CaseActionBook> listFrom = new ArrayList<CaseActionBook>(cab);

		Iterator<CaseActionBook> iterator = listFrom.iterator();

		while (iterator.hasNext()) {

			listConverted.add(this.convert(iterator.next()));
		}

		return listConverted;
	}

	/**
	 * Fetching the user name through the user facade layer and decorating the
	 * view object.
	 * 
	 * */

	public String getUserFullName(String userID) {

		UserObject uObject = this.userInformationService
				.loadUserByUserId(userID);
		if (null != uObject) {
			return (uObject.getFirstName() + " " + uObject.getLastName());
		}
		return null;
	}

	/**
	 * Dao layer injection to get user details for assignment.
	 * **/
	/*
	 * public void setUserDetailsDao(UserDetailsDao userDetailsDao){
	 * this.userDetailsDao=userDetailsDao; }
	 */

	/**
	 * Fetching the list of all attachments for a given action ID.
	 * 
	 * */
	public List<CaseActionBookAttachment> listAttachments(Long actionID) {

		List<CaseActionBookAttachment> list = this.caseActionBookDao
				.listAttachments(actionID);
		return list;
	}

	/**
	 * Fetching the list of all attachments MODEL class for a given action ID .
	 * 
	 * */
	public List<CaseActionBookAttachmentTO> listAttachmentsWithUserName(
			Long actionID) {

		List<CaseActionBookAttachment> list = this.caseActionBookDao
				.listAttachments(actionID);
		List<CaseActionBookAttachmentTO> listTo = new ArrayList<CaseActionBookAttachmentTO>();
		for (CaseActionBookAttachment CABA : list) {
			listTo.add(convertAttachmentTO(CABA));
		}
		return listTo;
	}

	private CaseActionBookAttachmentTO convertAttachmentTO(
			CaseActionBookAttachment CABA) {

		CaseActionBookAttachmentTO CABATO = new CaseActionBookAttachmentTO();

		CABATO.setActionAttachmentID(CABA.getActionAttachmentID());
		CABATO.setAttachmentNumber(CABA.getAttachmentNumber());
		CABATO.setActionID(CABA.getActionID());
		CABATO.setAttachmentName(CABA.getAttachmentName());
		CABATO.setAttachmentType(CABA.getAttachmentType());
		CABATO.setAttachmentBlob(CABA.getAttachmentBlob());
		CABATO.setCreationDateTime(CABA.getCreationDateTime());
		CABATO.setCreatedBy(CABA.getCreatedBy());
		CABATO.setCreatedByFullName(this.getUserFullName(CABA.getCreatedBy()));
		CABATO.setSensitive(CABA.getSensitive());
		CABATO.setMarkAsDeleted(CABA.getMarkAsDeleted());
		CABATO.setAttachmentDescription(CABA.getAttachmentDescription());

		return CABATO;
	}

	/**
	 * Saving a new attachment through DAO layer.
	 * 
	 * */
	public CaseActionBookAttachment downloadCaseActionBookAttachment(
			String attachmentID) {
		return this.caseActionBookDao.downloadCaseActionBookAttachment(Long
				.parseLong(attachmentID));
	}

	public CaseActionBookAttachment loadCaseActionBookAttachment(
			final String attachmentID) {
		return this.caseActionBookDao.loadCaseActionBookAttachment(Long
				.parseLong(attachmentID));
	}

	/**
	 * downloading a attachment through DAO layer.
	 * 
	 * */
	public void saveCaseActionBookAttachment(
			CaseActionBookAttachment caseActionBookAttachment) {
		this.caseActionBookDao
				.saveCaseActionBookAttachment(caseActionBookAttachment);
	}

	/**
	 * Saving a new attachment through DAO layer.
	 * 
	 * */
	public String getCaseActionBookAttachmentNumber(Long actionID) {
		return this.caseActionBookDao
				.getCaseActionBookAttachmentNumber(actionID);
	}

	/**
	 * This method is responsible for loading the CaseActionBook Model object by
	 * calling DAO layer of ActionBook.
	 * 
	 * @param noOfDays
	 * 
	 * @return List<CaseActionBookTO>
	 * @throws ServiceException
	 * @throws ParseException
	 * */
	public List<CaseActionBookTO> loadDueCaseActionBook(int noOfDays)
			throws ServiceException, ParseException {
		return (List<CaseActionBookTO>) this.convert(caseActionBookDao
				.loadDueCaseActionBooks(noOfDays));
	}

	/**
	 * This method is responsible for loading all case action books for the
	 * search criteria..
	 * 
	 * @param ActionSearchTO
	 * 
	 * @return ActionSearchTO
	 * @throws ServiceException
	 * */
	public ActionSearchTO getActionSearchResults(ActionSearchTO searchTO,
			SessionUser user) throws ServiceException {

		ActionSearchTO resultSearchTO = caseActionBookDao
				.getActionSearchResults(searchTO, user);

		List<CaseActionSearchObject> result = resultSearchTO.getSearchResults();

		List<CaseActionBookTO> resultTO = resultSearchTO.getSearchResultsTO();

		if (result != null && !result.isEmpty()) {

			for (CaseActionSearchObject entity : result) {

				resultTO.add(convertSearch(entity));
			}
		}
		return resultSearchTO;
	}

	@Override
	public Collection<CaseActionBookTO> loadCaseActionBook(
			CaseActionFilterCriteria filter) throws ServiceException {

		return this.convert(caseActionBookDao.loadCaseActionBook(filter));

	}
	
	@Override
	public String getActiveIMOMessageReceiverStaffId() {
		return imoMessagereceiverService.getActiveStaffId();
	}

	@Override
	public String getActiveCIUMessagesReceiverStaffId(){
		return ciuMessagesReceiverService.getActiveStaffId();
	}
	/**
	 * Fetching the list of all attachments in All ActionBook for a given case
	 * ID. This is being used is CPS document list to list all the action book
	 * attachments for a given case ID.
	 * 
	 * @param Long
	 *            caseID
	 * @return List<CaseActionBookAttachment>
	 * 
	 * */
	public List<CaseActionBookAttachment> listAllAttachments(Long caseID) {
		ArrayList<CaseActionBookAttachment> CABAS = new ArrayList<CaseActionBookAttachment>();
		ArrayList<CaseActionBookTO> CABTOS;
		try {
			CABTOS = (ArrayList<CaseActionBookTO>) this
					.loadAllCaseActionBook(caseID + "");
			for (CaseActionBookTO CABTO : CABTOS) {
				CABAS.addAll(listAttachments(CABTO.getCaseActionBookId()));
			}
		} catch (ServiceException e) {
			e.printStackTrace();
			return null;
		}
		return CABAS;
	}
}
