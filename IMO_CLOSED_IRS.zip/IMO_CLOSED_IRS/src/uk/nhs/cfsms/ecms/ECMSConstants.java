package uk.nhs.cfsms.ecms;

import java.text.SimpleDateFormat;

public final class ECMSConstants {

	private ECMSConstants() {
	}

	public final static String SESSION_USER_DETAILS = "SessionUser";

	public final static String SESSION_INFO_GATHER = "sessioninfogather";

	public final static String SESSION_INFORMATION = "sessionInformation";

	public final static String ACEGI_SECURITY = "ACEGI_SECURITY_LAST_USERNAME";

	public static final String SECURITY_PROFILE = "SECURITY_PROFILE";

	public static final String BREAD_CRUMBS = "breadCrumbs";

	public static final String VIEW_HELPER = "viewHelper";

	public final static SimpleDateFormat dateFormat = new SimpleDateFormat(
			"dd/MM/yyyy");

	public final static SimpleDateFormat datetimeFormat = new SimpleDateFormat(
			"dd/MM/yyyy HH:mm:ss");

	/** GROUP NAME FOR THE LOOKUP DATA. * */

	public final static String LOOKUP_OCCUPATION_TYPE = "OCCUPATION_TYPE";

	@Deprecated
	public final static String LOOKUP_FRAUD_TYPE = "FRAUD_TYPE";

	public final static String LOOKUP_FRAUD_AMOUNT_RANGE = "FRAUD_AMOUNT_RANGE";

	public final static String LOOKUP_SECURITY_MENU_ITEMS = "SECURITY_MENU_ITEMS";

	public final static String LOOKUP_COMPANY_STATUS = "COMPANY_STATUS";
	public final static String LOOKUP_COMPANY_TYPE = "COMPANY_TYPE";

	public final static String LOOKUP_SOURCE = "SOURCE";
	// -- Lookup has parent Id, so DYNAMIC.
	public final static String LOOKUP_SOURCE_SUB_TYPE = "SUB_TYPE";

	/** Restructure, Lookup groups for NHS PROTECT from April/2011... **/
	// -- Information Admin fraud Type based on Area
	public final static String LOOKUP_NHS_FRAUD_AREA = "NHS_FRAUD_AREA";
	// -- Lookup has parent Id, so DYNAMIC.
	public final static String LOOKUP_FRAUD_SUB_AREA_1 = "FRAUD_SUB_AREA_1";
	// -- Lookup has parent Id, so DYNAMIC.
	public final static String LOOKUP_FRAUD_SUB_AREA_2 = "FRAUD_SUB_AREA_2";
	// -- Lookup has parent Id, so DYNAMIC.
	public final static String LOOKUP_AREA_FRAUD_TYPE = "AREA_FRAUD_TYPE";
	// -- SUBJECT Occupation Types..
	public final static String LOOKUP_NHS_CAREER_AREA_TYPE = "NHS_CAREER_AREA_TYPE";
	public final static String LOOKUP_OCCUPATION_PATIENT_TYPE = "OCCUPATION_PATIENT_TYPE";
	public final static String LOOKUP_OCCUPATION_OTHER_TYPE = "OCCUPATION_OTHER_TYPE";
	// -- Lookup has parent Id, so DYNAMIC.
	public final static String LOOKUP_OCCUPATION_NHS_TYPE = "OCCUPATION_NHS_TYPE";
	// -- CASE CLOSURE TYPES..
	public static final String LOOKUP_CASE_CLOSURE_TYPE = "CASE_CLOSURE_TYPE";
	public static final String LOOKUP_CASE_CLOSURE_PART1_TYPE = "NEW_CLOSURE_TYPE_1";
	public static final String LOOKUP_CASE_CLOSURE_PART2_TYPE = "NEW_CLOSURE_TYPE_2";

	/** PERSON AND PERSON DESCRIPTION GROUPS * */

	public final static String LOOKUP_NATIONALITY = "NATIONALITY";

	public final static String LOOKUP_PERSON_ETHNIC_CODE = "PERSON_ETHNIC_CODE";

	public final static String LOOKUP_HAIR_COLOUR = "HAIR_COLOUR";

	public final static String LOOKUP_FACIAL_HAIR = "FACIAL_HAIR";

	public final static String LOOKUP_HAIR_DESCRIPTION = "HAIR_DESCRIPTION";

	public final static String LOOKUP_HAIR_TYPE = "HAIR_TYPE";

	public final static String LOOKUP_EYE_COLOUR = "EYE_COLOUR";

	public final static String LOOKUP_BODY_TYPE = "BODY_TYPE";

	public final static String LOOKUP_FEATURES = "FEATURES";

	/** CASE CONTACT LOOKUP GROUPS * */

	public final static String LOOKUP_CASE_CONTACT_STATE = "CASE_CONTACT_STATE";

	public final static String LOOKUP_CASE_CONTACT_TITLE = "CASE_CONTACT_TITLE";

	public final static String LOOKUP_CASE_CONTACT_TYPE = "CASE_CONTACT_TYPE";
	
	public final static String LOOKUP_PATIENT_OCCUPATION = "PATIENT_OCCUPATION";

	/** CASE COURT APPEARANCE LOOKUP GROUPS * */
	public static final String LOOKUP_CASE_COURT_TYPE = "CASE_COURT_TYPE";

	public static final String LOOKUP_CASE_APPEARANCE_TYPE = "CASE_APPEARANCE_TYPE";

	/** APPEAL HEARING LOOKUP GROUPS * */
	public static final String LOOKUP_CASE_COURT_TYPE_APPEAL = "CASE_COURT_TYPE_APPEAL";

	public static final String LOOKUP_CRIMINAL_APPEAL_COURT_TYPE = "CRIMINAL_APPEAL_COURT_TYPE";

	public static final String LOOKUP_CIVIL_APPEAL_COURT_TYPE = "CIVIL_APPEAL_COURT_TYPE";

	public static final String LOOKUP_INT_DISP_APPEAL_COURT_TYPE = "INT_DISP_APPEAL_COURT_TYPE";

	public static final String LOOKUP_EXT_DISP_APPEAL_COURT_TYPE = "EXT_DISP_APPEAL_COURT_TYPE";

	public static final String LOOKUP_CASE_APPEARANCE_TYPE_APPEAL = "CASE_APPEARANCE_TYPE_APPEAL";

	public static final String SUCCESS_SANCTIONS = "SUCCESS_SANCTIONS";

	public static final String UNSUCCESS_SANCTIONS = "UNSUCCESS_SANCTIONS";

	public static final String SANCTION_ORDERS = "SANCTION_ORDERS";

	/** Case permission constants * */

	public static final String ASSIGNEE_PERMISSION = "LEAD_ASSIGNEE";

	public static final String TEAM_PERMISSION = "TEAM_CODE";
	
	/**This is being used for information transfer to provide read only information to the teams
	 * */
	public static final String INFO_PERMISSION_READ_ONLY = "READ_ONLY"; 

	public static final String CASE_ASSIGNEE_PERMISSION = "CASE_ASSIGNEE";
	
	public static final String DISCLOSURE_OFFICER_PERMISSION = "DISC_OFFICER";
	
	public static final String SENIOR_INVESTIGATING_OFFICER_PERMISSION = "SEN_INV_OFFICER";
	
	public static final String FINANCIAL_INVESTIGATOR_PERMISSION = "FINANCIAL_INV";
	
	public static final String FORENSIC_COMPUTING_SPECIALIST_PERMISSION = "FORENSIC_COMP_SPEC";

	public static final String INFO_ASSIGNEE_PERMISSION = "INFO_ASSIGNEE";

	public static final String DELETE_SUFFIX = "_DELETE";
	
	public static final String INFO_ASSIGNEE_PERMISSION_DELETE = "INFO_ASSIGNEE_DELETE";
	
	public static final String ORGANISATIONAL_PERMISSION = "ORG_CODE";
	
	public static final String ORGANISATIONAL_PERMISSION_DELETE = "ORG_CODE_DELETE";
	
	public static final String TEAM_PERMISSION_DELETE = "TEAM_CODE_DELETE";

	public static final String CASE_ASSIGNEE_PERMISSION_DELETE = "CASE_ASSIGNEE_DELETE";
	
	public static final String LEAD_ASSIGNEE_PERMISSION_DELETE = "LEAD_ASSIGNEE_DELETE";
	
	public static final String SENIOR_INVESTIGATING_OFFICER_PERMISSION_DELETE = "SIO_DELETE";
	
	public static final String DISCLOSURE_OFFICER_PERMISSION_DELETE = "DO_DELETE";
	
	public static final String FINANCIAL_INVESTIGATOR_PERMISSION_DELETE = "FI_DELETE";

	public static final String FORENSIC_COMPUTING_SPECIALIST_PERMISSION_DELETE = "FCS_DELETE";
	
	public static final String INFO_PERMISSION_READ_ONLY_DELETE = "READ_ONLY_DELETE"; 

	public static final String FCRL_PERMISSION = "FCRL";

	public static final String FCRL_PERMISSION_VALUE = "FCRL";

	public static final String REGIONAL = "CFS_REG";

	public static final String LOCAL = "CFS_LOC";

	public static final String NATIONAL = "CFS_NAT";

	/** User Directorate * */

	public static final String DIRECTORATE_REGIONAL = "REG";

	public static final String DIRECTORATE_LOCAL = "LOC";

	public static final String DIRECTORATE_NATIONAL = "NAT";

	/** Permission Group constants * */

	public static final String ADMIN = "ADMIN";

	public static final String DIRECTOR = "DIRECTOR";

	public static final String REPORTER = "REPORTER";

	public static final String OFM = "DETECTIVE_OFM";

	public static final String CFS = "DETECTIVE_CFS";

	public static final String LCFS = "DETECTIVE_LCFS";

	public static final String FCRL = "FCRL";

	public static final String OFM_AFS = "AFS";

	public static final String AAFSS = "AAFS";

	public static final String AFL = "AFL";

	/** Permission Group constants * */

	public static final String ADMIN_LEVEL = "1";

	public static final String DIRECTOR_LEVEL = "2";

	public static final String REPORTER_LEVEL = "3";

	public static final String OFM_LEVEL = "4";

	public static final String CFS_LEVEL = "5";

	public static final String LCFS_LEVEL = "6";

	public static final String FCRL_LEVEL = "7";

	/*******
	 * RESTRUCTURING FROM CFSMS - PROTECT ********** New Levels instead of OFM
	 * (AFL(AntiFraudLead)), CFS(AFS (AreaAntiFraudSpecialist)) and AAFS_LEVEL
	 * (AreaAntiFraudSpecialistSupport)) from April/2011
	 */

	public static final String AFS_LEVEL = "8";

	public static final String AFL_LEVEL = "9";

	public static final String AAFS_LEVEL = "10";

	/** National Investigation Team North and South **/

	public static final String NIT_NORTH = "NITN";

	public static final String NIT_SOUTH = "NITS";

	public static enum NIT_TEAMS { NITN, NITS };
	
	/** Case Status Constants * */

	public static final String CASE_OPEN = "OPEN";

	public static final String CASE_CLOSED = "CLOSED";

	public static final String CASE_PENDING = "PENDING_CLOSURE";

	public static final String CASE_AWAITING = "AWAITING";
	
	public static final String CASE_REOPENED = "REOPENED";

	public static final String LCFS_CASE_CLOSED = "LCFS-CLOSED";

	public static final String CFS_CASE_CLOSED = "CFS-CLOSED";
	
	public static final String CASE_ACTION_COMPLETED = "COMPLETED";
	
	public static final String CASE_ACTION_OUSTANDING = "OUTSTANDING";

	/** Witness Status Constants * */

	public static final String WITNESS_USED = "CURRENT-USED";

	public static final String WITNESS_UNUSED = "CURRENT-UNUSED";

	public static final String WITNESS_SUBJECT = "SUBJECT";

	/** Case Contacts State Constants **/

	public static final String CASE_CONTACT_SUBJECT = "SUBJECT";

	public static final String CASE_CONTACT_WITNESS = "WITNESS";

	/** Witness Statement Constants * */

	public static final String UPLOADED_STATEMENT = "UPLOADED";

	public static final String FILLED_STATEMENT = "FILLED";

	/** Transfer constants * */

	public static final String TRANSFER_LCFS = "LCFS";

	public static final String TRANSFER_CFS = "CFS";

	/**
	 * The below 3 flags are being updated in CASE AFL transfer
	 * */
	// MANAGER APPROVAL PENDING FOR CFS/AFL CASE TRANSFER.
	public static final String TRANSFER_LEAD_APPROVAL_PENDING = "P"; 
	// MANAGER APPROVES THE CFS/AFL TRANSFER
	public static final String TRANSFER_LEAD_APPROVAL_APPROVED = "A"; 
	// MANAGER REJECTS THE CFS/AFL TRANSFER
	public static final String TRANSFER_LEAD_APPROVAL_REJECTED = "R"; 
	
	public static final String TRANSFER_APPROVAL_PENDING = "APPROVAL PENDING";

	public static final String TRANSFER_REFERRED = "REFERRED";

	public static final String TRANSFER_ACCEPTED = "ACCEPTED";

	public static final String TRANSFER_REJECTED = "REJECTED";

	public static final String TRANSFER_CANCELLED = "CANCELLED";

	public static final String TRANSFER_NEW = "NEW";

	public static final String MESSAGE_STATE_NEW = "NEW";

	public static final String MESSAGE_STATE_READ = "READ";

	public static final String MESSAGE_STATE_DELETE = "DELETE";

	/** MGForm constants * */

	public static final String MGFORM_TYPE = "MGFORM_TYPE";

	/** Java Mail constants * */

	public static final String SMTP_HOST_STRING = "smtp.cfsms.nhs.uk";

	public static final String SMTP_HOST_IP = "10.10.10.45";

	// Access level constants
	public static final String ACL_ADMIN = "ADMIN";

	public static final String ACL_DIR = "DIR";

	public static final String ACL_REP = "REP";

	public static final String ACL_OFM = "OFM";

	public static final String ACL_CFS = "CFS";

	public static final String ACL_LCFS = "LCFS";

	public static final String ACL_FCRL = "FCRL";

	public static final String ACL_UNKNOWN = "UNKNOWN";

	public static final String ACL_OFM_AFS = "AFS";

	public static final String ACL_AAFSS = "AAFS";

	public static final String ACL_NIT = "AFL";

	public static final String CIU_TEAM_CODE = "CIU";

	// -- FPU
	public static final String FPU_FRAUD_TYPE = "FPU_FRAUD_TYPE";
	public static final String FPU_SYS_WEAKNESS_TYPE = "FPU_SYS_WEAKNESS_TYPE";
	public static final String FPU_AREA_TYPE = "FPU_AREA_TYPE";
	public static final String FPU_GROUP_TYPE = "FPU_GROUP_TYPE";
	public static final String FPU_ACTION_TYPE = "FPU_ACTION_TYPE";

	public static final String DISCIP_SANCTION_TYPE = "DISCIP_SANCTION_TYPE";

	public static final String CASE_PROGRESS_MINS = "CASEPROGRESSMINS";
	public static final String CASE_PROGRESS_TYPE = "CASEPROGRESSTYPE";
	
	// Add new contact or address or alias details for the person.
	public static final String ADD_NEW_CONTACT = "addNewContact";
	public static final String ADD_NEW_ADDRESS = "addNewAddress";
	public static final String ADD_NEW_ALIAS = "addNewAlias";

	// Case prosecute
	public static final String SOLP = "SOLP";

	// UNKOWN ORG CODES and TEAM CODES..
	public static final String UNKNOWN_ORG_CODE = "99999";
	public static final String ORG_UNKNOWN = "ORG-UNKNOWN";
	public static final String UNKOWN_TEAM_CODE = "999";
	public static final String TEAM_UNKNOWN = "TEAM-UNKNOWN";

	public static final String CASE_INFO_IN_SESSION = "CASE_INFO_IN_SESSION";

	// NATIONAL LEVEL TEAM_ORGS, CUOPS is the new convention for CU/CFSMS
	public static enum NATIONAL_ORGS {CUOPS, OST, NPT, PFT, DFT, CU, SOP, NITN, NITS};

	// Default password
	public static final String DEFAULT_PASSWORD = "changeit";

	// Default password
	public static final String PASSWORD_MD5_COMPLAINT = "Y";

	public static final String TEAM_CIU = "CIU";
	public static final String TEAM_FPU = "FPU";
	public static final String TEAM_IMO = "IMO";
	public static final String TEAM_SOP = "SOP";
	public static final String TEAM_WARO = "WARO";
	public static final String TEAM_PFSU = "PFSU";
	public static final String TEAM_SWRT = "SWRT";
	public static final String TEAM_CUOPS = "CUOPS";
	public static final String TEAM_DHAFU = "DHAFU";
	public static final String TEAM_FCO = "FCO";
	
	public static enum OFM_TEAMS { CIU, FPU, PFSU, SOP, WARO, DHAFU };

	// -- Information Discard and transfers
	public static final String INFO_DISCARD_REJECT = "R";
	public static final String INFO_DISCARD_HOLD = "H";
	public static final String INFO_DISCARD_OPEN = "O";

	// -- Information states.
	public static final String INFO_STATE_CLOSED = "CLOSED";
	public static final String INFO_STATE_REJECT_TRANSFER = "REJECT_TRANSFER_CIU";
	public static final String INFO_TRANSFERRED = "TRANSFERRED";
	// -- Information approval states Start.
	public static final String INFO_APPROVAL_STATUS_APPROVED = "A"; 
	public static final String INFO_APPROVAL_STATUS_REJECTED = "R";
	public static final String INFO_APPROVAL_STATUS_PENDING = "P";
	public static final String INFO_APPROVAL_STATUS_NOT_INITIATED = "N";
	// -- Information approval states End.

	// -- Information Transfers.
	public static final String INFO_TEAM_STATE_NEW = "N";
	public static final String INFO_TEAM_STATE_CREATED = "C";
	public static final String INFO_TEAM_STATE_OLD = "O";
	public static final String INFO_TEAM_STATE_PROCESSED = "P";
	public static final String INFO_TEAM_STATE_DISCARDED = "D";

	public static final String INFO_OPEN = "OPEN";

	// -- Data Value for Information Source Type.
	public static final String SOURCE_TYPE_OTHER = "387";
	
	// PATRICK NOLAN - Business Manger until April 2012
	public static final String USER_MANAGER = "ops0005";
	// DEREK JOHNSON - Head of Operations
	public static final String USER_HEAD_OPS = "ops0068";
	// SUSAN FRITH -- Deputy Head of Operations
	public static final String USER_DEPUTY_OPS = "ops0256";

	public static final String NOT_FOUND = "NOT_FOUND";

	public static final String ACCESS_FLAG_CONFIDENTIAL = "C";
	
	public static final String ACCESS_FLAG_RESTRICTED = "R";
	
	public static enum MESSAGE_PARENT_FLOW {NEW, READ, SENT, VIEW, REJECT, INFORMATION, CASE, TRASH};

	public static enum REGIONAL_TEAMS {SERT, SWRT, LORT, EART, EMRT, WMRT, NWRT, NYRT, WARO};
	
	public static enum NAT_TEAMS { NITN, NITS, SOP, DHAFU };
	
	public static enum FCO_TEAMS { NITN, NITS, SOP, DHAFU, IMO };
	
	public static enum LSDS_REGIONAL_TEAMS {SERT, SWRT, LORT, EART, EMRT, WMRT, NWRT, NYRT};
	
	public static final String DEFAULT_USER_FONT = "11";
	public static final String SESSION_USER_FONT = "USER_FONT";
	public static final String NO_SUBJECTS = "no_case_subjects";

	public static final String ERROR_MESSAGES = "errorMessages";
	
	public static final String Cps_MgFormsTO = "cpsMgFormsTO";
	
	public static final String OTHER="Other";
	
	public static final String WORD_DOC="WORD DOC";
	
	public static final String WORD_DOCX="WORD DOCX";

	public static final String TEXT = "TEXT";

	public static final String DOC_EXT = "DOC";
	
	public static final String DOCX_EXT="DOCX";

	public static final String TXT_EXT = "TXT";
	
	public static final String IMO="IMO";
	
	public static final String CIU="CIU";

	/**
	 * CPS Documents Approval request/response constants
	 */
	public static final String CASE_ID = "caseID";

	public static final String NEW = "NEW";
	public static final String COMMA = ",";
	public static final String SEMI_COLON = ";";
	public static final String HYPHEN = "-";
	public static final String TILDE = "~";
	public static final String APR = "APR";
	public static final String REJ = "REJ";
	public static final String ACCEPT = "accept";
	public static final String REJECT = "reject";
	
	public static final String ACTION_BOOK = "ACTION BOOK";
	public static final String EXHIBITS = "EXHIBITS";
	public static final String EXHIBITLABEL = "EXHIBITLABEL";
	public static final String INTERVIEWS = "INTERVIEWS";
	public static final String MGFORMS = "MGFORMS";
	public static final String CLOSURE_REPORT = "CLOSURE REPORT";
	public static final String WITNESS = "WITNESS";
	
	public static final String SENT = "SENT";
	
	public static final String FIRST_CACHEMANAGER = "FIRST_CacheManager";
	public static final String EHCACHE_XML_FILE = "WEB-INF/ehcache.xml";

	public static final String CLOSED = "CLOSED";
	

}