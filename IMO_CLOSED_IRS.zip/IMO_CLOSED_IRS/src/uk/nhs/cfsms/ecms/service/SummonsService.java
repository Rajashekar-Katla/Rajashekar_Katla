package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.Summons;

public interface SummonsService extends BaseService {

	List<Summons> getSummons(Long criminalSanctionId);
	
}
