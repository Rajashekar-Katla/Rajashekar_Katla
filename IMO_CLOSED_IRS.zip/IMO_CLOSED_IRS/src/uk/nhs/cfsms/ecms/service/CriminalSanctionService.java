package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.PoliceCharge;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalSanctionTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface CriminalSanctionService extends BaseService {
	
	List<CriminalSanctionTO> loadCriminalSanctions(Long caseId) throws ServiceException ;

	PoliceCharge loadPoliceCharge(Long sanctionId) throws ServiceException ;
	
	PoliceCharge savePoliceCharge(PoliceCharge charge) throws ServiceException ;

	CriminalSanctionOutcome loadCriminalSanctionOutcome(Long sanctionId) throws ServiceException;

	CriminalSanctionOutcome saveOutcome(CriminalSanctionOutcome dto) throws ServiceException ;
	
	public List<CriminalSanctionTO> loadCriminalSanctionsForReport(Long caseId) throws ServiceException ;

	public void deleteCriminalSanctionById(Long sanctionId) throws ServiceException ;
	
	public CriminalSanctionTO getCriminalSanction(Long sanctionId) throws ServiceException ;

}
