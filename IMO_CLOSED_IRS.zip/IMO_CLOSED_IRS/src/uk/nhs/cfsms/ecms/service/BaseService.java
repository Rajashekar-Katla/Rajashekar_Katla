package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.dao.BaseDao;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface BaseService {

	
	void setBaseDao(BaseDao baseDao) throws ServiceException;

    List getObjects(Class thisClass) throws ServiceException;

    Object getObject(Class clazz, Long id) throws ServiceException;

    void saveObject(Object o) throws ServiceException;
    
    void saveObjects(List objects) throws ServiceException;

    void deleteObject(Object o) throws ServiceException;

    void evictObject(Object o) throws ServiceException;
    
}
