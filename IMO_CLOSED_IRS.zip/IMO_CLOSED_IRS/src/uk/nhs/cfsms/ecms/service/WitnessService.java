package uk.nhs.cfsms.ecms.service;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.List;

import org.dom4j.Document;

import uk.nhs.cfsms.ecms.data.witness.Witness;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationDetails;
import uk.nhs.cfsms.ecms.dto.witness.WitnessTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface WitnessService {

	public List loadWitnessesByCaseId(Long caseId);

	public WitnessTO loadWitnessById(Long witnessId) throws ServiceException;

	//	public WitnessTO saveWitness(WitnessTO witness) throws ServiceException;

	public WitnessTO saveWitness(WitnessTO witnessTO, boolean isLookupUserSave)
			throws ServiceException;

	public WitnessTO updateWitness(WitnessTO witness) throws ServiceException;

	public Document transform(String stylesheet, List<Witness> list)
			throws ServiceException;

	public Document transform(String stylesheet, List<Witness> list,
			String caseNumber, String operationName) throws ServiceException;

	public List<Witness> loadAllWitnessesByCaseId(Long caseId, String byFilter);

	public void updateWitnessToSubject(WitnessTO witnessTO)
			throws ServiceException;

	public List<WitnessTO> loadWitnessByNativeSql(final String firstName,
			final String lastName, final String dob) throws ServiceException,
			IllegalAccessException, InvocationTargetException, ParseException;

	public InformationDetails loadWitnessByIdForInfoSubject(Long witnessId)
			throws ServiceException;

	public CaseContactTO loadWitnessByIdForContact(Long witnessId)
			throws ServiceException;
	
	public List<WitnessTO> loadAllWitnessesByCaseIdForExhibit(Long caseId);
	
	public WitnessTO loadWitnessesByIdForExhibit(Long caseId);
}
