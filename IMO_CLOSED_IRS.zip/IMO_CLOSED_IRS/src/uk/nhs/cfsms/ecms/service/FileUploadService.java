package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.FileObject;

public interface FileUploadService {
	
	
	public FileObject saveFile(FileObject file);
	
	public FileObject updateFile(FileObject file);
		
	public void deleteFile(Long fileId);
		
	public FileObject loadFileByFileId(Long  fileId);
	
	public List<FileObject> loadFileByFileByDept(String dept);
	
	public List<FileObject> loadFileByFileByCategory(String category);
	
	public Boolean isUserUploadAdmin(String category, String staffId);

}
