/**
 * 
 */
package uk.nhs.cfsms.ecms.service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSDocumentsDTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSDocumentsViewDTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSFileNamingRulesDocumentDTO;
import uk.nhs.cfsms.ecms.dto.cps.CPSMailFormFieldsDTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface CPSDocumentService {

	/**
	 * This service method is responsible for loading all requests created by
	 * the user for a case.
	 * 
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 * */
	public List<CPSDocumentsViewDTO> loadAllRequests(final long caseID)
			throws IllegalAccessException, InvocationTargetException;

	/**
	 * This service method is responsible for loading all requests history
	 * created by the user for a case.
	 * */
	public List<CPSDocumentsViewDTO> loadAllRequestsHistory(
			final String staffID, final long caseID);

	/**
	 * This service method is responsible for loading all the documents
	 * associated with the given case ID.
	 * */
	public List<CPSDocumentsDTO> loadAllDocuments(Long caseID);

	/**
	 * This service method is responsible for downloading the requested
	 * document.
	 * 
	 **/
	public CPSDocumentsDTO downloadCPSDocument(final Long documentID,
			final Long caseID, final String category,
			final boolean isFileBlobRequired);

	public CPSDocumentsViewDTO createApprovalRequest(CPSDocumentsViewDTO cpsDTO);

	/**
	 * This service method is responsible for triggering the dao layar to save
	 * the Lead Acceptance for the currently available request in system. This
	 * layer first load the current Request and then update the object with
	 * approval data and save. System screen will be loaded with request
	 * cleared.
	 * */
	public List<CPSDocumentsViewDTO> createApprovalResponse(
			CPSDocumentsViewDTO cpsDocumentsViewDTO);

	/**
	 * Fetching the user name through the user facade layer and decorating the
	 * view object.
	 * 
	 * */
	public String getUserFullName(String userID);

	public Map<String, String> getCPSDocumentsNamingRules();

	public void updateCPSDocumentFileName(final String category,
			final String fileName, final String docID) throws ServiceException;

	public void saveCPSFileNamingRulesDocument(
			final CPSFileNamingRulesDocumentDTO cpsFileNamingRulesDocumentDTO);

	public CPSFileNamingRulesDocumentDTO downloadCPSFileNamingRulesDocument()
			throws ServiceException;

	public List<CPSMailFormFieldsDTO> getCPSFormFields(
			final SessionUser sessionUser, final String caseID,
			final String caseNumber) throws ServiceException;

	public String getCPSDocsRequestorStaffID(final long caseID);

	public String getStaffNHSEmailAddress(final String staffID);

	public String getStaffNHSEmailAddressFromCPOD(final String staffID);

	public List<CPSDocumentsDTO> loadAllCPSApprovedDocumentsByNativeSQL(
			String staffID, long caseID) throws ServiceException;
	
	public CaseTO loadCase(Long caseID) throws ServiceException;

}
