package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.dto.caseInfo.FpuReportTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface FpuReportService {
	
	public FpuReportTO saveFpuReport(FpuReportTO report) throws ServiceException;
			
	public FpuReportTO loadFpuReportByCaseId(Long caseId) throws ServiceException;
	
	public FpuReportTO loadFpuReportByInfoId(Long infoId) throws ServiceException;
	
	public FpuReportTO updateFpuReport(FpuReportTO report) throws ServiceException;
	
	public List<LookupView> loadFpuFraudTypes() throws ServiceException;
	
	public List<LookupView> loadFpuSystemWeaknessTypes() throws ServiceException;
	
	public List<LookupView> loadFpuAreaTypes() throws ServiceException;
	
	public List<LookupView> loadFpuActionTakenTypes() throws ServiceException;
	
	public List<LookupView> loadFpuGroupTypes() throws ServiceException;
	
	public InformationView loadInformationByCaseId(Long caseId);

	public FpuReportTO loadAllListTypes(FpuReportTO reportTO)  throws ServiceException;
	
}
