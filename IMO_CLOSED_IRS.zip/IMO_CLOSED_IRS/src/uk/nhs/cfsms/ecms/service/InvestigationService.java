package uk.nhs.cfsms.ecms.service;

import uk.nhs.cfsms.ecms.dto.caseInfo.InvestigationTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface InvestigationService {

	InvestigationTO loadInvestigationById(Long investigationId) throws ServiceException;

	InvestigationTO saveInvestigation(InvestigationTO dto) throws ServiceException;
	
	void updateInvestigation(InvestigationTO dto) throws ServiceException;

	void deleteInvestigation(InvestigationTO dto) throws ServiceException;
}
