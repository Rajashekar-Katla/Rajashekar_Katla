package uk.nhs.cfsms.ecms.service;

public interface EhcacheService {

	void resetGetCPSDocumentsNamingRulesCache();

	void resetDownloadCPSFileNamingRulesDocumentCache();

	void clearAllCacheEntries();
	
	void resetLoadClosedInformationReportsForIMO();

}
