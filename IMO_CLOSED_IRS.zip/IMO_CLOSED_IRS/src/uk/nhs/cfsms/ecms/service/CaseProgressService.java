package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseProgress;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface CaseProgressService extends BaseService {

	Long generateMinuteNumber(Long caseId) throws ServiceException;
	
	Long generateMinuteNumber(Long caseId, String caseType) throws ServiceException;

	List<CaseProgress> loadCaseProgresses(Long caseId) throws ServiceException;

	List<CaseProgress> loadCaseProgresses(Long caseId, String type)
			throws ServiceException;

	List<CaseProgress> loadCaseProgressesByCaseByMinutes(Long caseId,
			String type, int startMin, int endMin) throws ServiceException;

	List<CaseProgress> loadCaseProgresses(Long long1, String progressSheetType,
			String sensitivity) throws ServiceException;
 	
	CaseProgress loadCaseProgressById(Long caseProgressId) throws ServiceException;

	void deleteCaseProgress(Long caseProgressId) throws ServiceException;
}
