package uk.nhs.cfsms.ecms.service;

import java.util.List;

import org.dom4j.Document;

import uk.nhs.cfsms.ecms.data.cim.Interview;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface InterviewService extends BaseService {

	public List getInterviews(final Long caseId);

	public List getInterviewsUploaded(Long caseId);

	public List<Interview> getInterviewsForCPS(final Long caseId);

	public Interview loadInterview(Long interviewId);

	public Document transform(String stylesheet, Interview interview)
			throws ServiceException;

	public void deleteInterviewById(Long interviewId) throws ServiceException;

	public Interview updateInterviewFileName(final Long interviewId,
			final String fileName);

	public Long getInterviewFileSize(final long interviewId);

	public Interview downloadInterviewsForCPS(final Long interviewId,
			final boolean isFileBlobRequired);
}
