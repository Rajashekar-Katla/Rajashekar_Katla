package uk.nhs.cfsms.ecms.service;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.InformationProgress;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationProgressTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface InformationProgressService extends BaseService {

	Long generateMinuteNumber(Long informationId) throws ServiceException;

	List<InformationProgressTO> loadInformationProgresses(Long informationId)
			throws ServiceException, IllegalAccessException, InvocationTargetException;

	void saveInformationProgress(
			final InformationProgressTO informationProgressTO)
			throws ServiceException, IllegalAccessException,
			InvocationTargetException;
	
	String convertToInformationProgressListToJsonString(
			List<InformationProgressTO> informationProgressTOList)
			throws IOException;
	
}
