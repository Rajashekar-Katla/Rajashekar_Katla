package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.AppealOutcome;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppeal;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.PoliceCharge;
import uk.nhs.cfsms.ecms.dto.criminalsanction.CriminalAppealTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface CriminalAppealService extends BaseService {


	public CriminalAppealTO loadCriminalAppeal(Long appealId) throws ServiceException;
	
	public List<CriminalAppealTO> loadCriminalAppeals(Long caseId) throws ServiceException;

	public List<CriminalAppealTO> loadCriminalSanctionsForReport(Long caseId) throws ServiceException;
	
	public List<CriminalAppeal> loadAppealsByParentSanctionId(Long sanctionId) throws ServiceException;	
	 
	public void saveAppeal(CriminalAppealTO dto) throws ServiceException;
		
	public PoliceCharge loadPoliceCharge(Long sanctionId) throws ServiceException;

	public PoliceCharge savePoliceCharge(PoliceCharge charge) throws ServiceException;

	public AppealOutcome loadCriminalAppealOutcome(Long appealId) throws ServiceException;
	
	public CriminalSanctionOutcome loadCriminalSanctionOutcome(Long sanctionId) throws ServiceException;

	public AppealOutcome saveOutcome(AppealOutcome dto) throws ServiceException;

	public void deleteAppeal(Long appealId) throws ServiceException;
	
}
