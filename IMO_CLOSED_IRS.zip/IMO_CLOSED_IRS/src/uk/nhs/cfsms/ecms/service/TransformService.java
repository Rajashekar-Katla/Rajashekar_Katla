package uk.nhs.cfsms.ecms.service;

import org.dom4j.Document;

import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface TransformService {

	Document transform (String stylesheet, Document document) throws ServiceException;
	
}
