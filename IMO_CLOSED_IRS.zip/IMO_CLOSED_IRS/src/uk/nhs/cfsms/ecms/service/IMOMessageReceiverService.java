package uk.nhs.cfsms.ecms.service;

import java.util.Map;

public interface IMOMessageReceiverService {

	String getActiveStaffId();

	void activateUserToReceiveMessages(String staffId);
	
	Map<String, String> getAllIMOMessageReceivers();
}
