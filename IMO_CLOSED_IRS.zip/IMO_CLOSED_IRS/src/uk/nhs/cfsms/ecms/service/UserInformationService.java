package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.authentication.Users;
import uk.nhs.cfsms.ecms.data.common.UserHistory;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.common.UserPreference;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;

public interface UserInformationService {

	public UserObject loadUserByUserId(String staffId);
	
	public UserObject loadUserByUserIdForCPS(final String staffId);
	
	public List loadUsersByGroups(String userGroups[]);
	
	public Users getUserNamePassword(String userId);

	public List loadUserAccessListByAccessLevel(String aclLevel);
	
	public UserHistory loadUserHistory(String staffId);

	public void createUserHistory(UserHistory history);

	public void updateUserHistory(UserHistory history);
	
	public UserPreference loadUserPrefereces(String staffId);
	
	public void updateUserPreferences(UserPreference preference);
	
	public List<String> searchUsers(String userSearchPattern);
	
	public List searchUsers(String userSearchPattern ,SessionUser user, String caseId);
	
	public String getStaffNHSEmailAddress(final String staffId);
	
	public String getStaffNHSEmailAddressFromCPOD(final String staffId);
}
