package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.Vehicle;

public interface VehicleService extends BaseService {
	
	
	List<Vehicle> loadVehicles(Long caseID);
	
	void saveAllVehicles(List<Vehicle> vehicles);
	
	void saveVehicle(Vehicle vehicle);

	List<Vehicle>loadVehiclesByInformation(Long informationId);
	
	Vehicle getVehicle(Long vehicleId);
	
	void deleteVehicle(Vehicle vehicle);
}
