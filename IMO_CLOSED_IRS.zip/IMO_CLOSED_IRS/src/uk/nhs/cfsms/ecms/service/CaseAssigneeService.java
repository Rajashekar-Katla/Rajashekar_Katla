package uk.nhs.cfsms.ecms.service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseAssigneeTO;
import uk.nhs.cfsms.ecms.data.cim.CasePermission;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.dto.user.UserObjectTo;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface CaseAssigneeService {
	
	
	public List<UserObject> loadUsers(Long caseId,String staffId) throws ServiceException;
	
	public void  deletCaseAssignee(Long  permissionId) throws ServiceException;
	
	public CaseAssigneeTO saveCaseAssignee(CaseAssigneeTO assignee) throws ServiceException;
	
	public List<CaseAssigneeTO> loadAssigneeByCaseId(Long caseId) throws ServiceException;
	
	public CaseAssigneeTO loadAssigneeByPermissionId(Long permissionId) throws ServiceException;
	
	public CasePermission loadCasePermission(Long permissionId) throws ServiceException;

	public CasePermission upddateCasePermission(CasePermission permission) throws ServiceException;
	
	public List<UserObjectTo> loadUsersByTeamCodes(String[] teamCodes,Long caseId) throws ServiceException, IllegalAccessException, InvocationTargetException;
	
	public List<UserObjectTo> loadNewAssigneesByCaseOrgCode(Long caseId, List<String> currentAssignees) throws IllegalAccessException, InvocationTargetException;
	
	
}
