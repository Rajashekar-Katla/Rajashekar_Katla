package uk.nhs.cfsms.ecms.service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionOutcome;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionTO;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealOutcomeTO;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealTO;
import uk.nhs.cfsms.ecms.dto.civilsanction.CivilAppealsAndOutcomes;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface CivilSanctionService extends BaseService {

	public List<CivilSanctionTO> loadCivilSanctions(Long caseId) throws ServiceException;
		
	public  CivilSanctionOutcome loadCivilSanctionOutcome(Long civilSanctionId);
	
	public Map<String, List> loadSanctionsAndAppeals(Long caseId) ;
	
	public List<CivilAppealTO> loadCivilAppealsForCase(Long caseId) ;
	
	public CivilAppealTO  loadCivilAppeal(Long appealID) throws  Exception;
	
	public List<CivilSanctionTO> loadCivilSanctionsForReport(Long caseId) throws ServiceException;

	public CivilAppealsAndOutcomes getAppealsAndOuctomesForCase(Long caseID)
			throws IllegalAccessException, InvocationTargetException;

	public CivilAppealOutcomeTO loadCivilAppealOutcome(Long appealID) throws Exception;

	public CivilAppealTO loadCivilAppeal(CivilAppealTO appealTO) throws Exception; 
	
	public List<CivilAppealOutcomeTO> loadAppealOutcomeForCivilSanctionId(Long civilSanctionId) throws Exception;
	
	public void saveAppeal(CivilAppealTO appealTO) throws Exception;
		
	public void deleteCivilAppeal(Long appealId) throws ServiceException;
	
}
