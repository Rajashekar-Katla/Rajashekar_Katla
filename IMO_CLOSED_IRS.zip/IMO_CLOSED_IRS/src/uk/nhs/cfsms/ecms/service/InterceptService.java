package uk.nhs.cfsms.ecms.service;

import uk.nhs.cfsms.ecms.dto.user.SessionUser;

public interface InterceptService {
	
	public boolean authorizeUserByACL(SessionUser user, Long interceptId);
	
}
