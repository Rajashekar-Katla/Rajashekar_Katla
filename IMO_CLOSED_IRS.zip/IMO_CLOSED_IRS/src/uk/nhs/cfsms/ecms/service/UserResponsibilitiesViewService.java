package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.AllUserResponsibilities;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;

public interface UserResponsibilitiesViewService {

	public List<AllUserResponsibilities> loadResponsibilitiesById(String staffId);

	public List<UserDirectorate> getDirectorates(String staffID);
}
