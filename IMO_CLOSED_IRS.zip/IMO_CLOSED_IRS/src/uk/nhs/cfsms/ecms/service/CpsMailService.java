package uk.nhs.cfsms.ecms.service;

import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import uk.nhs.cfsms.ecms.dto.cps.CpsMailDto;

public interface CpsMailService {

	public Long save(final CpsMailDto cpsMailDto)
			throws IllegalAccessException, InvocationTargetException;

	public List<CpsMailDto> getCpsMailDetails(final long caseID);

	public CpsMailDto getCpsMailDetailsByDate(Date fromDate, Date toDate);

	public Timestamp isDocumentSent(final String docGrpID);

	public void delete(final Long cpsMailID);

	public Long getFileSize(final long documentID, final String category);

}
