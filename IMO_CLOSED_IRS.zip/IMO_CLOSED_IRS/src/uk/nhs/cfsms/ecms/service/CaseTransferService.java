package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.cim.CaseTransfer;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.InfoTransferHistory;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTransferTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InfoTransferHistTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface CaseTransferService{
	
	public CaseTransferTO saveCaseTransfer(CaseTransferTO caseTransfer) throws ServiceException;
	
	public CaseTransferTO updateCaseTransfer(CaseTransferTO caseTransfer) throws ServiceException;
	
	public CaseTransferTO loadCaseTransfersById(Long transferId) throws ServiceException;
		
	public List<CaseTransfer> loadReceivedLcfsTransfersByUserId(String staffId) throws ServiceException;
	
	public List<CaseTransfer> loadReceivedCfsTransfersByUserId(String staffId) throws ServiceException;
	
	public List<CaseTransfer> loadCreatedLcfsTransfersByUserId(String staffId) throws ServiceException;
	
	public List<CaseTransfer> loadCreatedCfsTransfersByUserId(String staffId) throws ServiceException;
	
	public List<CaseTransfer> loadApprovalPendingLcfsTransfersByUserId(String staffId) throws ServiceException;
	
	public List<CaseTransfer> loadApprovalPendingCfsTransfersByUserId(String staffId) throws ServiceException;
	
	public List<CaseTransfer> loadCaseLcfsTransfersByCaseId(Long caseIDLong)  throws ServiceException;
	
	public List<CaseTransfer> loadCaseCfsTransfersByCaseId(Long caseIDLong)  throws ServiceException;

	public Case loadCaseByCaseId(Long caseId) throws ServiceException;
		
	public List<UserObject> loadLcfsUsers(String teamCode) throws ServiceException;
	
	public List<Organisation> loadTeams() throws ServiceException;
	
	public List<CaseTransfer> loadPendingTransfersByCaseId(Long caseId) throws ServiceException;
	
	public CaseTransferTO saveAcceptCaseTransfer(CaseTransferTO caseTransferTO,SessionUser user) throws ServiceException;
	
	public List<InfoTransferHistTO> loadApprovalPendingInformationTransfersByUserId(String staffId) throws ServiceException;
	
	
}