package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.dto.caseInfo.AppealHearingTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface AppealHearingService extends BaseService {
 
	public List<AppealHearingTO> loadCourtAppearancesByType(
			Long sanctionId, String sanctionType) throws ServiceException; 
	
	public AppealHearingTO loadCourtAppearanceById(Long apprearanceId) throws ServiceException; 
	
	public AppealHearingTO saveAppealHearing(AppealHearingTO appealHearing) throws ServiceException; 

	public AppealHearingTO updateAppealHearing(AppealHearingTO appealHearing) throws ServiceException; 
	
	public void deleteAppealHearing(AppealHearingTO appealHearing) throws ServiceException;

	public AppealHearingTO updateCivilAppealHearing(AppealHearingTO appealHearing) throws ServiceException; 
	
}
