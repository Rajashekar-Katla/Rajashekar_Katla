package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.UserDirectorate;
import uk.nhs.cfsms.ecms.dto.search.SearchResultsTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;

public interface IndexedSearchService {

	public SearchResultsTO getCaseIndexedSearchResults(String keywords,
			SessionUser user);

	public List<SearchResultsTO> getInformationIndexedSearchResults(
			String keywords, String staffId, boolean regionalCode,
			boolean orgCode, List<UserDirectorate> directorates,
			String[] responsibilites);

	public SearchResultsTO getCaseSearchResultDetails(Long searchId,
			Long caseId, SessionUser user);

	public SearchResultsTO getInformationIndexedSearchResults(
			String searchKeywordsParam, SessionUser user);

	public SearchResultsTO getInformationSearchDetails(Long curSearchId,
			Long curInfoId, SessionUser user);

}
