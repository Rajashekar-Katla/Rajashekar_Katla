package uk.nhs.cfsms.ecms.service;

import java.text.ParseException;
import java.util.Collection;
import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseActionBookAttachment;
import uk.nhs.cfsms.ecms.dto.search.ActionSearchTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.model.CaseActionBookAttachmentTO;
import uk.nhs.cfsms.ecms.model.CaseActionBookTO;
import uk.nhs.cfsms.ecms.model.CaseActionFilterCriteria;

public interface CaseActionBookService {
	
	/** 
	 * This method is responsible for saving the state of object by calling DAO layer of ActionBook.
	 * 
	 * @param caseActionBook
	 * 
	 * @return CaseActionBook
	 * @throws ServiceException 
	 * */
	public CaseActionBookTO saveCase(CaseActionBookTO caseActionBook) throws ServiceException;

	/** 
	 * This method is responsible for loading the state of object by calling DAO layer of ActionBook.
	 * 
	 * @param actionID
	 * 
	 * @return CaseActionBook
	 * @throws ServiceException 
	 * */
	public CaseActionBookTO loadCaseActionBook(Long actionID) throws ServiceException;

	/** 
	 * This method is responsible for updating the state of object by calling DAO layer of ActionBook.
	 * 
	 * @param caseActionBook
	 * 
	 * @return CaseActionBook
	 * @throws ServiceException
	 * */
	public CaseActionBookTO saveOrUpdate(CaseActionBookTO caseActionBook) throws ServiceException;

	/** 
	 * This method is responsible for for generating a new Action Number for a given case ID by calling DAO layer of ActionBook.
	 * 
	 * @param caseActionBook
	 * @param caseID
	 * 
	 * @return String
	 * @throws ServiceException 
	 * */
	public String generateCaseActionBookNumber(Long caseID) throws ServiceException;

	
	/** 
	 * This method is responsible for loading a list of all case action Books for the given case ID
	 *  by calling DAO layer of ActionBook.
	 * 
	 * @param caseID
	 * 
	 * @return CaseActionBook
	 * @throws ServiceException
	 * */
	public Collection<CaseActionBookTO> loadAllCaseActionBook(String caseID)throws ServiceException;
	
	/** 
	 * This method is responsible for loading a list of object, with in the given starting and ending range of action Book Number
	 * for a given case ID, by calling DAO layer of ActionBook.
	 * 
	 * @param caseID
	 * @param startingActionID
	 * @param endingActionID
	 * 
	 * @return Collection<CaseActionBook>
	 * @throws ServiceException 
	 * */
	public Collection<CaseActionBookTO> loadAllCaseActionBook(String caseID,String startingActionID, String endingActionID)throws ServiceException;


	/** 
	 * This method is responsible for loading a list of all case action Books for the given case ID
	 *  by calling DAO layer of ActionBook.
	 * 
	 * @param caseID
	 * @param actionStatus
	 * 
	 * @return CaseActionBook
	 * @throws ServiceException
	 * */
	public Collection<CaseActionBookTO> loadAllCaseActionBook(String caseID, String actionStatus)throws ServiceException;
	
	/** 
	 * This method is responsible for loading a list of object, with in the given starting and ending range of action Book Number
	 * for a given case ID, by calling DAO layer of ActionBook.
	 * 
	 * @param caseID
	 * @param startingActionID
	 * @param endingActionID
	 * @param actionStatus
	 * 
	 * @return Collection<CaseActionBook>
	 * @throws ServiceException 
	 * */
	public Collection<CaseActionBookTO> loadAllCaseActionBook(String caseID,String startingActionID, String endingActionID, String actionStatus)throws ServiceException;

	public String getUserFullName(String userID);
	//public List<UserObject> loadUsersToAllocate(String[] responsbilityCodes, Long caseId);
	
	/**
	 * Fetching the list of all attachments for a given action ID.
	 * 
	 * */	
	public List<CaseActionBookAttachment> listAttachments(Long actionID);
	
	/**
	 * Saving a new attachment through DAO layer.
	 * 
	 * */	
	public void saveCaseActionBookAttachment(CaseActionBookAttachment caseActionBookAttachment);
	
	/**
	 * Saving a new attachment through DAO layer.
	 * 
	 * */	
	public CaseActionBookAttachment downloadCaseActionBookAttachment(String attachmentID);
	
	public CaseActionBookAttachment loadCaseActionBookAttachment(final String attachmentID);

	/**
	 * Saving a new attachment through DAO layer.
	 * 
	 * */	
	public String getCaseActionBookAttachmentNumber(Long actionID);
	
	/** 
	 * This method is responsible for loading the CaseActionBook Model object by calling DAO layer of ActionBook.
	 * 
	 * @param noOfDays
	 * 
	 * @return List<CaseActionBookTO>
	 * @throws ServiceException 
	 * @throws ParseException 
	 * */
	public List<CaseActionBookTO> loadDueCaseActionBook(int noOfDays) throws ServiceException, ParseException;
	
	public ActionSearchTO getActionSearchResults(ActionSearchTO searchTO, SessionUser user) throws ServiceException;
	
	
	/** 
	 * This method is responsible for loading a list of object, for a given filter Criteria.
     *
	 * @param filter
	 * @return Collection<CaseActionBook>
	 * @throws ServiceException 
	 * */
	public Collection<CaseActionBookTO> loadCaseActionBook(CaseActionFilterCriteria filter)throws ServiceException;

	/**
	 * Fetching the list of all attachments MODEL class for a given action ID .
	 * 
	 * */
	public List<CaseActionBookAttachmentTO> listAttachmentsWithUserName(Long actionID);
	
	/**
	 * Fetching the list of all attachments in All ActionBook for a given case ID.
	 * This is being used is CPS document list to list all the action book attachments
	 * for a given case ID.
	 * 
	 * @param Long caseID
	 * @return List<CaseActionBookAttachment> 
	 * 
	 * */
	public List<CaseActionBookAttachment> listAllAttachments(Long caseID);
	
	public String getActiveIMOMessageReceiverStaffId();
	
	public String getActiveCIUMessagesReceiverStaffId();
}


