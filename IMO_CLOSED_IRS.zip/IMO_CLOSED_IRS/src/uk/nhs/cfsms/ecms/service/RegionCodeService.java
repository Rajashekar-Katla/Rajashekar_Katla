package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.RegionCode;

public interface RegionCodeService {

	public List<RegionCode> loadAllRegionCode();
	
}
