package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.MGForm;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.dto.mgforms.MGFormTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface MGFormService {
	
	public List<MGForm>  listMGForms(Long caseId) throws ServiceException;
	
	public List<MGForm> listMGFormsForCPS(Long caseId) throws ServiceException;
	
	public void  deleteMGForms(Long mgFormId) throws ServiceException;
	
	public MGFormTO  saveMGForm(MGFormTO mgForm) throws ServiceException;
	
	public MGForm  loadMgForm(Long mgFormId) throws ServiceException;
	
	public MGForm downloadMgForm(final Long mgFormId,final boolean isFileBlobRequired) throws ServiceException;
	
	public List<LookupView> loadMGFormTypes(String groupName) throws ServiceException;
	
	public String loadRegexForDocumentType(String docType);
	
	public MGFormTO updateMGFormFileName(final Long mgFormId,final String fileName) throws ServiceException;
	
	public Long getMGFormFileSize(final long mgFormId);

}
