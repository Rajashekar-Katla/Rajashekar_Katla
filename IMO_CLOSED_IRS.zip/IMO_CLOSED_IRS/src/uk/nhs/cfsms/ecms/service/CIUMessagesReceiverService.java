package uk.nhs.cfsms.ecms.service;

import java.util.Map;

public interface CIUMessagesReceiverService {

	String getActiveStaffId();

	void activateUserToReceiveMessages(String staffId);

	Map<String, String> getAllCIUMessagesReceivers();
}
