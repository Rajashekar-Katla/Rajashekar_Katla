package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppeal;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealView;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionOffence;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionView;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealHearingTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealOutcomeTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealSanctionTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryAppealTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryHearingTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryOffenceTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinaryOutcomeTO;
import uk.nhs.cfsms.ecms.dto.disciplinarysanction.DisciplinarySanctionTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface DisciplinarySanctionService extends BaseService {
	
	public List<DisciplinarySanctionView> loadSanctionViewListByCaseId(Long caseId) throws ServiceException ;
	
	public DisciplinarySanctionTO loadDisciplinarySanction(Long sanctionId) throws ServiceException;

	public List<DisciplinarySanctionTO> loadDisciplinarySanctionList() throws ServiceException;
	
	public List<CaseContact> loadContactsByCaseId(Long caseId) throws ServiceException;

	public void saveDisciplinarySanction(DisciplinarySanctionTO dispTO) throws ServiceException;
	
	public void saveDisciplinaryAppeal(DisciplinaryAppealTO dispTO) throws ServiceException;
	
	public void saveDisciplinaryOffence(DisciplinaryOffenceTO dispTO) throws ServiceException;

	public void saveDisciplinaryOutcome(DisciplinaryOutcomeTO dispTO) throws ServiceException;

	public List<DisciplinarySanctionHearing> loadDisciplinaryHearingList(Long sanctionId) throws ServiceException;
		
	public List<DisciplinarySanctionOffence> loadDisciplinaryOffenceList(Long sanctionId) throws ServiceException;	
	
	public List<DisciplinarySanctionOutcome> loadDisciplinaryOutcomeList(Long sanctionId) throws ServiceException;

	public void saveDisciplinaryHearing(DisciplinaryHearingTO dispTO) throws ServiceException;
	
	public DisciplinaryHearingTO loadDisciplinaryHearing(Long hearingId) throws ServiceException;
		
	public List<DisciplinarySanctionTO> loadSanctionsByCaseId(Long id)	throws ServiceException ;
	
	public DisciplinaryAppealHearingTO loadDisciplinaryAppealHearing(Long hearingId) throws ServiceException;

	public DisciplinaryOffenceTO loadDisciplinaryOffence(Long sanctionId) throws ServiceException;
	
	public DisciplinaryOutcomeTO loadDisciplinaryOutcomeBySanctionId(Long sanctionId) throws ServiceException;
	
	public DisciplinaryOutcomeTO loadDisciplinaryOutcome(Long outcomeId) throws ServiceException;

	public void deleteDisciplinarySanction(Long id) throws ServiceException;

	public void deleteDisciplinaryHearing(Long id) throws ServiceException;

	public void deleteDisciplinaryOutcome(Long id) throws ServiceException;
	
	public List<LookupView> loadSanctionImposedTypes(final String sanctionType) throws ServiceException;
	
	public void saveDisciplinaryAppealHearing(DisciplinaryAppealHearingTO dispTO) throws ServiceException;

	public List<DisciplinaryAppealView> loadAppealViewListByCaseId(Long caseId) throws ServiceException ;

	public DisciplinaryAppealTO loadDisciplinaryAppeal(Long appealId) throws ServiceException;
	
	public DisciplinaryAppealView loadAppealViewByAppealId(Long appealId) throws ServiceException;
	
	public DisciplinaryAppealTO loadDisciplinaryAppealByParentAppealId(Long sanctionId) throws ServiceException;
	
	public void saveDisciplinaryAppealOutcome(DisciplinaryAppealOutcomeTO dispTO) throws ServiceException;

	public List<DisciplinaryAppealHearing> loadDisciplinaryAppealHearingList(Long sanctionId) throws ServiceException;

	public void deleteDisciplinaryAppeal(Long id) throws ServiceException;

	public void deleteDisciplinaryAppealHearing(Long id) throws ServiceException;
	
	public List<DisciplinaryAppealTO> loadAppealsListByCaseId(Long id)	throws ServiceException ;

	public DisciplinaryAppealOutcomeTO loadAppealOutcomeByAppealId(Long appealId) throws ServiceException;
	
	public List<DisciplinaryAppeal> loadAppealsByParentSanctionId(Long sanctionId) throws ServiceException;

	public List<DisciplinaryAppeal> loadAppealsByParentAppealId(Long appealId) throws ServiceException;

	public List<DisciplinaryAppealSanctionTO> getAppealAndSanctionList(Long caseIdL) throws ServiceException;

	public DisciplinaryAppealTO loadDisciplinaryAppealByParentSanctionId(Long parentId)throws ServiceException;

}
