package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.Message;
import uk.nhs.cfsms.ecms.data.cim.MessageView;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface MessageService {

	public MessageTO saveMessage(MessageTO message) throws ServiceException;

	public MessageTO loadMessage(Long messageId) throws ServiceException;

	public List<Message> loadMessagesByToStaffId(String staffId, String state)
			throws ServiceException;

	public List<Message> loadMessagesByFromStaffId(String staffId, String state)
			throws ServiceException;

	public MessageTO updateMessage(MessageTO message, boolean rejectCaseClosure)
			throws ServiceException;

	public UserObject loadOFMByTeamOrOrgCode(String teamOrgCode,
			boolean hasOrgCode) throws ServiceException;

	public UserObject loadAFLByTeamCode(String teamCode)
			throws ServiceException;

	public InformationView loadInformationViewById(Long informationId)
			throws ServiceException;

	public UserObject loadUserByUserId(String staffId) throws ServiceException;

	/**
	 * NHS Restructure changes
	 * 
	 * @param user
	 * @param state
	 * @return
	 * @throws ServiceException
	 */
	public List<MessageView> loadMessagesByToStaffId(SessionUser user,
			String state) throws ServiceException;

	public MessageView loadMessageView(Long messageId) throws ServiceException;

	/**
	 * Phase 4 after 5(Restructure)
	 * 
	 * @param caseId
	 * @return
	 */
	public List<Message> loadMessagesByCaseId(Long caseId)
			throws ServiceException;

	public List<Message> loadMessagesByInfoId(Long informationId)
			throws ServiceException;

	public InformationView loadInformationViewByCaseId(Long caseId);

	public List<MessageView> loadMessagesByFromStaffId(SessionUser user)
			throws ServiceException;

	public MessageTO updateInfoMessage(MessageTO message,
			boolean rejectInfoClosure) throws ServiceException;

	/**
	 * This service method is responsible for fetching the trashed read messaged
	 * using message DAO for the given Session User.
	 * 
	 * @param sessionStaff
	 * @param msgState
	 * 
	 * @return List<MessageView>
	 * 
	 * **/

	public List<MessageView> loadTrashMessagesByToStaffID(
			SessionUser sessionStaff, String msgState);

	/**
	 * This service method is responsible for fetching the trashed sent message
	 * using Message DAO for the given Session User.
	 * 
	 * @param sessionStaff
	 * 
	 * @return List<MessageView>
	 * 
	 * **/

	public List<MessageView> loadTrashMessagesByFromStaffID(
			SessionUser sessionStaff);

	/**
	 * This method is responsible for updating the Case closure acceptance and
	 * triggering the message. for the concern AFS/LCFS Users.
	 * 
	 * @param MessageTO
	 * @param boolean
	 * 
	 * @return MessageTO
	 * 
	 **/
	public MessageTO updateAcceptedCaseClosureMessage(MessageTO message,
			boolean acceptCaseClosure) throws ServiceException;

	public void forwardMsgsToIMOMember(final String staffName, final String staffId, final String msgIds);
}
