package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseCourtCosts;
import uk.nhs.cfsms.ecms.data.cim.ExpectedCourtCost;
import uk.nhs.cfsms.ecms.data.cim.SoiCosts;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface SoiCostService {
	
	public SoiCosts saveSoiCosts(SoiCosts soicost) throws ServiceException;
	
	public SoiCosts loadSoiCosts(Long costId) throws ServiceException;
	
	public SoiCosts loadSoiCostsByCaseId(Long caseId) throws ServiceException;
	
	public SoiCosts updateSoiCosts(SoiCosts soicost) throws ServiceException;
	
	public List<CaseCourtCosts> saveCourtCosts(List<CaseCourtCosts> courtCost,Long caseID) throws ServiceException;
	
	public List<CaseCourtCosts> loadCourtCaseCostsByCaseId(Long caseId) throws ServiceException;
	
	public List<ExpectedCourtCost> loadExpectedCourtCosts() throws ServiceException;
	

}
