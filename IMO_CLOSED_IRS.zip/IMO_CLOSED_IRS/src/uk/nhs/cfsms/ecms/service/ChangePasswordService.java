package uk.nhs.cfsms.ecms.service;

import uk.nhs.cfsms.ecms.data.authentication.Users;
import uk.nhs.cfsms.ecms.data.common.UserHistory;


public interface ChangePasswordService {

	public boolean changePassword(String userId, String password);

	public Users loadUser(String userId);
	
	public void updateUserHistory(UserHistory history);

	public UserHistory loadUserHistory(String staffId);
}
