package uk.nhs.cfsms.ecms.service;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.ClosedInformationView;
import uk.nhs.cfsms.ecms.data.infoGath.FcrolInformationView;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SubjectName;
import uk.nhs.cfsms.ecms.dto.infoGath.InfoTransferHistTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationDetails;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationViewTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

	
public interface InformationGatherService {
	
	public InformationTO saveInformationDetails(InformationDetails details, SessionUser user);
	
	public InformationDetails createFraudDetailsTO();
	
	public InformationDetails loadInformationById(Long informationId) throws IllegalAccessException, InvocationTargetException, ServiceException, IOException;
	
	public InformationTO loadInformationTOById(Long informationId);

	public List<InformationViewTO> loadAllInformationView(SessionUser user) throws IllegalAccessException, InvocationTargetException;

	public void saveInformation(InformationTO info, SessionUser user);

	public InformationTO loadInformationByCaseId(Long caseId);
	
	public InformationTO loadInformationByCaseId(Long caseId, boolean isCasePersonsOnly);

	public InformationTO saveCaseInformation(InformationTO info, SessionUser user);

	public List<InformationView> loadTopInformationView(SessionUser user, Integer count);
	
	public boolean isFPUSystemWeakness(Long informationId);
	
	public boolean checkAccessToInformation(Long infoId, SessionUser user, boolean state);

	public UserObject getOwnerDetailsByInfoId(Long infoId);
	
	public InformationDetails loadFcrolInformationById(Long informationId);
		
	public List<FcrolInformationView> loadFcrolInformationView();
	
	public void saveFcrolInformation(String userId,String teamCode,Long infoId,String regOverride,String orgCode);
	
	public void rejectFcrolInformation(Long infoId,String rejectStaffId,String rejectInfo);

	public void updateSubjectToWitness(InformationTO info, SessionUser user, String subjectId );

	public List<ClosedInformationView> loadClosedInformationView(SessionUser user, String createdByFilter);

	public List<InformationView> loadMyTeamsInformationView(SessionUser user);

	/**
	 * Loading information history and returning the Information transfer Object
	 * @throws ServiceException 
	 */	
	public InfoTransferHistTO loadInformationHistory(Long InfoId) throws ServiceException;
	
	public InfoTransferHistTO loadInformationHistoryByApprover(Long infoId, String staffId) throws ServiceException;
		
	List<SubjectName> getAllSubjects(String caseId);
	
//	public void deleteThreeYearsOldClosedInformation();
	
	public List<InformationViewTO> load_LCFS_Other_InformationReports(
			final SessionUser user) throws IllegalAccessException, InvocationTargetException;
	
	public List<ClosedInformationView> loadClosedInformationReportsForIMO(SessionUser user) throws IllegalAccessException, InvocationTargetException;
}