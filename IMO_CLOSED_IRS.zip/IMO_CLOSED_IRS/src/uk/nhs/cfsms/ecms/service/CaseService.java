package uk.nhs.cfsms.ecms.service;

import java.util.List;
import java.util.Map;

import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.cim.CaseObject;
import uk.nhs.cfsms.ecms.data.cim.CaseSummaryInformation;
import uk.nhs.cfsms.ecms.data.cim.CaseUpdate;
import uk.nhs.cfsms.ecms.data.cim.InformationObject;
import uk.nhs.cfsms.ecms.data.cim.InvestigationPlan;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.OrganisationTeamCode;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.fpureport.FpuReport;
import uk.nhs.cfsms.ecms.data.infoGath.InfoTransferHistory;
import uk.nhs.cfsms.ecms.data.infoGath.Information;
import uk.nhs.cfsms.ecms.data.infoGath.InformationPermission;
import uk.nhs.cfsms.ecms.data.infoGath.Person;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseClosureTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.search.CaseSearchFormTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface CaseService {

	/*
	 * Collect data and save the Case object then set permissions and then save
	 * the permissions
	 * 
	 * @param caseTO Case transfer object 
	 * @param user Session User object.
	 * @param teamCode Team Code 
	 * @param staffId allocated staff Id. 
	 * @return CaseTO Case Transfer Object.
	 * 
	 */
	public CaseTO saveCase(CaseTO caseTO, SessionUser user, String teamCode,
			String staffId) throws ServiceException;

	public CaseTO saveHoldCase(CaseTO caseInfo, SessionUser sessionUser)
			throws ServiceException;

	public List loadUsersByGroups(String[] userGroup);

	public Map<String, List<UserObject>> loadUsersByTeamCodeAndGroups(
			String teamCode);

	public List<CaseObject> loadCases(boolean regionalCode, boolean orgCode,
			List<UserDirectorate> directorates, String[] responsibilites);

	public List<CaseObject> loadRegionalCases(
			List<UserDirectorate> directorates, String[] responsibilites);

	public List<CaseObject> loadAssignedCases(SessionUser user);

	public List<CaseObject> loadCases();

	public CaseTO loadCase(Long id) throws ServiceException;

	public Case saveOrUpdate(CaseTO caseTo) throws ServiceException;

	public OrganisationTeamCode loadTeamCodeByOrgCode(String org_code);

	public Information updateTransferInformation(CaseTO caseTo,
			boolean discarded);

	public List<CaseObject> loadCases(boolean regionalCode, boolean overLoaded,
			String[] responsibilites);

	public List listTeamCodes();

	public InformationPermission updateInfoTransferToNewTeam(String newTeam,
			Long informationId, SessionUser user) throws ServiceException;

	public InformationPermission updateInfoPermissionToLCFS(String staffId,
			CaseTO caseInfo, SessionUser user);

	public CaseTO saveUserAllocatedHoldCase(CaseTO caseInfo, String sessionUser)
			throws ServiceException;

	public String generateCaseNumber(CaseTO caseTo) throws ServiceException;

	public CaseTO loadCaseByCaseNumber(String caseNum) throws ServiceException;

	public List<CaseContact> loadContactsByCaseId(Long caseId);

	public List<InvestigationPlan> loadInvestigationsByCaseId(Long caseId);

	public List<InvestigationPlan> loadFullInvestigationsByCaseId(Long caseId);

	public CaseClosureTO saveCaseClosure(CaseClosureTO caseClosureTO)
			throws ServiceException;

	public CaseClosureTO saveCaseClosureOnly(CaseClosureTO caseClosureTO)
			throws ServiceException;

	public CaseClosureTO loadCaseClosureByCaseId(Long caseId)
			throws ServiceException;

	public CaseClosureTO loadCaseClosureByCaseIdForCPS(final Long caseId)
			throws ServiceException;

	public CaseClosureTO downloadCaseClosureByCaseId(Long caseId)
			throws ServiceException;

	public CaseClosureTO updateCaseClosure(CaseClosureTO caseClosureTO)
			throws ServiceException;

	public Case saveCloseCase(Long caseId) throws ServiceException;

	public List<CaseObject> loadClosedCases(boolean regionalCode,
			boolean orgCode, List<UserDirectorate> directorates,
			String[] responsibilites);

	public List<LookupView> loadCaseClosureTypes() throws ServiceException;

	public FpuReport loadFpuReportByCaseId(Long caseId) throws ServiceException;

	public CaseSearchFormTO getCaseSearchResults(CaseSearchFormTO search,
			SessionUser user) throws ServiceException;

	public CaseSearchFormTO getGenericCaseSearchResults(
			CaseSearchFormTO search, SessionUser user) throws ServiceException;

	public CaseSummaryInformation loadCaseSummaryInformation(Long caseId)
			throws ServiceException;

	public void updateCaseSummaryInformation(CaseSummaryInformation summary)
			throws ServiceException;

	public Information saveTransferInfoFromCIU(CaseTO caseTo)
			throws ServiceException;

	public List<TeamCodes> listTeamsByTeamCode(String[] teams);

	public InfoTransferHistory updateOldAndAddNewInfoTransferHistory(
			Long infoId, String newTeamCode, SessionUser user)
			throws ServiceException;

	public boolean checkAccessToCase(Long caseId, SessionUser user);

	public UserObject getOwnerDetailsBycaseId(Long caseId);

	public Information rejectInformation(CaseTO caseTo, SessionUser user);

	public void saveInfoOnly(InformationObject info);

	public InformationObject loadInfoObjectOnly(Long infoId);

	public void saveRejectTransferInfo(SessionUser user,
			InformationObject info, String message) throws ServiceException;

	public void saveChangeCasePCT(String userId, String newPCT,
			boolean removeOldLCFS, String newLCFSAssignee, Long caseId)
			throws ServiceException;

	public List<String> loadSubjectsByCaseId(Long caseId);

	/**
	 * Save Case
	 * 
	 * @param caseInfo
	 * @param sessionUser
	 * @return
	 * @throws ServiceException
	 * @deprecated
	 */
	public CaseTO saveCase(CaseTO caseInfo, String sessionUser)
			throws ServiceException;

	public List<LookupView> loadNewCaseClosurePart1Types()
			throws ServiceException;

	public List<LookupView> loadNewCaseClosurePart2Types()
			throws ServiceException;

	public Map<String, List<UserObject>> loadNITUsersByGroups()
			throws ServiceException;

	public List<CaseObject> loadNITSCases(List<UserDirectorate> setDirectorate);

	public List<CaseObject> loadNITNCases(List<UserDirectorate> setDirectorate);

	public List<CaseObject> loadAwaitCases(
			List<UserDirectorate> setDirectorate, String[] responsibilites);

	public CaseTO reopenClosedCase(CaseTO caseTO, SessionUser user,
			String teamCode, String staffId, Boolean isClosedCase)
			throws ServiceException;

	public List<CaseUpdate> loadAllCaseUpdates(Long caseId)
			throws ServiceException;

	public Case saveOrUpdate(CaseTO caseTo, String staffId)
			throws ServiceException;

	/**
	 * Fetch user full name by User staffId
	 * */
	public String getUserFullName(String userID);

	/**
	 * This method will be responsible for storing the information transfer
	 * data.
	 * */
	public InfoTransferHistory updateInformationTransferHistory(Long infoId,
			String oldTeamCode, String newTeamCode, String staffId,
			MessageTO messageTo) throws ServiceException;

	public InformationPermission transferInfoPermissionsToNewTeam(Long infoId,
			String createdStaffID) throws ServiceException;;

	/**
	 * This method is responsible for triggering the message b/w sender and
	 * receiver, to update about acceptance and rejection of information
	 * transfer.
	 * 
	 * */
	public boolean prepareInformationTransferResponses(String approvalStatus,
			Long infoTransferId) throws ServiceException;

	/**
	 * To be used to enable information transfer through messaging.
	 * 
	 * This method is responsible for triggering the message b/w sender and
	 * receiver, to update about acceptance and rejection of information
	 * transfer.
	 * 
	 * */
	public boolean prepareReplyMessages(MessageTO messageTO,
			String approvalStatus, Long infoTransferId) throws ServiceException;

	/**
	 * This method is responsible for updating the information history table and
	 * triggering the various access flags.
	 * 
	 * */
	public Long updateInformationTransfer(Long infoID, String approvalStatus,
			String comments) throws ServiceException;

	/**
	 * This method is responsible for triggering system notification to the end
	 * user.
	 * 
	 * */
	public boolean triggerTransferNotification(Long infoTransferId)
			throws ServiceException;

	/**
	 * This method is responsible for providing the OFM details for the given
	 * case ID using the CAST DAO layer. This service method is being used in
	 * CPS Document Service layer as well.
	 * */
	public UserObject getOFMDetailsByCaseId(Long caseId);

	public String getApproverStaffIdForCPSDocsRequest();

	public String loadCPSURN(final Long caseID) throws ServiceException;

	public Person loadSubjectsByCaseIdForCps(final Long caseId);
	
	public String loadCaseNumber(final Long caseID) throws ServiceException;
}