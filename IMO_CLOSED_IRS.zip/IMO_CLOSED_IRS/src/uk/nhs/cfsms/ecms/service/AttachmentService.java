package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.Attachment;

public interface AttachmentService extends BaseService{
	
	public Attachment loadAttachment(Long AttachmentId);
	public List listAttachments(Long caseId);
	public List listInfoAttachments(Long infoId);
	public void saveAttachment(Attachment attachment);
	public void deleteAttachment(Long attachmentId);
}
