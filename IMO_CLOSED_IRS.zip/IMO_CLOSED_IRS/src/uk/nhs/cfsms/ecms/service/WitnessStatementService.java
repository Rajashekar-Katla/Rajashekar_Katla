package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.dto.witness.WitnessStatementTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface WitnessStatementService {

	public List loadCPSWitnesseStatementsByCaseID(Long caseId, String type);
	
	public List loadWitnesseStatementsByWitnessId(Long witnessId);

	public List loadWitnesseStatementsByCaseId(Long caseId,int partNumber, String type);

	public List loadStatementsByWitnessIdAndType(Long witnessId,int partNumber, String type);
	
	public WitnessStatementTO loadWitnessStatementById(Long statementId)
			throws ServiceException;
	
	public WitnessStatementTO downloadWitnessStatementById(final Long statementId,final boolean isFileBlobRequired)
			throws ServiceException;

	public WitnessStatementTO saveWitnessStatement(
			WitnessStatementTO witnessStatementTO) throws ServiceException;

	public WitnessStatementTO updateWitnessStatement(
			WitnessStatementTO witnessStatementTO) throws ServiceException;
	
	public WitnessStatementTO updateWitnessStatementFileName(final long witnessStatementId,final String  fileName) throws ServiceException;

	public void deleteWitnessStatement(Long statementId) throws ServiceException;
	
	public Long getWitnessStatementFileSize(final long witnessStatementId);

}
