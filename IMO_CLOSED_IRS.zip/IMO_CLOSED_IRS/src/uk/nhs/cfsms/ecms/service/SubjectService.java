package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.SubjectNhsSearchResults;
import uk.nhs.cfsms.ecms.data.cim.SubjectNonNhsSearchResults;
import uk.nhs.cfsms.ecms.data.cim.SubjectSearchResults;
import uk.nhs.cfsms.ecms.data.cim.VehicleSearchResults;
import uk.nhs.cfsms.ecms.data.infoGath.SubjectInformation;
import uk.nhs.cfsms.ecms.dto.infoGath.SubjectInformationTO;

public interface SubjectService {
	
	public SubjectInformation loadSubject(SubjectInformation subject);
	
	public SubjectInformation saveSubject(SubjectInformation subject);
	
	public SubjectInformation updateSubject(SubjectInformation subject);
	
	public void deleteSubject(SubjectInformation subject);
	
	public List<SubjectSearchResults> searchPersonSubjects(String firstName,String lastName);
	
	public List<SubjectNhsSearchResults> searchNHSSubjects(String name);
	
	public List<SubjectNonNhsSearchResults> searchNonNHSSubjects(String name);
	
	
	public List<VehicleSearchResults> searchVehicles(String licenseNumber);
	
	public SubjectInformationTO loadSubjectInformationByCaseId(final Long caseId);
	
	public SubjectInformation loadSubjectById(final long subjectId);

}
