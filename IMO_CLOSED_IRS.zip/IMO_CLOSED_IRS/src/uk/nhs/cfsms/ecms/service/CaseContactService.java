package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;

public interface CaseContactService {

	public CaseContactTO loadContactById(Long integer);

	public CaseContactTO saveContact(CaseContactTO contact);

	public void updateContact(CaseContactTO contact);

	public void deleteContact(CaseContactTO contact);

	public void updateCaseContactToSubject(CaseContactTO contactTO);

	public void updateCaseContactToWitness(CaseContactTO contactTO, String staffId);

	public List<CaseContactTO> loadContactsByInformation(Long informationId);
	
	public CaseContact findContactByIdForWitnessLookupUser(
			final Long contactId) ;
	
}
