package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.audit.AuditLogsCommand;
import uk.nhs.cfsms.ecms.audit.CustomTrackingRevisionEntity;
import uk.nhs.cfsms.ecms.audit.RevisionedEntityInfo;
import uk.nhs.cfsms.ecms.data.common.AuditLog;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

/**
 * Interface to interact with the audit log data access object class
 * @author Sukhraj Matharu
 *
 */
public interface AuditLogService {

	public final static String LOGGED_IN = "LOGGED IN";
	public final static String LOGGED_OUT = "LOGGED OUT";
	public final static String RESET_PWD = "RESET PASSWORD";
	public final static String DOWNLOAD = "DOWNLOAD";
	public final static String UPLOAD = "UPLOAD";

		
	public final static String CREATE = "CREATE";
	public final static String UPDATE = "UPDATE";
	public final static String DELETE = "DELETE";
	public static final String LOADING = "LOADING";
	
		
	/**
	 * Passes the audit log to the DAO class for saving 
	 * @param auditLog
	 */
	void save(AuditLog auditLog);	
	
	/**
	 * 
	 * @param properties a description of the action
	 * @param state the action for the audit 
	 * @param userId the user who action the event
	 * @param objectId the id of the object that was modified 
	 */
	void save(String properties, String state, String staffId, long objectId);
	
    /**
     * 
     * @param properties
     * @param state
     * @param action
     * @param staffId
     * @param objectId
     */  
    void save(String properties, String state, String action, String staffId,  long objectId);
    
    
    /**
     * 
     * @param objectClass
     * @param properties
     * @param state
     * @param action
     * @param staffId
     * @param objectId
     */
    void save(Class objectClass, String properties, String state, String action, String staffId,  long objectId);
    
    List<CustomTrackingRevisionEntity> getLogs(AuditLogsCommand command);
    
    List<AuditLog> getCaseLogsByCaseId(String caseId) throws ServiceException;
    
    List<CustomTrackingRevisionEntity> getCaseLogsById(String caseId);

	List<RevisionedEntityInfo> getAuditInfoForCaseAndRevision(Integer revId,
			Long caseId);

	List<RevisionedEntityInfo> getAuditInfo(AuditLogsCommand command);

	List<CustomTrackingRevisionEntity> getAuditDump(AuditLogsCommand command);
	
}
