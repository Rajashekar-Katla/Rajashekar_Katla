package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.Exhibit;
import uk.nhs.cfsms.ecms.data.cim.ExhibitDocuments;
import uk.nhs.cfsms.ecms.dto.exhibit.ExhibitViewTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface ExhibitService extends BaseService {

	List<Exhibit> loadExhibits(Long caseId);

	/**
	 * This service method is responsible for loading the case Exhibit for the
	 * given exhibit ID Which is basically in turn calling the exhibit DAO layer
	 * to get the results.
	 * 
	 * */
	public Exhibit loadExhibit(Long exhibitId);

	public List<ExhibitDocuments> loadExhibitsForCPS(final Long caseId);

	public boolean updateExhibitFileName(final Long exhibitId,
			final String fileName);

	public void updateExhibit(final Exhibit exhibit);

	public void deleteExhibit(Long exhibitId) throws ServiceException;

	public Long getExhibitFileSize(final Long exhibitId);

	public void saveExhibitDocuments(final ExhibitDocuments exhibitDocuments);

	public List<Exhibit> loadAllExhibitDocuments(final long caseId,
			final String exhibitType);

	public ExhibitViewTO downloadExhibit(final Long exhibitId,
			final String exhibitType);

	public ExhibitDocuments downloadExhibitDocument(final Long id);
	
	public void deleteExhibitDocument(final Long id) throws ServiceException;
	
}
