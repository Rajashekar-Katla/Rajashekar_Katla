package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;

public interface OrganisationService {

	public List<Organisation> loadOrganisationsByOrgName(String keyword);
	
	public Organisation loadOrganisationByOrgCode(String orgCode);

	public List<Organisation> loadOrganisationsByOrgName(String keyword, String staffId);

	public List<Organisation> loadOrganisationsByOrgName(String keyword, SessionUser user);
	
	public List<TeamCodes> loadAllTeamCodes();
}
