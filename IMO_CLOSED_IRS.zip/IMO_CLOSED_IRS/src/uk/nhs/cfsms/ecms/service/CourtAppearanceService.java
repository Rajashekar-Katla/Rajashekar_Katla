package uk.nhs.cfsms.ecms.service;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;
import uk.nhs.cfsms.ecms.dto.caseInfo.CourtAppearanceTO;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface CourtAppearanceService extends BaseService {

	public List<CourtAppearance> loadCourtAppearancesBySanctionId(Long sanctionId) throws ServiceException;
	
	public List<CourtAppearance> loadCourtAppearancesByType(
			Long sanctionId,String sanctionType) throws ServiceException; 
	
	public CourtAppearanceTO loadCourtAppearanceById(Long apprearanceId) throws ServiceException; 
	
	public CourtAppearanceTO saveCourtAppearance(CourtAppearanceTO courtAppearance) throws ServiceException; 

	public CourtAppearanceTO updateCourtAppearance(CourtAppearanceTO courtAppearance) throws ServiceException; 
	
	public void deleteCourtAppearance(CourtAppearanceTO courtAppearance) throws ServiceException; 
	
}
