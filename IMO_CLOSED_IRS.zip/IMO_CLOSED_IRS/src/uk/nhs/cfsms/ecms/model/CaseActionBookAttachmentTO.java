package uk.nhs.cfsms.ecms.model;

import java.util.Date;

public class CaseActionBookAttachmentTO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = 1L;

	private Long actionAttachmentID;

	private Long attachmentNumber;

	private Long actionID;

	private String attachmentName;

	private String attachmentType;

	private byte[] attachmentBlob;

	private Date creationDateTime;

	private String createdBy;
	
	private String createdByFullName;

	private String sensitive;

	private String markAsDeleted;
	
	private String attachmentDescription;

	
	public Long getActionAttachmentID() {
		return actionAttachmentID;
	}

	public void setActionAttachmentID(Long actionAttachmentID) {
		this.actionAttachmentID = actionAttachmentID;
	}

	public Long getAttachmentNumber() {
		return attachmentNumber;
	}

	public void setAttachmentNumber(Long attachmentNumber) {
		this.attachmentNumber = attachmentNumber;
	}

	public Long getActionID() {
		return actionID;
	}

	public void setActionID(Long actionID) {
		this.actionID = actionID;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public byte[] getAttachmentBlob() {
		return attachmentBlob;
	}

	public void setAttachmentBlob(byte[] attachmentBlob) {
		this.attachmentBlob = attachmentBlob;
	}

	public Date getCreationDateTime() {
		return creationDateTime;
	}

	public void setCreationDateTime(Date creationDateTime) {
		this.creationDateTime = creationDateTime;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getSensitive() {
		return sensitive;
	}

	public void setSensitive(String sensitive) {
		this.sensitive = sensitive;
	}

	public String getMarkAsDeleted() {
		return markAsDeleted;
	}

	public void setMarkAsDeleted(String markAsDeleted) {
		this.markAsDeleted = markAsDeleted;
	}

	public String getAttachmentDescription() {
		return attachmentDescription;
	}

	public void setAttachmentDescription(String attachmentDescription) {
		this.attachmentDescription = attachmentDescription;
	}

	public String getCreatedByFullName() {
		return createdByFullName;
	}

	public void setCreatedByFullName(String createdByFullName) {
		this.createdByFullName = createdByFullName;
	}


}
