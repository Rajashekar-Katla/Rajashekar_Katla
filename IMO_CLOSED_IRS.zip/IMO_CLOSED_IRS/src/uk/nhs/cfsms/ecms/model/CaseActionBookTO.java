package uk.nhs.cfsms.ecms.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import uk.nhs.cfsms.ecms.data.cim.CaseActionBook;

public class CaseActionBookTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5190155072373623934L;

	private Long caseActionBookId;

	private Long actionNumber;

	private Long caseID;

	private Date dateRecorded;

	private String allocatedBy;

	private String sourceReference;

	private String actionRequired;

	private Date dateAllocated;

	private String allocatedTo;

	private String result;

	private String seenByOFM;

	private Date dateCompleted;

	private String sentivity;

	private Date dueDate;

	private String actionStatus;

	private String allocatedToStaffName;

	private String allocatedByStaffName;

	private String actionStatusAsText;

	private MultipartFile fileToUpload;

	private String attachmentComment;

	private String caseNumber;

	private String operationName;

	private String caseStatus;

	private String actionModel;
	
	private String empOrgCode;

	public CaseActionBookTO() {

	}

	public CaseActionBookTO(CaseActionBook cab, String caseNumber,
			String operationName, String caseStatus) {

		this.caseNumber = caseNumber;
		this.operationName = operationName;
		this.caseStatus = caseStatus;
		this.caseActionBookId = cab.getCaseActionBookId();
		this.caseID = cab.getCaseID();
		this.dateRecorded = cab.getDateRecorded();
		this.allocatedBy = cab.getAllocatedBy();
		this.sourceReference = cab.getSourceReference();
		this.actionRequired = cab.getActionRequired();
		this.dateAllocated = cab.getDateAllocated();

		this.allocatedTo = cab.getAllocatedTo();
		this.result = cab.getResult();
		this.seenByOFM = cab.getSeenByOFM();
		this.dateCompleted = cab.getDateCompleted();
		this.sentivity = cab.getSentivity();
		this.actionNumber = cab.getActionNumber();

		this.actionStatus = cab.getActionStatus();
		this.dueDate = cab.getDueDate();

		if (null != cab.getAllocatedToUser()) {
			this.allocatedToStaffName = cab.getAllocatedToUser().getFirstName()
					+ " " + cab.getAllocatedToUser().getLastName();
		}

		if (null != cab.getAllocatedByUser()) {
			this.allocatedByStaffName = cab.getAllocatedByUser().getFirstName()
					+ " " + cab.getAllocatedByUser().getLastName();
		}
	}

	public String getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public Long getCaseActionBookId() {
		return caseActionBookId;
	}

	public void setCaseActionBookId(Long caseActionBookId) {
		this.caseActionBookId = caseActionBookId;
	}

	public Long getCaseID() {
		return caseID;
	}

	public void setCaseID(Long caseID) {
		this.caseID = caseID;
	}

	public Date getDateRecorded() {
		return dateRecorded;
	}

	public void setDateRecorded(Date dateRecorded) {
		this.dateRecorded = dateRecorded;
	}

	public String getAllocatedBy() {
		return allocatedBy;
	}

	public void setAllocatedBy(String allocatedBy) {
		this.allocatedBy = allocatedBy;
	}

	public String getSourceReference() {
		return sourceReference;
	}

	public void setSourceReference(String sourceReference) {
		this.sourceReference = sourceReference;
	}

	public String getActionRequired() {
		return actionRequired;
	}

	public void setActionRequired(String actionRequired) {
		this.actionRequired = actionRequired;
	}

	public Date getDateAllocated() {
		return dateAllocated;
	}

	public void setDateAllocated(Date dateAllocated) {
		this.dateAllocated = dateAllocated;
	}

	public String getAllocatedTo() {
		return allocatedTo;
	}

	public void setAllocatedTo(String allocatedTo) {
		this.allocatedTo = allocatedTo;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getSeenByOFM() {
		return seenByOFM;
	}

	public void setSeenByOFM(String seenByOFM) {
		this.seenByOFM = seenByOFM;
	}

	public Date getDateCompleted() {
		return dateCompleted;
	}

	public void setDateCompleted(Date dateCompleted) {
		this.dateCompleted = dateCompleted;
	}

	public String getSentivity() {
		return sentivity;
	}

	public void setSentivity(String sentivity) {
		this.sentivity = sentivity;
	}

	public Long getActionNumber() {
		return actionNumber;
	}

	public void setActionNumber(Long actionNumber) {
		this.actionNumber = actionNumber;
	}

	public String getAllocatedToStaffName() {
		return allocatedToStaffName;
	}

	public void setAllocatedToStaffName(String allocateToStaffName) {
		this.allocatedToStaffName = allocateToStaffName;
	}

	public String getAllocatedByStaffName() {
		return allocatedByStaffName;
	}

	public void setAllocatedByStaffName(String allocatedByStaffName) {
		this.allocatedByStaffName = allocatedByStaffName;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getActionStatus() {
		return actionStatus;
	}

	public void setActionStatusAsText(String actionStatusAsText) {
		this.actionStatusAsText = actionStatusAsText;
	}

	public String getActionStatusAsText() {

		if (actionStatus.equals("1")) {
			
			this.actionStatusAsText = "Not Started";
			
		} else if (actionStatus.equals("2")) {
			
			this.actionStatusAsText = "In Progress";
			
		} else if (actionStatus.equals("3")) {
			
			this.actionStatusAsText = "Completed";
		} else {
			this.actionStatusAsText = "Unknown";
		}
		return this.actionStatusAsText;
	}

	public void setActionStatus(String actionStatus) {
		this.actionStatus = actionStatus;
	}

	public MultipartFile getFileToUpload() {
		return fileToUpload;
	}

	public void setFileToUpload(MultipartFile fileToUpload) {
		this.fileToUpload = fileToUpload;
	}

	public String getAttachmentComment() {
		return attachmentComment;
	}

	public void setAttachmentComment(String attachmentComment) {
		this.attachmentComment = attachmentComment;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getActionModel() {
		return actionModel;
	}

	public void setActionModel(String actionModel) {
		this.actionModel = actionModel;
	}

	public String getEmpOrgCode() {
		return empOrgCode;
	}

	public void setEmpOrgCode(String empOrgCode) {
		this.empOrgCode = empOrgCode;
	}
	
}
