package uk.nhs.cfsms.ecms.model;

import org.springframework.web.multipart.MultipartFile;

public class ActionAttachmentFileUpload {
	
	private MultipartFile file;

	private String attachmentDescription;
	
	
	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public String getAttachmentDescription() {
		return attachmentDescription;
	}

	public void setAttachmentDescription(String attachmentDescription) {
		this.attachmentDescription = attachmentDescription;
	}

}
