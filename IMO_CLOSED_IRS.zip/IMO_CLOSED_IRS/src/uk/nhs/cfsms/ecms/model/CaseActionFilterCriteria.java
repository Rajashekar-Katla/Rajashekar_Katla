/**
 * 
 */
package uk.nhs.cfsms.ecms.model;

import java.io.Serializable;

/**
 * @author vdabas
 *
 */
public class CaseActionFilterCriteria implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long firstActionNumber;
	
	private Long lastActionNumber;

	private Long caseId;
	
    private String allocatedTo;
	
	private String allcatedBy;
	
	private String orderBy;
	
	private String status;
	
	private boolean ascending; 
	
	public Long getFirstActionNumber() {
		return firstActionNumber;
	}

	public void setFirstActionNumber(Long firstActionNumber) {
		this.firstActionNumber = firstActionNumber;
	}

	public Long getLastActionNumber() {
		return lastActionNumber;
	}

	public void setLastActionNumber(Long lastActionNumber) {
		this.lastActionNumber = lastActionNumber;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getAllocatedTo() {
		return allocatedTo;
	}

	public void setAllocatedTo(String allocatedTo) {
		this.allocatedTo = allocatedTo;
	}

	public String getAllcatedBy() {
		return allcatedBy;
	}

	public void setAllcatedBy(String allcatedBy) {
		this.allcatedBy = allcatedBy;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isAscending() {
		return ascending;
	}

	public void setAscending(boolean ascending) {
		this.ascending = ascending;
	}

	

	
}
