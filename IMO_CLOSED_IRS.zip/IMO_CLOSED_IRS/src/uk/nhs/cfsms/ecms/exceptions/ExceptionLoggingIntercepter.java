package uk.nhs.cfsms.ecms.exceptions;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ExceptionLoggingIntercepter implements MethodInterceptor {

	private final Log logger = LogFactory.getLog("uk.nhs.cfsms.ecms");

	public Object invoke(MethodInvocation arg0) throws Throwable {

		Object result = null;

		try {
			result = arg0.proceed();
		} catch (Exception e) {
			String message = "Error invoking "
					+ arg0.getMethod().getDeclaringClass().getName() + "."
					+ arg0.getMethod().getName();
			logger.error(message, e);
			throw e;
		}
		return result;
	}

}
