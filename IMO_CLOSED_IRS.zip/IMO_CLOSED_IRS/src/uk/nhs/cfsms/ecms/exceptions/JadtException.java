package uk.nhs.cfsms.ecms.exceptions;

public class JadtException extends RuntimeException {
    
	private static final long serialVersionUID = 10078903L;

	public JadtException(String msg) {
		
		super(msg);
	}
	
}
