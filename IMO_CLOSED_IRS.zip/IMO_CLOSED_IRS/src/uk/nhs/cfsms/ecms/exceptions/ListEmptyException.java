package uk.nhs.cfsms.ecms.exceptions;

public class ListEmptyException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ListEmptyException(String s) {
        super(s);
    }


}
