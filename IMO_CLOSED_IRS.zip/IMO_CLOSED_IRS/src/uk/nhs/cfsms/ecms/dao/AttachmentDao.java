package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.Attachment;


public interface AttachmentDao extends BaseDao{
	
	public Attachment loadAttachment(Long AttachmentId);
	public List<Attachment> listAttachments(Long caseId);
	public List<Attachment> listInfoAttachments(Long infoId);
	public void saveAttachment(Attachment attachment);
	public void deleteAttachment(Attachment attachment);
}
