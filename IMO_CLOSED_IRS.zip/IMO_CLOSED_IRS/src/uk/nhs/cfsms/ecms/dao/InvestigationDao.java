package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.InvestigationPlan;

public interface InvestigationDao {

	public InvestigationPlan loadInvestigationPlanById(Long investigationId);

	public InvestigationPlan saveInvestigationPlan(InvestigationPlan hibernate);

	public void updateInvestigationPlan(InvestigationPlan hibernate);

	public void deleteInvestigationPlan(InvestigationPlan hibernate);

	public List<InvestigationPlan> loadAllInvestigationPlansByCaseId(Long caseId);

}
