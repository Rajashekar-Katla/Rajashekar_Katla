package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.LookupViewDao;
import uk.nhs.cfsms.ecms.data.common.LookupView;

@Repository
public class HibernateLookupViewDao extends HibernateBaseDao implements
		LookupViewDao {

	private static final String[] PATIENT_OCCUPATION_DESC = new String[] {
			"Registered Patient", "Health Visitor", "Other" };

	@SuppressWarnings("unchecked")
	public List<LookupView> loadActiveLookupDetailsByGroups(String groupName) {
		Criteria criteria = getCurrentSession()
				.createCriteria(LookupView.class);
		criteria.add(Restrictions.eq("groupName", groupName));
		criteria.add(Restrictions.eq("active", "Y"));
		//criteria.addOrder(Order.asc("description"));
		return criteria.list();

	}

	@SuppressWarnings("unchecked")
	public List<LookupView> loadActiveLookupDetailsByGroupForInternal(
			String groupName) {

		Criteria criteria = getCurrentSession()
				.createCriteria(LookupView.class);
		criteria.add(Restrictions.eq("groupName", groupName));
		criteria.add(Restrictions.eq("active", "Y"));
		criteria.add(Restrictions.isNull("parentId"));
		//criteria.addOrder(Order.asc("description"));

		return criteria.list();

	}

	@SuppressWarnings("unchecked")
	public List<LookupView> loadActiveLookupDetailsByGroupForExternal(
			String groupName) {

		Criteria criteria = getCurrentSession()
				.createCriteria(LookupView.class);
		criteria.add(Restrictions.eq("groupName", groupName));
		criteria.add(Restrictions.eq("active", "Y"));
		//criteria.addOrder(Order.asc("description"));

		return criteria.list();

	}

	@SuppressWarnings("unchecked")
	public List<LookupView> loadActiveLookupDetailsByParentId(Integer parentId) {

		Criteria criteria = getCurrentSession()
				.createCriteria(LookupView.class);

		criteria.add(Restrictions.eq("parentId", parentId));
		criteria.add(Restrictions.eq("active", "Y"));
		criteria.addOrder(Order.asc("description"));

		return criteria.list();
	}

	@SuppressWarnings("unchecked")
	public LookupView loadLookupDetailsById(Integer lookupId) {

		Criteria criteria = getCurrentSession()
				.createCriteria(LookupView.class);

		criteria.add(Restrictions.idEq(lookupId));

		List list = criteria.list();

		if (null != list && !list.isEmpty()) {
			return (LookupView) list.get(0);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<LookupView> loadActiveLookupDetailsByParentId(Integer parentId,
			Integer groupId) {

		Criteria criteria = getCurrentSession()
				.createCriteria(LookupView.class);

		criteria.add(Restrictions.eq("parentId", parentId));
		criteria.add(Restrictions.eq("groupId", groupId));
		criteria.add(Restrictions.eq("active", "Y"));
		criteria.addOrder(Order.asc("description"));

		return criteria.list();
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<LookupView> loadByGroupAndOrderByLookupId(String groupName) {

		Criteria criteria = getCurrentSession()
				.createCriteria(LookupView.class);
		criteria.add(Restrictions.eq("groupName", groupName));
		criteria.add(Restrictions.eq("active", "Y"));
		criteria.addOrder(Order.asc("lookupId"));

		return criteria.list();
	}

	@Override
	public List<LookupView> loadPatientOccupationDescriptions() {

		Criteria criteria = getCurrentSession()
				.createCriteria(LookupView.class);
		criteria.add(Restrictions.in("description", PATIENT_OCCUPATION_DESC));
		criteria.addOrder(Order.asc("description"));
		criteria.setProjection(Projections.projectionList()
				.add(Projections.property("lookupId"), "lookupId")
				.add(Projections.property("description"), "description"))
				.setResultTransformer(Transformers.aliasToBean(LookupView.class));
		return criteria.list();
	}
}
