package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.ChargeListDao;
import uk.nhs.cfsms.ecms.data.sanction.ChargeList;

@Repository
public class HibernateChargeListDao extends HibernateBaseDao implements ChargeListDao {

	@SuppressWarnings("unchecked")
	public List<ChargeList> getChargeLists(Long criminalSanctionId) {
		
		List<ChargeList> result = new ArrayList<ChargeList>();
		DetachedCriteria criteria = DetachedCriteria.forClass(
				ChargeList.class).add(
				Restrictions.eq("criminalSanctionId", criminalSanctionId));

		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		result = criteria.getExecutableCriteria(getCurrentSession()).list();
		
		return result;
	}
	
}
