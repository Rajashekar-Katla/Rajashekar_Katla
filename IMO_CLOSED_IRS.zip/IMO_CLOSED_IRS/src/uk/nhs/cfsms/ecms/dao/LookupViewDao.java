package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.LookupView;

public interface LookupViewDao {

	public List<LookupView> loadActiveLookupDetailsByGroups(String groupName);	
	
	public List<LookupView> loadActiveLookupDetailsByParentId(Integer parentId);
	
	public LookupView loadLookupDetailsById(Integer lookupId);

	public List<LookupView> loadActiveLookupDetailsByParentId(Integer parentId,
			Integer groupId);
	
	public List<LookupView> loadByGroupAndOrderByLookupId(String groupName);
	
	public List<LookupView> loadActiveLookupDetailsByGroupForExternal(String groupName);
	
	public List<LookupView> loadActiveLookupDetailsByGroupForInternal(
			String groupName);
	
	public List<LookupView> loadPatientOccupationDescriptions();
}
