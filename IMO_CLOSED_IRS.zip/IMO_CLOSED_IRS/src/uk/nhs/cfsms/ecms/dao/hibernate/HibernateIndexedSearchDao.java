package uk.nhs.cfsms.ecms.dao.hibernate;

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.IndexedSearchDao;
import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.cim.CaseIndexSearch;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.Information;
import uk.nhs.cfsms.ecms.data.infoGath.InformationIndexSearch;
import uk.nhs.cfsms.ecms.dto.search.SearchResultsTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * Hibernate Implementation for Indexed Search DAO. Applied for cases and
 * information.
 * 
 */
@Repository
public class HibernateIndexedSearchDao extends HibernateBaseDao implements
		IndexedSearchDao {

	protected final Log log = LogFactory.getLog(getClass());
	
	public SearchResultsTO getCaseIndexedSearchResults(String outkeywords,
			final SessionUser user) {

		SearchResultsTO resTO = new SearchResultsTO();
		List<CaseIndexSearch> caseIndxList = new ArrayList<CaseIndexSearch>();

		final String hql = "SELECT search_id, case_id, case_number, description_values, origin_table, origin_id, confidential, confidential_search, "
				+ "restricted_search, created_date, NVL( LENGTH( REGEXP_REPLACE( lower(description_values), ?, ? ) ), 0) as pattern_count "
				+ " FROM INDEXED_CASE_SEARCH_TBL WHERE CONTAINS(description_values , ? , 1) > 0 ORDER BY pattern_count DESC";

		if (log.isDebugEnabled()) {
			log.debug("**QUERY= " + hql);
		}

		char outfirstChar = ' ';
		String outlaterPart = "";
		outkeywords = this.replaceSpecialChars(outkeywords);
		int keyLength = outkeywords.length();
		if (keyLength >= 1) {
			outfirstChar = outkeywords.toLowerCase().charAt(0);
			if (keyLength > 1) {
				outlaterPart = outkeywords.substring(1, keyLength - 1)
						.toLowerCase();
			}
		}

		final String inkeywords = outkeywords;

		final String inlaterPart = outlaterPart;
		final char infirstChar = outfirstChar;

		SQLQuery sqlquery = getCurrentSession().createSQLQuery(hql.toString());
		sqlquery.setString(0, "(" + infirstChar + ")"
				+ inlaterPart + "|.");
		sqlquery.setString(1, "/1");
		sqlquery.setString(2, inkeywords);
		ScrollableResults results = sqlquery.scroll(ScrollMode.FORWARD_ONLY);
		/*ScrollableResults results = (ScrollableResults) getHibernateTemplate()
				.execute(new HibernateCallback() {
					public Object doInHibernate(Session session)
							throws HibernateException, SQLException {
						SQLQuery sqlquery = session.createSQLQuery(hql
								.toString());
						sqlquery.setString(0, "(" + infirstChar + ")"
								+ inlaterPart + "|.");
						sqlquery.setString(1, "/1");
						sqlquery.setString(2, inkeywords);
						return sqlquery.scroll(ScrollMode.FORWARD_ONLY);

					}
				});*/
		try {

			while (results.next()) {

				CaseIndexSearch sto = new CaseIndexSearch();
				Object[] rs = results.get();

				if (rs[0] != null) {
					BigDecimal searchId = (BigDecimal) rs[0];
					sto.setSearchId(searchId.longValue());
				}
				if (rs[1] != null) {
					BigDecimal caseId = (BigDecimal) rs[1];
					sto.setCaseId(caseId.longValue());
				}
				if (rs[2] != null) {
					String caseNumber = (String) rs[2];
					sto.setCaseNumber(caseNumber);
				}
				if (rs[3] != null) {
					String description = getClobString(rs[3]);
					sto.setDescription(description.toString());
				}
				if (rs[4] != null) {
					String tableName = (String) rs[4];
					int indexLen = tableName.length() - 1;
					if ((indexLen = tableName.indexOf("_TBL")) == -1) {
						indexLen = tableName.length() - 1;
					}
					sto.setOriginTable(tableName.substring(0, indexLen));
				}
				if (rs[5] != null) {
					BigDecimal tableId = (BigDecimal) rs[5];
					sto.setOriginId(tableId.longValue());
				}
				if (rs[6] != null) {
					String confidential = (String) rs[6];
					sto.setConfidentialSearch(confidential);
				}
				if (rs[7] != null) {
					String confidentialSearch = (String) rs[7];
					sto.setConfidentialSearch(confidentialSearch);
				}
				if (rs[8] != null) {
					String restrictedSearch = (String) rs[8];
					sto.setRestrictedSearch(restrictedSearch);
				}
				if (rs[9] != null) {
					Date createdDate = (Date) rs[9];
					if (createdDate != null)
						sto.setCreatedTime(new java.sql.Date(createdDate
								.getTime()));
				}
				if (rs[10] != null) {
					BigDecimal keywordCount = (BigDecimal) rs[10];
					//sto.setKeywordCount(keywordCount.intValue());
				}

				if (log.isDebugEnabled()) {
					log.debug("Result set :" + sto.toString());
				}
				caseIndxList.add(sto);
			}
			results.close();

		} catch (Exception e) {
			log.error(e);
		}

		resTO.setSearchKeywords(outkeywords);
		resTO.setSearchResults(caseIndxList);

		return resTO;
	}

	public SearchResultsTO getCaseIndexedSearchResultsWithFuncation(
			String keyword) {

		SearchResultsTO resTO = new SearchResultsTO();
		final String sql = "select * from table(FIRST.CASE_SEARCH_FUNCTION(:keyword))";

		if (log.isDebugEnabled()) {
			log.debug("**QUERY= " + sql);
		}
		keyword = this.replaceSpecialChars(keyword);
		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("keyword", keyword);
		query.addEntity(CaseIndexSearch.class);

		@SuppressWarnings("unchecked")
		List<CaseIndexSearch> results = query.list();

		resTO.setSearchKeywords(keyword);
		resTO.setSearchResults(results);

		return resTO;
	}

	/**
	 * Get search results details based on the search Id after checking
	 * permission for the case Id for a user
	 * 
	 * 
	 * public SearchResultsTO getCaseSearchResultDetails(Long searchId, Long
	 * caseId, SessionUser user) {
	 * 
	 * SearchResultsTO resTO = new SearchResultsTO();
	 * resTO.setApplicationId(caseId); resTO.setNodeId(searchId.toString());
	 * resTO.setSearchType("case");
	 * 
	 * List<CaseIndexSearch> caseIndxList = new ArrayList<CaseIndexSearch>();
	 * 
	 * if (checkPermissionForCase(caseId, user) > 0) { Connection con =
	 * getSession().connection();
	 * 
	 * String query =
	 * "SELECT search_id, case_id, case_number, description_values, origin_table,"
	 * +
	 * "origin_id, confidential, confidential_search, restricted_search, created_date "
	 * + " FROM INDEXED_CASE_SEARCH_TBL WHERE search_id = ?";
	 * 
	 * if (log.isDebugEnabled()) { log.debug("QUERY= " + query); }
	 * 
	 * try {
	 * 
	 * PreparedStatement stmt = con.prepareStatement(query); stmt.setLong(1,
	 * searchId); ResultSet rs = stmt.executeQuery();
	 * 
	 * while (rs.next()) {
	 * 
	 * CaseIndexSearch sto = new CaseIndexSearch(); // Long searchId1 =
	 * rs.getLong(1); // Long caseId1 = rs.getLong(2); String caseNumber =
	 * rs.getString(3); String description = rs.getString(4); String tableName =
	 * rs.getString(5); Long tableId = rs.getLong(6); String confidential =
	 * rs.getString(7); String confidentialSearch = rs.getString(8); String
	 * restrictedSearch = rs.getString(9); java.sql.Date createdDate =
	 * rs.getDate(10);
	 * 
	 * sto.setSearchId(searchId); sto.setCaseId(caseId);
	 * sto.setCaseNumber(caseNumber); sto.setDescription(description);
	 * sto.setOriginId(tableId); sto.setConfidential(confidential);
	 * sto.setConfidentialSearch(confidentialSearch);
	 * sto.setRestrictedSearch(restrictedSearch);
	 * sto.setCreatedTime(createdDate);
	 * 
	 * int indexLen = tableName.length() - 1; if ((indexLen =
	 * tableName.indexOf("_TBL")) == -1) { indexLen = tableName.length() - 1; }
	 * sto.setOriginTable(tableName.substring(0, indexLen));
	 * 
	 * if (log.isDebugEnabled()) { log.debug("Results CaseIndexSearch=" + sto);
	 * }
	 * 
	 * caseIndxList.add(sto); } rs.close();
	 * 
	 * } catch (Exception e) { log.error(e); }
	 * 
	 * resTO.setSearchResults(caseIndxList); } else {
	 * resTO.setSummary("NO ACCESS");
	 * 
	 * String teamCode = getTeamCodeByCaseId(caseId);
	 * 
	 * if (teamCode == null || EcmsUtils.isTeamCodeCFSMS(teamCode)) { teamCode =
	 * "T1350"; } UserObject managerDetails = getOFMByTeamCode(teamCode);
	 * resTO.setDataOwner(managerDetails); } return resTO; }
	 */

	public SearchResultsTO getCaseSearchResultDetails(final Long searchId,
			Long caseId, SessionUser user) {

		SearchResultsTO resTO = new SearchResultsTO();
		resTO.setApplicationId(caseId);
		resTO.setNodeId(searchId.toString());
		resTO.setSearchType("case");

		List<CaseIndexSearch> caseIndxList = new ArrayList<CaseIndexSearch>();

		if (checkPermissionForCase(caseId, user) > 0) {

			final String hql = "SELECT search_id, case_id, case_number, description_values, origin_table,"
					+ "origin_id, confidential, confidential_search, restricted_search, created_date "
					+ " FROM INDEXED_CASE_SEARCH_TBL WHERE search_id = ?";

			if (log.isDebugEnabled()) {
				log.debug("QUERY= " + hql);
			}

			SQLQuery sqlquery = getCurrentSession().createSQLQuery(hql);
			sqlquery.setLong(0, searchId);
			ScrollableResults results = sqlquery.scroll();
			try {

				/*ScrollableResults results = (ScrollableResults) getHibernateTemplate()
						.execute(new HibernateCallback() {
							public Object doInHibernate(Session session)
									throws HibernateException, SQLException {
								SQLQuery sqlquery = session.createSQLQuery(hql);
								sqlquery.setLong(0, searchId);

								return sqlquery.scroll();

							}
						});*/
				while (results.next()) {

					CaseIndexSearch sto = new CaseIndexSearch();
					Object rs[] = results.get();
					if (rs[0] != null) {
						BigDecimal searchId1 = (BigDecimal) rs[0];
						sto.setSearchId(searchId1.longValue());
					}
					if (rs[1] != null) {
						BigDecimal caseId1 = (BigDecimal) rs[1];
						sto.setCaseId(caseId1.longValue());
					}
					if (rs[2] != null) {
						String caseNumber = (String) rs[2];
						sto.setCaseNumber(caseNumber);
					}
					if (rs[3] != null) {
						String description = getClobString(rs[3]);
						sto.setDescription(description.toString());
					}

					if (rs[4] != null) {
						String tableName = (String) rs[4];
						int indexLen = tableName.length() - 1;
						if ((indexLen = tableName.indexOf("_TBL")) == -1) {
							indexLen = tableName.length() - 1;
						}
						sto.setOriginTable(tableName.substring(0, indexLen));

					}
					if (rs[5] != null) {
						BigDecimal tableId = (BigDecimal) rs[5];
						sto.setOriginId(tableId.longValue());
					}
					if (rs[6] != null) {
						String confidential = (String) rs[6];
						sto.setConfidentialSearch(confidential);
					}
					if (rs[7] != null) {
						String confidentialSearch = (String) rs[7];
						sto.setConfidentialSearch(confidentialSearch);
					}
					if (rs[8] != null) {
						String restrictedSearch = (String) rs[8];
						sto.setRestrictedSearch(restrictedSearch);
					}
					if (rs[9] != null) {
						Date createdDate = (Date) rs[9];
						sto.setCreatedTime(new java.sql.Date(createdDate
								.getTime()));
					}

					if (log.isDebugEnabled()) {
						log.debug("Results CaseIndexSearch=" + sto);
					}

					caseIndxList.add(sto);
				}
				results.close();

			} catch (Exception e) {
				log.error(e);
			}

			resTO.setSearchResults(caseIndxList);
		} else {
			resTO.setSummary("NO ACCESS");

			String teamCode = getTeamCodeByCaseId(caseId);

			if (teamCode == null || EcmsUtils.isTeamCodeCFSMS(teamCode)) {
				teamCode = "T1350";
			}
			UserObject managerDetails = getOFMByTeamCode(teamCode);
			resTO.setDataOwner(managerDetails);
		}
		return resTO;
	}

	/**
	 * Get OFM staff details by their team code.
	 * 
	 * @param teamCode
	 * @return UserObject.
	 */
	private UserObject getOFMByTeamCode(final String teamCode) {

		final StringBuffer hql = new StringBuffer("SELECT user FROM");
		hql.append(" UserObject user, AllUserResponsibilities resp");
		hql.append(" WHERE user.staffId = resp.staffId AND");
		hql.append(" user.employerOrgCode= :teamCode AND");
		hql.append(" resp.respCode = :teamCode AND");
		if (teamCode.equalsIgnoreCase("T1350")) {
			hql.append(" user.groupPermission in (4, 1)");
		} else if (EcmsUtils.isTeamCodeInOFMTeams(teamCode)) {
			hql.append(" user.groupPermission = 4");
		} else if (EcmsUtils.isNITTeamCode(teamCode)) {
			hql.append(" user.groupPermission = 9");	
		} else {
			hql.append(" user.groupPermission = 8");
		}
		
		hql.append(" AND user.status = :status");
		
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("teamCode", teamCode);
		query.setParameter("status", "A");//only include active users

		if (log.isDebugEnabled()) {
			log.debug(hql);
		}
		List userList = query.list();
		/*List userList = (List) getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session)
							throws HibernateException, SQLException {
						Query query = session.createQuery(hql.toString());
						query.setParameter("teamCode", teamCode);

						if (log.isDebugEnabled()) {
							log.debug(hql);
						}

						List userList = query.list();
						return userList;

					}
				});*/
		if (null != userList && !userList.isEmpty() && userList.size() == 1) {
			return (UserObject) userList.get(0);
		}

		return null;
	}

	/**
	 * Get TeamCode from case using caseId.
	 * 
	 * @param caseId
	 * @return TeamCode
	 */
	private String getTeamCodeByCaseId(Long caseId) {
		String teamCode = null;
		DetachedCriteria criteria = DetachedCriteria.forClass(Case.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();
		if (null != list && !list.isEmpty()) {
			Case caseObj = (Case) (list.get(0));
			teamCode = caseObj.getTeamCode();
		}
		return teamCode;
	}

	/**
	 * Check permission for the user for a particular case.
	 * 
	 * @param caseId
	 * @param user
	 * @return count.
	 */
	private int checkPermissionForCase(final Long caseId, SessionUser user) {

		if (user.isUserFCRL())
			return 0;

		String staffId = user.getStaffId().trim();
		String[] userResps = user.getOrgOrTeamResponsibilities();
		List<UserDirectorate> dirList = user.getDirectorates();
		String[] dirs = user.getCFSDirectorateLevel();
		String dirString = EcmsUtils.getCommaSeperatedValues(dirs);
		String respString = EcmsUtils.getCommaSeperatedValues(userResps);

		if (log.isDebugEnabled()) {
			log.debug("* DIR =" + dirString);
			log.debug("* RESP =" + respString);
			log.debug("* StaffId =" + staffId);
		}
		
		final StringBuffer qSB = new StringBuffer("SELECT count(*) as count ");
		qSB.append(" FROM CASE_PERM_TBL casePerm, CASE_TBL case1 ");
		qSB.append(" WHERE case1.case_id = casePerm.case_id AND ");
//		qSB.append(" case1.state in ('");
//		qSB.append(ECMSConstants.CASE_OPEN).append("','");
//		qSB.append(ECMSConstants.CASE_PENDING).append("','");
//		qSB.append(ECMSConstants.CASE_CLOSED).append("','");
//		qSB.append(ECMSConstants.CASE_REOPENED).append("','");
//		qSB.append(ECMSConstants.CASE_AWAITING).append("') AND ( ");
		qSB.append(" (");
		if (!user.isUserLCFS()) {
			qSB.append(" (casePerm.PERM_TYPE='TEAM_CODE' AND ");
			qSB.append(" (case1.RESTRICT_TO in ");
			qSB.append(dirString).append(")");
			qSB.append(" AND casePerm.VALUE in ");
			qSB.append(respString).append(" ) OR ");
		}

		qSB.append(" (casePerm.PERM_TYPE in ");
		qSB.append("('LEAD_ASSIGNEE','CASE_ASSIGNEE') AND casePerm.value= '");
		qSB.append(staffId).append("' ");

		if (!user.isUserLCFS()) {
			
			qSB.append(" AND case1.RESTRICT_TO in ");
			qSB.append(dirString).append(") ) ");
		} else {
			
			qSB.append(" ) OR (casePerm.PERM_TYPE='ORG_CODE' ");
			
			if (null != dirList && !dirList.isEmpty()) {
				qSB.append(" and (case1.RESTRICT_TO in ");
				qSB.append(dirString).append(")");
			}
			qSB.append(" and (casePerm.VALUE in ");
			qSB.append(respString).append("))) ");
		}

		qSB.append(" AND case1.case_id = ?");

		SQLQuery sqlquery = getCurrentSession().createSQLQuery(qSB.toString());
		sqlquery.setLong(0, caseId);
		Object recordCountObj = sqlquery.uniqueResult();
		
		/*Object recordCountObj = (Object) getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session)
							throws HibernateException, SQLException {
						SQLQuery query = session.createSQLQuery(qSB.toString());
						query.setLong(0, caseId);
						return query.uniqueResult();
					}
				});*/

		if (recordCountObj instanceof BigDecimal) {
			BigDecimal recordCount = (BigDecimal) recordCountObj;
			return recordCount.intValue();
		} else if (recordCountObj instanceof Integer) {
			Integer recordCount = (Integer) recordCountObj;
			return recordCount.intValue();
		}

		return 0;

	}

	/**
	 * Get Information Indexed Search Results
	 * 
	 * 
	 * public SearchResultsTO getInformationIndexedSearchResults(String
	 * keywords, SessionUser user) {
	 * 
	 * SearchResultsTO resTO = new SearchResultsTO();
	 * List<InformationIndexSearch> infoIndxList = new
	 * ArrayList<InformationIndexSearch>(); Connection con =
	 * getSession().connection();
	 * 
	 * StringBuffer querySB = new StringBuffer();
	 * querySB.append("SELECT search_id, information_id, ");
	 * querySB.append("description_values, origin_table, origin_id,");
	 * querySB.append("created_date");
	 * 
	 * if (hasNoBooleanExpression(keywords)) { querySB .append(", NVL( LENGTH( REGEXP_REPLACE( lower(description_values), ?, '\\1' ) ), 0) as pattern_count "
	 * ); } querySB.append(" FROM INDEXED_INFORMATION_SEARCH_TBL ");
	 * querySB.append(" WHERE ");
	 * querySB.append(" CONTAINS(description_values , ? , 1) > 0 ");
	 * 
	 * if (hasNoBooleanExpression(keywords)) {
	 * querySB.append(" ORDER BY pattern_count DESC"); } String query =
	 * querySB.toString();
	 * 
	 * if (log.isDebugEnabled()) { log.debug("***INFO SEARCH QUERY=" + query); }
	 * char firstChar = ' '; String laterPart = ""; // Replace special chars or
	 * meta data with blanks or like. keywords =
	 * this.replaceSpecialChars(keywords); int keyLength = keywords.length(); if
	 * (keyLength >= 1) { firstChar = keywords.toLowerCase().charAt(0); if
	 * (keyLength > 1) { laterPart = keywords.substring(1, keyLength - 1).trim()
	 * .toLowerCase(); } } try { PreparedStatement stmt =
	 * con.prepareStatement(query);
	 * 
	 * if (hasNoBooleanExpression(keywords)) { stmt.setString(1, "(" + firstChar
	 * + ")" + laterPart + "|."); stmt.setString(2, keywords); } else {
	 * stmt.setString(1, keywords); } ResultSet rs = stmt.executeQuery();
	 * 
	 * while (rs.next()) {
	 * 
	 * InformationIndexSearch sto = new InformationIndexSearch(); Long searchId
	 * = rs.getLong(1); Long informationId = rs.getLong(2); String description =
	 * rs.getString(3); String tableName = rs.getString(4); Long tableId =
	 * rs.getLong(5); java.sql.Date createdDate = rs.getDate(6);
	 * 
	 * sto.setSearchId(searchId); sto.setInformationId(informationId);
	 * sto.setDescription(description); sto.setOriginId(tableId);
	 * sto.setCreatedTime(createdDate);
	 * 
	 * if (hasNoBooleanExpression(keywords)) { int keywordCount = rs.getInt(7);
	 * sto.setKeywordCount(keywordCount); } else { sto.setKeywordCount(1); } int
	 * indexLen = tableName.length() - 1; if ((indexLen =
	 * tableName.indexOf("_TBL")) == -1) { indexLen = tableName.length() - 1; }
	 * sto.setOriginTable(tableName.substring(0, indexLen));
	 * 
	 * if (log.isDebugEnabled()) { log.debug("Result set :" + sto.toString()); }
	 * infoIndxList.add(sto); } rs.close();
	 * 
	 * } catch (Exception e) { log.error(e); }
	 * 
	 * resTO.setSearchKeywords(keywords);
	 * resTO.setInfoSearchResults(infoIndxList);
	 * 
	 * return resTO; }
	 */

	public SearchResultsTO getInformationIndexedSearchResults(
			String outkeywords, SessionUser user) {

		SearchResultsTO resTO = new SearchResultsTO();
		List<InformationIndexSearch> infoIndxList = new ArrayList<InformationIndexSearch>();

		final StringBuffer querySB = new StringBuffer();
		querySB.append("SELECT search_id, information_id, ");
		querySB.append("description_values, origin_table, origin_id,");
		querySB.append("created_date");

		//if (hasNoBooleanExpression(outkeywords)) {
			querySB
					.append(", NVL( LENGTH( REGEXP_REPLACE( lower(description_values), ?, ? ) ), 0) as pattern_count ");
		//}
		querySB.append(" FROM INDEXED_INFORMATION_SEARCH_TBL ");
		querySB.append(" WHERE ");
		querySB.append(" CONTAINS(description_values , ? , 1) > 0 ");

		//if (hasNoBooleanExpression(outkeywords)) {
			querySB.append(" ORDER BY pattern_count DESC");
		//}
		String query = querySB.toString();

		if (log.isDebugEnabled()) {
			log.debug("***INFO SEARCH QUERY=" + query);
		}
		char outfirstChar = ' ';
		String outlaterPart = "";

		// Replace special chars or meta data with blanks or like.
		outkeywords = this.replaceSpecialChars(outkeywords);
		int keyLength = outkeywords.length();
		if (keyLength >= 1) {
			outfirstChar = outkeywords.toLowerCase().charAt(0);
			if (keyLength > 1) {
				outlaterPart = outkeywords.substring(1, keyLength - 1).trim()
						.toLowerCase();
			}
		}
		final String inkeywords = outkeywords;
		final char infirstChar = outfirstChar;
		final String inlaterPart = outlaterPart;

		SQLQuery sqlquery = getCurrentSession().createSQLQuery(querySB
				.toString());
		sqlquery.setString(0, "(" + infirstChar + ")"
				+ inlaterPart + "|.");
		sqlquery.setString(1, "/1");
		sqlquery.setString(2, inkeywords);
		ScrollableResults results = sqlquery.scroll(ScrollMode.FORWARD_ONLY);
		
		try {
			/*ScrollableResults results = (ScrollableResults) getHibernateTemplate()
					.execute(new HibernateCallback() {
						public Object doInHibernate(Session session)
								throws HibernateException, SQLException {
							SQLQuery sqlquery = session.createSQLQuery(querySB
									.toString());
							sqlquery.setString(0, "(" + infirstChar + ")"
									+ inlaterPart + "|.");
							sqlquery.setString(1, "/1");
							sqlquery.setString(2, inkeywords);
							return sqlquery.scroll(ScrollMode.FORWARD_ONLY);

						}
					});*/

			while (results.next()) {

				Object rs[] = results.get();
				InformationIndexSearch sto = new InformationIndexSearch();

				if (rs[0] != null) {
					BigDecimal searchId1 = (BigDecimal) rs[0];
					sto.setSearchId(searchId1.longValue());
				}
				if (rs[1] != null) {
					BigDecimal informationId1 = (BigDecimal) rs[1];
					sto.setInformationId(informationId1.longValue());
				}
				if (rs[2] != null) {
					String description = getClobString(rs[2]);
					sto.setDescription(description.toString());
				}
				if (rs[3] != null) {
					String tableName = (String) rs[3];
					int indexLen = tableName.length() - 1;
					if ((indexLen = tableName.indexOf("_TBL")) == -1) {
						indexLen = tableName.length() - 1;
					}
					sto.setOriginTable(tableName.substring(0, indexLen));

				}
				if (rs[4] != null) {
					BigDecimal tableId = (BigDecimal) rs[4];
					sto.setOriginId(tableId.longValue());
				}
				if (rs[5] != null) {
					Date createdDate = (Date) rs[5];
					sto
							.setCreatedTime(new java.sql.Date(createdDate
									.getTime()));
				}
				if (hasNoBooleanExpression(outkeywords)) {
					if (rs[6] != null) {
						BigDecimal keywordCount = (BigDecimal) rs[6];
						sto.setKeywordCount(keywordCount.intValue());
					}
				} else {
					sto.setKeywordCount(1);
				}

				if (log.isDebugEnabled()) {
					log.debug("Result set :" + sto.toString());
				}
				infoIndxList.add(sto);
			}
			results.close();

		} catch (Exception e) {
			log.error(e);
		}

		resTO.setSearchKeywords(outkeywords);
		resTO.setInfoSearchResults(infoIndxList);

		return resTO;
	}

	/**
	 * Get Information Search Results Details...
	 * 
	 */
	public SearchResultsTO getInformationResultDetails(final Long searchId,
			Long informationId, SessionUser user) {

		SearchResultsTO resTO = new SearchResultsTO();
		resTO.setApplicationId(informationId);
		resTO.setNodeId(searchId.toString());
		resTO.setSearchType("information");

		List<InformationIndexSearch> infoIndxList = new ArrayList<InformationIndexSearch>();
		int permissionCount = checkPermissionForInformation(informationId, user);
		if (log.isDebugEnabled()) {
			log.debug("Perm Count on InfoId=" + informationId + ","
					+ permissionCount);
		}
		if (permissionCount > 0) {

			final String query = "SELECT search_id, information_id, description_values, origin_table,"
					+ "origin_id, created_date FROM INDEXED_INFORMATION_SEARCH_TBL WHERE search_id = ?";

			if (log.isDebugEnabled()) {
				log.debug("QUERY= " + query);
			}

			SQLQuery sqlquery = getCurrentSession().createSQLQuery(query.toString());
			sqlquery.setLong(0, searchId);
			ScrollableResults results = sqlquery.scroll();
			try {

				while (results.next()) {

					InformationIndexSearch sto = new InformationIndexSearch();

					Object rs[] = results.get();

					if (rs[0] != null) {
						BigDecimal searchId1 = (BigDecimal) rs[0];
						sto.setSearchId(searchId1.longValue());
					}
					if (rs[1] != null) {
						BigDecimal informationId1 = (BigDecimal) rs[1];
						sto.setInformationId(informationId1.longValue());
					}
					if (rs[2] != null) {
						String description = getClobString(rs[2]);
						sto.setDescription(description.toString());
					}
					if (rs[3] != null) {
						String tableName = (String) rs[3];
						int indexLen = tableName.length() - 1;
						if ((indexLen = tableName.indexOf("_TBL")) == -1) {
							indexLen = tableName.length() - 1;
						}
						sto.setOriginTable(tableName.substring(0, indexLen));

					}
					if (rs[4] != null) {
						BigDecimal tableId = (BigDecimal) rs[4];
						sto.setOriginId(tableId.longValue());
					}
					if (rs[5] != null) {
						Date createdDate = (Date) rs[5];
						sto.setCreatedTime(new java.sql.Date(createdDate
								.getTime()));
					}

					if (log.isDebugEnabled()) {
						log.debug("Results InformationIndexSearch=" + sto);
					}

					infoIndxList.add(sto);
				}
				results.close();

			} catch (Exception e) {
				log.error(e);
			}

			resTO.setInfoSearchResults(infoIndxList);

		} else {

			resTO.setSummary("NO ACCESS");
			String tC = getTeamCodeByInfoId(informationId);

			// Temp fix, if teamCode is null or unkown, OFM org is 'T1350'
			if (tC == null || EcmsUtils.isTeamCodeCFSMS(tC)
					|| tC.equalsIgnoreCase(ECMSConstants.UNKOWN_TEAM_CODE)
					|| tC.equalsIgnoreCase(ECMSConstants.TEAM_UNKNOWN)
					|| tC.equalsIgnoreCase(ECMSConstants.UNKNOWN_ORG_CODE)) {
				tC = "T1350";
			}
			UserObject managerDetails = getOFMByTeamCode(tC);
			resTO.setDataOwner(managerDetails);
		}
		return resTO;
	}

	/**
	 * Get TeamCode by Information Id.
	 * 
	 * @param informationId
	 * @return TeamCode
	 */
	private String getTeamCodeByInfoId(Long informationId) {
		String teamCode = null;
		DetachedCriteria criteria = DetachedCriteria
				.forClass(Information.class);
		criteria.add(Restrictions.eq("informationId", informationId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();
		if (null != list && !list.isEmpty()) {
			Information info = (Information) (list.get(0));
			teamCode = info.getTeamCode();
		}
		return teamCode;
	}

	private int checkPermissionForInformation(final Long informationId,
			final SessionUser user) {

		final String resp[] = user.getOrgOrTeamResponsibilities();

		final StringBuffer hSql = new StringBuffer(
				"SELECT count(*) as count FROM ");
		hSql.append(" Information iv ");

		if (user.isUserAdmin() || user.isUserDirector()) {

			hSql.append(" WHERE iv.caseId is null");
			hSql.append(" AND iv.informationId=").append(informationId);
			List list = getCurrentSession().createQuery(hSql.toString()).list();
			
			//List list = getHibernateTemplate().find(hSql.toString());
			return list.size();
		}

		hSql.append(", InformationPermission ip");
		hSql.append(" WHERE iv.informationId = ip.informationId");
		// Non case access to FCRL user for information.
		if (!user.isUserFCRL()) {
			hSql.append(" AND iv.caseId is null");
		}
		hSql.append(" AND iv.informationId=").append(informationId);

		if (user.isUserFCRL()) {
			hSql.append(" AND (ip.permissionType = '");
			hSql.append(ECMSConstants.FCRL_PERMISSION);
			hSql.append("' AND ip.permissionValue = '");
			hSql.append(ECMSConstants.FCRL_PERMISSION_VALUE);
			hSql.append("')");
		}

		if (user.isUserLCFS()) {
			hSql.append(" AND ( (ip.permissionType = '");
			hSql.append(ECMSConstants.INFO_ASSIGNEE_PERMISSION);
			hSql.append("' AND ip.permissionValue = '");
			hSql.append(user.getStaffId()).append("')");
			hSql.append(" OR (ip.permissionType = '");
			hSql.append(ECMSConstants.ORGANISATIONAL_PERMISSION);
			hSql.append("' AND ip.permissionValue in (:allResps) )");
			hSql.append(")");
		}

		if (user.isUserCFS() || user.isUserOFM() || user.isUserAntiFraudLead()) {
			hSql.append(" AND ( (ip.permissionType = '");
			hSql.append(ECMSConstants.INFO_ASSIGNEE_PERMISSION);
			hSql.append("' AND ip.permissionValue = '");
			hSql.append(user.getStaffId()).append("')");
			if (resp.length > 0) {
				hSql.append(" OR (ip.permissionType = '");
				hSql.append(ECMSConstants.TEAM_PERMISSION);
				hSql.append("' AND ip.permissionValue in (:allResps) )");
			}
			hSql.append(")");
		}

		Query query =  getCurrentSession().createQuery(hSql.toString());

		if (log.isDebugEnabled()) {
			log.debug("Information Permission=" + query);
			for (String rep : resp) {
				log.debug("RESP @ " + rep);
			}
		}
		if (resp.length > 0
				&& (user.isUserLCFS() || user.isUserCFS() || user
						.isUserOFM() || user.isUserAntiFraudLead())) {
			query.setParameterList("allResps", resp);
		}
		Object recordCountObj = query.uniqueResult();
		
		if (recordCountObj instanceof BigDecimal) {
			
			BigDecimal recordCount = (BigDecimal) recordCountObj;
			if (log.isDebugEnabled()) { 
				log.debug(" BigDecimal Count = " + recordCount);
			}
			return recordCount.intValue();

		} else if (recordCountObj instanceof Integer) {
			
			Integer recordCount = (Integer) recordCountObj;
			if (log.isDebugEnabled()) { 
				log.debug(" Integer Count = " + recordCount);
			}
			return recordCount;
		} else if (recordCountObj instanceof Long) {
			
			Long recordCount = (Long) recordCountObj;
			if (log.isDebugEnabled()) { 
				log.debug(" Long Count = " + recordCount);
			}
			return recordCount.intValue();

		} else if (recordCountObj instanceof Short) {
			
			Short recordCount = (Short) recordCountObj;
			if (log.isDebugEnabled()) { 
				log.debug(" Short Count = " + recordCount);
			}
			return recordCount.intValue();
		}
		

		return 0;

	}

	/**
	 * Check there is No Boolean expression in the data.
	 * 
	 * @param data
	 * @return boolean
	 */
	private boolean hasNoBooleanExpression(String data) {
		if (StringUtils.containsIgnoreCase(data, " and ")
				|| StringUtils.containsIgnoreCase(data, " or ")) {
			return false;
		}
		return true;
	}

	/**
	 * Helper method to replace special meta data in the keywords
	 * 
	 * @param original
	 * @return output
	 */

	private String replaceSpecialChars(String originalStr) {

		String blankReplaceStr = "";
		String likeReplaceStr = "%";

		String[] patterns = { "[*]", "[+]", "%", "[?]", "#", "~", "[&]", "[$]",
				"!", "\\(", "\\)", "\\[", "\\]", "\\{", "\\}", "\\\\" };

		String output = originalStr;
		for (String pattern : patterns) {
			if (pattern != likeReplaceStr) {
				if (pattern == "[*]") {
					output = output.replaceAll(pattern, likeReplaceStr);
				} else if (pattern == "[+]") {
					output = output.replaceAll(pattern, likeReplaceStr);
				} else {
					output = output.replaceAll(pattern, blankReplaceStr);
				}
			}
		}
		if (log.isDebugEnabled()) {
			log.debug("Replace Orig =" + originalStr + ", Output =" + output);
		}
		return output.trim();
	}

	private String getClobString(Object obj) throws Exception {

		if (obj instanceof Clob) {
			Clob clob = (Clob) obj;
			if (clob == null) {
				return new String("");
			}

			if (log.isDebugEnabled()) {
				log.debug("CLOB LENGTH =" +  clob.length());
			}
			return clob.getSubString(1, (int) clob.length());
		}

		return "";

	}
}
