package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.DisciplinarySanctionDao;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppeal;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealOutcome;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealView;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanction;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionOffence;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionView;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

/**
 * Hibernate DAO implementation of Disciplinary Sanctions and Appeals. 
 *
 */
@Repository
public class HibernateDisciplinarySanctionDao extends HibernateBaseDao implements DisciplinarySanctionDao {


	@Override
	public DisciplinarySanction loadDisciplinarySanctionById(Long sanctionId) {
	
		Object obj = getObject(DisciplinarySanction.class, sanctionId);
		
		if (obj instanceof DisciplinarySanction) {
			
			return (DisciplinarySanction)obj;
		}
		
		return null;
		
	}
	
	public List<DisciplinarySanctionView> loadDisciplinarySanctions(Long caseId) {
				
        Session session = getCurrentSession();
        
		Query query = session.createQuery("from DisciplinarySanctionView where caseId =:caseId")
				.setLong("caseId", caseId);
		
		List<DisciplinarySanctionView> list = query.list(); 
		
		return list;
	}
	


	@Override
	public DisciplinarySanctionView loadDisciplinarySanctionViewById(Long sanctionId) {
		
		Session session = getCurrentSession();
	        
		Query query = session.createQuery("from DisciplinarySanctionView where disciplinarySanctionId =:sanctionId")
				.setLong("sanctionId", sanctionId);
		
		List<DisciplinarySanctionView> list = query.list(); 
		
		if (null != list && !list.isEmpty()) {
			
			return (DisciplinarySanctionView)list.get(0);
		}
		return null;
	}
	
   public List<DisciplinaryAppealView> loadDisciplinaryAppeals(Long caseId) {
				
		Session session = getCurrentSession();
		Query query = session.createQuery("from DisciplinaryAppealView where caseId =:caseId")
				.setLong("caseId", caseId);
		
		List<DisciplinaryAppealView> list = query.list(); 
		
		return list;
	}
	
   public List<DisciplinaryAppealView> loadAppealsByCaseIdOrderByAppealedDate(Long caseId) {
		
		Session session = getCurrentSession();
		Query query = session.createQuery("from DisciplinaryAppealView where caseId =:caseId order by appealedDate desc")
				.setLong("caseId", caseId);
		
		List<DisciplinaryAppealView> list = query.list(); 
		
		return list;
	}
   
   public DisciplinaryAppealView loadDisciplinaryAppeal(Long appealId) {
		
		Object obj = getCurrentSession().get(DisciplinaryAppealView.class, appealId);
		
		if (obj instanceof DisciplinaryAppealView) {
			return (DisciplinaryAppealView) obj;
		}
		return null;
	}

	public Object getCiminalAppealById(Class clazz, Long disciplinarySanctionId) {
		
		return getCurrentSession().createQuery("from " + clazz.getName()
                + " where disciplinarySanctionId = " + disciplinarySanctionId).list(); 
	}
	
	public DisciplinaryAppeal getDisciplinaryAppealDetails(Long appealId) {
		
		Session session = getCurrentSession();
		List list = session.createQuery("from DisciplinaryAppeal where appealId = :appealId").setLong("appealId", appealId).list(); 
		
		if (null != list && !list.isEmpty()) {
			
			return (DisciplinaryAppeal)list.get(0);
		}
		
		return null;
	}
	
	public List getObjects(Class clazz, Long disciplinarySanctionId) {
		
		Criteria criteria = getCurrentSession().createCriteria(clazz);
		
		criteria.add(Restrictions.eq("disciplinarySanctionId", disciplinarySanctionId));
		
		return criteria.list();
		 
	}


	public List<CaseContact> loadContactsByCaseId(Long caseId) {
		
		Criteria criteria = getCurrentSession().createCriteria(CaseContact.class);
		
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		return criteria.list();
	 
	}


	public List<DisciplinarySanctionHearing> loadDisciplinaryHearingList(Long sanctionId) {
				
		Session session = getCurrentSession();
		Query query = session.createQuery("from DisciplinarySanctionHearing where disciplinarySanctionId =:sanctionId")
				.setLong("sanctionId", sanctionId);
		List<DisciplinarySanctionHearing> list = query.list(); 
		return list;
	}
	
   public List<DisciplinaryAppealHearing> loadDisciplinaryAppealHearingList(Long appealId) {
				
		Session session = getCurrentSession();
		Query query = session.createQuery("from DisciplinaryAppealHearing where appealId =:appealId")
				.setLong("appealId", appealId);
		List<DisciplinaryAppealHearing> list = query.list(); 
		return list;
	}


	public List<DisciplinarySanctionOffence> loadDisciplinaryOffenceList(Long sanctionId) {
		
		Criteria criteria = getCurrentSession().createCriteria(DisciplinarySanctionOffence.class);
		criteria.add(Restrictions.eq("disciplinarySanctionId", sanctionId));
		List list = criteria.list();
		
		return list;
	}


	public List<DisciplinarySanctionOutcome> loadDisciplinaryOutcomeList(final Long sanctionId) {
		
		Criteria criteria = getCurrentSession().createCriteria(DisciplinarySanctionOutcome.class);
		criteria.add(Restrictions.eq("disciplinarySanctionId", sanctionId));
		List list = criteria.list();
		 
		if (null != list && !list.isEmpty()) {
			
			DisciplinarySanctionOutcome outcome=(DisciplinarySanctionOutcome)list.get(0);
			List<OutcomeAppliedSanction> sanctionsList=loadAppliedSanctions(outcome.getOutcomeId(), "DISCIPLINARY");
			outcome.setOutcomeAppliedSanctions(sanctionsList);	
		}	
		return list;
	}
	
    public List<DisciplinaryAppealOutcome> loadAppealOutcomeList(final Long appealId) {
		

    	Session session = getCurrentSession();
    	
    	String sql = "from DisciplinaryAppealOutcome where appealId=:appealId";
    	
    	Query query = session.createQuery(sql);
    	query.setLong("appealId", appealId);
    	
    	List list =  query.list();
		 
		if (null != list && !list.isEmpty()) {
			 
			DisciplinaryAppealOutcome outcome=(DisciplinaryAppealOutcome)list.get(0);
			
			List<OutcomeAppliedSanction> outcomeSanctionsList = loadAppliedSanctions(
					outcome.getOutcomeId(), 
					CaseUtil.APPLIED_SANCTION_TYPE.DISCIPLINARY_APPEAL.toString());
			
			outcome.setOutcomeAppliedSanctions(outcomeSanctionsList);	
		} 
		return list;
	}
	
	public DisciplinarySanctionHearing loadDisciplinaryHearing(Long hearingId) {
		
		Object obj = getCurrentSession().get(DisciplinarySanctionHearing.class, hearingId);
		if (obj != null) {
			return (DisciplinarySanctionHearing) obj;
		}
		return null;
	}
	
   public DisciplinaryAppealHearing loadDisciplinaryAppealHearing(Long hearingId) {
		
		Object obj = getCurrentSession().get(DisciplinaryAppealHearing.class, hearingId);
		if (obj != null) {
			return (DisciplinaryAppealHearing) obj;
		}
		return null;
	}
	


	public DisciplinarySanctionOffence loadDisciplinaryOffence(Long sanctionId) {		
        String sql = "from DisciplinarySanctionOffence where disciplinarySanctionId=:disciplinarySanctionId";
    	Session session = getCurrentSession();
    	Query query = session.createQuery(sql);
    	query.setLong("disciplinarySanctionId", sanctionId);
    	List res =  query.list();
    	
		if (res != null && !res.isEmpty()) {
			return (DisciplinarySanctionOffence)res.get(0);
		}
		return null;
	}

	public DisciplinarySanctionOutcome loadDisciplinaryOutcome(Long outcomeId) {
		Object obj = getCurrentSession().get(DisciplinarySanctionOutcome.class, outcomeId);
		if (obj != null) {
			return (DisciplinarySanctionOutcome) obj;
		}
		return null;
	}
	
	
	public List<OutcomeAppliedSanction> loadAppliedSanctions(Long outcomeId) {
		
		Session session = getCurrentSession();
		
		String sql = "from OutcomeAppliedSanction where outcomeId=:outcomeId and sanctionType=:sanctionType";
    	Query query = session.createQuery(sql);
    	query.setLong("outcomeId", outcomeId);
    	query.setString("sanctionType", "DISCIPLINARY");
    	
    	List res =  query.list();
		
    	return res;
	
	}
	
	public void deleteAppliedSanctions(List<OutcomeAppliedSanction> list) {
		
		if (null != list && !list.isEmpty()) {
			
			deleteObjects(list);
		}
	
	}
	
	public DisciplinaryAppealOutcome saveDisciplinaryAppealOutcome(DisciplinaryAppealOutcome outcome){
		
		Session session = getCurrentSession();
		session.saveOrUpdate(outcome);
		
		// As DELETE_ORPHANS is not working, has to do it manual. 		
		Query query = session.createQuery("from OutcomeAppliedSanction where outcomeId is null");
		
		List<OutcomeAppliedSanction> list = query.list(); 
		
		if (null != list && !list.isEmpty()) {
			
			deleteObjects(list);
		}
		
		return outcome;
	}
	
    public DisciplinarySanctionOutcome saveDisciplinarySanctionOutcome(DisciplinarySanctionOutcome outcome){
		
		Session session = getCurrentSession();
		session.saveOrUpdate(outcome);
		
		// As DELETE_ORPHANS is not working, has to do it manual. 
		
		Query query = session.createQuery("from OutcomeAppliedSanction where outcomeId is null");

		List<OutcomeAppliedSanction> list = query.list(); 
		
		if (null != list && !list.isEmpty()) {
			
			deleteObjects(list);
		}
		
		return outcome;
	}
    
    @Override
	public List<DisciplinaryAppeal> loadAppealsByParentSanctionId(Long sanctionId) { 
	
		Session session = getCurrentSession();
		
		Query query = session.createQuery("from DisciplinaryAppeal where sanctionId =:sanctionId")
				.setLong("sanctionId", sanctionId);
		
		return query.list();  
		
	}

    @Override
	public List<DisciplinaryAppeal> loadAppealsByParentAppealId(Long appealId) { 
	
		Session session = getCurrentSession();
		
		Query query = session.createQuery("from DisciplinaryAppeal where parentAppealId =:appealId")
				.setLong("appealId", appealId);
		
		return query.list();  
		
	}
}
