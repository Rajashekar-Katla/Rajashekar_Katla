package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.Interview;

public interface InterviewDao extends BaseDao {

	public List getInterviews(Long caseId);

	public Interview loadInterview(Long interviewId);

	public List getInterviewsUploaded(Long caseId);

	public List<Interview> getInterviewsForCPS(Long caseId);

	public Interview updateInterviewFileName(final Long interviewId,
			final String fileName);

	public Long getInterviewFileSize(final long interviewId);

	public Interview downloadInterviewForCps(final Long interviewId,
			final boolean isFileBlobRequired);
}
