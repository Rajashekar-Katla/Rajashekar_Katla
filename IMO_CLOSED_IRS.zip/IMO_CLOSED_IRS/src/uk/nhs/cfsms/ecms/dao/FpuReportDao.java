package uk.nhs.cfsms.ecms.dao;

import uk.nhs.cfsms.ecms.data.fpureport.FpuReport;

public interface FpuReportDao {
	
	public FpuReport saveFpuReport(FpuReport report);
	
	public FpuReport loadFpuReportByCaseId(Long caseId);
		
	public FpuReport loadFpuReportByInfoId(Long infoId);
	
	public FpuReport updateFpuReport(FpuReport report);
	
	public void deleteAllFpuSubTypes(Long caseId);
	

}
