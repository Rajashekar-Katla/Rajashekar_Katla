package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.Message;
import uk.nhs.cfsms.ecms.data.cim.MessageView;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;

public interface MessageDao {

	public Message saveMessage(Message message);

	public Message loadMessage(Long messageId);

	public List<Message> loadMessagesByFromStaffId(String staffId, String state);

	public List<Message> loadMessagesByToStaffId(String staffId, String state);

	public Message updateMessage(Message message);

	/**
	 * NHS restructure changes from CFSMS to Protect.
	 * 
	 * @param user
	 * @param state
	 * @return List of users.
	 */
	public List<MessageView> loadMessagesByToStaffId(SessionUser user,
			String state);

	public MessageView loadMessageView(Long messageId);

	public List<Message> loadMessagesByCaseId(Long caseId);

	public List<Message> loadMessagesByInfoId(Long informationId);

	public List<MessageView> loadMessagesByFromStaffId(SessionUser user);

	/**
	 * This method is responsible for fetching the trashed read messaged for the
	 * given Session User.
	 * 
	 * @param sessionStaff
	 * @param msgState
	 * 
	 * @return List<MessageView>
	 * 
	 * **/
	public List<MessageView> loadTrashMessagesByToStaffId(
			SessionUser sessionStaff, String msgState);

	/**
	 * This method is responsible for fetching the trashed sent messaged for the
	 * given Session User.
	 * 
	 * @param sessionStaff
	 * 
	 * @return List<MessageView>
	 * 
	 * **/
	public List<MessageView> loadTrashMessagesByFromStaffId(
			SessionUser sessionStaff);

	public void forwardMsgsToIMOMember(final String staffName, final String staffId, final Long[] msgIds);
}
