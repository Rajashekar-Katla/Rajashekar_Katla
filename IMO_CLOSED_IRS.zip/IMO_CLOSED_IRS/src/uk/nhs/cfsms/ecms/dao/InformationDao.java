package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.InformationObject;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.ClosedInformationView;
import uk.nhs.cfsms.ecms.data.infoGath.FcrolInformationView;
import uk.nhs.cfsms.ecms.data.infoGath.InfoTransferHistory;
import uk.nhs.cfsms.ecms.data.infoGath.Information;
import uk.nhs.cfsms.ecms.data.infoGath.InformationPermission;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.data.infoGath.Person;
import uk.nhs.cfsms.ecms.data.witness.Witness;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;

public interface InformationDao {

	public InformationTO saveInformation(InformationTO fraud, SessionUser user);

	public InformationTO loadInformationById(Long InformationId);
	
	public InformationTO loadFcrolInformationById(Long InformationId);
	
	public Information loadInformationByIdData(Long informationId);
	
	public void updateInformationData(Information doObj);
	
	public List<InformationTO> loadAllInformation(String staffId);

	public void save(InformationTO info, SessionUser user);

	public void updateInformation(InformationTO informationTO,boolean updatePermission, SessionUser user);
	
	public List<InformationView> loadAllInformationView(SessionUser user, boolean isMine);
	
	public void savePermission(Information info, SessionUser user );
	
	public void updatePermission(Information info, SessionUser user);

	public List<InformationPermission> getInformationPersmissions(Long informationId);
	
	public InformationPermission loadPermissionByInfoIdAndPermType(Long infoId,String permType);
	
	public List<InformationPermission> loadPermissionsByInfoIdAndPermType(Long infoId,String permType);
	
	public InformationPermission loadPermissionByInfoIdAndPermTypeAndValue(Long infoId,String permType,String perm);
	
	public InformationPermission updatePermission(InformationPermission infoPermission);

	public Information loadInformationByCaseId(Long caseId);
	
	public Information loadInformationByCaseId(Long caseId, boolean isCasePersonsOnly);

	public List<InformationView> loadTopInformationView(SessionUser user, Integer rowCount, boolean mineOnly);
	
	public InformationView loadInformationViewById(Long informationId);
	
	public InfoTransferHistory saveInfoTransferHistory(InfoTransferHistory history);
	
	public InfoTransferHistory updateInfoTransferHistory(InfoTransferHistory history);
	
	public InfoTransferHistory loadInfoTransferHistoryById(Long historyId);
	
	public List<InfoTransferHistory> loadInfoTransferHistoryByInfoId(Long infoId);
	
	public InfoTransferHistory loadInfoTransferHistoryByInfoIdState(Long infoId,String state);
	
	public List<InfoTransferHistory> loadInfoTransferHistoryByInfoIdAndTeam(Long historyId,String teamCode);
	
		public InfoTransferHistory updateOldAndAddNewInfoTransferHistory(Long infoId, String newTeamCode, SessionUser user);
	
	public InfoTransferHistory updateInfoTransferHistory(Long infoId,String oldTeamCode,String newTeamCode,String staffId, MessageTO messageTO);
	
	public InformationView loadInformationViewByCaseId(Long caseId);
	
	public boolean isUserAuthorizedToAccessInformation(Long informationId, SessionUser user, boolean state);

	public UserObject getOFMDetailsByInfoId(Long infoId);	
	
	public UserObject getOFMByTeamCode(final String teamCode);
		
	public void saveInfoOnly(InformationObject dto);
	
	public InformationObject loadInfoObjectOnly(Long infoId);
	
	public InformationPermission saveInformationPermission(InformationPermission permission);
	
	// Phase-2 
	public List<FcrolInformationView> loadFcrolInformationView();
	
	public void saveFcrolInformationPermission(List<InformationPermission> list);
	
	public void saveFcrolInformationDiscard(Long infoId,String discard,String staffId,String rejectReason,String regOverride);
	
	public String getTeamCode(String orgCode);
	
	// Phase-3 
	public void updateSubjectToWitness(Witness witness);

	// Phase-4 
	public List<ClosedInformationView> loadClosedInformationView(SessionUser user, String createdByFilter);

	public List<InformationView> loadMyTeamsInformation(SessionUser user);
	
	//Phase-9
	public InfoTransferHistory loadCurrentInfoTransferHistoryByInfoId(Long infoId) ;
	
	// public InfoTransferHistory loadCurrentInfoTransferHistoryByTransferId(Long caseTransferID);
	
	/**
	 * This method is responsible for loading the information transfer history pending for approval for the given user ID.
	 * 
	 * */
	public List<InfoTransferHistory>loadPendingInformationTransfersForUser(String staffID);
	
	public InfoTransferHistory loadNewInfoTransferHistoryByApprover(Long infoId, String staffId);
	
//	public void deleteThreeYearsOldClosedInformation();
	
	public Person loadInformationByCaseIdForCps(Long caseId);
	
	public List<InformationView> loadLCFS_Other_InformationView(final SessionUser user);
	
	public List<ClosedInformationView> loadClosedInformationReportsForIMO(SessionUser user);
	
}