package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.Vehicle;

public interface VehicleDao extends BaseDao {
	
	void save(Vehicle vehicle);
	
	Vehicle load(Long id);

	List<Vehicle> loadVehicles(Long caseId);
	
	void saveAllVehicles(List<Vehicle> vehicles);
	
	List<Vehicle>loadVehiclesByInformation(Long informationId);
	
}
