package uk.nhs.cfsms.ecms.dao.hibernate;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.BaseDao;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
//import org.hibernate.SessionFactory;

@Repository(value="baseDAO")
public class HibernateBaseDao  implements BaseDao {
 
	@PersistenceContext
	private EntityManager entityManager;
	 
	protected final Log logger = LogFactory.getLog(getClass());
	
	protected final Session getCurrentSession(){
		/* Hibernate session - to be moved to JPA soon */
		return entityManager.unwrap(Session.class);
	}
	
	protected final EntityManager getEntityManager(){
		/* Hibernate session - to be moved to JPA soon */
		return entityManager;
	}

	public Object getObject(Class thisClass, Long id) {
		
		return getCurrentSession().get(thisClass, id);
	}

	public List getObjects(Class thisClass) {
		
		return getObjects(thisClass, null);
	}

	public List getObjects(Class thisClass, String orderBy) {
		
		return getCurrentSession().createQuery(
						"from "	+ thisClass.getName()
								+ (orderBy != null ? " order by " + orderBy
										: "")).list();
	}

	public List getObjects(Class thisClass, int offset, int maxResults) {
		
		return getObjects(thisClass, offset, maxResults, null);
	}

	
	public List getObjects(final Class thisClass, final int offset,
			final int maxResults, final String orderBy) {

		List list =  getCurrentSession().createQuery("from " + 
								thisClass.getName() + 
								(orderBy != null ? " order by " + orderBy
										: "")).setFirstResult(offset)
				.setMaxResults(maxResults).list();


		return list;
	}


	public int getObjectCount(final Class thisClass) {
		
		Object resultObj = getCurrentSession().createQuery("select count(obj) from " + thisClass.getName()
								+ " as obj").uniqueResult();


		if (resultObj instanceof BigDecimal) {
			
			BigDecimal result = (BigDecimal) resultObj;
			return result != null ? result.intValue() : 0;

		} else if (resultObj instanceof Integer) {
			
			BigDecimal result = (BigDecimal) resultObj;
			return result != null ? result.intValue() : 0;
		}

		return 0;

	}


	public void saveObject(Object object) {
		
		getCurrentSession().merge(object);
		
	}

	public void saveObjects(List objects) {
		
		if (null != objects) {
			for (Object curr : objects) {
				getCurrentSession().merge(curr);
			}
		}
	}

	public void deleteObject(Object object) {

		try {
			getCurrentSession().delete(object);
		} catch (Exception exp) { 
			exp.printStackTrace();
		}
	}

	public void deleteObjects(List objects) {
		
		for (Object curr : objects) {
			getCurrentSession().delete(curr);
		}
	
	}

	public void evictObject(Object object) {
		
		getCurrentSession().evict(object);
		
	}
	
	public Object mergeObject(Object object) {
		 
		try {
		
			Object obj = getCurrentSession().merge(object);
			
			return obj;
			
		}catch(Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace(); 
		}
		return null;
	}
	
	@Override
	public List<OutcomeAppliedSanction> loadAppliedSanctions(Long outcomeId,
			String sanctionType) {
		
		String sqlStr = "from OutcomeAppliedSanction where outcomeId=:outcomeId and sanctionType=:sanctionType";
		
		Query query = getCurrentSession().createQuery(sqlStr)
				.setLong("outcomeId", outcomeId)
				.setString("sanctionType", sanctionType);
				
		List<OutcomeAppliedSanction> list = query.list();
		 
		return list;
	}
}
