package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.SummonsDao;
import uk.nhs.cfsms.ecms.data.sanction.Summons;

@Repository
public class HibernateSummonsDao extends HibernateBaseDao implements SummonsDao {

	public List<Summons> getSummons(Long criminalSanctionId) {
		List<Summons> result = new ArrayList<Summons>();
		
		DetachedCriteria criteria = DetachedCriteria.forClass(
				Summons.class).add(
						Restrictions.eq("criminalSanctionId", criminalSanctionId));
		
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		result = criteria.getExecutableCriteria(getCurrentSession()).list();
		
		return result;
		
	}	
	
}
