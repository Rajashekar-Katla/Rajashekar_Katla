package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.CriminalAppealView;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionView;
import uk.nhs.cfsms.ecms.data.sanction.PoliceCharge;

public interface CriminalSanctionDao extends BaseDao {
	
	List<CriminalSanctionView> loadCriminalSanctions(Long caseId);
		
	List<PoliceCharge> loadPoliceCharge(Long sanctionId);
	
	PoliceCharge savePoliceCharge(PoliceCharge charge);

	List<CriminalSanctionOutcome> loadCriminalSanctionOutcome(Long sanctionId);

	CriminalSanctionOutcome saveCriminalSanctionOutcome(CriminalSanctionOutcome outcome);
 	
	CriminalSanctionView loadCriminalSanctionView(Long sanctionId);

	List<CriminalAppealView> loadAppealsByParentSanctionId(Long criminalSanctionId);
}
