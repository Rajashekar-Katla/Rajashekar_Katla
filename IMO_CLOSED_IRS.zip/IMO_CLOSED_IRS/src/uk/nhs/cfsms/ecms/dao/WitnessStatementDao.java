package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.witness.WitnessStatement;

public interface WitnessStatementDao {

	public List loadWitnesseStatementsByCaseId(Long caseId,int partNumber, String type);

	public List loadWitnesseStatementsByWitnessId(Long witnessId);

	public List loadStatementsByWitnessIdAndType(Long witnessId,int partNumber, String type);
	
	public WitnessStatement loadWitnessStatementById(Long statementId);
	
	public WitnessStatement downloadWitnessStatementById(final Long statementId,final boolean isFileBlobRequired);

	public WitnessStatement saveWitnessStatement(
			WitnessStatement witnessStatement);

	public WitnessStatement updateWitnessStatement(
			WitnessStatement witnessStatement);
	
	public WitnessStatement updateWitnessStatementFileName(final Long witnessStatementId,
			final String fileName);

	public void deleteWitnessStatement(Long statementId);
	
	public List loadCPSWitnesseStatementsByCaseID(Long caseId, String type);
	
	public Long getWitnessStatementFileSize(final long witnessStatementId);

}
