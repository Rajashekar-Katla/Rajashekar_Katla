package uk.nhs.cfsms.ecms.dao;

import uk.nhs.cfsms.ecms.dto.search.SearchResultsTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;

public interface IndexedSearchDao {

	public SearchResultsTO getCaseIndexedSearchResults(String keywords, SessionUser user);
	
	public SearchResultsTO getCaseIndexedSearchResultsWithFuncation(String keyword);

	public SearchResultsTO getCaseSearchResultDetails(Long searchId, Long caseId, SessionUser user);

	public SearchResultsTO getInformationIndexedSearchResults(String keywords, SessionUser user);

	public SearchResultsTO getInformationResultDetails(Long searchId, Long caseId, SessionUser user);
}
