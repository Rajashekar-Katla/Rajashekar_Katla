package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppeal;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppealView;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionOutcome;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionView;

public interface CivilSanctionDao extends BaseDao {
	
	List<CivilSanctionView> loadCivilSanctions(Long caseId);
	
	CivilSanctionOutcome loadCivilSanctionOutcome(Long civilSanctionId);
	
	List<CivilAppeal> loadCivilAppeals(Long caseId);
	
	List<CivilSanctionOutcome> loadCivilSanctionOutcomeForCase(Long caseID) ;

	List<CivilAppealView> loadAppealsByParentSanctionId(Long sanctionId);
	
}
