package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;

public interface BaseDao {

	Object getObject(Class thisClass, Long id);

    List getObjects(Class thisClass);

    List getObjects(Class thisClass, String orderBy);

    List getObjects(Class thisClass, int offset, int maxResults);

    List getObjects(Class thisClass, int offset, int maxResults, String orderBy);

    int getObjectCount(Class thisClass);

    void saveObject(Object object);
    
    void saveObjects(List objects);
    
    void deleteObject(Object object);

    void deleteObjects(List objects);
    
    void evictObject(Object object);
    
    Object mergeObject(Object object);
    
	public List<OutcomeAppliedSanction> loadAppliedSanctions(Long outcomeId,
			String sanctionType);
    
}
