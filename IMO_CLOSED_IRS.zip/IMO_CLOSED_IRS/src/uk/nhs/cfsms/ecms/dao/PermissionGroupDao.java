package uk.nhs.cfsms.ecms.dao;

import uk.nhs.cfsms.ecms.data.common.PermissionGroup;

public interface PermissionGroupDao {
	
	PermissionGroup save(PermissionGroup permissionGroup);
	PermissionGroup load(long id);
}
