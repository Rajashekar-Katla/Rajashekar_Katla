package uk.nhs.cfsms.ecms.dao.hibernate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.CaseActionBookDao;
import uk.nhs.cfsms.ecms.data.cim.CaseActionBook;
import uk.nhs.cfsms.ecms.data.cim.CaseActionBookAttachment;
import uk.nhs.cfsms.ecms.dto.search.ActionSearchTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.model.CaseActionFilterCriteria;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * @author Jshrivastav
 *
 *         This Class is representing the DAO layer for the Case Action Book
 *         Functionality. Provide all the DAO method required to service the
 *         user requirement against the case action Book.
 * 
 * */
@Repository(value = "caseActionBookDao")
public class HibernateCaseActionBookDao extends HibernateBaseDao implements
		CaseActionBookDao {

	/**
	 * This method is responsible for generating a new Action Number for a given
	 * case ID By having a current count of exiting case action book for the
	 * case and return the next to be used.
	 * 
	 * @param caseID
	 * 
	 * */
	public String getCaseActionBookNumber(Long caseId) {
		String actionNumber = null;

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBook.class);
		criteria.add(Restrictions.eq("caseID", caseId));
		criteria.addOrder(Order.desc("actionNumber"));
		@SuppressWarnings("unchecked")
		List<CaseActionBook> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		if (!list.isEmpty()) {

			String currentHighestActionNumber = ((CaseActionBook) list.get(0))
					.getActionNumber() + "";
			actionNumber = ""
					+ ((Integer.parseInt(currentHighestActionNumber)) + 1);

		} else {
			actionNumber = "1";
		}

		return actionNumber;
	}

	/**
	 * This method is responsible for saving a new case Action book in the
	 * system
	 * 
	 * @param cab
	 * 
	 * */
	public CaseActionBook saveCaseActionBook(CaseActionBook cab) {

		CaseActionBook currentAction = loadCaseActionBookByCABCaseIdAndCABNumber(cab);

		if (null == currentAction) {
			currentAction = (CaseActionBook) getCurrentSession().merge(cab);
		} else {
			cab.setCaseActionBookId(currentAction.getCaseActionBookId());
			getCurrentSession().saveOrUpdate(cab);
		}
		return currentAction;
	}

	/**
	 * This method is responsible for retrieving an case action book for a given
	 * ID
	 * 
	 * @param caseActionBookId
	 * 
	 * @return CaseActionBook
	 * 
	 * */
	public CaseActionBook loadCaseActionBook(Long caseActionBookId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBook.class);
		criteria.add(Restrictions.eq("caseActionBookId", caseActionBookId));
		@SuppressWarnings("unchecked")
		List<CaseActionBook> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}

	/**
	 * This method is responsible for retrieving an case action book for a given
	 * CASE ID & CASE ACTION BOOK NUMBER.
	 * 
	 * @param caseActionBook
	 * 
	 * @return CaseActionBook
	 * 
	 * */
	public CaseActionBook loadCaseActionBookByCABCaseIdAndCABNumber(
			CaseActionBook caseActionBook) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBook.class);
		criteria.add(Restrictions.eq("caseID", caseActionBook.getCaseID()));
		criteria.add(Restrictions.eq("actionNumber",
				caseActionBook.getActionNumber()));
		@SuppressWarnings("unchecked")
		List<CaseActionBook> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}

	/**
	 * This method is responsible for updating an case action book in system.
	 * 
	 * @param cab
	 * 
	 * @return CaseActionBook
	 * 
	 * */
	public CaseActionBook updateCaseActionBook(CaseActionBook cab) {

		return (CaseActionBook) getCurrentSession().merge(cab);
	}

	/**
	 * This method is responsible for loading all case action books for a given
	 * case ID in system.
	 * 
	 * @param caseId
	 * 
	 * @return java.util.List<CaseActionBook>
	 * 
	 * */
	public java.util.List<CaseActionBook> loadCaseActionBookByCaseId(Long caseId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBook.class);
		criteria.add(Restrictions.eq("caseID", caseId));
		criteria.addOrder(Order.desc("actionNumber"));
		@SuppressWarnings("unchecked")
		java.util.List<CaseActionBook> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		return list;
	}

	/**
	 * This method is responsible for loading all case action books with in the
	 * given starting and ending range for a given case ID in system.
	 * 
	 * @param caseId
	 * @param startingActionID
	 * @param endingActionID
	 * 
	 * @return java.util.List<CaseActionBook>
	 * 
	 * */
	public java.util.List<CaseActionBook> loadCaseActionBookByCaseId(
			Long caseId, Long startingActionID, Long endingActionID) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBook.class);
		criteria.add(Restrictions.eq("caseID", caseId));
		criteria.add(Restrictions.between("actionNumber", startingActionID,
				endingActionID));
		criteria.addOrder(Order.desc("dateRecorded"));
		@SuppressWarnings("unchecked")
		java.util.List<CaseActionBook> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		return list;
	}

	/**
	 * This method is responsible for loading all case action books for a given
	 * case ID in system.
	 * 
	 * @param caseId
	 * 
	 * @return java.util.List<CaseActionBook>
	 * 
	 * */
	public java.util.List<CaseActionBook> loadCaseActionBookByCaseId(
			Long caseId, String actionStatus) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBook.class);
		criteria.add(Restrictions.eq("caseID", caseId));

		if (actionStatus.equalsIgnoreCase("3"))
			criteria.add(Restrictions.eq("actionStatus", actionStatus));
		else {
			if (null != actionStatus && actionStatus.contains(",")) {
				String s[] = actionStatus.split(",");

				if (s != null)
					criteria.add(Restrictions.in("actionStatus", s));
			}

		}

		criteria.addOrder(Order.desc("dateRecorded"));
		@SuppressWarnings("unchecked")
		java.util.List<CaseActionBook> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		return list;
	}

	/**
	 * This method is responsible for loading all case action books with in the
	 * given starting and ending range for a given case ID in system.
	 * 
	 * @param caseId
	 * @param startingActionID
	 * @param endingActionID
	 * 
	 * @return java.util.List<CaseActionBook>
	 * 
	 * */
	public java.util.List<CaseActionBook> loadCaseActionBookByCaseId(
			Long caseId, Long startingActionID, Long endingActionID,
			String actionStatus) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBook.class);
		criteria.add(Restrictions.eq("caseID", caseId));

		if(null != actionStatus){
		if (actionStatus.equals("3")) {

			criteria.add(Restrictions.eq("actionStatus", actionStatus));

		} else if (null != actionStatus && actionStatus.contains(",")) {

			String strArray[] = actionStatus.split(",");

			if (strArray != null) {
				criteria.add(Restrictions.in("actionStatus", strArray));
			}
		}
	}
		criteria.add(Restrictions.between("actionNumber", startingActionID,
				endingActionID));
		criteria.addOrder(Order.desc("dateRecorded"));

		@SuppressWarnings("unchecked")
		java.util.List<CaseActionBook> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		return list;
	}

	/**
	 * This method is responsible for loading all case action books attachments
	 * for a given action ID in system.
	 * 
	 * @param actionID
	 * 
	 * @return java.util.List<CaseActionBookAttachment>
	 * 
	 */
	public List<CaseActionBookAttachment> listAttachments(Long actionID) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBookAttachment.class);

		criteria.add(Restrictions.eq("actionID", actionID));

		List<CaseActionBookAttachment> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		return list;
	}

	/**
	 * This method is responsible for saving a case action books attachment for
	 * a given action ID in system.
	 * 
	 * @param caseActionBookAttachment
	 * 
	 * */
	public void saveCaseActionBookAttachment(
			CaseActionBookAttachment caseActionBookAttachment) {

		getCurrentSession().merge(caseActionBookAttachment);
	}

	/**
	 * This method is responsible for downloading a case action books attachment
	 * for a given attachment ID in system.
	 * 
	 * @param caseActionBookAttachment
	 * 
	 * */
	public CaseActionBookAttachment downloadCaseActionBookAttachment(
			Long attachmentID) {
		return (CaseActionBookAttachment) getCurrentSession().get(
				CaseActionBookAttachment.class, attachmentID);
	}

	public CaseActionBookAttachment loadCaseActionBookAttachment(
			final Long attachmentID) {
		CaseActionBookAttachment actionBookAttachment = null;

		Criteria criteria = getCurrentSession().createCriteria(
				CaseActionBookAttachment.class);
		criteria.add(Restrictions.eq("actionAttachmentID", attachmentID));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("actionAttachmentID"),
				"actionAttachmentID");
		projectionList.add(Projections.property("attachmentName"),
				"attachmentName");
		projectionList.add(Projections.property("attachmentType"),
				"attachmentType");
		projectionList.add(Projections.property("attachmentBlob"),
				"attachmentBlob");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers
				.aliasToBean(CaseActionBookAttachment.class));

		@SuppressWarnings("unchecked")
		List<CaseActionBookAttachment> list = criteria.list();

		actionBookAttachment = list.get(0);

		return actionBookAttachment;
	}

	/**
	 * This method is responsible for saving a case action books attachment for
	 * a given action ID in system.
	 * 
	 * @param actionID
	 * 
	 * */
	@SuppressWarnings("unchecked")
	public String getCaseActionBookAttachmentNumber(Long actionID) {

		List<CaseActionBookAttachment> list = new ArrayList<CaseActionBookAttachment>();

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBookAttachment.class);

		criteria.add(Restrictions.eq("actionID", actionID));

		list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return "" + (list.size() + 1);
	}

	/**
	 * This method is responsible for loading all case action books that are due
	 * for actions with in the number of days as on current date in the system.
	 * 
	 * @param inNumberOfDays
	 * 
	 * @return java.util.List<CaseActionBook>
	 * @throws ParseException 
	 * 
	 * */
	public java.util.List<CaseActionBook> loadDueCaseActionBooks(
			int inNumberOfDays) throws ParseException {

		// Calendar currentDate = Calendar.getInstance();
		Calendar endingDate = Calendar.getInstance();
		endingDate.add(Calendar.DATE, inNumberOfDays);
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		String newDate = format.format(endingDate.getTime());
		
		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBook.class);
		// criteria.add(Restrictions.between("dueDate", currentDate.getTime(),
		// endingDate.getTime()));
		criteria.add(Restrictions.eq("dueDate", new Date(format.parse(newDate).getTime())));
		criteria.add(Restrictions.ne("actionStatus", "3"));

		criteria.addOrder(Order.desc("dateRecorded"));

		java.util.List<CaseActionBook> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		return list;
	}

	/**
	 * This method is responsible for loading all case action books for the
	 * search criteria..
	 * 
	 * @param ActionSearchTO
	 * 
	 * @return ActionSearchTO
	 * 
	 * */
	@Override
	public ActionSearchTO getActionSearchResults(final ActionSearchTO searchTO,
			final SessionUser user) {

		final StringBuffer hql = new StringBuffer("SELECT distinct ca FROM ");
		hql.append("CaseActionSearchObject ca WHERE (ca.allocatedBy = :userId or ca.allocatedTo = :userId)");

		if (searchTO.isNotEmptyCaseNumber()) {

			hql.append(" AND lower(ca.caseNumber) like '%")
					.append(EcmsUtils.removeSpecialChars(
							searchTO.getCaseNumber().toLowerCase()).trim())
					.append("%' ");
		}
		if (searchTO.isNotEmptyOperationName()) {

			hql.append(" AND lower(ca.caseOperationName) like '%")
					.append(EcmsUtils.removeSpecialChars(
							searchTO.getOperationName().toLowerCase()).trim())
					.append("%' ");
		}
		if (searchTO.isValidDateRange()) {

			hql.append(" AND ca.dateRecorded between :startDate and :endDate ");
		}
		String actionStatus = searchTO.getActionStatus();

		if (ECMSConstants.CASE_ACTION_COMPLETED.equals(actionStatus)) {

			hql.append(" AND ca.actionStatus = 3 ");

		} else if (ECMSConstants.CASE_ACTION_OUSTANDING.equals(actionStatus)) {

			hql.append(" AND ca.actionStatus in (1,2) ");
		}
		hql.append(" ORDER BY ca.caseID, ca.actionNumber DESC");

		Query query = getCurrentSession().createQuery(hql.toString());
		if (searchTO.isValidDateRange()) {
			query.setParameter("startDate", searchTO.getStartDate());
			query.setParameter("endDate", searchTO.getEndDate());
		}
		query.setParameter("userId", user.getStaffId());

		List list = query.list();
		searchTO.setSearchResults(list);

		return searchTO;
	}

	@Override
	public List<CaseActionBook> loadCaseActionBook(
			CaseActionFilterCriteria filter) throws ServiceException {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseActionBook.class);

		if (null != filter.getCaseId()) {

			criteria.add(Restrictions.eq("caseID", filter.getCaseId()));
		}
		String actionStatus = filter.getStatus() == null ? "" : filter
				.getStatus();

		if (actionStatus.equalsIgnoreCase("3")) {

			criteria.add(Restrictions.eq("actionStatus", actionStatus.trim()));

		} else if (null != actionStatus && actionStatus.contains(",")) {

			String s[] = actionStatus.split(",");

			if (s != null) {
				criteria.add(Restrictions.in("actionStatus", s));
			}
		}
		if (filter.getFirstActionNumber() != null
				&& filter.getLastActionNumber() != null) {

			criteria.add(Restrictions.between("actionNumber",
					filter.getFirstActionNumber(), filter.getLastActionNumber()));
		}
		if (StringUtils.isNotBlank(filter.getOrderBy())) {

			if (filter.isAscending()) {

				criteria.addOrder(Order.asc(filter.getOrderBy().trim()));
			} else {
				criteria.addOrder(Order.desc(filter.getOrderBy().trim()));
			}
		} else {
			criteria.addOrder(Order.desc("dateRecorded"));
		}
		@SuppressWarnings("unchecked")
		List<CaseActionBook> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		return list;
	}

}
