package uk.nhs.cfsms.ecms.dao;

import java.text.ParseException;
import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.infoGath.SubjectInformation;
import uk.nhs.cfsms.ecms.data.witness.Witness;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;

public interface CaseContactDao {

	public CaseContactTO loadContactById(Long contactId);

	public CaseContactTO saveContact(CaseContactTO contact);

	public void updateContact(CaseContactTO contact);

	public void deleteContact(CaseContactTO contact);

	public void updateCaseContactToSubject(SubjectInformation subject);

	public void updateCaseContactToWitness(Witness witness);

	public void mergeContact(CaseContactTO contactTO);
	
	public List<CaseContactTO>loadContactsByInformation(Long informationId);
	
	public List<CaseContact> loadCaseContactByNativeSql(final String firstName,
			final String lastName, final String dob) throws ParseException;
	
	public CaseContact findContactByIdForWitnessLookupUser(final Long contactId);
}
