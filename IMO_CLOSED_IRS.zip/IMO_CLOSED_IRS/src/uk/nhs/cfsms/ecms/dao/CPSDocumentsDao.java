package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CPSDocumentsNamingRules;
import uk.nhs.cfsms.ecms.data.cim.CPSDocumentsView;
import uk.nhs.cfsms.ecms.data.cim.CPSFileNamingRulesDocument;
import uk.nhs.cfsms.ecms.data.cim.CPSMailFormFields;
import uk.nhs.cfsms.ecms.data.cps.CPSRequestTbl;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface CPSDocumentsDao {

	/**
	 * This DAO Method is responsible for saving the state CPS document request.
	 * 
	 * */
	CPSRequestTbl save(CPSRequestTbl cpsDocReq);

	/**
	 * This DAO Method is responsible for updating the state CPS document
	 * request.
	 * 
	 * */
	CPSRequestTbl update(CPSRequestTbl cpsDocReq);

	List<CPSDocumentsView> loadAllCPSDocsRequestsByNativeSql(final long caseID);

	/**
	 * This method is responsible for retrieving all requests history.
	 * 
	 * */
	List<CPSRequestTbl> loadAllRequestsHistory(final String staffID,
			final long caseID);

	List<CPSDocumentsNamingRules> getCPSDocumentsNamingRules();

	void saveCPSFileNamingRulesDocument(
			final CPSFileNamingRulesDocument cpsFileNamingRulesDocument);

	CPSFileNamingRulesDocument loadCPSFileNamingRulesDocument()
			throws ServiceException;

	List<CPSMailFormFields> getCPSFormFields();

	String getCPSDocsRequestorStaffID(final long caseID);

	List<CPSDocumentsView> loadAllCPSDocsRequestsByNativeSql_ToApprove(
			final String staffID, long caseID);

	List<CPSDocumentsView> loadAllApprovedCPSDocsByNativeSql(
			final String staffID, long caseID);
}
