package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.CIUMessagesReceiverDao;
import uk.nhs.cfsms.ecms.data.common.CIUMessagesReceiver;
import uk.nhs.cfsms.ecms.data.common.IMOMessagesReceiver;

@Repository(value = "ciuMessageReceiverRepository")
public class HibernateCIUMessagesReceiver extends HibernateBaseDao implements
		CIUMessagesReceiverDao {

	@Override
	public String getActiveStaffId() {
		Session session = getCurrentSession();
		Query query = session
				.createQuery("select ciuStaffId from CIUMessagesReceiver where status = :active");
		query.setParameter("active", "A");
		String ciuStaffId = (String) query.list().get(0);
		return ciuStaffId;	
	}

	@Override
	public void activateUserToReceiveMessages(String staffId) {
		deActivateExistingActiveUser();
		activateUser(staffId);

	}

	@Override
	public List<CIUMessagesReceiver> getAllCIUMessageReceivers() {
		final DetachedCriteria criteria = DetachedCriteria
				.forClass(IMOMessagesReceiver.class);
		@SuppressWarnings("unchecked")
		final List<CIUMessagesReceiver> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		return list	;
	}

	private void deActivateExistingActiveUser() {
		final String activeStaffId = getActiveStaffId();
		Session session = getCurrentSession();
		Query update = session
				.createQuery("update CIUMessagesReceiver set status=:active where CIU_STAFF_ID = :staffId");
		update.setParameter("active", "D");
		update.setParameter("staffId", activeStaffId);
	}

	private void activateUser(final String staffId) {
		Session session = getCurrentSession();
		Query query = session
				.createQuery("update CIUMessagesReceiver set status=:active where CIU_STAFF_ID = :staffId");
		query.setParameter("active", "A");
		query.setParameter("staffId", staffId);
	}
}
