package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.CivilAppealDao;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppealOutcome;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppealView;

@Repository
public class HibernateCivilAppealDao  extends HibernateBaseDao  implements CivilAppealDao {

	
	@Override
	public List<CivilAppealView> loadCivilAppealsByCaseId(Long caseId) {
		
		String hSql = " Select cv from CivilAppealView cv  where cv.sanction.caseId =:caseId order by cv.id desc";
		
		Query query = getCurrentSession().createQuery(hSql);
		query.setParameter("caseId", caseId);
		
		List<CivilAppealView> appeals = query.list();
		
		
		return appeals;
	}

	@Override
	public List<CivilAppealOutcome> loadAppealOuctomesForCaseID(Long caseID) {
		
		//String hql = "from  CivilAppealOutcome where forAppeal.sanctioncaseId :=caseID";
		Query query = getCurrentSession().getNamedQuery("getOutcomesForCase");
		query.setParameter("caseID", caseID);
		List<CivilAppealOutcome> outcomes = query.list();
		return outcomes;
	}

	@Override
	public CivilAppealOutcome loadAppealOutcomeForAppealID(Long appealID) {
		Query query = getCurrentSession().createQuery("Select co from CivilAppealOutcome co, CivilAppeal ca where co.forAppeal.id =:appealID");
		query.setParameter("appealID", appealID);
		List<CivilAppealOutcome> outcomes = query.list();
		return outcomes == null || outcomes.isEmpty() ? null : outcomes.get(0) ;
	}
	
	public List<CivilAppealOutcome> loadAppealOutcomeForCivilSanctionId(Long civilSanctionId) {
		
		Query query = getCurrentSession().createQuery("Select co from CivilAppealOutcome co where forAppeal.sanction.civilSanctionId = :civilSanctionId ");
		query.setParameter("civilSanctionId", civilSanctionId);
		List<CivilAppealOutcome> outcomes = query.list();
		return outcomes;
	}

	@Override
	public List<CivilAppealView> loadAppealsByParentAppealId(Long appealId) {
		//outcome: (CivilAppealOutcome) -> CIVIL_APPEAL_OUTCOME_TBL,  forAppeal:(CivilAppeal)-> CIVIL_APPEAL_TBL
		//-- from CivilAppealView where appealId =:appealId";		
		
		String hSql = " Select cv from CivilAppealView cv where cv.parentAppealId =:appealId";
		
		Query query = getCurrentSession().createQuery(hSql);
		
		query.setParameter("appealId", appealId);
		
		List<CivilAppealView> appeals = query.list();
		
		
		return appeals;
	}
	
	
}
