package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseTransfer;

public interface CaseTransferDao {
	
	public CaseTransfer loadCaseTransferById(Long transferId);
	
	public CaseTransfer saveCaseTransfer(CaseTransfer caseTransfer);
	
	public CaseTransfer updateCaseTransfer(CaseTransfer caseTransfer);
	
	public List<CaseTransfer> loadLcfsTransfers(String staffId,String[] state,boolean received);
	
	public List<CaseTransfer> loadCfsTransfers(String[] teamCodes,String staffId,String[] state,boolean received);
	
	public List<CaseTransfer> loadPendingApprovalCfsTransfers(String[] teamCodes);
	
	public List<CaseTransfer> loadPendingApprovalLcfsTransfers(String[] teamCodes);
	
	public List<CaseTransfer> loadCaseLcfsTransfersByCaseId(Long caseIDLong);
	
	public List<CaseTransfer> loadCaseCfsTransfersByCaseId(Long caseIDLong);
	
	public List<CaseTransfer> loadPendingTransfersByCaseId(Long caseId);
	
	
	
	}
