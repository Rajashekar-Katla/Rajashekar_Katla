package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.OrganisationDao;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.OrganisationTeamCode;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;

@Repository
public class HibernateOrganisationDao extends HibernateBaseDao implements
		OrganisationDao {

	public List<Organisation> loadAllOrganisations() {

		Criteria criteria = getCurrentSession().createCriteria(
				Organisation.class);
		return criteria.list();
	}

	public Organisation loadOrganisationByOrgCode(String orgCode) {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				Organisation.class).add(Restrictions.idEq(orgCode));

		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (Organisation) list.get(0);
		}

		return null;
	}

	public List<Organisation> loadAllOrganisationsByOrgName(String keyword) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(Organisation.class);

		if (keyword != null && keyword.trim().length() > 0) {
			criteria.add(Restrictions.like("orgName", keyword.toUpperCase(),
					MatchMode.ANYWHERE));
		}
		criteria.add(Restrictions.eq("statusCode", "A"));
		criteria.add(Restrictions.isNull("closeDate"));
		criteria.addOrder(Order.asc("orgName"));

		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}

	/**
	 * Check for respCode which could be org code or region code...
	 */
	public List<Organisation> loadAllOrganisationsByOrgName(
			final String keyword, final String staffId) {

		StringBuffer sbHQL = new StringBuffer("select org");
		sbHQL.append(" from Organisation as org");
		sbHQL.append(" where org.orgCode in");
		sbHQL.append(" (select resp.respCode from AllUserResponsibilities as resp where resp.endDate is null and resp.staffId="
				+ "'" + staffId + "')");
		sbHQL.append(" and org.orgName like");
		sbHQL.append(" '%").append(keyword.toUpperCase().replaceAll("'", "%"))
				.append("%'");
		sbHQL.append(" and org.statusCode = 'A'");
		sbHQL.append(" and org.closeDate is null");
		sbHQL.append(" order by org.orgName asc");
		List list = getCurrentSession().createQuery(sbHQL.toString()).list();

		return list;
	}

	public List<Organisation> loadAllTeams() {

		StringBuffer sbHQL = new StringBuffer(" select distinct");
		sbHQL.append(" org from Organisation org,");
		sbHQL.append(" TeamCodes team  ");
		sbHQL.append(" where org.orgCode = team.orgCode and team.status ='A' and team.teamCode not in ('FPU') order by org.orgCode");

		List list = getCurrentSession().createQuery(sbHQL.toString()).list();
		/*		List list = getHibernateTemplate().executeFind(new HibernateCallback() {

					public Object doInHibernate(Session arg0)
							throws HibernateException, SQLException {
						StringBuffer sbHQL = new StringBuffer(" select distinct");
						sbHQL.append(" org from Organisation org,");
						sbHQL.append(" TeamCodes team  ");
						sbHQL.append(" where org.orgCode = team.orgCode and team.status ='A' and team.teamCode not in ('FPU') order by org.orgCode");
						Query query = arg0.createQuery(sbHQL.toString());
						return query.list();
					}
				});
		*/
		return list;

	}

	public List<TeamCodes> loadAllTeamCodes() {
		DetachedCriteria criteria = DetachedCriteria.forClass(TeamCodes.class);
		criteria.add(Restrictions.eq("status", "A"));
		criteria.add(Restrictions.ne("teamCode", "FPU"));
		criteria.addOrder(Order.asc("teamCode"));
		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();
		return list;
	}

	public OrganisationTeamCode loadTeamCodeByOrgCode(String orgCode) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(OrganisationTeamCode.class);
		criteria.add(Restrictions.eq("orgCode", orgCode));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();
		if (null != list && !list.isEmpty()) {
			return (OrganisationTeamCode) list.get(0);
		}
		return null;
	}

}
