package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.OrganisationTeamCode;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;

public interface OrganisationDao {

	public List<Organisation> loadAllOrganisations();

	public Organisation loadOrganisationByOrgCode(String orgCode);

	public List<Organisation> loadAllOrganisationsByOrgName(String keyword);

	public List<Organisation> loadAllOrganisationsByOrgName(String keyword,
			String staffId);

	public List<Organisation> loadAllTeams();

	public List<TeamCodes> loadAllTeamCodes();

	public OrganisationTeamCode loadTeamCodeByOrgCode(String org_code);

}
