package uk.nhs.cfsms.ecms.dao;

import uk.nhs.cfsms.ecms.data.cim.Md5Users;


public interface UserDao extends BaseDao {
	
	public Md5Users loadUser(String staffId);
	
	public Md5Users saveUsers(Md5Users user);
	
	public Md5Users updateUsers(Md5Users user);
	
	public void  deleteUsers(Md5Users user); 

}
