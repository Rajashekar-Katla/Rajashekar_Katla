package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.AppealHearing;

public interface AppealHearingDao extends BaseDao {


	public AppealHearing loadAppealHearing(Long appearanceId);
	
	public List<AppealHearing> loadAppealHearingsByAppealId(
			Long appealId); 
	
	public List<AppealHearing> loadCourtHearingsByTypeAndAppealId(
			Long appealId,String sanctionType);
	
	public AppealHearing getLatestHearingByType(Long id, String type);

	public String loadLatestAppealHearingCourtName(Long appealId);
  

}
