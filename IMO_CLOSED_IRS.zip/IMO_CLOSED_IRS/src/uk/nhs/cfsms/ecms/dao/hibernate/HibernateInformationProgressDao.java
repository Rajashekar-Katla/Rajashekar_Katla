package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.InformationProgressDao;
import uk.nhs.cfsms.ecms.data.cim.InformationProgress;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

@Repository(value = "informationProgressDao")
public class HibernateInformationProgressDao extends HibernateBaseDao implements
		InformationProgressDao {

	@Override
	public Long generateMinuteNumber(Long informationId)
			throws ServiceException {

		final String sql = "select max(to_number(MINUTE_NO)) as sequence from INFORMATION_PROGRESS_TBL where INFORMATION_ID = "
				+ informationId;
		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.addScalar("sequence");
		List<?> list = query.list();

		if (null == list || null == list.get(0)) {
			return 1l;
		}

		String currentSeq = list.get(0).toString();

		if (StringUtils.isEmpty(currentSeq)) {
			return 1l;
		}

		return new Long(currentSeq) + 1;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<InformationProgress> loadInformationProgresses(Long infoId) {

		List<InformationProgress> list = new ArrayList<InformationProgress>();

		DetachedCriteria criteria = DetachedCriteria
				.forClass(InformationProgress.class)
				.add(Restrictions.eq("informationId", infoId))
				.addOrder(Order.asc("minuteNumber"));

		list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}

	@Override
	public void saveInformationProgress(InformationProgress informationProgress)
			throws ServiceException {
		getCurrentSession().save(informationProgress);
	}

}
