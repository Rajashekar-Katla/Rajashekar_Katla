package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.InvestigationDao;
import uk.nhs.cfsms.ecms.data.cim.InvestigationPlan;

/**
 * Hibernate implementation of Case Investigation DAO
 * 
 */
@Repository
public class HibernateInvestigationDao extends HibernateBaseDao implements
		InvestigationDao {

	public InvestigationPlan loadInvestigationPlanById(Long investigationId) {
		
		DetachedCriteria criteria = DetachedCriteria.forClass(
				InvestigationPlan.class).add(Restrictions.idEq(investigationId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();
		if (list != null && !list.isEmpty()) {
			return (InvestigationPlan) list.get(0);
		}
		return null;
	}

	public InvestigationPlan saveInvestigationPlan(InvestigationPlan hibernate) {

		//Long investmentID = (Long) this.getHibernateTemplate().save(hibernate);
		return (InvestigationPlan) getCurrentSession().merge(hibernate);
	}
	
	public void updateInvestigationPlan(InvestigationPlan hibernate) {

		getCurrentSession().merge(hibernate);
	}	

	public void deleteInvestigationPlan(InvestigationPlan plan) {

		InvestigationPlan hibernate = this.loadInvestigationPlanById(plan.getInvestigationId());

		if (hibernate != null) {
			getCurrentSession().delete(hibernate);
		}
	}

	public List<InvestigationPlan> loadAllInvestigationPlansByCaseId(Long caseId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(
				InvestigationPlan.class).add(Restrictions.eq("caseId", caseId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}


}
