package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.IMOMessagesReceiver;

public interface IMOMessagesReceiverDao {

	String getActiveStaffId();

	void activateUserToReceiveMessages(String staffId);

	List<IMOMessagesReceiver> getAllIMOMessageReceivers();
}
