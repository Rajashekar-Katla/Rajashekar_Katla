package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.RegionCode;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;

public interface RegionCodeDao {

	public List<RegionCode> loadAllRegionCode();
	
	public List<TeamCodes> loadAllTeamCodes();
	
	public List listTeamsByTeamCode(String[] teams);
}
