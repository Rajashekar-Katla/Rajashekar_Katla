package uk.nhs.cfsms.ecms.dao;

import uk.nhs.cfsms.ecms.dto.user.SessionUser;

public interface InterceptDao {

	public boolean authorizeUserByACL(SessionUser user, Long interceptId);
		
}
