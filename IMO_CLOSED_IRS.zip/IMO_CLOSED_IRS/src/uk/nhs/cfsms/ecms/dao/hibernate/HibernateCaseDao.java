package uk.nhs.cfsms.ecms.dao.hibernate;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.CaseDao;
import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.cim.CaseClosure;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.cim.CaseNumber;
import uk.nhs.cfsms.ecms.data.cim.CaseObject;
import uk.nhs.cfsms.ecms.data.cim.CasePermission;
import uk.nhs.cfsms.ecms.data.cim.CaseSummaryInformation;
import uk.nhs.cfsms.ecms.data.cim.CaseUpdate;
import uk.nhs.cfsms.ecms.data.cim.InvestigationPlan;
import uk.nhs.cfsms.ecms.data.cim.TempConfCase;
import uk.nhs.cfsms.ecms.data.common.OrganisationTeamCode;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.search.CaseSearchFormTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.IMOMessageReceiverService;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.StringUtilities;

/**
 * Hibernate implementation for Case DAO (Data Access Object).
 * 
 */
@Repository
public class HibernateCaseDao extends HibernateBaseDao implements CaseDao {

	@Autowired
	private IMOMessageReceiverService imoMessagereceiverService;

	public Case loadCase(Long id) {

		Case c = (Case) getCurrentSession().get(Case.class, id);
		return c;
	}

	public String loadCaseNumber(final Long caseID) {
		final Criteria criteria = getCurrentSession()
				.createCriteria(Case.class);
		criteria.add(Restrictions.eq("caseId", caseID));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("caseNumber"), "caseNumber");
		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers.aliasToBean(Case.class));
		@SuppressWarnings("unchecked")
		final List<Case> cases = criteria.list();
		final String caseNumber = cases.get(0).getCaseNumber();
		return caseNumber;
	}

	public String loadCPSURN(final Long caseID) {
		final Criteria criteria = getCurrentSession()
				.createCriteria(Case.class);
		criteria.add(Restrictions.eq("caseId", caseID));
		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("cpsURN"), "cpsURN");
		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers.aliasToBean(Case.class));
		@SuppressWarnings("unchecked")
		final List<Case> cases = criteria.list();
		final String cpsURN = cases.get(0).getCpsURN();
		return cpsURN;
	}

	public List<CaseObject> loadCases() {

		return getCurrentSession().createQuery("FROM CaseObject").list();

	}

	public List<CaseObject> loadCases(final boolean regionalCode,
			final boolean overLoaded, final String[] responsibilites) {

		final StringBuffer hql = new StringBuffer();
		hql.append("SELECT distinct c FROM CasePermission cp, CaseObject c WHERE");
		hql.append(" c.caseId = cp.caseId AND c.state IN ");
		this.appendCaseStatusType(hql, true, false, false);

		hql.append(" AND c.isOverLoadedCase = " + (overLoaded ? "'Y'" : "'N'"));

		if (regionalCode) {

			hql.append(" AND cp.permissionType = '")
					.append(ECMSConstants.TEAM_PERMISSION).append("'");
			// User Responsibilities so regional and org code has a value to
			// filter on
			hql.append(" AND cp.value in (:values)");
		}

		Query query = getCurrentSession().createQuery(hql.toString());
		if (regionalCode) {
			query.setParameterList("values", responsibilites);
		}

		return query.list();

	}

	public List<CaseObject> loadRegionalCases(
			final List<UserDirectorate> directorates,
			final String[] responsibilites) {

		final StringBuffer hql = new StringBuffer();
		hql.append("SELECT distinct c FROM CasePermission cp, CaseObject c WHERE");
		hql.append(" c.caseId = cp.caseId AND c.state IN ");
		this.appendCaseStatusType(hql, true, false, false);

		// if we are filtering by regional code then add the where clause
		hql.append(" AND cp.permissionType =");
		hql.append("'").append(ECMSConstants.TEAM_PERMISSION).append("'");

		// check the directorate level of the user
		String[] outdirs = null;

		if (!directorates.isEmpty()) {

			outdirs = getUserDirectorates(directorates, true);
			hql.append(" AND c.restrictTo in (:restrictToValues)");
		}

		final String[] indirs = outdirs;

		hql.append(" AND cp.value in (:values)");
		hql.append(" ORDER BY c.caseNumber desc");

		// DEBUG
		if (logger.isDebugEnabled()) {

			debugUserRespandDirectorates(indirs, responsibilites);
		}

		Query query = getCurrentSession().createQuery(hql.toString());

		query.setParameterList("values", responsibilites);

		if (!directorates.isEmpty()) {
			query.setParameterList("restrictToValues", indirs);
		}

		return query.list();

	}

	public List<CaseObject> loadCases(final boolean regionalCode,
			final boolean orgCode, final List<UserDirectorate> directorates,
			final String[] responsibilites) {

		final StringBuffer hql = new StringBuffer();
		hql.append("SELECT distinct c FROM CasePermission cp, CaseObject c");
		hql.append(" WHERE c.caseId = cp.caseId AND c.state IN ");
		this.appendCaseStatusType(hql, true, false, false);

		// if we are filtering by regional code then add the where clause
		if (regionalCode) {
			hql.append(" AND cp.permissionType = '"
					+ ECMSConstants.TEAM_PERMISSION + "'");
		}

		// if we are filtering by org code then add the where clause
		if (orgCode) {
			hql.append(" AND cp.permissionType = '"
					+ ECMSConstants.ORGANISATIONAL_PERMISSION + "'");
		}

		// check the directorate level of the user
		String[] outdirs = null;
		if (!directorates.isEmpty()) {

			outdirs = getUserDirectorates(directorates, false);

			hql.append(" AND c.restrictTo in (:restrictToValues)");
		}

		final String[] indirs = outdirs;

		if (regionalCode || orgCode) {

			// Responsibilities for the user so that regional and org code has a
			// value to filter on

			hql.append(" AND cp.value in (:values)");
		}

		hql.append(" order by c.caseNumber desc");

		if (logger.isDebugEnabled()) {

			debugUserRespandDirectorates(indirs, responsibilites);
		}

		Query query = getCurrentSession().createQuery(hql.toString());

		query.setParameterList("values", responsibilites);

		// if we have regional code or org code the put the
		// values in
		if (regionalCode || orgCode) {
			query.setParameterList("values", responsibilites);
		}

		if (!directorates.isEmpty()) {
			query.setParameterList("restrictToValues", indirs);
		}

		return query.list();

	}

	/**
	 * Helper method.
	 * 
	 * @param directorates
	 * @param notLocal
	 *            , check for LEVEL != ECMSConstants.LOCAL
	 * @return
	 */
	private String[] getUserDirectorates(List<UserDirectorate> directorates,
			boolean notLocal) {

		String[] outdirs = new String[directorates.size()];

		for (int i = 0; i < directorates.size(); i++) {

			UserDirectorate dir = directorates.get(i);

			if (notLocal
					&& !dir.getDirectorateLevel().equalsIgnoreCase(
							ECMSConstants.LOCAL)) {

				outdirs[i] = dir.getDirectorateLevel();
			} else {
				outdirs[i] = dir.getDirectorateLevel();
			}
		}

		return outdirs;
	}

	public List<CaseObject> loadClosedCases(final boolean regionalCode,
			final boolean orgCode, final List<UserDirectorate> directorates,
			final String[] responsibilites) {

		final StringBuffer hql = new StringBuffer();
		hql.append("SELECT distinct c FROM CasePermission cp, CaseObject c");
		hql.append(" WHERE c.caseId = cp.caseId AND c.state IN ");
		this.appendCaseStatusType(hql, false, false, true);

		// if we are filtering by regional code then add the where clause
		if (regionalCode) {
			hql.append(" AND cp.permissionType in ");
			this.appendCasePermissionsByArea(hql, true, false);
		}

		// if we are filtering by org code then add the where clause
		if (orgCode) {
			hql.append(" AND cp.permissionType in ");
			this.appendCasePermissionsByArea(hql, false, true);
		}

		// check the directorate level of the user
		String[] outdirs = null;
		if (!directorates.isEmpty()) {
			outdirs = new String[directorates.size()];

			for (int i = 0; i < directorates.size(); i++) {
				UserDirectorate dir = directorates.get(i);
				outdirs[i] = dir.getDirectorateLevel();
			}
			hql.append(" AND c.restrictTo in (:restrictToValues)");
		}

		final String[] indirs = outdirs;

		if (regionalCode || orgCode) {
			// Responsibilities for the user so that regional and org
			// code has a value to filter on

			hql.append(" AND cp.value in (:values)");
		}
		hql.append(" order by c.caseNumber desc");

		if (logger.isDebugEnabled()) {

			debugUserRespandDirectorates(indirs, responsibilites);
		}
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameterList("values", responsibilites);

		// Regional or Organisation code values in
		if (regionalCode || orgCode) {
			query.setParameterList("values", responsibilites);
		}

		if (!directorates.isEmpty()) {
			query.setParameterList("restrictToValues", indirs);
		}

		return query.list();

	}

	/**
	 * Helper method to append local and regional case permissions.
	 * 
	 * @param hql
	 * @param regional
	 * @param local
	 */
	private void appendCasePermissionsByArea(StringBuffer hql,
			boolean regional, boolean local) {

		hql.append("('");
		if (local) {
			hql.append(ECMSConstants.ORGANISATIONAL_PERMISSION).append("','");
		}
		if (regional) {
			hql.append(ECMSConstants.TEAM_PERMISSION).append("','");
		}
		hql.append(ECMSConstants.ASSIGNEE_PERMISSION).append("','");
		hql.append(ECMSConstants.CASE_ASSIGNEE_PERMISSION).append("','");
		hql.append(ECMSConstants.SENIOR_INVESTIGATING_OFFICER_PERMISSION)
				.append("','");
		hql.append(ECMSConstants.DISCLOSURE_OFFICER_PERMISSION).append("','");
		hql.append(ECMSConstants.FINANCIAL_INVESTIGATOR_PERMISSION).append(
				"','");
		hql.append(ECMSConstants.FORENSIC_COMPUTING_SPECIALIST_PERMISSION)
				.append("')");
	}

	public List<CaseObject> loadAssignedCases(final SessionUser user,
			final List<UserDirectorate> directorates) {

		final StringBuffer hql = new StringBuffer(
				"SELECT distinct c FROM CaseObject c,");
		hql.append(" CasePermission cp WHERE c.caseId=cp.caseId ");
		hql.append(" AND cp.permissionType IN ");
		this.appendCasePermissionsByArea(hql, false, false);

		hql.append(" AND c.state IN ");
		this.appendCaseStatusType(hql, true, false, false);

		hql.append(" and cp.value='").append(user.getStaffId()).append("'");

		String[] outvals = null;
		if (!directorates.isEmpty()) {
			hql.append("AND c.restrictTo IN (:restrictToValues)");
			outvals = new String[directorates.size()];
			for (int i = 0; i < directorates.size(); i++) {
				UserDirectorate dir = directorates.get(i);
				outvals[i] = "CFS_" + dir.getDirectorateLevel();
			}
		}
		hql.append(" ORDER BY c.caseNumber desc");

		final String[] invals = outvals;

		Query query = getCurrentSession().createQuery(hql.toString());

		if (!directorates.isEmpty()) {
			query.setParameterList("restrictToValues", invals);
		}
		if (logger.isDebugEnabled()) {
			logger.debug(hql);
		}

		return query.list();

	}

	/**
	 * Create CaseNumber example: NITN/11/00047
	 * 
	 * @return caseNumber.
	 */
	public String getCaseNumber(final CaseTO caseTo) {

		String newTeamCode = getTopTeamCode(caseTo.getTeamCode());

		if (null != newTeamCode) {

			String caseNumber = "";

			SimpleDateFormat df = new SimpleDateFormat("yy");
			final String year = df.format(new Date(System.currentTimeMillis()));

			DetachedCriteria criteria = DetachedCriteria
					.forClass(CaseNumber.class);
			criteria.add(Restrictions.eq("teamCode", newTeamCode));
			criteria.add(Restrictions.eq("year", year));

			List list = criteria.getExecutableCriteria(getCurrentSession())
					.list();

			// If the query didn't return any results then this is the first
			// case of the year
			if (list.isEmpty()) {

				// Assemble the current case number
				caseNumber = newTeamCode + "/" + year + "/00001";

				// create the next sequence
				CaseNumber cn = new CaseNumber();
				cn.setNextSequence("00002");
				cn.setYear(year);
				cn.setTeamCode(newTeamCode);

				// and save the bugger
				getCurrentSession().save(cn);

			} else {

				// Get the sequence
				CaseNumber caseNumberObj = null;
				if (!list.isEmpty()) {
					caseNumberObj = (CaseNumber) list.get(0);
				}
				// Assemble the case number
				caseNumber = newTeamCode + "/" + year + "/"
						+ caseNumberObj.getNextSequence();

				// Increment the sequence
				Integer sequenceInt = Integer.valueOf(caseNumberObj
						.getNextSequence());
				int nextSequenceVal = sequenceInt.intValue();
				nextSequenceVal++;

				// Pad the new sequence to the required number of characters
				String nextSequence = StringUtilities.padLeft(
						String.valueOf(nextSequenceVal), 5, '0');

				// Update the case numbers table

				caseNumberObj.setNextSequence(nextSequence);
				getCurrentSession().update(caseNumberObj);
			}
			return caseNumber;
		}
		return null;
	}

	/**
	 * Return New Team Code based on the existing teamCode from TeamCodes.
	 * 
	 * @param teamCode
	 * @return newTeamCode
	 */
	@SuppressWarnings("unchecked")
	private String getTopTeamCode(String teamCode) {

		DetachedCriteria criteria = DetachedCriteria.forClass(TeamCodes.class);
		criteria.add(Restrictions.eq("teamCode", teamCode));
		criteria.add(Restrictions.eq("status", "A"));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();
		if (null != list && !list.isEmpty()) {
			// return ((TeamCodes)list.get(0)).getNewTeamCode();
			return ((TeamCodes) list.get(0)).getTeamCode();
		}
		return null;
	}

	public Case saveOrUpdate(Case caseObject) {

		caseObject.setUpdatedFlag("Y");

		return (Case) getCurrentSession().merge(caseObject);
	}

	public Case saveCase(Case caseInfo) {

		caseInfo.setUpdatedFlag("Y");

		return (Case) getCurrentSession().merge(caseInfo);
	}

	public OrganisationTeamCode loadTeamCodeByOrgCode(String orgCode) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(OrganisationTeamCode.class);
		criteria.add(Restrictions.eq("orgCode", orgCode));

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();
		if (null != list && !list.isEmpty()) {

			return (OrganisationTeamCode) list.get(0);
		}

		return null;
	}

	public Case loadCaseByCaseNumber(String caseNumber) {

		DetachedCriteria criteria = DetachedCriteria.forClass(Case.class);
		criteria.add(Restrictions.eq("caseNumber", caseNumber));

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {

			return (Case) list.get(0);
		}
		return null;
	}

	public List<CaseContact> loadContactsByCaseId(Long caseId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseContact.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.ne("state",
				ECMSConstants.CASE_CONTACT_SUBJECT));
		criteria.add(Restrictions.ne("state",
				ECMSConstants.CASE_CONTACT_WITNESS));

		criteria.add(Restrictions.or(
				Restrictions.ne("contactType", "ASSOCIATE"),
				Restrictions.isNull("contactType")));

		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		return criteria.getExecutableCriteria(getCurrentSession()).list();

	}

	public List<InvestigationPlan> loadInvestigationsByCaseId(Long caseId) {

		StringBuilder hsql = new StringBuilder("");
		hsql.append("SELECT invPlan.investigationId, invPlan.caseId,");
		hsql.append(" invPlan.createdStaffId, invPlan.createdDate FROM");
		hsql.append(" InvestigationPlan invPlan WHERE");
		hsql.append(" invPlan.caseId='").append(caseId);
		hsql.append("' ORDER BY invPlan.createdDate asc");

		List<Object[]> list = getCurrentSession().createQuery(hsql.toString())
				.list();

		return createInvestigationList(list);
	}

	public List<InvestigationPlan> loadFullInvestigationsByCaseId(Long caseId) {

		final StringBuilder hsql = new StringBuilder("");
		hsql.append("SELECT invPlan FROM");
		hsql.append(" InvestigationPlan invPlan WHERE");
		hsql.append(" invPlan.caseId='").append(caseId);
		hsql.append("' ORDER BY invPlan.createdDate asc");

		return getCurrentSession().createQuery(hsql.toString()).list();

	}

	private List<InvestigationPlan> createInvestigationList(
			List<Object[]> queryResults) {

		List<InvestigationPlan> list = new ArrayList<InvestigationPlan>();

		for (Object[] result : queryResults) {
			InvestigationPlan plan = new InvestigationPlan();
			plan.setInvestigationId((Long) result[0]);
			plan.setCaseId((Long) result[1]);
			plan.setCreatedStaffId((String) result[2]);
			plan.setCreatedDate((Timestamp) result[3]);
			list.add(plan);
		}
		return list;
	}

	public CaseClosure saveCaseClosure(CaseClosure closure) {

		return (CaseClosure) getCurrentSession().merge(closure);
	}

	public CaseClosure updateCaseClosure(CaseClosure closure) {
		// getHibernateTemplate().update(closure);
		return (CaseClosure) getCurrentSession().merge(closure);
	}

	public CaseClosure loadCaseClosure(Long caseId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseClosure.class);
		criteria.add(Restrictions.eq("caseId", caseId));

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {

			return (CaseClosure) list.get(0);
		}
		return null;

	}

	public CaseClosure loadCaseClosureForCPS(final Long caseId) {

		CaseClosure caseClosure = null;
		final Criteria criteria = getCurrentSession().createCriteria(
				CaseClosure.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.isNotNull("closureReport"));
		criteria.add(Restrictions.isNotNull("closureReportFileName"));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("closureReportFileName"),
				"closureReportFileName");
		projectionList.add(Projections.property("closureReportFileType"),
				"closureReportFileType");
		projectionList.add(Projections.property("caseClosureId"),
				"caseClosureId");
		projectionList.add(Projections.property("caseId"), "caseId");
		projectionList.add(Projections.property("closureReport"),
				"closureReport");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers
				.aliasToBean(CaseClosure.class));

		@SuppressWarnings("unchecked")
		final List<CaseClosure> list = criteria.list();

		if (null != list && !list.isEmpty()) {
			caseClosure = list.get(0);
		}
		return caseClosure;
	}

	public CaseClosure downloadCaseClosure(final Long caseId) {
		CaseClosure caseClosure = null;

		final Criteria criteria = getCurrentSession().createCriteria(
				CaseClosure.class);
		criteria.add(Restrictions.eq("caseId", caseId));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("closureReportFileName"),
				"closureReportFileName");
		projectionList.add(Projections.property("closureReportFileType"),
				"closureReportFileType");
		projectionList.add(Projections.property("closureReport"),
				"closureReport");
		projectionList.add(Projections.property("caseClosureId"),
				"caseClosureId");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers
				.aliasToBean(CaseClosure.class));

		@SuppressWarnings("unchecked")
		List<CaseClosure> list = criteria.list();

		caseClosure = list.get(0);

		return caseClosure;

	}

	/**
	 * Helper method for appending case status types.
	 * 
	 * @param hql
	 * @param opened
	 * @param await
	 * @param closed
	 */
	private void appendCaseStatusType(StringBuffer hql, boolean opened,
			boolean await, boolean closed) {

		hql.append("('");

		if (opened) {

			hql.append(ECMSConstants.CASE_OPEN).append("','");
			hql.append(ECMSConstants.CASE_REOPENED).append("','");
			hql.append(ECMSConstants.CASE_PENDING);
			if (await || closed) {
				hql.append("','");
			}
		}
		if (await) {
			hql.append(ECMSConstants.CASE_AWAITING);
			if (closed) {
				hql.append("','");
			}
		}
		if (closed) {
			hql.append(ECMSConstants.CASE_CLOSED);
		}
		hql.append("')");
	}

	public CaseSearchFormTO getCaseSearchResults(final CaseSearchFormTO sTO,
			final SessionUser user) {

		CaseSearchFormTO resultsTO = sTO;
		final String[] userResps = user.getOrgOrTeamResponsibilities();

		final List<UserDirectorate> dirList = user.getDirectorates();
		final String[] dirs = user.getCFSDirectorateLevel();

		String caseStatus = sTO.getCaseStatus();

		final StringBuffer hql = new StringBuffer("SELECT distinct c FROM ");
		hql.append("CasePermission cp, CaseObject c WHERE c.caseId = cp.caseId ");

		// if we are filtering by regional code then add the where clause
		if (user.isUserRegionalLevel()) {
			hql.append(" AND cp.permissionType = '"
					+ ECMSConstants.TEAM_PERMISSION + "'");
		}
		// if we are filtering by org code then add the where clause
		if (user.isUserLocalLevel()) {
			hql.append(" AND cp.permissionType = '"
					+ ECMSConstants.ORGANISATIONAL_PERMISSION + "'");
		}
		// check the directorate(National) level of the user
		if (!dirList.isEmpty()) {
			hql.append(" AND c.restrictTo in (:restrictToValues)");
		}

		// if (user.isUserRegionalLevel() || user.isUserLocalLevel()) {
		// Responsibilities for the user so that regional and org
		// code has a value to filter on
		hql.append(" AND cp.value in (:values)");
		// }

		if (null != caseStatus & !caseStatus.equalsIgnoreCase("ALL")) {
			hql.append(" AND c.state ='").append(caseStatus).append("' ");
		} else if (null != caseStatus & caseStatus.equalsIgnoreCase("ALL")) {
			hql.append(" AND c.state IN ");
			this.appendCaseStatusType(hql, true, true, true);
		}

		// Cater new case status like LCFS-CLOSED, LCFS-PENDING, LCFS-OPENED,
		// CFS-CLOSED, CFS-PENDING, CFS-OPENED...
		if ((caseStatus.equals(ECMSConstants.CASE_CLOSED)
				|| caseStatus.equals(ECMSConstants.CASE_PENDING) || caseStatus
					.equals(ECMSConstants.CASE_OPEN))
				& StringUtils.isNotEmpty(sTO.getClosedBy())) {

			if (sTO.getClosedBy().equals(ECMSConstants.LOCAL)) {
				hql.append(" AND c.restrictTo ='").append(ECMSConstants.LOCAL);
			} else {
				hql.append(" AND c.restrictTo <>'").append(ECMSConstants.LOCAL);
			}
			hql.append("' ");
		}

		if (sTO.getCaseNumber() != null) {
			hql.append(" AND lower(c.caseNumber) like '%")
					.append(EcmsUtils.removeSpecialChars(sTO.getCaseNumber()
							.toLowerCase())).append("%' ");
		}
		if (sTO.getOperationName() != null) {
			hql.append(" AND lower(c.operationName) like '%")
					.append(EcmsUtils.removeSpecialChars(sTO.getOperationName()
							.toLowerCase())).append("%' ");
		}
		if (sTO.isCloseDataRange()) {
			hql.append(" AND c.closedTime between :startDate and :endDate ");
		} else if (sTO.isDataRange() && sTO.getStartDate() != null
				& sTO.getEndDate() != null) {
			hql.append(" AND c.createdTime between :startDate and :endDate ");
		}
		// DEBUG
		if (logger.isDebugEnabled()) {
			debugUserRespandDirectorates(dirs, userResps);
		}
		Query query = getCurrentSession().createQuery(hql.toString());
		// if (user.isUserRegionalLevel() || user.isUserLocalLevel()) {
		query.setParameterList("values", userResps);
		// }
		if (!dirList.isEmpty()) {
			query.setParameterList("restrictToValues", dirs);
		}
		if (sTO.isDataRange() && sTO.getStartDate() != null
				& sTO.getEndDate() != null) {
			query.setParameter("startDate", sTO.getStartDate());
			query.setParameter("endDate", sTO.getEndDate());
		}
		// Execute
		List list = query.list();

		if (null != list && !list.isEmpty()) {
			logger.info("Result size from getCaseSearchResults =" + list.size());
		}
		resultsTO.setSearchResults(list);
		return resultsTO;

	}

	public CaseSearchFormTO getGenericCaseSearchResults(
			final CaseSearchFormTO sTO, final SessionUser user) {
		CaseSearchFormTO resultsTO = sTO;
		final String[] userResps = user.getOrgOrTeamResponsibilities();

		final List<UserDirectorate> dirList = user.getDirectorates();
		final String[] dirs = user.getCFSDirectorateLevel();

		String caseStatus = sTO.getCaseStatus();

		final StringBuffer hql = new StringBuffer("SELECT distinct c FROM ");
		hql.append("CasePermission cp, CaseObject c WHERE c.caseId = cp.caseId ");

		// if we are filtering by regional code then add the where clause
		if (user.isUserRegionalLevel()) {
			hql.append(" AND cp.permissionType = '"
					+ ECMSConstants.TEAM_PERMISSION + "'");
		}
		// if we are filtering by org code then add the where clause
		if (user.isUserLocalLevel()) {
			hql.append(" AND cp.permissionType = '"
					+ ECMSConstants.ORGANISATIONAL_PERMISSION + "'");
		}
		// check the directorate(National) level of the user
		if (!dirList.isEmpty()) {
			hql.append(" AND c.restrictTo in (:restrictToValues)");
		}

		// if (user.isUserRegionalLevel() || user.isUserLocalLevel()) {
		// Responsibilities for the user so that regional and org
		// code has a value to filter on
		hql.append(" AND cp.value in (:values)");
		// }

		if (null != caseStatus & !caseStatus.equalsIgnoreCase("ALL")) {
			hql.append(" AND c.state ='").append(caseStatus).append("' ");
		} else if (null != caseStatus & caseStatus.equalsIgnoreCase("ALL")) {
			hql.append(" AND c.state IN ");
			this.appendCaseStatusType(hql, true, true, true);
		}

		// Cater new case status like LCFS-CLOSED, LCFS-PENDING, LCFS-OPENED,
		// CFS-CLOSED, CFS-PENDING, CFS-OPENED...
		if ((caseStatus.equals(ECMSConstants.CASE_CLOSED)
				|| caseStatus.equals(ECMSConstants.CASE_PENDING) || caseStatus
					.equals(ECMSConstants.CASE_OPEN))
				& StringUtils.isNotEmpty(sTO.getClosedBy())) {

			if (sTO.getClosedBy().equals(ECMSConstants.LOCAL)) {
				hql.append(" AND c.restrictTo ='").append(ECMSConstants.LOCAL);
			} else {
				hql.append(" AND c.restrictTo <>'").append(ECMSConstants.LOCAL);
			}
			hql.append("' ");
		}

		if (sTO.getCaseNumber() != null) {
			hql.append(" AND lower(c.caseNumber) like '%")
					.append(EcmsUtils.removeSpecialChars(sTO.getCaseNumber()
							.toLowerCase())).append("%' ");
		}

		// DEBUG
		if (logger.isDebugEnabled()) {
			debugUserRespandDirectorates(dirs, userResps);
		}

		Query query = getCurrentSession().createQuery(hql.toString());
		// if (user.isUserRegionalLevel() || user.isUserLocalLevel()) {
		query.setParameterList("values", userResps);
		// }
		if (!dirList.isEmpty()) {
			query.setParameterList("restrictToValues", dirs);
		}
		// Execute
		List list = query.list();

		if (null != list && !list.isEmpty()) {
			logger.info("Result size from getGenericCaseSearchResults ="
					+ list.size());
		}
		resultsTO.setSearchResults(list);

		return resultsTO;

	}

	/**
	 * Helper to debug user directorates and Responsibilities.
	 * 
	 * @param dirs
	 * @param userResps
	 */
	private void debugUserRespandDirectorates(String[] dirs, String[] userResps) {

		if (null != dirs) {
			logger.debug("DIR @ restrictToValue : [");
			for (String dir : dirs) {
				logger.debug(dir + ", ");
			}
			logger.debug("]");
		}
		if (null != userResps) {
			logger.debug("USER RESP @ value : [");
			for (String resp : userResps) {
				logger.debug(resp + ", ");
			}
			logger.debug("]");
		}
	}

	public CaseSummaryInformation loadCaseSummaryInformation(Long caseId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseSummaryInformation.class);

		criteria.add(Restrictions.eq("caseId", caseId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (CaseSummaryInformation) list.get(0);
		}
		return null;

	}

	public void updateCaseSummaryInformation(CaseSummaryInformation summary) {

		getCurrentSession().merge(summary);
	}

	public boolean isUserAuthorizedToAccessCase(final Long caseId,
			final SessionUser user) {

		if (user.isUserFCRL()) {

			return false;
		} else if ((user.isUserAntiFraudSpecialist() || user.isUserOFM()
				|| user.isUserAntiFraudLead() || user.isUserCFS())
				&& isCaseInTransfer(caseId, user)) {

			return true;
		}
		String staffId = user.getStaffId().trim();
		String[] userResps = user.getOrgOrTeamResponsibilities();
		List<UserDirectorate> dirList = user.getDirectorates();
		String[] dirs = user.getCFSDirectorateLevel();
		String dirString = EcmsUtils.getCommaSeperatedValues(dirs);
		String respString = EcmsUtils.getCommaSeperatedValues(userResps);

		if (logger.isDebugEnabled()) {
			logger.debug("*** DIR =" + dirString + ", RESP =" + respString
					+ ", STAFFID =" + staffId);
		}

		String caseAccessTeamCodes = null;
		final List<String> userRespList = Arrays.asList(userResps);
		if (userRespList.contains(ECMSConstants.TEAM_FCO)) {
			caseAccessTeamCodes = EcmsUtils
					.getCommaSeperatedValues(ECMSConstants.FCO_TEAMS.values());
		} else {
			caseAccessTeamCodes = EcmsUtils
					.getCommaSeperatedValues(ECMSConstants.NAT_TEAMS.values());
		}

		final StringBuffer qSB = new StringBuffer("SELECT count(*) as count ");
		qSB.append(" FROM CASE_PERM_TBL casePerm, CASE_TBL case1");
		qSB.append(" WHERE case1.case_id = casePerm.case_id AND");
		// qSB.append(" case1.state in ('OPEN','PENDING_CLOSURE','CLOSED','REOPENED','AWAITING') AND (");

		qSB.append(" (");

		if (user.isUserAntiFraudLead() || user.isUserCFS()) {
			qSB.append(" (casePerm.PERM_TYPE='TEAM_CODE' AND casePerm.VALUE in ");
			qSB.append(caseAccessTeamCodes);
			qSB.append(" ) OR ");
		} else if (!user.isUserLCFS()) {
			qSB.append(" (casePerm.PERM_TYPE='TEAM_CODE' AND casePerm.VALUE in ");
			qSB.append(respString).append(" ) OR ");
		}

		qSB.append(" (casePerm.PERM_TYPE in ('LEAD_ASSIGNEE','CASE_ASSIGNEE','FINANCIAL_INV','SEN_INV_OFFICER','FORENSIC_COMP_SPEC','DISC_OFFICER') AND casePerm.value= '");
		qSB.append(staffId).append("' ");

		if (!user.isUserLCFS()) {
			qSB.append(" AND case1.RESTRICT_TO in ");
			qSB.append(dirString).append(") ) ");
		} else {
			qSB.append(" ) OR (casePerm.PERM_TYPE='ORG_CODE' ");
			if (null != dirList && !dirList.isEmpty()) {
				qSB.append(" and (case1.RESTRICT_TO in ");
				qSB.append(dirString).append(")");
			}
			qSB.append(" and (casePerm.VALUE in ");
			qSB.append(respString).append("))) ");
		}

		qSB.append(" AND case1.case_id = '" + caseId + "'");

		SQLQuery query = getCurrentSession().createSQLQuery(qSB.toString());
		Object recordCountObj = query.uniqueResult();

		if (recordCountObj instanceof BigDecimal) {
			BigDecimal recordCount = (BigDecimal) recordCountObj;
			if (recordCount.intValue() > 0) {
				return true;
			}
		} else if (recordCountObj instanceof Integer) {
			Integer recordCount = (Integer) recordCountObj;
			if (recordCount.intValue() > 0) {
				return true;
			}
		}

		return false;
	}

	private boolean isCaseInTransfer(Long caseId, SessionUser user) {

		final StringBuffer qSB = new StringBuffer("SELECT count(*) as count ");
		qSB.append(" FROM CASE_TRANSFER_TBL caseTrans, CASE_TBL case1");
		qSB.append(" WHERE case1.case_id = caseTrans.case_id AND ");
		qSB.append(" caseTrans.STATE='" + ECMSConstants.TRANSFER_REFERRED);
		qSB.append("' AND caseTrans.RECIPIENT_TEAM in ");
		qSB.append(EcmsUtils.getCommaSeperatedValues(user
				.getOrgOrTeamResponsibilities()));
		qSB.append(" AND case1.case_id = '" + caseId + "'");

		SQLQuery query = getCurrentSession().createSQLQuery(qSB.toString());
		Object recordCountObj = query.uniqueResult();

		if (recordCountObj instanceof BigDecimal) {
			BigDecimal recordCount = (BigDecimal) recordCountObj;
			if (recordCount.intValue() > 0) {
				return true;
			}
		} else if (recordCountObj instanceof Integer) {
			Integer recordCount = (Integer) recordCountObj;
			if (recordCount.intValue() > 0) {
				return true;
			}
		}

		return false;
	}

	public UserObject getOFMDetailsByCaseId(Long caseId) {

		String teamCode = null;
		DetachedCriteria permCriteria = DetachedCriteria
				.forClass(CasePermission.class);
		permCriteria.add(Restrictions.eq("permissionType",
				ECMSConstants.TEAM_PERMISSION));
		permCriteria.add(Restrictions.eq("caseId", caseId));
		Session session = getCurrentSession();
		List list = permCriteria.getExecutableCriteria(session).list();

		if (null != list && !list.isEmpty()) {
			CasePermission casePermObj = (CasePermission) (list.get(0));

			if (casePermObj != null) {
				teamCode = casePermObj.getValue();
			}
		}
		if (null == teamCode) {
			DetachedCriteria caseCriteria = DetachedCriteria
					.forClass(Case.class);
			caseCriteria.add(Restrictions.eq("caseId", caseId));

			list = caseCriteria.getExecutableCriteria(session).list();

			if (null != list && !list.isEmpty()) {
				Case caseObj = (Case) (list.get(0));

				if (caseObj != null) {
					teamCode = caseObj.getTeamCode();
				}
			}
		}
		//		 If teamCode is null or unknown, OFM organisation is 'T1350'
		if (null == teamCode || EcmsUtils.isTeamCodeCFSMS(teamCode)) {
			teamCode = "T1350";
		}
		return getOFMByTeamCode(teamCode);

	}

	/*
	 * This method finds active staff id to be received cps documents request messages from lcfs.
	 * @see uk.nhs.cfsms.ecms.dao.CaseDao#getApproverStaffIdForCPSDocsRequest()
	 * @return active staff id
	 */

	public String getApproverStaffIdForCPSDocsRequest() {
		final String sql = new String(
				"SELECT STAFF_ID FROM FCO_MESSAGES_RECEIVER_TBL WHERE STATUS=:STATUS");
		final SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("STATUS", "A");
		return (String) query.list().get(0);
	}

	/*public String getOFMDetailsByCaseIdForCPS(final Long caseId) {

		String teamCode = null;

		final Criteria casePermissionCriteria = getCurrentSession()
				.createCriteria(CasePermission.class);
		casePermissionCriteria.add(Restrictions.eq("permissionType",
				ECMSConstants.TEAM_PERMISSION));
		casePermissionCriteria.add(Restrictions.eq("caseId", caseId));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("value"), "value");

		casePermissionCriteria.setProjection(projectionList);
		casePermissionCriteria.setResultTransformer(Transformers
				.aliasToBean(CasePermission.class));

		@SuppressWarnings("unchecked")
		final List<CasePermission> list = casePermissionCriteria.list();

		final CasePermission casePermission = list.get(0);
		if (null != casePermission) {
			teamCode = casePermission.getValue();
		}

		if (null == teamCode) {
			final Criteria caseCriteria = getCurrentSession().createCriteria(
					Case.class);
			caseCriteria.add(Restrictions.eq("caseId", caseId));

			final ProjectionList caseProjectionList = Projections
					.projectionList();
			caseProjectionList
					.add(Projections.property("teamCode"), "teamCode");

			caseCriteria.setProjection(caseProjectionList);
			caseCriteria.setResultTransformer(Transformers
					.aliasToBean(Case.class));

			@SuppressWarnings("unchecked")
			final List<Case> caseList = caseCriteria.list();
			final Case caseObj = caseList.get(0);

			if (null != caseObj) {
				teamCode = caseObj.getTeamCode();
			}
		}

		if (null == teamCode || EcmsUtils.isTeamCodeCFSMS(teamCode)) {
			teamCode = "T1350";
		}
		return getOFMByTeamCodeForCPS(teamCode);

	}*/

	private UserObject getOFMByTeamCode(final String teamCode) {

		final StringBuffer hql = new StringBuffer("SELECT distinct user FROM");
		hql.append(" UserObject user, AllUserResponsibilities resp");
		hql.append(" WHERE user.staffId = resp.staffId AND");
		hql.append(" user.employerOrgCode = :teamCode AND");
		hql.append(" user.status = 'A' AND");
		hql.append(" resp.respCode = :teamCode AND");
		if (teamCode.equalsIgnoreCase("T1350")) {

			hql.append(" user.groupPermission in (4, 1)");
		} else if (EcmsUtils.isTeamCodeInOFMTeams(teamCode)) {

			hql.append(" user.groupPermission = 4");
		} else if (EcmsUtils.isNITTeamCode(teamCode)) {

			hql.append(" user.groupPermission = 9");
		} else {

			hql.append(" user.groupPermission = 8");
		}
		if (ECMSConstants.IMO.equalsIgnoreCase(teamCode)) {
			final String activeStaffId = imoMessagereceiverService
					.getActiveStaffId();
			hql.append(" AND user.staffId = '" + activeStaffId + "'");
		}

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("teamCode", teamCode);

		if (logger.isDebugEnabled()) {
			logger.debug(hql);
		}
		List userList = query.list();

		if (null != userList && !userList.isEmpty() && userList.size() == 1) {
			return (UserObject) userList.get(0);
		}
		return null;
	}

	private String getOFMByTeamCodeForCPS(final String teamCode) {

		final StringBuffer hql = new StringBuffer(
				"SELECT distinct user.staffId FROM");
		hql.append(" UserObject user, AllUserResponsibilities resp");
		hql.append(" WHERE user.staffId = resp.staffId AND");
		hql.append(" user.employerOrgCode = :teamCode AND");
		hql.append(" user.status = 'A' AND");
		hql.append(" resp.respCode = :teamCode AND");
		if (teamCode.equalsIgnoreCase("T1350")) {

			hql.append(" user.groupPermission in (4, 1)");
		} else if (EcmsUtils.isTeamCodeInOFMTeams(teamCode)) {

			hql.append(" user.groupPermission = 4");
		} else if (EcmsUtils.isNITTeamCode(teamCode)) {

			hql.append(" user.groupPermission = 9");
		} else {

			hql.append(" user.groupPermission = 8");
		}
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("teamCode", teamCode);

		if (logger.isDebugEnabled()) {
			logger.debug(hql);
		}
		@SuppressWarnings("unchecked")
		List<String> userList = query.list();

		return (String) userList.get(0);

	}

	public void runConfidentialProcedure(final Long caseId) {

		// TODO check whether this method is needed.
		/*
		 * getHibernateTemplate().execute(new HibernateCallback() { public
		 * Object doInHibernate(Session session) throws HibernateException,
		 * SQLException { CallableStatement stmt =
		 * getSession().connection().prepareCall(
		 * " call case_confidentiality(?)"); stmt.setLong(1, caseId);
		 * stmt.execute(); return null; } });
		 */

	}

	public void callTransactionCommit() {

		// TODO check whether this method is needed.
		/*
		 * getHibernateTemplate().execute(new HibernateCallback() { public
		 * Object doInHibernate(Session session) throws HibernateException,
		 * SQLException { session.getTransaction().commit(); return null; } });
		 */

	}

	public void callTransactionBeginAndSave(final TempConfCase tempCase) {

		getCurrentSession().merge(tempCase);

	}

	public void saveTempConfCase(TempConfCase tempCase) {

		getCurrentSession().merge(tempCase);
	}

	/**
	 * Phase-4 -- updated FIRST.ALL_CASE_VIEW --
	 */
	public List<CaseObject> loadNITCasesByTeam(
			final List<UserDirectorate> directorates, String teamValue) {

		final StringBuffer hql = new StringBuffer();
		hql.append("SELECT distinct c FROM CasePermission cp, CaseObject c WHERE");
		hql.append(" c.caseId = cp.caseId AND c.state IN ");
		this.appendCaseStatusType(hql, true, false, false);

		// if we are filtering by NITS then add the where clause
		hql.append(" AND cp.permissionType = '");
		hql.append(ECMSConstants.TEAM_PERMISSION).append("'");
		// NITS or NITN...
		hql.append(" AND cp.value ='").append(teamValue).append("'");

		// -- CFS_NAT
		String[] outdirs = null;

		if (!directorates.isEmpty()) {

			outdirs = new String[directorates.size()];

			for (int i = 0; i < directorates.size(); i++) {

				UserDirectorate dir = directorates.get(i);

				String directorateLevel = dir.getDirectorateLevel();

				if (directorateLevel.equalsIgnoreCase(ECMSConstants.NATIONAL)
						|| directorateLevel
								.equalsIgnoreCase(ECMSConstants.REGIONAL)) {

					outdirs[i] = dir.getDirectorateLevel();
				}
			}
			hql.append(" AND c.restrictTo in (:restrictToValues)");
		}

		hql.append(" order by c.reopenedTime asc, c.createdTime desc, c.caseNumber desc");

		final String[] indirs = outdirs;

		// DEBUG
		if (logger.isDebugEnabled()) {

			debugUserRespandDirectorates(indirs, new String[] { teamValue });
		}

		Query query = getCurrentSession().createQuery(hql.toString());

		if (!directorates.isEmpty()) {
			query.setParameterList("restrictToValues", indirs);
		}

		return query.list();
	}

	/**
	 * Load Awaiting cases by user restrictions and responsibilities
	 * 
	 */
	public List<CaseObject> loadAwaitCases(
			final List<UserDirectorate> directorates,
			final String[] responsibilites) {

		final StringBuffer hql = new StringBuffer();
		hql.append("SELECT distinct c FROM CasePermission cp, CaseObject c WHERE");
		hql.append(" c.caseId = cp.caseId AND c.state IN ");
		this.appendCaseStatusType(hql, false, true, false);

		// if we are filtering by regional code then add the where clause
		hql.append(" AND cp.permissionType in ");
		this.appendCasePermissionsByArea(hql, true, true);

		// check the directorate level of the user
		String[] outdirs = null;

		if (null != directorates && !directorates.isEmpty()) {

			outdirs = getUserDirectorates(directorates, false);

			hql.append(" AND c.restrictTo in (:restrictToValues)");
		}

		final String[] indirs = outdirs;

		// Responsibilities for the user so that regional and org
		// code has a value to filter on
		hql.append(" AND cp.value in (:values)");
		hql.append(" ORDER BY c.caseNumber DESC");

		if (logger.isDebugEnabled()) {
			// debug...
			debugUserRespandDirectorates(indirs, responsibilites);
		}
		Query query = getCurrentSession().createQuery(hql.toString());

		query.setParameterList("values", responsibilites);

		if (!directorates.isEmpty()) {
			query.setParameterList("restrictToValues", indirs);
		}

		return query.list();

	}

	@Override
	public CaseUpdate saveCaseUpdate(CaseUpdate newUpdate) {

		return (CaseUpdate) getCurrentSession().merge(newUpdate);
	}

	@Override
	public List<CaseUpdate> loadCaseUpdatesByCaseId(Long caseId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(CaseUpdate.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.addOrder(Order.asc("caseUpdateId"));

		return criteria.getExecutableCriteria(getCurrentSession()).list();

	}

}
