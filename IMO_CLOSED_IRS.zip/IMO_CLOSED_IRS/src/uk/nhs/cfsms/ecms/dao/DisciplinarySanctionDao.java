package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppeal;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealOutcome;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealView;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanction;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionOffence;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionView;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;

public interface DisciplinarySanctionDao extends BaseDao {

	DisciplinarySanction loadDisciplinarySanctionById(Long sanctionId);
	
	List<DisciplinarySanctionView> loadDisciplinarySanctions(Long caseId);

	List<CaseContact> loadContactsByCaseId(Long caseId);
	
	List<DisciplinarySanctionHearing> loadDisciplinaryHearingList(Long sanctionId);	
	
	List<DisciplinarySanctionOffence> loadDisciplinaryOffenceList(Long sanctionId);
	
	List<DisciplinarySanctionOutcome> loadDisciplinaryOutcomeList(Long sanctionId);

	DisciplinarySanctionHearing loadDisciplinaryHearing(Long hearingId);

	DisciplinarySanctionOffence loadDisciplinaryOffence(Long sanctionId);

	DisciplinarySanctionOutcome loadDisciplinaryOutcome(Long outcomeId);
	
	List<OutcomeAppliedSanction> loadAppliedSanctions(Long outcomeId);
	
	void deleteAppliedSanctions(List<OutcomeAppliedSanction> list);

	DisciplinarySanctionOutcome saveDisciplinarySanctionOutcome(DisciplinarySanctionOutcome outcome);
	
	List<DisciplinaryAppeal> loadAppealsByParentSanctionId(Long sanctionId);
	
	DisciplinaryAppeal getDisciplinaryAppealDetails(Long appealId);

	List<DisciplinaryAppealView> loadDisciplinaryAppeals(Long caseId);
	
	DisciplinaryAppealView loadDisciplinaryAppeal(Long appealId);
	
	List<DisciplinaryAppealHearing> loadDisciplinaryAppealHearingList(Long appealId);	
	
	List<DisciplinaryAppealOutcome> loadAppealOutcomeList(Long sanctionId);

	DisciplinaryAppealHearing loadDisciplinaryAppealHearing(Long hearingId);

	DisciplinaryAppealOutcome saveDisciplinaryAppealOutcome(DisciplinaryAppealOutcome outcome);
	
	List<DisciplinaryAppeal> loadAppealsByParentAppealId(Long appealId);

	List<DisciplinaryAppealView> loadAppealsByCaseIdOrderByAppealedDate(
			Long caseId);

	DisciplinarySanctionView loadDisciplinarySanctionViewById(Long sanctionId);
	
}		