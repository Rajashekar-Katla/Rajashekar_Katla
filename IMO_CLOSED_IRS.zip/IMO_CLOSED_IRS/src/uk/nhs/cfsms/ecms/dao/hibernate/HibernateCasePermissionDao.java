package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.CasePermissionDao;
import uk.nhs.cfsms.ecms.data.cim.CasePermission;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

@Repository
public class HibernateCasePermissionDao extends HibernateBaseDao implements
		CasePermissionDao {

	private static final Class<CasePermission> CASE_PERMISSION = CasePermission.class;

	public List<CasePermission> saveCasePermissions(
			List<CasePermission> casePermissions) {

		List<CasePermission> returnList = new ArrayList<CasePermission>(); 
		//getHibernateTemplate().saveOrUpdateAll(casePermissions);
		if (null != casePermissions && !casePermissions.isEmpty()) {
			Session session = getCurrentSession();
			for(CasePermission curr : casePermissions){
				returnList.add((CasePermission) session.merge(curr));
			}
		}
		return returnList;
	}

	public List<CasePermission> loadCasePermissionsByCaseId(Long caseId) {
		
		DetachedCriteria criteria = DetachedCriteria.forClass(CASE_PERMISSION);
		criteria.add(Restrictions.eq("caseId", caseId));
		return criteria.getExecutableCriteria(getCurrentSession()).list();
	}

	public void deleteCasePermissionsByCaseId(Long caseId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(CASE_PERMISSION);
		criteria.add(Restrictions.eq("caseId", caseId));
		List<CasePermission> list = criteria.getExecutableCriteria(getCurrentSession()).list();

		this.updateDeleteFlag(list);
	}

	public void deleteAllExcptTeamCasePermissionsByCaseId(Long caseId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(CASE_PERMISSION);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.ne("permissionType",
				ECMSConstants.TEAM_PERMISSION));
		List<CasePermission> list = criteria.getExecutableCriteria(getCurrentSession()).list();

		this.updateDeleteFlag(list);
	}

	public List<CasePermission> loadAllCaseAssigneesByCaseId(Long caseId) {
		
		String[] permTypes = { 
					ECMSConstants.ASSIGNEE_PERMISSION, 
					ECMSConstants.CASE_ASSIGNEE_PERMISSION,
					ECMSConstants.SENIOR_INVESTIGATING_OFFICER_PERMISSION,
					ECMSConstants.DISCLOSURE_OFFICER_PERMISSION,
					ECMSConstants.FINANCIAL_INVESTIGATOR_PERMISSION,
					ECMSConstants.FORENSIC_COMPUTING_SPECIALIST_PERMISSION };
		
		DetachedCriteria criteria = DetachedCriteria.forClass(CASE_PERMISSION);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.in("permissionType", permTypes));
		List<CasePermission> list = criteria.getExecutableCriteria(getCurrentSession()).list();
		/*List<CasePermission> list = getHibernateTemplate().findByCriteria(
				criteria);*/
		return list;

	}

	public void deletePermissionByPermTypeAndCaseId(Long caseId,
			String[] permTypes) {

		DetachedCriteria criteria = DetachedCriteria.forClass(CASE_PERMISSION);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.in("permissionType", permTypes));
		Session session = getCurrentSession();
		List list = criteria.getExecutableCriteria(session).list();

		if (null != list && !list.isEmpty()) {
			//getHibernateTemplate().deleteAll(list);
			for(Object curr : list){
				session.delete(curr);
			}
		}
	}

	public CasePermission updateCasePermission(CasePermission permission) {
		//getHibernateTemplate().update(permission);
		return (CasePermission) getCurrentSession().merge(permission);

	}

	public CasePermission saveCasePermission(CasePermission casePermission) {

		//getHibernateTemplate().save(casePermission);
		return (CasePermission) getCurrentSession().merge(casePermission);
	}

	public CasePermission loadCasePermissionByPermissionId(Long permissionId) {
		
		DetachedCriteria criteria = DetachedCriteria.forClass(CASE_PERMISSION);
		criteria.add(Restrictions.eq("casePermissionId", permissionId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();
		
		if (null != list && !list.isEmpty()) {
			return (CasePermission) list.get(0);

		}
		return null;
	}

	public void deleteCasePermissionsByPermissionId(Long permissionId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(CASE_PERMISSION);
		criteria.add(Restrictions.eq("casePermissionId", permissionId));
		List<CasePermission> list = criteria.getExecutableCriteria(getCurrentSession()).list();
		
		this.updateDeleteFlag(list);
	}
	
	/**
	 * Helper to mark delete flag with an update, rather than delete the record
	 * @param list
	 */
	private void updateDeleteFlag(List<CasePermission> list) {
		
		if (null != list && !list.isEmpty()) {
			
			// getHibernateTemplate().deleteAll(list);
			
			Session session = getCurrentSession();
			for (CasePermission perm: list) {
				
				String permType = perm.getPermissionType();
				
				if (null != permType && (CaseUtil.isPermTypeInCasePermissions(permType))) {
		
					// Set delete Case Permission Type.
					perm.setPermissionType(CaseUtil.getDeleteCasePermType(permType));				
				}
				
				session.merge(perm);
			}				 
		}
	}
	
}
