package uk.nhs.cfsms.ecms.dao.hibernate;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Id;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.RevisionType;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.persister.entity.SingleTableEntityPersister;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.audit.AuditEntityContexualHelper;
import uk.nhs.cfsms.ecms.audit.AuditedPropertyInfo;
import uk.nhs.cfsms.ecms.audit.CustomTrackingRevisionEntity;
import uk.nhs.cfsms.ecms.audit.DisplayedLoggedProperty;
import uk.nhs.cfsms.ecms.audit.RevisionedEntityInfo;
import uk.nhs.cfsms.ecms.dao.AuditLogDao;
import uk.nhs.cfsms.ecms.data.common.AuditLog;
import uk.nhs.cfsms.ecms.data.common.Lookup;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

/**
 * Class to work with audit log entries to the table
 * 
 * @author Sukhraj Matharu
 * 
 * @modified Vijay Dabbas
 * 
 */
@Repository
public class HibernateAuditLogDao extends HibernateBaseDao implements
		AuditLogDao {

	@Override
	public void save(AuditLog auditLog) {
		try {
			String tableName = "";
			try {
				if (auditLog.getObjectClass() != null) {
					tableName = getTableName(auditLog.getObjectClass());
				}
			} catch (Exception e) {
				System.err.println("Error getting ClassMetadata for class="
						+ auditLog.getObjectClass());
			}
			auditLog.setTableName(tableName);
			getCurrentSession().save(auditLog);
		} catch (Exception e) {
			System.err.println("Error while Audting Log = "
					+ auditLog.toString());
		}
	}

	private String getTableName(Class objClass) {
		EntityManager entityManager; 
		
		//SessionFactory sf = this.getSessionFactory();
		String className = objClass.getSimpleName();

		if (className.indexOf("TO") != -1) {
			className = className.substring(0, className.indexOf("TO"));
			if (className.indexOf("Case") != -1) {
				className = "uk.nhs.cfsms.ecms.data.cim." + className;
			} else if (className.indexOf("Information") != -1) {
				className = "uk.nhs.cfsms.ecms.data.infoGath." + className;
			} else if (className.indexOf("CivilSanction") != -1) {
				className = "uk.nhs.cfsms.ecms.data.civilsanction." + className;
			} else if (className.indexOf("Attachment") != -1) {
				className = "uk.nhs.cfsms.ecms.data.common." + className;
			} else if (className.indexOf("Witness") != -1) {
				className = "uk.nhs.cfsms.ecms.data.witness." + className;
			} else if ((className.indexOf("Criminal") != -1)
					|| (className.indexOf("Disciplinary") != -1)
					|| (className.indexOf("Police") != -1)
					|| (className.indexOf("Court") != -1)
					|| (className.indexOf("Summons") != -1)
					|| (className.indexOf("Charge") != -1)) {
				className = "uk.nhs.cfsms.ecms.data.sanction." + className;
			}
		} else if (className.indexOf("File") != -1) {
			className = "uk.nhs.cfsms.ecms.data.common." + className;
		}

		SingleTableEntityPersister metadata = (SingleTableEntityPersister) getCurrentSession().getSessionFactory()
				.getClassMetadata(className);
		if (metadata != null)
			return metadata.getTableName();

		return "";
	}

	public List<AuditLog> getCaseProgressLog() {

		List<AuditLog> list = new ArrayList<AuditLog>();
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(
					AuditLog.class).add(
					Restrictions.eq("action", CaseUtil.CASE_PROGRESS));
			criteria.addOrder(Order.desc("createdDate"));

			list = criteria.getExecutableCriteria(getCurrentSession()).list();

		} catch (Exception e) {
			System.err.println("Error while Case Progress Log = "
					+ e.toString());
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AuditLog> getCaseLogsByCaseId(final Long caseId)
			throws ServiceException {
  
		String hql = "select log from AuditLog log where log.objectId='"
				+ caseId
				+ "' and log.state not in ('LOGGED IN','LOGGED OUT','RESET PASSWORD') order by log.createdDate Desc";

		Query query = getCurrentSession().createQuery(hql);
		return query.list();

	}

	@Override
	public List<CustomTrackingRevisionEntity> getCaseLogsById(String caseId) {
		
		Query query = getCurrentSession().createQuery(
						"Select distinct cr from AuditDetails cr where cr.caseId =:id order by cr.customTimestamp desc");
		query.setParameter("id", new Long(caseId)); 
		
		return query.list();
	}

	@Override
	public List<RevisionedEntityInfo> getAuditInfoForCaseAndRevision(
			Integer revId, Long caseId) {

		Session session = getCurrentSession();
		AuditReader auditreader = AuditReaderFactory.get(session);
		Map<RevisionType, List<Object>> allEntitiesList = auditreader
				.getCrossTypeRevisionChangesReader()
				.findEntitiesGroupByRevisionType(revId);
		/*
		 * Query query = session.createSQLQuery(
		 * "SELECT MAX(REV) FROM REVISION_HISTORY rh WHERE rh.CASE_ID = :caseId AND rh.REV < :revId"
		 * ); query.setParameter("caseId", caseId); query.setParameter("revId",
		 * revId); BigDecimal result = (BigDecimal) query.uniqueResult();
		 * Integer prevRevId = (result == null ? null : result.intValue());
		 */
		// List<Object> previousList =
		// auditreader.getCrossTypeRevisionChangesReader().findEntities(prevrevId,
		// RevisionType.MOD);

		List<RevisionedEntityInfo> auditInfoList = generateRevisionedEntities(
				revId, session, auditreader, allEntitiesList);
		return auditInfoList;
	}

	private List<RevisionedEntityInfo> generateRevisionedEntities(
			Integer revId, Session session, AuditReader auditreader,
			Map<RevisionType, List<Object>> allEntitiesList) {

		List<RevisionedEntityInfo> auditInfoList = new ArrayList<RevisionedEntityInfo>();

		List<Object> addedEntityList = allEntitiesList.get(RevisionType.ADD);

		if (addedEntityList != null && !addedEntityList.isEmpty()) {

			for (Object curr : addedEntityList) {
				auditInfoList.add(createAddedEntityInfo(curr));
				session.evict(curr);
			}
		}

		List<Object> deletedEntityList = allEntitiesList.get(RevisionType.DEL);

		if (deletedEntityList != null && !deletedEntityList.isEmpty()) {

			for (Object curr : deletedEntityList) {

				ClassMetadata entityMetaData = getCurrentSession().getSessionFactory()
						.getClassMetadata(curr.getClass());
				Object previousEntity = getPreviousVersion(curr, revId,
						entityMetaData.getIdentifier(curr,
								(SessionImplementor) session), auditreader);
				if (null != previousEntity) {
					auditInfoList.add(createDeletedEntityInfo(curr,
							previousEntity));
				}
				session.evict(curr);
				session.evict(previousEntity);
			}
		}
		List<Object> modifiedEntityList = allEntitiesList.get(RevisionType.MOD);

		if (modifiedEntityList != null && !modifiedEntityList.isEmpty()) {

			for (Object curr : modifiedEntityList) {

				ClassMetadata entityMetaData = getCurrentSession().getSessionFactory()
						.getClassMetadata(curr.getClass());
				Object previousEntity = getPreviousVersion(curr, revId,
						entityMetaData.getIdentifier(curr,
								(SessionImplementor) session), auditreader);
				if (null != previousEntity) {
					// Object previousEntity = auditreader.find(curr.getClass(),
					// entityMetaData.getIdentifier(curr, (SessionImplementor)
					// session), prevrevId);
					auditInfoList.add(createModifiedEntityInfo(curr,
							previousEntity));
				}
				session.evict(curr);
				session.evict(previousEntity);
			}
		}
		return auditInfoList;
	}

	private <T> T getPreviousVersion(Object curr, Integer current_rev,
			Serializable serializable, AuditReader reader) {

		Number prior_revision = (Number) reader.createQuery()
				.forRevisionsOfEntity(curr.getClass(), false, true)
				.addProjection(AuditEntity.revisionNumber().max())
				.add(AuditEntity.id().eq(serializable))
				.add(AuditEntity.revisionNumber().lt(current_rev))
				.getSingleResult();

		if (prior_revision != null) {
			return (T) reader.find(curr.getClass(), serializable,
					prior_revision);
		}
		return null;

	}

	private RevisionedEntityInfo createAddedEntityInfo(Object obj) {

		RevisionedEntityInfo info = new RevisionedEntityInfo();
		String entityName = extractClassName(obj.getClass().getName());
		info.setEntityName(entityName);
		info.setOperationType("Created");
		setContextualInfo(info, obj);
		return generateInfoData(info, obj, null, RevisionType.ADD);

	}

	private RevisionedEntityInfo createDeletedEntityInfo(Object newState,
			Object oldState) {

		RevisionedEntityInfo info = new RevisionedEntityInfo();
		String entityName = extractClassName(oldState.getClass().getName());
		info.setEntityName(entityName);
		info.setOperationType("Deleted");
		setContextualInfo(info, oldState);
		return generateInfoData(info, newState, oldState, RevisionType.DEL);

	}

	private RevisionedEntityInfo createModifiedEntityInfo(Object newState,
			Object oldstate) {

		RevisionedEntityInfo info = new RevisionedEntityInfo();
		String entityName = extractClassName(newState.getClass().getName());
		info.setEntityName(entityName);
		info.setOperationType("Modified");
		setContextualInfo(info, newState);
		return generateInfoData(info, newState, oldstate, RevisionType.MOD);

	}

	private RevisionedEntityInfo generateInfoData(RevisionedEntityInfo revInfo,
			Object t, Object t2, RevisionType revType) {

		Field[] fields = t.getClass().getDeclaredFields();
		if (fields != null) {
			for (Field field : fields) {
				/*
				 * if (!(field.isAnnotationPresent(OneToMany.class) ||
				 * field.isAnnotationPresent(ManyToOne.class) ||
				 * field.isAnnotationPresent(OneToOne.class) ||
				 * field.isAnnotationPresent(Lob.class) ||
				 * field.isAnnotationPresent(Id.class ) ||
				 * Modifier.isFinal(field.getModifiers()) ||
				 * Modifier.isStatic(field.getModifiers()))) {
				 */
				if (field.isAnnotationPresent(Id.class)) {
					field.setAccessible(true);
					String propertyName = field.getName();
					String propertyValue = "";
					try {
						Object val = field.get(t);
						val = (val != null ? val.toString() : null);
						if (val != null) {
							propertyValue = (String) val;
							revInfo.setPrimaryKey(propertyName + "="
									+ propertyValue);
						}
					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					}
				}
				if (field.isAnnotationPresent(DisplayedLoggedProperty.class)) {
					field.setAccessible(true);
					AuditedPropertyInfo propInfo = new AuditedPropertyInfo();
					String propertyName = field.getName();

					DisplayedLoggedProperty annotation = field
							.getAnnotation(DisplayedLoggedProperty.class);
					propertyName = annotation.displayName();
					// When blank.
					if (StringUtils.isEmpty(propertyName)) {
						propertyName = field.getName();
					}
					propInfo.setPropertyName(propertyName);
					try {
						if (RevisionType.ADD.equals(revType)) {
							Object val = field.get(t); 
							
							if (val instanceof Timestamp) { 
								propInfo.setModifiedValue(ECMSConstants.datetimeFormat.format(val));
							}
							else {
								val = (val != null ? val.toString() : null);
								if (val != null) {
									if (annotation.isList()
											&& "LOOK_UP_TABLE".equals(annotation
													.listType())) {

										setUpListValues(propInfo, null,
												(String) val);
									} else {
										propInfo.setModifiedValue((String) val);
										
									}

								} else {
									continue;
								}
							}
						} else if (RevisionType.DEL.equals(revType)) {
							
							Object val = field.get(t2);
							
							if (val instanceof Timestamp) { 
								propInfo.setPreviousValue(ECMSConstants.datetimeFormat.format(val));
							}
							else {
								val = val != null ? val.toString() : null;
								if (val != null) {
									if (annotation.isList()
											&& "LOOK_UP_TABLE".equals(annotation
													.listType())) {
										setUpListValues(propInfo, (String) val,
												null);
									} else {
										propInfo.setPreviousValue((String) val);
									}
								} else {
									continue;
								}
							}
						} else {
							Object val = field.get(t);
							if (val instanceof Timestamp) {
								
								propInfo.setModifiedValue(ECMSConstants.datetimeFormat.format(val));
							}
							else {
								val = val != null ? val.toString() : "";
							}
							Object val2 = field.get(t2);
							
							if (val2 instanceof Timestamp) {
								 
								propInfo.setPreviousValue(ECMSConstants.datetimeFormat.format(val2));							
							}
							else {
								
								val2 = val2 != null ? val2.toString() : "";

								// Fix: ClassCastException: java.sql.Timestamp cannot be cast to java.lang.String	
								val = val != null ? val.toString() : "";
								
								if (!StringUtils.equals((String) val, (String) val2)) {
									
									if (annotation.isList() && "LOOK_UP_TABLE".equals(annotation.listType())) {
										
										setUpListValues(propInfo, (String) val2, (String) val);
										
									} else {
										propInfo.setModifiedValue((String) val);
										propInfo.setPreviousValue(((String) val2));
									}
								} else {
									continue;
								}
							}
							
						}
					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					}
					revInfo.getPropertiesList().add(propInfo);
				}
			}
		}
		return revInfo;
	}

	private void setContextualInfo(RevisionedEntityInfo revInfo, Object t) {

		DisplayedLoggedProperty classInfo = t.getClass().getAnnotation(
				DisplayedLoggedProperty.class);

		if (classInfo != null
				&& (StringUtils.isNotBlank(classInfo.detailsMethod()))) {

			String methodName = classInfo.detailsMethod();
			Class targetClass = t.getClass();
			Method method = null;
			Object[] methodArgs = null;

			if (methodName.startsWith("Helper.")) {
				targetClass = AuditEntityContexualHelper.class;
				methodName = methodName.substring("Helper.".length());
				methodArgs = new Object[2];
				methodArgs[0] = getCurrentSession().getSessionFactory();
				methodArgs[1] = t;
			}
			try {

				if (methodArgs != null) {

					method = targetClass.getMethod(methodName,
							EntityManager.class, t.getClass());
					revInfo.setKeyDetails((String) method.invoke(null,
							methodArgs));

				} else {

					method = targetClass.getMethod(methodName);
					revInfo.setKeyDetails((String) method.invoke(t));
				}

			} catch (Exception exc) {
				logger.error("Exception while getting audit info for "
						+ t.getClass());
			}

		}
	}

	private void setUpListValues(AuditedPropertyInfo propertyInfo,
			String oldVal, String newVal) {

		if (StringUtils.isNotBlank(oldVal)) {

			Lookup oldLookUp = (Lookup) getCurrentSession()
					.get(Lookup.class, Integer.parseInt(oldVal));
			if (null != oldLookUp) {
				propertyInfo.setPreviousValue(oldLookUp.getDescription());
			}
		}
		if (StringUtils.isNotBlank(newVal)) {

			Lookup newLookUp = (Lookup) getCurrentSession()
					.get(Lookup.class, Integer.parseInt(newVal));
			if (newLookUp != null) {
				propertyInfo.setModifiedValue(newLookUp.getDescription());
			}
		}
	}

	private String extractClassName(String name) {

		if (StringUtils.isNotBlank(name)) {
			int lastPeriod = StringUtils.lastIndexOf(name, ".");
			if (lastPeriod >= 0) {
				name = name.substring(lastPeriod + 1);
			}
		}
		return name == null ? "" : name;
	}

	@Override
	public List<CustomTrackingRevisionEntity> getInfoLogsById(Long infoID) {

		Session session = getCurrentSession();
		Query query = session
				.createQuery("Select distinct cr from AuditDetails cr where cr.informationId =:id order by cr.customTimestamp desc");
		query.setParameter("id", new Long(infoID));

		// getAuditInfoForRevision(132, 11220l );
		session.clear();

		return query.list();
	}

	@Override
	public List<RevisionedEntityInfo> getAuditInfoForInformationRevision(
			Integer revisionID, Long infoId) {

		Session session = getCurrentSession();
		AuditReader auditReader = AuditReaderFactory.get(session);
		Map<RevisionType, List<Object>> allEntitiesList = auditReader
				.getCrossTypeRevisionChangesReader()
				.findEntitiesGroupByRevisionType(revisionID);
		/*
		 * Query query = session.createSQLQuery(
		 * "SELECT MAX(REV) FROM REVISION_HISTORY rh WHERE rh.INFORMATION_ID = :infoId AND rh.REV < :revId"
		 * ); query.setParameter("infoId", infoId); query.setParameter("revId",
		 * revisionID); BigDecimal result = (BigDecimal) query.uniqueResult();
		 * Integer prevRevId = (result == null ? null : result.intValue());
		 */

		List<RevisionedEntityInfo> auditInfoList = generateRevisionedEntities(
				revisionID, session, auditReader, allEntitiesList);

		return auditInfoList;
	}

	@Override
	public List<CustomTrackingRevisionEntity> retrieveAudit(boolean isCase,
			Long id) {

		List<CustomTrackingRevisionEntity> revisionList;
		if (isCase) {
			revisionList = getCaseLogsById(id.toString());
		} else {
			revisionList = getInfoLogsById(id);
		}
		Session session = getCurrentSession();
		
		if (revisionList != null) {
		
			for (CustomTrackingRevisionEntity curr : revisionList) {
			
				session.evict(curr);
				List<RevisionedEntityInfo> revList = null;
				
				if (isCase) {
					revList = getAuditInfoForCaseAndRevision(
							curr.getCustomId(), id);
				} else {
					revList = getAuditInfoForInformationRevision(
							curr.getCustomId(), id);
				}
				curr.setRevisionInfoList(revList);

			}
		}
		return revisionList;
	}

}
