package uk.nhs.cfsms.ecms.dao;

import java.text.ParseException;
import java.util.List;

import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.data.infoGath.SubjectInformation;
import uk.nhs.cfsms.ecms.data.witness.Witness;
import uk.nhs.cfsms.ecms.dto.witness.WitnessTO;

@Repository
public interface WitnessDao {

	public List loadWitnessesByCaseId(Long caseId);

	public Witness loadWitnessById(Long witnessId);

	public Witness saveWitness(Witness witness);
	
	public Witness mergeWitness(Witness witness);

	public Witness updateWitness(Witness witness);

	public List<Witness> loadAllWitnessesByCaseId(Long caseId, String byFilter);

	public void updateWitnessToSubject(SubjectInformation subject);
	
	public List<Witness> loadWitnessByNativeSql(final String firstName,
			final String lastName, final String dob) throws ParseException;
	
	public List<WitnessTO> loadAllWitnessesByCaseIdForExhibit(final long caseId);
	
	public WitnessTO loadWitnessesByIdForExhibit(final long witnessId) ;
}
