package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.CPSDocumentsDao;
import uk.nhs.cfsms.ecms.data.cim.CPSDocumentsNamingRules;
import uk.nhs.cfsms.ecms.data.cim.CPSDocumentsView;
import uk.nhs.cfsms.ecms.data.cim.CPSFileNamingRulesDocument;
import uk.nhs.cfsms.ecms.data.cim.CPSMailFormFields;
import uk.nhs.cfsms.ecms.data.cps.CPSRequestTbl;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

/**
 * This is the DAO layer for the CPS Documents submission handling.
 * 
 * 
 * */
@Repository(value = "cPSDocumentDao")
public class HibernateCPSDocumentDao implements CPSDocumentsDao {

	@PersistenceContext
	EntityManager entityManager;

	/**
	 * This DAO Method is responsible for saving the state CPS document request.
	 * 
	 * @param CPSRequestTbl
	 *            cpsRequestTbl
	 * @return CPSRequestTbl
	 * */
	@Override
	public CPSRequestTbl save(CPSRequestTbl cpsRequestTbl) {
		cpsRequestTbl = (CPSRequestTbl) getHibernateSession().merge(
				cpsRequestTbl);
		return cpsRequestTbl;
	}

	@Override
	public List<CPSDocumentsNamingRules> getCPSDocumentsNamingRules() {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(CPSDocumentsNamingRules.class);
		Session session = getHibernateSession().getSessionFactory()
				.openSession();
		@SuppressWarnings("unchecked")
		List<CPSDocumentsNamingRules> list = criteria.getExecutableCriteria(
				session).list();

		return list;
	}

	@Override
	public void saveCPSFileNamingRulesDocument(
			final CPSFileNamingRulesDocument cpsFileNamingRulesDocument) {
		getHibernateSession().merge(cpsFileNamingRulesDocument);
	}

	@Override
	public CPSFileNamingRulesDocument loadCPSFileNamingRulesDocument()
			throws ServiceException {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(CPSFileNamingRulesDocument.class);
		criteria.addOrder(Order.asc("createdTime"));

		Session session = getHibernateSession().getSessionFactory()
				.openSession();
		@SuppressWarnings("unchecked")
		final List<CPSFileNamingRulesDocument> cpsFileNamingRulesDocument = criteria
				.getExecutableCriteria(session).list();
		return cpsFileNamingRulesDocument
				.get(cpsFileNamingRulesDocument.size() - 1);

	}

	@Override
	public List<CPSDocumentsView> loadAllCPSDocsRequestsByNativeSql(final long caseID) {

		final String sql = "select * from table(first.CPS_DOCLIST_FUNCTION(:caseID,:REJ,:NEW,:APR))";
		final SQLQuery query = getHibernateSession().createSQLQuery(sql);

		query.setParameter("caseID", caseID);
		query.setParameter("REJ", "REJ");
		query.setParameter("NEW", "NEW");
		query.setParameter("APR", "APR");
		query.addEntity(CPSDocumentsView.class);

		@SuppressWarnings("unchecked")
		final List<CPSDocumentsView> results = query.list();
		return results;
	}

	@Override
	public List<CPSDocumentsView> loadAllCPSDocsRequestsByNativeSql_ToApprove(
			final String staffID, long caseID) {

		final String sql = "select * from table(first.CPS_DOCLIST_FUNCTION(:caseID,:status))";

		final SQLQuery query = getHibernateSession().createSQLQuery(sql);
		query.setParameter("caseID", caseID);
		query.setParameter("status", "NEW");
		query.addEntity(CPSDocumentsView.class);

		@SuppressWarnings("unchecked")
		final List<CPSDocumentsView> results = query.list();

		return results;
	}

	@Override
	public List<CPSDocumentsView> loadAllApprovedCPSDocsByNativeSql(
			final String staffID, long caseID) {
		final String sql = "select * from table(first.CPS_DOCLIST_FUNCTION(:caseID,:APR))";

		final SQLQuery query = getHibernateSession().createSQLQuery(sql);
		query.setParameter("caseID", caseID);
		query.setParameter("APR", "APR");
		query.addEntity(CPSDocumentsView.class);

		@SuppressWarnings("unchecked")
		final List<CPSDocumentsView> results = query.list();
		return results;
	}

	/**
	 * This method is responsible for retrieving all requests history.
	 * 
	 * @param String
	 *            staffID
	 * @param long caseID
	 * 
	 * @return CPSDocsSubmit
	 * */
	@SuppressWarnings("unchecked")
	public List<CPSRequestTbl> loadAllRequestsHistory(final String staffID,
			final long caseID) {
		final DetachedCriteria criteria = DetachedCriteria
				.forClass(CPSRequestTbl.class);
		criteria.add(Restrictions.eq("caseId", caseID));
		criteria.addOrder(Order.desc("createdTime"));

		final List<CPSRequestTbl> CPSRequestTbl = criteria
				.getExecutableCriteria(getHibernateSession()).list();

		return CPSRequestTbl;
	}

	/**
	 * This DAO Method is responsible for updating the state CPS document
	 * request.
	 * 
	 * @param CPSRequestTbl
	 *            cpsDocReq
	 * @return CPSRequestTbl
	 * 
	 * */
	@Override
	public CPSRequestTbl update(CPSRequestTbl cpsDocReq) {
		CPSRequestTbl cpsdocs = (CPSRequestTbl) getHibernateSession().merge(
				cpsDocReq);

		return cpsdocs;
	}

	private Session getHibernateSession() {
		return entityManager.unwrap(Session.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CPSMailFormFields> getCPSFormFields() {
		final DetachedCriteria criteria = DetachedCriteria
				.forClass(CPSMailFormFields.class);
		final List<CPSMailFormFields> list = criteria.getExecutableCriteria(
				getHibernateSession()).list();
		return list;
	}

	@Override
	public String getCPSDocsRequestorStaffID(final long caseID) {
		final DetachedCriteria criteria = DetachedCriteria
				.forClass(CPSRequestTbl.class);
		criteria.add(Restrictions.eq("caseId", caseID));
		criteria.setProjection(Projections.distinct(Projections
				.property("createdStaffId")));
		@SuppressWarnings("unchecked")
		final List<String> list = criteria.getExecutableCriteria(
				getHibernateSession()).list();
		if (list.size() > 0) {
			return list.get(0);
		} else {
			return null;
		}
	}
}
