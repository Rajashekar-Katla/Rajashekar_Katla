package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.CaseTransferDao;
import uk.nhs.cfsms.ecms.data.cim.CaseTransfer;

@Repository
public class HibernateCaseTransferDao extends HibernateBaseDao  implements CaseTransferDao {
	
		
	public CaseTransfer loadCaseTransferById(Long transferId)
	{
		DetachedCriteria criteria = DetachedCriteria.forClass(CaseTransfer.class);
		criteria.add(Restrictions.eq("caseTransferId", transferId));
		
		List<CaseTransfer> list = criteria.getExecutableCriteria(getCurrentSession()).list();
		
		if (null != list && !list.isEmpty()) {
			return (CaseTransfer)list.get(0);
		}
		return null;
	}
	
	public CaseTransfer saveCaseTransfer(CaseTransfer caseTransfer)
	{
		return (CaseTransfer) getCurrentSession().merge(caseTransfer);
	}
	
	public CaseTransfer updateCaseTransfer(CaseTransfer caseTransfer)
	{
		return (CaseTransfer) getCurrentSession().merge(caseTransfer);
	}
	
	public List<CaseTransfer> loadLcfsTransfers(String staffId,String state[],boolean received)
	{
		DetachedCriteria criteria = DetachedCriteria.forClass(CaseTransfer.class);
		if(received) {
			criteria.add(Restrictions.eq("receipentLcfs", staffId));
		}
		else {
			criteria.add(Restrictions.eq("createdStaffId", staffId));
		}
		criteria.add(Restrictions.in("state",state));
		
		criteria.add(Restrictions.eq("transferType",ECMSConstants.TRANSFER_LCFS));
		
		return criteria.getExecutableCriteria(getCurrentSession()).list();
	}
	
	public List<CaseTransfer> loadCfsTransfers(String[] teams,String staffId,String[] state,boolean received)
	{
				
		DetachedCriteria criteria = DetachedCriteria.forClass(CaseTransfer.class);
		
		if(received) {
			
			criteria.add(Restrictions.in("recipientTeamCode", teams));
		}	
		else {
			  criteria.add(Restrictions.eq("createdStaffId", staffId));
		}
		criteria.add(Restrictions.in("state",state));
		criteria.add(Restrictions.eq("transferType",ECMSConstants.TRANSFER_CFS));
			
		return  criteria.getExecutableCriteria(getCurrentSession()).list();
	}
	
	
	public List<CaseTransfer> loadPendingApprovalCfsTransfers(final String[] teamCodes)
	{
		StringBuffer sqlString=new StringBuffer(" select ct from CaseTransfer ct,CasePermission cp " );
		sqlString.append(" where ct.transferType ='");
		sqlString.append(ECMSConstants.TRANSFER_CFS +"' and ");
		sqlString.append(" ct.caseObject.caseId=cp.caseId  and ");
		sqlString.append(" ct.state='");
		sqlString.append(ECMSConstants.TRANSFER_APPROVAL_PENDING + "' and ");
		sqlString.append(" cp.permissionType ='");
		sqlString.append(ECMSConstants.TEAM_PERMISSION);
	    sqlString.append("' and value in (:teamCodes)");	
	    Query query = getCurrentSession().createQuery(sqlString.toString());
	    query.setParameterList("teamCodes",teamCodes);
	    List transferList = query.list();
		
		/*List transferList = getHibernateTemplate().executeFind(new HibernateCallback() {

			public Object doInHibernate(Session session) throws HibernateException, SQLException {
				
				StringBuffer sqlString=new StringBuffer(" select ct from CaseTransfer ct,CasePermission cp " );
				sqlString.append(" where ct.transferType ='");
				sqlString.append(ECMSConstants.TRANSFER_CFS +"' and ");
				sqlString.append(" ct.caseObject.caseId=cp.caseId  and ");
				sqlString.append(" ct.state='");
				sqlString.append(ECMSConstants.TRANSFER_APPROVAL_PENDING + "' and ");
				sqlString.append(" cp.permissionType ='");
				sqlString.append(ECMSConstants.TEAM_PERMISSION);
			    sqlString.append("' and value in (:teamCodes)");	
				
				Query query=session.createQuery(sqlString.toString());
			    query.setParameterList("teamCodes",teamCodes);
			    
			  return query.list();	
			}
		});
*/		
		return transferList;
	}
	
	
	public List<CaseTransfer> loadPendingApprovalLcfsTransfers(final String[] teamCodes)
	{
		
		StringBuffer sqlString=new StringBuffer(" select ct from CaseTransfer ct,CasePermission cp " );
		sqlString.append(" where ct.transferType ='");
		sqlString.append(ECMSConstants.TRANSFER_LCFS +"' and ");
		sqlString.append(" ct.caseObject.caseId=cp.caseId  and ");
		sqlString.append(" ct.state='");
		sqlString.append(ECMSConstants.TRANSFER_APPROVAL_PENDING + "' and ");
		sqlString.append(" cp.permissionType ='");
		sqlString.append(ECMSConstants.TEAM_PERMISSION);
	    sqlString.append("' and value in (:teamCodes)");	
						
		Query query = getCurrentSession().createQuery(sqlString.toString());
		List transferList = query.setParameterList("teamCodes",teamCodes).list();
	    
		/*List transferList = getHibernateTemplate().executeFind(new HibernateCallback() {

			public Object doInHibernate(Session session) throws HibernateException, SQLException {
				
				StringBuffer sqlString=new StringBuffer(" select ct from CaseTransfer ct,CasePermission cp " );
				sqlString.append(" where ct.transferType ='");
				sqlString.append(ECMSConstants.TRANSFER_LCFS +"' and ");
				sqlString.append(" ct.caseObject.caseId=cp.caseId  and ");
				sqlString.append(" ct.state='");
				sqlString.append(ECMSConstants.TRANSFER_APPROVAL_PENDING + "' and ");
				sqlString.append(" cp.permissionType ='");
				sqlString.append(ECMSConstants.TEAM_PERMISSION);
			    sqlString.append("' and value in (:teamCodes)");	
								
				Query query=session.createQuery(sqlString.toString());
			    query.setParameterList("teamCodes",teamCodes);
			  return query.list();	
			}
		});*/
		
		return transferList;
	}
	
	
	public List<CaseTransfer> loadCaseCfsTransfersByCaseId(final Long caseIDLong)
	{
		StringBuffer sqlString = new StringBuffer(" select ct from CaseTransfer ct" );
		sqlString.append(" where ct.caseObject.caseId='");
		sqlString.append(caseIDLong +"' and ");
		sqlString.append(" ct.transferType='");	
		sqlString.append(ECMSConstants.TRANSFER_CFS+ "'");
		Query query = getCurrentSession().createQuery(sqlString.toString());
		List transferList = query.list();
		return transferList;
	}

	public List<CaseTransfer> loadCaseLcfsTransfersByCaseId(final Long caseIDLong)
	{
		
		StringBuffer sqlString = new StringBuffer(" select ct from CaseTransfer ct" );
		sqlString.append(" where ct.caseObject.caseId='");
		sqlString.append(caseIDLong +"' and");
		sqlString.append(" ct.transferType='");	
		sqlString.append(ECMSConstants.TRANSFER_LCFS+ "'");
		Query query = getCurrentSession().createQuery(sqlString.toString());
		List transferList = query.list();
		/*List transferList = getHibernateTemplate().executeFind(new HibernateCallback() {

			public Object doInHibernate(Session session) throws HibernateException, SQLException {
				
				StringBuffer sqlString=new StringBuffer(" select ct from CaseTransfer ct" );
				sqlString.append(" where ct.caseObject.caseId='");
				sqlString.append(caseIDLong +"' and");
				sqlString.append(" ct.transferType='");	
				sqlString.append(ECMSConstants.TRANSFER_LCFS+ "'");
				Query query=session.createQuery(sqlString.toString());
			    
			    
			  return query.list();	
			}
		});
*/		
		return transferList;
	}
	
	
	public List<CaseTransfer> loadPendingTransfersByCaseId(final Long caseId)
	{
		StringBuffer sqlString=new StringBuffer(" select ct from CaseTransfer ct " );
		sqlString.append(" where ");
		sqlString.append(" ct.caseObject.caseId='");
		sqlString.append(caseId + "' and ");
		sqlString.append(" ct.state in ('");
		sqlString.append(ECMSConstants.TRANSFER_REFERRED+"','");
		sqlString.append(ECMSConstants.TRANSFER_APPROVAL_PENDING+"')");
	    Query query = getCurrentSession().createQuery(sqlString.toString());
	    
	    List transferList = query.list();	
		
	    /*List transferList = getHibernateTemplate().executeFind(new HibernateCallback() {

			public Object doInHibernate(Session session) throws HibernateException, SQLException {
				
				StringBuffer sqlString=new StringBuffer(" select ct from CaseTransfer ct " );
				sqlString.append(" where ");
				sqlString.append(" ct.caseObject.caseId='");
				sqlString.append(caseId + "' and ");
				sqlString.append(" ct.state in ('");
				sqlString.append(ECMSConstants.TRANSFER_REFERRED+"','");
				sqlString.append(ECMSConstants.TRANSFER_APPROVAL_PENDING+"')");
			    Query query=session.createQuery(sqlString.toString());
			   
			  return query.list();	
			}
		});*/
		
		return transferList;	
	}

}
