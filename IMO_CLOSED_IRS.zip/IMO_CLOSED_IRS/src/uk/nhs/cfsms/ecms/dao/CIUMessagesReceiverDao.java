package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.common.CIUMessagesReceiver;

public interface CIUMessagesReceiverDao {

	String getActiveStaffId();

	void activateUserToReceiveMessages(String staffId);

	List<CIUMessagesReceiver> getAllCIUMessageReceivers();
}
