package uk.nhs.cfsms.ecms.dao.hibernate;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.InformationDao;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.cim.InformationObject;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.OrganisationTeamCode;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.ClosedInformationView;
import uk.nhs.cfsms.ecms.data.infoGath.FcrolInformation;
import uk.nhs.cfsms.ecms.data.infoGath.FcrolInformationView;
import uk.nhs.cfsms.ecms.data.infoGath.InfoTransferHistory;
import uk.nhs.cfsms.ecms.data.infoGath.Information;
import uk.nhs.cfsms.ecms.data.infoGath.InformationPermission;
import uk.nhs.cfsms.ecms.data.infoGath.InformationView;
import uk.nhs.cfsms.ecms.data.infoGath.Person;
import uk.nhs.cfsms.ecms.data.witness.Witness;
import uk.nhs.cfsms.ecms.dto.caseInfo.MessageTO;
import uk.nhs.cfsms.ecms.dto.infoGath.InformationTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.service.UserInformationService;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.ConvertToDTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;
import uk.nhs.cfsms.ecms.utility.InformationUtil;

@Repository
public class HibernateInformationDao extends HibernateBaseDao implements
		InformationDao {

	@Autowired
	private UserInformationService userInformationService;

	protected final Log log = LogFactory.getLog(getClass());

	public InformationTO saveInformation(InformationTO dto, SessionUser user) {

		Information hibernate = ConvertFromDTO.getInstance()
				.convertFromDTO(dto);

		Organisation org = getOrganisation(hibernate.getOrganisation()
				.getOrgCode());

		if (org != null) {
			hibernate.setOrganisation(org);
		}
		hibernate = (Information) getCurrentSession().merge(hibernate);

		// Save Information Permissions.
		savePermission(hibernate, user);

		// Save Information Transfer History.
		// Save information is called for updating information as well.

		saveInfoTransHistory(hibernate);

		return ConvertToDTO.getInstance().convertToDTO(hibernate);
	}

	public void updateInformation(InformationTO dto, boolean updatePermission,
			SessionUser user) {

		Information hibernate = ConvertFromDTO.getInstance()
				.convertFromDTO(dto);
		String hibOrgCode = hibernate.getOrganisation().getOrgCode();
		Long infoId = hibernate.getInformationId();
		String regionOverride = hibernate.getRegionOverride();
		// Load organisation by orgCode to have up-to-date Organisation.
		Organisation org = this.getOrganisation(hibOrgCode);

		if (null != org) {

			hibernate.setOrganisation(org);
		}
		// Save or Update Information.
		/*
		 * if (null != infoId && null != hibernate.getCaseId()) {
		 * 
		 * this.getHibernateTemplate().merge(hibernate);
		 * 
		 * } else {
		 * 
		 * this.getHibernateTemplate().saveOrUpdate(hibernate); }
		 */
		hibernate = (Information) getCurrentSession().merge(hibernate);
		// Update Information Permissions.
		if (updatePermission
				&& dto.getState() != null
				&& !dto.getState().equalsIgnoreCase(
						ECMSConstants.INFO_TRANSFERRED)) {

			updatePermission(hibernate, user);
		}
		// Update Information Transfer History.
		if (null != regionOverride && regionOverride.equalsIgnoreCase("Y")) {

			updateInfoTransHistory(infoId, hibernate.getTeamCode());

		} else {

			updateInfoTransHistory(infoId, getTeamCode(hibOrgCode));
		}
	}

	/**
	 * Get the organisation.
	 * 
	 * @param orgCode
	 * @return Organisation
	 */
	private Organisation getOrganisation(String orgCode) {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				Organisation.class).add(Restrictions.idEq(orgCode));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (list != null && !list.isEmpty()) {
			return (Organisation) list.get(0);
		}

		return null;
	}

	public InformationTO loadInformationById(Long informationId) {

		InformationTO dto = null;
		DetachedCriteria criteria = DetachedCriteria
				.forClass(Information.class).add(
						Restrictions.idEq(informationId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (list != null && !list.isEmpty()) {

			Information info = (Information) list.get(0);

			dto = ConvertToDTO.getInstance().convertToDTO(info);

			dto.setHasPrimarySubject(hasPrimarSubject(informationId));
		}
		return dto;
	}

	public InformationTO loadFcrolInformationById(Long informationId) {
		InformationTO dto = null;
		DetachedCriteria criteria = DetachedCriteria.forClass(
				FcrolInformation.class).add(Restrictions.idEq(informationId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (list != null && !list.isEmpty()) {

			FcrolInformation info = (FcrolInformation) list.get(0);

			dto = ConvertToDTO.getInstance().convertToDTO(info);

			dto.setHasPrimarySubject(hasPrimarSubject(informationId));
		}
		return dto;
	}

	/**
	 * Check for Information has a primary subject.
	 * 
	 * @param informationId
	 * 
	 * @return boolean
	 */
	private Boolean hasPrimarSubject(Long informationId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				InformationView.class).add(Restrictions.idEq(informationId));
		criteria.add(Restrictions.isNotNull("subjectName"));

		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (list != null && !list.isEmpty()) {
			return true;
		}
		return false;
	}

	public List<InformationTO> loadAllInformation(String staffId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(Information.class).add(
						Restrictions.eq("createdStaffId", staffId));

		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		// No criteria for ordering, Delegate ordering to front end.
		return criteria.getExecutableCriteria(getCurrentSession()).list();
	}

	public void save(InformationTO dto, SessionUser user) {

		Information hibernate = ConvertFromDTO.getInstance()
				.convertFromDTO(dto);

		Organisation org = getOrganisation(hibernate.getOrganisation()
				.getOrgCode());

		if (org != null) {
			hibernate.setOrganisation(org);
		}

		hibernate = (Information) getCurrentSession().merge(hibernate);

		// Update permission.. Also saving if one is not available.
		// If information is transferred or rejected transfer no need to
		// update permissions
		String state = hibernate.getState();

		if (null == state
				|| (null != state && (!state
						.equalsIgnoreCase(ECMSConstants.INFO_TRANSFERRED) && !state
						.equalsIgnoreCase(ECMSConstants.INFO_STATE_REJECT_TRANSFER)))) {

			updatePermission(hibernate, user);
		}

		String regionOverride = hibernate.getRegionOverride();

		if (null != regionOverride && regionOverride.equalsIgnoreCase("Y")) {

			updateInfoTransHistory(hibernate.getInformationId(),
					hibernate.getTeamCode());

		} else {
			updateInfoTransHistory(hibernate.getInformationId(),
					getTeamCode(hibernate.getOrganisation().getOrgCode()));
		}
	}

	public void savePermission(Information info, SessionUser user) {

		Date createdDate = new Date();

		InformationPermission assigneeHibernate = createInformationPermission(
				info, createdDate, ECMSConstants.INFO_ASSIGNEE_PERMISSION);
		assigneeHibernate = (InformationPermission) getCurrentSession().merge(
				assigneeHibernate);

		// if user is lcfs or fcrl then only enter org_code permission.
		// TODO: please cross check permission issues for information.--venkat
		// ---important
		/*
		 * if (user.isUserLCFS() || user.isUserFCRL()) { InformationPermission
		 * orgCodeHib = createInformationPermission( info, createdDate,
		 * ECMSConstants.ORGANISATIONAL_PERMISSION);
		 * this.getHibernateTemplate().save(orgCodeHib); }
		 */

		if (user.isUserLCFS()) {
			InformationPermission orgCodeHib = createInformationPermission(
					info, createdDate, ECMSConstants.ORGANISATIONAL_PERMISSION);
			getCurrentSession().save(orgCodeHib);
		}

		// NATIONAL level Users do not use INFORMATION TeamCode.
		if (user.isUserNationalLevel()) {

			/*
			 * Commented out coz if user is national level,add team permission
			 * as his employer org code. Revise if nessary depending on user
			 * comments.Venkat-26/08/2009 for (String teamCode :
			 * user.getOrgOrTeamResponsibilityList()) { InformationPermission
			 * teamCodeHib = createInformationNatPermission( info, createdDate,
			 * ECMSConstants.TEAM_PERMISSION, teamCode);
			 * 
			 * this.getHibernateTemplate().save(teamCodeHib); }
			 */

			InformationPermission teamCodePerm = InformationUtil
					.createInfoPermission(info.getInformationId(),
							ECMSConstants.TEAM_PERMISSION,
							user.getEmployerOrgCode(), info.getCreatedStaffId());
			if (info.getTeamCode().equals(ECMSConstants.TEAM_DHAFU)) {
				teamCodePerm.setPermissionValue(ECMSConstants.TEAM_DHAFU);
			}

			getCurrentSession().save(teamCodePerm);

		} else {
			InformationPermission teamCodeHib = createInformationPermission(
					info, createdDate, ECMSConstants.TEAM_PERMISSION);

			getCurrentSession().save(teamCodeHib);
		}
		// if fcrl is entering the information add one more permission row in
		// INFORMATION_PERMISSION_TBL
		if (EcmsUtils.isUserFCRL(info.getCreatedStaffId())) {
			InformationPermission fcrlHib = createInformationPermission(info,
					createdDate, ECMSConstants.FCRL_PERMISSION);
			getCurrentSession().save(fcrlHib);
		}

	}

	public void saveFcrolInformationPermission(List<InformationPermission> list) {
		for (InformationPermission perm : list) {
			getCurrentSession().merge(perm);
		}
	}

	public void saveFcrolInformationDiscard(final Long infoId,
			final String discard, final String staffId,
			final String rejectReason, final String regOverride) {

		final StringBuffer hql = new StringBuffer(
				"update FcrolInformation set dataCleansedFlag =?, reviewedStaffId =? ,reviewedDate=? ,rejectReason=?, regionOverride=? where informationId=?");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setString(0, discard);
		query.setString(1, staffId);
		query.setTimestamp(2, new Date());
		query.setLong(5, infoId);
		query.setString(4, regOverride);
		if (discard.equalsIgnoreCase("R"))
			query.setString(3, rejectReason);
		else
			query.setString(3, "");

		query.executeUpdate();

	}

	private InformationPermission createInformationPermission(Information info,
			Date created, String permType) {

		InformationPermission perm = InformationUtil
				.createInfoPermission(info.getInformationId(), permType, "",
						info.getCreatedStaffId());

		setPermissionType(permType, perm, info);

		return perm;
	}

	private void setPermissionType(String permType,
			InformationPermission permission, Information info) {

		String finalTeamCode = null;
		Organisation org = info.getOrganisation();
		// TODO: Still not clear on whom to assign the permission to, the
		// creator or session user.
		if (permType.equals(ECMSConstants.INFO_ASSIGNEE_PERMISSION)
				&& StringUtils.isEmpty(permission.getPermissionValue())) {

			permission.setPermissionValue(info.getCreatedStaffId());
		}
		if (permType.equals(ECMSConstants.ORGANISATIONAL_PERMISSION)) {

			permission.setPermissionValue(org.getOrgCode());
		}
		if (permType.equals(ECMSConstants.TEAM_PERMISSION)) {
			// if region override is 'YES' .get region code mapped to org_code
			// from team_orgs_tbl
			if (info.hasRegionOverride()) {
				finalTeamCode = info.getTeamCode();
			} else {
				finalTeamCode = getTeamCode(org.getOrgCode());
			}
			permission.setPermissionValue(finalTeamCode);
			if (log.isDebugEnabled()) {
				log.debug("PermissionType TEAM CODE=" + finalTeamCode);
			}
		}
		if (permType.equals(ECMSConstants.FCRL_PERMISSION)) {
			permission.setPermissionValue(ECMSConstants.FCRL_PERMISSION_VALUE);
		}

	}

	public void updatePermission(Information info, SessionUser user) {

		if (info.getCaseId() == null) {
			DetachedCriteria criteria = DetachedCriteria.forClass(
					InformationPermission.class).add(
					Restrictions.eq("informationId", info.getInformationId()));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

			List list = criteria.getExecutableCriteria(getCurrentSession())
					.list();

			if (log.isDebugEnabled()) {
				log.debug("update permissions list size="
						+ (list != null ? list.size() : 0));
			}

			if (null != info.getOrganisation()) {

			}

			if (list != null && !list.isEmpty()) {

				boolean hasOrgCodePerm = false;

				for (int i = 0; i < list.size(); i++) {

					InformationPermission perm = (InformationPermission) list
							.get(i);

					if (perm.getPermissionType().equals(
							ECMSConstants.ORGANISATIONAL_PERMISSION)) {

						hasOrgCodePerm = true;
					}
					// Get the National level TeamCode in to picture - Venkat.
					// if (user.isUserNationalLevel()) {
					// System.out.println("\n\n Nation level user");
					// check Info has a National level TEAM value.
					// String permVal = perm.getPermissionValue();
					// List<String> teamCodes = user
					// .getOrgOrTeamResponsibilityList();
					// if (teamCodes != null && teamCodes.contains(permVal)) {
					// System.out.println("\n\n Nation level user 1");
					// perm.setPermissionValue(permVal);
					// } else if (teamCodes != null && !teamCodes.isEmpty()) {
					// System.out.println("\n\n Nation level user 2");
					// perm.setPermissionValue(teamCodes.get(0));
					// } else {
					// System.out.println("\n\n Nation level user 3");
					// setPermissionType(perm.getPermissionType(), perm,
					// information);
					// }
					// } else {
					// System.out.println("\n\n NON-Nation level ");
					// setPermissionType(perm.getPermissionType(), perm,
					// information);
					// }
					setPermissionType(perm.getPermissionType(), perm, info);

					getCurrentSession().update(perm);
				}
				// missing in action.
				if (!hasOrgCodePerm
						&& !user.isUserNationalLevel()
						&& (user.isUserLCFS() || user.isUserFCRL() || user
								.isUserRegional())) {

					InformationPermission orgCodeHib = createInformationPermission(
							info, new Date(),
							ECMSConstants.ORGANISATIONAL_PERMISSION);

					logger.warn("\n Creating Missing ORG_CODE PERMISSION 4 InfoId ="
							+ info.getInformationId());
					getCurrentSession().save(orgCodeHib);
				}

			} else {
				// Save the existing information with no permissions.
				savePermission(info, user);
			}
		}
	}

	/**
	 * Information Permission using the informationId.
	 * 
	 */
	public List<InformationPermission> getInformationPersmissions(
			Long informationId) {

		String hsql = "from InformationPermission ip where ip.informationId=?";
		Query query = getCurrentSession().createQuery(hsql.toString());
		return query.setLong(0, informationId).list();
		// return getHibernateTemplate().find(hsql, informationId);
	}

	/**
	 * Get Team Code by OrgCode and RegionCode
	 * 
	 * @param orgCode
	 * @param regionCode
	 * @return teamCode
	 */
	public String getTeamCode(String orgCode) {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				OrganisationTeamCode.class).add(
				Restrictions.eq("orgCode", orgCode));

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (list != null && !list.isEmpty()) {
			OrganisationTeamCode team = (OrganisationTeamCode) list.get(0);
			return team.getTeamCode();
		}
		return null;
	}

	public Information loadInformationByIdData(Long informationId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(Information.class).add(
						Restrictions.idEq(informationId));
		// TODO: order by criteria at some point...
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (list != null && !list.isEmpty()) {

			Information info = (Information) list.get(0);

			return info;

		}
		return null;
	}

	public void updateInformationData(Information doObj) {
		doObj.setUpdatedFlag("Y");
		getCurrentSession().merge(doObj);
	}

	/**
	 * Can use "SELECT distinct iv.informationId, iv FROM ");
	 */
	public List<InformationView> loadAllInformationView(SessionUser user,
			boolean mineOnly) {

		return this.loadTopInformationView(user, 0, mineOnly);
	}

	public InformationPermission loadPermissionByInfoIdAndPermType(Long infoId,
			String permType) {

		List<InformationPermission> list = loadPermissionsByInfoIdAndPermType(
				infoId, permType);

		if (null != list && list.size() == 1) {
			InformationPermission permission = list.get(0);
			return permission;
		}
		return null;
	}

	public List<InformationPermission> loadPermissionsByInfoIdAndPermType(
			Long infoId, String permType) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(InformationPermission.class)
				.add(Restrictions.eq("informationId", infoId))
				.add(Restrictions.eq("permissionType", permType));

		List<InformationPermission> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		return list;
	}

	public InformationPermission updatePermission(
			InformationPermission infoPermission) {
		return (InformationPermission) getCurrentSession()
				.merge(infoPermission);
	}

	public InformationPermission saveInformationPermission(
			InformationPermission permission) {
		return (InformationPermission) getCurrentSession().merge(permission);
	}

	public Information loadInformationByCaseId(Long caseId) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(Information.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (Information) list.get(0);
		}
		return null;
	}

	public Person loadInformationByCaseIdForCps(Long caseId) {
		Person person = null;

		final String sql = "select p.FIRST_NAME, p.LAST_NAME from information_tbl i "
				+ "inner join information_subject_tbl s on i.INFORMATION_ID=s.Information_id "
				+ "inner join Person_tbl p on p.PERSON_ID = s.SUBJECT_PERSON_ID "
				+ "where i.CASE_ID=:caseID";
		final SQLQuery query = getCurrentSession().createSQLQuery(sql);

		query.setParameter("caseID", caseId);
		final List<?> result = query.list();

		if (!result.isEmpty()) {
			final Object[] objects = (Object[]) result.get(0);
			person = new Person();
			final String firstName = objects[0] != null ? objects[0].toString()
					: "";
			final String lastName = objects[1] != null ? objects[1].toString()
					: "";
			person.setFirstName(firstName);
			person.setLastName(lastName);
		}
		return person;
	}

	public InformationView loadInformationViewByCaseId(Long caseId) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(InformationView.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (InformationView) list.get(0);
		}
		return null;
	}

	public Information loadInformationByCaseId(Long caseId,
			boolean isCasePersonsOnly) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(Information.class);
		criteria.add(Restrictions.eq("caseId", caseId));

		/**
		 * TODO: Comments recreated as side effects include creating an inner
		 * join rather than an outer join..
		 *
		 * if (isCasePersonsOnly) { criteria.createAlias("subjectInformation",
		 * "subj").add( Restrictions.or(Restrictions.isNull("subj.isWitness"),
		 * Restrictions.ne("subj.isWitness", "Y"))); }
		 */

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			Information info = (Information) list.get(0);
			if (isCasePersonsOnly) {
				Set<CaseContact> csAssociates = new HashSet<CaseContact>();
				for (CaseContact c : info.getCaseAssociates()) {
					if ("ASSOCIATE".equalsIgnoreCase(c.getContactType())) {
						csAssociates.add(c);
					}
				}
				info.setCaseAssociates(csAssociates);
			}
			return info;
		}
		return null;
	}

	public InformationView loadInformationViewById(Long informationId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(InformationView.class);
		criteria.add(Restrictions.eq("informationId", informationId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (InformationView) list.get(0);
		}
		return null;
	}

	public List<FcrolInformationView> loadFcrolInformationView() {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(FcrolInformationView.class);
		criteria.add(Restrictions.eq("dataCleansedFlag", "N"));
		List<FcrolInformationView> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		return list;
	}

	public List<InformationView> loadTopInformationView(final SessionUser user,
			Integer rowCount, boolean mineOnly) {

		final String resp[] = user.getOrgOrTeamResponsibilities();
		String[] lcfsResp = new String[resp.length + 1];

		// DEBUG, INFO
		if (log.isInfoEnabled()) {

			if (resp != null) {
				for (String resps : resp)
					log.info("\n RESP @ Value :" + resps);
			}
		}

		final StringBuffer hSql = new StringBuffer("SELECT distinct iv FROM ");
		hSql.append(" InformationView iv ");

		// removed -- user.isUserDirectorate()
		if (user.isUserAdmin() || user.isUserDirector()) {

			hSql.append(" WHERE iv.caseId is null");
			if (rowCount > 0) {
				hSql.append(" AND ROWNUM <= " + rowCount);
			}
			hSql.append(" ORDER BY iv.createdDate DESC");

			return getCurrentSession().createQuery(hSql.toString()).list();
			// return getHibernateTemplate().find(hSql.toString());
		}

		hSql.append(", InformationPermission ip");
		hSql.append(" WHERE iv.informationId = ip.informationId");

		if (!user.isUserFCRL()) {
			hSql.append(" AND iv.caseId is null");
		}

		if (user.isUserFCRL()) {
			hSql.append(" AND (ip.permissionType = :fcrlPermission");
			hSql.append("' AND ip.permissionValue = :fcrlPermissionValue");

			if (mineOnly) {
				hSql.append(" AND (ip.createdStaffId = '");
				hSql.append(user.getStaffId());
				hSql.append("')");
			}
		}

		if (user.isUserLCFS()) {
			lcfsResp[0] = user.getStaffId();
			System.arraycopy(resp, 0, lcfsResp, 1, resp.length);
			hSql.append(" AND ip.permissionType = :lcfsInfoAssigneePermission");
			hSql.append(" AND ip.permissionValue in (:allResps)");
		}

		if (user.isUserOFM() || user.isUserAntiFraudSpecialistSupport()
				|| user.isUserAntiFraudSpecialist()) {
			hSql.append(" AND ( ((ip.permissionType = '");
			hSql.append(ECMSConstants.INFO_ASSIGNEE_PERMISSION);
			hSql.append("' AND ip.permissionValue = '");
			hSql.append(user.getStaffId()).append("') )");
			if (resp.length > 0) {
				hSql.append(" OR ((ip.permissionType = '");
				hSql.append(ECMSConstants.TEAM_PERMISSION);
				hSql.append("' AND ip.permissionValue in (:allResps) ))");

				hSql.append(" OR ((ip.permissionType = '");
				hSql.append(ECMSConstants.INFO_PERMISSION_READ_ONLY);
				hSql.append("' AND ip.permissionValue ='");
				hSql.append(user.getStaffId()).append("'))");
			}
			hSql.append(")");
		}

		if (user.isUserCFS() || user.isNITAFL()) {
			hSql.append(" AND (( (ip.permissionType = '");
			hSql.append(ECMSConstants.INFO_ASSIGNEE_PERMISSION);
			hSql.append("' AND ip.permissionValue = '");
			hSql.append(user.getStaffId()).append("') )");
			hSql.append(" OR ((ip.permissionType = '");
			hSql.append(ECMSConstants.TEAM_PERMISSION);
			hSql.append("' AND ip.permissionValue in (:allResps) ))");

			hSql.append(" OR ((ip.permissionType = '");
			hSql.append(ECMSConstants.INFO_PERMISSION_READ_ONLY);
			hSql.append("' AND ip.permissionValue ='");
			hSql.append(user.getStaffId()).append("'))");
			hSql.append(")");

		}

		if (rowCount > 0) {
			hSql.append(" AND ROWNUM <= " + rowCount);
		}
		hSql.append(" ORDER BY iv.createdDate DESC");

		if (log.isDebugEnabled()) {
			log.debug("\n HQL Query=" + hSql.toString());
		}

		Query query = getCurrentSession().createQuery(hSql.toString());
		if (resp.length > 0) {
			if (user.isUserLCFS()) {
				query.setParameter("lcfsInfoAssigneePermission",
						ECMSConstants.INFO_ASSIGNEE_PERMISSION);
				query.setParameterList("allResps", lcfsResp);
			} else if (user.isUserOFM()
					|| user.isUserAntiFraudSpecialistSupport()
					|| user.isUserAntiFraudSpecialist()) {
				query.setParameterList("allResps", resp);
			} else if (user.isUserCFS() || user.isNITAFL()) {
				// query.setParameterList("allResps", getNITAFLResp(user));
				query.setParameterList("allResps",
						EcmsUtils.nationalTeamsToStringArray());
			}
		}
		if (user.isUserFCRL()) {
			query.setParameter("fcrlPermission", ECMSConstants.FCRL_PERMISSION);
			query.setParameter("fcrlPermissionValue",
					ECMSConstants.FCRL_PERMISSION_VALUE);
		}
		List list = query.list();
		/*
		 * List list = getHibernateTemplate().executeFind(new
		 * HibernateCallback() {
		 * 
		 * public Object doInHibernate(Session session) throws
		 * HibernateException, SQLException {
		 * 
		 * Query query = session.createQuery(hSql.toString());
		 * 
		 * if (resp.length > 0 ) { if (user.isUserLCFS() || user.isUserOFM() ||
		 * user.isUserAntiFraudSpecialistSupport() ||
		 * user.isUserAntiFraudSpecialist()) {
		 * query.setParameterList("allResps", resp); } else if (user.isUserCFS()
		 * || user.isNITAFL()){ //query.setParameterList("allResps",
		 * getNITAFLResp(user)); query.setParameterList("allResps",
		 * ECMSConstants.NAT_TEAMS); } } return query.list(); } });
		 */

		return list;
	}

	public List<InformationView> loadLCFS_Other_InformationView(
			final SessionUser user) {

		final String resp[] = user.getOrgOrTeamResponsibilities();

		if (log.isInfoEnabled()) {

			if (resp != null) {
				for (String resps : resp)
					log.info("\n RESP @ Value :" + resps);
			}
		}

		final StringBuffer hSql = new StringBuffer("SELECT distinct iv FROM ");
		hSql.append(" InformationView iv, ");
		hSql.append(" InformationPermission ip");
		hSql.append(" WHERE iv.informationId = ip.informationId");
		hSql.append(" AND iv.caseId is null");
		hSql.append(" AND ip.permissionType =:lcfsInfoAssigneePermission");
		hSql.append(" AND ip.permissionValue in (:allResps)");
		hSql.append(" ORDER BY iv.createdDate DESC");

		if (log.isDebugEnabled()) {
			log.debug("\n HQL Query=" + hSql.toString());
		}
		//
		Query query = getCurrentSession().createQuery(hSql.toString());
		query.setParameter("lcfsInfoAssigneePermission",
				ECMSConstants.ORGANISATIONAL_PERMISSION);
		if (resp.length > 0) {
			query.setParameterList("allResps", resp);
		}
		List list = query.list();

		return list;
	}

	public InfoTransferHistory saveInfoTransferHistory(
			InfoTransferHistory history) {

		// this.getHibernateTemplate().save(history);
		return (InfoTransferHistory) getCurrentSession().merge(history);
	}

	public InfoTransferHistory updateInfoTransferHistory(
			InfoTransferHistory history) {
		// this.getHibernateTemplate().update(history);
		return (InfoTransferHistory) getCurrentSession().merge(history);

	}

	public InfoTransferHistory loadInfoTransferHistoryById(Long transId) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(InfoTransferHistory.class);
		criteria.add(Restrictions.idEq(transId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (InfoTransferHistory) list.get(0);
		}
		return null;

	}

	public List<InfoTransferHistory> loadInfoTransferHistoryByInfoId(Long infoId) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(InfoTransferHistory.class);
		criteria.add(Restrictions.eq("infoId", infoId));
		List<InfoTransferHistory> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		return list;
	}

	/**
	 * 
	 * This DAO method is responsible for returning the current transfer request
	 * in the system Which is having state as "N" (New) Other possible options
	 * are as follows P-Processed - if the request have been processed by lead
	 * used state will set as Processed N-New This will be initial state of any
	 * newly introduced transfer. This will also set the other request state N
	 * as D, representing as discarded system will have only one transfer
	 * request for each information ID in N state D-Discarded System receives a
	 * new transfer request before an existing one is turned to processed.
	 * 
	 * @param infoId
	 * @return List
	 * 
	 * */
	public InfoTransferHistory loadCurrentInfoTransferHistoryByInfoId(
			Long infoId) {

		return this.loadInfoTransferHistoryByInfoIdState(infoId, "N");
	}

	public InfoTransferHistory loadCurrentInfoTransferHistoryByTransferId(
			Long caseTransferID) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(InfoTransferHistory.class);
		criteria.add(Restrictions.eq("transId", caseTransferID));
		List<InfoTransferHistory> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		/*
		 * List<InfoTransferHistory> list =
		 * getHibernateTemplate().findByCriteria( criteria);
		 */
		if (null != list && list.size() > 0)
			return list.get(0);
		else
			return null;
	}

	public List<InfoTransferHistory> loadInfoTransferHistoryByInfoIdAndTeam(
			Long transId, String teamCode) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(InfoTransferHistory.class);
		criteria.add(Restrictions.eq("transId", transId));
		criteria.add(Restrictions.eq("teamCode", transId));
		List<InfoTransferHistory> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		/*
		 * List<InfoTransferHistory> list =
		 * getHibernateTemplate().findByCriteria( criteria);
		 */
		return list;

	}

	public InfoTransferHistory loadInfoTransferHistoryByInfoIdState(
			Long infoId, String state) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(InfoTransferHistory.class);
		criteria.add(Restrictions.eq("infoId", infoId));
		criteria.add(Restrictions.eq("state", state));
		List<InfoTransferHistory> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		if (null != list && !list.isEmpty()) {
			return (InfoTransferHistory) list.get(0);
		}
		return null;

	}

	public void saveInfoTransHistory(Information info) {

		String finalTeamCode = null;
		InfoTransferHistory history = new InfoTransferHistory();
		history.setInfoId(info.getInformationId());
		history.setCreatedStaffId(info.getCreatedStaffId());
		history.setCreatedTime(new Date());
		history.setState(ECMSConstants.INFO_TEAM_STATE_CREATED);

		if (info.hasRegionOverride()) {

			finalTeamCode = info.getTeamCode();
		} else {

			finalTeamCode = getTeamCode(info.getOrganisation().getOrgCode());
		}
		history.setTeamCode(finalTeamCode);
		getCurrentSession().merge(history);

		// getHibernateTemplate().save(history);
	}

	public InfoTransferHistory updateInfoTransHistory(Long infoId,
			String teamCode) {

		InfoTransferHistory history = this
				.loadInfoTransferHistoryByInfoIdState(infoId,
						ECMSConstants.INFO_TEAM_STATE_NEW);

		if (history == null
				|| (history != null && history.getTeamCode() == null)
				|| (teamCode != null && teamCode.equalsIgnoreCase(history
						.getTeamCode()))) {

			return null;
		}

		history.setTeamCode(teamCode);
		getCurrentSession().update(history);
		return history;
	}

	/**
	 * Create Information Transfer History.
	 * 
	 * @param staffId
	 * @param infoId
	 * @param teamCode
	 * 
	 * @return infoTransferHistory.
	 */
	private InfoTransferHistory createTransferHistory(String staffId,
			Long infoId, String teamCode, String newTeamCode, String toStaffId,
			String comments) {

		InfoTransferHistory history = new InfoTransferHistory();
		history.setCreatedStaffId(staffId);
		history.setCreatedTime(new Date());
		history.setInfoId(infoId);
		history.setTeamCode(teamCode);
		history.setState(ECMSConstants.INFO_TEAM_STATE_NEW);
		history.setTransferTeamCode(newTeamCode);
		// history.setTransferStaffId(transferStaffId);
		// TODO: TransferStaffID >>
		if (null == toStaffId) {

			logger.info("toStaffId is NULL, trying OFM details using Team:"
					+ newTeamCode);

			UserObject userObj = this.getOFMByTeamCode(newTeamCode);

			if (null != userObj && null != userObj.getStaffId()) {

				history.setTransferStaffId(userObj.getStaffId());
				history.setApproverStaffID(userObj.getStaffId());
			}
		} else {
			history.setTransferStaffId(toStaffId);
			history.setApproverStaffID(toStaffId);
		}
		history.setTransferComments(comments);
		return history;
	}

	/**
	 * This DAO method is responsible for updating the transfer table
	 * */
	public InfoTransferHistory updateInfoTransferHistory(Long infoId,
			String oldTeamCode, String newTeamCode, String staffId,
			MessageTO messageTO) {

		InfoTransferHistory oldhistory = this
				.loadInfoTransferHistoryByInfoIdState(infoId,
						ECMSConstants.INFO_TEAM_STATE_NEW);

		if (oldhistory != null) {
			oldhistory.setState(ECMSConstants.INFO_TEAM_STATE_DISCARDED);
			getCurrentSession().update(oldhistory);

		}

		InfoTransferHistory newHistory = this.createTransferHistory(staffId,
				infoId, oldTeamCode, newTeamCode, messageTO.getToStaffId(),
				messageTO.getMessage());

		getCurrentSession().save(newHistory);

		return newHistory;

	}

	/**
	 * Check user is authorised to access Information by informationId.
	 * 
	 * @param informationId
	 * @param user
	 * @return boolean.
	 */
	public boolean isUserAuthorizedToAccessInformation(Long informationId,
			final SessionUser user, boolean open) {

		final String resp[] = user.getOrgOrTeamResponsibilities();
		String imoResp[] = new String[resp.length + 1];

		if (user.isUserIMO()) {
			final Information information = loadInformationByIdData(informationId);
			final String state = information.getState();
			final boolean isClosedIR = state != null ? state.equalsIgnoreCase(
					ECMSConstants.CLOSED):false;
			if (isClosedIR) {
				final String teamCode = information.getTeamCode();

				if (resp.length > 0) {
					imoResp[0] = teamCode;
					System.arraycopy(resp, 0, imoResp, 1, resp.length);
				}
			}else{
				System.arraycopy(resp, 0, imoResp, 0, resp.length);
			}

		}

		final StringBuffer hSql = new StringBuffer("");

		hSql.append("SELECT count(*) as count FROM ");

		hSql.append(" Information iv ");

		// if (open) {
		// hSql.append(" InformationView iv ");
		// } else {
		// hSql.append(" ClosedInformationView iv ");
		// }
		if (user.isUserAdmin() || user.isUserDirector()) {

			// hSql.append(" WHERE iv.caseId is null").append(" AND ");
			hSql.append(" WHERE ");
			hSql.append(" iv.informationId=").append(informationId);

			List list = getCurrentSession().createQuery(hSql.toString()).list();
			// List list = getHibernateTemplate().find(hSql.toString());

			if (null != list && !list.isEmpty()) {

				return true;
			}
		}

		hSql.append(", InformationPermission ip");
		hSql.append(" WHERE iv.informationId = ip.informationId");
		// -- hSql.append(" AND iv.caseId is null");
		hSql.append(" AND iv.informationId=").append(informationId);

		if (user.isUserFCRL()) {

			hSql.append(" AND (ip.permissionType = '");
			hSql.append(ECMSConstants.FCRL_PERMISSION);
			hSql.append("' AND ip.permissionValue = '");
			hSql.append(ECMSConstants.FCRL_PERMISSION_VALUE);
			hSql.append("')");
		}

		if (user.isUserLCFS()) {

			hSql.append(" AND ( (ip.permissionType = '");
			hSql.append(ECMSConstants.INFO_ASSIGNEE_PERMISSION);
			hSql.append("' AND ip.permissionValue = '");
			hSql.append(user.getStaffId()).append("')");
			hSql.append(" OR (ip.permissionType = '");
			hSql.append(ECMSConstants.ORGANISATIONAL_PERMISSION);
			hSql.append("' AND ip.permissionValue in (:allResps) )");
			hSql.append(")");
		}

		/** Restructure from April 2011 **/
		if (user.isUserCFS() || user.isUserOFM()
				|| user.isUserAntiFraudSpecialistSupport()
				|| user.isUserAntiFraudSpecialist()
				|| user.isUserAntiFraudLead()) {

			hSql.append(" AND ( (ip.permissionType = '");
			hSql.append(ECMSConstants.INFO_ASSIGNEE_PERMISSION);
			hSql.append("' AND ip.permissionValue = '");
			hSql.append(user.getStaffId()).append("')");

			if (resp.length > 0
					|| (user.isUserAntiFraudLead() || user.isUserCFS())) {
				hSql.append(" OR (ip.permissionType = '");
				hSql.append(ECMSConstants.TEAM_PERMISSION);
				hSql.append("' AND ip.permissionValue in (:allResps) )");
			}

			if (resp.length > 0
					|| (user.isUserAntiFraudLead() || user.isUserCFS())) {
				hSql.append(" OR (ip.permissionType = '");
				hSql.append(ECMSConstants.INFO_PERMISSION_READ_ONLY);
				hSql.append("' AND ip.permissionValue ='");
				hSql.append(user.getStaffId()).append("'))");
			}
			hSql.append(")");
		}

		Query query = getCurrentSession().createQuery(hSql.toString());
		if (user.isUserAntiFraudLead() || user.isUserCFS()) {

			query.setParameterList("allResps",
					EcmsUtils.nationalTeamsToStringArray());
		} else if (resp.length > 0
				&& (user.isUserLCFS()
						|| user.isUserAntiFraudSpecialistSupport()
						|| user.isUserAntiFraudSpecialist() || user.isUserOFM())) {
			if (user.isUserIMO()) {
				query.setParameterList("allResps", imoResp);
			} else {
				query.setParameterList("allResps", resp);
			}
		}
		List list = query.list();

		if ((Long) list.get(0) > 0) {
			return true;
		}
		return false;
	}

	public UserObject getOFMDetailsByInfoId(Long infoId) {

		String teamCode = "T1350";
		DetachedCriteria criteria = DetachedCriteria
				.forClass(Information.class);
		criteria.add(Restrictions.idEq(infoId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			Information info = (Information) (list.get(0));
			if (info != null) {
				teamCode = info.getTeamCode();
			}
		}
		// If teamCode is null or unkown, OFM org is 'T1350'
		if (teamCode == null || EcmsUtils.isTeamCodeCFSMS(teamCode)) {

			teamCode = "T1350";
		}
		return getOFMByTeamCode(teamCode);
	}

	/**
	 * Get OFM staff details by their team code.
	 * 
	 * @param teamCode
	 * @return UserObject.
	 */
	public UserObject getOFMByTeamCode(final String teamCode) {

		final StringBuffer hql = new StringBuffer("SELECT user FROM");
		hql.append(" UserObject user, AllUserResponsibilities resp");
		hql.append(" WHERE user.staffId = resp.staffId AND");
		hql.append(" user.employerOrgCode= :teamCode AND");
		hql.append(" user.status = 'A' AND");
		hql.append(" resp.respCode = :teamCode AND");
		if (teamCode.equalsIgnoreCase("T1350")) {
			hql.append(" user.groupPermission in (4, 1)");
		} else if (EcmsUtils.isTeamCodeInOFMTeams(teamCode)) {
			hql.append(" user.groupPermission = 4");
		} else if (EcmsUtils.isNITTeamCode(teamCode)) {
			hql.append(" user.groupPermission = 9");
		} else {
			hql.append(" user.groupPermission = 8");
		}

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("teamCode", teamCode);

		List userList = query.list();
		if (null != userList && !userList.isEmpty() && userList.size() == 1) {
			return (UserObject) userList.get(0);
		}

		return null;
	}

	public InformationObject loadInfoObjectOnly(Long infoId) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(InformationObject.class);
		criteria.add(Restrictions.eq("informationId", infoId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (InformationObject) list.get(0);
		}
		return null;
	}

	public InformationPermission loadPermissionByInfoIdAndPermTypeAndValue(
			Long infoId, String permType, String perm) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(InformationPermission.class)
				.add(Restrictions.eq("informationId", infoId))
				.add(Restrictions.eq("permissionType", permType))
				.add(Restrictions.eq("permissionValue", perm));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (list != null && !list.isEmpty()) {
			InformationPermission permission = (InformationPermission) list
					.get(0);
			return permission;
		}
		return null;
	}

	public void saveInfoOnly(InformationObject dto) {

		getCurrentSession().merge(dto);
	}

	public void updateSubjectToWitness(Witness witness) {
		witness.setCreatedTime(new Timestamp(System.currentTimeMillis()));
		getCurrentSession().merge(witness);
	}

	@Override
	public List<ClosedInformationView> loadClosedInformationView(
			SessionUser user, String createdByFilter) {

		final StringBuffer hSql = new StringBuffer("SELECT distinct iv FROM ");
		hSql.append(" ClosedInformationView iv ");
		// TODO: Verify the latest users in the ECMS Constants.
		if (user.isUserCIU() || user.isUserManager()
				|| user.isUserHeadOperations() || user.isUserDeputyOperations()) {

			hSql.append(" WHERE iv.caseId is null ");
			hSql.append(" AND (iv.state='CLOSED' OR iv.informationDiscarded='R')");

			if (createdByFilter
					.equals(InformationUtil.INFO_CREATED_BY_FILTER.CFS
							.toString())) {
				hSql.append(" AND (iv.createdStaffId not like 'lcfs%')");
			} else if (createdByFilter
					.equals(InformationUtil.INFO_CREATED_BY_FILTER.LCFS
							.toString())) {
				hSql.append(" AND (iv.createdStaffId like 'lcfs%')");
			}

			hSql.append(" ORDER BY iv.createdDate DESC");
			return getCurrentSession().createQuery(hSql.toString()).list();

		}
		return null;
	}

	@Override
	public List<InformationView> loadMyTeamsInformation(SessionUser user) {

		if (log.isDebugEnabled()) {
			log.debug("ListFCRLInformation, User=" + user.getStaffId()
					+ ",Name=" + user.getFullName());
		}

		final StringBuffer hSql = new StringBuffer("SELECT distinct iv FROM ");
		hSql.append(" InformationView iv ");
		hSql.append(" WHERE iv.createdStaffId in ");
		// hSql.append("'").append(user.getStaffId()).append("')");
		// -- Pat changed the my to group (team's)
		hSql.append(" (select usr.staffId from UserObject usr where usr.directorate ='");
		hSql.append(user.getDirectorate()).append("'");
		hSql.append(" and usr.groupPermission=")
				.append(user.getGroupPermission()).append(") ");
		// --
		hSql.append(" ORDER BY iv.createdDate DESC");

		return getCurrentSession().createQuery(hSql.toString()).list();
	}

	/**
	 * This method is responsible for loading the information transfer history
	 * pending for approval for the given user ID.
	 * 
	 * */
	public List<InfoTransferHistory> loadPendingInformationTransfersForUser(
			String staffID) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(InfoTransferHistory.class);
		criteria.add(Restrictions.eq("approverStaffID", staffID));
		criteria.add(Restrictions.eq("state", "N"));
		criteria.addOrder(Order.desc("createdTime"));

		List<InfoTransferHistory> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		if (null != list && list.size() > 0)
			return list;
		else
			return null;
	}

	public InfoTransferHistory loadNewInfoTransferHistoryByApprover(
			Long infoId, String approver) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(InfoTransferHistory.class);
		criteria.add(Restrictions.eq("infoId", infoId));
		criteria.add(Restrictions.eq("approverStaffID", approver));
		criteria.add(Restrictions.eq("state", "N"));
		List<InfoTransferHistory> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (InfoTransferHistory) list.get(0);
		}

		return null;
	}

	/**
	 * Lead or AAFS or OFM users only.
	 * 
	 */
	public InfoTransferHistory updateOldAndAddNewInfoTransferHistory(
			Long infoId, String newTeamCode, SessionUser user) {

		InfoTransferHistory oldhistory = this
				.loadInfoTransferHistoryByInfoIdState(infoId,
						ECMSConstants.INFO_TEAM_STATE_NEW);

		String currentTeam = user.getEmployerOrgCode();
		String currentStaffId = user.getStaffId();

		if (null != oldhistory) {

			oldhistory.setTeamCode(user.getEmployerOrgCode());
			oldhistory.setTransferDate(new Date());
			oldhistory.setTransferTeamCode(newTeamCode);
			oldhistory.setTransferStaffId(user.getStaffId());
			oldhistory.setState(ECMSConstants.INFO_TEAM_STATE_OLD);
			// update old Information Transfer History.
			this.saveObject(oldhistory);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("InfoId=" + infoId + ", CurrentTeam=" + currentTeam
					+ ", NewTeamCode= " + newTeamCode);
		}
		InfoTransferHistory newHistory = this.createTransferHistory(
				currentStaffId, infoId, currentTeam, newTeamCode, null, null);
		newHistory = (InfoTransferHistory) getCurrentSession()
				.merge(newHistory);

		return newHistory;
	}

	@Override
	public List<ClosedInformationView> loadClosedInformationReportsForIMO(SessionUser user) {
		final String resp[] = user.getIMOTeamResponsibilities();
		final StringBuffer hSql = new StringBuffer("SELECT distinct iv FROM ");
		hSql.append(" ClosedInformationView iv ");
		hSql.append(", InformationPermission ip");
		hSql.append(" WHERE iv.informationId = ip.informationId AND iv.state !=null");		
		if (resp.length > 0) {
			hSql.append(" AND ip.permissionType = '");
			hSql.append(ECMSConstants.TEAM_PERMISSION);
			hSql.append("' AND ip.permissionValue in (:allResps)");			
		}
		hSql.append(" AND iv.caseId is null ");		
		hSql.append(" AND iv.state='CLOSED'");		
		hSql.append(" ORDER BY iv.createdDate DESC");

		if (log.isDebugEnabled()) {
			log.debug("\n HQL Query=" + hSql.toString());
		}

		Query query = getCurrentSession().createQuery(hSql.toString());
		query.setParameterList("allResps", resp);
		List list = query.list();
		
		return list;
	}

	/*public void deleteThreeYearsOldClosedInformation() {
		final StringBuffer sql = new StringBuffer(
				"DELETE FROM INFORMATION_TBL WHERE CASE_ID IS NULL AND STATE = 'CLOSED' AND CLOSED_TIME < ADD_MONTHS(sysdate, -36)");
		Query query = getCurrentSession().createSQLQuery(sql.toString());
		query.executeUpdate();
	}*/
}