package uk.nhs.cfsms.ecms.dao;

import uk.nhs.cfsms.ecms.data.infoGath.Person;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonTO;

public interface PersonDao {

	public PersonTO insertPerson(PersonTO person);

	public PersonTO LoadPersonById(Person person);
	
}
