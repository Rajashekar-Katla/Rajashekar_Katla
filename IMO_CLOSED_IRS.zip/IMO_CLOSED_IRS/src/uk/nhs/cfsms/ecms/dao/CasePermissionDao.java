package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CasePermission;

public interface CasePermissionDao {
	
	public List loadCasePermissionsByCaseId(Long caseId);
	
	public List saveCasePermissions(List<CasePermission> casePermissions);
	
	public void deleteCasePermissionsByCaseId(Long caseId);
	
	public void deleteCasePermissionsByPermissionId(Long permissionId);
	
	public void deleteAllExcptTeamCasePermissionsByCaseId(Long caseId);
	
	public List<CasePermission> loadAllCaseAssigneesByCaseId(Long caseId);
	
	public void deletePermissionByPermTypeAndCaseId(Long caseId,String[] permTypes);
	
	public CasePermission saveCasePermission(CasePermission casePermission);
	
	public CasePermission loadCasePermissionByPermissionId(Long permissionId);
	
	public CasePermission updateCasePermission(CasePermission permission);
	
}
