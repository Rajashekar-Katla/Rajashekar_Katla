package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.Summons;

public interface SummonsDao extends BaseDao {
	
	List<Summons> getSummons(Long criminalSanctionId);
}
