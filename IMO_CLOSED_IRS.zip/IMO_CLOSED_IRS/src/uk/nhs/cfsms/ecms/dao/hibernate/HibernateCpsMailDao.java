package uk.nhs.cfsms.ecms.dao.hibernate;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.CpsMailDao;
import uk.nhs.cfsms.ecms.data.cps.CpsMail;

@Repository
public class HibernateCpsMailDao extends HibernateBaseDao implements CpsMailDao {

	@Override
	public List<CpsMail> getCpsMailDetails(final long caseID) {
		@SuppressWarnings("unchecked")
		List<CpsMail> list = getCurrentSession().createCriteria(CpsMail.class)
				.add(Restrictions.eq("caseID", caseID)).list();
		return list;
	}

	@Override
	public CpsMail getCpsMailDetailsByDate(Date fromDate, Date toDate) {
		return null;
	}

	@Override
	public Long save(final CpsMail mail) {
		return (Long) getCurrentSession().save(mail);
	}

	@Override
	public void delete(final Long cpsMailID) {
		final Serializable id = new Long(cpsMailID);
		final Object persistentInstance = getCurrentSession().load(
				CpsMail.class, id);
		if (persistentInstance != null) {
			getCurrentSession().delete(persistentInstance);
		}
	}

	public Timestamp isDocumentSent(final String docGrpID) {
		final Criteria criteria = getCurrentSession().createCriteria(
				CpsMail.class);
		criteria.add(Restrictions.like("attachedDocs", "%" + docGrpID + "%"));
		criteria.setProjection(Projections.max("emailDate"));
		final Timestamp emailedDate = (Timestamp) criteria.uniqueResult();
		return emailedDate;
	}

}
