package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.SubjectSearchDao;
import uk.nhs.cfsms.ecms.data.cim.SubjectNhsSearchResults;
import uk.nhs.cfsms.ecms.data.cim.SubjectNonNhsSearchResults;
import uk.nhs.cfsms.ecms.data.cim.SubjectSearchResults;
import uk.nhs.cfsms.ecms.data.cim.VehicleSearchResults;

@Repository
public class HibernateSubjectSearchDao extends HibernateBaseDao implements SubjectSearchDao {
	
	
	public List<SubjectSearchResults> searchPersonSubjects(String firstName,String lastName)
	{
		 
		final String  param2="%"+lastName.toUpperCase()+"%";
		final String  param1="%"+firstName.toUpperCase()+"%";
				
		final StringBuffer hql = new StringBuffer();
		hql.append("SELECT sr FROM SubjectSearchResults sr ");
		hql.append("WHERE upper(sr.firstName) like ? and ");
		hql.append(" upper(sr.lastName) like ? ");
		List list= getCurrentSession().createQuery(hql.toString()).setString(0,param1).setString(1,param2).list();
        
/*		List list= (List)getHibernateTemplate().execute(new HibernateCallback() {
	            public Object doInHibernate(Session session) throws HibernateException, SQLException {
	           	 Query query = session.createQuery(hql.toString());
	           	 query.setString(0,param1);
	            	query.setString(1,param2);
	           	 return query.list();
	            }
	        });*/

		return list;

		
		
		
		
		
	}
	
	public List<SubjectNhsSearchResults> searchNHSSubjects(String orgCode)
	{
		DetachedCriteria criteria = DetachedCriteria
		.forClass(SubjectNhsSearchResults.class);
		criteria.add(Restrictions.eq("orgCode", orgCode));
		
		
		List<SubjectNhsSearchResults> list=criteria.getExecutableCriteria(getCurrentSession()).list();
		return list;

		
		
		
		
		
	}
	
	public List<SubjectNonNhsSearchResults> searchNonNHSSubjects(final String name)
	{
		
		final String  param1="%"+name.toUpperCase()+"%";

		final StringBuffer hql = new StringBuffer();
		hql.append("SELECT sr FROM SubjectNonNhsSearchResults sr ");
		hql.append("WHERE upper(sr.orgName) like ? ");
		List list = getCurrentSession().createQuery(hql.toString()).setString(0,param1).list();		
		/*List list= (List)getHibernateTemplate().execute(new HibernateCallback() {
	            public Object doInHibernate(Session session) throws HibernateException, SQLException {
	           	 Query query = session.createQuery(hql.toString());
	           	 query.setString(0,param1);
	           	 return query.list();
	            }
	        });*/
		return list;
	}
	
	
	public List<VehicleSearchResults> searchVehicles(String licenseNumber)
	{
		
		final String  param1="%"+licenseNumber.toUpperCase()+"%";

		final StringBuffer hql = new StringBuffer();
		hql.append("SELECT sr FROM VehicleSearchResults sr ");
		hql.append("WHERE upper(sr.licenseNumber) like ? ");
		List list = getCurrentSession().createQuery(hql.toString()).setString(0,param1).list();
		/*List list= (List)getHibernateTemplate().execute(new HibernateCallback() {
	            public Object doInHibernate(Session session) throws HibernateException, SQLException {
	           	 Query query = session.createQuery(hql.toString());
	           	 query.setString(0,param1);
	           	 return query.list();
	            }
	        });*/
		return list;
		
		
	}



}
