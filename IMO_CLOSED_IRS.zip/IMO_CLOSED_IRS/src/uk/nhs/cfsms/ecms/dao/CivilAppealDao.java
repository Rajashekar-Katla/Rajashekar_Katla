package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppealOutcome;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppealView;

public interface CivilAppealDao {

	List<CivilAppealView> loadCivilAppealsByCaseId(Long caseId);
	
	List<CivilAppealOutcome> loadAppealOuctomesForCaseID(Long caseId);
	
	CivilAppealOutcome loadAppealOutcomeForAppealID(Long caseId);
	
	List<CivilAppealOutcome> loadAppealOutcomeForCivilSanctionId(Long SanctionId);
	
	List<CivilAppealView> loadAppealsByParentAppealId(Long appealId);
	
}
