package uk.nhs.cfsms.ecms.dao.hibernate;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import uk.nhs.cfsms.ecms.dao.LookupDao;
import uk.nhs.cfsms.ecms.data.common.Lookup;
import uk.nhs.cfsms.ecms.data.common.LookupView;

public class HibernateLookupDao extends HibernateBaseDao implements LookupDao {

	public LookupView getLookupView(long id) {
		
		return (LookupView) getCurrentSession().createQuery(
				"from LookupView where lookupId = " + id).list().get(0);
	}
	
	public void save(Lookup lookup) {
		getCurrentSession().merge(lookup);
	}

	public void delete(Lookup lookup) {
		getCurrentSession().delete(lookup);
	}

	
}
