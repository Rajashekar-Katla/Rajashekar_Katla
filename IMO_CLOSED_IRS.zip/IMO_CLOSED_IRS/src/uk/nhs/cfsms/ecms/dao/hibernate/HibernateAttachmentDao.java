package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.AttachmentDao;
import uk.nhs.cfsms.ecms.data.common.Attachment;

@Repository
public class HibernateAttachmentDao extends HibernateBaseDao implements
		AttachmentDao {

	public Attachment loadAttachment(Long AttachmentId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(Attachment.class)
				.add(Expression.idEq(AttachmentId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list(); //criteria.getExecutableCriteria(getCurrentSession()).list();

		if (list != null && !list.isEmpty()) {
			return (Attachment) list.get(0);
		}

		return null;
	}

	public List listAttachments(Long caseId) {

		List<Attachment> list = new ArrayList<Attachment>();

		DetachedCriteria criteria = DetachedCriteria.forClass(Attachment.class)
				.add(Expression.eq("caseId", caseId));
		criteria.addOrder(Order.asc("name"));
		list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}

	public List listInfoAttachments(Long infoId) {

		List<Attachment> list = new ArrayList<Attachment>();

		/*DetachedCriteria criteria = DetachedCriteria.forClass(Attachment.class)
		.add(Expression.eq("infoId", infoId));*/
		final Criteria criteria = getCurrentSession().createCriteria(
				Attachment.class);
		criteria.add(Restrictions.eq("infoId", infoId));
		criteria.add(Restrictions.isNotNull("attachment"));
		criteria.add(Restrictions.isNotNull("name"));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("id"), "id");
		projectionList.add(Projections.property("fileType"), "fileType");
		projectionList.add(Projections.property("createdTime"), "createdTime");
		projectionList.add(Projections.property("createdStaffId"),
				"createdStaffId");
		projectionList.add(Projections.property("description"), "description");
		projectionList.add(Projections.property("name"), "name");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers
				.aliasToBean(Attachment.class));

		//		list = criteria.getExecutableCriteria(getCurrentSession()).list();
		list = criteria.list();

		return list;
	}

	public void saveAttachment(Attachment attachment) {
		// TODO Auto-generated method stub

	}

	public void deleteAttachment(Attachment attachment) {
		getCurrentSession().delete(attachment);
	}

}
