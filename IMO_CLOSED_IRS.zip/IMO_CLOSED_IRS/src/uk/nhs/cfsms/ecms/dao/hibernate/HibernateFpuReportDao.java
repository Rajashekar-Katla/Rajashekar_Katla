package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.FpuReportDao;
import uk.nhs.cfsms.ecms.data.fpureport.FpuReport;
import uk.nhs.cfsms.ecms.data.fpureport.FpuReportSubType;

@Repository
public class HibernateFpuReportDao extends HibernateBaseDao implements  FpuReportDao{
	
	public FpuReport saveFpuReport(FpuReport report)
	{
		saveObject(report);
		return report;
		
	}
	
	public FpuReport loadFpuReportByCaseId(Long caseId)
	{
		DetachedCriteria criteria = DetachedCriteria
		.forClass(FpuReport.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		List<FpuReport> list=criteria.getExecutableCriteria(getCurrentSession()).list();
		
		if (null != list && !list.isEmpty()) {
			return (FpuReport)list.get(0);
		}
		return null;
		
	}
	public FpuReport loadFpuReportByInfoId(Long infoId)
	{
		DetachedCriteria criteria = DetachedCriteria
		.forClass(FpuReport.class);
		criteria.add(Restrictions.eq("informationId", infoId));
		List<FpuReport> list=criteria.getExecutableCriteria(getCurrentSession()).list();
		if (null != list && !list.isEmpty()) {
			return (FpuReport)list.get(0);
		}
		return null;
		
	}
	
	public FpuReport updateFpuReport(FpuReport report)
	{
		saveObject(report);
		return report;
		
	}
	
	
	public void deleteAllFpuSubTypes(Long reportId)
	{
		DetachedCriteria criteria = DetachedCriteria
		.forClass(FpuReportSubType.class);
		criteria.add(Restrictions.eq("fpuReportId", reportId));
		List<FpuReportSubType> list=criteria.getExecutableCriteria(getCurrentSession()).list();
		
		if (null != list && !list.isEmpty()) {
			deleteObjects(list);
		}	
		
	}
}
