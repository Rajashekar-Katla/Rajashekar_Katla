package uk.nhs.cfsms.ecms.dao;

import uk.nhs.cfsms.ecms.dto.infoGath.SourceInformationTO;

public interface SourceDao {

	public SourceInformationTO insertSource(SourceInformationTO dto);

	public SourceInformationTO LoadSourceById(SourceInformationTO subject);
	
}
