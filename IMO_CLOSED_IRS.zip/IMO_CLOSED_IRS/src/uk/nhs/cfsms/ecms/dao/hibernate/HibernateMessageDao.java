package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.MessageDao;
import uk.nhs.cfsms.ecms.data.cim.CPSDocumentsView;
import uk.nhs.cfsms.ecms.data.cim.Message;
import uk.nhs.cfsms.ecms.data.cim.MessageView;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;

@Repository
public class HibernateMessageDao extends HibernateBaseDao implements MessageDao {

	public Message saveMessage(Message message) {

		return (Message) mergeObject(message);

	}

	public Message loadMessage(Long messageId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(Message.class);
		criteria.add(Restrictions.eq("messageId", messageId));
		List<Message> list = criteria
				.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (Message) list.get(0);
		}
		return null;
	}

	public List<Message> loadMessagesByFromStaffId(String staffId, String state) {

		DetachedCriteria criteria = DetachedCriteria.forClass(Message.class);
		criteria.add(Restrictions.eq("fromStaffId", staffId));
		criteria.add(Restrictions.eq("state", state));
		/**
		 * Deleted Message filter changes. Start
		 * */
		Criterion c1 = Restrictions.isNull("deleteFrom");
		Criterion c2 = Restrictions.eq("deleteFrom", "N");
		LogicalExpression logEx = Restrictions.or(c1, c2);
		criteria.add(logEx);
		/**
		 * Deleted Message filter changes. Ends
		 * */
		criteria.addOrder(Order.desc("createdTime"));
		List<Message> list = criteria
				.getExecutableCriteria(getCurrentSession()).list();
		return list;
	}

	public List<Message> loadMessagesByToStaffId(String staffId, String state) {

		DetachedCriteria criteria = DetachedCriteria.forClass(Message.class);
		criteria.add(Restrictions.eq("toStaffId", staffId));
		criteria.add(Restrictions.eq("state", state));

		/**
		 * Deleted Message filter changes. Start
		 * */
		Criterion c1 = Restrictions.isNull("deleteTo");
		Criterion c2 = Restrictions.eq("deleteTo", "N");
		LogicalExpression logEx = Restrictions.or(c1, c2);
		criteria.add(logEx);
		/**
		 * Deleted Message filter changes. Ends
		 * */
		criteria.addOrder(Order.desc("createdTime"));
		List<Message> list = criteria
				.getExecutableCriteria(getCurrentSession()).list();
		return list;
	}

	public List<MessageView> loadMessagesByToStaffId(SessionUser user,
			String state) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(MessageView.class);

		if (user.isNITNorthLead() || user.isNITSouthLead()) {

			criteria.add(Restrictions.in("toStaffId", user.getLeadStaffIds()
					.toArray()));

			/**
			 * Deleted Message filter changes. Start
			 * */
			if (user.isNITNorthLead()) {

				if (state.equalsIgnoreCase(ECMSConstants.MESSAGE_STATE_NEW)) {
					Criterion cS1 = Restrictions.isNull("nitnLeadState");
					Criterion cS2 = Restrictions.eq("nitnLeadState", state);
					LogicalExpression logExs = Restrictions.or(cS1, cS2);
					Criterion c4 = Restrictions.eq("nitnLeadState",
							ECMSConstants.MESSAGE_STATE_READ);
					Criterion c5 = Restrictions.eq("markAsUnread", "Y");
					LogicalExpression logEx1 = Restrictions.and(c4, c5);
					LogicalExpression logEx2 = Restrictions.or(logExs, logEx1);
					criteria.add(logEx2);
				} else {
					//criteria.add(Restrictions.eq("nitnLeadState", state));	
					Criterion c3 = Restrictions.eq("nitnLeadState", state);
					Criterion c4 = Restrictions.isNull("markAsUnread");
					LogicalExpression logEx1 = Restrictions.and(c3, c4);
					criteria.add(logEx1);
				}

				Criterion c1 = Restrictions.isNull("deleteNitn");
				Criterion c2 = Restrictions.eq("deleteNitn", "N");
				LogicalExpression logEx = Restrictions.or(c1, c2);
				criteria.add(logEx);
			}

			if (user.isNITSouthLead()) {
				if (state.equalsIgnoreCase(ECMSConstants.MESSAGE_STATE_NEW)) {
					Criterion cS1 = Restrictions.isNull("nitsLeadState");
					Criterion cS2 = Restrictions.eq("nitsLeadState", state);
					LogicalExpression logExs = Restrictions.or(cS1, cS2);
					Criterion c4 = Restrictions.eq("nitsLeadState",
							ECMSConstants.MESSAGE_STATE_READ);
					Criterion c5 = Restrictions.eq("markAsUnread", "Y");
					LogicalExpression logEx1 = Restrictions.and(c4, c5);
					LogicalExpression logEx2 = Restrictions.or(logExs, logEx1);
					criteria.add(logEx2);
				} else {
					//criteria.add(Restrictions.eq("nitsLeadState", state));
					Criterion c3 = Restrictions.eq("nitsLeadState", state);
					Criterion c4 = Restrictions.isNull("markAsUnread");
					LogicalExpression logEx1 = Restrictions.and(c3, c4);
					criteria.add(logEx1);
				}
				Criterion c1 = Restrictions.isNull("deleteNits");
				Criterion c2 = Restrictions.eq("deleteNits", "N");
				LogicalExpression logEx = Restrictions.or(c1, c2);
				criteria.add(logEx);
			}
		} else {

			criteria.add(Restrictions.eq("toStaffId", user.getStaffId()));
			//criteria.add(Restrictions.eq("state", state));
			if (state.equalsIgnoreCase(ECMSConstants.MESSAGE_STATE_NEW)) {
				Criterion c3 = Restrictions.eq("state", state);
				Criterion c4 = Restrictions.eq("state",
						ECMSConstants.MESSAGE_STATE_READ);
				Criterion c5 = Restrictions.eq("markAsUnread", "Y");
				LogicalExpression logEx1 = Restrictions.and(c4, c5);
				LogicalExpression logEx2 = Restrictions.or(c3, logEx1);
				criteria.add(logEx2);
			} else if (state.equalsIgnoreCase(ECMSConstants.MESSAGE_STATE_READ)) {
				Criterion c3 = Restrictions.eq("state", state);
				Criterion c4 = Restrictions.isNull("markAsUnread");
				LogicalExpression logEx1 = Restrictions.and(c3, c4);
				criteria.add(logEx1);
			}

			Criterion c1 = Restrictions.isNull("deleteTo");
			Criterion c2 = Restrictions.eq("deleteTo", "N");
			LogicalExpression logEx = Restrictions.or(c1, c2);
			criteria.add(logEx);
		}

		/**
		 * Deleted Message filter changes. Ends
		 * */

		if (ECMSConstants.MESSAGE_STATE_NEW.equals(state)) {

			criteria.addOrder(Order.desc("createdTime"));
		} else if (ECMSConstants.MESSAGE_STATE_READ.equals(state)) {

			criteria.addOrder(Order.desc("readTime"));
		} else {
			criteria.addOrder(Order.desc("messageId"));
		}

		List<MessageView> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		return list;
	}

	public Message updateMessage(Message message) {

		saveObject(message);
		return message;
	}

	@Override
	public MessageView loadMessageView(Long messageId) {

		MessageView view = null;
		DetachedCriteria criteria = DetachedCriteria
				.forClass(MessageView.class);
		criteria.add(Restrictions.eq("messageId", messageId));
		List<MessageView> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			view = (MessageView) list.get(0);
		}
		return view;
	}

	@Override
	public List<Message> loadMessagesByCaseId(Long caseId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(Message.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.addOrder(Order.desc("createdTime"));
		List<Message> list = criteria
				.getExecutableCriteria(getCurrentSession()).list();
		return list;
	}

	@Override
	public List<Message> loadMessagesByInfoId(Long informationId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(Message.class);
		criteria.add(Restrictions.eq("informationId", informationId));
		criteria.addOrder(Order.desc("createdTime"));
		List<Message> list = criteria
				.getExecutableCriteria(getCurrentSession()).list();
		return list;
	}

	@Override
	public List<MessageView> loadMessagesByFromStaffId(SessionUser user) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(MessageView.class);

		if (user.isNITNorthLead() || user.isNITSouthLead()) {

			criteria.add(Restrictions.in("fromStaffId", user.getLeadStaffIds()
					.toArray()));

			/**
			 * Deleted Message filter changes. Start
			 * */
			if (user.isNITNorthLead()) {
				Criterion c1 = Restrictions.isNull("deleteNitn");
				Criterion c2 = Restrictions.eq("deleteNitn", "N");
				LogicalExpression logEx = Restrictions.or(c1, c2);
				criteria.add(logEx);
			}

			if (user.isNITSouthLead()) {
				Criterion c1 = Restrictions.isNull("deleteNits");
				Criterion c2 = Restrictions.eq("deleteNits", "N");
				LogicalExpression logEx = Restrictions.or(c1, c2);
				criteria.add(logEx);
			}
		} else {

			criteria.add(Restrictions.eq("fromStaffId", user.getStaffId()));
			Criterion c1 = Restrictions.isNull("deleteFrom");
			Criterion c2 = Restrictions.eq("deleteFrom", "N");
			LogicalExpression logEx = Restrictions.or(c1, c2);
			criteria.add(logEx);

		}
		/**
		 * Deleted Message filter changes. Ends
		 * */

		criteria.addOrder(Order.desc("createdTime"));
		List<MessageView> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		return list;
	}

	/**
	 * This method is responsible for fetching the trashed read messaged for the
	 * given Session User.
	 * 
	 * @param sessionStaff
	 * @param msgState
	 * 
	 * @return List<MessageView>
	 * 
	 * **/
	@SuppressWarnings("unchecked")
	public List<MessageView> loadTrashMessagesByToStaffId(
			SessionUser sessionStaff, String msgState) {
		ArrayList<MessageView> readMessages = new ArrayList<MessageView>();

		DetachedCriteria criteria = DetachedCriteria
				.forClass(MessageView.class);

		if (sessionStaff.isNITNorthLead() || sessionStaff.isNITSouthLead()) {

			criteria.add(Restrictions.in("toStaffId", sessionStaff
					.getLeadStaffIds().toArray()));

			if (sessionStaff.isNITNorthLead()) {
				if (msgState.equalsIgnoreCase(ECMSConstants.MESSAGE_STATE_NEW)) {
					Criterion cS1 = Restrictions.isNull("nitnLeadState");
					Criterion cS2 = Restrictions.eq("nitnLeadState", msgState);
					LogicalExpression logExs = Restrictions.or(cS1, cS2);
					criteria.add(logExs);
				} else {
					criteria.add(Restrictions.eq("nitnLeadState", msgState));
				}
				criteria.add(Restrictions.eq("deleteNitn", "Y"));
			}

			if (sessionStaff.isNITSouthLead()) {
				if (msgState.equalsIgnoreCase(ECMSConstants.MESSAGE_STATE_NEW)) {
					Criterion cS1 = Restrictions.isNull("nitsLeadState");
					Criterion cS2 = Restrictions.eq("nitsLeadState", msgState);
					LogicalExpression logExs = Restrictions.or(cS1, cS2);
					criteria.add(logExs);
				} else {
					criteria.add(Restrictions.eq("nitsLeadState", msgState));
				}
				criteria.add(Restrictions.eq("deleteNits", "Y"));
			}
		} else {
			criteria.add(Restrictions.eq("toStaffId", sessionStaff.getStaffId()));
			criteria.add(Restrictions.eq("state", msgState));
			criteria.add(Restrictions.eq("deleteTo", "Y"));
		}
		criteria.addOrder(Order.desc("createdTime"));
		readMessages = (ArrayList<MessageView>) criteria.getExecutableCriteria(
				getCurrentSession()).list();
		return readMessages;
	}

	/**
	 * This method is responsible for fetching the trashed sent messaged for the
	 * given Session User.
	 * 
	 * @param sessionStaff
	 * 
	 * @return List<MessageView>
	 * 
	 * **/
	@SuppressWarnings("unchecked")
	public List<MessageView> loadTrashMessagesByFromStaffId(
			SessionUser sessionStaff) {
		ArrayList<MessageView> sentMessages = new ArrayList<MessageView>();
		DetachedCriteria criteria = DetachedCriteria
				.forClass(MessageView.class);
		if (sessionStaff.isNITNorthLead() || sessionStaff.isNITSouthLead()) {
			criteria.add(Restrictions.in("fromStaffId", sessionStaff
					.getLeadStaffIds().toArray()));
			if (sessionStaff.isNITNorthLead()) {
				criteria.add(Restrictions.eq("deleteNitn", "Y"));
			}
			if (sessionStaff.isNITSouthLead()) {
				criteria.add(Restrictions.eq("deleteNits", "Y"));
			}
		} else {
			criteria.add(Restrictions.eq("fromStaffId",
					sessionStaff.getStaffId()));
			criteria.add(Restrictions.eq("deleteFrom", "Y"));
		}
		criteria.addOrder(Order.desc("createdTime"));
		sentMessages = (ArrayList<MessageView>) criteria.getExecutableCriteria(
				getCurrentSession()).list();

		return sentMessages;
	}
	
	@Override
	public void forwardMsgsToIMOMember(final String staffName, final String staffId, final Long[] msgIds){
		final String sql = "UPDATE MESSAGE_TBL SET TO_STAFF_NAME=:NAME,TO_STAFF_ID=:STAFF_ID, STATE=:STATE WHERE MESSAGE_ID IN :MSGIDS";
		final SQLQuery query = getCurrentSession().createSQLQuery(sql);
		
		query.setParameter("NAME", staffName);
		query.setParameter("STAFF_ID", staffId);
		query.setParameter("STATE", "NEW");
		query.setParameterList("MSGIDS", msgIds);

		int count = query.executeUpdate();
		
		System.out.println("count=="+count);
	}

}
