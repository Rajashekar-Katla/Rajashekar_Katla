package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.PersonDao;
import uk.nhs.cfsms.ecms.data.infoGath.Person;
import uk.nhs.cfsms.ecms.data.infoGath.PersonDescription;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonTO;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.ConvertToDTO;

@Repository
public class HibernatePersonDao extends HibernateBaseDao implements PersonDao {

	public PersonTO insertPerson(PersonTO dto) {

		if (dto.getPersonId() == null) {

			Person hibernate = ConvertFromDTO.getInstance().convertFromDTO(dto,
					null, false);

			if (dto.getPersonDescriptionTO() != null) {
				PersonDescription pDHibernate = ConvertFromDTO.getInstance()
						.convertFromDTO(dto.getPersonDescriptionTO());
				getCurrentSession().save(pDHibernate);

				hibernate.setPersonDescription(pDHibernate);
			}

			getCurrentSession().save(hibernate);

			return ConvertToDTO.getInstance().convertToDTO(hibernate);
		}
		return dto;
	}

	public PersonTO LoadPersonById(Person contact) {

		DetachedCriteria criteria = DetachedCriteria.forClass(Person.class)
				.add(Restrictions.idEq(contact.getPersonId()));

		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		PersonTO[] arrayTO = convertToDTO(list);

		if (arrayTO != null && arrayTO.length > 0) {
			return arrayTO[0];
		}

		return null;
	}

	private PersonTO[] convertToDTO(List hibernateList) {
		Iterator iter = hibernateList.iterator();
		List<PersonTO> list = new ArrayList<PersonTO>();
		while (iter.hasNext()) {
			Person hibernate = (Person) iter.next();
			PersonTO dto = new PersonTO();
			dto = ConvertToDTO.getInstance().convertToDTO(hibernate);
			list.add(dto);
		}

		return list.toArray(new PersonTO[list.size()]);
	}

}
