package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.MGFormDao;
import uk.nhs.cfsms.ecms.data.cim.MGForm;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileExtensions;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileTypes;

@Repository
public class HibernateMGFormDao extends HibernateBaseDao implements MGFormDao {

	@SuppressWarnings("unchecked")
	public List<MGForm> listMGForms(Long caseId) {

		List<MGForm> forms = new ArrayList<MGForm>();
		DetachedCriteria criteria = DetachedCriteria.forClass(MGForm.class)
				.add(Restrictions.eq("caseId", caseId));
		forms = criteria.getExecutableCriteria(getCurrentSession()).list();
		return forms;

	}

	public List<MGForm> listMGFormsForCPS(final Long caseId) {

		final String[] mgform_types = {"MG4F","MG4D","MG4D PG","MG4E","MG4D PG","MG8","MG13","MG6B"};
		final Criteria criteria = getCurrentSession().createCriteria(
				MGForm.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.isNotNull("mgForm"));
		criteria.add(Restrictions.isNotNull("fileName"));
		criteria.add(Restrictions.not(Restrictions.in("mgFormType", mgform_types)));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("mgFormId"), "mgFormId");
		projectionList.add(Projections.property("caseId"), "caseId");
		projectionList.add(Projections.property("fileName"), "fileName");
		projectionList.add(Projections.property("fileType"), "fileType");
		projectionList.add(Projections.property("mgFormType"), "mgFormType");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers.aliasToBean(MGForm.class));

		@SuppressWarnings("unchecked")
		final List<MGForm> list = criteria.list();

		return list;
	}
	
	@Override
	public Long getMGFormFileSize(final long mgFormId) {

		final String sql = "select (DBMS_LOB.GETLENGTH(MGFORM)) AS SIZE_MB from MGFORMS_TBL where MGFORM_ID=:id";

		final SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("id", mgFormId);

		@SuppressWarnings("unchecked")
		final List<Long> results = query.list();

		final long value = Long.parseLong(results.get(0)+"");

		return value;
	}

	public void deleteMGForm(Long mgFormId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(MGForm.class)
				.add(Restrictions.eq("mgFormId", mgFormId));
		@SuppressWarnings("unchecked")
		List<MGForm> forms = criteria
				.getExecutableCriteria(getCurrentSession()).list();
		MGForm mgForm = forms.get(0);
		getCurrentSession().delete(mgForm);
	}

	public MGForm saveMGForm(MGForm mgForm) {
		return (MGForm) getCurrentSession().merge(mgForm);

	}

	public MGForm loadMGForm(Long mgFormId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(MGForm.class)
				.add(Restrictions.eq("mgFormId", mgFormId));
		@SuppressWarnings("unchecked")
		List<MGForm> forms = criteria
				.getExecutableCriteria(getCurrentSession()).list();
		MGForm mgForm = (forms != null && !forms.isEmpty()) ? forms.get(0)
				: null;
		return mgForm;
	}

	public MGForm updateMGFormFileName(final Long mgFormId, String fileName) {
		MGForm mgForm = null;

		DetachedCriteria criteria = DetachedCriteria.forClass(MGForm.class)
				.add(Restrictions.eq("mgFormId", mgFormId));

		@SuppressWarnings("unchecked")
		List<MGForm> list = criteria.getExecutableCriteria(getCurrentSession())
				.list();

		if (list != null && !list.isEmpty()) {
			mgForm = list.get(0);

			final String dbFileName = mgForm.getFileName();
			final String dbFileExt = mgForm.getFileType();

			if (null != dbFileName) {
				String extension = FilenameUtils.getExtension(dbFileName);

				if (extension.isEmpty() && null != dbFileExt
						&& !dbFileExt.isEmpty()) {
					if (FileExtensions
							.isValidExtension(dbFileExt.toLowerCase())) {
						final String fullFileName = dbFileName + "."
								+ dbFileExt;
						if (!fileName.equals(fullFileName)) {
							mgForm.setFileName(fileName);
							getCurrentSession().update(mgForm);
							return mgForm;
						}
					} else {
						final FileTypes fileTypes = FileTypes
								.getExtention(dbFileExt.toLowerCase());
						if (fileTypes != null) {
							final String ext = fileTypes.toString();
							final String fullFileName = dbFileName + "." + ext;
							if (!fileName.equals(fullFileName)) {
								mgForm.setFileName(fileName);
								getCurrentSession().update(mgForm);
								return mgForm;
							}
						}
					}
				} else if (!extension.isEmpty() && !dbFileName.equals(fileName)) {
					mgForm.setFileName(fileName);
					getCurrentSession().update(mgForm);
					return mgForm;
				} else if (extension.isEmpty()
						&& (null == dbFileExt || dbFileExt.isEmpty())) {
					if (!dbFileName.isEmpty()) {
						extension = FilenameUtils.getExtension(fileName);
						if (FileExtensions.isValidExtension(extension
								.toLowerCase())) {
							fileName = fileName.substring(0,
									fileName.indexOf("." + extension));
							if (!dbFileName.equals(fileName)) {
								mgForm.setFileName(fileName);
								mgForm.setFileType(extension);
								getCurrentSession().update(mgForm);
								return mgForm;
							}
						} else {
							if (!dbFileName.equals(fileName)) {
								mgForm.setFileName(fileName);
								getCurrentSession().update(mgForm);
								return mgForm;
							}
						}

					} else {
						extension = FilenameUtils.getExtension(fileName);
						mgForm.setFileName(fileName);
						if (FileExtensions.isValidExtension(extension
								.toLowerCase())) {
							mgForm.setFileType(extension);
						}
						getCurrentSession().update(mgForm);
						return mgForm;
					}

				}
			}
		}
		return mgForm;
	}

	public MGForm downloadMGForm(final Long mgFormId,
			final boolean isFileBlobRequired) {
		MGForm mgForm = null;

		final Criteria criteria = getCurrentSession().createCriteria(
				MGForm.class);
		criteria.add(Restrictions.eq("mgFormId", mgFormId));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("fileName"), "fileName");
		projectionList.add(Projections.property("mgFormId"), "mgFormId");
		if (isFileBlobRequired) {
			projectionList.add(Projections.property("mgForm"), "mgForm");
		}
		projectionList.add(Projections.property("fileType"), "fileType");
		projectionList.add(Projections.property("mgFormType"), "mgFormType");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers.aliasToBean(MGForm.class));

		@SuppressWarnings("unchecked")
		final List<MGForm> list = criteria.list();

		if (!list.isEmpty()) {
			mgForm = list.get(0);
		}
		return mgForm;

	}

	public String loadRegexForDocumentType(String docType) {
		StringBuilder sbRegexQuery = new StringBuilder(" select");
		sbRegexQuery.append(" regex FROM CPS_REGEX_TBL reg");
		sbRegexQuery.append(" where reg.form_type = ?");

		@SuppressWarnings("unchecked")
		List<String> list = getCurrentSession()
				.createSQLQuery(sbRegexQuery.toString()).setString(0, docType)
				.list();
		return (list != null && !list.isEmpty()) ? list.get(0).toString() : "";
	}

}
