package uk.nhs.cfsms.ecms.dao;


import java.text.ParseException;
import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseActionBook;
import uk.nhs.cfsms.ecms.data.cim.CaseActionBookAttachment;
import uk.nhs.cfsms.ecms.dto.search.ActionSearchTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.model.CaseActionFilterCriteria;

/**
 * @author Jshrivastav
 *
 * This Interface is representing a skeleton of the DAO layer for the Case Action Book Functionality.
 * Defines all the DAO method required to service the user requirement against the case action Book. 
 * 
 * */
public interface CaseActionBookDao {

	/** 
	 * This method is responsible for generating a new Action Number for a given case ID
	 * By having a current count of exiting case action book for the case and return the next to be used.
	 * 
	 * @param caseID
	 * 
	 * */
	public String getCaseActionBookNumber(Long caseId);
	
	/** 
	 * This method is responsible for saving a new case Action book in the system
	 * 
	 * @param cab
	 * 
	 * */
	public CaseActionBook saveCaseActionBook(CaseActionBook cab);

	/** 
	 * This method is responsible for retrieving an case action book for a given ID
	 * 
	 * @param caseActionBookId
	 * 
	 * @return CaseActionBook
	 * 
	 * */
	public CaseActionBook loadCaseActionBook(Long caseActionBookId);
	
	/** 
	 * This method is responsible for updating an case action book in system.
	 * 
	 * @param cab
	 * 
	 * @return CaseActionBook
	 * 
	 * */
	public CaseActionBook updateCaseActionBook(CaseActionBook cab);
	
	/** 
	 * This method is responsible for loading all case action books for a given case ID in system.
	 * 
	 * @param caseId
	 * 
	 * @return java.util.List<CaseActionBook>
	 * 
	 * */
	public java.util.List<CaseActionBook> loadCaseActionBookByCaseId(Long caseId);
	
	/** 
	 * This method is responsible for loading all case action books with in the given starting and ending range
	 * for a given case ID in system.
	 * 
	 * @param caseId
	 * @param startingActionID
	 * @param endingActionID
	 * 
	 * @return java.util.List<CaseActionBook>
	 * 
	 * */
	public java.util.List<CaseActionBook> loadCaseActionBookByCaseId(Long caseId,Long startingActionID, Long endingActionID);
	
	/** 
	 * This method is responsible for loading all case action books for a given case ID in system.
	 * 
	 * @param caseId
	 * @param actionStatus
	 * 
	 * @return java.util.List<CaseActionBook>
	 * 
	 * */
	public java.util.List<CaseActionBook> loadCaseActionBookByCaseId(Long caseId, String actionStatus);
	
	/** 
	 * This method is responsible for loading all case action books with in the given starting and ending range
	 * for a given case ID in system.
	 * 
	 * @param caseId
	 * @param startingActionID
	 * @param endingActionID
	 * @param actionStatus
	 * 
	 * @return java.util.List<CaseActionBook>
	 * 
	 * */
	public java.util.List<CaseActionBook> loadCaseActionBookByCaseId(Long caseId,Long startingActionID, Long endingActionID, String actionStatus);
	
	/** 
	 * This method is responsible for loading all case action books attachments for a given action ID in system.
	 * 
	 * @param actionID
	 * 
	 * @return java.util.List<CaseActionBookAttachment>
	 * 
	 * */
	public List<CaseActionBookAttachment> listAttachments(Long actionID);
	
	/** 
	 * This method is responsible for saving a case action books attachment for a given action ID in system.
	 * 
	 * @param caseActionBookAttachment
	 * 
	 * */
	public void saveCaseActionBookAttachment(CaseActionBookAttachment caseActionBookAttachment);
	
	/** 
	 * This method is responsible for downloading a case action books attachment for a given attachment ID in system.
	 * 
	 * @param caseActionBookAttachment
	 * 
	 * */
	public CaseActionBookAttachment downloadCaseActionBookAttachment(Long attachmentID);
	
	public CaseActionBookAttachment loadCaseActionBookAttachment(Long attachmentID);
	
	/** 
	 * This method is responsible for saving a case action books attachment for a given action ID in system.
	 * 
	 * @param actionID
	 * 
	 * */
	public String getCaseActionBookAttachmentNumber(Long actionID);
	
	/** 
	 * This method is responsible for loading all case action books that are due 
	 * for actions with in the number of days as on current date in the system.
	 * 
	 * @param inNumberOfDays
	 * 
	 * @return java.util.List<CaseActionBook>
	 * @throws ParseException 
	 * 
	 * */
	public java.util.List<CaseActionBook> loadDueCaseActionBooks(int inNumberOfDays) throws ParseException;

	public ActionSearchTO getActionSearchResults(ActionSearchTO searchTO,
			SessionUser user);
	
	public List<CaseActionBook> loadCaseActionBook(
			CaseActionFilterCriteria filter) throws ServiceException ;
}
