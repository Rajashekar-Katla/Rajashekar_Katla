package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.InterviewDao;
import uk.nhs.cfsms.ecms.data.cim.Interview;
import uk.nhs.cfsms.ecms.data.cim.InterviewContent;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileExtensions;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileTypes;

@Repository(value = "interviewDao")
public class HibernateInterviewDao extends HibernateBaseDao implements
		InterviewDao {

	/**
	 * Get Interviews mainly for manullay filled form details.
	 * 
	 */
	public List<Interview> getInterviews(Long caseId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(Interview.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.ne("uploaded", 'Y'));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}

	/**
	 * Get Interviews mainly for uploaded form details.
	 * 
	 */
	public List<Interview> getInterviewsUploaded(Long caseId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(Interview.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.isNotNull("mg16Form"));
		criteria.addOrder(Order.asc("date"));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}

	public List<Interview> getInterviewsForCPS(final Long caseId) {

		final Criteria criteria = getCurrentSession().createCriteria(
				Interview.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.isNotNull("mg16Form"));
		criteria.add(Restrictions.isNotNull("fileName"));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("interviewId"), "interviewId");
		projectionList.add(Projections.property("caseId"), "caseId");
		projectionList.add(Projections.property("fileName"), "fileName");
		projectionList.add(Projections.property("fileType"), "fileType");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers.aliasToBean(Interview.class));

		@SuppressWarnings("unchecked")
		final List<Interview> list = criteria.list();

		return list;
	}

	@Override
	public Long getInterviewFileSize(final long interviewId) {

		final String sql = "select (DBMS_LOB.GETLENGTH(MG_16_FORM)) AS SIZE_MB from INTERVIEW_TBL where INTERVIEW_ID=:id";

		final SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("id", interviewId);

		@SuppressWarnings("unchecked")
		final List<Long> results = query.list();

		final long value = Long.parseLong(results.get(0) + "");

		return value;
	}

	/**
	 * Gets the interview contents then loads the interview and sets the
	 * interview contents.
	 * 
	 */
	public Interview loadInterview(Long interviewId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				InterviewContent.class).add(
				Restrictions.eq("interview.interviewId", interviewId));

		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<InterviewContent> contentList = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		for (int i = 0; i < contentList.size(); i++) {
			InterviewContent c = (InterviewContent) contentList.get(i);
			c.setTextString(new String(c.getText()));
		}

		Interview interview = (Interview) getObject(Interview.class,
				interviewId);

		interview.setInterviewContents(contentList);

		return interview;

	}

	public Interview downloadInterviewForCps(final Long interviewId,
			final boolean isFileBlobRequired) {

		Interview interview = null;

		final Criteria criteria = getCurrentSession().createCriteria(
				Interview.class);
		criteria.add(Restrictions.eq("interviewId", interviewId));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("fileName"), "fileName");
		projectionList.add(Projections.property("fileType"), "fileType");
		projectionList.add(Projections.property("interviewId"), "interviewId");

		if (isFileBlobRequired) {
			projectionList.add(Projections.property("mg16Form"), "mg16Form");
		}

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers.aliasToBean(Interview.class));

		@SuppressWarnings("unchecked")
		final List<Interview> list = criteria.list();

		if (!list.isEmpty()) {
			interview = list.get(0);
		}
		return interview;

	}

	/**
	 * Gets the interview contents then loads the interview and sets the
	 * interview contents.
	 * 
	 */
	public Interview updateInterviewFileName(final Long interviewId,
			String fileName) {

		Interview interview = null;

		final DetachedCriteria criteria = DetachedCriteria
				.forClass(Interview.class);

		criteria.add(Restrictions.eq("interviewId", interviewId));

		@SuppressWarnings("unchecked")
		final List<Interview> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		if (list != null && !list.isEmpty()) {
			interview = list.get(0);
			final String dbFileName = interview.getFileName();
			final String dbFileExt = interview.getFileType();

			if (null != dbFileName) {
				String extension = FilenameUtils.getExtension(dbFileName);
				if (extension.isEmpty() && null != dbFileExt
						&& !dbFileExt.isEmpty()) {
					if (FileExtensions
							.isValidExtension(dbFileExt.toLowerCase())) {
						final String fullFileName = dbFileName + "."
								+ dbFileExt;
						if (!fileName.equals(fullFileName)) {
							interview.setFileName(fileName);
							getCurrentSession().update(interview);
							return interview;
						}
					} else {
						final FileTypes fileTypes = FileTypes
								.getExtention(dbFileExt.toLowerCase());
						if (fileTypes != null) {
							final String ext = fileTypes.toString();
							final String fullFileName = dbFileName + "." + ext;
							if (!fileName.equals(fullFileName)) {
								interview.setFileName(fileName);
								getCurrentSession().update(interview);
								return interview;
							}
						}
					}

				} else if (!extension.isEmpty() && !dbFileName.equals(fileName)) {
					interview.setFileName(fileName);
					getCurrentSession().update(interview);
					return interview;
				} else if (extension.isEmpty()
						&& (null == dbFileExt || dbFileExt.isEmpty())) {
					if (!dbFileName.isEmpty()) {
						extension = FilenameUtils.getExtension(fileName);
						if (FileExtensions.isValidExtension(extension
								.toLowerCase())) {
							fileName = fileName.substring(0,
									fileName.indexOf("." + extension));
							if (!dbFileName.equals(fileName)) {
								interview.setFileName(fileName);
								interview.setFileType(extension);
								getCurrentSession().update(interview);
								return interview;
							}
						} else {
							if (!dbFileName.equals(fileName)) {
								interview.setFileName(fileName);
								getCurrentSession().update(interview);
								return interview;
							}
						}
					} else {
						extension = FilenameUtils.getExtension(fileName);
						if (FileExtensions.isValidExtension(extension
								.toLowerCase())) {
							interview.setFileType(extension);
						}
						interview.setFileName(fileName);
						getCurrentSession().update(interview);
						return interview;
					}
				}
			}
		}
		return interview;

	}

}
