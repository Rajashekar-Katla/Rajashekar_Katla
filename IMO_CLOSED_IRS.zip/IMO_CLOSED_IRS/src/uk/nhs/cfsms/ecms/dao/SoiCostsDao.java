package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.CaseCourtCosts;
import uk.nhs.cfsms.ecms.data.cim.ExpectedCourtCost;
import uk.nhs.cfsms.ecms.data.cim.SoiCosts;


public interface SoiCostsDao {
			
	public SoiCosts saveSoiCosts(SoiCosts soicost);
	
	public SoiCosts loadSoiCosts(Long soicost) ;
	
	public SoiCosts updateSoiCosts(SoiCosts soicost);
		
	public SoiCosts loadSoiCostsByCaseId(Long caseId) ;
	
	public List<CaseCourtCosts> saveCourtCosts(List<CaseCourtCosts> cost) ;
	
	public List<CaseCourtCosts> loadCourtCaseCostsByCaseId(Long caseId) ;
	
	public List<ExpectedCourtCost> loadExpectedCourtCosts() ;
	
	public void deleteCourtCosts(List<CaseCourtCosts> cost) ;
}