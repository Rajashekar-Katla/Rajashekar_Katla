package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.InformationProgress;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

public interface InformationProgressDao {

	Long generateMinuteNumber(Long informationId)
			throws ServiceException;

	List<InformationProgress> loadInformationProgresses(Long informationId)
			throws ServiceException;

	void saveInformationProgress(final InformationProgress informationProgress) throws ServiceException;
}
