package uk.nhs.cfsms.ecms.dao.hibernate;

/**
 * HibernateDao for Case Progress
 * @author schilukuri
 *   
 */

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.ScrollableResults;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.CaseProgressDao;
import uk.nhs.cfsms.ecms.data.cim.CaseProgress;
import uk.nhs.cfsms.ecms.data.cim.CaseProgressNumber;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
@Repository
public class HibernateCaseProgressDao extends HibernateBaseDao implements
		CaseProgressDao {

	@Deprecated
	public Long generateMinuteNumber(final Long caseId) {
		Long result = null;	 
		
		StringBuffer sbHQL = new StringBuffer();
		sbHQL.append("select max(to_number(sequence)) as sequence from case_progress_no_tbl ");
		sbHQL.append("where case_id = ");
		sbHQL.append(caseId);
			
		SQLQuery query = getCurrentSession().createSQLQuery(sbHQL.toString());
		query.addScalar("sequence");
		List list = query.list(); 
		 
		// No results from query means first entry for the case - vKolla
		if (list.isEmpty()) {

			// create a long for the first progress number
			result = new Long(1);

			// create the next sequence
			CaseProgressNumber cpn = new CaseProgressNumber();
			cpn.setCaseId(caseId);
			cpn.setSequence("2");

			// and save the bugger
			getCurrentSession().save(cpn);

		} else {

			// Get the sequence
			Long sequence = null;
			if (list.size() == 1) {
				if (list.get(0) != null)
					sequence = (Long) list.get(0);
				else
					sequence = new Long(1);
			} else {
				sequence = (Long) list.get(list.size() - 1);
			}

			// store the sequence number
			result = sequence;

			// Increment the sequence
			Long nextSequenceVal = sequence;
			nextSequenceVal++;
			

			// Update the case numbers table
			CaseProgressNumber cpn = new CaseProgressNumber();
			cpn.setCaseId(caseId);
			cpn.setSequence(nextSequenceVal == null ? "" : nextSequenceVal
					.toString());
			
			getCurrentSession().merge(cpn);
			
		}
		return result;
	}
	
	
	public Long generateMinuteNumber(final Long caseId, final String caseType) {
		
		final String sql = "select max(to_number(MINUTE_NO)) as sequence from CASE_PROGRESS_TBL" +
				" where case_id = "+ caseId +" and type = '"+caseType+"'";
		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.addScalar("sequence");
		List list =  query.list();
				 
		
		if (null == list || null == list.get(0)) {
			return 1l;
		}
		
		String currentSeq = list.get(0).toString();
		
		if (StringUtils.isEmpty(currentSeq)) {
			return 1l;
		}
		
		return new Long(currentSeq) + 1; 
	}
	
	

	@SuppressWarnings("unchecked")
	public List<CaseProgress> loadCaseProgresses(Long caseId) {
		
		List<CaseProgress> list = new ArrayList<CaseProgress>();

		DetachedCriteria criteria = DetachedCriteria.forClass(
				CaseProgress.class).add(Restrictions.eq("caseId", caseId));
		criteria.addOrder(Order.asc("minuteNumber"));
		
		list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}

	public List<CaseProgress> loadCaseProgresses(Long caseId, String type) {
		
		List<CaseProgress> list = new ArrayList<CaseProgress>();

		DetachedCriteria criteria = DetachedCriteria.forClass(
				CaseProgress.class).add(Restrictions.eq("caseId", caseId));
		if (isPolicyOrDecisionLog(type)) {
			criteria.add(Restrictions.or(
					Restrictions.eq("type", CaseUtil.POLICY_BOOK_TYPE),
					Restrictions.eq("type", CaseUtil.DECISION_LOG_TYPE)));
		} else {
			criteria.add(Restrictions.eq("type", type));
		}
		criteria.addOrder(Order.asc("minuteNumber"));
		list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}
	
	private boolean isPolicyOrDecisionLog(String type) {
		if (type.equals(CaseUtil.POLICY_BOOK_TYPE) || type.equals(CaseUtil.DECISION_LOG_TYPE)) {
			return true;
		}
		return false;
	}

	public List<CaseProgress> loadCaseProgressesByCaseByMinutes(
			final Long caseId, final String type, final int startMin,
			final int endMin) throws ServiceException {
		
		StringBuffer sbHQL = new StringBuffer();
		sbHQL.append("select CASE_PROGRESS_ID,TYPE,MINUTE_REF,RECORDED_BY,DATE_OF_EVENT,DATE_RECORDED,TIME,CASE_ID,CREATED_STAFF_ID,CREATED_TIME,DESCRIPTION,MINUTE_NO,SENSITIVE  from case_progress_tbl ");
		sbHQL.append("where case_id =").append(caseId);
		
		if (isPolicyOrDecisionLog(type)) {
			sbHQL.append(" and ((type ='").append(CaseUtil.POLICY_BOOK_TYPE+ "') ");
			sbHQL.append(" or (type ='").append(CaseUtil.DECISION_LOG_TYPE+ "') )");
		} else {
			sbHQL.append(" and type ='").append(type + "'");
		}						
		sbHQL.append(" and to_number(minute_no) >=").append(startMin);
		sbHQL.append(" and to_number(minute_no) <=").append(endMin);

		SQLQuery query = getCurrentSession().createSQLQuery(sbHQL
				.toString());

		ScrollableResults results = query.scroll();
		
		/*ScrollableResults results = (ScrollableResults) getHibernateTemplate()
				.execute(new HibernateCallback() {
					public Object doInHibernate(Session session)
							throws HibernateException, SQLException {
						StringBuffer sbHQL = new StringBuffer();
						sbHQL.append("select CASE_PROGRESS_ID,TYPE,MINUTE_REF,RECORDED_BY,DATE_OF_EVENT,DATE_RECORDED,TIME,CASE_ID,CREATED_STAFF_ID,CREATED_TIME,DESCRIPTION,MINUTE_NO,SENSITIVE  from case_progress_tbl ");
						sbHQL.append("where case_id =").append(caseId);
						
						if (isPolicyOrDecisionLog(type)) {
							sbHQL.append(" and ((type ='").append(CaseUtil.POLICY_BOOK_TYPE+ "') ");
							sbHQL.append(" or (type ='").append(CaseUtil.DECISION_LOG_TYPE+ "') )");
						} else {
							sbHQL.append(" and type ='").append(type + "'");
						}						
						sbHQL.append(" and to_number(minute_no) >=").append(startMin);
						sbHQL.append(" and to_number(minute_no) <=").append(endMin);

						SQLQuery query = session.createSQLQuery(sbHQL
								.toString());

						return query.scroll();
					}
				});*/
		try {
			// If the query didn't return any results
			return setCaseProgressList(results);
		} catch (Exception e) {

			throw new ServiceException(e);
		}

	}

	public List<CaseProgress> setCaseProgressList(ScrollableResults queryResults)
			throws Exception {
		List<CaseProgress> progressList = new ArrayList<CaseProgress>();

		while (queryResults.next()) {
			CaseProgress progress = new CaseProgress();

			Object[] result = queryResults.get();

			if (result[0] != null)
				progress.setCaseProgressId(getLongValue(result[0]));

			if (result[1] != null)
				progress.setType((String) result[1]);

			if (result[2] != null)
				progress.setMinuteNumberCrossRefered((String) result[2]);
			if (result[3] != null)
				progress.setRecordedBy((String) result[3]);
			if (result[4] != null)
				progress.setDateOfEvent((Date) result[4]);
			if (result[5] != null)
				progress.setDateRecorded((Date) result[5]);
			if (result[6] != null)
				progress.setTime((String) result[6]);
			if (result[7] != null)
				progress.setCaseId(getLongValue(result[7]));
			if (result[8] != null)
				progress.setCreatedStaffId((String) result[8]);
			if (result[9] != null)
				progress.setCreatedTime((Date) result[9]);
			if (result[10] != null)
				progress.setDescription(getClobString(result[10]));
			if (result[11] != null)
				progress.setMinuteNumber((String) result[11]);
			progressList.add(progress);

		}
		return progressList;
	}

	public Long getLongValue(Object obj) {
		
		if (obj instanceof BigDecimal) {
			
			BigDecimal big = (BigDecimal) obj;
			return new Long(big.longValue());
			
		} else if (obj instanceof Long) {

			return (Long) obj;
		}
		
		return null;
	}

	private String getClobString(Object obj) throws Exception {

		if (obj instanceof Clob) {
			
			Clob clob = (Clob) obj;
			return clob.getSubString(1, (int) clob.length());
		}
		
		return "";
	}

	@SuppressWarnings("unchecked")
	@Override 
	public List<CaseProgress> loadCaseProgresses(Long caseId, 
			String progressSheetType, String sensitivity)
			throws ServiceException {
		
		List<CaseProgress> list = new ArrayList<CaseProgress>();

		DetachedCriteria criteria = DetachedCriteria.forClass(CaseProgress.class).add(Restrictions.eq("caseId", caseId));
		
		if (isPolicyOrDecisionLog(progressSheetType)) {
			
			criteria.add(Restrictions.or(
					Restrictions.eq("type", CaseUtil.POLICY_BOOK_TYPE),
					Restrictions.eq("type", CaseUtil.DECISION_LOG_TYPE)));
		} else {
			criteria.add(Restrictions.eq("type", progressSheetType));
		}
		
		criteria.add(Restrictions.eq("sensitive", sensitivity));
		criteria.addOrder(Order.asc("minuteNumber"));
		
		list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}


	@Override
	@SuppressWarnings("rawtypes")
	public CaseProgress loadCaseProgressById(Long caseProgressId)
			throws ServiceException {
		
		Criteria criteria = getCurrentSession().createCriteria(CaseProgress.class);
		criteria.add(Restrictions.idEq(caseProgressId));
		
		
		List list = criteria.list();

		if (null != list && !list.isEmpty()) {
			return (CaseProgress)list.get(0);
		}
		return null;
	}

}
