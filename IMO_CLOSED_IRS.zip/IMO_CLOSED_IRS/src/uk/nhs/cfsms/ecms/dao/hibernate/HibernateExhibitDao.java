package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.commons.io.FilenameUtils;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.ExhibitDao;
import uk.nhs.cfsms.ecms.data.cim.Exhibit;
import uk.nhs.cfsms.ecms.data.cim.ExhibitDocuments;
import uk.nhs.cfsms.ecms.dto.exhibit.ExhibitViewTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileExtensions;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileTypes;

@Repository
public class HibernateExhibitDao extends HibernateBaseDao implements ExhibitDao {

	@SuppressWarnings("unchecked")
	public List<Exhibit> loadExhibits(Long caseId) {

		final String sql = "select new uk.nhs.cfsms.ecms.data.cim.Exhibit("
				+ "e.exhibitId,e.reference,e.description,e.disclosureState,e.caseId,e.createdDate,e.fromPlacePerson) "
				+ "from Exhibit e where e.caseId=:caseId";

		final Query query = getEntityManager().createQuery(sql);
		query.setParameter("caseId", caseId);

		final List<Exhibit> results = query.getResultList();

		return results;
	}
	
	public Exhibit loadExhibit(final Long exhibitId) {

		final String sql = "select new uk.nhs.cfsms.ecms.data.cim.Exhibit("
				+ "e.exhibitId,e.reference,e.description,e.disclosureState,e.caseId,e.createdDate,e.fromPlacePerson) "
				+ "from Exhibit e where e.exhibitId=:exhibitId";

		final Query query = getEntityManager().createQuery(sql);
		query.setParameter("exhibitId", exhibitId);

		final Exhibit result = (Exhibit) query.getSingleResult();

		return result;
	}

	public List<ExhibitDocuments> loadExhibitsForCPS(final Long caseId) {
		
		final String sql = "select new uk.nhs.cfsms.ecms.data.cim.ExhibitDocuments(ed.id, ed.fileName, ed.exhibitType) "
				+ "from ExhibitDocuments ed where ed.exhibit.caseId=:caseId and ed.document is not null";

		final Query query = getEntityManager().createQuery(sql);
		query.setParameter("caseId", caseId);

		@SuppressWarnings("unchecked")
		final List<ExhibitDocuments> results = query.getResultList();

		return results;

	}

	@Override
	public List<Exhibit> loadAllExhibitDocuments(final long caseId,
			final String exhibitType) {

		final Query query = getEntityManager()
				.createQuery(
						"select documents.id, documents.fileExtension, documents.fileName, documents.exhibitType, exhibit.exhibitId, exhibit.reference, exhibit.disclosureState,documents.uploadedOn from Exhibit exhibit join exhibit.exhibitDocumentsList documents where exhibit.caseId=:caseId and documents.exhibitType=:type and documents.document is not null and documents.fileName is not null");
		query.setParameter("caseId", caseId);
		query.setParameter("type", exhibitType);

		@SuppressWarnings("unchecked")
		final List<Exhibit> results = query.getResultList();

		return results;
	}

	@Override
	public Long getExhibitFileSize(final long id) {

		final String sql = "select (DBMS_LOB.GETLENGTH(document)) AS SIZE_MB from EXHIBIT_DOCUMENTS_TBL where ID=:id";

		final SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("id", id);

		@SuppressWarnings("unchecked")
		final List<Long> results = query.list();

		final long value = Long.parseLong(results.get(0) + "");

		return value;
	}

	public ExhibitDocuments downloadExhibitDocument(final Long id) {

		final String sql = "select documents from ExhibitDocuments documents where documents.id=:id";

		final Query query = getEntityManager().createQuery(sql,
				ExhibitDocuments.class);
		query.setParameter("id", id);

		@SuppressWarnings("unchecked")
		final List<ExhibitDocuments> results = query.getResultList();

		return results.get(0);

	}

	public void deleteExhibitDocument(final Long id) {
		final String sql = "delete from ExhibitDocuments documents where documents.id=:id";
		final Query query = getEntityManager().createQuery(sql);
		query.setParameter("id", id);
		query.executeUpdate();
	}

	public void deleteExhibit(final Long exhibitId) {
		
		final String deleteChild = "delete from ExhibitDocuments document where document.exhibit.exhibitId=:exhibitId";
		final String deleteParent = "delete from Exhibit exhibit where exhibit.exhibitId=:exhibitId";
		
		final Query childQuery = getEntityManager().createQuery(deleteChild);
		childQuery.setParameter("exhibitId", exhibitId);
		childQuery.executeUpdate();
		
		final Query parentQuery = getEntityManager().createQuery(deleteParent);
		parentQuery.setParameter("exhibitId", exhibitId);
		parentQuery.executeUpdate();
	}

	public ExhibitViewTO downloadExhibit(final Long id, final String exhibitType) {

		String query = "select NEW uk.nhs.cfsms.ecms.dto.exhibit.ExhibitViewTO("
				+ "documents.fileExtension, "
				+ "documents.fileName, "
				+ "documents.exhibitType) "
				+ "from ExhibitDocuments documents "
				+ "where documents.id=:id "
				+ "and documents.exhibitType=:exhibitType and documents.document is not null and documents.fileName is not null";

		TypedQuery<ExhibitViewTO> typedQuery = getEntityManager().createQuery(
				query, ExhibitViewTO.class);
		typedQuery.setParameter("id", id);
		typedQuery.setParameter("exhibitType", exhibitType);

		final List<ExhibitViewTO> results = typedQuery.getResultList();

		return results.get(0);

	}

	public ExhibitDocuments downloadExhibitLabel(final Long exhibitId,
			final boolean isFileBlobRequired) {

		ExhibitDocuments exhibitLabel = null;

		Criteria criteria = getCurrentSession().createCriteria(
				ExhibitDocuments.class);
		criteria.add(Restrictions.eq("exhibitId", exhibitId));
		criteria.add(Restrictions.eq("exhibitType", "ExhibitLabel"));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("fileName"), "fileName");
		projectionList.add(Projections.property("exhibitId"), "exhibitId");
		projectionList.add(Projections.property("fileExtension"),
				"fileExtension");

		if (isFileBlobRequired) {
			projectionList.add(Projections.property("document"), "document");
		}

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers
				.aliasToBean(ExhibitDocuments.class));

		@SuppressWarnings("unchecked")
		List<ExhibitDocuments> list = criteria.list();

		if (!list.isEmpty()) {
			exhibitLabel = list.get(0);
		}

		return exhibitLabel;

	}

	public void updateExhibit(final Exhibit exhibit) {
		getCurrentSession().update(exhibit);
	}

	public void saveExhibitDocuments(final ExhibitDocuments exhibitDocuments) {
		getCurrentSession().merge(exhibitDocuments);
	}

	/**
	 * This method is responsible for updating Exhibit file name with new name.
	 * */
		@SuppressWarnings("unchecked")
		public boolean updateExhibitFileName(final Long id, String fileName) {
			ExhibitDocuments exhibitDocuments = null;
	
			DetachedCriteria criteria = DetachedCriteria.forClass(ExhibitDocuments.class);
			criteria.add(Restrictions.eq("id", id));
			List<ExhibitDocuments> list = criteria
					.getExecutableCriteria(getCurrentSession()).list();
	
			if (list != null && !list.isEmpty()) {
				exhibitDocuments = list.get(0);
							final String dbFileName = exhibitDocuments.getFileName();
							final String dbFileExt = exhibitDocuments.getFileExtension();
	
							if (null != dbFileName) {
								String extension = FilenameUtils.getExtension(dbFileName);
								if (extension.isEmpty() && null != dbFileExt
										&& !dbFileExt.isEmpty()) {
									if (FileExtensions
											.isValidExtension(dbFileExt.toLowerCase())) {
										final String fullFileName = dbFileName + "."
												+ dbFileExt;
										if (!fileName.equals(fullFileName)) {
											exhibitDocuments.setFileName(fileName);
											getCurrentSession().update(exhibitDocuments);
											return true;
										}
									} else {
										final FileTypes fileTypes = FileTypes
												.getExtention(dbFileExt.toLowerCase());
										if (fileTypes != null) {
											final String ext = fileTypes.toString();
											final String fullFileName = dbFileName + "." + ext;
											if (!fileName.equals(fullFileName)) {
												exhibitDocuments.setFileName(fileName);
												getCurrentSession().update(exhibitDocuments);
												return true;
											}
										}
									}
				
								} else if (!extension.isEmpty() && !dbFileName.equals(fileName)) {
									exhibitDocuments.setFileName(fileName);
									getCurrentSession().update(exhibitDocuments);
									return true;
								} else if (extension.isEmpty()
										&& (null == dbFileExt || dbFileExt.isEmpty())) {
									if (!dbFileName.isEmpty()) {
										extension = FilenameUtils.getExtension(fileName);
										if (FileExtensions.isValidExtension(extension
												.toLowerCase())) {
											fileName = fileName.substring(0,
													fileName.indexOf("." + extension));
											if (!dbFileName.equals(fileName)) {
												exhibitDocuments.setFileName(fileName);
												exhibitDocuments.setFileExtension(extension);
												getCurrentSession().update(exhibitDocuments);
												return true;
											}
										} else {
											if (!dbFileName.equals(fileName)) {
												exhibitDocuments.setFileName(fileName);
												getCurrentSession().update(exhibitDocuments);
												return true;
											}
										}
									} else {
										extension = FilenameUtils.getExtension(fileName);
										if (FileExtensions.isValidExtension(extension
												.toLowerCase())) {
											exhibitDocuments.setFileExtension(extension);
										}
										exhibitDocuments.setFileName(fileName);
										getCurrentSession().update(exhibitDocuments);
										return true;
									}
				
								}
							}
			}
			return false;
		}

}
