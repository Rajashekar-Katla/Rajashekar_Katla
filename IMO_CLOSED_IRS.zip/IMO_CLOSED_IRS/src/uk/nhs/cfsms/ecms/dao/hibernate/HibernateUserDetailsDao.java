package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.UserDetailsDao;
import uk.nhs.cfsms.ecms.data.authentication.Users;
import uk.nhs.cfsms.ecms.data.authorization.AccessControl;
import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.common.CPODLatestUsersView;
import uk.nhs.cfsms.ecms.data.common.OrganisationTeamCode;
import uk.nhs.cfsms.ecms.data.common.StaffTeams;
import uk.nhs.cfsms.ecms.data.common.UserHistory;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.common.UserPreference;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;
import uk.nhs.cfsms.ecms.exceptions.ListEmptyException;
import uk.nhs.cfsms.ecms.service.IMOMessageReceiverService;
import uk.nhs.cfsms.ecms.utility.CaseUtil;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * @author R Tobin Hibernate dao : UserObject Mapping UserObject ->
 *         ALL_USERS_VIEW
 * 
 * @changes As a part of the new restructure(CFSMS>>PROTECT), NewTeamCodes start
 *          from 31 March 2011.
 */

@Repository
public class HibernateUserDetailsDao extends HibernateBaseDao implements
		UserDetailsDao {

	@Autowired
	private IMOMessageReceiverService imoMessagereceiverService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * uk.nhs.cfsms.ecms.dao.UserDetailsDao#loadUserByUserId(java.lang.String)
	 * 
	 * load user details Object by staffID
	 */

	public UserObject loadUserByUserId(String staffId) {
		// MatchMode matchMode = MatchMode.EXACT;
		DetachedCriteria criteria = DetachedCriteria.forClass(UserObject.class);
		criteria.add(Restrictions.idEq(staffId)).addOrder(Order.asc("staffId"));

		List users = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (users != null && !users.isEmpty()) {
			return (UserObject) (users.get(0));
		}
		return null;
	}

	public UserObject loadUserByUserIdForCPS(final String staffId) {
		UserObject userObject = null;
		Criteria criteria = getCurrentSession()
				.createCriteria(UserObject.class);
		criteria.add(Restrictions.eq("staffId", staffId));
		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("title"), "title");
		projectionList.add(Projections.property("firstName"), "firstName");
		projectionList.add(Projections.property("lastName"), "lastName");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers
				.aliasToBean(UserObject.class));

		@SuppressWarnings("unchecked")
		List<UserObject> list = criteria.list();

		userObject = list.get(0);

		return userObject;
	}

	// TODO staff email address retrieved from CPOD DB, so this method may not be in use

	public String getStaffEmailAddress(final String staffId) {
		UserObject userObject = null;
		Criteria criteria = getCurrentSession()
				.createCriteria(UserObject.class);
		criteria.add(Restrictions.eq("staffId", staffId));
		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("nhsEmailAddress"),
				"nhsEmailAddress");
		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers
				.aliasToBean(UserObject.class));

		@SuppressWarnings("unchecked")
		final List<UserObject> list = criteria.list();
		userObject = list.get(0);
		final String nhsEmailID = userObject.getNhsEmailAddress();

		return nhsEmailID != null ? nhsEmailID : "";
	}

	/**
	 * This method retrieves staff email address from CPOD DB.
	 */
	public String getStaffEmailAddressFromCPOD(final String staffId) {
		final String sql = "select * from cpod.LATEST_USERS_VIEW@cpod_ro where user_ref = :staffId";
		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("staffId", staffId);
		query.addEntity(CPODLatestUsersView.class);

		@SuppressWarnings("unchecked")
		final List<CPODLatestUsersView> results = query.list();
		String nhsEmailID = null;
		if (!results.isEmpty()) {
			CPODLatestUsersView cpodLatestUsersView = results.get(0);
			nhsEmailID = cpodLatestUsersView.getEmailNhs();
		} else {
			nhsEmailID = null;
		}
		return nhsEmailID != null ? nhsEmailID : "";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * uk.nhs.cfsms.ecms.dao.UserDetailsDao#loadUsersByGroups(java.lang.String)
	 * 
	 * load user details Object by user groups
	 */
	public List loadUsersByGroups(String userGroups[]) {

		DetachedCriteria criteria = DetachedCriteria.forClass(UserObject.class);
		criteria.add(Property.forName("groupPermission").in(userGroups));
		List users = criteria.getExecutableCriteria(getCurrentSession()).list();
		return users;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see uk.nhs.cfsms.ecms.dao.UserDetailsDao#loadUser(java.lang.String)
	 * 
	 * load user details Object by staffID
	 */
	public UserObject loadUser(String staffId) {

		return (UserObject) getCurrentSession().get(UserObject.class, staffId);
	}

	public List<StaffTeams> loadTeamsByStaffId(String staffId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(StaffTeams.class);
		criteria.add(Restrictions.eq("staffId", staffId));
		List teams = criteria.getExecutableCriteria(getCurrentSession()).list();
		return teams;
	}

	public List loadLcfsStaffByCaseTeamCodeByCaseId(Long caseId) {

		final StringBuffer sql = new StringBuffer("select ");
		sql.append("distinct lcfs_staff_tbl.staff_id,");
		sql.append("lcfs_staff_tbl.title, lcfs_staff_tbl.forename1,");
		sql.append("lcfs_staff_tbl.surname,lcfs_staff_tbl.job_title,");
		sql.append("lcfs_staff_tbl.emp_orgcode,team_orgs_tbl.team_code ");
		sql.append("from lcfs_staff_tbl inner join lcfs_responsibilities_tbl");
		sql.append(" on lcfs_staff_tbl.staff_id = lcfs_responsibilities_tbl.staff_id");
		sql.append(" inner join team_orgs_tbl on ");
		sql.append(" lcfs_responsibilities_tbl.org_code = team_orgs_tbl.org_code ");
		sql.append(" where team_orgs_tbl.team_code = ");
		sql.append("(select team_code from case_tbl where case_id = '");
		sql.append(caseId);
		sql.append("' and restrict_to ='CFS_LOC')");
		sql.append(" and lcfs_responsibilities_tbl.start_date <= current_date");
		sql.append(" and (lcfs_responsibilities_tbl.end_date >= current_date ");
		sql.append(" or lcfs_responsibilities_tbl.end_date is null )");
		sql.append(" and lcfs_staff_tbl.status = 'A'");

		List lcfsStaffList = getCurrentSession().createSQLQuery(sql.toString())
				.list();

		return setUserList(lcfsStaffList);

	}

	public List<UserObject> listUserDetailsByAccessLevelAndOrgCode(
			String accessLevel, String orgCode) {
		final StringBuffer sqlString = new StringBuffer("select distinct ");
		sqlString.append("all_users_view.staff_id,");
		sqlString.append("all_users_view.title,");
		sqlString.append("all_users_view.forename1,");
		sqlString.append("all_users_view.surname,");
		sqlString.append("all_users_view.job_title,");
		sqlString.append("all_users_view.emp_orgcode,");
		sqlString.append("team_codes_tbl.team_code,");
		sqlString.append("staff_access_level_tbl.access_level  ");
		sqlString.append("from ");
		sqlString
				.append("all_users_view, team_codes_tbl, staff_access_level_tbl  ");
		sqlString.append("where ");

		sqlString.append("  all_users_view.status = 'A' and ");

		sqlString
				.append("all_users_view.emp_orgcode = team_codes_tbl.org_code ");
		sqlString.append(" and ");
		sqlString
				.append("all_users_view.staff_id = staff_access_level_tbl.staff_id ");
		sqlString.append(" and ");
		sqlString.append("all_users_view.emp_orgcode = '" + orgCode + "' ");
		sqlString.append(" and ");
		sqlString.append("staff_access_level_tbl.access_level='" + accessLevel
				+ "' ");
		sqlString
				.append(" ORDER BY all_users_view.forename1 asc,all_users_view.surname asc");
		List cfsStaffList = getCurrentSession().createSQLQuery(
				sqlString.toString()).list();

		return setUserList(cfsStaffList);

	}

	/**
	 * Setting User List from the String array.
	 * 
	 * @param queryResults
	 * @return List of Users.
	 */
	private List<UserObject> setUserList(List<Object[]> queryResults) {

		if (queryResults == null) {
			return null;
		}

		List<UserObject> userList = new ArrayList<UserObject>();

		for (Object[] result : queryResults) {

			UserObject user = new UserObject();
			user.setStaffId((String) result[0]);
			user.setTitle((String) result[1]);
			user.setFirstName((String) result[2]);
			user.setLastName((String) result[3]);
			user.setJobTitle((String) result[4]);
			user.setEmployerOrgCode((String) result[5]);
			user.setTeamCode((String) result[6]);

			userList.add(user);
		}
		return userList;
	}

	@SuppressWarnings("unchecked")
	public List<String> getAllOrgsFromTeamCode(String teamCode) {
		List<String> teamCodeList = new ArrayList<String>();
		List<OrganisationTeamCode> teamCodes = new ArrayList<OrganisationTeamCode>();
		DetachedCriteria criteria = DetachedCriteria
				.forClass(OrganisationTeamCode.class);
		criteria.add(Restrictions.eq("teamCode", teamCode));
		criteria.addOrder(Order.asc("orgCode"));
		teamCodes = criteria.getExecutableCriteria(getCurrentSession()).list();
		if (teamCodes != null && !teamCodes.isEmpty()) {
			for (OrganisationTeamCode teamOrg : teamCodes) {
				teamCodeList.add(teamOrg.getOrgCode());
			}
		}
		return teamCodeList;
	}

	public List<UserObject> loadUsersByTeamCode(String teamCode,
			String[] groupLevel) {
		List<UserObject> userList = new ArrayList<UserObject>();
		userList = listUsersByTeamCodeAndGroups(teamCode, groupLevel);
		return userList;
	}

	/**
	 * Get Users by team code and user groups.
	 * 
	 * @param teamCode
	 * @param groups
	 * @return UserObject List.
	 */
	private List<UserObject> listUsersByTeamCodeAndGroups(String teamCode,
			String[] groups) {
		final StringBuffer querySB = new StringBuffer("");
		querySB.append("SELECT distinct ");
		querySB.append("all_users_view.staff_id,");
		querySB.append("all_users_view.title,");
		querySB.append("all_users_view.forename1,");
		querySB.append("all_users_view.surname,");
		querySB.append("all_users_view.job_title,");
		querySB.append("all_users_view.emp_orgcode,");
		if (containsLCFS(groups)) {
			// to get unique staffId other wise duplicate may take place.
			querySB.append("team_orgs_tbl.team_code,");
		} else {
			querySB.append("team_codes_tbl.team_code,");
		}
		querySB.append("all_users_view.group_id,");
		querySB.append("lower(all_users_view.surname) as lsurname");
		querySB.append(" FROM all_users_view ");

		// -- added...
		if (containsLCFS(groups)) {
			querySB.append(" INNER JOIN USER_RESPONSIBILITIES_VIEW ON ");
			querySB.append(" all_users_view.staff_id = USER_RESPONSIBILITIES_VIEW.staff_id ");
			querySB.append(" LEFT OUTER JOIN team_orgs_tbl ON ");
			querySB.append(" USER_RESPONSIBILITIES_VIEW.org_code=team_orgs_tbl.org_code ");
		} else {
			querySB.append(" LEFT OUTER JOIN team_codes_tbl ON ");
			querySB.append(" all_users_view.emp_orgcode=team_codes_tbl.org_code");
		}

		querySB.append(" WHERE ");

		// common condition ..checks for active users.
		querySB.append("  all_users_view.status = 'A' and ");

		if (containsLCFS(groups)) {
			querySB.append("((USER_RESPONSIBILITIES_VIEW.start_date <= current_date) or (USER_RESPONSIBILITIES_VIEW.start_date is null))");
			querySB.append(" and ");
			querySB.append("((USER_RESPONSIBILITIES_VIEW.end_date >= current_date) or (USER_RESPONSIBILITIES_VIEW.end_date is null))");
			querySB.append(" and ");
			querySB.append("team_orgs_tbl.team_code='");
		} else {
			querySB.append("team_codes_tbl.team_code='");
		}

		querySB.append(teamCode).append("'");
		querySB.append(" AND all_users_view.group_id in ");
		querySB.append(EcmsUtils.getCommaSeperatedValues(groups));

		querySB.append(" ORDER BY forename1, lsurname ASC ");

		// System.out.println("query"+querySB.toString());
		List teamStaffList = getCurrentSession().createSQLQuery(
				querySB.toString()).list();

		return setUserList(teamStaffList);
	}

	/**
	 * Load user access list by access level,
	 * 
	 * @return List.
	 */
	public List loadUserAccessListByAccessLevel(String aclLevel) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(AccessControl.class);
		if (!aclLevel.equals(ECMSConstants.ACL_UNKNOWN)) {
			criteria.add(Restrictions.like("accessLevels", aclLevel,
					MatchMode.ANYWHERE));
		}
		return criteria.getExecutableCriteria(getCurrentSession()).list();
	}

	private boolean containsLCFS(String[] groups) {
		if (groups != null)
			for (String group : groups) {
				if (group.equals("6")) {
					return true;
				}
			}
		return false;
	}

	/**
	 * Restructure (April/2011) OFM is AFS for regional and OFM is AFL for
	 * national (NIS) and OFM is same for WARO, SOP and FPU teams.
	 **/
	public UserObject loadOFMByTeamCode(String teamCode) {

		if (EcmsUtils.isLSDSRegionalTeam(teamCode)) {
			teamCode = "Unknown";
		}

		final StringBuffer sqlString = new StringBuffer(
				"select distinct all_users_view.* ");
		sqlString.append(" from all_users_view inner join ");
		sqlString
				.append("(organisations_tbl inner join team_codes_tbl on organisations_tbl.org_code=team_codes_tbl.org_code) ");
		sqlString
				.append(" on all_users_view.emp_orgcode=organisations_tbl.org_code ");
		sqlString
				.append(" inner join staff_access_level_tbl on all_users_view.staff_id = staff_access_level_tbl.staff_id ");
		sqlString.append(" where team_codes_tbl.team_code='" + teamCode + "'");

		if (EcmsUtils.isNITTeamCode(teamCode)) {

			sqlString.append(" and staff_access_level_tbl.access_level='AFL' ");
		} else if (EcmsUtils.isTeamCodeInOFMTeams(teamCode)) {

			sqlString.append(" and staff_access_level_tbl.access_level='OFM' ");
		} else {
			sqlString.append(" and staff_access_level_tbl.access_level='AFS' ");
		}
		sqlString.append(" and all_users_view.status='A' ");

		if (ECMSConstants.IMO.equalsIgnoreCase(teamCode)) {
			final String activeStaffId = imoMessagereceiverService
					.getActiveStaffId();
			sqlString.append(" and all_users_view.staff_id='" + activeStaffId
					+ "'");

		}
		sqlString
				.append(" ORDER BY all_users_view.forename1 asc,all_users_view.surname asc");

		UserObject userObj = (UserObject) getCurrentSession()
				.createSQLQuery(sqlString.toString())
				.addEntity(UserObject.class).uniqueResult();

		/*@SuppressWarnings("unchecked")
		List<UserObject> userObj = getCurrentSession()
				.createSQLQuery(sqlString.toString())
				.addEntity(UserObject.class).list();*/

		return userObj;

	}

	@Deprecated
	public List<UserObject> loadCFSUsersByTeamCode(String teamCode) {
		final StringBuffer sqlString = new StringBuffer();
		sqlString
				.append(" select distinct all_users_view.*  from all_users_view ");
		sqlString
				.append(" inner join staff_access_level_tbl on all_users_view.staff_id = staff_access_level_tbl.staff_id ");
		sqlString
				.append(" inner join staff_teams_tbl   on staff_teams_tbl.staff_id=all_users_view.staff_id ");
		sqlString
				.append(" where staff_teams_tbl.TEAM='"
						+ teamCode
						+ "' and staff_teams_tbl.READ_WRITE='RW' and staff_teams_tbl.STATUS='A' ");
		sqlString
				.append(" and staff_access_level_tbl.access_level in ('OFM','CFS')  and all_users_view.status='A' ");
		sqlString
				.append(" ORDER BY all_users_view.forename1 asc,all_users_view.surname asc");

		List users = getCurrentSession().createSQLQuery(sqlString.toString())
				.addEntity(UserObject.class).list();

		return users;

	}

	public List<UserObject> loadCFSUsersByTeamCodes(String[] teamCodes) {

		final StringBuffer sqlString = new StringBuffer();
		String teamCodeString = getTeamCodeString(teamCodes);
		sqlString
				.append(" select distinct all_users_view.*  from all_users_view ");
		sqlString
				.append(" inner join staff_access_level_tbl on all_users_view.staff_id = staff_access_level_tbl.staff_id ");
		sqlString
				.append(" inner join staff_teams_tbl   on staff_teams_tbl.staff_id=all_users_view.staff_id ");
		sqlString
				.append(" where staff_teams_tbl.TEAM in "
						+ teamCodeString
						+ " and staff_teams_tbl.READ_WRITE='RW' and staff_teams_tbl.STATUS='A' ");
		sqlString
				.append(" and staff_access_level_tbl.access_level in ('OFM','CFS', 'AFS')  and all_users_view.status='A' ");
		sqlString
				.append(" ORDER BY all_users_view.forename1 asc,all_users_view.surname asc");

		List users = getCurrentSession().createSQLQuery(sqlString.toString())
				.addEntity(UserObject.class).list();

		return users;

	}

	public List loadLcfsStaffByTeamCodes(String[] teamCodes) {

		String teamCodeString = getTeamCodeString(teamCodes);

		final StringBuffer sql = new StringBuffer("select ");
		sql.append("distinct lcfs_staff_tbl.staff_id,");
		sql.append("lcfs_staff_tbl.title,");
		sql.append("lcfs_staff_tbl.forename1,");
		sql.append("lcfs_staff_tbl.surname,");
		sql.append("lcfs_staff_tbl.job_title,");
		sql.append("lcfs_staff_tbl.emp_orgcode,");
		sql.append("team_orgs_tbl.team_code ");
		sql.append("from lcfs_staff_tbl");
		sql.append(" inner join lcfs_responsibilities_tbl on lcfs_staff_tbl.staff_id = lcfs_responsibilities_tbl.staff_id");
		sql.append(" inner join team_orgs_tbl on lcfs_responsibilities_tbl.org_code = team_orgs_tbl.org_code ");
		sql.append(" where team_orgs_tbl.team_code in  ");
		sql.append(teamCodeString);
		sql.append("and lcfs_responsibilities_tbl.start_date <= current_date and ");
		sql.append("( lcfs_responsibilities_tbl.end_date >= current_date  or lcfs_responsibilities_tbl.end_date is null ) ");

		List lcfsStaffList = getCurrentSession().createSQLQuery(sql.toString())
				.list();

		return setUserList(lcfsStaffList);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * uk.nhs.cfsms.ecms.dao.UserDetailsDao#getUserNamePassword(java.lang.String
	 * )
	 * 
	 * Method to retrieve user name, password and enabled flag based on userId
	 */
	public Users getUserNamePassword(String userId) {
		Users user = (Users) getCurrentSession().get(Users.class, userId);
		return user;
	}

	public String getTeamCodeString(String[] teamCode) {
		StringBuffer str = new StringBuffer();
		str.append("(");
		int i = 0;
		for (String str1 : teamCode) {
			if (i != 0)
				str.append(",");
			str.append("'" + str1 + "'");
			i++;
		}
		str.append(")");

		return str.toString();
	}

	/*
	 * NEW RESTRUCTURE CFSMS to NHS PROTECT, CHANGE IN TEAMS EFFECTS FROM 31
	 * MARCH 2011
	 */

	@SuppressWarnings("unchecked")
	public List<String> getAllOrgsFromNewTeamCode(String teamCode) {

		final StringBuffer sqlString = new StringBuffer();
		sqlString
				.append(" select distinct team_org_tbl.org_code from team_orgs_tbl ");
		sqlString
				.append(" inner join team_codes_tbl on team_orgs_tbl.team_code = team_codes_tbl.team_code ");
		sqlString.append(" where team_codes_tbl.team_code in (");
		sqlString
				.append(" select team_code from team_codes_tbl where status='A' and new_team_code = '");
		sqlString.append(teamCode);
		sqlString.append("') order by team_org_tbl.org_code");
		return getCurrentSession().createSQLQuery(sqlString.toString()).list();
	}

	public List<UserObject> loadUsersByNewTeamCode(String teamCode,
			String[] groupLevel) {

		List<UserObject> userList = new ArrayList<UserObject>();
		userList = loadUsersByNewTeamCodeAndGroups(teamCode, groupLevel);
		return userList;
	}

	@SuppressWarnings("unchecked")
	public List<UserObject> loadUsersByNewTeamCodeAndGroups(String teamCode,
			String[] groups) {

		final StringBuffer querySB = new StringBuffer("");

		querySB.append("SELECT distinct all_users_view.staff_id,");
		querySB.append("all_users_view.title,all_users_view.forename1,");
		querySB.append("all_users_view.surname,all_users_view.job_title,");
		querySB.append("all_users_view.emp_orgcode,");
		if (containsLCFS(groups)) {
			// to get unique staffId other wise duplicate may take place.
			querySB.append("team_orgs_tbl.team_code,");
		} else {
			querySB.append("team_codes_tbl.team_code,");
		}
		querySB.append("all_users_view.group_id,");
		querySB.append("lower(all_users_view.surname) as lsurname");
		querySB.append(" FROM all_users_view ");

		// -- added...
		if (containsLCFS(groups)) {
			querySB.append(" INNER JOIN USER_RESPONSIBILITIES_VIEW ON ");
			querySB.append(" all_users_view.staff_id = USER_RESPONSIBILITIES_VIEW.staff_id ");
			querySB.append(" LEFT OUTER JOIN team_orgs_tbl ON ");
			querySB.append(" USER_RESPONSIBILITIES_VIEW.org_code=team_orgs_tbl.org_code ");
		} else {
			querySB.append(" LEFT OUTER JOIN team_codes_tbl ON ");
			querySB.append(" all_users_view.emp_orgcode=team_codes_tbl.org_code");
		}

		querySB.append(" WHERE ");

		// common condition ..checks for active users.
		querySB.append("  all_users_view.status = 'A' and ");

		if (containsLCFS(groups)) {
			querySB.append("((USER_RESPONSIBILITIES_VIEW.start_date <= current_date) or (USER_RESPONSIBILITIES_VIEW.start_date is null))");
			querySB.append(" and ");
			querySB.append("((USER_RESPONSIBILITIES_VIEW.end_date >= current_date) or (USER_RESPONSIBILITIES_VIEW.end_date is null))");
			querySB.append(" and ");
			querySB.append("team_orgs_tbl.team_code='");
		} else {
			querySB.append("team_codes_tbl.team_code='");
		}

		querySB.append(teamCode).append("'");
		querySB.append(" AND all_users_view.group_id in ");
		querySB.append(EcmsUtils.getCommaSeperatedValues(groups));

		querySB.append("  ORDER BY forename1, lsurname ASC ");

		// System.out.println("query"+querySB.toString());
		Query query = getCurrentSession().createSQLQuery(querySB.toString());

		return setUserList(query != null ? query.list() : null);
	}

	/**
	 * OFM = AFL in the structure.
	 */
	public UserObject loadOFMByNewTeamCode(String teamCode) {

		final StringBuffer sqlString = new StringBuffer(
				"select distinct all_users_view.* ");
		sqlString.append(" from all_users_view inner join ");
		sqlString
				.append("(organisations_tbl inner join team_codes_tbl on organisations_tbl.org_code=team_codes_tbl.org_code) ");
		sqlString
				.append(" on all_users_view.emp_orgcode=organisations_tbl.org_code ");
		sqlString
				.append(" inner join staff_access_level_tbl on all_users_view.staff_id = staff_access_level_tbl.staff_id ");
		sqlString.append(" where team_codes_tbl.team_code in (");
		sqlString
				.append(" select team_code from team_codes_tbl where status='A' and new_team_code ='");
		sqlString.append(teamCode);
		sqlString.append("') and staff_access_level_tbl.access_level='AFL' ");
		sqlString.append(" and all_users_view.status='A' ");
		sqlString
				.append(" ORDER BY all_users_view.forename1 asc,all_users_view.surname asc");

		Object userObj = getCurrentSession()
				.createSQLQuery(sqlString.toString())
				.addEntity(UserObject.class).uniqueResult();

		if (userObj != null) {
			return (UserObject) userObj;
		}

		return null;
	}

	/**
	 * CFS users , <CFS under AFL> and new area team is AFS
	 * 
	 */
	public List<UserObject> loadCFSUsersByNewTeamCode(String teamCode) {

		final StringBuffer sqlString = new StringBuffer();
		sqlString
				.append(" select distinct all_users_view.*  from all_users_view ");
		sqlString
				.append(" inner join staff_access_level_tbl on all_users_view.staff_id = staff_access_level_tbl.staff_id ");
		sqlString
				.append(" inner join staff_teams_tbl   on staff_teams_tbl.staff_id=all_users_view.staff_id ");
		sqlString
				.append(" where staff_teams_tbl.TEAM='"
						+ teamCode
						+ "' and staff_teams_tbl.READ_WRITE='RW' and staff_teams_tbl.STATUS='A' ");
		sqlString.append(" and staff_access_level_tbl.access_level in (");

		if (EcmsUtils.isNITTeamCode(teamCode)) {
			sqlString.append(" 'AFL','CFS'");
		} else if (EcmsUtils.isSOPOrWAROTeamCode(teamCode)) {
			sqlString.append(" 'AFS','OFM'");
		} else {
			sqlString.append(" 'AFS' ");
		}
		sqlString.append(" ) and all_users_view.status='A' ");
		sqlString
				.append(" ORDER BY all_users_view.forename1 asc,all_users_view.surname asc");
		List users = getCurrentSession().createSQLQuery(sqlString.toString())
				.addEntity(UserObject.class).list();

		return users;

	}

	/**
	 * New team codes (NITN & NITS) .
	 * 
	 * @param teamCodes
	 * @return List of Users.
	 */
	public List<UserObject> loadCFSUsersByNewTeamCodes(String[] teamCodes) {

		String teamCodeString = getTeamCodeString(teamCodes);

		String accessLevels = "'CFS'";

		if (EcmsUtils.isNITTeamCode(teamCodes)) {

			accessLevels = " 'AFL','CFS'";
		} else if (!EcmsUtils.isNITTeamCode(teamCodes)
				&& (EcmsUtils.isSOPOrWAROTeamCode(teamCodes) || EcmsUtils
						.isDHAFUTeamCode(teamCodes))) {

			accessLevels = " 'AFS','OFM'";
		} else if (!EcmsUtils.isNITTeamCode(teamCodes)) {

			// System.out.println("Access Level defaults to 'CFS'.");
		}

		final StringBuffer sqlString = new StringBuffer();
		sqlString
				.append(" SELECT distinct all_users_view.*  FROM all_users_view ")
				.append(" INNER JOIN staff_access_level_tbl ON all_users_view.staff_id = staff_access_level_tbl.staff_id ")
				.append(" INNER JOIN staff_teams_tbl ON staff_teams_tbl.staff_id=all_users_view.staff_id ")
				.append(" WHERE staff_teams_tbl.TEAM in (SELECT team_code FROM team_codes_tbl WHERE status='A' AND new_team_code IN ")
				.append(teamCodeString)
				.append(" ) AND staff_teams_tbl.READ_WRITE='RW' AND staff_teams_tbl.STATUS='A' ")
				.append(" AND staff_access_level_tbl.access_level in (")
				.append(accessLevels)
				.append(" ) AND all_users_view.status='A'")
				.append(" ORDER BY all_users_view.forename1 asc,all_users_view.surname asc");

		List users = getCurrentSession().createSQLQuery(sqlString.toString())
				.addEntity(UserObject.class).list();

		return users;
	}

	public List<UserObject> loadLcfsStaffByNewTeamCodes(String[] teamCodes) {

		final StringBuffer sql = new StringBuffer();

		String teamCodeString = getTeamCodeString(teamCodes);
		sql.append("SELECT DISTINCT lcfs_staff_tbl.staff_id,");
		sql.append("lcfs_staff_tbl.title,lcfs_staff_tbl.forename1,");
		sql.append("lcfs_staff_tbl.surname,lcfs_staff_tbl.job_title,");
		sql.append("lcfs_staff_tbl.emp_orgcode,team_orgs_tbl.team_code ");
		sql.append(" FROM lcfs_staff_tbl INNER JOIN lcfs_responsibilities_tbl ON ");
		sql.append(" lcfs_staff_tbl.staff_id = lcfs_responsibilities_tbl.staff_id");
		sql.append(" INNER JOIN team_orgs_tbl ON ");
		sql.append(" lcfs_responsibilities_tbl.org_code = team_orgs_tbl.org_code ");
		sql.append(" WHERE team_orgs_tbl.team_code IN  ");
		sql.append(" (SELECT team_code FROM team_codes_tbl WHERE status='A' AND ");
		if (EcmsUtils.isNITTeamCode(teamCodes)) {
			sql.append(" team_code IN ");
		} else {
			sql.append(" new_team_code IN ");
		}
		sql.append(teamCodeString);
		sql.append(" ) AND lcfs_responsibilities_tbl.start_date <= current_date AND ");
		sql.append("( lcfs_responsibilities_tbl.end_date >= current_date OR ");
		sql.append(" lcfs_responsibilities_tbl.end_date is null ) ");

		List lcfsStaffList = getCurrentSession().createSQLQuery(sql.toString())
				.list();

		return setUserList(lcfsStaffList);
	}

	public List<UserObject> loadLcfsStaffByCaseNewTeamCodeByCaseId(Long caseId) {

		final StringBuffer sql = new StringBuffer("select ");
		sql.append("distinct lcfs_staff_tbl.staff_id,");
		sql.append("lcfs_staff_tbl.title, lcfs_staff_tbl.forename1,");
		sql.append("lcfs_staff_tbl.surname,lcfs_staff_tbl.job_title,");
		sql.append("lcfs_staff_tbl.emp_orgcode,team_orgs_tbl.team_code ");
		sql.append("from lcfs_staff_tbl inner join lcfs_responsibilities_tbl");
		sql.append(" on lcfs_staff_tbl.staff_id = lcfs_responsibilities_tbl.staff_id");
		sql.append(" inner join team_orgs_tbl on ");
		sql.append(" lcfs_responsibilities_tbl.org_code = team_orgs_tbl.org_code ");
		sql.append(" where team_orgs_tbl.team_code in ");
		// Extra for new Team code
		sql.append("(select team_code from team_codes_tbl where status='A' and new_team_code in (");
		sql.append("(select team_code from case_tbl where case_id = '");
		sql.append(caseId);
		sql.append("' and restrict_to ='CFS_LOC'))");
		sql.append(" and lcfs_responsibilities_tbl.start_date <= current_date");
		sql.append(" and (lcfs_responsibilities_tbl.end_date >= current_date ");
		sql.append(" or lcfs_responsibilities_tbl.end_date is null ) ");

		List lcfsStaffList = getCurrentSession().createSQLQuery(sql.toString())
				.list();

		return setUserList(lcfsStaffList);

	}

	public UserObject loadAFLByTeamCode(String teamCode) {

		return loadOFMByNewTeamCode(teamCode);

	}

	@Override
	public UserHistory loadUserHistory(String staffId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(UserHistory.class);
		criteria.add(Restrictions.eq("staffId", staffId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (UserHistory) list.get(0);
		}

		return null;
	}

	@Override
	public void createUserHistory(UserHistory history) {

		getCurrentSession().merge(history);
	}

	@Override
	public void updateUserHistory(UserHistory history) {

		getCurrentSession().merge(history);
	}

	@Override
	public UserPreference loadUserPrefereces(String staffId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(UserPreference.class);
		criteria.add(Restrictions.eq("staffId", staffId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		if (null != list && !list.isEmpty()) {
			return (UserPreference) list.get(0);
		}

		return null;
	}

	@Override
	public void updateUserPreferences(UserPreference preference) {

		UserPreference currentPref = null;

		if (null != preference && null != preference.getStaffId()) {

			currentPref = loadUserPrefereces(preference.getStaffId());
		}
		if (null != currentPref) {

			currentPref.setFontSize(preference.getFontSize());
			currentPref.setModifiedTime(new Date());
		} else {

			currentPref = preference;
		}
		getCurrentSession().merge(currentPref);
	}

	public List<String> searchUsers(String userSearchPattern) {

		ArrayList<String> userList = null;

		DetachedCriteria criteria = DetachedCriteria.forClass(UserObject.class);
		criteria.add(
				Restrictions.ilike("firstName", userSearchPattern,
						MatchMode.START)).addOrder(Order.asc("firstName"));

		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		List<UserObject> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		userList = new ArrayList<String>();
		if (!list.isEmpty()) {
			for (UserObject user : list) {
				userList.add(user.getFirstName() + " " + user.getLastName()
						+ "-" + user.getStaffId());
			}
		} else {
			userList.add("Invalid User-0");
		}

		return userList;
	}

	public List<String> searchUsers(String userSearchPattern, SessionUser user,
			String caseId) {

		List<String> userList = null;
		String[] userTeamCodes = null;

		try {
			userTeamCodes = CaseUtil.getTeamCodesFromResponsibilities(user
					.getUserResponsibilities());

		} catch (ListEmptyException e) {
			// TODO
		}
		String caseOrg = null;
		if (!user.isUserLCFS()) {
			Case caseEntity = (Case) getCurrentSession().get(Case.class,
					new Long(caseId));
			if (StringUtils.isNotBlank(caseEntity.getRestrictTo())) {
				caseOrg = caseEntity.getOrgCode();
			}
		}
		if (StringUtils.isNotBlank(caseOrg)) {
			List<String> fixedList = Arrays.asList(userTeamCodes);
			List<String> teamCodes = new ArrayList<String>();
			teamCodes.addAll(fixedList);
			teamCodes.add(caseOrg);
			userTeamCodes = teamCodes.toArray(new String[teamCodes.size()]);

		}
		List<UserObject> list = this.loadUsersByTeamCodes(userTeamCodes,
				userSearchPattern);
		userList = new ArrayList<String>();
		if (!list.isEmpty()) {
			for (UserObject user1 : list) {
				userList.add(user1.getFirstName() + " " + user1.getLastName()
						+ "-" + user1.getStaffId());
			}
		} else {
			userList.add("No User Found-0");
		}

		return userList;
	}

	@SuppressWarnings("rawtypes")
	public List<UserObject> loadUsersByTeamCodes(String[] teamCodes,
			String keyword) {

		final StringBuffer sqlString = new StringBuffer();
		String teamCodeString = getTeamCodeString(teamCodes);

		final boolean isIMOTeam = Arrays.asList(teamCodes).contains(
				ECMSConstants.IMO);

		sqlString.append("select distinct all_users_view.* ");
		sqlString
				.append(" from all_users_view  left outer join staff_access_level_tbl on "
						+ "all_users_view.staff_id = staff_access_level_tbl.staff_id ");
		sqlString
				.append(" left outer join USER_RESPONSIBILITIES_VIEW on USER_RESPONSIBILITIES_VIEW.staff_id=all_users_view.staff_id "
						+ "where USER_RESPONSIBILITIES_VIEW.ORG_CODE in ");
		sqlString.append(teamCodeString);
		if (isIMOTeam) {
			sqlString.append(" and all_users_view.EMP_ORGCODE !='"
					+ ECMSConstants.TEAM_FCO + "'");
		}
		
		/*sqlString.append(" and (lower(all_users_view.forename1) like '%"
				+ StringUtils.lowerCase(keyword) + "%' ");
		sqlString.append(" or lower(all_users_view.surname) like '%"
				+ StringUtils.lowerCase(keyword) + "%' )");*/
		sqlString
				.append("  and (staff_access_level_tbl.access_level in ('AFL', 'OFM','CFS', 'AFS', 'AAFS') or "
						+ "USER_RESPONSIBILITIES_VIEW.staff_id like 'lcfs%')  and all_users_view.status='A'");
		sqlString
				.append(" ORDER BY all_users_view.forename1 asc,all_users_view.surname asc");
		List users = getCurrentSession().createSQLQuery(sqlString.toString())
				.addEntity(UserObject.class).list();

		return users;
	}

	@Override
	public List<UserObject> loadNewLCFSByCaseOrgCode(Long caseId,
			List<String> currentAssignees) {

		final StringBuffer sql = new StringBuffer("");
		sql.append("select distinct lcfs_staff_tbl.staff_id,");
		sql.append("lcfs_staff_tbl.title, lcfs_staff_tbl.forename1,");
		sql.append("lcfs_staff_tbl.surname,lcfs_staff_tbl.job_title,");
		sql.append("lcfs_staff_tbl.emp_orgcode,team_orgs_tbl.team_code ");
		sql.append("from lcfs_staff_tbl inner join lcfs_responsibilities_tbl");
		sql.append(" on lcfs_staff_tbl.staff_id = lcfs_responsibilities_tbl.staff_id");
		sql.append(" inner join team_orgs_tbl on ");
		sql.append(" lcfs_responsibilities_tbl.org_code = team_orgs_tbl.org_code ");
		sql.append(" where team_orgs_tbl.org_code = ");
		sql.append("(select org_code from case_tbl where case_id = ").append(
				caseId);
		sql.append(" and restrict_to ='CFS_LOC')");
		sql.append(" and lcfs_responsibilities_tbl.start_date <= current_date");
		sql.append(" and (lcfs_responsibilities_tbl.end_date >= current_date");
		sql.append(" or lcfs_responsibilities_tbl.end_date is null ) ");
		sql.append(" and (lcfs_responsibilities_tbl.lead = 'N' ");
		sql.append(" or lcfs_responsibilities_tbl.lead is null) ");
		sql.append(" and lcfs_staff_tbl.staff_id not in ");
		sql.append(EcmsUtils.getCommaSeperatedValues(currentAssignees
				.toArray(new String[currentAssignees.size()])));
		List lcfsStaffList = getCurrentSession().createSQLQuery(sql.toString())
				.list();

		return setUserList(lcfsStaffList);
	}

	@Override
	public List<UserObject> loadIMOTeam(final String empOrgCode) {
		final Criteria casePermissionCriteria = getCurrentSession()
				.createCriteria(UserObject.class);
		casePermissionCriteria.add(Restrictions.eq("employerOrgCode",
				empOrgCode));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("staffId"), "staffId");
		projectionList.add(Projections.property("title"), "title");
		projectionList.add(Projections.property("firstName"), "firstName");
		projectionList.add(Projections.property("lastName"), "lastName");

		casePermissionCriteria.setProjection(projectionList);
		casePermissionCriteria.setResultTransformer(Transformers
				.aliasToBean(UserObject.class));

		@SuppressWarnings("unchecked")
		final List<UserObject> list = casePermissionCriteria.list();
		return list;
	}

}
