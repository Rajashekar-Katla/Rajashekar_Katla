package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.CriminalAppealDao;
import uk.nhs.cfsms.ecms.data.sanction.AppealOutcome;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppeal;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppealView;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.PoliceCharge;

@Repository
public class HibernateCriminalAppealDao extends HibernateBaseDao implements CriminalAppealDao {

	public List<CriminalAppealView> loadCriminalAppealsByCaseId(Long caseId) {
		 
		Session session = getCurrentSession();
		
		Query query = session.createQuery("from CriminalAppealView where caseId =:caseId order by appearedDate desc")
				.setLong("caseId", caseId);
		
		List<CriminalAppealView> list = query.list(); 
		
		return list;			
		
	}

	public CriminalAppealView loadCriminalAppealView(Long appealId) {
		
		Session session = getCurrentSession();
		
		Query query = session.createQuery("from CriminalAppealView where appealId =:appealId")
				.setLong("appealId", appealId);
		
		List list = query.list(); 
		
		if (null != list && !list.isEmpty()) {
			
			return (CriminalAppealView)list.get(0);
		}
		return null;
		
	} 
	

	@SuppressWarnings("unchecked")
	public List<PoliceCharge> loadPoliceCharge(Long sanctionId) {
		 
		Session session = getCurrentSession();
		
		Query query = session.createQuery("from PoliceCharge where sanctionId =:sanctionId")
				.setLong("sanctionId", sanctionId);
		
		return query.list(); 
	 
	}

	public PoliceCharge savePoliceCharge(PoliceCharge charge) {
		 
		return (PoliceCharge) getCurrentSession().merge(charge);
	}

	@SuppressWarnings("unchecked")
	public List<AppealOutcome> loadCriminalAppealsOutcome(Long appealId) {
 
		Session session = getCurrentSession();
		
		Query query = session.createQuery("from AppealOutcome where appealId =:appealId")
				.setLong("appealId", appealId);
		
		return query.list(); 
	}

	
	public AppealOutcome saveCriminalAppealOutcome(final AppealOutcome outcome) {
		
		Session session = getCurrentSession();
		
		session.saveOrUpdate(outcome);
		
		// As DELETE_ORPHANS is not working, has to do it manual. 
		
/*		DetachedCriteria criteria = DetachedCriteria.forClass(OutcomeAppliedSanction.class);
		criteria.add(Expression.isNull("outcomeId")); 
		
		List list = criteria.getExecutableCriteria(session).list();
*/
		
		Query query = session.createQuery("from OutcomeAppliedSanction where outcomeId is null");
		
		List list = query.list(); 
		
		if (null != list && !list.isEmpty()) {
			
			for (Object curr : list) { 
				
				session.delete(curr);
			}
		}
		
		return outcome;
	}

	@Override
	public List<CriminalSanctionOutcome> loadCriminalSanctionOutcome(Long sanctionId) {

		Session session = getCurrentSession();
		
		Query query = session.createQuery("from CriminalSanctionOutcome where criminalSanctionId = :criminalSanctionId").
				setLong("criminalSanctionId", sanctionId);
		
		return query.list();  
	}

	@Override
	public CriminalAppeal loadCriminalAppeal(Long appealId) {

		Session session = getCurrentSession();
		
		Query query = session.createQuery("from CriminalAppeal where appealId = :appealId").
				setLong("appealId", appealId);
		
		List list = query.list();
		
		if (!list.isEmpty()) {
			return (CriminalAppeal)list.get(0);
		}
			
		return null;
	}

	@Override
	public List<CriminalAppeal> loadAppealsByParentSanctionId(Long sanctionId) { 
	
		Session session = getCurrentSession();
		
		Query query = session.createQuery("from CriminalAppeal where sanctionId =:sanctionId")
				.setLong("sanctionId", sanctionId);
		
		return query.list();  
		
	}

	@Override
	public List<CriminalAppeal> loadAppealsByParentAppealId(Long appealId) {

		Session session = getCurrentSession();
		
		Query query = session.createQuery("from CriminalAppeal where parentAppealId =:appealId")
				.setLong("appealId", appealId);
		
		return query.list();  
		
	}

}
