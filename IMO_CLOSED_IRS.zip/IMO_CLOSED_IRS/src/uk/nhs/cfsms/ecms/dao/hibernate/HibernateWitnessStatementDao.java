package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.WitnessStatementDao;
import uk.nhs.cfsms.ecms.data.infoGath.PersonContacts;
import uk.nhs.cfsms.ecms.data.witness.WitnessStatement;
import uk.nhs.cfsms.ecms.dto.witness.WitnessStatementTO;
import uk.nhs.cfsms.ecms.dto.witness.WitnessTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileExtensions;
import uk.nhs.cfsms.ecms.utility.EcmsUtils.FileTypes;

@Repository
public class HibernateWitnessStatementDao extends HibernateBaseDao implements
		WitnessStatementDao {

	/**
	 * This method is being used to list out witness statements for CPS document
	 * listing.
	 * */
	public List<WitnessStatementTO> loadCPSWitnesseStatementsByCaseID(
			Long caseId, String type) {

		StringBuilder hsql = new StringBuilder("");
		hsql.append("select witness.witnessId,witness.caseId,");
		hsql.append(" witness.state,stmt.statementId, ");
		hsql.append(" stmt.statementFileType,stmt.fileName ");
		hsql.append(" from Witness witness,WitnessStatement stmt ");
		hsql.append(" where stmt.witness.witnessId=witness.witnessId ");
		hsql.append(" and stmt.isUploadedStatment='").append(type).append("'");
		hsql.append(" and witness.caseId='").append(caseId).append("'");
		hsql.append(" and stmt.statementFile IS NOT NULL and stmt.fileName IS NOT NULL");

		@SuppressWarnings("unchecked")
		List<Object[]> queryResults = getCurrentSession().createQuery(
				hsql.toString()).list();
		List<WitnessStatementTO> statementList = setCPSWitnessStatementList(queryResults);

		return statementList;

	}

	@Override
	public Long getWitnessStatementFileSize(final long witnessStatementId) {

		final String sql = "select (DBMS_LOB.GETLENGTH(STATEMENT_FILE)) AS SIZE_MB from WITNESS_STATEMENT_TBL where STATEMENT_ID=:id";

		final SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("id", witnessStatementId);

		@SuppressWarnings("unchecked")
		final List<Long> results = query.list();

		final long value = Long.parseLong(results.get(0)+"");

		return value;
	}
	
	/**
	 * TODO Refine for CPS document listing Supporting bean mapping method for
	 * the witness statement reporting. This method is being used to list out
	 * witness statements for CPS document listing.
	 * */
	public List<WitnessStatementTO> setCPSWitnessStatementList(
			List<Object[]> queryResults) {
		List<WitnessStatementTO> statementList = new ArrayList<WitnessStatementTO>();

		for (Object[] result : queryResults) {
			WitnessStatementTO stmt = new WitnessStatementTO();
			stmt.setWitness(new WitnessTO());
			stmt.getWitness().setWitnessId((Long) result[0]);
			stmt.getWitness().setCaseId((Long) result[1]);
			// stmt.getWitness().getPerson().setPersonId((Long) result[2]);
			// stmt.getWitness().getPerson().setTitle((String) result[3]);
			// stmt.getWitness().getPerson().setFirstName((String) result[4]);
			// stmt.getWitness().getPerson().setLastName((String) result[5]);
			// stmt.getWitness().getPerson().setGender((String) result[6]);
			// stmt.getWitness().getPerson().setOtherTitle((String) result[10]);
			// List<PersonContacts> contacts = new ArrayList<PersonContacts>();
			// stmt.getWitness().getPerson().setContactsList(contacts);

			stmt.getWitness().setState((String) result[2]);
			stmt.setStatementId((Long) result[3]);
			stmt.setStatementFileType((String) result[4]);
			stmt.setFileName((String) result[5]);
			statementList.add(stmt);

		}

		return statementList;

	}

	public List loadWitnesseStatementsByCaseId(Long caseId, int partNumber, String type) {

		StringBuilder hsql = new StringBuilder("");
		hsql.append("select witness.witnessId,witness.caseId,");
		hsql.append(" witness.person.personId,witness.person.title,");
		hsql.append(" witness.person.firstName,witness.person.lastName,");
		hsql.append(" witness.person.gender, "); // ,elements(witness.person.contactsList),");
		hsql.append(" witness.state,stmt.statementId,stmt.createdTime, witness.person.otherTitle ");
		hsql.append(" from Witness witness,WitnessStatement stmt ");
		hsql.append(" where stmt.witness.witnessId=witness.witnessId ");
		hsql.append(" and stmt.isUploadedStatment='").append(type).append("'");
		hsql.append(" and witness.caseId='").append(caseId).append("'");
		hsql.append(" and stmt.partNumber=").append(partNumber);
		hsql.append(" order by stmt.createdTime asc");

		List<Object[]> queryResults = getCurrentSession().createQuery(
				hsql.toString()).list();
		List<WitnessStatementTO> statementList = setWitnessStatementList(queryResults);

		return statementList;

	}

	public List loadWitnesseStatementsByWitnessId(Long statementId) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(WitnessStatement.class);
		criteria.add(Restrictions.eq("statementId", statementId));
		List witnesses = criteria.getExecutableCriteria(getCurrentSession())
				.list();
		return witnesses;

	}

	@Override
	public List loadStatementsByWitnessIdAndType(Long witnessId,int partNumber, String type) {

		StringBuilder hsql = new StringBuilder("");
		hsql.append("select witness.witnessId,witness.caseId,");
		hsql.append(" witness.person.personId,witness.person.title,");
		hsql.append(" witness.person.firstName,witness.person.lastName,");
		hsql.append(" witness.person.gender, "); // ,elements(witness.person.contactsList),");
		hsql.append(" witness.state,stmt.statementId,stmt.createdTime, witness.person.otherTitle ");
		hsql.append(" from Witness witness,WitnessStatement stmt ");
		hsql.append(" where stmt.witness.witnessId=witness.witnessId ");
		hsql.append(" and stmt.isUploadedStatment='").append(type).append("'");
		hsql.append(" and witness.witnessId='").append(witnessId).append("'");
		hsql.append(" and stmt.partNumber=").append(partNumber);
		hsql.append(" order by stmt.createdTime DESC");

		List<Object[]> queryResults = getCurrentSession().createQuery(
				hsql.toString()).list();
		List<WitnessStatementTO> statementList = setWitnessStatementList(queryResults);

		return statementList;

	}

	public WitnessStatement loadWitnessStatementById(Long witnessStatementId) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(WitnessStatement.class);
		criteria.add(Restrictions.eq("statementId", witnessStatementId));
		List statements = criteria.getExecutableCriteria(getCurrentSession())
				.list();

		if (null != statements && !statements.isEmpty()) {
			return (WitnessStatement) statements.get(0);
		}

		return null;

	}

	public WitnessStatement downloadWitnessStatementById(
			final Long witnessStatementId, final boolean isFileBlobRequired) {

		WitnessStatement witnessStatement = null;

		final Criteria criteria = getCurrentSession().createCriteria(
				WitnessStatement.class);
		criteria.add(Restrictions.eq("statementId", witnessStatementId));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("fileName"), "fileName");
		projectionList.add(Projections.property("statementFileType"),
				"statementFileType");
		projectionList.add(Projections.property("statementId"), "statementId");

		if (isFileBlobRequired) {
			projectionList.add(Projections.property("statementFile"),
					"statementFile");
		}

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers
				.aliasToBean(WitnessStatement.class));

		@SuppressWarnings("unchecked")
		final List<WitnessStatement> list = criteria.list();

		if (!list.isEmpty()) {
			witnessStatement = list.get(0);
		}

		return witnessStatement;

	}

	public WitnessStatement saveWitnessStatement(WitnessStatement statement) {
		statement.setUpdatedFlag("Y");
		return (WitnessStatement) getCurrentSession().merge(statement);
	}

	public WitnessStatement updateWitnessStatement(WitnessStatement statement) {
		statement.setUpdatedFlag("Y");
		getCurrentSession().update(statement);

		return statement;
	}

	public WitnessStatement updateWitnessStatementFileName(
			final Long witnessStatementId, String fileName) {

		WitnessStatement witnessStatement = null;

		DetachedCriteria criteria = DetachedCriteria
				.forClass(WitnessStatement.class);
		criteria.add(Restrictions.eq("statementId", witnessStatementId));

		@SuppressWarnings("unchecked")
		List<WitnessStatement> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		if (list != null && !list.isEmpty()) {
			witnessStatement = list.get(0);
			final String dbFileName = witnessStatement.getFileName();
			final String dbFileExt = witnessStatement.getStatementFileType();

			if (null != dbFileName) {
				String extension = FilenameUtils.getExtension(dbFileName);
				if (extension.isEmpty() && null != dbFileExt
						&& !dbFileExt.isEmpty()) {
					if (FileExtensions
							.isValidExtension(dbFileExt.toLowerCase())) {
						final String fullFileName = dbFileName + "."
								+ dbFileExt;
						if (!fileName.equals(fullFileName)) {
							witnessStatement.setUpdatedFlag("Y");
							witnessStatement.setFileName(fileName);
							getCurrentSession().update(witnessStatement);
							return witnessStatement;
						}
					} else {
						final FileTypes fileTypes = FileTypes
								.getExtention(dbFileExt.toLowerCase());
						if (fileTypes != null) {
							final String ext = fileTypes.toString();
							final String fullFileName = dbFileName + "." + ext;
							if (!fileName.equals(fullFileName)) {
								witnessStatement.setUpdatedFlag("Y");
								witnessStatement.setFileName(fileName);
								getCurrentSession().update(witnessStatement);
								return witnessStatement;
							}
						}
					}

				} else if (!extension.isEmpty() && !dbFileName.equals(fileName)) {
					witnessStatement.setUpdatedFlag("Y");
					witnessStatement.setFileName(fileName);
					getCurrentSession().update(witnessStatement);
					return witnessStatement;
				} else if (extension.isEmpty()
						&& (null == dbFileExt || dbFileExt.isEmpty())) {
					if (!dbFileName.isEmpty()) {
						extension = FilenameUtils.getExtension(fileName);
						if (FileExtensions.isValidExtension(extension
								.toLowerCase())) {
							fileName = fileName.substring(0,
									fileName.indexOf("." + extension));
							if (!dbFileName.equals(fileName)) {
								witnessStatement.setUpdatedFlag("Y");
								witnessStatement.setFileName(fileName);
								witnessStatement
										.setStatementFileType(extension);
								getCurrentSession().update(witnessStatement);
								return witnessStatement;
							}
						} else {
							if (!dbFileName.equals(fileName)) {
								witnessStatement.setUpdatedFlag("Y");
								witnessStatement.setFileName(fileName);
								getCurrentSession().update(witnessStatement);
								return witnessStatement;
							}
						}

					} else {
						extension = FilenameUtils.getExtension(fileName);
						if (FileExtensions.isValidExtension(extension
								.toLowerCase())) {
							witnessStatement.setStatementFileType(extension);
						}
						witnessStatement.setUpdatedFlag("Y");
						witnessStatement.setFileName(fileName);
						getCurrentSession().update(witnessStatement);
						return witnessStatement;
					}
				}
			}
		}
		return witnessStatement;
	}

	public List<WitnessStatementTO> setWitnessStatementList(
			List<Object[]> queryResults) {

		List<WitnessStatementTO> statementList = new ArrayList<WitnessStatementTO>();

		for (Object[] result : queryResults) {

			WitnessStatementTO stmt = new WitnessStatementTO();
			stmt.setWitness(new WitnessTO());
			stmt.getWitness().setWitnessId((Long) result[0]);
			stmt.getWitness().setCaseId((Long) result[1]);
			stmt.getWitness().getPerson().setPersonId((Long) result[2]);
			stmt.getWitness().getPerson().setTitle((String) result[3]);
			stmt.getWitness().getPerson().setOtherTitle((String) result[10]);
			stmt.getWitness().getPerson().setFirstName((String) result[4]);
			stmt.getWitness().getPerson().setLastName((String) result[5]);
			stmt.getWitness().getPerson().setGender((String) result[6]);
			List<PersonContacts> contacts = new ArrayList<PersonContacts>();
			// contacts.add((PersonContacts) result[7]);
			stmt.getWitness().getPerson().setContactsList(contacts);
			// stmt.getWitness().getPerson().setHomeTel((String) result[7]);
			// stmt.getWitness().setState((String) result[8]);
			// stmt.setStatementId((Long) result[9]);
			// stmt.setCreatedTime((Date) result[10]);
			stmt.getWitness().setState((String) result[7]);
			stmt.setStatementId((Long) result[8]);
			stmt.setCreatedTime((Date) result[9]);

			statementList.add(stmt);

		}

		return statementList;

	}

	/**
	 * Delete Witness Statement based on Id.
	 */
	public void deleteWitnessStatement(Long statementId) {
		WitnessStatement statement = this.loadWitnessStatementById(statementId);
		if (statement != null) {
			getCurrentSession().delete(statement);
		}
	}

}
