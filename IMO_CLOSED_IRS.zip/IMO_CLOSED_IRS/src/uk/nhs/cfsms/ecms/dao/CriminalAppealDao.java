package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.AppealOutcome;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppeal;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppealView;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.PoliceCharge;

public interface CriminalAppealDao extends BaseDao {
	
	CriminalAppeal loadCriminalAppeal(Long appealId);
	
	CriminalAppealView loadCriminalAppealView(Long appealId);
	
	List<CriminalAppealView> loadCriminalAppealsByCaseId(Long caseId);
		
	
	List<PoliceCharge> loadPoliceCharge(Long appealId);
	
	PoliceCharge savePoliceCharge(PoliceCharge charge);

	List<AppealOutcome> loadCriminalAppealsOutcome(Long appealId);

	AppealOutcome saveCriminalAppealOutcome(AppealOutcome outcome);
	
	List<CriminalAppeal> loadAppealsByParentSanctionId(Long sanctionId);
	
	// loading sanctions not appeals.
	List<CriminalSanctionOutcome> loadCriminalSanctionOutcome(Long sanctionId);

	List<CriminalAppeal> loadAppealsByParentAppealId(Long appealId);


}
