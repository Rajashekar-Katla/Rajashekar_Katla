package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.MGForm;

public interface MGFormDao {
	
	public List<MGForm> listMGForms(Long caseId);
	
	public List<MGForm> listMGFormsForCPS(Long caseId);
	
	public void  deleteMGForm(Long mgFormId);
	
	public MGForm  saveMGForm(MGForm mgForm);
	
	public MGForm downloadMGForm(final Long mgFormId,final boolean isFileBlobRequired);
	
	public MGForm loadMGForm(Long mgFormId);
	
	public String loadRegexForDocumentType(String docType);
	
	public MGForm updateMGFormFileName(final Long mgFormId,final String fileName);
	
	public Long getMGFormFileSize(final long mgFormId);


}
