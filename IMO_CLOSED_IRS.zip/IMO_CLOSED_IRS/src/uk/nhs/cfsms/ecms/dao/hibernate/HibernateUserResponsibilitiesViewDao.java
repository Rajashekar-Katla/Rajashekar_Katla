package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.UserResponsibilitiesViewDao;
import uk.nhs.cfsms.ecms.data.common.AllUserResponsibilities;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;

@Repository
public class HibernateUserResponsibilitiesViewDao extends HibernateBaseDao
		implements UserResponsibilitiesViewDao {
 
	@SuppressWarnings("unchecked")
	public List<AllUserResponsibilities> loadResponsibilitiesById(String staffId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				AllUserResponsibilities.class).add(
				Restrictions.ilike("staffId", staffId, MatchMode.EXACT))
				.addOrder(Order.asc("staffId"));

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}

	@SuppressWarnings("unchecked")
	public List<UserDirectorate> getDirectorates(String staffID) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(UserDirectorate.class);
		criteria.add(Restrictions.eq("staffId", staffID));

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}

}
