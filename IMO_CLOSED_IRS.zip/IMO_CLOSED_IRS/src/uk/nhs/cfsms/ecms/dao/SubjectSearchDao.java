package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.SubjectNhsSearchResults;
import uk.nhs.cfsms.ecms.data.cim.SubjectNonNhsSearchResults;
import uk.nhs.cfsms.ecms.data.cim.SubjectSearchResults;
import uk.nhs.cfsms.ecms.data.cim.VehicleSearchResults;

public interface SubjectSearchDao {
	
	public List<SubjectSearchResults> searchPersonSubjects(String firstName,String lastName);
	
	public List<SubjectNhsSearchResults> searchNHSSubjects(String name);
	
	public List<SubjectNonNhsSearchResults> searchNonNHSSubjects(String name);
	
	public List<VehicleSearchResults> searchVehicles(String licenseNumber);

}
