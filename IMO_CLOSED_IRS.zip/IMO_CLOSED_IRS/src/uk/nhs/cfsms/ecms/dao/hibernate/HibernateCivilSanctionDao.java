package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.CivilSanctionDao;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppeal;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppealView;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionOutcome;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionView;

@Repository
public class HibernateCivilSanctionDao extends HibernateBaseDao implements CivilSanctionDao {
	
	public List<CivilSanctionView> loadCivilSanctions(Long caseId) {
		
		Session session = getCurrentSession();
		 
		Criteria criteria = session.createCriteria(CivilSanctionView.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		
		List<CivilSanctionView> res = criteria.list();
		
		return res;
	}
	
	public CivilSanctionOutcome loadCivilSanctionOutcome(Long civilSanctionId) {
		
		Session session = getCurrentSession();
		Criteria criteria = session.createCriteria(CivilSanctionOutcome.class);
		criteria.add(Restrictions.eq("civilSanctionId", civilSanctionId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		List list = criteria.list();
		
		if (list != null && !list.isEmpty()) {
			return (CivilSanctionOutcome) list.get(0);
		}

		return null;
		
	}
	@Override
    public List<CivilSanctionOutcome> loadCivilSanctionOutcomeForCase(Long caseID) {
		
		Session session = getCurrentSession();
		
    	Query query = session.getNamedQuery("getSanctionOutcomesForCase");
		query.setParameter("caseID", caseID);
		
		List<CivilSanctionOutcome> outcomes = query.list();
		
		return outcomes;
		
	}

	@Override
	public List<CivilAppeal> loadCivilAppeals(Long caseId) {
		
		Session session = getCurrentSession();
		 
		Criteria criteria = session.createCriteria(CivilAppeal.class);
		criteria.add(Restrictions.eq("sanction.caseId", caseId));
		
		List<CivilAppeal> res = criteria.list();
		
		return res;
		
	}

	@Override
	public List<CivilAppealView> loadAppealsByParentSanctionId(Long sanctionId) {
		
		Session session = getCurrentSession();
		 
		Query query = session.getNamedQuery("getAppealsByParentSanctionId");
		
		query.setLong("sanctionId",sanctionId);
		
		List<CivilAppealView> res = query.list();
		
		return res;
		
	}
	
}
