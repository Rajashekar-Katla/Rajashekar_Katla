package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.RegionCodeDao;
import uk.nhs.cfsms.ecms.data.common.RegionCode;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;

@Repository
public class HibernateRegionCodeDao extends HibernateBaseDao implements RegionCodeDao {

	public List<RegionCode> loadAllRegionCode() {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				RegionCode.class);
		criteria.addOrder(Order.asc("region"));

		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		return criteria.getExecutableCriteria(getCurrentSession()).list();

	}
	
	
	public List<TeamCodes> loadAllTeamCodes()
	{
		DetachedCriteria criteria = DetachedCriteria.forClass(
				TeamCodes.class);
		criteria.add(Restrictions.eq("status","A"));
		criteria.addOrder(Order.asc("teamCode"));

		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		return criteria.getExecutableCriteria(getCurrentSession()).list();

		
		
		
	}
	
	
	public List<TeamCodes> listTeamsByTeamCode(String[] teams)
	{
		
		DetachedCriteria criteria = DetachedCriteria.forClass(
				TeamCodes.class);
		
		criteria.add(Restrictions.eq("status","A"));
		criteria.add(Restrictions.in("teamCode",teams));
		
		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		return criteria.getExecutableCriteria(getCurrentSession()).list();

		
		
	}

}
