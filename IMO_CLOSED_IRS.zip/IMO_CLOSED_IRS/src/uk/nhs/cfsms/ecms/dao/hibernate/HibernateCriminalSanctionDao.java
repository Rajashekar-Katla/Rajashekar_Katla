package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.CriminalSanctionDao;
import uk.nhs.cfsms.ecms.data.sanction.CriminalAppealView;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionView;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeOrderSanction;
import uk.nhs.cfsms.ecms.data.sanction.PoliceCharge;

@Repository
public class HibernateCriminalSanctionDao extends HibernateBaseDao implements CriminalSanctionDao {


	public List<CriminalSanctionView> loadCriminalSanctions(Long caseId) {
		
		Criteria criteria = getCurrentSession().createCriteria(CriminalSanctionView.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		return criteria.list();
		
	}	

	public Object getCiminalAppealById(Class clazz, Long criminalSanctionId) {
		return getCurrentSession().createQuery("from " + clazz.getName()
                + " where criminalSanctionId = " + criminalSanctionId).list();
		/*return getHibernateTemplate().find("from " + clazz.getName()
                + " where criminalSanctionId = " + criminalSanctionId);*/
	}
	
	public List getObjects(Class clazz, Long criminalSanctionId) {
		
		Criteria criteria = getCurrentSession().createCriteria(clazz);
		criteria.add(Restrictions.eq("criminalSanctionId", criminalSanctionId));
		return criteria.list();
		 
	}

	@SuppressWarnings("unchecked")
	public List<PoliceCharge> loadPoliceCharge(Long sanctionId) {
		
		Criteria criteria = getCurrentSession().createCriteria(PoliceCharge.class);
		criteria.add(Restrictions.eq("sanctionId", sanctionId));
		return criteria.list();
		
	}

	public PoliceCharge savePoliceCharge(PoliceCharge charge) {
		
		//this.getHibernateTemplate().saveOrUpdate(charge);
		return (PoliceCharge) getCurrentSession().merge(charge);
	}

	@SuppressWarnings("unchecked")
	public List<CriminalSanctionOutcome> loadCriminalSanctionOutcome(Long sanctionId) {
		
		Criteria criteria = getCurrentSession().createCriteria(CriminalSanctionOutcome.class);
		criteria.add(Restrictions.eq("criminalSanctionId", sanctionId));
		return criteria.list();
		
		
	}

	
	public CriminalSanctionOutcome saveCriminalSanctionOutcome(final CriminalSanctionOutcome outcome) {
		
		Session session = getCurrentSession();
		session.saveOrUpdate(outcome);
		
		// As DELETE_ORPHANS is not working, has to do it manual. 
		Criteria criteria = session.createCriteria(OutcomeOrderSanction.class);
		criteria.add(Restrictions.isNull("outcomeId"));
		
		
		List list = criteria.list();	
		if (null != list && !list.isEmpty()) {
			for(Object curr : list){
				session.delete(curr);
			}
		}
		//this.getHibernateTemplate().deleteAll(list);
		criteria = session.createCriteria(OutcomeAppliedSanction.class);
		criteria.add(Restrictions.isNull("outcomeId"));
		
		list = criteria.list();
		if (null != list && !list.isEmpty()) {
			for(Object curr : list){
				session.delete(curr);
			}
		}
		//this.getHibernateTemplate().deleteAll(list);
		
		return outcome;
	}

	@Override
	public CriminalSanctionView loadCriminalSanctionView(Long sanctionId) {
		
		Session  session = getCurrentSession();
		
		List list = session.createQuery("from CriminalSanctionView where criminalSanctionId = :sanctionId")
					.setLong("sanctionId", sanctionId).list();
		
		if (null != list && !list.isEmpty()) {
			
			return (CriminalSanctionView)list.get(0);
		}
		return null;
	}

	@Override
	public List<CriminalAppealView> loadAppealsByParentSanctionId(
			Long criminalSanctionId) {
		
		Session  session = getCurrentSession();
		
		List list = session.createQuery("from CriminalAppealView where sanctionId = :sanctionId")
					.setLong("sanctionId", criminalSanctionId).list();
		
		return list;
	}
	
}
