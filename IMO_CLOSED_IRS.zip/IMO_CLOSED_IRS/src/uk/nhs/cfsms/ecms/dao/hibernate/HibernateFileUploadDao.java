package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.FileUploadDao;
import uk.nhs.cfsms.ecms.data.common.FileObject;
import uk.nhs.cfsms.ecms.data.common.FileUploadPermissions;

@Repository
public class HibernateFileUploadDao extends HibernateBaseDao implements
		FileUploadDao { 

	public FileObject saveFile(FileObject file) {
		return (FileObject) getCurrentSession().merge(file);
	}

	public FileObject updateFile(FileObject file) {
		return (FileObject) getCurrentSession().merge(file);
	}

	public void deleteFile(FileObject file) {
		getCurrentSession().delete(file);

	}

	public FileObject loadFileByFileId(final Long fileId) {
		
		DetachedCriteria criteria = DetachedCriteria.forClass(FileObject.class);
		criteria.add(Restrictions.eq("fileId", fileId));
		List<FileObject> list =  criteria.getExecutableCriteria(getCurrentSession()).list();
		/*List<FileObject> list = (List) getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session)
							throws HibernateException, SQLException {
						Criteria criteria = session
								.createCriteria(FileObject.class);
						criteria.add(Restrictions.eq("fileId", fileId));

						return criteria.list();
					}
				});*/

		if (null != list && !list.isEmpty()) {

			return (FileObject) list.get(0);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<FileObject> loadFileByFileByDept(String dept) {

		DetachedCriteria criteria = DetachedCriteria.forClass(FileObject.class);
		criteria.add(Restrictions.eq("uploadedDepartment", dept));
		criteria.addOrder(Order.asc("fileDescrption"));
		return criteria.getExecutableCriteria(getCurrentSession()).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FileObject> loadFileByFileByCategory(String category) {
		DetachedCriteria criteria = DetachedCriteria.forClass(FileObject.class);
		criteria.add(Restrictions.eq("category", category));
		criteria.addOrder(Order.asc("fileDescrption"));
		return criteria.getExecutableCriteria(getCurrentSession()).list();
	}

	@Override
	public Boolean isUserUploadAdmin(String category, String staffId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(FileUploadPermissions.class);
		criteria.add(Restrictions.eq("category", category));
		criteria.add(Restrictions.ilike("permissions", staffId, MatchMode.ANYWHERE));
		Session session = getCurrentSession();
		@SuppressWarnings("unchecked")
		List<FileUploadPermissions> list = criteria.getExecutableCriteria(session).list();
		if (null != list && !list.isEmpty()) {
			return true;
		}
		return false;
	}
}
