package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.cim.CaseClosure;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.cim.CaseObject;
import uk.nhs.cfsms.ecms.data.cim.CaseSummaryInformation;
import uk.nhs.cfsms.ecms.data.cim.CaseUpdate;
import uk.nhs.cfsms.ecms.data.cim.InvestigationPlan;
import uk.nhs.cfsms.ecms.data.cim.TempConfCase;
import uk.nhs.cfsms.ecms.data.common.OrganisationTeamCode;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;
import uk.nhs.cfsms.ecms.dto.search.CaseSearchFormTO;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;

public interface CaseDao {

	public List<CaseObject> loadCases();

	public List<CaseObject> loadCases(boolean regionalCode, boolean overLoaded,
			String[] responsibilites);

	public List<CaseObject> loadCases(boolean regionalCode, boolean orgCode,
			List<UserDirectorate> directorates, String[] responsibilites);
	
	public List<CaseObject> loadRegionalCases(List<UserDirectorate> directorates, String[] responsibilites);

	public List<CaseObject> loadAssignedCases(SessionUser user,
			List<UserDirectorate> directorates);

	public Case saveCase(Case caseInfo);

	public Case loadCase(Long id);
	
	public String loadCaseNumber(final Long caseID);

	public Case saveOrUpdate(Case caseObject);

	public OrganisationTeamCode loadTeamCodeByOrgCode(String org_code);

	public String getCaseNumber(final CaseTO caseTo);

	public Case loadCaseByCaseNumber(String caseNum);

	public List<CaseContact> loadContactsByCaseId(Long caseId);

	public List<InvestigationPlan> loadInvestigationsByCaseId(Long caseId);
	
	public List<InvestigationPlan> loadFullInvestigationsByCaseId(Long caseId);

	public CaseClosure saveCaseClosure(CaseClosure closure);

	public CaseClosure updateCaseClosure(CaseClosure closure);

	public CaseClosure loadCaseClosure(Long caseId);
	
	public CaseClosure loadCaseClosureForCPS(Long caseId);
	
	public CaseClosure downloadCaseClosure(Long caseId);

	public List<CaseObject> loadClosedCases(boolean regionalCode, boolean orgCode,
			List<UserDirectorate> directorates, String[] responsibilites);

	public CaseSearchFormTO getCaseSearchResults(CaseSearchFormTO searchTO, SessionUser user);
	
	public CaseSearchFormTO getGenericCaseSearchResults(CaseSearchFormTO searchTO, SessionUser user);
	
	public CaseSummaryInformation loadCaseSummaryInformation(Long caseId); 
	
	public void updateCaseSummaryInformation(CaseSummaryInformation summary);

	public boolean isUserAuthorizedToAccessCase(Long caseId, SessionUser user);

	public UserObject getOFMDetailsByCaseId(Long caseId);
	
	public String getApproverStaffIdForCPSDocsRequest();
	
	public void runConfidentialProcedure(Long caseId);
	
	public void callTransactionCommit();
	
	public void callTransactionBeginAndSave(final TempConfCase tempCase);
	
	public void saveTempConfCase(TempConfCase tempCase);

	public List<CaseObject> loadNITCasesByTeam(List<UserDirectorate> directorates, String teamValue);
	
	public List<CaseObject> loadAwaitCases(List<UserDirectorate> directorate, String[] responsibilites);

	public CaseUpdate saveCaseUpdate(CaseUpdate newUpdate);

	public List<CaseUpdate> loadCaseUpdatesByCaseId(Long caseId);
	
	public String loadCPSURN(final Long caseID);
		
}
