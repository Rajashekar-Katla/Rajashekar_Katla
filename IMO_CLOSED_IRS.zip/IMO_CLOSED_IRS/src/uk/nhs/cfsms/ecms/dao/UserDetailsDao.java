package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.authentication.Users;
import uk.nhs.cfsms.ecms.data.common.StaffTeams;
import uk.nhs.cfsms.ecms.data.common.UserHistory;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.common.UserPreference;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;

/*
 * Author: R Tobin
 * 
 * interface implemented by HibernateUserDetailsDao
 */

public interface UserDetailsDao {

	public UserObject loadUserByUserId(String staffId);

	public UserObject loadUserByUserIdForCPS(final String staffId);

	public List<UserObject> loadUsersByGroups(String[] userGroup);

	public UserObject loadUser(String staffId);

	public List<StaffTeams> loadTeamsByStaffId(String staffId);

	public List<UserObject> loadLcfsStaffByCaseTeamCodeByCaseId(Long caseId);

	public List<UserObject> listUserDetailsByAccessLevelAndOrgCode(
			String accessLevel, String orgCode);

	public UserObject loadOFMByTeamCode(String team_code);

	public List<UserObject> loadUsersByTeamCode(String teamCode,
			String[] groupLevel);

	public List loadUserAccessListByAccessLevel(String aclLevel);

	public Users getUserNamePassword(String userId);

	public List<UserObject> loadCFSUsersByTeamCode(String teamCode);

	public List<UserObject> loadCFSUsersByTeamCodes(String[] teamCode);

	public List loadLcfsStaffByTeamCodes(String[] teamCodes);

	// New Restructure from 1April2011... OFM's changed...

	public List<String> getAllOrgsFromNewTeamCode(String teamCode);

	public List<UserObject> loadUsersByNewTeamCode(String teamCode,
			String[] groupLevel);

	public List<UserObject> loadUsersByNewTeamCodeAndGroups(String teamCode,
			String[] groups);

	public UserObject loadOFMByNewTeamCode(String teamCode);

	public List<UserObject> loadCFSUsersByNewTeamCode(String teamCode);

	public List<UserObject> loadCFSUsersByNewTeamCodes(String[] teamCodes);

	public List<UserObject> loadLcfsStaffByNewTeamCodes(String[] teamCodes);

	public List<UserObject> loadLcfsStaffByCaseNewTeamCodeByCaseId(Long caseId);

	public UserObject loadAFLByTeamCode(String teamCode);

	public UserHistory loadUserHistory(String staffId);

	public void createUserHistory(UserHistory history);

	public void updateUserHistory(UserHistory history);

	public UserPreference loadUserPrefereces(String staffId);

	public void updateUserPreferences(UserPreference preference);

	public List<String> searchUsers(String userSearchPattern);

	public List<String> searchUsers(String userSearchPattern, SessionUser user,
			String caseId);

	public List<UserObject> loadNewLCFSByCaseOrgCode(Long caseId,
			List<String> currentAssignees);

	public String getStaffEmailAddress(final String staffId);

	public String getStaffEmailAddressFromCPOD(final String staffId);

	public List<UserObject> loadIMOTeam(final String empOrgCode);

}