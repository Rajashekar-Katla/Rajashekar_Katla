package uk.nhs.cfsms.ecms.dao.hibernate;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.InterceptDao;
import uk.nhs.cfsms.ecms.dto.user.SessionUser;

@Repository
public class HibernateInterceptDao extends HibernateBaseDao implements InterceptDao {

	public boolean authorizeUserByACL(SessionUser user, Long interceptId) {
		// TODO Auto-generated method stub
		return false;
	}

}
