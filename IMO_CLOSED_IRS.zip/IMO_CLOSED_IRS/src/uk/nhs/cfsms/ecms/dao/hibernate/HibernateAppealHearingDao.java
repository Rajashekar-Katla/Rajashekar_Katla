package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.AppealHearingDao;
import uk.nhs.cfsms.ecms.data.sanction.AppealHearing;

/**
 * Appeal Hearing DAO implementation.
 * 
 */
@Repository
public class HibernateAppealHearingDao extends HibernateBaseDao implements
		AppealHearingDao {
	
	public List<AppealHearing> loadAppealHearingsByAppealId(Long appealId) {
		Session session = getCurrentSession();
		Query query = session.createQuery("from AppealHearing where appealId = :appealId");
		query.setParameter("appealId", appealId);
		List<AppealHearing> list = query.list();
		return list;
	}

	public List<AppealHearing> loadCourtHearingsByTypeAndAppealId(Long appealId,
			String sanctionType) {
		Session session = getCurrentSession();
		//Criteria criteria = getCurrentSession().createCriteria(AppealHearing.class);
		
		Criteria criteria = session.createCriteria(AppealHearing.class);
		criteria.add(Restrictions.eq("appealId", appealId));
		criteria.add(Restrictions.eq("sanctionType", sanctionType));

		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.addOrder(Order.asc("appearanceId"));
		List<AppealHearing> list = criteria.list();

		return list;
	}

	@Override
	public AppealHearing getLatestHearingByType(Long id, String type) {

		Session session = getCurrentSession();
		Query query = session
				.createQuery("Select o from AppealHearing o where o.id = "
						+ "(Select max(i.id) from AppealHearing i where i.appealId = :id and i.sanctionType = :type )");

		query.setParameter("id", id);
		query.setParameter("type", type);
		List list = query.list();
		return (AppealHearing) ((list != null && list.size() > 0) ? list.get(0)
				: null);

	}

	@Override
	public AppealHearing loadAppealHearing(Long appearanceId) {

		Session session = getCurrentSession();
		Query query = session
				.createQuery("from AppealHearing where appearanceId = :appearanceId");
		query.setLong("appearanceId", appearanceId);
		List list = query.list();

		if (!list.isEmpty()) {
			return (AppealHearing) list.get(0);
		}

		return null;
	}

	@Override
	public String loadLatestAppealHearingCourtName(Long appealId) {
		
		Session session = getCurrentSession();
		// "from AppealHearing where sanctionId = :appealId  ORDER BY  hearingDate, hearingTime DESC");
		Query query = session.createQuery(
				"from AppealHearing where appealId = :appealId ORDER BY to_date(TO_CHAR(hearing_date, 'DD/MON/YYYY ') || hearing_time, 'DD/MON/YYYY HH24:MI:SS') DESC");
		
		query.setLong("appealId", appealId); 
		List list = query.list();
		
		if (null != list && !list.isEmpty()) {
		
			AppealHearing hearing =  (AppealHearing)list.get(0);
			if (logger.isDebugEnabled()) {
				
				logger.debug("Hearing for appealId="+ appealId + ", at index-0=" + hearing);
			}
			return hearing.getCourtName();
		}
		
		return "";
	}

}
