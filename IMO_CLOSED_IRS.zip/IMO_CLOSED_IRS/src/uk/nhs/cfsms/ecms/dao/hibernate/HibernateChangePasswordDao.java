package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.ChangePasswordDao;
import uk.nhs.cfsms.ecms.data.authentication.Users;
import uk.nhs.cfsms.ecms.data.common.UserHistory;

/**
 * @author SKavali
 * DAO Class for updating the password
 *
 */
@Repository
public class HibernateChangePasswordDao extends HibernateBaseDao
			implements ChangePasswordDao {

	protected final Log log = LogFactory.getLog(getClass());

	/**
	 * Method to load the user details
	 * @param id
	 * @return
	 */
	public Users loadUser(String id) {
		Users user = (Users) getCurrentSession().get(Users.class, id);
		return user;
	}
	


	/** 
	 * Method to update password, the password will not be updated if if the new password and old password are same.
	 *  @param userId
	 *  @param New Password
	 *  
	 *  @return true if password updated, false if update failed
	 */
	public boolean changePassword(String userId, String password) {
		boolean pwdChanged = false;
		Users user = loadUser(userId);
		if (user.getPassword().equals(password)) {
			pwdChanged = false;
		} else {
			user.setPassword(password);
			getCurrentSession().update(user);
			pwdChanged = true;
		}
		return pwdChanged;
	}
	

	@Override
	public void updateUserHistory(UserHistory history) {
		
		getCurrentSession().merge(history);
	}

	@Override
	public UserHistory loadUserHistory(String staffId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(UserHistory.class);
		criteria.add(Restrictions.eq("staffId", staffId));
		List list = criteria.getExecutableCriteria(getCurrentSession()).list();
		
		if (null != list && !list.isEmpty()) {
			return (UserHistory)list.get(0);
		}
		
		return null;
	}

}
