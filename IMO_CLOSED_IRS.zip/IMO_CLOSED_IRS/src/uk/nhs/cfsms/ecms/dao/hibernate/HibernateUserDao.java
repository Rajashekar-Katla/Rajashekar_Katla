package uk.nhs.cfsms.ecms.dao.hibernate;

import uk.nhs.cfsms.ecms.dao.UserDao;
import uk.nhs.cfsms.ecms.data.cim.Md5Users;


public class HibernateUserDao extends HibernateBaseDao implements UserDao{
	
	public Md5Users loadUser(String staffId)
	{
		return null;
		
	}
	
	
	public Md5Users saveUsers(Md5Users user)
	{
		saveObject(user);
		return user;
	}
	
	public Md5Users updateUsers(Md5Users user)
	{
		return null;
	}
	
	public void  deleteUsers(Md5Users user)
	{
		deleteObject(user);
		
	}
	

}
