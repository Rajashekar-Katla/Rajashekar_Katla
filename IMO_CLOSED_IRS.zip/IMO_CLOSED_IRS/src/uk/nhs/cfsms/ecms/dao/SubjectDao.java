package uk.nhs.cfsms.ecms.dao;

import java.text.ParseException;
import java.util.List;

import uk.nhs.cfsms.ecms.data.infoGath.NHSSubjectInformation;
import uk.nhs.cfsms.ecms.data.infoGath.NonNHSSubjectInformation;
import uk.nhs.cfsms.ecms.data.infoGath.SubjectInformation;
import uk.nhs.cfsms.ecms.dto.infoGath.NHSSubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.NonNHSSubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SubjectInformationTO;

/**
 * SubjectDao is a DAO for accessing subject's (person/NHS/non-NHS) details both
 * in information and case stages.
 * 
 * @author schilukuri
 * 
 */
public interface SubjectDao {

	public SubjectInformationTO loadSubjectInformationById(
			SubjectInformation subject);

	public SubjectInformationTO insertSubjectInformation(
			SubjectInformationTO dto);
	
	public NHSSubjectInformationTO LoadNHSSubjectInformationById(
			NHSSubjectInformation subject);

	public NHSSubjectInformationTO insertNHSSubjectInformation(
			NHSSubjectInformationTO dto);
	
	public NonNHSSubjectInformationTO loadNonNHSSubjectInformationById(
			NonNHSSubjectInformation subject);

	public NonNHSSubjectInformationTO insertNonNHSSubjectInformation(
			NonNHSSubjectInformationTO dto);

	/**		 Subject Information (PERSON)	**/
	public SubjectInformation loadSubjectById(SubjectInformation subject);

	public SubjectInformation insertSubject(SubjectInformation subject);

	public SubjectInformation updateSubject(SubjectInformation subject);

	public void removeSubject(SubjectInformation subject);

	/**		 NHS Subject Information 	**/
	public NHSSubjectInformation LoadNHSSubjectById(NHSSubjectInformation subject);

	public NHSSubjectInformation insertSubject(NHSSubjectInformation subject);

	public NHSSubjectInformation updateSubject(NHSSubjectInformation subject);

	public void removeSubject(NHSSubjectInformation subject);
	
	/**		NON-NHS Subject Information 	**/
	
	public NonNHSSubjectInformation LoadNHSSubjectById(NonNHSSubjectInformation subject);

	public NonNHSSubjectInformation insertSubject(NonNHSSubjectInformation subject);

	public NonNHSSubjectInformation updateSubject(NonNHSSubjectInformation subject);

	public void removeSubject(NonNHSSubjectInformation subject);	
	
	public SubjectInformationTO loadSubjectInformationByCaseId(
			final Long caseId);
	
	public List<SubjectInformation> loadInformationSubjectByNativeSql(final String firstName,
			final String lastName, final String dob) throws ParseException;
	
	public SubjectInformation loadSubjectById(final long subjectId);
}
