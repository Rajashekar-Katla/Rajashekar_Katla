package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.audit.CustomTrackingRevisionEntity;
import uk.nhs.cfsms.ecms.audit.RevisionedEntityInfo;
import uk.nhs.cfsms.ecms.data.common.AuditLog;
import uk.nhs.cfsms.ecms.exceptions.ServiceException;

/**
 * Data Access Object interface for audit logs
 * @author Sukhraj Matharu
 *
 */
public interface AuditLogDao {

	/**
	 * Saves an audit log object to the table
	 * @param auditLog to save 
	 */
	void save(AuditLog auditLog);
	
	List<AuditLog> getCaseLogsByCaseId(Long caseId) throws ServiceException;
	
	List<CustomTrackingRevisionEntity> getInfoLogsById(Long infoID) ;
	
	List<RevisionedEntityInfo> getAuditInfoForCaseAndRevision(Integer revId, Long caseId);

	List<RevisionedEntityInfo> getAuditInfoForInformationRevision(
			Integer revisionID, Long entityId);
		
	List<CustomTrackingRevisionEntity> getCaseLogsById(String caseId) ;

	List<CustomTrackingRevisionEntity> retrieveAudit(boolean isCase, Long id);

}
