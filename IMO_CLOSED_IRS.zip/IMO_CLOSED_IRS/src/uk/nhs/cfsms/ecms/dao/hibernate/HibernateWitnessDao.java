package uk.nhs.cfsms.ecms.dao.hibernate;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.dao.WitnessDao;
import uk.nhs.cfsms.ecms.data.infoGath.Information;
import uk.nhs.cfsms.ecms.data.infoGath.PersonContacts;
import uk.nhs.cfsms.ecms.data.infoGath.SubjectInformation;
import uk.nhs.cfsms.ecms.data.witness.Witness;
import uk.nhs.cfsms.ecms.dto.witness.WitnessTO;

@Repository
public class HibernateWitnessDao extends HibernateBaseDao implements WitnessDao {

	@PersistenceContext
	EntityManager entityManager;

	public List<WitnessTO> loadWitnessesByCaseId(Long caseId) {

		/*
		 * StringBuilder hsql = new StringBuilder("");
		 * hsql.append("select witness.witnessId,witness.caseId,");
		 * hsql.append("witness.person.personId,witness.person.title,");
		 * hsql.append("witness.person.firstName,witness.person.lastName,");
		 * //hsql
		 * .append("witness.person.gender,elements(witness.person.contactsList),"
		 * );
		 * hsql.append("witness.state,witness.createdTime from Witness witness "
		 * ); hsql.append(" where witness.caseId='").append(caseId);
		 * hsql.append("' order by witness.createdTime asc");
		 * 
		 * return
		 * createWitnessList(getHibernateTemplate().find(hsql.toString()));
		 */

		DetachedCriteria criteria = DetachedCriteria.forClass(Witness.class)
				.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.ne("state", ECMSConstants.WITNESS_SUBJECT));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		return criteria.getExecutableCriteria(getCurrentSession()).list();

	}

	public List<WitnessTO> loadAllWitnessesByCaseIdForExhibit(final long caseId) {

		final String sql = "select NEW uk.nhs.cfsms.ecms.dto.witness.WitnessTO("
				+ "w.witnessId, p.title, p.firstName, p.lastName, p.otherTitle) "
				+ "from Witness w join w.person p where w.caseId = :caseId";

		final Query query = getEntityManager().createQuery(sql);
		query.setParameter("caseId", caseId);

		@SuppressWarnings("unchecked")
		final List<WitnessTO> results = query.getResultList();

		return results;
	}
	
	
	public WitnessTO loadWitnessesByIdForExhibit(final long witnessId) {

		final String sql = "select NEW uk.nhs.cfsms.ecms.dto.witness.WitnessTO("
				+ "w.witnessId, p.title, p.firstName, p.lastName, p.otherTitle) "
				+ "from Witness w join w.person p where w.witnessId = :witnessId";

		final Query query = getEntityManager().createQuery(sql);
		query.setParameter("witnessId", witnessId);

		final WitnessTO result = (WitnessTO) query.getSingleResult();

		return result;
	}

	public List<Witness> loadAllWitnessesByCaseId(Long caseId, String byFilter) {

		DetachedCriteria criteria = DetachedCriteria.forClass(Witness.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.createAlias("person", "prs");
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.add(Restrictions.eq("state", ECMSConstants.WITNESS_USED));
		if (byFilter.equalsIgnoreCase("surname")) {
			criteria.addOrder(Order.asc("prs.lastName"));
		} else if (byFilter.equalsIgnoreCase("statementDate")) {
			criteria.addOrder(Order.asc("createdTime"));
		} else if (byFilter.equalsIgnoreCase("witnessSerialNo")) {
			criteria.addOrder(Order.asc("serialNumber"));
		}
		return criteria.getExecutableCriteria(getCurrentSession()).list();
	}

	public Witness loadWitnessById(Long witnessId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(Witness.class);
		criteria.add(Restrictions.eq("witnessId", witnessId));
		List witnesses = criteria.getExecutableCriteria(getCurrentSession())
				.list();

		if (null != witnesses && !witnesses.isEmpty()) {
			return (Witness) witnesses.get(0);
		}
		return null;
	}

	public Witness loadWitnessByIdForLookupUser(final Long witnessId) {

		Witness witness = null;

		final Criteria criteria = getCurrentSession().createCriteria(
				Witness.class);

		criteria.add(Restrictions.eq("witnessId", witnessId));
		criteria.add(Restrictions.isNotNull("caseId"));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("witnessId"), "witnessId");
		projectionList.add(Projections.property("caseId"), "caseId");
		projectionList.add(Projections.property("person"), "person");
		projectionList.add(Projections.property("createdTime"), "createdTime");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers.aliasToBean(Witness.class));

		@SuppressWarnings("unchecked")
		final List<Witness> list = criteria.list();

		if (null != list && !list.isEmpty()) {
			witness = list.get(0);
		}
		return witness;
	}

	public List<Witness> loadWitnessByNativeSql(final String firstName,
			final String lastName, final String dob) throws ParseException {

		String personSQL = "select PERSON_ID from PERSON_TBL where lower(FIRST_NAME)=lower(:i_Fname) and lower(LAST_NAME)=lower(:i_Lname)";
		final List<Witness> witnesses = new ArrayList<Witness>();
		String newDate = null;
		SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");

		if (!dob.isEmpty()) {
			personSQL = personSQL + " and DOB = :dob";

			SimpleDateFormat format1 = new SimpleDateFormat("dd/MM/yyyy");
			Date date = format1.parse(dob);
			newDate = format2.format(date.getTime());
		}

		final String witnessIDQuery = "select WITNESS_ID FROM WITNESS_TBL WHERE PERSON_ID IN ("
				+ personSQL + ")";

		final SQLQuery query = getHibernateSession().createSQLQuery(
				witnessIDQuery);
		query.setParameter("i_Fname", firstName);
		query.setParameter("i_Lname", lastName);

		if (!dob.isEmpty()) {
			query.setParameter("dob",
					new Date(format2.parse(newDate).getTime()));
		}

		@SuppressWarnings("unchecked")
		final List<BigDecimal> results = query.list();

		for (BigDecimal l : results) {
			Witness witness = loadWitnessByIdForLookupUser(l.longValue());
			if (witness != null) {
				witness.setState("Witness");
				witnesses.add(witness);
			}

		}

		return witnesses;
	}

	public Witness saveWitness(Witness witness) {
		witness.setUpdatedFlag("Y");
		return (Witness) getCurrentSession().merge(witness);
	}

	public Witness updateWitness(Witness witness) {
		witness.setUpdatedFlag("Y");
		return (Witness) getCurrentSession().merge(witness);
	}

	public Witness mergeWitness(Witness witness) {
		witness.setUpdatedFlag("Y");
		return (Witness) getCurrentSession().merge(witness);
	}

	private List<WitnessTO> createWitnessList(List<Object[]> queryResults) {
		List<WitnessTO> witnessList = new ArrayList<WitnessTO>();

		for (Object[] result : queryResults) {
			WitnessTO witness = new WitnessTO();
			witness.setWitnessId((Long) result[0]);
			witness.setCaseId((Long) result[1]);
			witness.getPerson().setPersonId((Long) result[2]);
			witness.getPerson().setTitle((String) result[3]);
			witness.getPerson().setFirstName((String) result[4]);
			witness.getPerson().setLastName((String) result[5]);
			witness.getPerson().setGender((String) result[6]);
			List<PersonContacts> contacts = new ArrayList<PersonContacts>();
			contacts.add((PersonContacts) result[7]);
			witness.getPerson().setContactsList(contacts);
			// witness.getPerson().setHomeTel((String) result[7]);
			witness.setState((String) result[8]);
			witness.setCreatedTime((Date) result[9]);
			witnessList.add(witness);

		}
		return witnessList;
	}

	public void updateWitnessToSubject(SubjectInformation subject) {

		boolean isWitnessExSubject = false;
		Information information = findInformationByCaseId(subject.getCaseId());
		subject.setInformation(information.getInformationId());
		Long personId = subject.getSubjectPerson().getPersonId();

		// Set<SubjectInformation> subjects = hibernate.getSubjectInformation();
		List<SubjectInformation> subjects = information.getSubjectInformation();

		for (int i = 0; i < subjects.size(); i++) {
			SubjectInformation subInfo = subjects.get(i);
			if (subInfo.getSubjectPerson().getPersonId().equals(personId)) {
				subjects.get(i).setIsWitness("N");
				isWitnessExSubject = true;
			}
		}
		if (!isWitnessExSubject) {
			subjects.add(subject);
		}
		getCurrentSession().merge(information);
	}

	private Information findInformationByCaseId(Long caseId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(Information.class).add(
						Restrictions.eq("caseId", caseId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();
		if (list != null && !list.isEmpty()) {
			return (Information) list.get(0);
		}
		return null;
	}

	private Session getHibernateSession() {
		return entityManager.unwrap(Session.class);
	}
}
