package uk.nhs.cfsms.ecms.dao;

import uk.nhs.cfsms.ecms.data.authentication.Users;
import uk.nhs.cfsms.ecms.data.common.UserHistory;


public interface ChangePasswordDao {
	
	public Users loadUser(String id);
	
	public boolean changePassword(String userId, String password);
	
	public void updateUserHistory(UserHistory history);

	public UserHistory loadUserHistory(String staffId);
}
