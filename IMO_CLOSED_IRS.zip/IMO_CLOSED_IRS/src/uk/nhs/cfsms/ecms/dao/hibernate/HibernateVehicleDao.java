package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.VehicleDao;
import uk.nhs.cfsms.ecms.data.cim.Vehicle;
import uk.nhs.cfsms.ecms.data.cim.VehicleStandalone;

@Repository
public class HibernateVehicleDao extends HibernateBaseDao implements VehicleDao {

	public Vehicle load(Long id) {
		return (Vehicle)getCurrentSession().get(Vehicle.class, id);
		
	}

	public void save(Vehicle vehicle) {
		vehicle.setUpdatedFlag("Y");
		getCurrentSession().merge(vehicleToStandalone(vehicle));
		
	}

	public List<Vehicle> loadVehicles(Long caseID) {
		List<Vehicle> res = new ArrayList<Vehicle>();
		
		DetachedCriteria criteria = DetachedCriteria.forClass(Vehicle.class).add(Restrictions.eq("caseId", caseID));
		res = criteria.getExecutableCriteria(getCurrentSession()).list();
		
		return res;
		
		
	}

	public void saveAllVehicles(List<Vehicle> vehicles) {
		if (null != vehicles) {
			for (Vehicle curr : vehicles) {
				getCurrentSession().merge(curr);
			}
		}
	}

	public List<Vehicle> loadVehiclesByInformation(Long informationId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(Vehicle.class).add(
						Restrictions.eq("infoId", informationId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		return criteria.getExecutableCriteria(getCurrentSession()).list();
			
	}

	public VehicleStandalone vehicleToStandalone(Vehicle vehicleFrm) {
		VehicleStandalone vehicleTo = new VehicleStandalone();
		vehicleTo.setCaseId(vehicleFrm.getCaseId());
		vehicleTo.setColour(vehicleFrm.getColour());
		vehicleTo.setComments(vehicleFrm.getComments());
		vehicleTo.setInfoId(vehicleFrm.getInfoId());
		vehicleTo.setLicensePlate(vehicleFrm.getLicensePlate());
		vehicleTo.setMake(vehicleFrm.getMake());
		vehicleTo.setModel(vehicleFrm.getModel());
		vehicleTo.setPostcode(vehicleFrm.getPostcode());
		vehicleTo.setRegisteredAddress1(vehicleFrm.getRegisteredAddress1());
		vehicleTo.setRegisteredAddress2(vehicleFrm.getRegisteredAddress2());
		vehicleTo.setRegisteredAddress3(vehicleFrm.getRegisteredAddress3());
		vehicleTo.setRegisteredAddress4(vehicleFrm.getRegisteredAddress4());
		vehicleTo.setRegisteredKeeperName(vehicleFrm.getRegisteredKeeperName());
		vehicleTo.setUpdatedFlag(vehicleFrm.getUpdatedFlag());
		vehicleTo.setVehicleId(vehicleFrm.getVehicleId());
		return vehicleTo;
	}

	public List<VehicleStandalone> vehicleToStandalone(List<Vehicle> vehiclesFrm) {
		List<VehicleStandalone> vehiclesTo = new ArrayList<VehicleStandalone>();
		VehicleStandalone vehicleTo = null;
		
		for (Vehicle vehicleFrm : vehiclesFrm) {
			vehicleTo = new VehicleStandalone();
			
			vehicleTo.setCaseId(vehicleFrm.getCaseId());
			vehicleTo.setColour(vehicleFrm.getColour());
			vehicleTo.setComments(vehicleFrm.getComments());
			vehicleTo.setInfoId(vehicleFrm.getInfoId());
			vehicleTo.setLicensePlate(vehicleFrm.getLicensePlate());
			vehicleTo.setMake(vehicleFrm.getMake());
			vehicleTo.setModel(vehicleFrm.getModel());
			vehicleTo.setPostcode(vehicleFrm.getPostcode());
			vehicleTo.setRegisteredAddress1(vehicleFrm.getRegisteredAddress1());
			vehicleTo.setRegisteredAddress2(vehicleFrm.getRegisteredAddress2());
			vehicleTo.setRegisteredAddress3(vehicleFrm.getRegisteredAddress3());
			vehicleTo.setRegisteredAddress4(vehicleFrm.getRegisteredAddress4());
			vehicleTo.setRegisteredKeeperName(vehicleFrm
					.getRegisteredKeeperName());
			vehicleTo.setUpdatedFlag(vehicleFrm.getUpdatedFlag());
			vehicleTo.setVehicleId(vehicleFrm.getVehicleId());
			
			vehiclesTo.add(vehicleTo);
		}
		return vehiclesTo;
	}

	public Vehicle standaloneToVehicle(VehicleStandalone vehicleFrm) {
		Vehicle vehicleTo = new Vehicle();
		vehicleTo.setCaseId(vehicleFrm.getCaseId());
		vehicleTo.setColour(vehicleFrm.getColour());
		vehicleTo.setComments(vehicleFrm.getComments());
		vehicleTo.setInfoId(vehicleFrm.getInfoId());
		vehicleTo.setLicensePlate(vehicleFrm.getLicensePlate());
		vehicleTo.setMake(vehicleFrm.getMake());
		vehicleTo.setModel(vehicleFrm.getModel());
		vehicleTo.setPostcode(vehicleFrm.getPostcode());
		vehicleTo.setRegisteredAddress1(vehicleFrm.getRegisteredAddress1());
		vehicleTo.setRegisteredAddress2(vehicleFrm.getRegisteredAddress2());
		vehicleTo.setRegisteredAddress3(vehicleFrm.getRegisteredAddress3());
		vehicleTo.setRegisteredAddress4(vehicleFrm.getRegisteredAddress4());
		vehicleTo.setRegisteredKeeperName(vehicleFrm.getRegisteredKeeperName());
		vehicleTo.setUpdatedFlag(vehicleFrm.getUpdatedFlag());
		vehicleTo.setVehicleId(vehicleFrm.getVehicleId());
		return vehicleTo;
	}

}
