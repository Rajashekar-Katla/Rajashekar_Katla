package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.SourceDao;
import uk.nhs.cfsms.ecms.data.infoGath.SourceInformation;
import uk.nhs.cfsms.ecms.dto.infoGath.SourceInformationTO;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.ConvertToDTO;

@Repository
public class HibernateSourceDao extends HibernateBaseDao implements
		SourceDao {

	public SourceInformationTO insertSource(SourceInformationTO dto) {
		if (dto.getSourceId() == null) {

			SourceInformation hibernate = ConvertFromDTO.getInstance()
					.convertFromDTO(dto);
/*			System.out.println("SAVING SourceInformation : "
					+ hibernate.getSourceId());
*/
			return ConvertToDTO.getInstance().convertToDTO((SourceInformation)getCurrentSession().merge(hibernate));
		}
		return dto;
	}

	public SourceInformationTO LoadSourceById(SourceInformationTO dto) {
		DetachedCriteria criteria = DetachedCriteria.forClass(
				SourceInformation.class)
				.add(Restrictions.idEq(dto.getSourceId()));

		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		SourceInformationTO[] arrayTO = convertToDTO(list);

		if (arrayTO != null && arrayTO.length > 0) {
			return arrayTO[0];
		}

		return null;
	}

	private SourceInformationTO[] convertToDTO(List hibernateList) {
		Iterator iter = hibernateList.iterator();
		List<SourceInformationTO> list = new ArrayList<SourceInformationTO>();
		while (iter.hasNext()) {
			SourceInformation hibernate = (SourceInformation) iter.next();
			SourceInformationTO dto = ConvertToDTO.getInstance().convertToDTO(
					hibernate);
			list.add(dto);
		}

		return list.toArray(new SourceInformationTO[list.size()]);
	}

}
