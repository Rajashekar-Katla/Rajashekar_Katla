package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.Exhibit;
import uk.nhs.cfsms.ecms.data.cim.ExhibitDocuments;
import uk.nhs.cfsms.ecms.dto.exhibit.ExhibitViewTO;


public interface ExhibitDao extends BaseDao {
	
	List<Exhibit> loadExhibits(Long caseId);
	
	/**
	 * This method is responsible for loading a given case Exhibit for a given ID.
	 * This is being used CPS document list downloading.
	 * */
	public Exhibit loadExhibit(Long exhibitId);
	
	public List<ExhibitDocuments> loadExhibitsForCPS(final Long caseId);
	
	public boolean updateExhibitFileName(Long exhibitId,final String fileName);
	
	public void updateExhibit(final Exhibit exhibit);
	
	public Long getExhibitFileSize(final long exhibitId);
	
	public void saveExhibitDocuments(final ExhibitDocuments exhibitDocuments);
	
	public ExhibitViewTO downloadExhibit(final Long exhibitId, final String exhibitType);
	
	public ExhibitDocuments downloadExhibitLabel(final Long exhibitId,
			final boolean isFileBlobRequired);
	
	public List<Exhibit> loadAllExhibitDocuments(final long caseId,final String exhibitType);
	
	public void deleteExhibitDocument(final Long id);
	
	public ExhibitDocuments downloadExhibitDocument(final Long id);
	
	public void deleteExhibit(final Long exhibitId);
}
