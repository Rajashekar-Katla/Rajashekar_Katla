package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.CourtAppearanceDao;
import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;

/**
 * Court Appearance Hibernate DAO implementation.
 * 
 */
@Repository
public class HibernateCourtAppearanceDao extends HibernateBaseDao implements
		CourtAppearanceDao {

	public List<CourtAppearance> loadCourtAppearancesBySanctionId(
			Long sanctionId) {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				CourtAppearance.class).add(
				Restrictions.eq("sanctionId", sanctionId));

		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List list = criteria.getExecutableCriteria(getCurrentSession()).list();

		return list;
	}
	
	
	public List<CourtAppearance> loadCourtAppearancesByType(
			Long sanctionId,String sanctionType)
			{
			DetachedCriteria criteria = DetachedCriteria.forClass(
					CourtAppearance.class).add(
					Restrictions.eq("sanctionId", sanctionId));
					criteria.add(Restrictions.eq("sanctionType", sanctionType));
            
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			criteria.addOrder(Order.asc("appearanceId"));
			List list = criteria.getExecutableCriteria(getCurrentSession()).list();

			return list;
			}


	@Override
	public CourtAppearance loadLatestCourtAppearanceBySanctionId(Long sanctionId) {
		
		Query query = getCurrentSession().getNamedQuery("getLatestBySanctionId");
		query.setParameter("sanctionId", sanctionId);
		List result = query.list();
		return (CourtAppearance) (result != null && result.size() > 0 ? result.get(0) : null);
	}

}
