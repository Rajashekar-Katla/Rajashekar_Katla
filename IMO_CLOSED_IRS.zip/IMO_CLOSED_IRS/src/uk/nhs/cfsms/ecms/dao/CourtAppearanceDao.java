package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;

public interface CourtAppearanceDao extends BaseDao {

	public List<CourtAppearance> loadCourtAppearancesBySanctionId(
			Long sanctionId);
	
	
	public List<CourtAppearance> loadCourtAppearancesByType(
			Long sanctionId,String sanctionType);
	
	public CourtAppearance loadLatestCourtAppearanceBySanctionId(
			Long sanctionId);
}
