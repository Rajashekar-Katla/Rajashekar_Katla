package uk.nhs.cfsms.ecms.dao.hibernate;

import java.io.Serializable;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.PermissionGroupDao;
import uk.nhs.cfsms.ecms.data.common.PermissionGroup;

@Repository
public class HibernatePermissionGroupDao extends HibernateBaseDao implements
		PermissionGroupDao {

	public PermissionGroup save(PermissionGroup permissionGroup) {
		// Serializable s = getHibernateTemplate().save(permissionGroup);
//		Session session = this.getSession(false);
//		Serializable s = session.save(permissionGroup);
		Serializable s = getCurrentSession().save(permissionGroup);
		return permissionGroup;
	}

	public PermissionGroup load(long id) {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				PermissionGroup.class).add(Restrictions.eq("id", id));

		List pgList = criteria.getExecutableCriteria(getCurrentSession()).list();
		PermissionGroup pg = null;
		// PermissionGroup = (PermissionGroup)
		// getHibernateTemplate().load(PermissionGroup.class, new Long(id));
		if (null != pgList && !pgList.isEmpty()) {
			
			pg = (PermissionGroup) pgList.get(0);
		}
		return pg;

	}
}
