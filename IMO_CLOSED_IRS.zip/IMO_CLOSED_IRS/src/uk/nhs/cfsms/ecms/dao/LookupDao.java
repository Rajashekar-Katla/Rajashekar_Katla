package uk.nhs.cfsms.ecms.dao;

import uk.nhs.cfsms.ecms.data.common.Lookup;

public interface LookupDao {

	void save(Lookup lookup);

	void delete(Lookup lookup);

}
