package uk.nhs.cfsms.ecms.dao;

import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.ChargeList;

public interface ChargeListDao extends BaseDao {
	
	List<ChargeList> getChargeLists(Long criminalSanctionId);
	
	
}
