package uk.nhs.cfsms.ecms.dao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import uk.nhs.cfsms.ecms.data.cps.CpsMail;

public interface CpsMailDao {
	
	public Long save(final CpsMail mail);
	
	public List<CpsMail> getCpsMailDetails(final long caseID);
	
	public CpsMail getCpsMailDetailsByDate(final Date fromDate, final Date toDate);
	
	public Timestamp isDocumentSent(final String docGrpID);
	
	public void delete(final Long cpsMailID);

}
