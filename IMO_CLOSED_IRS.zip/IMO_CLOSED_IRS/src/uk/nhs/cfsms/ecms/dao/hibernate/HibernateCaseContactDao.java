package uk.nhs.cfsms.ecms.dao.hibernate;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.CaseContactDao;
import uk.nhs.cfsms.ecms.data.cim.CaseContact;
import uk.nhs.cfsms.ecms.data.cim.CaseContactStandalone;
import uk.nhs.cfsms.ecms.data.infoGath.Information;
import uk.nhs.cfsms.ecms.data.infoGath.SubjectInformation;
import uk.nhs.cfsms.ecms.data.witness.Witness;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.ConvertToDTO;

/**
 * Case Contact Hibernate Implementation.
 * 
 * @author sChilukuri
 * 
 */
@Repository
public class HibernateCaseContactDao extends HibernateBaseDao implements
		CaseContactDao {

	public CaseContactTO loadContactById(Long contactId) {

		CaseContact hibernate = findContactById(contactId);
		if (null != hibernate) {
			return ConvertToDTO.getInstance().convertToDTO(hibernate);
		}
		return null;
	}

	protected CaseContact findContactById(Long contactId) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseContact.class).add(Restrictions.idEq(contactId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<CaseContact> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		if (list != null && !list.isEmpty()) {
			return (CaseContact) list.get(0);
		}
		return null;
	}

	public CaseContact findContactByIdForWitnessLookupUser(final Long contactId) {

		CaseContact caseContact = null;

		final Criteria criteria = getCurrentSession().createCriteria(
				CaseContact.class);

		criteria.add(Restrictions.eq("contactId", contactId));
		criteria.add(Restrictions.isNotNull("caseId"));
//		criteria.add(Restrictions.isNotNull("infoId"));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("contactId"), "contactId");
		projectionList.add(Projections.property("caseId"), "caseId");
//		projectionList.add(Projections.property("infoId"), "infoId");
		projectionList.add(Projections.property("person"), "person");
		projectionList.add(Projections.property("createdDate"), "createdDate");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers
				.aliasToBean(CaseContact.class));

		@SuppressWarnings("unchecked")
		final List<CaseContact> list = criteria.list();

		if (null != list && !list.isEmpty()) {
			caseContact = list.get(0);
		}

		return caseContact;
	}

	public List<CaseContact> loadCaseContactByNativeSql(final String firstName,
			final String lastName, final String dob) throws ParseException {

		String personSQL = "select PERSON_ID from PERSON_TBL where lower(FIRST_NAME)=lower(:i_Fname) and lower(LAST_NAME)=lower(:i_Lname)";
		final List<CaseContact> caseContactList = new ArrayList<CaseContact>();
		String newDate = null;
		SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");

		if (!dob.isEmpty()) {
			personSQL = personSQL + " and DOB = :dob";

			SimpleDateFormat format1 = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date date = format1.parse(dob);
			newDate = format2.format(date.getTime());
		}

		final String caseContactIDQuery = "select CONTACT_ID FROM CASE_CONTACT_TBL WHERE CONTACT_PERSON_ID IN ("
				+ personSQL + ")";

		final SQLQuery query = getCurrentSession().createSQLQuery(
				caseContactIDQuery);
		query.setParameter("i_Fname", firstName);
		query.setParameter("i_Lname", lastName);

		if (!dob.isEmpty()) {
			query.setParameter("dob",
					new Date(format2.parse(newDate).getTime()));
		}

		@SuppressWarnings("unchecked")
		final List<BigDecimal> results = query.list();

		for (BigDecimal l : results) {
			CaseContact caseContact = findContactByIdForWitnessLookupUser(l
					.longValue());
			if (caseContact != null) {
				caseContact.setContactType("Contact");
				caseContactList.add(caseContact);
			}

		}

		return caseContactList;
	}

	public CaseContactTO saveContact(CaseContactTO contact) {
		CaseContactStandalone hibernate = ConvertFromDTO.getInstance()
				.convertFromDTO(contact, false);
		hibernate.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		hibernate.setUpdatedFlag("Y");
		hibernate = (CaseContactStandalone) getCurrentSession()
				.merge(hibernate);
		return ConvertToDTO.getInstance().convertToDTO(hibernate);
	}

	public void updateContact(CaseContactTO contact) {
		CaseContact hibernate = ConvertFromDTO.getInstance().convertFromDTO(
				contact);
		//this.getHibernateTemplate().saveOrUpdate(hibernate);
		getCurrentSession().merge(hibernate);
	}

	public void deleteContact(CaseContactTO contact) {

		CaseContact hibernate = this.findContactById(contact.getContactId());

		if (hibernate != null) {
			getCurrentSession().delete(hibernate);
		}
	}

	public void updateCaseContactToSubject(SubjectInformation subject) {

		Information hibernate = findInformationByCaseId(subject.getCaseId());
		List<SubjectInformation> subjects = hibernate.getSubjectInformation();
		subjects.add(subject);
		getCurrentSession().merge(hibernate);
	}

	public void updateCaseContactToWitness(Witness witness) {
		witness.setCreatedTime(new Timestamp(System.currentTimeMillis()));
		getCurrentSession().merge(witness);
	}

	public void mergeContact(CaseContactTO contactTO) {
		CaseContact hibernate = ConvertFromDTO.getInstance().convertFromDTO(
				contactTO);
		getCurrentSession().merge(hibernate);
	}

	private Information findInformationByCaseId(Long caseId) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(Information.class).add(
						Restrictions.eq("caseId", caseId));

		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<Information> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		if (list != null && !list.isEmpty()) {
			return (Information) list.get(0);
		}
		return null;
	}

	public List<CaseContactTO> loadContactsByInformation(Long informationId) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(CaseContact.class).add(
						Restrictions.eq("infoId", informationId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		return criteria.getExecutableCriteria(getCurrentSession()).list();

	}
}
