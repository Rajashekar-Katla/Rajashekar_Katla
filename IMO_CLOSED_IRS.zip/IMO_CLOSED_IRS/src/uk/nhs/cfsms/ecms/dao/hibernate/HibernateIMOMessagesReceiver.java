package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.IMOMessagesReceiverDao;
import uk.nhs.cfsms.ecms.data.common.IMOMessagesReceiver;

@Repository(value = "imoMessageReceiverRepository")
public class HibernateIMOMessagesReceiver extends HibernateBaseDao implements
		IMOMessagesReceiverDao {

	@Override
	public String getActiveStaffId() {
		Session session = getCurrentSession();
		Query query = session
				.createQuery("select imoStaffId from IMOMessagesReceiver where status = :active");
		query.setParameter("active", "A");
		String imoStaffId = (String) query.list().get(0);
		return imoStaffId;
	}

	@Override
	public void activateUserToReceiveMessages(final String staffId) {
		deActivateExistingActiveUser();
		activateUser(staffId);
	}

	private void deActivateExistingActiveUser() {
		final String activeStaffId = getActiveStaffId();
		Session session = getCurrentSession();
		Query update = session
				.createQuery("update IMOMessagesReceiver set status=:active where IMO_STAFF_ID = :staffId");
		update.setParameter("active", "D");
		update.setParameter("staffId", activeStaffId);
	}

	private void activateUser(final String staffId) {
		Session session = getCurrentSession();
		Query query = session
				.createQuery("update IMOMessagesReceiver set status=:active where IMO_STAFF_ID = :staffId");
		query.setParameter("active", "A");
		query.setParameter("staffId", staffId);
	}

	@Override
	public List<IMOMessagesReceiver> getAllIMOMessageReceivers() {
		final DetachedCriteria criteria = DetachedCriteria
				.forClass(IMOMessagesReceiver.class);
		@SuppressWarnings("unchecked")
		final List<IMOMessagesReceiver> list = criteria.getExecutableCriteria(
				getCurrentSession()).list();

		return list	;
	}

}
