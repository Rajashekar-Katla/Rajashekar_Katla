package uk.nhs.cfsms.ecms.dao.hibernate;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.SubjectDao;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.infoGath.NHSSubjectInformation;
import uk.nhs.cfsms.ecms.data.infoGath.NonNHSSubjectInformation;
import uk.nhs.cfsms.ecms.data.infoGath.SubjectInformation;
import uk.nhs.cfsms.ecms.dto.infoGath.NHSSubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.NonNHSSubjectInformationTO;
import uk.nhs.cfsms.ecms.dto.infoGath.SubjectInformationTO;
import uk.nhs.cfsms.ecms.utility.ConvertFromDTO;
import uk.nhs.cfsms.ecms.utility.ConvertToDTO;

@Repository
public class HibernateSubjectDao extends HibernateBaseDao implements SubjectDao {

	protected final Log logger = LogFactory.getLog(getClass());

	public SubjectInformationTO insertSubjectInformation(
			SubjectInformationTO dto) {

		if (dto.getSubjectId() == null) {

			SubjectInformation hibernate = ConvertFromDTO.getInstance()
					.convertFromDTO(dto);

			return ConvertToDTO.getInstance().convertToDTO(
					(SubjectInformation) getCurrentSession().merge(hibernate));
		}
		return dto;
	}

	/**
	 * Load Subject by subject Id.
	 * 
	 */
	public SubjectInformationTO loadSubjectInformationById(
			SubjectInformation subject) {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				SubjectInformation.class).add(
				Restrictions.idEq(subject.getSubjectId()));

		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List subjectList = criteria.getExecutableCriteria(getCurrentSession())
				.list();

		SubjectInformationTO[] subjectArray = convertToDTO(subjectList);

		if (subjectArray != null && subjectArray.length > 0) {
			return subjectArray[0];
		}

		return null;
	}

	public SubjectInformationTO loadSubjectInformationByCaseId(final Long caseId) {

		DetachedCriteria criteria = DetachedCriteria
				.forClass(SubjectInformation.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		@SuppressWarnings("unchecked")
		final List<SubjectInformation> subjectList = criteria
				.getExecutableCriteria(getCurrentSession()).list();

		SubjectInformationTO[] subjectArray = convertToDTO(subjectList);

		if (subjectArray != null && subjectArray.length > 0) {
			return subjectArray[0];
		}

		return null;
	}

	private SubjectInformationTO[] convertToDTO(List hibernateList) {
		Iterator iter = hibernateList.iterator();
		List<SubjectInformationTO> list = new ArrayList<SubjectInformationTO>();
		while (iter.hasNext()) {
			SubjectInformation hibernate = (SubjectInformation) iter.next();

			SubjectInformationTO dto = ConvertToDTO.getInstance().convertToDTO(
					hibernate);

			list.add(dto);
		}
		return list.toArray(new SubjectInformationTO[list.size()]);
	}

	public NHSSubjectInformationTO LoadNHSSubjectInformationById(
			NHSSubjectInformation subject) {
		// TODO Auto-generated method stub
		return null;
	}

	public NHSSubjectInformationTO insertNHSSubjectInformation(
			NHSSubjectInformationTO dto) {

		if (dto.getSubjectNHSId() == null) {

			NHSSubjectInformation hibernate = ConvertFromDTO.getInstance()
					.convertFromDTO(dto);

			Organisation org = hibernate.getOrganisation();

			// Get the organisation.
			DetachedCriteria criteria = DetachedCriteria.forClass(
					Organisation.class)
					.add(Restrictions.idEq(org.getOrgCode()));

			criteria = criteria
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

			List list = criteria.getExecutableCriteria(getCurrentSession())
					.list();

			if (null != list && !list.isEmpty()) {
				org = (Organisation) list.get(0);
			}
			hibernate.setOrganisation(org);

			return ConvertToDTO.getInstance().convertToDTO(
					(NHSSubjectInformation) getCurrentSession()
							.merge(hibernate));
		}
		return dto;
	}

	public NonNHSSubjectInformationTO loadNonNHSSubjectInformationById(
			NonNHSSubjectInformation subject) {
		// TODO Auto-generated method stub
		return null;
	}

	public NonNHSSubjectInformationTO insertNonNHSSubjectInformation(
			NonNHSSubjectInformationTO dto) {

		if (dto.getSubjectNonNhsId() == null) {
			NonNHSSubjectInformation hibernate = ConvertFromDTO.getInstance()
					.convertFromDTO(dto);

			return ConvertToDTO.getInstance().convertToDTO(
					(NonNHSSubjectInformation) getCurrentSession().merge(
							hibernate));
		}
		return dto;
	}

	public List<SubjectInformation> loadInformationSubjectByNativeSql(
			final String firstName, final String lastName, final String dob)
			throws ParseException {

		String personSQL = "select PERSON_ID from PERSON_TBL where lower(FIRST_NAME)=lower(:i_Fname) and lower(LAST_NAME)=lower(:i_Lname)";
		final List<SubjectInformation> subjectInformationList = new ArrayList<SubjectInformation>();
		String newDate = null;
		final SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");

		if (!dob.isEmpty()) {
			personSQL = personSQL + " and DOB = :dob";

			SimpleDateFormat format1 = new SimpleDateFormat("dd/MM/yyyy");
			Date date = format1.parse(dob);
			newDate = format2.format(date.getTime());
		}

		final String informationSubjectIDQuery = "select SUBJECT_ID FROM INFORMATION_SUBJECT_TBL WHERE SUBJECT_PERSON_ID IN ("
				+ personSQL + ")";

		final SQLQuery query = getCurrentSession().createSQLQuery(
				informationSubjectIDQuery);
		query.setParameter("i_Fname", firstName);
		query.setParameter("i_Lname", lastName);

		if (!dob.isEmpty()) {
			query.setParameter("dob",
					new Date(format2.parse(newDate).getTime()));
		}

		@SuppressWarnings("unchecked")
		final List<BigDecimal> results = query.list();

		for (BigDecimal l : results) {
			final SubjectInformation subjectInformation = loadSubjectById(l
					.longValue());
			if (subjectInformation != null) {
				subjectInformation.setSubjectType("Subject");
				subjectInformationList.add(subjectInformation);
			}

		}

		return subjectInformationList;
	}

	/** Subject Information (PERSON) **/

	public SubjectInformation loadSubjectById(SubjectInformation subject) {

		DetachedCriteria criteria = DetachedCriteria.forClass(
				SubjectInformation.class).add(
				Restrictions.idEq(subject.getSubjectId()));

		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		@SuppressWarnings("unchecked")
		List<SubjectInformation> subjectList = criteria.getExecutableCriteria(
				getCurrentSession()).list();
		if (null != subjectList && !subjectList.isEmpty()) {
			return subjectList.get(0);
		}

		return null;
	}

	/** Subject Information (PERSON) **/

	public SubjectInformation loadSubjectById(final long subjectId) {

		SubjectInformation subjectInformation = null;

		final Criteria criteria = getCurrentSession().createCriteria(
				SubjectInformation.class);

		criteria.add(Restrictions.eq("subjectId", subjectId));
		criteria.add(Restrictions.isNotNull("caseId"));
//		criteria.add(Restrictions.isNotNull("information"));

		final ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("subjectId"), "subjectId");
		projectionList.add(Projections.property("caseId"), "caseId");
//		projectionList.add(Projections.property("information"), "information");
		projectionList.add(Projections.property("subjectPerson"),
				"subjectPerson");

		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers
				.aliasToBean(SubjectInformation.class));

		@SuppressWarnings("unchecked")
		final List<SubjectInformation> list = criteria.list();

		if (null != list && !list.isEmpty()) {
			subjectInformation = list.get(0);
		}

		return subjectInformation;
	}

	public SubjectInformation insertSubject(SubjectInformation subject) {

		return (SubjectInformation) getCurrentSession().merge(subject);
	}

	public void removeSubject(SubjectInformation subject) {

		getCurrentSession().delete(subject);
	}

	public SubjectInformation updateSubject(SubjectInformation hibernate) {

		return (SubjectInformation) getCurrentSession().merge(hibernate);
	}

	/** NHS Subject Information **/

	public NHSSubjectInformation LoadNHSSubjectById(
			NHSSubjectInformation subject) {
		DetachedCriteria crt = DetachedCriteria.forClass(
				NHSSubjectInformation.class).add(
				Restrictions.idEq(subject.getSubjectNHSId()));

		crt = crt.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<NHSSubjectInformation> subjectList = crt.getExecutableCriteria(
				getCurrentSession()).list();
		if (null != subjectList && !subjectList.isEmpty()) {
			return subjectList.get(0);
		}

		return null;
	}

	public NHSSubjectInformation insertSubject(NHSSubjectInformation subject) {

		return (NHSSubjectInformation) getCurrentSession().merge(subject);
	}

	public NHSSubjectInformation updateSubject(NHSSubjectInformation subject) {

		return (NHSSubjectInformation) getCurrentSession().merge(subject);
	}

	public void removeSubject(NHSSubjectInformation subject) {

		getCurrentSession().delete(subject);
	}

	/** NON-NHS Subject Information **/

	public NonNHSSubjectInformation LoadNHSSubjectById(
			NonNHSSubjectInformation subject) {
		DetachedCriteria criteria = DetachedCriteria.forClass(
				NonNHSSubjectInformation.class).add(
				Restrictions.idEq(subject.getSubjectNonNhsId()));

		criteria = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<NonNHSSubjectInformation> subjectList = criteria
				.getExecutableCriteria(getCurrentSession()).list();
		if (null != subjectList && !subjectList.isEmpty()) {
			return subjectList.get(0);
		}

		return null;
	}

	public NonNHSSubjectInformation insertSubject(
			NonNHSSubjectInformation subject) {

		subject = (NonNHSSubjectInformation) getCurrentSession().merge(subject);

		return subject;
	}

	public NonNHSSubjectInformation updateSubject(
			NonNHSSubjectInformation subject) {
		return (NonNHSSubjectInformation) getCurrentSession().merge(subject);
	}

	public void removeSubject(NonNHSSubjectInformation subject) {
		getCurrentSession().delete(subject);
		//getHibernateTemplate().delete(subject);
	}

}
