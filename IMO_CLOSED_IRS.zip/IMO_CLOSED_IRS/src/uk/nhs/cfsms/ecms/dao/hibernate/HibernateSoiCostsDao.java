package uk.nhs.cfsms.ecms.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.cfsms.ecms.dao.SoiCostsDao;
import uk.nhs.cfsms.ecms.data.cim.CaseCourtCosts;
import uk.nhs.cfsms.ecms.data.cim.ExpectedCourtCost;
import uk.nhs.cfsms.ecms.data.cim.SoiCosts;

@Repository
public class HibernateSoiCostsDao extends HibernateBaseDao implements
		SoiCostsDao {

	public SoiCosts saveSoiCosts(SoiCosts soiCost) {
		saveObject(soiCost);
		return soiCost;
	}

	public SoiCosts loadSoiCosts(Long costId) {

		return (SoiCosts) getObject(SoiCosts.class, costId);
	}

	public SoiCosts updateSoiCosts(SoiCosts soicost) {

		saveObject(soicost);
		return soicost;
	}

	public SoiCosts loadSoiCostsByCaseId(Long caseId) {

		 
		Session session = getCurrentSession();
		
		Query query = session.createQuery("from SoiCosts where caseId =:caseId")
				.setLong("caseId", caseId);
		
		List<SoiCosts> list = query.list(); 
		
		if (null != list && !list.isEmpty()) {
			return (SoiCosts) list.get(0);
		}
		return null;
	}

	public List<CaseCourtCosts> saveCourtCosts(List<CaseCourtCosts> caseCourtCosts) {
		
		saveObjects(caseCourtCosts);
		
		return caseCourtCosts;

	}

	public List<CaseCourtCosts> loadCourtCaseCostsByCaseId(Long caseId) {
		
		DetachedCriteria criteria = DetachedCriteria.forClass(CaseCourtCosts.class);
		criteria.add(Restrictions.eq("caseId", caseId));
		criteria.addOrder(Order.asc("expctCostId"));
		
		List<CaseCourtCosts> list= criteria.getExecutableCriteria(getCurrentSession()).list();
		
		return  list;

	}

	public List<ExpectedCourtCost> loadExpectedCourtCosts() {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(ExpectedCourtCost.class);
		criteria.addOrder(Order.asc("expctCourtCostId"));
		List<ExpectedCourtCost> list = criteria.getExecutableCriteria(getCurrentSession()).list();
		return list;

	}

	public void deleteCourtCosts(List<CaseCourtCosts> costs) {

		deleteObjects(costs);
	}

}
