package uk.nhs.cfsms.ecms.authentication;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.acegisecurity.userdetails.UserDetails;
import org.acegisecurity.userdetails.UsernameNotFoundException;
import org.acegisecurity.userdetails.jdbc.JdbcDaoImpl;
import org.springframework.dao.DataAccessException;

@Deprecated
public class AuthenticationJdbcDaoImpl extends JdbcDaoImpl {
	
	@Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException, DataAccessException{
		
      	UserDetails user = super.loadUserByUsername(username);
      	
        return new CustomUser(user.getUsername(), user.getPassword(), user.isEnabled(), user.getAuthorities());       
    }
	
	private static String convertToHex(byte[] data) {
		
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < data.length; i++) {
        	int halfbyte = (data[i] >>> 4) & 0x0F;
        	int two_halfs = 0;
        	do {
	            if ((0 <= halfbyte) && (halfbyte <= 9))
	                buf.append((char) ('0' + halfbyte));
	            else
	            	buf.append((char) ('a' + (halfbyte - 10)));
	            halfbyte = data[i] & 0x0F;
        	} while(two_halfs++ < 1);
        }
        return buf.toString();
    }
 
    private static String SHA512(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException  {
    	MessageDigest md;
    	md = MessageDigest.getInstance("SHA-1");
    	byte[] sha1hash = new byte[40];
    	md.update(text.getBytes("iso-8859-1"), 0, text.length());
    	sha1hash = md.digest();
    	
    	String hex = convertToHex(sha1hash);
    	String res = Base64.encodeBytes(sha1hash);
    	
    	return hex;
    	
    }

	private synchronized static String encrypt(String plaintext) throws Exception {
		MessageDigest md = null;
	    try {
	    	//get an instance using SHA 
	    	md = MessageDigest.getInstance("SHA-1"); 
	    	//convert the plain text password to a byte array using UTF8 as its encoding 
	    	//this array is what the md will operate on, its source of data. 
	    	md.update(plaintext.getBytes("UTF-8"));
	    	//md.update(plaintext.getBytes("iso-8859-1"));
	    }
	    catch(NoSuchAlgorithmException e) {
    		//if the environment does not support SHA
	    	e.printStackTrace();
	    }
	    catch(UnsupportedEncodingException e) {
	    	//if utf8 is not supported in the environment 
	    	e.printStackTrace();
	    }

	    //transform the password into an array of encrypted bytes 
	    byte raw[] = md.digest();
	    
	    //create a string representation of the bytes so we can store it in a database, we will use 
	    //our 'own' method.
	    String hash = Base64.encodeBytes(raw);
	    return hash; 
    }


  }