package uk.nhs.cfsms.ecms.authentication;
import org.acegisecurity.GrantedAuthority;
import org.acegisecurity.userdetails.User;

/*
 * ACEGI security user class object
 * 
 * Author: Ronan Tobin
 * 
 * REF: As per recommendations by spring - see ACEGI CustomUser
 */


public class CustomUser extends User 
{
    
	private static final long serialVersionUID = 1L;
	
	private Object userInfo;
    
    public CustomUser(String username, String password, boolean isEnabled,
            GrantedAuthority[] authorities, Object u) {
        super(username, password, isEnabled, true, true, true, authorities);
        this.setUserInfo(u);
        
    }

    public CustomUser(String username, String password, boolean isEnabled, GrantedAuthority[] arrayAuths) {
        super(username, password, isEnabled, true, true, true, arrayAuths);
        
    }
   
    public Object getUserInfo() {
        return userInfo;
    }
    
    public void setUserInfo(Object userInfo) {
        this.userInfo = userInfo;
    }
	

}
