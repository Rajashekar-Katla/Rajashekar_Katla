package uk.nhs.cfsms.ecms.authentication;
import org.acegisecurity.context.SecurityContextHolder;

/*
 * ACEGI security user class object
 * 
 * Author: Ronan Tobin
 * 
 * REF: As per recommendations by spring - see ACEGI CurrentUser
 */

public class CurrentUser {
	    
	    
	    public CustomUser getUser() {
	        CustomUser user = (CustomUser) (SecurityContextHolder.getContext().getAuthentication().getPrincipal());
	        if(user != null)
	        {
	        	
	            return user;
	        }
	        else{
	            return null;
	        }
	    }
	}

