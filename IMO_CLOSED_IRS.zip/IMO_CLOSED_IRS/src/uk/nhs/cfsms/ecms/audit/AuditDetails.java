package uk.nhs.cfsms.ecms.audit;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;

@Entity
@Table(name = "AUDIT_VIEW")
public class AuditDetails extends CustomTrackingRevisionEntity {

	@Column(name = "USER_NAME")
	private String userName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getRevisionTime() {
		return new Date(getCustomTimestamp());
	}

	public String getModifiedEntities() {

		StringBuilder names = new StringBuilder();
		Set<String> entities = getModifiedEntityNames();
		boolean firstTime = true;

		if (null != entities && !entities.isEmpty()) {

			for (String curr : entities) {

				if (!firstTime) {

					names.append(",").append(extractClassName(curr));
				} else {

					names.append(extractClassName(curr));
					firstTime = false;
				}
			}
		}
		return names.toString();
	}

	private String extractClassName(String name) {

		if (StringUtils.isNotBlank(name)) {

			int lastPeriod = StringUtils.lastIndexOf(name, ".");

			if (lastPeriod >= 0) {

				name = name.substring(lastPeriod + 1);
			}
		}
		return name == null ? "" : name;
	}

	@Override
	public String toString() {
		String flow = getFlowName() == null ? "" : getFlowName();
		StringBuilder builder = new StringBuilder(flow + " \t " + userName
				+ " \t " + getRevisionTime());
		/*
		 * List<RevisionedEntityInfo> revList = getRevisionInfoList();
		 * if(revList != null && !revList.isEmpty()){ for(RevisionedEntityInfo
		 * curr : revList){ builder.append(curr.toString()); } }
		 */

		return builder.toString();

	}

}
