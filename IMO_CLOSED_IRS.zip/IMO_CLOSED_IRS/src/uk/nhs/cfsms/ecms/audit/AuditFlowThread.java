package uk.nhs.cfsms.ecms.audit;

import java.io.Serializable;

public class AuditFlowThread implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5138394377244184476L;

	private static final ThreadLocal<String> FLOWID = new ThreadLocal<String>() {
		protected String initialValue() {
			return null;
		}
	};

	public static void set(String flowId) {
		FLOWID.set(flowId);
	}

	public static String get() {
		return FLOWID.get();
	}

	public static void remove() {
		FLOWID.remove();
	}
}
