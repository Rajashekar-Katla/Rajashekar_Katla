package uk.nhs.cfsms.ecms.audit;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.ModifiedEntityNames;
import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.RevisionNumber;
import org.hibernate.envers.RevisionTimestamp;

@Entity
@Table(name = "REVISION_HISTORY")
@RevisionEntity(FirstCustomRevisionListener.class)
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class CustomTrackingRevisionEntity {

	@Id
	@GeneratedValue
	@RevisionNumber
	@Column(name = "REV")
	private int customId;

	@Column(name = "REVTSTMP")
	@RevisionTimestamp
	private long customTimestamp;

	@Column(name = "USER_ID")
	private String userId;

	@Column(name = "CASE_ID")
	private Long caseId;

	@Column(name = "INFORMATION_ID")
	private Long informationId;

	@Column(name = "FLOW_NAME")
	private String flowName;

	@ElementCollection(fetch = FetchType.EAGER)
	@JoinTable(name = "REVCHANGES", joinColumns = @JoinColumn(name = "REV"))
	@Column(name = "ENTITYNAME")
	@ModifiedEntityNames
	private Set<String> modifiedEntityNames;

	// @Column(name="TABLENAME")
	@Transient
	private String tableName;
	
	@Transient
	private List<RevisionedEntityInfo> revisionInfoList;

	
	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Set<String> getModifiedEntityNames() {
		return modifiedEntityNames;
	}

	public void setModifiedEntityNames(Set<String> modifiedEntityNames) {
		this.modifiedEntityNames = modifiedEntityNames;
	}

	public int getCustomId() {
		return customId;
	}

	public long getCustomTimestamp() {
		return customTimestamp;
	}

	public void setCustomTimestamp(long customTimestamp) {
		this.customTimestamp = customTimestamp;
	}

	public void setCustomId(int customId) {
		this.customId = customId;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFlowName() {
		return flowName;
	}

	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}

	public List<RevisionedEntityInfo> getRevisionInfoList() {
		if(revisionInfoList == null){
			revisionInfoList = new ArrayList<RevisionedEntityInfo>();
		}
		return revisionInfoList;
	}
    
	
	
	public void setRevisionInfoList(List<RevisionedEntityInfo> revisionInfoList) {
		this.revisionInfoList = revisionInfoList;
	}

	/*
	 * @OneToMany(mappedBy="revision", cascade={CascadeType.PERSIST,
	 * CascadeType.REMOVE}) private Set<ModifiedEntityTypeEntity>
	 * modifiedEntityTypes = new HashSet<ModifiedEntityTypeEntity>();
	 */

}
