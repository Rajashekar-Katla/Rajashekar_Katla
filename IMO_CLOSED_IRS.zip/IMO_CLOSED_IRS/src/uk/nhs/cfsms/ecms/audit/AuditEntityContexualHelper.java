package uk.nhs.cfsms.ecms.audit;

import javax.persistence.EntityManager;

import org.hibernate.Session;

import uk.nhs.cfsms.ecms.data.cim.CaseCourtCosts;
import uk.nhs.cfsms.ecms.data.cim.ExpectedCourtCost;
import uk.nhs.cfsms.ecms.data.infoGath.SubjectInformation;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanction;

public class AuditEntityContexualHelper {

	
	public static String getSubForCiminalSanction(EntityManager factory, CriminalSanction sanction) {
		
		Session session = factory.unwrap(Session.class);
		
		if (null != sanction && sanction.getSubjectId() != null) {
			
			SubjectInformation subject = (SubjectInformation) session.get(SubjectInformation.class,
							sanction.getSubjectId());

			return subject == null ? null : subject.getAssociatedID();
		}
		return null;
	}

	
	public static String getCaseCourtExpectedCost(EntityManager factory, CaseCourtCosts caseCourtCost) {
		Session session = factory.unwrap(Session.class);
		if (null != caseCourtCost && caseCourtCost.getExpctCostId() != null) {
		
			ExpectedCourtCost entity = (ExpectedCourtCost) session.get(ExpectedCourtCost.class,
							caseCourtCost.getExpctCostId());
			
			return entity == null ? null : caseCourtCost.getExpctCostId()
					+ " Desc -> " + entity.getDescription();
		}
		return null;
	}

}
