package uk.nhs.cfsms.ecms.audit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;


public class RevisionedEntityInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6770783765388156210L;

	private String operationType;
	
	private String entityName;
	
	private String keyDetails;	
	
	private List<AuditedPropertyInfo> propertiesList = new ArrayList<AuditedPropertyInfo>();
	
	private String primaryKey;
	
	public RevisionedEntityInfo() {
		// TODO Auto-generated constructor stub
	}

	public List<AuditedPropertyInfo> getPropertiesList() {
		return propertiesList;
	}

	public void setPropertiesList(List<AuditedPropertyInfo> propertiesList) {
		this.propertiesList = propertiesList;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getKeyDetails() {
		return  StringUtils.isNotBlank(keyDetails) ? keyDetails : null;
	}

	public void setKeyDetails(String keyDetails) {
		this.keyDetails = keyDetails;
	}

	public String getPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(String primaryKey) {
		this.primaryKey = primaryKey;
	}

	@Override
	public String toString(){
		String opType = getOperationType() ==  null? "" : getOperationType();
		StringBuilder desplayVal =   new StringBuilder(opType  + "\\n " );
		for(AuditedPropertyInfo curr :  propertiesList){
			desplayVal.append("\\n");
			desplayVal.append(curr.toString());
		}
		
		return desplayVal.toString();
	}
}
