package uk.nhs.cfsms.ecms.audit;

public class CaseIdThreadLocal {

	private static final ThreadLocal<Long> CASEID = new ThreadLocal<Long>() {
		protected Long initialValue() {
			return null;
		}
	};

	public static void set(Long id) {
		CASEID.set(id);
	}

	public static Long get() {
		return CASEID.get();
	}

	public static void remove() {
		CASEID.remove();
	}
}
