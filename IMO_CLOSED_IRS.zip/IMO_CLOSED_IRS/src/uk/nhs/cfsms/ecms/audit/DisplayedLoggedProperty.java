/**
 * 
 */
package uk.nhs.cfsms.ecms.audit;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author VDabas
 * 
 */
@Retention(value = RetentionPolicy.RUNTIME)
@Target(value = { ElementType.TYPE, ElementType.FIELD, ElementType.METHOD })
public @interface DisplayedLoggedProperty {

	String displayName() default "";

	String detailsMethod() default "";

	boolean isList() default false;

	String listType() default "LOOK_UP_TABLE";
}
