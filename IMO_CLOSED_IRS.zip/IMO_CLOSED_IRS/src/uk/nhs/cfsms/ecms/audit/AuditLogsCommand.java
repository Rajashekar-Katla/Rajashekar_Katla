package uk.nhs.cfsms.ecms.audit;

import java.io.Serializable;

public class AuditLogsCommand implements Serializable {

	
	private static final long serialVersionUID = 954764834301L;

	private String logType;

	private Long entityId;

	private Integer revisionID;
	

	public String getLogType() {
		return logType;
	}

	public void setLogType(String logType) {
		this.logType = logType;
	}

	public Long getEntityId() {
		return entityId;
	}

	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}

	public Integer getRevisionID() {
		return revisionID;
	}

	public void setRevisionID(Integer revisionID) {
		this.revisionID = revisionID;
	}

}
