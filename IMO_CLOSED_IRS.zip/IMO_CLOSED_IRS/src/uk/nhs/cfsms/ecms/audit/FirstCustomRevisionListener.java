package uk.nhs.cfsms.ecms.audit;

import java.io.Serializable;
import java.lang.reflect.Method;
import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.envers.EntityTrackingRevisionListener;
import org.hibernate.envers.RevisionType;

import uk.nhs.cfsms.ecms.utility.EcmsUtils;


public class FirstCustomRevisionListener implements EntityTrackingRevisionListener {

	private static final String GET_INFORMATION_ID = "getInformationId";

	private static final String GET_CASE_ID = "getCaseId";

	private static EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		FirstCustomRevisionListener.entityManager = entityManager;
	}

	public FirstCustomRevisionListener() {

	}

	@Override
	public void newRevision(Object arg0) {

		CustomTrackingRevisionEntity revEntity = (CustomTrackingRevisionEntity) arg0;
		revEntity.setFlowName(AuditFlowThread.get());
		revEntity.setCaseId(CaseIdThreadLocal.get());
		revEntity.setInformationId(InformationIdThreadLocal.get());
	}

	@Override
	public void entityChanged(Class entityClass, String entityName,
			Serializable entityId, RevisionType revisionType,
			Object revisionEntity) {

		// String type = entityClass.getName();
		Method caseMethod = null;
		Method informationMethod = null;
		try {
			CustomTrackingRevisionEntity revEntity = (CustomTrackingRevisionEntity) revisionEntity;

			if (null != revEntity) {

				if (null != EcmsUtils.getPrincipal()) {
					revEntity.setUserId(EcmsUtils.getPrincipal().getUsername());
				}
				else {
					//TODO: need to check
					revEntity.setUserId("ops9999");
				}

				caseMethod = getMethodWithName(entityClass.getMethods(), GET_CASE_ID);
				informationMethod = getMethodWithName(entityClass.getMethods(), GET_INFORMATION_ID);
				Session session = getEntityManager().unwrap(Session.class);
				Object entity = session.get(entityClass, entityId);

				if (revEntity.getCaseId() == null && caseMethod != null) {
					Object caseId = null;
					if(entity != null){
						caseId = caseMethod.invoke(entity);
						revEntity.setCaseId((Long) caseId);
					}
					else{
						revEntity.setCaseId((Long) entityId);
					}
				}

				if (revEntity.getInformationId() == null && informationMethod != null) {
					Object informationId = null;
					if(entity != null){
						informationId = informationMethod.invoke(entity);
						revEntity.setInformationId((Long) informationId);
					}
					else{
						revEntity.setInformationId((Long) entityId);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			entityManager.clear();
		}
	}

	private Method getMethodWithName(Method[] methods, String methodName) {

		if (null != methods) {

			for (Method curr : methods) {

				if (curr.getName().equalsIgnoreCase(methodName)) {

					return curr;
				}
			}
		}
		return null;
	}

}
