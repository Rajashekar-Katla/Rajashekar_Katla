package uk.nhs.cfsms.ecms.audit;

public class AuditedPropertyInfo {

	private String propertyName;

	private String previousValue;

	private String modifiedValue;

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getPreviousValue() {
		return previousValue;
	}

	public void setPreviousValue(String previousValue) {
		this.previousValue = previousValue;
	}

	public String getModifiedValue() {
		return modifiedValue;
	}

	public void setModifiedValue(String modifiedValue) {
		this.modifiedValue = modifiedValue;
	}

	public String toString(){
		return propertyName  + " \\t" +  previousValue  +  " \\t"  +   modifiedValue;
	}
}