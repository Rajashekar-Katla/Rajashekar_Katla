package uk.nhs.cfsms.ecms.audit;

public class InformationIdThreadLocal {

	private static final ThreadLocal<Long> information = new ThreadLocal<Long>() {
		protected Long initialValue() {
			return null;
		}
	};

	public static void set(Long informationId) {
		information.set(informationId);
	}

	public static Long get() {
		return information.get();
	}

	public static void remove() {
		information.remove();
	}
}
