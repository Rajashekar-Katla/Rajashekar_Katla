package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;
import java.util.Date;

public class InformationProgressTO implements Serializable {

	private static final long serialVersionUID = 702756064553267905L;

	private Long informationProgressId;

	private Long informationId;

	private String recordedBy;

	private Long minuteNumber;

	private Date dateOfEvent;

	private Date dateRecorded;

	private String description;

	private String createdStaffId;

	private String type;

	private Date createdTime;

	private String progressSheetRefersTo;

	public Long getInformationProgressId() {
		return informationProgressId;
	}

	public void setInformationProgressId(Long informationProgressId) {
		this.informationProgressId = informationProgressId;
	}

	public String getRecordedBy() {
		return recordedBy;
	}

	public void setRecordedBy(String recordedBy) {
		this.recordedBy = recordedBy;
	}

	public Long getMinuteNumber() {
		return minuteNumber;
	}

	public void setMinuteNumber(Long minuteNumber) {
		this.minuteNumber = minuteNumber;
	}

	public Date getDateOfEvent() {
		return dateOfEvent;
	}

	public void setDateOfEvent(Date dateOfEvent) {
		this.dateOfEvent = dateOfEvent;
	}

	public Date getDateRecorded() {
		return dateRecorded;
	}

	public void setDateRecorded(Date dateRecorded) {
		this.dateRecorded = dateRecorded;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getProgressSheetRefersTo() {
		return progressSheetRefersTo;
	}

	public void setProgressSheetRefersTo(String progressSheetRefersTo) {
		this.progressSheetRefersTo = progressSheetRefersTo;
	}

	@Override
	public String toString() {
		return "InformationProgressTO [informationProgressId="
				+ informationProgressId + ", informationId=" + informationId
				+ ", recordedBy=" + recordedBy + ", minuteNumber="
				+ minuteNumber + ", dateOfEvent=" + dateOfEvent
				+ ", dateRecorded=" + dateRecorded + ", description="
				+ description + ", createdStaffId=" + createdStaffId
				+ ", type=" + type + ", createdTime=" + createdTime
				+ ", progressSheetRefersTo=" + progressSheetRefersTo + "]";
	}

}
