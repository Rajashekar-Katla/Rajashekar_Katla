package uk.nhs.cfsms.ecms.dto.caseInfo;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.InvestigationActionPlan;
import uk.nhs.cfsms.ecms.utility.CaseUtil;

/**
 * InvestigationTO is a transfer object for InvestigationPlan
 * 
 */
public class InvestigationTO implements Serializable {

	private Long investigationId;

	private Long caseId;

	private Date allegationDate;

	private String allegationSummary;

	private String allegationOffences;

	private Timestamp createdDate;

	private String createdStaffId;

	private List<InvestigationActionPlan> investigationActionList = new ArrayList<InvestigationActionPlan>();
	
	public InvestigationTO() {
		super();
	}

	public Date getAllegationDate() {
		return allegationDate;
	}

	public void setAllegationDate(Date allegationDate) {
		this.allegationDate = allegationDate;
	}

	public String getAllegationOffences() {
		return allegationOffences;
	}

	public void setAllegationOffences(String allegationOffences) {
		this.allegationOffences = CaseUtil.replaceNewline(allegationOffences);
	}

	public String getAllegationSummary() {
		return allegationSummary;
	}

	public void setAllegationSummary(String allegationSummary) {
		this.allegationSummary = CaseUtil.replaceNewline(allegationSummary);
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Long getInvestigationId() {
		return investigationId;
	}

	public void setInvestigationId(Long investigationId) {
		this.investigationId = investigationId;
	}

	public List<InvestigationActionPlan> getInvestigationActionList() {
		return investigationActionList;
	}

	public void setInvestigationActionList(
			List<InvestigationActionPlan> investigationActionList) {
		this.investigationActionList = investigationActionList;
	}

}
