package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

public class NHSSubjectInformationTO  implements Serializable{

	private Long subjectNHSId;

	private Long informationTO;

	private Long caseId;

	private String subjectType;

	private String orgCode;

	private String orgName;

	private String location;

	private String place;

	private String additionalInfo;

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public Long getSubjectNHSId() {
		return subjectNHSId;
	}

	public void setSubjectNHSId(Long subjectNHSId) {
		this.subjectNHSId = subjectNHSId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	public Long getInformationTO() {
		return informationTO;
	}

	public void setInformationTO(Long informationTO) {
		this.informationTO = informationTO;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	/**
	 * Has valid Organisation code.
	 * 
	 * @return boolean.
	 */
	public boolean hasValidOrgCode() {

		if (orgCode != null && StringUtils.isNotEmpty(orgCode)
				&& orgCode.indexOf(",") == -1) {
			return true;
		}
		return false;
	}
}
