package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.utility.CaseUtil;

/**
 * Disciplinary Offence Tranfer Object
 *
 */
public class DisciplinaryOffenceTO  implements Serializable{

	private Long offenceId;

	private Long disciplinarySanctionId;

	private String offenceDetails;
	
	private String createdStaffId;

	private Date createdTime;
	

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getDisciplinarySanctionId() {
		return disciplinarySanctionId;
	}

	public void setDisciplinarySanctionId(Long disciplinarySanctionId) {
		this.disciplinarySanctionId = disciplinarySanctionId;
	}

	/*public  char[] getOffenceDetails() {
		if(null != offenceDetailsString && offenceDetailsString.length()>0)
		{
			offenceDetails=Hibernate.createClob(offenceDetailsString);
			
			
		}
		return offenceDetails;
	}*/

	public  String getOffenceDetails() {
		
		return offenceDetails;
	}
	
	public void setOffenceDetails(String  offenceDetails) {
		this.offenceDetails = CaseUtil.replaceNewline(offenceDetails);
		
	}

	public Long getOffenceId() {
		return offenceId;
	}

	public void setOffenceId(Long offenceId) {
		this.offenceId = offenceId;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	

	
}
