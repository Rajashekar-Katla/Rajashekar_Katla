package uk.nhs.cfsms.ecms.dto.infoGath;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class InformationValidator implements Validator {

	public InformationValidator() {
		super();
		// TODO Auto-generated constructor stub
	}

	public boolean supports(Class arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub

	}

}
