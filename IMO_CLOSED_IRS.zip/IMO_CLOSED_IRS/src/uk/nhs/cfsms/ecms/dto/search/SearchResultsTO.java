package uk.nhs.cfsms.ecms.dto.search;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.cim.CaseIndexSearch;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.InformationIndexSearch;

/**
 * Results from Search.
 * 
 */
public class SearchResultsTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 52070116L;

	private String nodeId;

	private String searchKeywords;

	private Long applicationId;

	private String url;

	private String title;

	private String summary;

	private Integer count;

	private String sectionName;

	private Long sectionId;
	
	private String searchType;
	
	private UserObject dataOwner;
	
	private String errorMessage;

	private List<CaseIndexSearch> searchResults = new ArrayList<CaseIndexSearch>();
	
	private List<InformationIndexSearch> infoSearchResults = new ArrayList<InformationIndexSearch>();

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public String getNodeId() {
		return nodeId;
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getSearchKeywords() {
		return searchKeywords;
	}

	public void setSearchKeywords(String searchKeywords) {
		this.searchKeywords = searchKeywords;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Long getSectionId() {
		return sectionId;
	}

	public void setSectionId(Long sectionId) {
		this.sectionId = sectionId;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public void setSearchResults(List<CaseIndexSearch> searchResults) {
		this.searchResults = searchResults;
	}

	public List<CaseIndexSearch> getSearchResults() {
		return searchResults;
	}

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public List<InformationIndexSearch> getInfoSearchResults() {
		return infoSearchResults;
	}

	public void setInfoSearchResults(List<InformationIndexSearch> infoSearchResults) {
		this.infoSearchResults = infoSearchResults;
	}

	public UserObject getDataOwner() {
		return dataOwner;
	}

	public void setDataOwner(UserObject dataOwner) {
		this.dataOwner = dataOwner;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
