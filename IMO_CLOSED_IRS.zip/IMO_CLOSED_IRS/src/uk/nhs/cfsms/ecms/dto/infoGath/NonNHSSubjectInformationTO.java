package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;
import java.util.Date;

public class NonNHSSubjectInformationTO implements Serializable {

	private static final long serialVersionUID = 43277824441L;

	private Long subjectNonNhsId;

	private Long informationTO;

	private Long caseId;

	private String subjectType;

	private String companyName;

	private String natureOfBusiness;

	private String sisCode;

	private String regNumber;

	private String incorpNumber;

	private String vatNumber;

	private String nonNHSIntelReference;

	private String tradeAddress1;

	private String tradeAddress2;

	private String tradeAddress3;

	private String tradeAddress4;

	private String tradePostcode;

	private String regAddress1;

	private String regAddress2;

	private String regAddress3;

	private String regAddress4;

	private String regPostcode;

	private String otherIdentification;

	private String companyStatus;

	private String companyType;

	private String tradeAddress21;

	private String tradeAddress22;

	private String tradeAddress23;

	private String tradeAddress24;

	private String tradePostcode2;

	private String regAddress21;

	private String regAddress22;

	private String regAddress23;

	private String regAddress24;

	private String regPostcode2;

	private String previousName2;

	private String previousName3;

	private Date dateOfChange;

	private String previousName;

	private Date incorprationDate;

	private String companyTel;

	private String faxNumber;

	private String webAddress;

	private String additionalInfo;

	private String otherCompanyType;

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyStatus() {
		return companyStatus;
	}

	public void setCompanyStatus(String companyStatus) {
		this.companyStatus = companyStatus;
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public String getIncorpNumber() {
		return incorpNumber;
	}

	public void setIncorpNumber(String incorpNumber) {
		this.incorpNumber = incorpNumber;
	}

	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}

	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}

	public String getOtherIdentification() {
		return otherIdentification;
	}

	public void setOtherIdentification(String otherIdentification) {
		this.otherIdentification = otherIdentification;
	}

	public String getRegAddress1() {
		return regAddress1;
	}

	public void setRegAddress1(String regAddress1) {
		this.regAddress1 = regAddress1;
	}

	public String getRegAddress2() {
		return regAddress2;
	}

	public void setRegAddress2(String regAddress2) {
		this.regAddress2 = regAddress2;
	}

	public String getRegAddress3() {
		return regAddress3;
	}

	public void setRegAddress3(String regAddress3) {
		this.regAddress3 = regAddress3;
	}

	public String getRegAddress4() {
		return regAddress4;
	}

	public void setRegAddress4(String regAddress4) {
		this.regAddress4 = regAddress4;
	}

	public String getRegNumber() {
		return regNumber;
	}

	public void setRegNumber(String regNumber) {
		this.regNumber = regNumber;
	}

	public String getRegPostcode() {
		return regPostcode;
	}

	public void setRegPostcode(String regPostcode) {
		this.regPostcode = regPostcode;
	}

	public String getSisCode() {
		return sisCode;
	}

	public void setSisCode(String sisCode) {
		this.sisCode = sisCode;
	}

	public Long getSubjectNonNhsId() {
		return subjectNonNhsId;
	}

	public void setSubjectNonNhsId(Long subjectNonNhsId) {
		this.subjectNonNhsId = subjectNonNhsId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	public String getTradeAddress1() {
		return tradeAddress1;
	}

	public void setTradeAddress1(String tradeAddress1) {
		this.tradeAddress1 = tradeAddress1;
	}

	public String getTradeAddress2() {
		return tradeAddress2;
	}

	public void setTradeAddress2(String tradeAddress2) {
		this.tradeAddress2 = tradeAddress2;
	}

	public String getTradeAddress3() {
		return tradeAddress3;
	}

	public void setTradeAddress3(String tradeAddress3) {
		this.tradeAddress3 = tradeAddress3;
	}

	public String getTradeAddress4() {
		return tradeAddress4;
	}

	public void setTradeAddress4(String tradeAddress4) {
		this.tradeAddress4 = tradeAddress4;
	}

	public String getTradePostcode() {
		return tradePostcode;
	}

	public void setTradePostcode(String tradePostcode) {
		this.tradePostcode = tradePostcode;
	}

	public String getVatNumber() {
		return vatNumber;
	}

	public void setVatNumber(String vatNumber) {
		this.vatNumber = vatNumber;
	}

	public Long getInformationTO() {
		return informationTO;
	}

	public void setInformationTO(Long informationTO) {
		this.informationTO = informationTO;
	}

	public String getCompanyTel() {
		return companyTel;
	}

	public void setCompanyTel(String companyTel) {
		this.companyTel = companyTel;
	}

	public Date getDateOfChange() {
		return dateOfChange;
	}

	public void setDateOfChange(Date dateOfChange) {
		this.dateOfChange = dateOfChange;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public Date getIncorprationDate() {
		return incorprationDate;
	}

	public void setIncorprationDate(Date incorprationDate) {
		this.incorprationDate = incorprationDate;
	}

	public String getPreviousName() {
		return previousName;
	}

	public void setPreviousName1(String previousName1) {
		this.previousName = previousName;
	}

	public String getPreviousName2() {
		return previousName2;
	}

	public void setPreviousName2(String previousName2) {
		this.previousName2 = previousName2;
	}

	public String getPreviousName3() {
		return previousName3;
	}

	public void setPreviousName3(String previousName3) {
		this.previousName3 = previousName3;
	}

	public String getRegAddress21() {
		return regAddress21;
	}

	public void setRegAddress21(String regAddress21) {
		this.regAddress21 = regAddress21;
	}

	public String getRegAddress22() {
		return regAddress22;
	}

	public void setRegAddress22(String regAddress22) {
		this.regAddress22 = regAddress22;
	}

	public String getRegAddress23() {
		return regAddress23;
	}

	public void setRegAddress23(String regAddress23) {
		this.regAddress23 = regAddress23;
	}

	public String getRegAddress24() {
		return regAddress24;
	}

	public void setRegAddress24(String regAddress24) {
		this.regAddress24 = regAddress24;
	}

	public String getRegPostcode2() {
		return regPostcode2;
	}

	public void setRegPostcode2(String regPostcode2) {
		this.regPostcode2 = regPostcode2;
	}

	public String getTradingAddress21() {
		return tradeAddress21;
	}

	public void setTradingAddress21(String tradingAddress21) {
		this.tradeAddress21 = tradingAddress21;
	}

	public String getTradingAddress22() {
		return tradeAddress22;
	}

	public void setTradingAddress22(String tradingAddress22) {
		this.tradeAddress22 = tradingAddress22;
	}

	public String getTradingAddress23() {
		return tradeAddress23;
	}

	public void setTradingAddress23(String tradingAddress23) {
		this.tradeAddress23 = tradingAddress23;
	}

	public String getTradingAddress24() {
		return tradeAddress24;
	}

	public void setTradingAddress24(String tradingAddress24) {
		this.tradeAddress24 = tradingAddress24;
	}

	public String getTradingPostcode2() {
		return tradePostcode2;
	}

	public void setTradingPostcode2(String tradingPostcode2) {
		this.tradePostcode2 = tradingPostcode2;
	}

	public String getWebAddress() {
		return webAddress;
	}

	public void setWebAddress(String webAddress) {
		this.webAddress = webAddress;
	}

	public String getOtherCompanyType() {
		return otherCompanyType;
	}

	public void setOtherCompanyType(String otherCompanyType) {
		this.otherCompanyType = otherCompanyType;
	}

	public String getTradeAddress21() {
		return tradeAddress21;
	}

	public void setTradeAddress21(String tradeAddress21) {
		this.tradeAddress21 = tradeAddress21;
	}

	public String getTradeAddress22() {
		return tradeAddress22;
	}

	public void setTradeAddress22(String tradeAddress22) {
		this.tradeAddress22 = tradeAddress22;
	}

	public String getTradeAddress23() {
		return tradeAddress23;
	}

	public void setTradeAddress23(String tradeAddress23) {
		this.tradeAddress23 = tradeAddress23;
	}

	public String getTradeAddress24() {
		return tradeAddress24;
	}

	public void setTradeAddress24(String tradeAddress24) {
		this.tradeAddress24 = tradeAddress24;
	}

	public String getTradePostcode2() {
		return tradePostcode2;
	}

	public void setTradePostcode2(String tradePostcode2) {
		this.tradePostcode2 = tradePostcode2;
	}

	public void setPreviousName(String previousName) {
		this.previousName = previousName;
	}

	public String getNonNHSIntelReference() {
		return nonNHSIntelReference;
	}

	public void setNonNHSIntelReference(String nonNHSIntelReference) {
		this.nonNHSIntelReference = nonNHSIntelReference;
	}

}
