package uk.nhs.cfsms.ecms.dto.user;

import java.io.Serializable;
import java.util.ArrayList;


/*
 * Author: R Tobin
 * 
 * 03/02/09
 * 
 * user object to hold user responsibilities - this object is put into session
 * and used un conjunction with the userInformation Object - user can be any user type.
 * This object may be extended to regions and org codes
 * This object could also be extended to cache history of new versus old org_codes or reg_codes
 */

public class UserResponsibilitiesTO implements Serializable{
	
	private String userId;
	private ArrayList userResponsibilities;
	
	
	public UserResponsibilitiesTO()
	{
		userResponsibilities = new ArrayList();
		
	}
	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public ArrayList getUserResponsibilities() {
		return userResponsibilities;
	}
	public void setUserResponsibilities(ArrayList userResponsibilities) {
		this.userResponsibilities = userResponsibilities;
	}
	

}
