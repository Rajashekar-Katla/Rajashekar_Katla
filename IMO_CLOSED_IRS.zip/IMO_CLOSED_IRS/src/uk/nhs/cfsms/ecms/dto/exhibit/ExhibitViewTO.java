package uk.nhs.cfsms.ecms.dto.exhibit;

public class ExhibitViewTO {

	private String fileExtension;
	private String fileName;
	private String exhibitType;

	public ExhibitViewTO(final String fileExtension, final String fileName,
			final String exhibitType) {

		this.fileExtension = fileExtension;
		this.fileName = fileName;
		this.exhibitType = exhibitType;
	}

	/**
	 * @return the fileExtension
	 */
	public String getFileExtension() {
		return fileExtension;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @return the exhibitType
	 */
	public String getExhibitType() {
		return exhibitType;
	}

}
