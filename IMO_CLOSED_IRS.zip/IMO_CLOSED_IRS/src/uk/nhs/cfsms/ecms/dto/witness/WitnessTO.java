package uk.nhs.cfsms.ecms.dto.witness;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.witness.NonAvailableDate;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonTO;

public class WitnessTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long witnessId;

	private Long caseId;

	private String caseRefNumber;

	private PersonTO person;

	private String contactPoint;

	private String contactAddress1;

	private String contactAddress2;

	private String contactAddress3;

	private String contactAddress4;

	private String contactPostCode;

	private String contactPhone;

	private String state;

	private Date createdTime;

	private String createdStaffId;

	private String contactTime;

	private String attendCourt;

	private String ensureAttendance;

	private String anyParticularNeeds;

	private String particularNeedsDescription;

	private String leafLetConsent;

	private String medicalRecordsConsent;

	private String defenceRecordsConsent;

	private String civilProceedingConsent;

	private byte[] mg2Form;

	private byte[] mg6Form;

	private String mg2FormFileName;

	private String mg2FormFileType;

	private String mg6FormFileType;

	private String mg6FormFileName;

	private String isMg2Uploaded;

	private String isMg6Uploaded;

	private String witnessSignature;

	private String parentGuardianName;

	private String parentSignature;

	private String specialMeasures;

	private String actionType;

	private Date dob;

	private String serialNumber;

	private boolean lookupSave;

	private String title;

	private String otherTitle;

	private String firstName;

	private String lastName;
	
	
	public WitnessTO(final Long witnessId, final String title,
			final String firstName, final String lastName,
			final String otherTitle) {
		this.witnessId = witnessId;
		this.title = title;
		this.firstName = firstName;
		this.lastName = lastName;
		this.otherTitle = otherTitle;
	}

	private List<NonAvailableDate> nonAvailableDates = LazyList.decorate(
			new ArrayList(),
			FactoryUtils.instantiateFactory(NonAvailableDate.class));

	private Date unAvailableDates;

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public WitnessTO() {
		this.person = new PersonTO();
	}

	public String getAnyParticularNeeds() {
		return anyParticularNeeds;
	}

	public void setAnyParticularNeeds(String anyParticularNeeds) {
		this.anyParticularNeeds = anyParticularNeeds;
	}

	public String getAttendCourt() {
		return attendCourt;
	}

	public void setAttendCourt(String attendCourt) {
		this.attendCourt = attendCourt;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getContactAddress1() {
		return contactAddress1;
	}

	public void setContactAddress1(String contactAddress1) {
		this.contactAddress1 = contactAddress1;
	}

	public String getContactAddress2() {
		return contactAddress2;
	}

	public void setContactAddress2(String contactAddress2) {
		this.contactAddress2 = contactAddress2;
	}

	public String getContactAddress3() {
		return contactAddress3;
	}

	public void setContactAddress3(String contactAddress3) {
		this.contactAddress3 = contactAddress3;
	}

	public String getContactAddress4() {
		return contactAddress4;
	}

	public void setContactAddress4(String contactAddress4) {
		this.contactAddress4 = contactAddress4;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getContactPoint() {
		return contactPoint;
	}

	public void setContactPoint(String contactPoint) {
		this.contactPoint = contactPoint;
	}

	public String getContactPostCode() {
		return contactPostCode;
	}

	public void setContactPostCode(String contactPostCode) {
		this.contactPostCode = contactPostCode;
	}

	public String getContactTime() {
		return contactTime;
	}

	public void setContactTime(String contactTime) {
		this.contactTime = contactTime;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getDefenceRecordsConsent() {
		return defenceRecordsConsent;
	}

	public void setDefenceRecordsConsent(String defenceRecordsConsent) {
		this.defenceRecordsConsent = defenceRecordsConsent;
	}

	public String getLeafLetConsent() {
		return leafLetConsent;
	}

	public void setLeafLetConsent(String leafLetConsent) {
		this.leafLetConsent = leafLetConsent;
	}

	public String getMedicalRecordsConsent() {
		return medicalRecordsConsent;
	}

	public void setMedicalRecordsConsent(String medicalRecordsConsent) {
		this.medicalRecordsConsent = medicalRecordsConsent;
	}

	public byte[] getMg2Form() {
		return mg2Form;
	}

	public void setMg2Form(byte[] mg2Form) {
		this.mg2Form = mg2Form;
	}

	public byte[] getMg6Form() {
		return mg6Form;
	}

	public void setMg6Form(byte[] mg6Form) {
		this.mg6Form = mg6Form;
	}

	public String getParentGuardianName() {
		return parentGuardianName;
	}

	public void setParentGuardianName(String parentGuardianName) {
		this.parentGuardianName = parentGuardianName;
	}

	public String getParentSignature() {
		return parentSignature;
	}

	public void setParentSignature(String parentSignature) {
		this.parentSignature = parentSignature;
	}

	public String getParticularNeedsDescription() {
		return particularNeedsDescription;
	}

	public void setParticularNeedsDescription(String particularNeedsDescription) {
		this.particularNeedsDescription = particularNeedsDescription;
	}

	public PersonTO getPerson() {
		return person;
	}

	public void setPerson(PersonTO person) {
		this.person = person;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getWitnessId() {
		return witnessId;
	}

	public void setWitnessId(Long witnessId) {
		this.witnessId = witnessId;
	}

	public String getWitnessSignature() {
		return witnessSignature;
	}

	public void setWitnessSignature(String witnessSignature) {
		this.witnessSignature = witnessSignature;
	}

	public String getEnsureAttendance() {
		return ensureAttendance;
	}

	public void setEnsureAttendance(String ensureAttendance) {
		this.ensureAttendance = ensureAttendance;
	}

	public String getCivilProceedingConsent() {
		return civilProceedingConsent;
	}

	public void setCivilProceedingConsent(String civilProceedingConsent) {
		this.civilProceedingConsent = civilProceedingConsent;
	}

	public String getSpecialMeasures() {
		return specialMeasures;
	}

	public void setSpecialMeasures(String specialMeasures) {
		this.specialMeasures = specialMeasures;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getIsMg2Uploaded() {
		if (mg2Form != null && mg2Form.length > 0)
			return "YES";
		return "NO";

	}

	public void setIsMg2Uploaded(String isMg2Uploaded) {
		this.isMg2Uploaded = isMg2Uploaded;
	}

	public String getIsMg6Uploaded() {
		if (mg6Form != null && mg6Form.length > 0)
			return "YES";
		return "NO";
	}

	public void setIsMg6Uploaded(String isMg6Uploaded) {
		this.isMg6Uploaded = isMg6Uploaded;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public Date getUnAvailableDates() {
		return unAvailableDates;
	}

	public void setUnAvailableDates(Date unAvailableDates) {
		this.unAvailableDates = unAvailableDates;
		if (this.unAvailableDates != null) {
			NonAvailableDate nonAvailDate = new NonAvailableDate();
			nonAvailDate.setWitnessId(this.witnessId);
			nonAvailDate.setNonAvailableDate(new java.sql.Date(unAvailableDates
					.getTime()));
			nonAvailableDates.add(nonAvailDate);
		}
	}

	public void addNonAvailableDate(NonAvailableDate nonAvailDate) {
		this.nonAvailableDates.add(nonAvailDate);
	}

	public List<NonAvailableDate> getNonAvailableDates() {
		return nonAvailableDates;
	}

	public void setNonAvailableDates(List<NonAvailableDate> nonAvailableDates) {
		this.nonAvailableDates = nonAvailableDates;
	}

	public String getMg2FormFileName() {
		return mg2FormFileName;
	}

	public void setMg2FormFileName(String mg2FormFileName) {
		this.mg2FormFileName = mg2FormFileName;
	}

	public String getMg2FormFileType() {
		return mg2FormFileType;
	}

	public void setMg2FormFileType(String mg2FormFileType) {
		this.mg2FormFileType = mg2FormFileType;
	}

	public String getMg6FormFileName() {
		return mg6FormFileName;
	}

	public void setMg6FormFileName(String mg6FormFileName) {
		this.mg6FormFileName = mg6FormFileName;
	}

	public String getMg6FormFileType() {
		return mg6FormFileType;
	}

	public void setMg6FormFileType(String mg6FormFileType) {
		this.mg6FormFileType = mg6FormFileType;
	}

	public boolean isLookupSave() {
		return lookupSave;
	}

	public void setLookupSave(boolean isLookupSave) {
		this.lookupSave = isLookupSave;
	}

	/**
	 * @return the caseRefNumber
	 */
	public String getCaseRefNumber() {
		return caseRefNumber;
	}

	/**
	 * @param caseRefNumber
	 *            the caseRefNumber to set
	 */
	public void setCaseRefNumber(String caseRefNumber) {
		this.caseRefNumber = caseRefNumber;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the otherTitle
	 */
	public String getOtherTitle() {
		return otherTitle;
	}

	/**
	 * @param otherTitle the otherTitle to set
	 */
	public void setOtherTitle(String otherTitle) {
		this.otherTitle = otherTitle;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
}
