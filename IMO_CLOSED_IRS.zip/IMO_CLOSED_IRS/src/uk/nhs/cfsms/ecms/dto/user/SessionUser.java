package uk.nhs.cfsms.ecms.dto.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.ECMSConstants.NATIONAL_ORGS;
import uk.nhs.cfsms.ecms.data.authorization.AccessControl;
import uk.nhs.cfsms.ecms.data.common.AllUserResponsibilities;
import uk.nhs.cfsms.ecms.data.common.PermissionGroup;
import uk.nhs.cfsms.ecms.data.common.UserDirectorate;
import uk.nhs.cfsms.ecms.exceptions.ListEmptyException;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * From 1st April 2011, National Investigation Team North & South is coming to
 * effect. named NIT(N) and NIT(S) and each has a Lead. AFS
 * (AntiFraudSpecialist) and AFL ( AntiFraudLead) are part of restructure. AFL
 * plays similar role to that of OFM. AFS plays is similar to CFS.
 * 
 */
public class SessionUser implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4859910710160105420L;

	private String staffId;

	private String title;

	private String firstName;

	private String middleName;

	private String lastName;

	private String knownAs;

	private String employerOrgCode;

	private String jobTitle;

	private String phoneNumber;

	private String phoneExtension;

	private String phoneNumber2;

	private String mobileNumber;

	private String homeNumber;

	private String pager;

	private String faxNumber;

	private String nhsEmailAddress;

	private String otherEmailAddress;

	private String additionalEmailAddress;

	private String address1;

	private String address2;

	private String address3;

	private String address4;

	private String address5;

	private String postCode;

	private String teamPermission;

	private String directorate;

	private String groupPermission;

	private List<AllUserResponsibilities> userResponsibilities;
	private List<PermissionGroup> permissionGroupList = new ArrayList<PermissionGroup>();
	private List<UserDirectorate> directorates = new ArrayList<UserDirectorate>();
	private List<AccessControl> accessControlList = new ArrayList<AccessControl>();
	private List<String> leadStaffIds = new ArrayList<String>();

	public SessionUser() {

	}

	public String getAdditionalEmailAddress() {
		return additionalEmailAddress;
	}

	public void setAdditionalEmailAddress(String additionalEmailAddress) {
		this.additionalEmailAddress = additionalEmailAddress;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getAddress5() {
		return address5;
	}

	public void setAddress5(String address5) {
		this.address5 = address5;
	}

	public String getEmployerOrgCode() {
		return employerOrgCode;
	}

	public void setEmployerOrgCode(String employerOrgCode) {
		this.employerOrgCode = employerOrgCode;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGroupPermission() {
		return groupPermission;
	}

	public void setGroupPermission(String groupPermission) {
		this.groupPermission = groupPermission;
	}

	public String getHomeNumber() {
		return homeNumber;
	}

	public void setHomeNumber(String homeNumber) {
		this.homeNumber = homeNumber;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getKnownAs() {
		return knownAs;
	}

	public void setKnownAs(String knownAs) {
		this.knownAs = knownAs;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getNhsEmailAddress() {
		return nhsEmailAddress;
	}

	public void setNhsEmailAddress(String nhsEmailAddress) {
		this.nhsEmailAddress = nhsEmailAddress;
	}

	public String getOtherEmailAddress() {
		return otherEmailAddress;
	}

	public void setOtherEmailAddress(String otherEmailAddress) {
		this.otherEmailAddress = otherEmailAddress;
	}

	public String getPager() {
		return pager;
	}

	public void setPager(String pager) {
		this.pager = pager;
	}

	public String getPhoneExtension() {
		return phoneExtension;
	}

	public void setPhoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber2() {
		return phoneNumber2;
	}

	public void setPhoneNumber2(String phoneNumber2) {
		this.phoneNumber2 = phoneNumber2;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List getUserResponsibilities() throws ListEmptyException {
		if (null != userResponsibilities && userResponsibilities.isEmpty()) {
			throw new ListEmptyException("userResponsibilitiesList isEmpty");
		}
		return userResponsibilities;
	}

	public void setUserResponsibilities(List userResponsibilities) {
		this.userResponsibilities = userResponsibilities;
	}

	public List getPermissionGroup() throws ListEmptyException {
		if (null != permissionGroupList && permissionGroupList.isEmpty()) {
			throw new ListEmptyException("permissionGroupList isEmpty");
		}
		return permissionGroupList;
	}

	public void setPermissionGroup(PermissionGroup pGroup) {
		this.permissionGroupList.add(pGroup);
	}

	public PermissionGroup getPermissionGroupTopLevel() {
		if (null != permissionGroupList && !permissionGroupList.isEmpty()) {
			return permissionGroupList.get(0);
		}
		return null;
	}

	/**
	 * Check whether the user is LCFS. group permission 6 denotes LCFS.
	 * 
	 * @return boolean
	 */
	public boolean isUserLCFS() {
		if (null != groupPermission
				&& ECMSConstants.LCFS_LEVEL.equalsIgnoreCase(groupPermission)) {
			return true;
		}
		return false;
	}

	public boolean isUserFCRL() {
		if (null != groupPermission
				&& ECMSConstants.FCRL_LEVEL.equalsIgnoreCase(groupPermission)) {
			return true;
		}
		return false;
	}

	public boolean isUserCFS() {

		if (null != groupPermission
				&& ECMSConstants.CFS_LEVEL.equalsIgnoreCase(groupPermission)) {
			return true;
		}
		return false;
	}

	public boolean isUserOFM() {

		if (null != groupPermission
				&& ECMSConstants.OFM_LEVEL.equalsIgnoreCase(groupPermission)) {
			return true;
		}
		return false;
	}

	public boolean isUserAdmin() {

		if (null != groupPermission
				&& ECMSConstants.ADMIN_LEVEL.equalsIgnoreCase(groupPermission)) {
			return true;
		}
		return false;
	}

	public boolean isUserDirector() {

		if (null != groupPermission
				&& ECMSConstants.DIRECTOR_LEVEL
						.equalsIgnoreCase(groupPermission)) {
			return true;
		}
		return false;
	}

	public boolean isUserReporter() {

		if (null != groupPermission
				&& ECMSConstants.REPORTER_LEVEL
						.equalsIgnoreCase(groupPermission)) {
			return true;
		}
		return false;
	}

	/**
	 * Check whether the user is National Directorate.
	 * 
	 * @return boolean
	 */
	public boolean isUserDirectorate() {
		if (null != directorate
				&& directorate
						.equalsIgnoreCase(ECMSConstants.DIRECTORATE_NATIONAL)) {
			return true;
		}
		return false;
	}

	/**
	 * Check whether the user is Local.
	 * 
	 * @return boolean
	 */
	public boolean isUserLocal() {
		if (null != directorate
				&& directorate
						.equalsIgnoreCase(ECMSConstants.DIRECTORATE_LOCAL)) {
			return true;
		}
		return false;
	}

	/**
	 * Check whether the user is Regional.
	 * 
	 * @return boolean
	 */
	public boolean isUserRegional() {
		if (null != directorate
				&& directorate
						.equalsIgnoreCase(ECMSConstants.DIRECTORATE_REGIONAL)) {
			return true;
		}
		return false;
	}

	public boolean isUserCIU() {

		String[] teamList = getOrgOrTeamResponsibilities();
		for (int i = 0; i < teamList.length; i++) {
			if (teamList[i] != null
					&& teamList[i]
							.equalsIgnoreCase(ECMSConstants.CIU_TEAM_CODE))
				return true;
		}

		return false;
	}
	
	public boolean isUserIMO() {

		String[] teamList = getOrgOrTeamResponsibilities();
		for (int i = 0; i < teamList.length; i++) {
			if (teamList[i] != null
					&& teamList[i]
							.equalsIgnoreCase(ECMSConstants.TEAM_IMO))
				return true;
		}

		return false;
	}
	
	/**
	 * Check whether the user is in regional level (team code).
	 * 
	 * @return boolean
	 */
	public boolean isUserRegionalLevel() {

		if (isUserOFM() || isUserAdmin() || isUserCFS() || isUserDirector()
				|| isUserRegional()) {
			return true;
		}
		return false;
	}

	/**
	 * Check whether the user is in local level (org code).
	 * 
	 * @return boolean
	 */
	public boolean isUserLocalLevel() {

		if (isUserLCFS() || isUserLocal()) {
			return true;
		}
		return false;
	}

	/**
	 * Depending on the type of User we get ORG_CODE or TEAM_CODE for
	 * responsibilities
	 * 
	 * @return array of ORG_CODE/TEAM_CODE
	 */
	public String[] getOrgOrTeamResponsibilities() {
		List<String> respList = new ArrayList<String>();
		Set<String> respSet = new HashSet<String>();
		if (null != userResponsibilities && !userResponsibilities.isEmpty()) {
			for (AllUserResponsibilities resp : userResponsibilities) {
				if(EcmsUtils.isLSDSRegionalTeam(resp.getRespCode())){
					respSet.add(ECMSConstants.IMO);
				}else{
					respSet.add(resp.getRespCode());
				}
			}
			respList.addAll(respSet);
		}
		return respList.toArray(new String[respList.size()]);
	}
	
	public String[] getIMOTeamResponsibilities() {
		List<String> respList = new ArrayList<String>();
		Set<String> respSet = new HashSet<String>();
		if (null != userResponsibilities && !userResponsibilities.isEmpty()) {
			for (AllUserResponsibilities resp : userResponsibilities) {
				respSet.add(resp.getRespCode());
			}
			respSet.add(ECMSConstants.IMO);
			respList.addAll(respSet);
		}
		return respList.toArray(new String[respList.size()]);
	}

	/**
	 * Depending on the type of User we get ORG_CODE or TEAM_CODE for
	 * responsibilities
	 * 
	 * @return array of ORG_CODE/TEAM_CODE
	 */
	public List<String> getOrgOrTeamResponsibilityList() {
		List<String> respList = new ArrayList<String>();
		Set<String> respSet = new HashSet<String>();
		if (this.isNITAFL()) {
			respList.add(ECMSConstants.NIT_NORTH);
			respList.add(ECMSConstants.NIT_SOUTH);
		} else if (null != userResponsibilities
				&& !userResponsibilities.isEmpty()) {
			for (AllUserResponsibilities resp : userResponsibilities) {
				if(EcmsUtils.isLSDSRegionalTeam(resp.getRespCode())){
					respSet.add(ECMSConstants.IMO);
				}else{
					respSet.add(resp.getRespCode());
				}
			}
			respList.addAll(respSet);
		}
		return respList;
	}

	public List<Long> getPermissionGroupsAsIds() {

		List<Long> res = new ArrayList<Long>();
		for (int i = 0; i < permissionGroupList.size(); i++) {
			PermissionGroup pg = permissionGroupList.get(i);
			res.add(pg.getId());
		}

		return res;
	}

	public String getDirectorate() {
		return directorate;
	}

	public void setDirectorate(String directorate) {
		this.directorate = directorate;
	}

	public String getTeamPermission() {
		return teamPermission;
	}

	public void setTeamPermission(String teamPermission) {
		this.teamPermission = teamPermission;
	}

	public List<UserDirectorate> getDirectorates() {
		return directorates;
	}

	public void setDirectorates(List<UserDirectorate> directorates) {
		this.directorates = directorates;
	}

	public List<AccessControl> getAccessControlList() {
		return accessControlList;
	}

	public void setAccessControlList(List<AccessControl> accessControlList) {
		this.accessControlList = accessControlList;
	}

	public String getFullName() {
		String fullName = "";

		if (StringUtils.isNotEmpty(this.title)) {
			fullName += this.title;
			fullName += " ";
		}
		if (StringUtils.isNotEmpty(this.firstName)) {
			fullName += this.firstName;
			fullName += " ";
		}
		if (StringUtils.isNotEmpty(this.middleName)) {
			fullName += this.middleName;
			fullName += " ";
		}
		if (StringUtils.isNotEmpty(this.lastName)) {
			fullName += this.lastName;
		}
		return fullName;
	}

	public String[] getCFSDirectorateLevel() {
		String[] dirs = null;
		if (this.directorates != null && this.directorates.size() > 0) {
			dirs = new String[this.directorates.size()];
			for (int i = 0; i < this.directorates.size(); i++) {
				// Old CMS data has levels like
				// "CFS_LOC", "CFS_REG", "CFS_NAT".
				dirs[i] = "CFS_"
						+ this.directorates.get(i).getDirectorateLevel();
			}
		}
		return dirs;
	}

	/**
	 * Depending on user responsibility get access level.
	 * 
	 * @return ACCESS
	 */
	public String getUserAccessLevel() {

		if (this.isUserFCRL()) {
			return ECMSConstants.ACL_FCRL;
		}
		if (this.isUserLCFS()) {
			return ECMSConstants.ACL_LCFS;
		}
		if (this.isUserCFS()) {
			return ECMSConstants.ACL_CFS;
		}
		if (this.isUserReporter()) {
			return ECMSConstants.ACL_REP;
		}
		if (this.isUserOFM()) {
			return ECMSConstants.ACL_OFM;
		}
		if (this.isUserAdmin()) {
			return ECMSConstants.ACL_ADMIN;
		}
		if (this.isUserDirector()) {
			return ECMSConstants.ACL_DIR;
		}
		if (this.isUserDirector()) {
			return ECMSConstants.ACL_DIR;
		}
		if (this.isUserAntiFraudSpecialist()) {
			return ECMSConstants.ACL_OFM_AFS;
		}
		if (this.isUserAntiFraudSpecialistSupport()) {
			return ECMSConstants.ACL_AAFSS;
		}
		if (this.isUserAntiFraudLead()) {
			return ECMSConstants.ACL_NIT;
		}

		return ECMSConstants.ACL_UNKNOWN;
	}

	/**
	 * Is User National TEAM TYPE.
	 * 
	 * @return boolean
	 */
	public boolean isUserNationalLevel() {

		for (NATIONAL_ORGS orgCode : ECMSConstants.NATIONAL_ORGS.values()) {
			 
			if (getOrgOrTeamResponsibilityList().contains(orgCode.toString())) {
				return true;
			}
		}
		return false;
	}

	public boolean isUserAntiFraudSpecialist() {
		if (null != groupPermission
				&& ECMSConstants.AFS_LEVEL.equalsIgnoreCase(groupPermission)) {
			return true;
		}
		return false;
	}

	public boolean isUserAntiFraudSpecialistSupport() {
		if (null != groupPermission
				&& ECMSConstants.AAFS_LEVEL.equalsIgnoreCase(groupPermission)) {
			return true;
		}
		return false;
	}

	public boolean isUserAntiFraudLead() {
		if (null != groupPermission
				&& ECMSConstants.AFL_LEVEL.equalsIgnoreCase(groupPermission)) {
			return true;
		}
		return false;
	}

	public boolean isNITSouthLead() {
		if (null != groupPermission
				&& ECMSConstants.AFL_LEVEL.equalsIgnoreCase(groupPermission)
				&& ECMSConstants.NIT_SOUTH.equalsIgnoreCase(employerOrgCode)) {
			return true;
		}
		return false;
	}

	public boolean isNITNorthLead() {
		if (null != groupPermission
				&& ECMSConstants.AFL_LEVEL.equalsIgnoreCase(groupPermission)
				&& ECMSConstants.NIT_NORTH.equalsIgnoreCase(employerOrgCode)) {
			return true;
		}
		return false;
	}
	
	public boolean isSOPLead() {
		if (null != groupPermission
				&& ECMSConstants.AFL_LEVEL.equalsIgnoreCase(groupPermission)
				&& ECMSConstants.TEAM_SOP.equalsIgnoreCase(employerOrgCode)) {
			return true;
		}
		return false;
	}

	public boolean isNITAFL() {
		if (isNITNorthLead() || isNITSouthLead() || isSOPLead()) {
			return true;
		}
		return false;
	}

	public List<String> getLeadStaffIds() {
		return leadStaffIds;
	}

	public void setLeadStaffIds(List<String> leadStaffIds) {
		this.leadStaffIds = leadStaffIds;
	}
	
	public boolean isUserManager() {
		
		if (this.staffId.equalsIgnoreCase(ECMSConstants.USER_MANAGER)) {
			return true;
		}
		return false;
	}
	
	public boolean isUserHeadOperations() {
		if (this.staffId.equalsIgnoreCase(ECMSConstants.USER_HEAD_OPS)) {
			return true;
		}
		return false;
	}
	
	public boolean isUserDeputyOperations() {
		if (this.staffId.equalsIgnoreCase(ECMSConstants.USER_DEPUTY_OPS)) {
			return true;
		}
		return false;
	}
	
	public boolean isUserWARO() {

		String[] teamList = getOrgOrTeamResponsibilities();
		
		for (int i = 0; i < teamList.length; i++) {
			
			if (null != teamList[i] && teamList[i].equalsIgnoreCase(ECMSConstants.TEAM_WARO)) {
				
				return true;
			}				
		}
		return false;
	}
	
	public boolean isUserNotTeamManager() {
		
		if ((!isUserDirector() && !isNITAFL() && !isUserAntiFraudLead() && !isUserOFM() && !isUserAntiFraudSpecialist()) || 				
				(isUserAntiFraudSpecialist() && ( isUserCIU() || isUserWARO()))) {
			
			return true;
		}
		
		return false;
	}
	
	public boolean isUserMangerAndAbove() {
		
		if (isUserOFM() || isUserAntiFraudLead() || isUserAntiFraudSpecialist() || isUserDirector() || isUserHeadOperations() || isUserDeputyOperations()) {
			
			return true;
		}
		
		return false;
	}
}
