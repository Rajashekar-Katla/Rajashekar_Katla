package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealOutcome;

 
public class DisciplinaryAppealTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2699065551297357260L;

	private Long appealId;
	
	private Long parentAppealId;
	
	private Long sanctionId;
	
	private Long caseId;
	
	private Long subjectId;
	
	private String appealMaker;

	private String subjectType;
	
	private String createdStaffId;
	
	private Date createdTime;
	
	private String sanctionType;
	
	private String state;

	private String  humanResourceContact;

	private String investigationManagerContact;
	
	private String professionalContact;
	
	private String healthBodyContact;
	
	private String organisationName;

	private Date appealedDate;

	private String nhsSubjectName;
	
	private String nonNhsSubjectName;
	
	private String personSubjectName;
	
	private String subjectName;
	
	private String organisationMakingDecisionName;
	
	private String selectedSanctions;
	
	private Date outcomeDate;

	private Long parentSubjectId;
	
	private String parentSanctionType;
	
	private String otherSubject;
	
	private String appellantType;

	/**
	 * Used to Manipulate the "subjectId;SubjectType" format
	 * examples: "206;PERSON", "209:NHS" , "213,NON_NHS"
	 * split string by ";" & set values to subjectId and SubjectType.  
	 */
	private String subjectIdSemiTypeName;
	
	private List<DisciplinaryAppealHearing> hearings;
	 
	private List<DisciplinaryAppealOutcome> outcomes; 

    
	private boolean appealExist;

    private DisciplinaryAppealTO parentAppealTO;
    
    private DisciplinarySanctionTO parentSanctionTO;
   
	
	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public String getHealthBodyContact() {
		return healthBodyContact;
	}

	public void setHealthBodyContact(String healthBodyContact) {
		this.healthBodyContact = healthBodyContact;
	}

	public String getHumanResourceContact() {
		return humanResourceContact;
	}

	public void setHumanResourceContact(String humanResourceContact) {
		this.humanResourceContact = humanResourceContact;
	}

	public String getInvestigationManagerContact() {
		return investigationManagerContact;
	}

	public void setInvestigationManagerContact(String investigationManagerContact) {
		this.investigationManagerContact = investigationManagerContact;
	}

	public String getNhsSubjectName() {
		return nhsSubjectName;
	}

	public void setNhsSubjectName(String nhsSubjectName) {
		this.nhsSubjectName = nhsSubjectName;
	}

	public String getNonNhsSubjectName() {
		return nonNhsSubjectName;
	}

	public void setNonNhsSubjectName(String nonNhsSubjectName) {
		this.nonNhsSubjectName = nonNhsSubjectName;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getPersonSubjectName() {
		return personSubjectName;
	}

	public void setPersonSubjectName(String personSubjectName) {
		this.personSubjectName = personSubjectName;
	}

	public String getProfessionalContact() {
		return professionalContact;
	}

	public void setProfessionalContact(String professionalContact) {
		this.professionalContact = professionalContact;
	}

	public String getSanctionType() {
		return sanctionType;
	}

	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

	public Date getAppealedDate() {
		return appealedDate;
	}

	public void setAppealedDate(Date appealedDate) {
		this.appealedDate = appealedDate;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
			this.subjectType = subjectType;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getSubjectIdSemiTypeName() {
		return subjectIdSemiTypeName;
	}
	
	public void setSubjectIdSemiTypeName(String subjectIdSemiTypeName) {
		if (StringUtils.isEmpty(subjectIdSemiTypeName)) {
			this.subjectIdSemiTypeName = subjectIdSemiTypeName;
		}
		else if (subjectIdSemiTypeName.length() > 2) {
			String[] values = subjectIdSemiTypeName.split(";");
			if (values.length == 2) {
				this.subjectId = new Long(values[0]);
				this.subjectType = values[1];
			}
		}
	}


	public String getOrganisationMakingDecisionName() {
		return organisationMakingDecisionName;
	}

	public void setOrganisationMakingDecisionName(
			String organisationMakingDecisionName) {
		this.organisationMakingDecisionName = organisationMakingDecisionName;
	}

	public String getAppealMaker() {
		return appealMaker;
	}

	public void setAppealMaker(String appealMaker) {
		this.appealMaker = appealMaker;
	}
	
	public String getSelectedSanctions() {
		return selectedSanctions;
	}

	public void setSelectedSanctions(String selectedSanctions) {
		this.selectedSanctions = selectedSanctions;
	}

	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public Long getParentSubjectId() {
		return parentSubjectId;
	}

	public void setParentSubjectId(Long parentSubjectId) {
		this.parentSubjectId = parentSubjectId;
	}
	
	public String getParentSanctionType() {
		return parentSanctionType;
	}

	public void setParentSanctionType(String parentSanctionType) {
		this.parentSanctionType = parentSanctionType;
	}
	
	public String getOtherSubject() {
		return otherSubject;
	}

	public void setOtherSubject(String otherSubject) {
		this.otherSubject = otherSubject;
	}
 
	
	public List<DisciplinaryAppealHearing> getHearings() {
		return hearings;
	}

	public void setHearings(List<DisciplinaryAppealHearing> hearings) {
		this.hearings = hearings;
	}
	

	public List<DisciplinaryAppealOutcome> getOutcomes() {
		return outcomes;
	}

	public void setOutcomes(List<DisciplinaryAppealOutcome> outcomes) {
		this.outcomes = outcomes;
	}

	public boolean isAppealExist() {
		return appealExist;
	}

	public void setAppealExist(boolean appealExist) {
		this.appealExist = appealExist;
	}

	public DisciplinaryAppealTO getParentAppealTO() {
		return parentAppealTO;
	}

	public void setParentAppealTO(DisciplinaryAppealTO parentAppealTO) {
		this.parentAppealTO = parentAppealTO;
	}

	public DisciplinarySanctionTO getParentSanctionTO() {
		return parentSanctionTO;
	}

	public void setParentSanctionTO(DisciplinarySanctionTO parentSanctionTO) {
		this.parentSanctionTO = parentSanctionTO;
	}
 
	public String getAppellantType() {
		return appellantType;
	}

	public void setAppellantType(String appellantType) {
		this.appellantType = appellantType;
	}
}
