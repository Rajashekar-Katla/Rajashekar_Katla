package uk.nhs.cfsms.ecms.dto.user;

public class User {
	private String username;
	private String password;
	private String newPassword;
	private String retypePassword;
	private int enabled;
	/**
	 * @return Returns the enabled.
	 */
	public int getEnabled() {
		return enabled;
	}
	/**
	 * @param enabled
	 *            The enabled to set.
	 */
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	/**
	 * @return Returns the password.
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password
	 *            The password to set.
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return Returns the retypePassword.
	 */
	public String getRetypePassword() {
		return retypePassword;
	}
	/**
	 * @param retypePassword
	 *            The retypePassword to set.
	 */
	public void setRetypePassword(String retypePassword) {
		this.retypePassword = retypePassword;
	}
	/**
	 * @return Returns the username.
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username
	 *            The username to set.
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return Returns the newpassword.
	 */
	public String getNewPassword() {
		return newPassword;
	}
	/**
	 * @param newpassword
	 *            The newpassword to set.
	 */
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

}
