package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeOrderSanction;

/**
 *	Criminal sanction outcome transfer object.  
 *
 */
public class SanctionOutcomeTO  implements Serializable{

	private Long outcomeId;
	
	private Long criminalSanctionId;
	
	private Date outcomeDate;
	
	private BigDecimal appliedInvCost;
	
	private BigDecimal awardedInvCost;
	
	private BigDecimal appliedProsCost;
	
	private BigDecimal awardedProsCost;
	
	private BigDecimal appliedCompensation;
	
	private String description;
	
	private String confiscationNumber;
	
	private BigDecimal criminalCofiscationCost;
	
	private BigDecimal awardedCompensation;
	
	private String sentenceImposed;
	
	private String compensationPayee;

	private String otherSanction;
	
	private String outcomeStatus;
	
	private String createdStaffId;
	
	private Date createdTime;
	
	private String otherSanctionImposed;
	
	private String sanctionsImposed;
	
	private List<OutcomeOrderSanction> outcomeOrders= LazyList.decorate(
			new ArrayList(), FactoryUtils
			.instantiateFactory(OutcomeOrderSanction.class));

	private List<OutcomeAppliedSanction> outcomeAppliedSanctions=LazyList.decorate(
			new ArrayList(), FactoryUtils
			.instantiateFactory(OutcomeAppliedSanction.class));

	private List<SanctionApplied> sanctionsImposedList;
	
	private List<SanctionApplied> unsuccessSanctionsImposedList;	
	
	private List<SanctionApplied> ordersImposedList;

	final static String[] SANCTION_NAMES = { 
		"IMPRISONMENT", 
		"IMPRISONMENT - SUSPENDED", 
		"FINE", 
		"CAUTION", 
		"CONDITIONAL CAUTION",
		"COMMUNITY PUNISHMENT AND REHABILITATION ORDER",
		"COMMUNITY ORDERS",	
		"CONDITIONAL DISCHARGE", 
		"ABSOLUTE DISCHARGE",
		"INTERMITTENT CUSTODY",
		"CUSTODY PLUS", 
		"CURFEW ORDER",
		"COMMUNITY REHABILITATION",
		"DRUG TREATMENT AND TESTING ORDER",
		"ATTENDANCE CENTRE ORDER",
		"OTHER"
	};
	
	final static String[] UNSUCCESS_SANCTION_NAMES = { 
		"WITHDRAWAL",
		"ACQUITTAL"
	};
	
	final static String[] ORDER_NAMES = { 
		"ANTI SOCIAL BEHAVIOUR ORDER",
		"PROTECTION FROM HARASSMENT ORDER",
		"CONFISCATION ORDER",
		"COMPENSATION ORDER",
		"MENTAL HEALTH ACT ORDER",
		"CONDITIONAL ORDER CAUTION"
	};
	
	public SanctionOutcomeTO() {
		
		//initialize 
		sanctionsImposedList= new ArrayList<SanctionApplied>();
		for (String name: SANCTION_NAMES) {
			SanctionApplied data = new SanctionApplied();
			data.setSanctionName(name);
			data.setChecked(false);
			sanctionsImposedList.add(data);
		}
		
		ordersImposedList= new ArrayList<SanctionApplied>();
		for (String name: ORDER_NAMES) {
			SanctionApplied data = new SanctionApplied();
			data.setSanctionName(name);
			data.setChecked(false);
			ordersImposedList.add(data);
		}
		
		unsuccessSanctionsImposedList= new ArrayList<SanctionApplied>();
		for (String name: UNSUCCESS_SANCTION_NAMES) {
			SanctionApplied data = new SanctionApplied();
			data.setSanctionName(name);
			data.setChecked(false);
			unsuccessSanctionsImposedList.add(data);
		}
	}

	public static String[] getORDER_NAMES() {
		return ORDER_NAMES;
	}
	
	public BigDecimal getAppliedCompensation() {
		return appliedCompensation == null
				? appliedCompensation
				: appliedCompensation.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAppliedCompensation(BigDecimal appliedCompensation) {
		this.appliedCompensation = appliedCompensation;
	}

	public BigDecimal getAppliedInvCost() {
		return appliedInvCost == null ? appliedInvCost : appliedInvCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAppliedInvCost(BigDecimal appliedInvCost) {
		this.appliedInvCost = appliedInvCost;
	}

	public BigDecimal getAppliedProsCost() {
		return appliedProsCost == null ? appliedProsCost : appliedProsCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAppliedProsCost(BigDecimal appliedProsCost) {
		this.appliedProsCost = appliedProsCost;
	}

	public BigDecimal getAwardedCompensation() {
		return awardedCompensation == null
				? awardedCompensation
				: awardedCompensation.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAwardedCompensation(BigDecimal awardedCompensation) {
		this.awardedCompensation = awardedCompensation;
	}

	public BigDecimal getAwardedInvCost() {
		return awardedInvCost == null ? awardedInvCost : awardedInvCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAwardedInvCost(BigDecimal awardedInvCost) {
		this.awardedInvCost = awardedInvCost;
	}

	public BigDecimal getAwardedProsCost() {
		return awardedProsCost == null ? awardedProsCost : awardedProsCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAwardedProsCost(BigDecimal awardedProsCost) {
		this.awardedProsCost = awardedProsCost;
	}

	public String getCompensationPayee() {
		return compensationPayee;
	}

	public void setCompensationPayee(String compensationPayee) {
		this.compensationPayee = compensationPayee;
	}

	public String getConfiscationNumber() {
		return confiscationNumber;
	}

	public void setConfiscationNumber(String confiscationNumber) {
		this.confiscationNumber = confiscationNumber;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public BigDecimal getCriminalCofiscationCost() {
		return criminalCofiscationCost == null
				? criminalCofiscationCost
				: criminalCofiscationCost.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCriminalCofiscationCost(BigDecimal criminalCofiscationCost) {
		this.criminalCofiscationCost = criminalCofiscationCost;
	}

	public Long getCriminalSanctionId() {
		return criminalSanctionId;
	}

	public void setCriminalSanctionId(Long criminalSanctionId) {
		this.criminalSanctionId = criminalSanctionId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<SanctionApplied> getOrdersImposedList() {
		return ordersImposedList;
	}

	public void setOrdersImposedList(List<SanctionApplied> ordersImposedList) {
		this.ordersImposedList = ordersImposedList;
	}

	public String getOtherSanction() {
		return otherSanction;
	}

	public void setOtherSanction(String otherSanction) {
		this.otherSanction = otherSanction;
	}

	public String getOtherSanctionImposed() {
		return otherSanctionImposed;
	}

	public void setOtherSanctionImposed(String otherSanctionImposed) {
		this.otherSanctionImposed = otherSanctionImposed;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long outcomeId) {
		this.outcomeId = outcomeId;
	}

	public String getOutcomeStatus() {
		return outcomeStatus;
	}

	public void setOutcomeStatus(String outcomeStatus) {
		this.outcomeStatus = outcomeStatus;
	}

	public String getSanctionsImposed() {
		return sanctionsImposed;
	}

	public void setSanctionsImposed(String sanctionsImposed) {
		this.sanctionsImposed = sanctionsImposed;
	}

	public List<SanctionApplied> getSanctionsImposedList() {
		return sanctionsImposedList;
	}

	public void setSanctionsImposedList(List<SanctionApplied> sanctionsImposedList) {
		if (this.sanctionsImposedList != null) {		
			this.sanctionsImposedList = sanctionsImposedList;
		}	
	}

	public String getSentenceImposed() {
		return sentenceImposed;
	}

	public void setSentenceImposed(String sentenceImposed) {
		
			this.sentenceImposed = sentenceImposed;
		}
	

	public List<SanctionApplied> getUnsuccessSanctionsImposedList() {
		return unsuccessSanctionsImposedList;
	}

	public void setUnsuccessSanctionsImposedList(
			List<SanctionApplied> unsuccessSanctionsImposedList) {
		if (this.unsuccessSanctionsImposedList != null) {
			this.unsuccessSanctionsImposedList = unsuccessSanctionsImposedList;
		}
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public List<OutcomeAppliedSanction> getOutcomeAppliedSanctions() {
		return outcomeAppliedSanctions;
	}

	public void setOutcomeAppliedSanctions(
			List<OutcomeAppliedSanction> outcomeAppliedSanctions) {
		this.outcomeAppliedSanctions = outcomeAppliedSanctions;
	}

	public List<OutcomeOrderSanction> getOutcomeOrders() {
		return outcomeOrders;
	}

	public void setOutcomeOrders(List<OutcomeOrderSanction> outcomeOrders) {
		this.outcomeOrders = outcomeOrders;
	}
	
}
