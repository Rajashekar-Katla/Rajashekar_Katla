package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.ECMSConstants;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;
import uk.nhs.cfsms.ecms.data.common.UserObject;
import uk.nhs.cfsms.ecms.data.infoGath.InformationPermission;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * InformationTO is the Transfer object for the Information which holds existing
 * information
 * 
 * @author sChilukuri
 * 
 */
public class InformationTO implements Serializable {

	private static final long serialVersionUID = 6505443246159160182L;

	private Long informationId;

	private String informationNum;

	private String comment;
	
	private String newComment;

	private String type;

	private BigDecimal cost;

	private String isStillFraudOccuring;

	private Date startDate;

	private String isStartDateCorrect;

	private String orgCode;

	private String orgName;

	private String regionCode;

	private String informationDiscarded;

	private SourceInformationTO sourceInformationTO;

	private String createdStaffId;

	private Timestamp createdDate;

	private Long caseId;

	private Boolean hasPrimarySubject;

	private boolean readOnlyInfo = false;

	private String userName;

	private List<SubjectInformationTO> subjectInfoList = LazyList.decorate(
			new ArrayList(),
			FactoryUtils.instantiateFactory(SubjectInformationTO.class));

	private List<NHSSubjectInformationTO> nhsSubjectInfoList = LazyList
			.decorate(new ArrayList(), FactoryUtils
					.instantiateFactory(NHSSubjectInformationTO.class));

	private List<NonNHSSubjectInformationTO> nonNHSSubjectInfoList = LazyList
			.decorate(new ArrayList(), FactoryUtils
					.instantiateFactory(NonNHSSubjectInformationTO.class));

	private List<CaseContactTO> caseAssociates = LazyList.decorate(
			new ArrayList(),
			FactoryUtils.instantiateFactory(CaseContactTO.class));

	private List<VehicleTO> vehicles = LazyList.decorate(new ArrayList(),
			FactoryUtils.instantiateFactory(VehicleTO.class));

	private List<InformationProgressTO> informationProgress = LazyList
			.decorate(new ArrayList(), FactoryUtils
					.instantiateFactory(InformationProgressTO.class));

	private Map<String, List<LookupView>> infoLookupViewMap = new HashMap<String, List<LookupView>>();

	private Map<String, List<LookupView>> dynamicInfoLookupViewMap = new HashMap<String, List<LookupView>>();

	private List<InformationPermission> infoPermissionList = LazyList.decorate(
			new ArrayList(),
			FactoryUtils.instantiateFactory(InformationPermission.class));

	private List<AuthorizedSubmission> formFieldList = LazyList.decorate(
			new ArrayList(),
			FactoryUtils.instantiateFactory(AuthorizedSubmission.class));

	List<String> informationList = new ArrayList<String>();
	List<String> commentsList = new ArrayList<String>();

	private String title;

	private String informationDetails;
	
	private String newInformationDetails;

	private String newInformation;

	private String intelligenceContent;

	private String intelligenceURN;

	private Date informationDate;

	private List<TeamCodes> teamCodesList;

	private String teamCode;

	private String regionOverride;

	private boolean isFpuSystemWeakness;

	private UserObject dataOwner;

	private String state;

	private String rejectedComment;

	private Long fcrolId;

	private String infoProgressJsonString;

	/**
	 * Restructure April/2011. New Fraud Types by Area Type like.. areaType,
	 * Area, subArea, NHSFraudTypes
	 */

	private String areatype;

	private String fraudArea;

	private String otherFraudArea;

	private String fraudSubArea;

	private String otherSubArea;

	private String nhsFraudType;

	private String otherNHSFraudType;

	private Timestamp closedDate;

	private String closedStaffId;

	/**
	 * Phase-4 December/2011, evaluate
	 */

	private String evaluate;

	private String intelInfo;

	/**
	 * Phase-9 January 2013, information Transfer
	 */

	private InfoTransferHistTO infoTransferHistTO;

	public InfoTransferHistTO getInfoTransferHistTO() {
		return infoTransferHistTO;
	}

	public void setInfoTransferHistTO(InfoTransferHistTO infoTransferHistTO) {
		this.infoTransferHistTO = infoTransferHistTO;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public boolean getIsFpuSystemWeakness() {
		return isFpuSystemWeakness;
	}

	public void setFpuSystemWeakness(boolean isFpuSystemWeakness) {
		this.isFpuSystemWeakness = isFpuSystemWeakness;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public BigDecimal getCost() {
		return cost == null ? cost : cost.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getNewComment() {
		return newComment;
	}

	public void setNewComment(String newComment) {
		this.newComment = newComment;
	}

	public List<String> getCommentsList() {
		return commentsList;
	}

	public void setCommentsList(List<String> commentsList) {
		this.commentsList = commentsList;
	}

	public String getInformationDiscarded() {
		return informationDiscarded;
	}

	public void setInformationDiscarded(String informationDiscarded) {
		this.informationDiscarded = informationDiscarded;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getInformationNum() {
		return informationNum;
	}

	public void setInformationNum(String informationNum) {
		this.informationNum = informationNum;
	}

	public String getIsStartDateCorrect() {
		return isStartDateCorrect;
	}

	public void setIsStartDateCorrect(String isStartDateCorrect) {
		this.isStartDateCorrect = isStartDateCorrect;
	}

	public String getIsStillFraudOccuring() {
		return isStillFraudOccuring;
	}

	public void setIsStillFraudOccuring(String isStillFraudOccuring) {
		this.isStillFraudOccuring = isStillFraudOccuring;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public SourceInformationTO getSourceInformationTO() {
		return sourceInformationTO;
	}

	public void setSourceInformationTO(SourceInformationTO sourceInformationTO) {
		this.sourceInformationTO = sourceInformationTO;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public Map<String, List<LookupView>> getInfoLookupViewMap() {
		return getStaticInfoLookupViewMap();
	}

	public void addInfoLookupViewMap(String name, List<LookupView> list) {
		infoLookupViewMap.put(name, list);
	}

	public List<LookupView> getInfoLookupViewMapByName(String name) {
		return this.getStaticInfoLookupViewMap().get(name);
	}

	private Map<String, List<LookupView>> getStaticInfoLookupViewMap() {
		if (this.infoLookupViewMap == null
				|| (this.infoLookupViewMap != null && this.infoLookupViewMap
						.size() < 12)) {
			return EcmsUtils.getInstance().getInfoLookupViewMap();
		}
		return infoLookupViewMap;
	}

	public void setStaticInfoLookupViewMap() {

		Map<String, List<LookupView>> map = EcmsUtils.getInstance()
				.getInfoLookupViewMap();

		if (null != this.infoLookupViewMap && !this.infoLookupViewMap.isEmpty()) {

			if (null != map) {

				map.putAll(this.infoLookupViewMap);
			} else {

				EcmsUtils.getInstance().setInfoLookupViewMap(
						this.infoLookupViewMap);
			}
		}
	}

	public Map<String, List<LookupView>> getDynamicInfoLookupViewMap() {
		return dynamicInfoLookupViewMap;
	}

	public void setDynamicInfoLookupViewMap(
			Map<String, List<LookupView>> dynamicInfoLookupViewMap) {
		this.dynamicInfoLookupViewMap = dynamicInfoLookupViewMap;
	}

	public void addDynamicInfoLookupViewMap(String name, List<LookupView> list) {
		dynamicInfoLookupViewMap.put(name, list);
	}

	public List<NHSSubjectInformationTO> getNhsSubjectInfoList() {
		return nhsSubjectInfoList;
	}

	public void setNhsSubjectInfoList(
			List<NHSSubjectInformationTO> nhsSubjectInfoList) {
		this.nhsSubjectInfoList = nhsSubjectInfoList;
	}

	public List<NonNHSSubjectInformationTO> getNonNHSSubjectInfoList() {
		return nonNHSSubjectInfoList;
	}

	public void setNonNHSSubjectInfoList(
			List<NonNHSSubjectInformationTO> nonNHSSubjectInfoList) {
		this.nonNHSSubjectInfoList = nonNHSSubjectInfoList;
	}

	public List<SubjectInformationTO> getSubjectInfoList() {
		return subjectInfoList;
	}

	public void setSubjectInfoList(List<SubjectInformationTO> subjectInfoList) {
		this.subjectInfoList = subjectInfoList;
	}

	public Boolean getHasPrimarySubject() {
		return hasPrimarySubject;
	}

	public void setHasPrimarySubject(Boolean hasPrimarySubject) {
		this.hasPrimarySubject = hasPrimarySubject;
	}

	public List<InformationPermission> getInfoPermissionList() {
		return infoPermissionList;
	}

	public void setInfoPermissionList(
			List<InformationPermission> infoPermissionList) {
		this.infoPermissionList = infoPermissionList;
	}

	public List<AuthorizedSubmission> getFormFieldList() {
		return formFieldList;
	}

	public void setFormFieldList(List<AuthorizedSubmission> formFieldList) {
		this.formFieldList = formFieldList;
	}

	public String getAssignedUserFromInfoPermissions() {
		if (infoPermissionList != null)
			for (InformationPermission informationPerm : infoPermissionList) {
				if (informationPerm != null
						&& informationPerm.getPermissionType().equals(
								ECMSConstants.INFO_ASSIGNEE_PERMISSION)) {
					return informationPerm.getPermissionValue();

				}
			}
		return null;
	}

	public String getOrgFromInfoPermissions() {
		if (infoPermissionList != null)
			for (InformationPermission informationPerm : infoPermissionList) {
				if (informationPerm != null
						&& informationPerm.getPermissionType().equals(
								ECMSConstants.ORGANISATIONAL_PERMISSION)) {
					return informationPerm.getPermissionValue();
				}
			}
		return null;

	}

	public String getTeamFromInfoPermissions() {
		if (infoPermissionList != null)
			for (InformationPermission informationPerm : infoPermissionList) {
				if (informationPerm != null
						&& informationPerm.getPermissionType().equals(
								ECMSConstants.TEAM_PERMISSION)) {
					return informationPerm.getPermissionValue();
				}
			}
		return null;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);

	}

	/**
	 * Has valid Organisation code.
	 * 
	 * @return boolean.
	 */
	public boolean hasValidOrgCode() {

		if (orgCode != null && StringUtils.isNotEmpty(orgCode)
				&& orgCode.indexOf(",") == -1) {
			return true;
		}
		return false;
	}

	public Date getInformationDate() {
		return informationDate;
	}

	public void setInformationDate(Date informationDate) {
		this.informationDate = informationDate;
	}

	public String getInformationDetails() {
		return informationDetails;
	}

	public void setInformationDetails(String informationDetails) {
		this.informationDetails = informationDetails;
		if (this.informationDetails != null) {
			String[] array = this.informationDetails.split("###");
			for (String infoRecord : array) {
				this.informationList.add(infoRecord);
			}
			//Collections.reverse(informationList);			
		}
	}
	public void setComment(String comments) {
		this.comment = comments;
		if (this.comment != null) {
			String[] array = this.comment.split("###");
			for (String comment : array) {
				this.commentsList.add(comment);
			}
		}
	}
	
	public String getComment() {
		return comment;
	}

	public String getIntelligenceContent() {
		return intelligenceContent;
	}

	public void setIntelligenceContent(String intelligenceContent) {
		this.intelligenceContent = intelligenceContent;
	}

	public String getIntelligenceURN() {
		return intelligenceURN;
	}

	public void setIntelligenceURN(String intelligenceURN) {
		this.intelligenceURN = intelligenceURN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public List<CaseContactTO> getCaseAssociates() {
		return caseAssociates;
	}

	public void setCaseAssociates(List<CaseContactTO> caseAssociates) {
		this.caseAssociates = caseAssociates;
	}

	public List<VehicleTO> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<VehicleTO> vehicles) {
		this.vehicles = vehicles;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public List<TeamCodes> getTeamCodesList() {
		return teamCodesList;
	}

	public void setTeamCodesList(List<TeamCodes> teamCodesList) {
		this.teamCodesList = teamCodesList;
	}

	public String getNewInformation() {
		return newInformation;
	}

	public void setNewInformation(String newInformation) {
		this.newInformation = newInformation;
		if (StringUtils.isNotEmpty(this.newInformation)) {
			if (StringUtils.isNotEmpty(this.informationDetails)) {
				this.informationDetails += "###";
			}
			this.informationDetails += this.newInformation;
		}
	}

	public List<String> getInformationList() {
		return informationList;
	}

	public void setInformationList(List<String> informationList) {
		this.informationList = informationList;
	}

	public String getRegionOverride() {
		return regionOverride;
	}

	public void setRegionOverride(String regionOverride) {
		this.regionOverride = regionOverride;
	}

	public UserObject getDataOwner() {
		return dataOwner;
	}

	public void setDataOwner(UserObject dataOwner) {
		this.dataOwner = dataOwner;
	}

	public String getRejectedComment() {
		return rejectedComment;
	}

	public void setRejectedComment(String rejectedComment) {
		this.rejectedComment = rejectedComment;
	}

	public Long getFcrolId() {
		return fcrolId;
	}

	public void setFcrolId(Long fcrolId) {
		this.fcrolId = fcrolId;
	}

	public String getAreatype() {
		return areatype;
	}

	public void setAreatype(String areatype) {
		this.areatype = areatype;
	}

	public String getFraudArea() {
		return fraudArea;
	}

	public void setFraudArea(String fraudArea) {
		this.fraudArea = fraudArea;
	}

	public String getFraudSubArea() {
		return fraudSubArea;
	}

	public void setFraudSubArea(String fraudSubArea) {
		this.fraudSubArea = fraudSubArea;
	}

	public String getNhsFraudType() {
		return nhsFraudType;
	}

	public void setNhsFraudType(String nhsFraudType) {
		this.nhsFraudType = nhsFraudType;
	}

	public String getOtherSubArea() {
		return otherSubArea;
	}

	public void setOtherSubArea(String otherSubArea) {
		this.otherSubArea = otherSubArea;
	}

	public String getOtherNHSFraudType() {
		return otherNHSFraudType;
	}

	public void setOtherNHSFraudType(String otherNHSFraudType) {
		this.otherNHSFraudType = otherNHSFraudType;
	}

	public void setInfoLookupViewMap(
			Map<String, List<LookupView>> infoLookupViewMap) {
		this.infoLookupViewMap = infoLookupViewMap;
	}

	public String getOtherFraudArea() {
		return otherFraudArea;
	}

	public void setOtherFraudArea(String otherFraudArea) {
		this.otherFraudArea = otherFraudArea;
	}

	public Timestamp getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(Timestamp closedDate) {
		this.closedDate = closedDate;
	}

	public String getClosedStaffId() {
		return closedStaffId;
	}

	public void setClosedStaffId(String closedStaffId) {
		this.closedStaffId = closedStaffId;
	}

	public String getEvaluate() {
		return evaluate;
	}

	public void setEvaluate(String evaluate) {
		this.evaluate = evaluate;
	}

	public boolean isReadOnlyInfo() {
		return readOnlyInfo;
	}

	public void setReadOnlyInfo(boolean readOnlyInfo) {
		this.readOnlyInfo = readOnlyInfo;
	}

	public void setIntelInfo(String intelInfo) {
		this.intelInfo = intelInfo;
	}

	public String getIntelInfo() {
		return intelInfo;
	}

	public String getInfoProgressJsonString() {
		return infoProgressJsonString;
	}

	public void setInfoProgressJsonString(String infoProgressJsonString) {
		this.infoProgressJsonString = infoProgressJsonString;
	}

	public List<InformationProgressTO> getInformationProgress() {
		return informationProgress;
	}

	public void setInformationProgress(
			List<InformationProgressTO> informationProgress) {
		this.informationProgress = informationProgress;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getNewInformationDetails() {
		return newInformationDetails;
	}

	public void setNewInformationDetails(String newInformationDetails) {
		this.newInformationDetails = newInformationDetails;
	}
	
}
