package uk.nhs.cfsms.ecms.dto.caseInfo;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

public class MessageTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3854368413233910592L;

	private Long messageId;

	private Long caseId;

	private String caseRef;

	private Long informationId;

	private String fromStaffId;

	private String toStaffId;

	private String message;

	private String state;

	private String createdStaffId;

	private Date createdTime;

	private Date readTime;

	private Date deletedTime;

	private String fromStaffName;

	private String toStaffName;

	private String informationRef;

	private String nitsLeadState;

	private String nitnLeadState;

	private String actionDetails;

	private String messageType;

	public enum Message_types {
		INFORMATION_TRANSFER, INFORMATION_ALLOCATION, CASE_ALLOCATION, CASE_TRANSFER, CFS_TRANSFER_APPROVAL_REQUEST, CFS_TRANSFER_APPROVAL_DECLINED, CASE_CLOSURE, CASE_CLOSURE_ACCEPTED, CASE_CLOSURE_REJECTED, CASE_REOPEN, IMO_AFL_REFERRAL, IIU_IMO_REFERRAL, INFO_CLOSURE, CASE_ACTION_ALLOCATION, CASE_ACTION_REJECTED, CASE_ACTION_ALERT, CASE_ACTION_INPROGRESS, CASE_ACTION_COMPLETED, INFORMATION_TRANSFER_REQUEST, INFORMATION_TRANSFER_APPROVED, INFORMATION_TRANSFER_REJECTED
	};

	private Long parentId;

	/**
	 * Fields introduced to track the deletion status for the various users.
	 * Deletion status changes starts.
	 * **/

	private String deleteFrom;

	private String deleteTo;

	private String deleteNits;

	private String deleteNitn;

	private String markAsUnread;

	private String actionTitle;

	/**
	 * Deletion status Changes Ends.
	 * 
	 * **/

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCaseRef() {
		return caseRef;
	}

	public void setCaseRef(String caseRef) {
		this.caseRef = caseRef;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getDeletedTime() {
		return deletedTime;
	}

	public void setDeletedTime(Date deletedTime) {
		this.deletedTime = deletedTime;
	}

	public String getFromStaffId() {
		return fromStaffId;
	}

	public void setFromStaffId(String fromStaffId) {
		this.fromStaffId = fromStaffId;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public Date getReadTime() {
		return readTime;
	}

	public void setReadTime(Date readTime) {
		this.readTime = readTime;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getToStaffId() {
		return toStaffId;
	}

	public void setToStaffId(String toStaffId) {
		this.toStaffId = toStaffId;
	}

	public String getFromStaffName() {
		return fromStaffName;
	}

	public void setFromStaffName(String fromStaffName) {
		this.fromStaffName = fromStaffName;
	}

	public String getToStaffName() {
		return toStaffName;
	}

	public void setToStaffName(String toStaffName) {
		this.toStaffName = toStaffName;
	}

	public String getInformationRef() {
		return informationRef;
	}

	public void setInformationRef(String informationRef) {
		this.informationRef = informationRef;
	}

	public String getNitsLeadState() {
		return nitsLeadState;
	}

	public void setNitsLeadState(String nitsLeadState) {
		this.nitsLeadState = nitsLeadState;
	}

	public String getNitnLeadState() {
		return nitnLeadState;
	}

	public void setNitnLeadState(String nitnLeadState) {
		this.nitnLeadState = nitnLeadState;
	}

	public String getActionDetails() {
		return actionDetails;
	}

	public void setActionDetails(String actionDetails) {
		this.actionDetails = actionDetails;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getDeleteFrom() {
		return deleteFrom;
	}

	public void setDeleteFrom(String deleteFrom) {
		this.deleteFrom = deleteFrom;
	}

	public String getDeleteTo() {
		return deleteTo;
	}

	public void setDeleteTo(String deleteTo) {
		this.deleteTo = deleteTo;
	}

	public String getDeleteNits() {
		return deleteNits;
	}

	public void setDeleteNits(String deleteNits) {
		this.deleteNits = deleteNits;
	}

	public String getDeleteNitn() {
		return deleteNitn;
	}

	public void setDeleteNitn(String deleteNitn) {
		this.deleteNitn = deleteNitn;
	}

	public String getMarkAsUnread() {
		return markAsUnread;
	}

	public void setMarkAsUnread(String markAsUnread) {
		this.markAsUnread = markAsUnread;
	}

	public String getActionTitle() {
		return actionTitle;
	}

	public void setActionTitle(String actionTitle) {
		this.actionTitle = actionTitle;
	}

}
