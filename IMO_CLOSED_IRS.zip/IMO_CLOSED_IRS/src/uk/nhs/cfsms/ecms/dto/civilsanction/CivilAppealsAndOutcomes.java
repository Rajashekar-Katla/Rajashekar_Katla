package uk.nhs.cfsms.ecms.dto.civilsanction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanctionOutcome;

public class CivilAppealsAndOutcomes implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3520699013667781378L;

	private List<CivilAppealTO> appealsList = new ArrayList<CivilAppealTO>();
	
	private List<CivilSanctionOutcome> sanctionOutComes =  new ArrayList<CivilSanctionOutcome>();
	
	private List<CivilAppealOutcomeTO> appealsOutComes =  new ArrayList<CivilAppealOutcomeTO>();
	
	private List<CivilAppealAndSanctionOutcome> outcomeList ;

	public List<CivilAppealTO> getAppealsList() {
		return appealsList;
	}

	public void setAppealsList(List<CivilAppealTO> appealsList) {
		this.appealsList = appealsList;
	}

	public List<CivilSanctionOutcome> getSanctionOutComes() {
		return sanctionOutComes;
	}

	public void setSanctionOutComes(List<CivilSanctionOutcome> sanctionOutComes) {
		this.sanctionOutComes = sanctionOutComes;
	}

	public List<CivilAppealOutcomeTO> getAppealsOutComes() {
		return appealsOutComes;
	}

	public void setAppealsOutComes(List<CivilAppealOutcomeTO> appealsOutComes) {
		this.appealsOutComes = appealsOutComes;
	}
	
	
	public List<CivilAppealAndSanctionOutcome> getOutcomes(){
		if(outcomeList == null){
			outcomeList = new ArrayList<CivilAppealAndSanctionOutcome>();
		}
		return outcomeList;
	}


	public void setOutcomeList(List<CivilAppealAndSanctionOutcome> outcomeList) {
		this.outcomeList = outcomeList;
	}

	public List<CivilAppealAndSanctionOutcome> getOutcomeList() {
		if(outcomeList == null){
			outcomeList = new ArrayList<CivilAppealAndSanctionOutcome>();
		}
		return outcomeList;
	}
	
	 
}
