package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;
import java.util.List;

public class AuthorizedSubmission implements Serializable{

	String name;

	String value;

	List<String> permissionLevelList;

	List<String> onClickEventList;
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getPermissionLevelList() {
		return permissionLevelList;
	}

	public void setPermissionLevelList(List<String> permissionLevelList) {
		this.permissionLevelList = permissionLevelList;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public List<String> getOnClickEventList() {
		return onClickEventList;
	}

	public void setOnClickEventList(List<String> onClickEventList) {
		this.onClickEventList = onClickEventList;
	}
	
}
