package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.apache.commons.lang.StringUtils;

import uk.nhs.cfsms.ecms.data.infoGath.Address;
import uk.nhs.cfsms.ecms.data.infoGath.BankDetails;
import uk.nhs.cfsms.ecms.data.infoGath.FcrolAddress;
import uk.nhs.cfsms.ecms.data.infoGath.FcrolPersonContacts;
import uk.nhs.cfsms.ecms.data.infoGath.PersonAlias;
import uk.nhs.cfsms.ecms.data.infoGath.PersonContacts;

public class PersonTO implements Serializable {

	private static final long serialVersionUID = -6619182880536219048L;

	private Long personId;

	private String title;

	private String otherTitle;

	private String firstName;

	private String lastName;

	private String otherName;

	private String occupation;

	private String orgName;

	private String orgCode;

	private Date dob;

	private PersonDescriptionTO personDescriptionTO;

	private String gender;

	private String ethnicCode;

	private String personType;

	private String niNumber;

	// version 3...
	private String knownAs;

	private String isPersonNhs;

	private String otherOccupation;

	private String nationality;

	private String passportNumber;

	private String drivingLicenseNumber;

	private String nhsNumber;

	private String payrollNumber;

	private String religion;

	private String placeOfBirth;

	private String isPersonNhsPatient;
	private String treatmant;
	private String patientType;
	private String linkToNhs;

	private String patientOccupation;

	private String patientOrganisation;

	private String otherInformation;

	private String professionalBody;

	private String registrationNumber;

	private String otherIdentifier;

	private String age;
	
	private String personIntelReference;
	
	private String nonNHSOccupation;
	private String nonNHSEmployer;
	
	private List<Address> addressList = LazyList.decorate(new ArrayList(),
			FactoryUtils.instantiateFactory(Address.class));

	private List<PersonContacts> contactsList = LazyList.decorate(new ArrayList(), 
			FactoryUtils.instantiateFactory(PersonContacts.class));

	private List<FcrolAddress> fcAddressList = LazyList.decorate(new ArrayList(), 
			FactoryUtils.instantiateFactory(FcrolAddress.class));

	private List<FcrolPersonContacts> fcContactsList = LazyList.decorate(new ArrayList(), 
			FactoryUtils.instantiateFactory(FcrolPersonContacts.class));

	private List<PersonAlias> aliasList = LazyList.decorate(new ArrayList(),
			FactoryUtils.instantiateFactory(PersonAlias.class));

	// Phase 3 additions.
	private List<BankDetails> bankList = LazyList.decorate(new ArrayList(),
			FactoryUtils.instantiateFactory(BankDetails.class));
	
	/** As part of Restructure from April 2011. NHS career areas and occupation type **/  
	private String nhsCareerArea;
	
	private String nhsOccupationType;
	
	private String otherNHSOccupationType; 
	
	private String patientOccupationType;
	
	private String patientOccupationByType;

	private String otherPatientOccupation;
	
	private String otherOccupationType;
	
	private String otherNHSCareerArea;
	
	private String otherNHSPatientType;
	
	
	public PersonTO() {
		this.personDescriptionTO = new PersonDescriptionTO();
		
		this.addressList = LazyList.decorate(new ArrayList(),
				FactoryUtils.instantiateFactory(Address.class));

		this.contactsList = LazyList.decorate(new ArrayList(), 
				FactoryUtils.instantiateFactory(PersonContacts.class));

		this.fcAddressList = LazyList.decorate(new ArrayList(), 
				FactoryUtils.instantiateFactory(FcrolAddress.class));

		this.fcContactsList = LazyList.decorate(new ArrayList(), 
				FactoryUtils.instantiateFactory(FcrolPersonContacts.class));

		this.aliasList = LazyList.decorate(new ArrayList(),
				FactoryUtils.instantiateFactory(PersonAlias.class));

		this.bankList = LazyList.decorate(new ArrayList(),
				FactoryUtils.instantiateFactory(BankDetails.class));
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNiNumber() {
		return niNumber;
	}

	public void setNiNumber(String niNumber) {
		this.niNumber = niNumber;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOtherName() {
		return otherName;
	}

	public void setOtherName(String otherName) {
		this.otherName = otherName;
	}

	public PersonDescriptionTO getPersonDescriptionTO() {
		return personDescriptionTO;
	}

	public void setPersonDescriptionTO(PersonDescriptionTO personDescriptionTO) {
		this.personDescriptionTO = personDescriptionTO;
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		// if (StringUtils.isNotEmpty(title)
		// && !(title.trim().equalsIgnoreCase("Other"))) {
		this.title = title;
		// }
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getEthnicCode() {
		return ethnicCode;
	}

	public void setEthnicCode(String ethnicCode) {
		this.ethnicCode = ethnicCode;
	}

	public String getDrivingLicenseNumber() {
		return drivingLicenseNumber;
	}

	public void setDrivingLicenseNumber(String drivingLicenseNumber) {
		this.drivingLicenseNumber = drivingLicenseNumber;
	}

	public String getIsPersonNhs() {
		return isPersonNhs;
	}

	public void setIsPersonNhs(String isPersonNhs) {
		this.isPersonNhs = isPersonNhs;
	}

	public String getKnownAs() {
		return knownAs;
	}

	public void setKnownAs(String knownAs) {
		this.knownAs = knownAs;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getNhsNumber() {
		return nhsNumber;
	}

	public void setNhsNumber(String nhsNumber) {
		this.nhsNumber = nhsNumber;
	}

	public String getOtherOccupation() {
		return otherOccupation;
	}

	public void setOtherOccupation(String otherOccupation) {
		this.otherOccupation = otherOccupation;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getPayrollNumber() {
		return payrollNumber;
	}

	public void setPayrollNumber(String payrollNumber) {
		this.payrollNumber = payrollNumber;
	}

	public String getPersonType() {
		return personType;
	}

	public void setPersonType(String personType) {
		this.personType = personType;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getOtherTitle() {
		return otherTitle;
	}

	public void setOtherTitle(String otherTitle) {
		this.otherTitle = otherTitle;
	}

	/**
	 * Has valid Organisation code.
	 * 
	 * @return boolean.
	 */
	public boolean hasValidOrgCode() {

		if (orgCode != null && StringUtils.isNotEmpty(orgCode)
				&& orgCode.indexOf(",") == -1) {
			return true;
		}
		return false;
	}

	public List<Address> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}

	public void addAddress(Address address) {
		this.addressList.add(address);
	}

	public List<PersonContacts> getContactsList() {
		return contactsList;
	}

	public void setContactsList(List<PersonContacts> contactsList) {
		this.contactsList = contactsList;
	}

	public List<PersonAlias> getAliasList() {
		return aliasList;
	}

	public void setAliasList(List<PersonAlias> aliasList) {
		this.aliasList = aliasList;
	}

	public void addContacts(PersonContacts contact) {
		this.contactsList.add(contact);
	}

	public void addAlias(PersonAlias alias) {
		this.aliasList.add(alias);
	}
	
	public void addBankDetails(BankDetails details) {
		this.bankList.add(details);
	}	

	private void updatePersonAddressDetails() {
		if (isListNullOrEmpty(this.getAddressList())) {

			Address address = new Address();
			address.setPersonId(this.getPersonId());

			if (this.getAddressList() == null) {

				List<Address> list = new ArrayList<Address>();
				list.add(address);
				this.setAddressList(list);
			} else if (this.getAddressList() != null
					&& this.getAddressList().isEmpty()) {
				this.addAddress(address);
			}
		}
	}

	private void updatePersonContacts() {

		if (isListNullOrEmpty(this.getContactsList())) {

			PersonContacts contacts = new PersonContacts();
			contacts.setPersonId(this.getPersonId());

			if (this.getContactsList() == null) {

				List<PersonContacts> list = new ArrayList<PersonContacts>();
				list.add(contacts);
				this.setContactsList(list);
			} else if (this.getContactsList() != null
					&& this.getContactsList().isEmpty()) {
				this.addContacts(contacts);
			}
		}
	}

	private void updatePersonAliasDetails() {

		if (isListNullOrEmpty(this.getAliasList())) {

			PersonAlias alias = new PersonAlias();
			alias.setPersonId(this.getPersonId());

			if (this.getAliasList() == null) {

				List<PersonAlias> list = new ArrayList<PersonAlias>();
				list.add(alias);
				this.setAliasList(list);
			} else if (this.getAliasList() != null
					&& this.getAliasList().isEmpty()) {
				this.addAlias(alias);
			}
		}
	}
	
	private void updatePersonBankDetails() {

		if (isListNullOrEmpty(this.getBankList())) {

			BankDetails bankDetails = new BankDetails();
			bankDetails.setPersonId(this.getPersonId());

			if (this.getBankList() == null) {

				List<BankDetails> list = new ArrayList<BankDetails>();
				list.add(bankDetails);
				this.setBankList(list);
			} else if (this.getBankList() != null
					&& this.getBankList().isEmpty()) {
				this.addBankDetails(bankDetails);
			}
		}
	}

	private boolean isListNullOrEmpty(List list) {

		if (list == null || (list != null && list.isEmpty())) {
			return true;
		}
		return false;
	}

	public void updateAllPersonListDetails() {
		this.updatePersonAddressDetails();
		this.updatePersonContacts();
		this.updatePersonAliasDetails();
		this.updatePersonBankDetails();
	}

	public String getIsPersonNhsPatient() {
		return isPersonNhsPatient;
	}

	public void setIsPersonNhsPatient(String isPersonNhsPatient) {
		this.isPersonNhsPatient = isPersonNhsPatient;
	}

	public String getLinkToNhs() {
		return linkToNhs;
	}

	public void setLinkToNhs(String linkToNhs) {
		this.linkToNhs = linkToNhs;
	}

	public String getPatientType() {
		return patientType;
	}

	public void setPatientType(String patientType) {
		this.patientType = patientType;
	}

	public String getTreatmant() {
		return treatmant;
	}

	public void setTreatmant(String treatmant) {
		this.treatmant = treatmant;
	}

	public String getOtherInformation() {
		return otherInformation;
	}

	public void setOtherInformation(String otherInformation) {
		this.otherInformation = otherInformation;
	}

	public String getPatientOccupation() {
		return patientOccupation;
	}

	public void setPatientOccupation(String patientOccupation) {
		this.patientOccupation = patientOccupation;
	}

	public String getPatientOrganisation() {
		return patientOrganisation;
	}

	public void setPatientOrganisation(String patientOrganisation) {
		this.patientOrganisation = patientOrganisation;
	}

	public String getOtherIdentifier() {
		return otherIdentifier;
	}

	public void setOtherIdentifier(String otherIdentifier) {
		this.otherIdentifier = otherIdentifier;
	}

	public String getProfessionalBody() {
		return professionalBody;
	}

	public void setProfessionalBody(String professionalBody) {
		this.professionalBody = professionalBody;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}
	
	public String getNonNHSOccupation() {
		return nonNHSOccupation;
	}

	public void setNonNHSOccupation(String nonNHSOccupation) {
		this.nonNHSOccupation = nonNHSOccupation;
	}

	public String getNonNHSEmployer() {
		return nonNHSEmployer;
	}

	public void setNonNHSEmployer(String nonNHSEmployer) {
		this.nonNHSEmployer = nonNHSEmployer;
	}

	public List<FcrolAddress> getFcAddressList() {
		return fcAddressList;
	}

	public void setFcAddressList(List<FcrolAddress> fcaddressList) {
		this.fcAddressList = fcaddressList;
	}

	public List<FcrolPersonContacts> getFcContactsList() {
		return fcContactsList;
	}

	public void setFcContactsList(List<FcrolPersonContacts> fccontactsList) {
		this.fcContactsList = fccontactsList;
	}

	public List<BankDetails> getBankList() {
		return bankList;
	}

	public void setBankList(List<BankDetails> bankList) {
		this.bankList = bankList;
	}

	public String getNhsCareerArea() {
		return nhsCareerArea;
	}

	public void setNhsCareerArea(String nhsCareerArea) {
		this.nhsCareerArea = nhsCareerArea;
	}

	public String getNhsOccupationType() {
		return nhsOccupationType;
	}

	public void setNhsOccupationType(String nhsOccupationType) {
		this.nhsOccupationType = nhsOccupationType;
	}

	public String getOtherNHSOccupationType() {
		return otherNHSOccupationType;
	}

	public void setOtherNHSOccupationType(String otherNHSOccupationType) {
		this.otherNHSOccupationType = otherNHSOccupationType;
	}

	public String getPatientOccupationType() {
		return patientOccupationType;
	}

	public void setPatientOccupationType(String patientOccupationType) {
		this.patientOccupationType = patientOccupationType;
	}

	public String getOtherOccupationType() {
		return otherOccupationType;
	}

	public void setOtherOccupationType(String otherOccupationType) {
		this.otherOccupationType = otherOccupationType;
	}

	public String getPatientOccupationByType() {
		return patientOccupationByType;
	}

	public void setPatientOccupationByType(String patientOccupationByType) {
		this.patientOccupationByType = patientOccupationByType;
	}

	public String getOtherPatientOccupation() {
		return otherPatientOccupation;
	}

	public void setOtherPatientOccupation(String otherPatientOccupation) {
		this.otherPatientOccupation = otherPatientOccupation;
	}
	
	public boolean isPersonWorkingForNHS() {
		if (null != isPersonNhs && (
				isPersonNhs.equalsIgnoreCase("YES") || 
				isPersonNhs.indexOf("Y") != -1)) {
			return true;
		}
		return false;
	}
	
	public boolean isPersonNHSPatient() {
		if (null != isPersonNhsPatient && (
				isPersonNhsPatient.equalsIgnoreCase("YES") || 
				isPersonNhsPatient.indexOf("Y") != -1)) {
			return true;
		}
		return false;
	}

	public String getOtherNHSCareerArea() {
		return otherNHSCareerArea;
	}

	public void setOtherNHSCareerArea(String otherNHSCareerArea) {
		this.otherNHSCareerArea = otherNHSCareerArea;
	}

	public String getOtherNHSPatientType() {
		return otherNHSPatientType;
	}

	public void setOtherNHSPatientType(String otherNHSPatientType) {
		this.otherNHSPatientType = otherNHSPatientType;
	}
	
	public String getPersonIntelReference() {
		return personIntelReference;
	}

	public void setPersonIntelReference(String personIntelReference) {
		this.personIntelReference = personIntelReference;
	}

	public String getFullName() {
		StringBuffer sb = new StringBuffer("");
		if (this.title != null)
			sb.append(this.title).append(" ");
		if (this.firstName != null)
			sb.append(this.firstName).append(" ");
		if (this.firstName != null)
			sb.append(this.lastName);
		return sb.toString();
	}

}