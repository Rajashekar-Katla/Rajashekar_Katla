package uk.nhs.cfsms.ecms.dto.cps;

import java.sql.Timestamp;

public class CpsMailDto {

	private Long caseID;
	private String investigationStage;
	private String to;
	private String cc;
	private String subject;
	private String message;
	private String attachedDocs;
	private String senderName;
	private String senderEmailId;
	private Timestamp emailDate;

	public String getInvestigationStage() {
		return investigationStage;
	}

	public void setInvestigationStage(String investigationStage) {
		this.investigationStage = investigationStage;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSenderEmailId() {
		return senderEmailId;
	}

	public void setSenderEmailId(String senderEmailId) {
		this.senderEmailId = senderEmailId;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public Long getCaseID() {
		return caseID;
	}

	public void setCaseID(Long caseID) {
		this.caseID = caseID;
	}

	public Timestamp getEmailDate() {
		return emailDate;
	}

	public void setEmailDate(Timestamp emailDate) {
		this.emailDate = emailDate;
	}

	public String getAttachedDocs() {
		return attachedDocs;
	}

	public void setAttachedDocs(String attachedDocs) {
		this.attachedDocs = attachedDocs;
	}

}
