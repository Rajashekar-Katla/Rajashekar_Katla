package uk.nhs.cfsms.ecms.dto.caseInfo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import uk.nhs.cfsms.ecms.data.common.LookupView;

public class CaseClosureTO implements Serializable {

	private Long caseClosureId;

	private String description;

	private String closureCategory;

	private String comments;

	private String systemWeakness;

	private byte[] closureReport;

	private String createdStaffId;

	private Date closureDate;

	private Date destructionDate;

	private Date createdDate;

	private Long caseId;

	private List<LookupView> categoryList;

	private String isReportUploaded;

	private BigDecimal recoveredAmount;

	private BigDecimal fraudAmount;

	private BigDecimal fraudAmountLoss;

	private BigDecimal nonFraudAmountLoss;

	private String closureReportFileType;

	private String closureReportFileName;

	private Long noOfAddPowersUsed;

	private List<LookupView> newCategoryPart1List;

	private List<LookupView> newCategoryPart2List;

	private String newClosureCategoryPart1;

	private Integer noOfSanctionsCateg2_1;

	private Integer noOfSanctionsCateg2_2;

	private Integer noOfSanctionsCateg2_3;

	private Integer noOfSanctionsCateg2_4;

	private Integer noOfSanctionsCateg2_5;

	private Integer noOfSanctionsCateg2_6;

	private Integer noOfSanctionsCateg2_7;

	private Integer noOfSanctionsCateg2_8;

	private Integer noOfSanctionsCateg2_9;

	private Integer noOfSanctionsCateg2_10;

	private Integer noOfSanctionsCateg2_11;

	private Integer criminalSanctionsNo;

	private Integer civilSanctionsNo;

	private Integer internalDispSanctionsNo;

	private Integer externalDispSanctionsNo;

	public Long getNoOfAddPowersUsed() {
		return noOfAddPowersUsed;
	}

	public void setNoOfAddPowersUsed(Long noOfAddPowersUsed) {
		this.noOfAddPowersUsed = noOfAddPowersUsed;
	}

	public String getIsReportUploaded() {
		if (null != closureReport && closureReport.length > 10) {
			return "YES";
		} else {
			return "NO";
		}
	}

	public void setIsReportUploaded(String isReportUploaded) {
		this.isReportUploaded = isReportUploaded;
	}

	public Long getCaseClosureId() {
		return caseClosureId;
	}

	public void setCaseClosureId(Long caseClosureId) {
		this.caseClosureId = caseClosureId;
	}

	public String getClosureCategory() {
		return closureCategory;
	}

	public void setClosureCategory(String closureCategory) {
		this.closureCategory = closureCategory;
	}

	public Date getClosureDate() {
		return closureDate;
	}

	public void setClosureDate(Date closureDate) {
		this.closureDate = closureDate;
	}

	public byte[] getClosureReport() {
		return closureReport;
	}

	public void setClosureReport(byte[] closureReport) {
		this.closureReport = closureReport;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSystemWeakness() {
		return systemWeakness;
	}

	public void setSystemWeakness(String systemWeakness) {
		this.systemWeakness = systemWeakness;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public List<LookupView> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<LookupView> categoryList) {
		this.categoryList = categoryList;
	}

	public BigDecimal getFraudAmount() {
		return fraudAmount == null ? fraudAmount : fraudAmount.setScale(2,
				BigDecimal.ROUND_DOWN);
	}

	public void setFraudAmount(BigDecimal fraudAmount) {
		this.fraudAmount = fraudAmount;
	}

	public BigDecimal getRecoveredAmount() {
		return recoveredAmount == null ? recoveredAmount : recoveredAmount
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setRecoveredAmount(BigDecimal recoveredAmount) {
		this.recoveredAmount = recoveredAmount;
	}

	public String getClosureReportFileName() {
		return closureReportFileName;
	}

	public void setClosureReportFileName(String closureReportFileName) {
		this.closureReportFileName = closureReportFileName;
	}

	public String getClosureReportFileType() {
		return closureReportFileType;
	}

	public void setClosureReportFileType(String closureReportFileType) {
		this.closureReportFileType = closureReportFileType;
	}

	public Date getDestructionDate() {
		return destructionDate;
	}

	public void setDestructionDate(Date destructionDate) {
		this.destructionDate = destructionDate;
	}

	public String getNewClosureCategoryPart1() {
		return newClosureCategoryPart1;
	}

	public void setNewClosureCategoryPart1(String newClosureCategoryPart1) {
		this.newClosureCategoryPart1 = newClosureCategoryPart1;
	}

	public List<LookupView> getNewCategoryPart1List() {
		return newCategoryPart1List;
	}

	public void setNewCategoryPart1List(List<LookupView> newCategoryPart1List) {
		this.newCategoryPart1List = newCategoryPart1List;
	}

	public List<LookupView> getNewCategoryPart2List() {
		return newCategoryPart2List;
	}

	public void setNewCategoryPart2List(List<LookupView> newCategoryPart2List) {
		this.newCategoryPart2List = newCategoryPart2List;
	}

	public Integer getNoOfSanctionsCateg2_1() {
		return noOfSanctionsCateg2_1;
	}

	public void setNoOfSanctionsCateg2_1(Integer noOfSanctionsCateg2_1) {
		this.noOfSanctionsCateg2_1 = noOfSanctionsCateg2_1;
	}

	public Integer getNoOfSanctionsCateg2_2() {
		return noOfSanctionsCateg2_2;
	}

	public void setNoOfSanctionsCateg2_2(Integer noOfSanctionsCateg2_2) {
		this.noOfSanctionsCateg2_2 = noOfSanctionsCateg2_2;
	}

	public Integer getNoOfSanctionsCateg2_3() {
		return noOfSanctionsCateg2_3;
	}

	public void setNoOfSanctionsCateg2_3(Integer noOfSanctionsCateg2_3) {
		this.noOfSanctionsCateg2_3 = noOfSanctionsCateg2_3;
	}

	public Integer getNoOfSanctionsCateg2_4() {
		return noOfSanctionsCateg2_4;
	}

	public void setNoOfSanctionsCateg2_4(Integer noOfSanctionsCateg2_4) {
		this.noOfSanctionsCateg2_4 = noOfSanctionsCateg2_4;
	}

	public Integer getNoOfSanctionsCateg2_5() {
		return noOfSanctionsCateg2_5;
	}

	public void setNoOfSanctionsCateg2_5(Integer noOfSanctionsCateg2_5) {
		this.noOfSanctionsCateg2_5 = noOfSanctionsCateg2_5;
	}

	public Integer getNoOfSanctionsCateg2_6() {
		return noOfSanctionsCateg2_6;
	}

	public void setNoOfSanctionsCateg2_6(Integer noOfSanctionsCateg2_6) {
		this.noOfSanctionsCateg2_6 = noOfSanctionsCateg2_6;
	}

	public Integer getNoOfSanctionsCateg2_7() {
		return noOfSanctionsCateg2_7;
	}

	public void setNoOfSanctionsCateg2_7(Integer noOfSanctionsCateg2_7) {
		this.noOfSanctionsCateg2_7 = noOfSanctionsCateg2_7;
	}

	public Integer getNoOfSanctionsCateg2_8() {
		return noOfSanctionsCateg2_8;
	}

	public void setNoOfSanctionsCateg2_8(Integer noOfSanctionsCateg2_8) {
		this.noOfSanctionsCateg2_8 = noOfSanctionsCateg2_8;
	}

	public Integer getNoOfSanctionsCateg2_9() {
		return noOfSanctionsCateg2_9;
	}

	public void setNoOfSanctionsCateg2_9(Integer noOfSanctionsCateg2_9) {
		this.noOfSanctionsCateg2_9 = noOfSanctionsCateg2_9;
	}

	public Integer getCriminalSanctionsNo() {
		return criminalSanctionsNo;
	}

	public void setCriminalSanctionsNo(Integer criminalSanctionsNo) {
		this.criminalSanctionsNo = criminalSanctionsNo;
	}

	public Integer getCivilSanctionsNo() {
		return civilSanctionsNo;
	}

	public void setCivilSanctionsNo(Integer civilSanctionsNo) {
		this.civilSanctionsNo = civilSanctionsNo;
	}

	public Integer getInternalDispSanctionsNo() {
		return internalDispSanctionsNo;
	}

	public void setInternalDispSanctionsNo(Integer internalDispSanctionsNo) {
		this.internalDispSanctionsNo = internalDispSanctionsNo;
	}

	public Integer getExternalDispSanctionsNo() {
		return externalDispSanctionsNo;
	}

	public void setExternalDispSanctionsNo(Integer externalDispSanctionsNo) {
		this.externalDispSanctionsNo = externalDispSanctionsNo;
	}

	public Integer getNoOfSanctionsCateg2_10() {
		return noOfSanctionsCateg2_10;
	}

	public void setNoOfSanctionsCateg2_10(Integer noOfSanctionsCateg2_10) {
		this.noOfSanctionsCateg2_10 = noOfSanctionsCateg2_10;
	}

	public Integer getNoOfSanctionsCateg2_11() {
		return noOfSanctionsCateg2_11;
	}

	public void setNoOfSanctionsCateg2_11(Integer noOfSanctionsCateg2_11) {
		this.noOfSanctionsCateg2_11 = noOfSanctionsCateg2_11;
	}

	public BigDecimal getFraudAmountLoss() {
		return fraudAmountLoss == null ? fraudAmountLoss : fraudAmountLoss
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setFraudAmountLoss(BigDecimal fraudAmountLoss) {
		this.fraudAmountLoss = fraudAmountLoss;
	}

	public BigDecimal getNonFraudAmountLoss() {
		return nonFraudAmountLoss == null ? nonFraudAmountLoss
				: nonFraudAmountLoss.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setNonFraudAmountLoss(BigDecimal nonFraudAmountLoss) {
		this.nonFraudAmountLoss = nonFraudAmountLoss;
	}

}
