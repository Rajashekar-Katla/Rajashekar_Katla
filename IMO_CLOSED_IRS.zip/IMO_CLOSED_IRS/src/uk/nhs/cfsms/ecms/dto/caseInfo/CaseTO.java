package uk.nhs.cfsms.ecms.dto.caseInfo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.cim.CaseUpdate;
import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.UserObject;

public class CaseTO {

	private Long caseId;

	private Long informationId;

	private String caseNumber;

	private String operationName;

	private String state;

	private Date createdTime;

	private Date pendingTime;

	private Date closedTime;

	private String createdStaffId;

	private String teamCode;

	private String orgCode;

	private String restrictTo;

	private String prosecuter;

	private String isOverLoadedCase;

	private List<UserObject> lcfsList;

	private List<UserObject> cfsList;

	private String allocatedUser;

	private String actionType;

	private List teamList;

	private String transferTeam;

	private String investigationType;

	private String rejectedComment;

	private String message;

	private String informationSummary;

	private String accessFlag;

	private String accessFlagString;

	// OFM DETAILS ...
	private UserObject dataOwner;

	private List orgList;

	private String allocateTeamSelected;

	//Phase-3 Subjects..
	List<String> subjectNames;

	private Date awaitingTime;

	private Date reopenedTime;

	private String reopenedStaffId;

	private String overloadReason;

	//FIRSTChanageProgramme - 1
	private List<LookupView> acceptanceTypeList = new ArrayList<LookupView>();

	private List<CaseUpdate> caseUpdates = LazyList.decorate(new ArrayList(),
			FactoryUtils.instantiateFactory(CaseUpdate.class));

	private String caseUpdateDesc;

	private Long acceptanceType;

	private String otherAcceptanceType;

	private String infoApprovalStatus;

	private String cpsURN;

	public List getCfsList() {
		return cfsList;
	}

	public void setCfsList(List cfsList) {
		this.cfsList = cfsList;
	}

	public List<UserObject> getLcfsList() {
		return lcfsList;
	}

	public void setLcfsList(List<UserObject> lcfsList) {
		this.lcfsList = lcfsList;
	}

	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId
	 *            The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the caseNumber.
	 */
	public String getCaseNumber() {
		return caseNumber;
	}

	/**
	 * @param caseNumber
	 *            The caseNumber to set.
	 */
	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	/**
	 * @return Returns the closedTime.
	 */
	public Date getClosedTime() {
		return closedTime;
	}

	/**
	 * @param closedTime
	 *            The closedTime to set.
	 */
	public void setClosedTime(Date closedTime) {
		this.closedTime = closedTime;
	}

	/**
	 * @return Returns the createdStaffId.
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	/**
	 * @param createdStaffId
	 *            The createdStaffId to set.
	 */
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	/**
	 * @return Returns the createdTime.
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime
	 *            The createdTime to set.
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return Returns the information.
	 */
	public Long getInformationId() {
		return informationId;
	}

	/**
	 * @param information
	 *            The information to set.
	 */
	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	/**
	 * @return Returns the operationName.
	 */
	public String getOperationName() {
		return operationName;
	}

	/**
	 * @param operationName
	 *            The operationName to set.
	 */
	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	/**
	 * @return Returns the orgCode.
	 */
	public String getOrgCode() {
		return orgCode;
	}

	/**
	 * @param orgCode
	 *            The orgCode to set.
	 */
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	/**
	 * @return Returns the pendingTime.
	 */
	public Date getPendingTime() {
		return pendingTime;
	}

	/**
	 * @param pendingTime
	 *            The pendingTime to set.
	 */
	public void setPendingTime(Date pendingTime) {
		this.pendingTime = pendingTime;
	}

	/**
	 * @return Returns the prosecuter.
	 */
	public String getProsecuter() {
		return prosecuter;
	}

	/**
	 * @param prosecuter
	 *            The prosecuter to set.
	 */
	public void setProsecuter(String prosecuter) {
		this.prosecuter = prosecuter;
	}

	/**
	 * @return Returns the restrictTo.
	 */
	public String getRestrictTo() {
		return restrictTo;
	}

	/**
	 * @param restrictTo
	 *            The restrictTo to set.
	 */
	public void setRestrictTo(String restrictTo) {
		this.restrictTo = restrictTo;
	}

	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return Returns the teamCode.
	 */
	public String getTeamCode() {
		return teamCode;
	}

	/**
	 * @param teamCode
	 *            The teamCode to set.
	 */
	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public String getAllocatedUser() {
		return allocatedUser;
	}

	public void setAllocatedUser(String allocatedUser) {
		this.allocatedUser = allocatedUser;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getIsOverLoadedCase() {
		return isOverLoadedCase;
	}

	public void setIsOverLoadedCase(String isOverLoadedCase) {
		this.isOverLoadedCase = isOverLoadedCase;
	}

	public List getTeamList() {
		return teamList;
	}

	public void setTeamList(List teamList) {
		this.teamList = teamList;
	}

	public String getTransferTeam() {
		return transferTeam;
	}

	public void setTransferTeam(String transferTeam) {
		this.transferTeam = transferTeam;
	}

	/**
	 * Has valid Organisation code.
	 * 
	 * @return boolean.
	 */
	public boolean hasValidOrgCode() {

		if (orgCode != null && StringUtils.isNotEmpty(orgCode)
				&& orgCode.indexOf(",") == -1) {
			return true;
		}
		return false;
	}

	public String getInvestigationType() {
		return investigationType;
	}

	public void setInvestigationType(String investigationType) {
		this.investigationType = investigationType;
	}

	public String getRejectedComment() {
		return rejectedComment;
	}

	public void setRejectedComment(String rejectedComment) {
		this.rejectedComment = rejectedComment;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getInformationSummary() {
		return informationSummary;
	}

	public void setInformationSummary(String informationSummary) {
		this.informationSummary = informationSummary;
	}

	public UserObject getDataOwner() {
		return dataOwner;
	}

	public void setDataOwner(UserObject dataOwner) {
		this.dataOwner = dataOwner;
	}

	public String getAccessFlag() {
		return accessFlag;
	}

	public void setAccessFlag(String accessFlag) {
		this.accessFlag = accessFlag;
	}

	public String getAccessFlagString() {
		if (accessFlag != null) {
			if (accessFlag.equalsIgnoreCase("C"))
				return "Confidential";
			else
				return "Restricted";
		}
		return accessFlagString;
	}

	public void setAccessFlagString(String accessFlagString) {
		this.accessFlagString = accessFlagString;
	}

	public List getOrgList() {
		return orgList;
	}

	public void setOrgList(List orgList) {
		this.orgList = orgList;
	}

	public String getAllocateTeamSelected() {
		return allocateTeamSelected;
	}

	public void setAllocateTeamSelected(String allocateTeamSelected) {
		this.allocateTeamSelected = allocateTeamSelected;
	}

	public List<String> getSubjectNames() {
		return subjectNames;
	}

	public void setSubjectNames(List<String> subjectNames) {
		this.subjectNames = subjectNames;
	}

	public Date getAwaitingTime() {
		return awaitingTime;
	}

	public void setAwaitingTime(Date awaitingTime) {
		this.awaitingTime = awaitingTime;
	}

	public Date getReopenedTime() {
		return reopenedTime;
	}

	public void setReopenedTime(Date reopenedTime) {
		this.reopenedTime = reopenedTime;
	}

	public String getReopenedStaffId() {
		return reopenedStaffId;
	}

	public void setReopenedStaffId(String reopenedStaffId) {
		this.reopenedStaffId = reopenedStaffId;
	}

	public String getOverloadReason() {
		return overloadReason;
	}

	public void setOverloadReason(String overloadReason) {
		this.overloadReason = overloadReason;
	}

	public List getAcceptanceTypeList() {
		return acceptanceTypeList;
	}

	public void setAcceptanceTypeList(List acceptanceTypeList) {
		this.acceptanceTypeList = acceptanceTypeList;
	}

	public List<CaseUpdate> getCaseUpdates() {
		return caseUpdates;
	}

	public void setCaseUpdates(List<CaseUpdate> caseUpdates) {
		this.caseUpdates = caseUpdates;
	}

	public String getCaseUpdateDesc() {
		return caseUpdateDesc;
	}

	public void setCaseUpdateDesc(String caseUpdateDesc) {
		this.caseUpdateDesc = caseUpdateDesc;
	}

	public Long getAcceptanceType() {
		return acceptanceType;
	}

	public void setAcceptanceType(Long acceptanceType) {
		this.acceptanceType = acceptanceType;
	}

	public String getOtherAcceptanceType() {
		return otherAcceptanceType;
	}

	public void setOtherAcceptanceType(String otherAcceptanceType) {
		this.otherAcceptanceType = otherAcceptanceType;
	}

	public String getInfoApprovalStatus() {
		return infoApprovalStatus;
	}

	public void setInfoApprovalStatus(String infoApprovalStatus) {
		this.infoApprovalStatus = infoApprovalStatus;
	}

	public String getCpsURN() {
		return cpsURN;
	}

	public void setCpsURN(String cpsURN) {
		this.cpsURN = cpsURN;
	}

	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}
}
