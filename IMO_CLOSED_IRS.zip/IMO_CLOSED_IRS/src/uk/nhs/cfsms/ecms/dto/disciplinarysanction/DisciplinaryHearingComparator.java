package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.util.Comparator;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionHearing;

public class DisciplinaryHearingComparator implements Comparator<DisciplinarySanctionHearing>{

	public int compare(DisciplinarySanctionHearing o1, DisciplinarySanctionHearing o2) {
        return o2.getHearingId().compareTo(o1.getHearingId());
    }
}
