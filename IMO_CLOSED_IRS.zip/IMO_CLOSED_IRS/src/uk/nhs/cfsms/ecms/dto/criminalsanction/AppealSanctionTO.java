package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.util.Date;

public class AppealSanctionTO {

	private Long appealId;
	private Long parentAppealId;
	private Long sanctionId;
	private String prosecutingAuthority;
	private Date outcomeDate;
	private String selectedSanctions;
	private String subject;
	private String otherSubject; 
	private String appellant;
	private boolean appealExistsForTheCurrent;
	

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public String getProsecutingAuthority() {
		return prosecutingAuthority;
	}

	public void setProsecutingAuthority(String prosecutingAuthority) {
		this.prosecutingAuthority = prosecutingAuthority;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public String getSelectedSanctions() {
		return selectedSanctions;
	}

	public void setSelectedSanctions(String selectedSanctions) {
		this.selectedSanctions = selectedSanctions;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getAppellant() {
		return appellant;
	}

	public void setAppellant(String appellant) {
		this.appellant = appellant;
	}

	public String getOtherSubject() {
		return otherSubject;
	}

	public void setOtherSubject(String otherSubject) {
		this.otherSubject = otherSubject;
	}

	public boolean isAppealExistsForTheCurrent() {
		return appealExistsForTheCurrent;
	}

	public void setAppealExistsForTheCurrent(boolean appealExistsForTheCurrent) {
		this.appealExistsForTheCurrent = appealExistsForTheCurrent;
	}
}
