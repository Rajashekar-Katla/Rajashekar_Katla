package uk.nhs.cfsms.ecms.dto.caseInfo;

import java.io.Serializable;
import java.sql.Date;

import uk.nhs.cfsms.ecms.utility.CaseUtil;

/**
 * InvestigationActionTO is a transfer object for InvestigationActionPlan
 * 
 * @author sChilukuri
 * 
 */
public class InvestigationActionTO  implements Serializable{

	private Long actionPlanId;

	private Long investigationId;;

	private String checkedByOFM;

	private String reasonForNewPlan;

	private Date checkedDate;

	private String actionPlan;

	private Date createdDate;

	private String createdStaffId;
	
	public InvestigationActionTO() {
		super();
	}

	public String getActionPlan() {
		return actionPlan;
	}

	public void setActionPlan(String actionPlan) {
		this.actionPlan = CaseUtil.replaceNewline(actionPlan);
	}

	public Long getActionPlanId() {
		return actionPlanId;
	}

	public void setActionPlanId(Long actionPlanId) {
		this.actionPlanId = actionPlanId;
	}

	public String getCheckedByOFM() {
		return checkedByOFM;
	}

	public void setCheckedByOFM(String checkedByOFM) {
		this.checkedByOFM = checkedByOFM;
	}

	public Date getCheckedDate() {
		return checkedDate;
	}

	public void setCheckedDate(Date checkedDate) {
		this.checkedDate = checkedDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Long getInvestigationId() {
		return investigationId;
	}

	public void setInvestigationId(Long investigationId) {
		this.investigationId = investigationId;
	}

	public String getReasonForNewPlan() {
		return reasonForNewPlan;
	}

	public void setReasonForNewPlan(String reasonForNewPlan) {
		this.reasonForNewPlan = reasonForNewPlan;
	}

}
