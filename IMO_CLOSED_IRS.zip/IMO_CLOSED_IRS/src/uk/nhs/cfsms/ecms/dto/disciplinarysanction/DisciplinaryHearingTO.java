package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Disciplinary Hearing Data Transfer Object.
 * 
 */
public class DisciplinaryHearingTO implements Serializable {

	private Long hearingId;

	private Long disciplinarySanctionId;

	private String hearingType;

	private String hearingOutcome;

	private Date hearingDate;

	private String orgName;

	private String address1;

	private String address2;

	private String address3;

	private String address4;

	private String postcode;

	private String createdStaffId;

	private Date createdTime;

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getDisciplinarySanctionId() {
		return disciplinarySanctionId;
	}

	public void setDisciplinarySanctionId(Long disciplinarySanctionId) {
		this.disciplinarySanctionId = disciplinarySanctionId;
	}

	public Date getHearingDate() {
		return hearingDate;
	}

	public void setHearingDate(Date hearingDate) {
		this.hearingDate = hearingDate;
	}

	public Long getHearingId() {
		return hearingId;
	}

	public void setHearingId(Long hearingId) {
		this.hearingId = hearingId;
	}

	public String getHearingOutcome() {
		return hearingOutcome;
	}

	public void setHearingOutcome(String hearingOutcome) {
		this.hearingOutcome = hearingOutcome;
	}

	public String getHearingType() {
		return hearingType;
	}

	public void setHearingType(String hearingType) {
		this.hearingType = hearingType;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}	
}
