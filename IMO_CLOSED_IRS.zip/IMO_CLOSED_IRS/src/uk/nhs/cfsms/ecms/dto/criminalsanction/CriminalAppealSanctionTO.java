package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.util.Date;

public class CriminalAppealSanctionTO {

	private Long appealId;
	
	private Long sanctionId;
	
	private Date startDate;  
	
	private Date outcomeDate; 
	
	private String selectedSanctions;
	
	private String courtName;
	
	private Long subjectId;
	
	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public String getSelectedSanctions() {
		return selectedSanctions;
	}

	public void setSelectedSanctions(String selectedSanctions) {
		this.selectedSanctions = selectedSanctions;
	}

	public String getCourtName() {
		return courtName;
	}

	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}
	
	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

}
