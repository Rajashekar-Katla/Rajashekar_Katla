package uk.nhs.cfsms.ecms.dto.civilsanction;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import uk.nhs.cfsms.ecms.data.civilsanction.CivilAppealOutcome;
import uk.nhs.cfsms.ecms.data.civilsanction.CivilSanction;
import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;
import uk.nhs.cfsms.ecms.dto.criminalsanction.SubjectName;

public class CivilAppealTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4895973071168635174L;

	private Long appealId;

	private Long parentAppealId;

	private Long caseId;

	private CivilSanction sanction;

	private Long sanctionId;

	private String personOrgMakingAppeal;

	private CivilAppealOutcome outcome;

	private String subjectIdType;

	private Long subjectId;

	private String subjectType;

	private String legalContact;

	private String createdStaffId;

	private Date createdTime;

	private Date dateOfAppeal;

	private String state;

	private Object subject;

	private String nameOfCourtMakingOriginalDecision;

	private Date dateOfOriginalDecision;

	private String decisionAppealAgainst;

	private String appellant;
	
	private String appellantName;

	private String subjectName;

	private Long appealedId;

	private String nhsSubjectName;

	private String nonNhsSubjectName;

	private String personSubjectName;

	private String appealedOutcomeType;

	private String otherSubjects;

	private List<SubjectName> subjects;

	private List<CourtAppearance> courtAppearanceList;

	private Long previousLink;

	private CivilAppealAndSanctionOutcome previousOutcome;
	
	private boolean appealExists;
	
	private String appellantType;

	public Date getPrevOutcomeDate() {
		if (previousOutcome != null) {
			return previousOutcome.getOutcomeDate();
		}
		return null;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public String getPersonOrgMakingAppeal() {
		return personOrgMakingAppeal;
	}

	public void setPersonOrgMakingAppeal(String personOrgMakingAppeal) {
		this.personOrgMakingAppeal = personOrgMakingAppeal;
	}

	public String getNhsSubjectName() {
		return nhsSubjectName;
	}

	public void setNhsSubjectName(String nhsSubjectName) {
		this.nhsSubjectName = nhsSubjectName;
	}

	public String getNonNhsSubjectName() {
		return nonNhsSubjectName;
	}

	public void setNonNhsSubjectName(String nonNhsSubjectName) {
		this.nonNhsSubjectName = nonNhsSubjectName;
	}

	public String getPersonSubjectName() {
		return personSubjectName;
	}

	public void setPersonSubjectName(String personSubjectName) {
		this.personSubjectName = personSubjectName;
	}

	public Object getSubject() {
		return subject;
	}

	public void setSubject(Object subject) {
		this.subject = subject;
	}

	public void setAppealId(Long id) {
		this.appealId = id;
	}

	public List<SubjectName> getSubjects() {
		return subjects;
	}

	public void setSubjects(List<SubjectName> subjects) {
		this.subjects = subjects;
	}

	public List<CourtAppearance> getCourtAppearanceList() {
		return courtAppearanceList;
	}

	public void setCourtAppearanceList(List<CourtAppearance> courtAppearanceList) {
		this.courtAppearanceList = courtAppearanceList;
	}

	public CivilSanction getSanction() {
		return sanction;
	}

	public void setSanction(CivilSanction sanction) {
		this.sanction = sanction;
	}

	public CivilAppealOutcome getOutcome() {
		return outcome;
	}

	public void setOutcome(CivilAppealOutcome outcome) {
		this.outcome = outcome;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	public String getLegalContact() {
		return legalContact;
	}

	public void setLegalContact(String legalContact) {
		this.legalContact = legalContact;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getDateOfAppeal() {
		return dateOfAppeal;
	}

	public void setDateOfAppeal(Date dateOfAppeal) {
		this.dateOfAppeal = dateOfAppeal;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getNameOfCourtMakingOriginalDecision() {
		return nameOfCourtMakingOriginalDecision;
	}

	public void setNameOfCourtMakingOriginalDecision(
			String nameOfCourtMakingOriginalDecision) {
		this.nameOfCourtMakingOriginalDecision = nameOfCourtMakingOriginalDecision;
	}

	public Date getDateOfOriginalDecision() {
		return dateOfOriginalDecision;
	}

	public void setDateOfOriginalDecision(Date dateOfOriginalDecision) {
		this.dateOfOriginalDecision = dateOfOriginalDecision;
	}

	public String getDecisionAppealAgainst() {
		return decisionAppealAgainst;
	}

	public void setDecisionAppealAgainst(String decisionAppealAgainst) {
		this.decisionAppealAgainst = decisionAppealAgainst;
	}

	public String getAppellant() {
		return appellant;
	}

	public void setAppellant(String appellant) {
		this.appellant = appellant;
	}

	public Long getAppealId() {
		return appealId;
	}

	public Long getAppealedId() {
		return appealedId;
	}

	public void setAppealedId(Long appealedId) {
		this.appealedId = appealedId;
	}

	public String getAppealedOutcomeType() {
		return appealedOutcomeType;
	}

	public void setAppealedOutcomeType(String appealedOutcomeType) {
		this.appealedOutcomeType = appealedOutcomeType;
	}

	public String getSubjectIdType() {
		if (null != subjectIdType && subjectIdType.contains("-")) {
			return subjectIdType;
		} else {
			if (null != subjectId && subjectId != 0L && null != subjectType) {
				return subjectId + "-" + subjectType;
			} else if ("Other".equalsIgnoreCase(subjectType)) {
				subjectIdType = "Other";
			}
			return subjectIdType;
		}
	}

	public void setSubjectIdType(String subjectIdType) {
		this.subjectIdType = subjectIdType;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getSubjectName() {
		return this.subjectName;
	}

	public void setPreviousLink(Long id) {
		this.previousLink = id;
	}

	public Long getPreviousLink() {
		if (previousOutcome != null) {
			return previousOutcome.getOwningId();
		}
		return null;
	}

	public CivilAppealAndSanctionOutcome getPreviousOutcome() {
		return previousOutcome;
	}

	public void setPreviousOutcome(CivilAppealAndSanctionOutcome previousOutcome) {
		this.previousOutcome = previousOutcome;
	}

	public String getPrevAppealedType() {
		if (previousOutcome != null) {
			return previousOutcome.getType();
		}
		return null;
	}

	public String getPrevFinalCourtName() {
		if (previousOutcome != null) {
			return previousOutcome.getFinalHearingCourtname();
		}
		return null;
	}

	public String getPrevDecision() {
		if (previousOutcome != null) {
			return previousOutcome.getOrdersMade();
		}
		return null;
	}

	public String getOtherSubjects() {
		return otherSubjects;
	}

	public void setOtherSubjects(String otherSubjects) {
		this.otherSubjects = otherSubjects;
	}

	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}
	
	public boolean isAppealExists() {
		return appealExists;
	}

	public void setAppealExists(boolean appealExists) {
		this.appealExists = appealExists;
	}
	
	public String getAppellantName() {
		return appellantName;
	}

	public void setAppellantName(String appellantName) {
		this.appellantName = appellantName;
	}

	public String getAppellantType() {
		return appellantType;
	}

	public void setAppellantType(String appellantType) {
		this.appellantType = appellantType;
	}
	
}
