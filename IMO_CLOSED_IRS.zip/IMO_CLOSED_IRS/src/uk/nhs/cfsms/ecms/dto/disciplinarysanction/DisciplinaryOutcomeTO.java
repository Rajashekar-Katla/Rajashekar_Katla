package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;

/**
 * Disciplinary Sanction Outcome Transfer Object
 * 
 */
public class DisciplinaryOutcomeTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5205099948092409565L;

	private Long outcomeId;

	private Long disciplinarySanctionId;

	private Date outcomeDate;

	private String status;

	private String createdStaffId;

	private Date createdTime;

	private String sanctionsImposed;

	private String otherSanctionImposed;

	private List<LookupView> lookupImposedList;
	
	private String dispType;
	
	private String sanctionType;
	
	private List<OutcomeAppliedSanction> outcomeAppliedSanctions = new ArrayList<OutcomeAppliedSanction>();
		
	
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getDisciplinarySanctionId() {
		return disciplinarySanctionId;
	}

	public void setDisciplinarySanctionId(Long disciplinarySanctionId) {
		this.disciplinarySanctionId = disciplinarySanctionId;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long outcomeId) {
		this.outcomeId = outcomeId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOtherSanctionImposed() {
		return otherSanctionImposed;
	}

	public void setOtherSanctionImposed(String otherSanctionImposed) {
		if (otherSanctionImposed != null) {
			this.otherSanctionImposed = otherSanctionImposed;
		}
	}

	public String getSanctionsImposed() {
		return sanctionsImposed;
	}
	
	

	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public List<OutcomeAppliedSanction> getOutcomeAppliedSanctions() {
		return outcomeAppliedSanctions;
	}

	public void setOutcomeAppliedSanctions(
			List<OutcomeAppliedSanction> outcomeAppliedSanctions) {
		this.outcomeAppliedSanctions = outcomeAppliedSanctions;
	}

	public List<LookupView> getLookupImposedList() {
		return lookupImposedList;
	}

	public void setLookupImposedList(List<LookupView> lookupImposedList) {
		this.lookupImposedList = lookupImposedList;
	}

	public void setSanctionsImposed(String sanctionsImposed) {
		this.sanctionsImposed = sanctionsImposed;
	}

	public String getDispType() {
		return dispType;
	}

	public void setDispType(String dispType) {
		this.dispType = dispType;
	}

	/**
	 * @return the sanctionType
	 */
	public String getSanctionType() {
		return sanctionType;
	}

	/**
	 * @param sanctionType the sanctionType to set
	 */
	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

}
