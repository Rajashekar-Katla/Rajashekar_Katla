package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionHearing;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionOffence;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinarySanctionOutcome;

/**
 * Disciplinary Sanction Transfer Object.
 *
 */
public class DisciplinarySanctionTO implements Serializable {

	private Long disciplinarySanctionId;

	private Long caseId;

	private Long subjectId;

	private String subjectType;

	private String createdStaffId;

	private Date createdTime;

	private String sanctionType;

	private String state;

	private String humanResourceContact;

	private String investigationManagerContact;

	private String professionalContact;

	private String healthBodyContact;

	private String organisationName;

	private Date startDate;

	private String nhsSubjectName;

	private String nonNhsSubjectName;

	private String personSubjectName;

	private String selectedSanctions;

	private String internalOrganisationName;

	/**
	 * Used to Manipulate the "subjectId;SubjectType" format examples:
	 * "206;PERSON", "209:NHS" , "213,NON_NHS" split string by ";" & set values
	 * to subjectId and SubjectType.
	 */
	private String subjectIdSemiTypeName;

	private List<DisciplinarySanctionHearing> hearings;

	private List<DisciplinarySanctionOffence> offences;

	private List<DisciplinarySanctionOutcome> outcomes;

	private boolean appealExist;

	public List<DisciplinarySanctionHearing> getHearings() {
		return hearings;
	}

	public void setHearings(List<DisciplinarySanctionHearing> hearings) {
		this.hearings = hearings;
	}

	public List<DisciplinarySanctionOffence> getOffences() {
		return offences;
	}

	public void setOffences(List<DisciplinarySanctionOffence> offences) {
		this.offences = offences;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getDisciplinarySanctionId() {
		return disciplinarySanctionId;
	}

	public void setDisciplinarySanctionId(Long disciplinarySanctionId) {
		this.disciplinarySanctionId = disciplinarySanctionId;
	}

	public String getHealthBodyContact() {
		return healthBodyContact;
	}

	public void setHealthBodyContact(String healthBodyContact) {
		this.healthBodyContact = healthBodyContact;
	}

	public String getHumanResourceContact() {
		return humanResourceContact;
	}

	public void setHumanResourceContact(String humanResourceContact) {
		this.humanResourceContact = humanResourceContact;
	}

	public String getInvestigationManagerContact() {
		return investigationManagerContact;
	}

	public void setInvestigationManagerContact(
			String investigationManagerContact) {
		this.investigationManagerContact = investigationManagerContact;
	}

	public String getNhsSubjectName() {
		return nhsSubjectName;
	}

	public void setNhsSubjectName(String nhsSubjectName) {
		this.nhsSubjectName = nhsSubjectName;
	}

	public String getNonNhsSubjectName() {
		return nonNhsSubjectName;
	}

	public void setNonNhsSubjectName(String nonNhsSubjectName) {
		this.nonNhsSubjectName = nonNhsSubjectName;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getPersonSubjectName() {
		return personSubjectName;
	}

	public void setPersonSubjectName(String personSubjectName) {
		this.personSubjectName = personSubjectName;
	}

	public String getProfessionalContact() {
		return professionalContact;
	}

	public void setProfessionalContact(String professionalContact) {
		this.professionalContact = professionalContact;
	}

	public String getSanctionType() {
		return sanctionType;
	}

	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		if (StringUtils.isNotEmpty(subjectType)) {
			this.subjectType = subjectType;
		}
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getSubjectIdSemiTypeName() {
		return subjectIdSemiTypeName;
	}

	public void setSubjectIdSemiTypeName(String subjectIdSemiTypeName) {
		if (StringUtils.isEmpty(subjectIdSemiTypeName)) {
			this.subjectIdSemiTypeName = subjectIdSemiTypeName;
		} else if (subjectIdSemiTypeName.length() > 2) {
			String[] values = subjectIdSemiTypeName.split(";");
			if (values.length == 2) {
				this.subjectId = new Long(values[0]);
				this.subjectType = values[1];
			}
		}
	}

	public List<DisciplinarySanctionOutcome> getOutcomes() {
		return outcomes;
	}

	public void setOutcomes(List<DisciplinarySanctionOutcome> outcomes) {
		this.outcomes = outcomes;
	}

	public String getSelectedSanctions() {
		return selectedSanctions;
	}

	public void setSelectedSanctions(String selectedSanctions) {
		this.selectedSanctions = selectedSanctions;
	}

	public boolean isAppealExist() {
		return appealExist;
	}

	public void setAppealExist(boolean appealExist) {
		this.appealExist = appealExist;
	}

	/**
	 * @return the internalOrganisationName
	 */
	public String getInternalOrganisationName() {
		return internalOrganisationName;
	}

	/**
	 * @param internalOrganisationName
	 *            the internalOrganisationName to set
	 */
	public void setInternalOrganisationName(String internalOrganisationName) {
		this.internalOrganisationName = internalOrganisationName;
	}

}
