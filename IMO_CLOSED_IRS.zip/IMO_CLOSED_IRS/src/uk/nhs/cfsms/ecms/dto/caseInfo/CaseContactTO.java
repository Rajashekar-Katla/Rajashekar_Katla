package uk.nhs.cfsms.ecms.dto.caseInfo;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.dto.infoGath.PersonTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

public class CaseContactTO implements Serializable {

	private Long contactId;

	private Long caseId;

	private Long infoId;
	
	private String contactType;

	private String otherContactType;

	private PersonTO personTO;

	private String isWitness;

	private String isSubject;

	private String state;

	private String createdStaffId;

	private Timestamp createdDate;
	
	private Map<String, List<LookupView>> lookupViewMap = new HashMap<String, List<LookupView>>();
	

	public CaseContactTO() {
		this.personTO = new PersonTO();
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getContactId() {
		return contactId;
	}

	public void setContactId(Long contactId) {
		this.contactId = contactId;
	}

	public String getContactType() {
		return contactType;
	}

	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	public String getIsSubject() {
		return isSubject;
	}

	public void setIsSubject(String isSubject) {
		this.isSubject = isSubject;
	}

	public String getIsWitness() {
		return isWitness;
	}

	public void setIsWitness(String isWitness) {
		this.isWitness = isWitness;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public PersonTO getPersonTO() {
		return personTO;
	}

	public void setPersonTO(PersonTO personTO) {
		this.personTO = personTO;
	}

	public Map<String, List<LookupView>> getLookupViewMap() {
		return getStaticLookupViewMap();
	}

	public void addLookupViewMap(String name, List<LookupView> list) {
		lookupViewMap.put(name, list);
	}

	public List<LookupView> getInfoLookupViewMapByName(String name) {
		return this.getStaticLookupViewMap().get(name);
	}

	private Map<String, List<LookupView>> getStaticLookupViewMap() {
		if (this.lookupViewMap == null
				|| (this.lookupViewMap != null && this.lookupViewMap.size() < 4)) {
			return EcmsUtils.getInfoLookupViewMap();
		}
		return lookupViewMap;
	}

	public void setStaticInfoLookupViewMap() {

		Map<String, List<LookupView>> map = EcmsUtils.getInfoLookupViewMap();
		if (null != this.lookupViewMap && !this.lookupViewMap.isEmpty()) {
			if (null != map) {
				map.putAll(this.lookupViewMap);
			} else {
				EcmsUtils.getInstance()
						.setInfoLookupViewMap(this.lookupViewMap);
			}
		}
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getOtherContactType() {

		return contactType;
	}

	public void setOtherContactType(String otherContactType) {
		if (StringUtils.isNotEmpty(otherContactType)) {
			this.contactType = otherContactType;
		}
	}

	/**
	 * @return Returns the infoId.
	 */
	public Long getInfoId() {
		return infoId;
	}

	/**
	 * @param infoId The infoId to set.
	 */
	public void setInfoId(Long infoId) {
		this.infoId = infoId;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);

	}	
}
