package uk.nhs.cfsms.ecms.dto.caseInfo;

import java.util.Date;
import java.util.List;
 
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import uk.nhs.cfsms.ecms.data.cim.Case;
import uk.nhs.cfsms.ecms.data.common.Organisation;
import uk.nhs.cfsms.ecms.data.common.UserObject;

public class CaseTransferTO  {

	private Long caseTransferId;

	private Case caseObject;

	private String createdStaffId;

	private Date createdTime;

	private Date transferTime;

	private Date acceptedTime;

	private Date rejectedTime;

	private Date cancelledTime;

	private String state;

	private String receipentLcfs;

	private String receipentLcfsName;

	private String transferType;

	private String recipientTeamCode;
	
	private String originTeamCode;

	private String transferCreatedStaffName;

	private String transferComment;

	private String rejectedComment;

	private String caseCreatedStaffName;

	private String caseOrgName;

	private List<UserObject> lcfsList;

	private List<Organisation> teamList;

	private String buttons = new String();

	private String actionType;

	private String cfsTransferApproverStaffID;
	
	private String cfsTransferApproverStaffName;
	
	private String transferApprovalStatus;
	
	private Date transferApprovalTime;
	
	private String transferApproverComments;
	
	public String getButtons() {
		return buttons;
	}

	public void setButtons(String buttons) {
		this.buttons = buttons;
	}

	public Date getAcceptedTime() {
		return acceptedTime;
	}

	public void setAcceptedTime(Date acceptedTime) {
		this.acceptedTime = acceptedTime;
	}

	public Date getCancelledTime() {
		return cancelledTime;
	}

	public void setCancelledTime(Date cancelledTime) {
		this.cancelledTime = cancelledTime;
	}

	public String getCaseCreatedStaffName() {
		return caseCreatedStaffName;
	}

	public void setCaseCreatedStaffName(String caseCreatedStaffName) {
		this.caseCreatedStaffName = caseCreatedStaffName;
	}

	public Long getCaseTransferId() {
		return caseTransferId;
	}

	public void setCaseTransferId(Long caseTransferId) {
		this.caseTransferId = caseTransferId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getReceipentLcfs() {
		return receipentLcfs;
	}

	public void setReceipentLcfs(String receipentLcfs) {
		this.receipentLcfs = receipentLcfs;
	}

	public String getRecipientTeamCode() {
		return recipientTeamCode;
	}

	public void setRecipientTeamCode(String recipientTeamCode) {
		this.recipientTeamCode = recipientTeamCode;
	}

	public String getRejectedComment() {
		return rejectedComment;
	}

	public void setRejectedComment(String rejectedComment) {
		this.rejectedComment = rejectedComment;
	}

	public Date getRejectedTime() {
		return rejectedTime;
	}

	public void setRejectedTime(Date rejectedTime) {
		this.rejectedTime = rejectedTime;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTransferComment() {
		return transferComment;
	}

	public void setTransferComment(String transferComment) {
		this.transferComment = transferComment;
	}

	public String getTransferCreatedStaffName() {
		return transferCreatedStaffName;
	}

	public void setTransferCreatedStaffName(String transferCreatedStaffName) {
		this.transferCreatedStaffName = transferCreatedStaffName;
	}

	public Date getTransferTime() {
		return transferTime;
	}

	public void setTransferTime(Date transferTime) {
		this.transferTime = transferTime;
	}

	public String getTransferType() {
		return transferType;
	}

	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	public Case getCaseObject() {
		if (caseObject == null)
			return new Case();
		return caseObject;
	}

	public void setCaseObject(Case caseObject) {
		this.caseObject = caseObject;
	}

	public String getReceipentLcfsName() {
		return receipentLcfsName;
	}

	public void setReceipentLcfsName(String receipentLcfsName) {
		this.receipentLcfsName = receipentLcfsName;
	}

	public String getCaseOrgName() {
		return caseOrgName;
	}

	public void setCaseOrgName(String orgName) {
		this.caseOrgName = orgName;
	}

	public List<UserObject> getLcfsList() {
		return lcfsList;
	}

	public void setLcfsList(List<UserObject> lcfsList) {
		this.lcfsList = lcfsList;
	}

	public List<Organisation> getTeamList() {
		return teamList;
	}

	public void setTeamList(List<Organisation> teamList) {
		this.teamList = teamList;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getOriginTeamCode() {
		return originTeamCode;
	}

	public void setOriginTeamCode(String originTeamCode) {
		this.originTeamCode = originTeamCode;
	}
	
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public String getCfsTransferApproverStaffID() {
		return cfsTransferApproverStaffID;
	}

	public void setCfsTransferApproverStaffID(String cfsTransferApproverStaffID) {
		this.cfsTransferApproverStaffID = cfsTransferApproverStaffID;
	}

	public String getCfsTransferApproverStaffName() {
		return cfsTransferApproverStaffName;
	}

	public void setCfsTransferApproverStaffNAme(String cfsTransferApproverStaffNAme) {
		this.cfsTransferApproverStaffName = cfsTransferApproverStaffNAme;
	}

	public String getTransferApprovalStatus() {
		return transferApprovalStatus;
	}

	public void setTransferApprovalStatus(String transferApprovalStatus) {
		this.transferApprovalStatus = transferApprovalStatus;
	}

	public Date getTransferApprovalTime() {
		return transferApprovalTime;
	}

	public void setTransferApprovalTime(Date transferApprovalTime) {
		this.transferApprovalTime = transferApprovalTime;
	}

	public String getTransferApproverComments() {
		return transferApproverComments;
	}

	public void setTransferApproverComments(String transferApproverComments) {
		this.transferApproverComments = transferApproverComments;
	}

}
