package uk.nhs.cfsms.ecms.dto.caseInfo;

import java.io.Serializable;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

public class AppealHearingTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7565367770127962234L;

	private Long appearanceId;

	private Long appealId;

	private String sanctionType;

	private String courtName;

	private Date hearingDate;

	private String hearingTime;

	private String courtType;

	private String appearanceType;

	private String otherAppearanceType;

	private String outcomeInfo;

	private Map<String, List<LookupView>> lookupViewMap = new HashMap<String, List<LookupView>>();
	
	public Long getAppearanceId() {
		return appearanceId;
	}

	public void setAppearanceId(Long appearanceId) {
		this.appearanceId = appearanceId;
	}

	public Date getHearingDate() {
		return hearingDate;
	}

	public void setHearingDate(Date hearingDate) {
		this.hearingDate = hearingDate;
	}

	public String getHearingTime() {
		return hearingTime;
	}

	public void setHearingTime(String hearingTime) {
		this.hearingTime = hearingTime;
	}

	public String getAppearanceType() {
		return appearanceType;
	}

	public void setAppearanceType(String appearanceType) {
		this.appearanceType = appearanceType;
	}

	public String getCourtName() {
		return courtName;
	}

	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}

	public String getCourtType() {
		return courtType;
	}

	public void setCourtType(String courtType) {
		this.courtType = courtType;
	}

	public Map<String, List<LookupView>> getLookupViewMap() {
		return this.lookupViewMap;
	}

	public void setLookupViewMap(Map<String, List<LookupView>> lookupViewMap) {
		this.lookupViewMap = lookupViewMap;
	}

	public String getOutcomeInfo() {
		return outcomeInfo;
	}

	public void setOutcomeInfo(String outcomeInfo) {
		this.outcomeInfo = outcomeInfo;
	}

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public String getSanctionType() {
		return sanctionType;
	}

	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

	public void addLookupViewMap(String groupName, List<LookupView> list) {
		lookupViewMap.put(groupName, list);
	}

	public String getOtherAppearanceType() {
		return appearanceType;
	}

	public void setOtherAppearanceType(String otherAppearanceType) {
		if (StringUtils.isNotEmpty(otherAppearanceType)) {
			this.appearanceType = otherAppearanceType;
		}
	}

	public void setStaticCriminalCourtAppearanceLookupViewMap() {
		
		Map<String, List<LookupView>> map = EcmsUtils
				.getCriminalAppealHearingLookupViewMap();
		
		if (null != this.lookupViewMap && !this.lookupViewMap.isEmpty()) {
			
			if (null == map || (map != null && map.isEmpty())) {
				EcmsUtils.getInstance()
						.setCriminalAppealHearingLookupViewMap(
								this.lookupViewMap);
			}
		}

	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
