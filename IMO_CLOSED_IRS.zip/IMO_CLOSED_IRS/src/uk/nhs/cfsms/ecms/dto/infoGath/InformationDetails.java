package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.common.TeamCodes;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseContactTO;
import uk.nhs.cfsms.ecms.utility.EcmsUtils;

/**
 * InformationDetails holds all the details of information gathered and helper
 * list for the front end presentation especially while creating a new
 * information.
 * 
 * @author schilukuri
 * 
 */
public class InformationDetails implements Serializable{

	public enum SubjectType {
		PERSON, NHS, NONNHS, ASSOCIATE, VEHICLE
	};

	private String subjectType;

	private InformationTO informationTO;

	private SubjectInformationTO subjectInformationTO;

	private NHSSubjectInformationTO nhsSubjectInformationTO;

	private NonNHSSubjectInformationTO nonNHSSubjectInformationTO;

	private Map<String, List<LookupView>> infoLookupViewMap = new HashMap<String, List<LookupView>>();
	
	private Map<String, List<LookupView>> dynamicInfoLookupViewMap = new HashMap<String, List<LookupView>>();

	private List<TeamCodes> teamCodesList;

	private CaseContactTO associate;

	private VehicleTO vehicle;
	
	private InfoTransferHistTO infoTransferHistTO;
	
	public Map<String, List<LookupView>> getInfoLookupViewMap() {
		return getStaticInfoLookupViewMap();
	}

	public void addInfoLookupViewMap(String name, List<LookupView> list) {
		infoLookupViewMap.put(name, list);
	}

	public List<LookupView> getInfoLookupViewMapByName(String name) {
		return this.getStaticInfoLookupViewMap().get(name);
	}

	private Map<String, List<LookupView>> getStaticInfoLookupViewMap() {
		if (this.infoLookupViewMap == null
				|| (this.infoLookupViewMap != null && this.infoLookupViewMap
						.isEmpty())) {
			return EcmsUtils.getInstance().getInfoLookupViewMap();
		}
		return infoLookupViewMap;
	}

	public void setStaticInfoLookupViewMap() {
		Map<String, List<LookupView>> lookupMap = EcmsUtils.getInstance()
				.getInfoLookupViewMap();

		if (null != infoLookupViewMap && !infoLookupViewMap.isEmpty()) {
			if (null != lookupMap) {

				lookupMap.putAll(this.infoLookupViewMap);
			} else {
				EcmsUtils.getInstance().setInfoLookupViewMap(
						this.infoLookupViewMap);
			}
		}
	}
	
	public void addDynamicInfoLookupViewMap(String name, List<LookupView> list) {
		dynamicInfoLookupViewMap.put(name, list);
	}
	
	public Map<String, List<LookupView>> getDynamicInfoLookupViewMap() {
		return dynamicInfoLookupViewMap;
	}

	public void setDynamicInfoLookupViewMap(
			Map<String, List<LookupView>> dynamicInfoLookupViewMap) {
		this.dynamicInfoLookupViewMap = dynamicInfoLookupViewMap;
	}


	public SubjectInformationTO getSubjectInformationTO() {
		return subjectInformationTO;
	}

	public void setSubjectInformationTO(
			SubjectInformationTO subjectInformationTO) {
		this.subjectInformationTO = subjectInformationTO;
	}

	public NonNHSSubjectInformationTO getNonNHSSubjectInformationTO() {
		return nonNHSSubjectInformationTO;
	}

	public void setNonNHSSubjectInformationTO(
			NonNHSSubjectInformationTO nonNHSSubjectInformationTO) {
		this.nonNHSSubjectInformationTO = nonNHSSubjectInformationTO;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	public NHSSubjectInformationTO getNhsSubjectInformationTO() {
		return nhsSubjectInformationTO;
	}

	public void setNhsSubjectInformationTO(
			NHSSubjectInformationTO nhsSubjectInformationTO) {
		this.nhsSubjectInformationTO = nhsSubjectInformationTO;
	}

	public InformationTO getInformationTO() {
		return informationTO;
	}

	public void setInformationTO(InformationTO informationTO) {
		this.informationTO = informationTO;
	}

	public List<TeamCodes> getTeamCodesList() {
		return teamCodesList;
	}

	public void setTeamCodesList(List<TeamCodes> teamCodesList) {
		this.teamCodesList = teamCodesList;
	}

	public CaseContactTO getAssociate() {
		return associate;
	}

	public void setAssociate(CaseContactTO associate) {
		this.associate = associate;
	}

	public VehicleTO getVehicle() {
		return vehicle;
	}

	public void setVehicle(VehicleTO vehicle) {
		this.vehicle = vehicle;
	}
	
	public String toString() {
		
		return ToStringBuilder.reflectionToString(this);
	}

	public InfoTransferHistTO getInfoTransferHistTO() {
		return infoTransferHistTO;
	}

	public void setInfoTransferHistTO(InfoTransferHistTO infoTransferHistTO) {
		this.infoTransferHistTO = infoTransferHistTO;
	}

	
}
