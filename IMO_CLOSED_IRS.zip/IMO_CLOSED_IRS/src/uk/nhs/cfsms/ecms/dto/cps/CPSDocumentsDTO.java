/**
 * 
 */
package uk.nhs.cfsms.ecms.dto.cps;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class CPSDocumentsDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private long formId;
	private String fileName;
	private String formType;
	private String fileType;
	private String groupName;
	private String description;
	private long size;
	private String tableName;
	private String caseID;
	private String primaryKey;
	private String createdBy;
	private String createdDate;
	private byte[] fileBlob;
	private String submissionType;
	private Date createdTime;
	private String requestStatus;
	private String submissionStatus;
	private boolean selected;
	private MultipartFile multipartMgForm;
	private String error;
	private String createdStaffId;
	private String requesterMessage;
	private String approverMessage;
	private Timestamp approverResponseTime;
	private String createdStaffName;
	private String approverStaffName;
	private String mailStatus;
	private Timestamp mailDate;
	private String acceptedData;
	private String rejedData;
	private String cpsDocReqId;
	private String cpsReqId;
	
	public long getFormId() {
		return formId;
	}
	public void setFormId(long formId) {
		this.formId = formId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFormType() {
		return formType;
	}
	public void setFormType(String formType) {
		this.formType = formType;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getSize() {
		return size;
	}
	public void setSize(long size) {
		this.size = size;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getCaseID() {
		return caseID;
	}
	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}
	public String getPrimaryKey() {
		return primaryKey;
	}
	public void setPrimaryKey(String primaryKey) {
		this.primaryKey = primaryKey;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public byte[] getFileBlob() {
		return fileBlob;
	}
	public void setFileBlob(byte[] fileBlob) {
		this.fileBlob = fileBlob;
	}
	public String getSubmissionType() {
		return submissionType;
	}
	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getSubmissionStatus() {
		return submissionStatus;
	}
	public void setSubmissionStatus(String submissionStatus) {
		this.submissionStatus = submissionStatus;
	}
	public boolean isSelected() {
		return selected;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	public MultipartFile getMultipartMgForm() {
		return multipartMgForm;
	}
	public void setMultipartMgForm(MultipartFile multipartMgForm) {
		this.multipartMgForm = multipartMgForm;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getCreatedStaffId() {
		return createdStaffId;
	}
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}
	public String getRequesterMessage() {
		return requesterMessage;
	}
	public void setRequesterMessage(String requesterMessage) {
		this.requesterMessage = requesterMessage;
	}
	public String getApproverMessage() {
		return approverMessage;
	}
	public void setApproverMessage(String approverMessage) {
		this.approverMessage = approverMessage;
	}
	public Timestamp getApproverResponseTime() {
		return approverResponseTime;
	}
	public void setApproverResponseTime(Timestamp approverResponseTime) {
		this.approverResponseTime = approverResponseTime;
	}
	public String getCreatedStaffName() {
		return createdStaffName;
	}
	public void setCreatedStaffName(String createdStaffName) {
		this.createdStaffName = createdStaffName;
	}
	public String getApproverStaffName() {
		return approverStaffName;
	}
	public void setApproverStaffName(String approverStaffName) {
		this.approverStaffName = approverStaffName;
	}
	public String getMailStatus() {
		return mailStatus;
	}
	public void setMailStatus(String mailStatus) {
		this.mailStatus = mailStatus;
	}
	public Timestamp getMailDate() {
		return mailDate;
	}
	public void setMailDate(Timestamp mailDate) {
		this.mailDate = mailDate;
	}
	public String getAcceptedData() {
		return acceptedData;
	}
	public void setAcceptedData(String acceptedData) {
		this.acceptedData = acceptedData;
	}
	public String getRejedData() {
		return rejedData;
	}
	public void setRejedData(String rejedData) {
		this.rejedData = rejedData;
	}
	public String getCpsDocReqId() {
		return cpsDocReqId;
	}
	public void setCpsDocReqId(String cpsDocReqId) {
		this.cpsDocReqId = cpsDocReqId;
	}
	public String getCpsReqId() {
		return cpsReqId;
	}
	public void setCpsReqId(String cpsReqId) {
		this.cpsReqId = cpsReqId;
	}

	

}
