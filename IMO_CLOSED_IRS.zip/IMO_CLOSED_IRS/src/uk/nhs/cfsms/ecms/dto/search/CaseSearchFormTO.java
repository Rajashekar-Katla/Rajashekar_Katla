package uk.nhs.cfsms.ecms.dto.search;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.cim.CaseObject;
import uk.nhs.cfsms.ecms.dto.caseInfo.CaseTO;

/**
 * Transfer object for case filter search.
 * 
 */
public class CaseSearchFormTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 44494540L;

	private String caseNumber;

	private String operationName;

	private String caseStatus;

	private boolean isDataRange;
	
	private Date startDate;

	private Date endDate;
	
	private String closedBy;
	
	private boolean isCloseDataRange;

	@SuppressWarnings("unchecked")
	private List<CaseObject> searchResults = LazyList.decorate(new ArrayList(),
			FactoryUtils.instantiateFactory(CaseObject.class));

	@SuppressWarnings("unchecked")
	private List<CaseTO> searchResultsTO = LazyList.decorate(new ArrayList(),
			FactoryUtils.instantiateFactory(CaseTO.class));
	
	
	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public String getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public List<CaseObject> getSearchResults() {
		return searchResults;
	}

	public void setSearchResults(List<CaseObject> searchResults) {
		this.searchResults = searchResults;
	}

	public boolean isDataRange() {
		return isDataRange;
	}

	public void setDateRange(boolean isDataRange) {
		this.isDataRange = isDataRange;
	}

	public String getClosedBy() {
		return closedBy;
	}

	public void setClosedBy(String closedBy) {
		this.closedBy = closedBy;
	}

	public List<CaseTO> getSearchResultsTO() {
		return searchResultsTO;
	}

	public void setSearchResultsTO(List<CaseTO> searchResultsTO) {
		this.searchResultsTO = searchResultsTO;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
	public boolean isCloseDataRange() {
		return isCloseDataRange;
	}

	public void setCloseDataRange(boolean isCloseDataRange) {
		this.isCloseDataRange = isCloseDataRange;
	}

}
