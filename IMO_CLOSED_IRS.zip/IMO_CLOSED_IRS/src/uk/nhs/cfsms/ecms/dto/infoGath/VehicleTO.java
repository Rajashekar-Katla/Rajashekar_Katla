package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;


public class VehicleTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 108970004L;

	private Long vehicleId;

	private String make;
	
	private String model;
	
	private String colour;
	
	private String licensePlate;
	
	private Long caseId;

	private Long infoId;
	
	private String comments;
	
	private String registeredKeeperName;
	
	private String registeredAddress1;
	
	private String registeredAddress2;
	
	private String registeredAddress3;
	
	private String registeredAddress4;
	
	private String postcode;

	
	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Long getInfoId() {
		return infoId;
	}

	public void setInfoId(Long infoId) {
		this.infoId = infoId;
	}

	public String getLicensePlate() {
		return licensePlate;
	}

	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getRegisteredAddress1() {
		return registeredAddress1;
	}

	public void setRegisteredAddress1(String registeredAddress1) {
		this.registeredAddress1 = registeredAddress1;
	}

	public String getRegisteredAddress2() {
		return registeredAddress2;
	}

	public void setRegisteredAddress2(String registeredAddress2) {
		this.registeredAddress2 = registeredAddress2;
	}

	public String getRegisteredAddress3() {
		return registeredAddress3;
	}

	public void setRegisteredAddress3(String registeredAddress3) {
		this.registeredAddress3 = registeredAddress3;
	}

	public String getRegisteredAddress4() {
		return registeredAddress4;
	}

	public void setRegisteredAddress4(String registeredAddress4) {
		this.registeredAddress4 = registeredAddress4;
	}

	public String getRegisteredKeeperName() {
		return registeredKeeperName;
	}

	public void setRegisteredKeeperName(String registeredKeeperName) {
		this.registeredKeeperName = registeredKeeperName;
	}

}
