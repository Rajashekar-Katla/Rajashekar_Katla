package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.common.LookupView;

/**
 * Disciplinary Appeal Hearing Transfer Object.
 * 
 */
public class DisciplinaryAppealHearingTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3393951437817326002L;

	private Long hearingId;

	private Long appealId;

	private String hearingType;

	private String hearingOutcome;

	private Date hearingDate;
	
	private String hearingTime;
	
	private String courtType;
	
	private String appearanceType;
	
	private String otherAppearanceType;

	private String orgName;

	private String address1;

	private String address2;

	private String address3;

	private String address4;

	private String postcode;

	private String createdStaffId;

	private Date createdTime;

	private Map<String, List<LookupView>> lookupViewMap = new HashMap<String, List<LookupView>>();
	
	
	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Date getHearingDate() {
		return hearingDate;
	}

	public void setHearingDate(Date hearingDate) {
		this.hearingDate = hearingDate;
	}

	public Long getHearingId() {
		return hearingId;
	}

	public void setHearingId(Long hearingId) {
		this.hearingId = hearingId;
	}

	public String getHearingOutcome() {
		return hearingOutcome;
	}

	public void setHearingOutcome(String hearingOutcome) {
		this.hearingOutcome = hearingOutcome;
	}

	public String getHearingType() {
		return hearingType;
	}

	public void setHearingType(String hearingType) {
		this.hearingType = hearingType;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	
	public String getHearingTime() {
		return hearingTime;
	}

	public void setHearingTime(String hearingTime) {
		this.hearingTime = hearingTime;
	}

	public String getCourtType() {
		return courtType;
	}

	public void setCourtType(String courtType) {
		this.courtType = courtType;
	}

	public String getAppearanceType() {
		return appearanceType;
	}

	public void setAppearanceType(String appearanceType) {
		this.appearanceType = appearanceType;
	}
	

	public String getOtherAppearanceType() {
		return appearanceType;
	}

	public void setOtherAppearanceType(String otherAppearanceType) {
		if (StringUtils.isNotEmpty(otherAppearanceType)) {
			this.appearanceType = otherAppearanceType;
		}
	}

	public Map<String, List<LookupView>> getLookupViewMap() {
		return lookupViewMap;
	}

	public void setLookupViewMap(Map<String, List<LookupView>> lookupViewMap) {
		this.lookupViewMap = lookupViewMap;
	}
	
	public void addLookupViewMap(String groupName, List<LookupView> list) {
		lookupViewMap.put(groupName, list);
	}	

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
