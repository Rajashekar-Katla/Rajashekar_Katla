package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.io.Serializable;

public class SubjectName  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5960682666529066389L;
	
	private Long id;
	private String title;
	private String otherTitle;
	private String firstname;
	private String lastname;
	private String subjectType; 
	
	/**
	 * @return Returns the firstname.
	 */
	public String getFirstname() {
		return firstname;
	}
	/**
	 * @param firstname The firstname to set.
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	/**
	 * @return Returns the lastname.
	 */
	public String getLastname() {
		return lastname;
	}
	/**
	 * @param lastname The lastname to set.
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	/**
	 * @return Returns the id.
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return Returns the subjectType.
	 */
	public String getSubjectType() {
		return subjectType;
	}
	/**
	 * @param subjectType The subjectType to set.
	 */
	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getOtherTitle() {
		return otherTitle;
	}
	public void setOtherTitle(String otherTitle) {
		this.otherTitle = otherTitle;
	}
	
	
	public String getSubjectIdType(){
		if(id != null && subjectType != null){
			return id + "-" + subjectType;
		}
		return null;
	}
		
	public String getIdString() {
		if (null != id) {
			return id.toString();
		}
		return "";
	}
	
	@Override
	public String toString() {
		StringBuilder subjectName = new StringBuilder();
		if(getTitle() != null){
			subjectName.append(getTitle());
		}
		if(getFirstname() != null){
			subjectName.append(getFirstname());
		}
		if(getLastname() != null){
			subjectName.append(getLastname());
		}
		return subjectName.toString();
	}
	 
}
