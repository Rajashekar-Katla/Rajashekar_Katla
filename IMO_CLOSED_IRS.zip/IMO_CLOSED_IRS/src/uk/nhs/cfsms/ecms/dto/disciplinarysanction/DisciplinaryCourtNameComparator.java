package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.util.Comparator;

import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;
import uk.nhs.cfsms.ecms.data.sanction.DisciplinaryAppealHearing;

public class DisciplinaryCourtNameComparator implements Comparator<DisciplinaryAppealHearing>{

	public int compare(DisciplinaryAppealHearing o1, DisciplinaryAppealHearing o2) {
        return o2.getHearingId().compareTo(o1.getHearingId());
    }

}
