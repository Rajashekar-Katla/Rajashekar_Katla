package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Sanction Applied class to hold of the name and whether it is checked.
 * 
 */

public class SanctionApplied  implements Serializable{

	String sanctionName;

	boolean checked;
	
	Long sanctionId;
	
	String sanctionCondition;
	
	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public String getSanctionName() {
		return sanctionName;
	}

	public void setSanctionName(String sanctionName) {
		this.sanctionName = sanctionName;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public String getSanctionCondition() {
		return sanctionCondition;
	}

	public void setSanctionCondition(String sanctionCondition) {
		this.sanctionCondition = sanctionCondition;
	}

}
