package uk.nhs.cfsms.ecms.dto.user;

import java.io.Serializable;
import java.util.ArrayList;

public class UserPermissionsTO implements Serializable{

	private String userId;

	private String userGroup;

	private ArrayList userPermissions;

	public UserPermissionsTO() {

	}

	public String getUserGroup() {
		return userGroup;
	}

	public void setUserGroup(String userGroup) {
		this.userGroup = userGroup;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public ArrayList getUserPermissions() {
		return userPermissions;
	}

	public void setUserPermissions(ArrayList userPermissions) {
		this.userPermissions = userPermissions;
	}

}
