package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.util.Date;

/**
 * Common transfer object to be used for both appeal and sanction details. 
 *
 */
public class DisciplinaryAppealSanctionTO {

	private Long appealId;
	
	private Long sanctionId;
	
	// start date or appealed date
	private Date appealedDate;  
	
	private Date outcomeDate; 
	
	private String selectedSanctions;
	
	private String courtName;
	
	private String outcomeStatus;
	
	private String organisationName;
	
	private String subjectName;
	
	private boolean appealExistsForTheCurrent;
	
	private String sanctionType;
	 

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public Date getAppealedDate() {
		return appealedDate;
	}

	public void setAppealedDate(Date appealedDate) {
		this.appealedDate = appealedDate;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public String getSelectedSanctions() {
		return selectedSanctions;
	}

	public void setSelectedSanctions(String selectedSanctions) {
		this.selectedSanctions = selectedSanctions;
	}
	
	public String getCourtName() {
		return courtName;
	}

	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}
	
	public String getOutcomeStatus() {
		return outcomeStatus;
	}

	public void setOutcomeStatus(String outcomeStatus) {
		this.outcomeStatus = outcomeStatus;
	}
	
	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public boolean isAppealExistsForTheCurrent() {
		return appealExistsForTheCurrent;
	}

	public void setAppealExistsForTheCurrent(boolean appealExistsForTheCurrent) {
		this.appealExistsForTheCurrent = appealExistsForTheCurrent;
	}

	/**
	 * @return the sanctionType
	 */
	public String getSanctionType() {
		return sanctionType;
	}

	/**
	 * @param sanctionType the sanctionType to set
	 */
	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

	 
}
