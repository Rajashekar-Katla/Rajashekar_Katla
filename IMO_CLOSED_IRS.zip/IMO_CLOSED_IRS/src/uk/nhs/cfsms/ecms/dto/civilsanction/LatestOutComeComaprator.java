package uk.nhs.cfsms.ecms.dto.civilsanction;

import java.util.Comparator;

public class LatestOutComeComaprator implements Comparator<CivilAppealAndSanctionOutcome>{

	@Override
	public int compare(CivilAppealAndSanctionOutcome o1,
			CivilAppealAndSanctionOutcome o2) {
		int result = 0;
		if(o1.getOutcomeDate() != null && o2.getOutcomeDate() != null){
			result =  o1.getOutcomeDate().compareTo(o2.getOutcomeDate());
		} else if(o1.getOutcomeDate() != null){
			result =  1;
		} else if(o2.getOutcomeDate() != null) {
			result =  -1;
		}
		return result;
	}
	
}
