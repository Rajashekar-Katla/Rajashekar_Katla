package uk.nhs.cfsms.ecms.dto.civilsanction;

import java.io.Serializable;
import java.util.Date;

public class CivilAppealAndSanctionOutcome implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8753358171622679289L;

	private Long outcomeId;
	private Long caseId;
	private Long sanctionId;
	private Long appealId;
	private String subjectName;
	private String type;
	private String outcomeStatus;
	private String courtMakingDecision;
	private String ordersMade;
	private String finalHearingCourtname;
	private Date outcomeDate;
	private boolean appealsExist;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long id) {
		this.outcomeId = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	private String detailsOfOutcome;

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public String getDetailsOfOutcome() {
		return detailsOfOutcome;
	}

	public void setDetailsOfOutcome(String detailsOfOutcome) {
		this.detailsOfOutcome = detailsOfOutcome;
	}

	public String getCourtMakingDecision() {
		return courtMakingDecision;
	}

	public void setCourtMakingDecision(String courtMakingDecision) {
		this.courtMakingDecision = courtMakingDecision;
	}

	public String getOrdersMade() {
		return ordersMade;
	}

	public void setOrdersMade(String ordersMade) {
		this.ordersMade = ordersMade;
	}

	public String getFinalHearingCourtname() {
		return finalHearingCourtname;
	}

	public void setFinalHearingCourtname(String finalHearingCourtname) {
		this.finalHearingCourtname = finalHearingCourtname;
	}

	public String getOutcomeStatus() {
		return outcomeStatus;
	}

	public void setOutcomeStatus(String outcomeStatus) {
		this.outcomeStatus = outcomeStatus;
	}

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Long getOwningId() {
		if ("SANCTION".equalsIgnoreCase(getType())) {
			return sanctionId;
		} else {
			return appealId;
		}
	}

	public boolean isAppealsExist() {
		return appealsExist;
	}

	public void setAppealsExist(boolean appealsExist) {
		this.appealsExist = appealsExist;
	}

}