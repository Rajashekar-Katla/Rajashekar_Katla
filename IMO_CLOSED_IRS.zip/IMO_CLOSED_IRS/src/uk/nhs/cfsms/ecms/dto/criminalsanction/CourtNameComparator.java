package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.util.Comparator;

import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;

public class CourtNameComparator implements Comparator<CourtAppearance>{
	
	public int compare(CourtAppearance o1, CourtAppearance o2) {
        return o2.getAppearanceId().compareTo(o1.getAppearanceId());
    }

}
