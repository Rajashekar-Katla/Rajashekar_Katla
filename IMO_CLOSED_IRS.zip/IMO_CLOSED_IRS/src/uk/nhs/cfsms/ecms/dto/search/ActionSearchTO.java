package uk.nhs.cfsms.ecms.dto.search;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.apache.commons.lang.StringUtils;

import uk.nhs.cfsms.ecms.data.cim.CaseActionSearchObject;
import uk.nhs.cfsms.ecms.model.CaseActionBookTO;

/**
 * Transfer object for case Action filter search.
 * 
 */
public class ActionSearchTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String caseNumber;

	private String actionNumber;
	
	private String operationName;

	private String actionStatus;

	private boolean isDataRange;
	
	private Date startDate;

	private Date endDate;
	
	private String closedBy;
	
	@SuppressWarnings("unchecked")
	private List<CaseActionSearchObject> searchResults = LazyList.decorate(new ArrayList(),
			FactoryUtils.instantiateFactory(CaseActionSearchObject.class));

	@SuppressWarnings("unchecked")
	private List<CaseActionBookTO> searchResultsTO = LazyList.decorate(new ArrayList(),
			FactoryUtils.instantiateFactory(CaseActionBookTO.class));
	

	public List<CaseActionSearchObject> getSearchResults() {
		return searchResults;
	}

	public void setSearchResults(List<CaseActionSearchObject> searchResults) {
		this.searchResults = searchResults;
	}

	public List<CaseActionBookTO> getSearchResultsTO() {
		return searchResultsTO;
	}

	public void setSearchResultsTO(List<CaseActionBookTO> searchResultsTO) {
		this.searchResultsTO = searchResultsTO;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public String getActionNumber() {
		return actionNumber;
	}

	public void setActionNumber(String actionNumber) {
		this.actionNumber = actionNumber;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getActionStatus() {
		return actionStatus;
	}

	public void setActionStatus(String actionStatus) {
		this.actionStatus = actionStatus;
	}

	public boolean isDataRange() {
		return isDataRange;
	}

	public void setDataRange(boolean isDataRange) {
		this.isDataRange = isDataRange;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getClosedBy() {
		return closedBy;
	}

	public void setClosedBy(String closedBy) {
		this.closedBy = closedBy;
	}
	
	public boolean isValidDateRange() {
		
		if (isDataRange() && isNotEmpty(startDate) && isNotEmpty(endDate)) {
			
			return true;
		}
		return false;
	}
	
	public boolean isNotEmptyCaseNumber() {
		
		return isNotEmpty(caseNumber);
	}
	
	public boolean isNotEmptyOperationName() {
		
		return isNotEmpty(operationName);
	}

	private boolean isNotEmpty(Date date) {
		
		if (null != date && StringUtils.isNotEmpty(date.toString())) {
			return true;
		}
		return false;
	}
	
	private boolean isNotEmpty(String str) {
		
		if (null != str && StringUtils.isNotEmpty(str)) {
			return true;
		}
		return false;		
	}
	
}
