package uk.nhs.cfsms.ecms.dto.civilsanction;

import java.io.Serializable;
import java.util.Date;
 
public class CivilAppealOutcomeTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7110354678380360511L;

	private Long outcomeId;

	private String createdStaffId;
	
	private Date createdTime;
	
	private Date dateofOutcome;
	
	private String outcomeStatus;
	
	private String ordersMade;
	
	private String amountsAwardedForThis;
	
	private String totalCostSettlement;
	
	private Long appealID;
	
	private Long caseID;
	
	private Long sanctionID;
	
	private String subjectName;
	
	private Date dateOfAppeal;
	
	private boolean appealsExist;
	

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long id) {
		this.outcomeId = id;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getDateofOutcome() {
		return dateofOutcome;
	}

	public void setDateofOutcome(Date dateofOutcome) {
		this.dateofOutcome = dateofOutcome;
	}

	public String getOutcomeStatus() {
		return outcomeStatus;
	}

	public void setOutcomeStatus(String outcomeStatus) {
		this.outcomeStatus = outcomeStatus;
	}

	public String getOrdersMade() {
		return ordersMade;
	}

	public void setOrdersMade(String ordersMade) {
		this.ordersMade = ordersMade;
	}

	public String getAmountsAwardedForThis() {
		return amountsAwardedForThis;
	}

	public void setAmountsAwardedForThis(String amountsAwardedForThis) {
		this.amountsAwardedForThis = amountsAwardedForThis;
	}

	public String getTotalCostSettlement() {
		return totalCostSettlement;
	}

	public void setTotalCostSettlement(String totalCostSettlement) {
		this.totalCostSettlement = totalCostSettlement;
	}

	public Long getAppealID() {
		return appealID;
	}

	public void setAppealID(Long appealID) {
		this.appealID = appealID;
	}

	public Long getCaseID() {
		return caseID;
	}

	public void setCaseID(Long caseID) {
		this.caseID = caseID;
	}

	public Long getSanctionID() {
		return sanctionID;
	}

	public void setSanctionID(Long sanctionID) {
		this.sanctionID = sanctionID;
	}
	
	public Date getDateOfAppeal() {
		return dateOfAppeal;
	}

	public void setDateOfAppeal(Date dateOfAppeal) {
		this.dateOfAppeal = dateOfAppeal;
	}

	public boolean isAppealsExist() {
		return appealsExist;
	}

	public void setAppealsExist(boolean appealsExist) {
		this.appealsExist = appealsExist;
	}
	
}
