package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;
import java.sql.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

public class SourceInformationTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 203403100L;

	private Integer sourceId;

	private String sourceType;
	
	private String source;

	private String method;

	private String otherMethod;

	private String receivedBy;

	private String receivedLocation;

	private Date receivedDate;

	private String isSourceIdentified;
	
	private PersonTO sourcePersonTO;

	private String isOfficialCapacity;

	private String jobTitle;

	private String otherDetails;

	private String otherSource;

	private String isSourceAnonymous;

	public String getIsSourceAnonymous() {
		return isSourceAnonymous;
	}

	public void setIsSourceAnonymous(String isSourceAnonymous) {
		this.isSourceAnonymous = isSourceAnonymous;
	}

	public String getIsSourceIdentified() {
		return isSourceIdentified;
	}

	public void setIsSourceIdentified(String isSourceIdentified) {
		this.isSourceIdentified = isSourceIdentified;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getOtherMethod() {
		return otherMethod;
	}

	public void setOtherMethod(String otherMethod) {
		this.otherMethod = otherMethod;
	}

	public String getReceivedBy() {
		return receivedBy;
	}

	public void setReceivedBy(String receivedBy) {
		this.receivedBy = receivedBy;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getReceivedLocation() {
		return receivedLocation;
	}

	public void setReceivedLocation(String receivedLocation) {
		this.receivedLocation = receivedLocation;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Integer getSourceId() {
		return sourceId;
	}

	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}

	public PersonTO getSourcePersonTO() {
		return sourcePersonTO;
	}

	public void setSourcePersonTO(PersonTO sourcePersonTO) {
		this.sourcePersonTO = sourcePersonTO;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	

	public String getIsOfficialCapacity() {
		return isOfficialCapacity;
	}

	public void setIsOfficialCapacity(String isOfficialCapacity) {
		this.isOfficialCapacity = isOfficialCapacity;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getOtherDetails() {
		return otherDetails;
	}

	public void setOtherDetails(String otherDetails) {
		this.otherDetails = otherDetails;
	}

	public String getOtherSource() {
		return otherSource;
	}

	public void setOtherSource(String otherSource) {
		this.otherSource = otherSource;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);

	}
}
