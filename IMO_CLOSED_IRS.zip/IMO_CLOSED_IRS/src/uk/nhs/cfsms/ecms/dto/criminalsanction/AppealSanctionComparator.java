package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.util.Comparator;

public class AppealSanctionComparator implements Comparator<AppealSanctionTO>{
       
	public int compare(AppealSanctionTO o1, AppealSanctionTO o2) {
		int rv = 0;
		if(o1 != null && o2 != null){
			if(o2.getOutcomeDate() != null && o1.getOutcomeDate() != null){
		    rv = o2.getOutcomeDate().compareTo(o1.getOutcomeDate());
			}
		}
	  return rv;
    }

}
