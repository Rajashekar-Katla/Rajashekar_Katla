package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.util.Comparator;

import uk.nhs.cfsms.ecms.dto.caseInfo.AppealHearingTO;

public class AppealHearingCourtNameComparator implements Comparator<AppealHearingTO>{

	public int compare(AppealHearingTO o1, AppealHearingTO o2) {
        
		int compareVal = o2.getHearingDate().compareTo(o1.getHearingDate());
		
		if (compareVal == 0) {
			// TODO : Check for Haring Time.
			compareVal = o2.getHearingTime().compareTo(o1.getHearingTime());	
		}
		if (compareVal == 0) {
			compareVal = o2.getAppearanceId().compareTo(o1.getAppealId());	
		}
		
		return compareVal;
    }
	
}
