package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Disciplinary Sanction Imposed class to hold of the name and whether it is
 * checked.
 * 
 */

public class DisciplinarySanctionImposed implements Serializable {
	
	String sanctionName;

	boolean checked;

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public String getSanctionName() {
		return sanctionName;
	}

	public void setSanctionName(String sanctionName) {
		this.sanctionName = sanctionName;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
