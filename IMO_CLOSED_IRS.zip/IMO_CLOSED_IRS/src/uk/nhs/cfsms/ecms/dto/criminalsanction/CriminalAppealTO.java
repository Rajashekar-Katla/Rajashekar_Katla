package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.sanction.AppealOutcome;
import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;

public class CriminalAppealTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3952228448833993894L;

	private Long appealId;
	private Long parentAppealId;
	private Long sanctionId;
	private Long caseId;
	private String subjectType;
	private String appealMaker;
	private String createdStaffId;
	private Date createdTime;
	private Date appearedDate;
	private String courtMakingDecName;
	private String state;
	private String nhsSubjectName;
	private String nonNhsSubjectName;
	private String personSubjectName;
	private String subject;

	private Long subjectId;

	private List<CourtAppearance> courtAppearanceList;

	private AppealOutcome outcome;
	private String selectedSanctions;
	private String otherSubject;
	private String appellantName;

	private CriminalAppealTO parentAppealTO;

	// Output parent details of this appeal (Appeal or Sanction).
	private boolean appealIsParent;
	
	// Has appeal (dependents) based on this original appeal.
	private boolean appealExist;

	private CriminalSanctionTO parentSanctionTO;
	

	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId
	 *            The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return Returns the createdStaffId.
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	/**
	 * @param createdStaffId
	 *            The createdStaffId to set.
	 */
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	/**
	 * @return Returns the createdTime.
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime
	 *            The createdTime to set.
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return Returns the criminalSanctionId.
	 */
	public Long getAppealId() {
		return appealId;
	}

	/**
	 * @param criminalSanctionId
	 *            The criminalSanctionId to set.
	 */
	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return Returns the subjectType.
	 */
	public String getSubjectType() {
		return subjectType;
	}

	/**
	 * @param subjectType
	 *            The subjectType to set.
	 */
	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	/**
	 * @return Returns the nhsSubjectName.
	 */
	public String getNhsSubjectName() {
		return nhsSubjectName;
	}

	/**
	 * @param nhsSubjectName
	 *            The nhsSubjectName to set.
	 */
	public void setNhsSubjectName(String nhsSubjectName) {
		this.nhsSubjectName = nhsSubjectName;
	}

	public String getAppealMaker() {
		return appealMaker;
	}

	public void setAppealMaker(String appealMaker) {
		this.appealMaker = appealMaker;
	}

	/**
	 * @return Returns the nonNhsSubjectName.
	 */
	public String getNonNhsSubjectName() {
		return nonNhsSubjectName;
	}

	/**
	 * @param nonNhsSubjectName
	 *            The nonNhsSubjectName to set.
	 */
	public void setNonNhsSubjectName(String nonNhsSubjectName) {
		this.nonNhsSubjectName = nonNhsSubjectName;
	}

	/**
	 * @return Returns the personSubjectName.
	 */
	public String getPersonSubjectName() {
		return personSubjectName;
	}

	/**
	 * @param personSubjectName
	 *            The personSubjectName to set.
	 */
	public void setPersonSubjectName(String personSubjectName) {
		this.personSubjectName = personSubjectName;
	}

	/**
	 * @return Returns the subjectId.
	 */
	public Long getSubjectId() {
		return subjectId;
	}

	/**
	 * @param subjectId
	 *            The subjectId to set.
	 */
	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public List<CourtAppearance> getCourtAppearanceList() {
		return courtAppearanceList;
	}

	public void setCourtAppearanceList(List<CourtAppearance> courtAppearanceList) {
		this.courtAppearanceList = courtAppearanceList;
	}

	public AppealOutcome getOutcome() {
		return outcome;
	}

	public void setOutcome(AppealOutcome outcome) {
		this.outcome = outcome;
	}

	public Date getAppearedDate() {
		return appearedDate;
	}

	public void setAppearedDate(Date appearedDate) {
		this.appearedDate = appearedDate;
	}

	public String getCourtMakingDecName() {
		return courtMakingDecName;
	}

	public void setCourtMakingDecName(String courtMakingDecName) {
		this.courtMakingDecName = courtMakingDecName;
	}

	public Long getSanctionId() {
		return sanctionId;
	}

	public void setSanctionId(Long sanctionId) {
		this.sanctionId = sanctionId;
	}

	public String getSelectedSanctions() {
		return selectedSanctions;
	}

	public void setSelectedSanctions(String selectedSanctions) {
		this.selectedSanctions = selectedSanctions;
	}

	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getOtherSubject() {
		return otherSubject;
	}

	public void setOtherSubject(String otherSubject) {
		this.otherSubject = otherSubject;
	}

	public String getAppellantName() {
		return appellantName;
	}

	public void setAppellantName(String appellantName) {
		this.appellantName = appellantName;
	}

	public CriminalAppealTO getParentAppealTO() {
		return parentAppealTO;
	}

	public void setParentAppealTO(CriminalAppealTO parentAppealTO) {
		this.parentAppealTO = parentAppealTO;
	}

	public boolean isAppealIsParent() {
		return appealIsParent;
	}

	public void setAppealIsParent(boolean appealIsParent) {
		this.appealIsParent = appealIsParent;
	}

	public CriminalSanctionTO getParentSanctionTO() {
		return parentSanctionTO;
	}

	public void setParentSanctionTO(CriminalSanctionTO parentSanctionTO) {
		this.parentSanctionTO = parentSanctionTO;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public boolean isAppealExist() {
		return appealExist;
	}

	public void setAppealExist(boolean appealExist) {
		this.appealExist = appealExist;
	}
}
