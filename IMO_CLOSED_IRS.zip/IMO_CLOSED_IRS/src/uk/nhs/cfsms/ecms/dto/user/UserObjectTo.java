package uk.nhs.cfsms.ecms.dto.user;

import java.io.Serializable;

public class UserObjectTo implements Serializable,Comparable<UserObjectTo> {

	private static final long serialVersionUID = 476534011L;

	private String staffId;

	private String title;

	private String firstName;

	private String middleName;

	private String lastName;

	private String knownAs;

	private String employerOrgCode;

	private String jobTitle;

	private String phoneNumber;

	private String phoneExtension;

	private String phoneNumber2;

	private String mobileNumber;

	private String homeNumber;

	private String pager;

	private String faxNumber;

	private String nhsEmailAddress;

	private String otherEmailAddress;

	private String additionalEmailAddress;

	private String address1;

	private String address2;

	private String address3;

	private String address4;

	private String address5;

	private String postCode;

	private String groupPermission;

	private String teamCode;

	private String directorate;

	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAdditionalEmailAddress() {
		return additionalEmailAddress;
	}

	public void setAdditionalEmailAddress(String additionalEmailAddress) {
		this.additionalEmailAddress = additionalEmailAddress;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getAddress5() {
		return address5;
	}

	public void setAddress5(String address5) {
		this.address5 = address5;
	}

	public String getEmployerOrgCode() {
		return employerOrgCode;
	}

	public void setEmployerOrgCode(String employerOrgCode) {
		this.employerOrgCode = employerOrgCode;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getKnownAs() {
		return knownAs;
	}

	public void setKnownAs(String knownAs) {
		this.knownAs = knownAs;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getOtherEmailAddress() {
		return otherEmailAddress;
	}

	public void setOtherEmailAddress(String otherEmailAddress) {
		this.otherEmailAddress = otherEmailAddress;
	}

	public String getPhoneExtension() {
		return phoneExtension;
	}

	public void setPhoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber2() {
		return phoneNumber2;
	}

	public void setPhoneNumber2(String phoneNumber2) {
		this.phoneNumber2 = phoneNumber2;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postalCode) {
		this.postCode = postalCode;
	}

	public String getStaffId() {
		return staffId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getGroupPermission() {
		return groupPermission;
	}

	public void setGroupPermission(String groupPermission) {
		this.groupPermission = groupPermission;
	}

	public String getPager() {
		return pager;
	}

	public void setPager(String pager) {
		this.pager = pager;
	}

	public String getHomeNumber() {
		return homeNumber;
	}

	public void setHomeNumber(String homeNumber) {
		this.homeNumber = homeNumber;
	}

	public String getNhsEmailAddress() {
		return nhsEmailAddress;
	}

	public void setNhsEmailAddress(String nhsEmailAddress) {
		this.nhsEmailAddress = nhsEmailAddress;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public String getDirectorate() {
		return directorate;
	}

	public void setDirectorate(String directorate) {
		this.directorate = directorate;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	@Override
	public int compareTo(UserObjectTo userObject) {
		return this.firstName.compareTo(userObject.firstName);
	}

	@Override
	public String toString() {
		return "UserObjectTo [staffId=" + staffId + ", title=" + title
				+ ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", knownAs=" + knownAs
				+ ", employerOrgCode=" + employerOrgCode + ", jobTitle="
				+ jobTitle + ", phoneNumber=" + phoneNumber
				+ ", phoneExtension=" + phoneExtension + ", phoneNumber2="
				+ phoneNumber2 + ", mobileNumber=" + mobileNumber
				+ ", homeNumber=" + homeNumber + ", pager=" + pager
				+ ", faxNumber=" + faxNumber + ", nhsEmailAddress="
				+ nhsEmailAddress + ", otherEmailAddress=" + otherEmailAddress
				+ ", additionalEmailAddress=" + additionalEmailAddress
				+ ", address1=" + address1 + ", address2=" + address2
				+ ", address3=" + address3 + ", address4=" + address4
				+ ", address5=" + address5 + ", postCode=" + postCode
				+ ", groupPermission=" + groupPermission + ", teamCode="
				+ teamCode + ", directorate=" + directorate + ", status="
				+ status + "]";
	}

}