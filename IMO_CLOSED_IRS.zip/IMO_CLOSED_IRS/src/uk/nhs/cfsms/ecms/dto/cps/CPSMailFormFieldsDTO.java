package uk.nhs.cfsms.ecms.dto.cps;

import java.io.Serializable;

public class CPSMailFormFieldsDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String investigationStage;
	private String action;
	private String subjectHeader;
	private String requiredInfo;

	public String getInvestigationStage() {
		return investigationStage;
	}

	public void setInvestigationStage(String investigationStage) {
		this.investigationStage = investigationStage;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getSubjectHeader() {
		return subjectHeader;
	}

	public void setSubjectHeader(String subjectHeader) {
		this.subjectHeader = subjectHeader;
	}

	public String getRequiredInfo() {
		return requiredInfo;
	}

	public void setRequiredInfo(String requiredInfo) {
		this.requiredInfo = requiredInfo;
	}

}
