package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;

public class InformationViewTO implements Serializable {

	private static final long serialVersionUID = 1305234L;

	private Long informationId;

	private String type;

	private BigDecimal cost;

	private String orgName;

	private String orgCode;

	private Long caseId;

	private Timestamp createdDate;

	private String createdStaffId;

	private String subjectName;

	private String regionOverride;

	private String teamCode;

	private String state;

	public BigDecimal getCost() {
		return cost == null ?  new BigDecimal(BigInteger.ZERO) : cost.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getRegionOverride() {
		return regionOverride;
	}

	public void setRegionOverride(String regionOverride) {
		this.regionOverride = regionOverride;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public boolean hasRegionOverride() {

		if (null != this.regionOverride
				&& (this.regionOverride.indexOf("Y") != -1 || this.regionOverride
						.indexOf("y") != -1)) {
			return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((caseId == null) ? 0 : caseId.hashCode());
		result = prime * result + ((cost == null) ? 0 : cost.hashCode());
		result = prime * result
				+ ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result
				+ ((createdStaffId == null) ? 0 : createdStaffId.hashCode());
		result = prime * result
				+ ((informationId == null) ? 0 : informationId.hashCode());
		result = prime * result + ((orgCode == null) ? 0 : orgCode.hashCode());
		result = prime * result + ((orgName == null) ? 0 : orgName.hashCode());
		result = prime * result
				+ ((regionOverride == null) ? 0 : regionOverride.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result
				+ ((subjectName == null) ? 0 : subjectName.hashCode());
		result = prime * result
				+ ((teamCode == null) ? 0 : teamCode.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InformationViewTO other = (InformationViewTO) obj;
		if (caseId == null) {
			if (other.caseId != null)
				return false;
		} else if (!caseId.equals(other.caseId))
			return false;
		if (cost == null) {
			if (other.cost != null)
				return false;
		} else if (!cost.equals(other.cost))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (createdStaffId == null) {
			if (other.createdStaffId != null)
				return false;
		} else if (!createdStaffId.equals(other.createdStaffId))
			return false;
		if (informationId == null) {
			if (other.informationId != null)
				return false;
		} else if (!informationId.equals(other.informationId))
			return false;
		if (orgCode == null) {
			if (other.orgCode != null)
				return false;
		} else if (!orgCode.equals(other.orgCode))
			return false;
		if (orgName == null) {
			if (other.orgName != null)
				return false;
		} else if (!orgName.equals(other.orgName))
			return false;
		if (regionOverride == null) {
			if (other.regionOverride != null)
				return false;
		} else if (!regionOverride.equals(other.regionOverride))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (subjectName == null) {
			if (other.subjectName != null)
				return false;
		} else if (!subjectName.equals(other.subjectName))
			return false;
		if (teamCode == null) {
			if (other.teamCode != null)
				return false;
		} else if (!teamCode.equals(other.teamCode))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "InformationViewTO [informationId=" + informationId + ", type="
				+ type + ", cost=" + cost + ", orgName=" + orgName
				+ ", orgCode=" + orgCode + ", caseId=" + caseId
				+ ", createdDate=" + createdDate + ", createdStaffId="
				+ createdStaffId + ", subjectName=" + subjectName
				+ ", regionOverride=" + regionOverride + ", teamCode="
				+ teamCode + ", state=" + state + "]";
	}

}
