package uk.nhs.cfsms.ecms.dto.witness;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class WitnessStatementTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long statementId;

	private WitnessTO witness;

	private Date createdTime;

	private Date statementDateTime;

	private String createdStaffId;

	private String statementDescription;

	private byte[] statementFile;

	private String statementFileType;

	private String statementSignature;

	private String urn1;

	private String urn2;

	private String urn3;

	private String urn4;

	private String age;

	private String statementOf;

	private String occupation;

	private String noofPages;

	private String signature;

	private String witnessedBy;

	private String witnessSignature;

	private String isUploadedStatment;

	private String visuallyRecorded;

	private Date dob;
	
	private List<WitnessTO> witnessList;
	
	private String fileName;
	
	private String fileUploadError;
	
	private int partNumber;
	

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getIsUploadedStatment() {
		return isUploadedStatment;
	}

	public void setIsUploadedStatment(String isUploadedStatment) {
		this.isUploadedStatment = isUploadedStatment;
	}

	public String getNoofPages() {
		return noofPages;
	}

	public void setNoofPages(String noofPages) {
		this.noofPages = noofPages;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getStatementDescription() {
		return statementDescription;
	}

	public void setStatementDescription(String statement) {
		this.statementDescription = statement;
	}

	public Date getStatementDateTime() {
		return statementDateTime;
	}

	public void setStatementDateTime(Date statementDateTime) {
		this.statementDateTime = statementDateTime;
	}

	public byte[] getStatementFile() {
		return statementFile;
	}

	public void setStatementFile(byte[] statementFile) {
		this.statementFile = statementFile;
	}

	public String getStatementFileType() {
		return statementFileType;
	}

	public void setStatementFileType(String statementFileType) {
		this.statementFileType = statementFileType;
	}

	public Long getStatementId() {
		return statementId;
	}

	public void setStatementId(Long statementId) {
		this.statementId = statementId;
	}

	public String getStatementOf() {
		return statementOf;
	}

	public void setStatementOf(String statementOf) {
		this.statementOf = statementOf;
	}

	public WitnessTO getWitness() {
		if (null == witness)
			return new WitnessTO();
		return witness;
	}

	public void setWitness(WitnessTO witness) {
		this.witness = witness;
	}

	public String getWitnessedBy() {
		return witnessedBy;
	}

	public void setWitnessedBy(String witnessedBy) {
		this.witnessedBy = witnessedBy;
	}

	public String getWitnessSignature() {
		return witnessSignature;
	}

	public void setWitnessSignature(String witnessSignature) {
		this.witnessSignature = witnessSignature;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public String getUrn1() {
		return urn1;
	}

	public void setUrn1(String urn1) {
		this.urn1 = urn1;
	}

	public String getUrn2() {
		return urn2;
	}

	public void setUrn2(String urn2) {
		this.urn2 = urn2;
	}

	public String getUrn3() {
		return urn3;
	}

	public void setUrn3(String urn3) {
		this.urn3 = urn3;
	}

	public String getUrn4() {
		return urn4;
	}

	public void setUrn4(String urn4) {
		this.urn4 = urn4;
	}

	public String getVisuallyRecorded() {
		return visuallyRecorded;
	}

	public void setVisuallyRecorded(String visuallyRecorded) {
		this.visuallyRecorded = visuallyRecorded;
	}

	public String getStatementSignature() {
		return statementSignature;
	}

	public void setStatementSignature(String statementSignature) {
		this.statementSignature = statementSignature;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public List<WitnessTO> getWitnessList() {
		return witnessList;
	}

	public void setWitnessList(List<WitnessTO> witnessList) {
		this.witnessList = witnessList;
	}

	public String getFileUploadError() {
		return fileUploadError;
	}

	public void setFileUploadError(String fileUploadError) {
		this.fileUploadError = fileUploadError;
	}

	public int getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(int partNumber) {
		this.partNumber = partNumber;
	}

	
}
