package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;

/**
 * Disciplinary Appeal Outcome Transfer Object.
 * 
 */
public class DisciplinaryAppealOutcomeTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3006957540214617645L;

	private Long outcomeId;

	private Long appealId;

	private Date outcomeDate;

	private String status;

	private String createdStaffId;

	private Date createdTime;

	private String sanctionsImposed;

	private String otherSanctionImposed;

	private List<LookupView> lookupImposedList;
	
	private String dispType;
	
	private List<OutcomeAppliedSanction> outcomeAppliedSanctions = new ArrayList<OutcomeAppliedSanction>();
	
	private String wasSanctionVaried;
	
	private String summarisedDetailsOfOutcome;
	
	//Appealed Date from appeal.
	private Date startDate; 
	
	private String sanctionType;
	
	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long outcomeId) {
		this.outcomeId = outcomeId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOtherSanctionImposed() {
		return otherSanctionImposed;
	}

	public void setOtherSanctionImposed(String otherSanctionImposed) {
		if (otherSanctionImposed != null) {
			this.otherSanctionImposed = otherSanctionImposed;
		}
	}

	public String getSanctionsImposed() {
		return sanctionsImposed;
	}
	
	

	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public List<OutcomeAppliedSanction> getOutcomeAppliedSanctions() {
		return outcomeAppliedSanctions;
	}

	public void setOutcomeAppliedSanctions(
			List<OutcomeAppliedSanction> outcomeAppliedSanctions) {
		this.outcomeAppliedSanctions = outcomeAppliedSanctions;
	}

	public List<LookupView> getLookupImposedList() {
		return lookupImposedList;
	}

	public void setLookupImposedList(List<LookupView> lookupImposedList) {
		this.lookupImposedList = lookupImposedList;
	}

	public void setSanctionsImposed(String sanctionsImposed) {
		this.sanctionsImposed = sanctionsImposed;
	}

	public String getDispType() {
		return dispType;
	}

	public void setDispType(String dispType) {
		this.dispType = dispType;
	}
	
	public String getWasSanctionVaried() {
		return wasSanctionVaried;
	}

	public void setWasSanctionVaried(String wasSanctionVaried) {
		this.wasSanctionVaried = wasSanctionVaried;
	}

	public String getSummarisedDetailsOfOutcome() {
		return summarisedDetailsOfOutcome;
	}

	public void setSummarisedDetailsOfOutcome(String summarisedDetailsOfOutcome) {
		this.summarisedDetailsOfOutcome = summarisedDetailsOfOutcome;
	}
	
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the sanctionType
	 */
	public String getSanctionType() {
		return sanctionType;
	}

	/**
	 * @param sanctionType the sanctionType to set
	 */
	public void setSanctionType(String sanctionType) {
		this.sanctionType = sanctionType;
	}

	
}
