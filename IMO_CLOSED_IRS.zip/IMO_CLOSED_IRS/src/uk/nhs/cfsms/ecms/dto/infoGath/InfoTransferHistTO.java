package uk.nhs.cfsms.ecms.dto.infoGath;

import java.util.Date;

public class InfoTransferHistTO {

	private Long transId;
	
	private Long infoId;
	
	private String teamCode;
	
	private String createdStaffId;
	
	private String createdStaffName;
	
	private Date createdTime;
	
	private String transferTeamCode;
	
	private Date transferDate;
	
	private String transferStaffId;
	
	private String state;
	
	private String approverStaffID;
	
	private String approverStaffName;
	
	private String transferComments;
	
	private String approvalComments;

	public Long getTransId() {
		return transId;
	}

	public void setTransId(Long transId) {
		this.transId = transId;
	}

	public Long getInfoId() {
		return infoId;
	}

	public void setInfoId(Long infoId) {
		this.infoId = infoId;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getTransferTeamCode() {
		return transferTeamCode;
	}

	public void setTransferTeamCode(String transferTeamCode) {
		this.transferTeamCode = transferTeamCode;
	}

	public Date getTransferDate() {
		return transferDate;
	}

	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}

	public String getTransferStaffId() {
		return transferStaffId;
	}

	public void setTransferStaffId(String transferStaffId) {
		this.transferStaffId = transferStaffId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getApproverStaffID() {
		return approverStaffID;
	}

	public void setApproverStaffID(String approverStaffID) {
		this.approverStaffID = approverStaffID;
	}

	public String getTransferComments() {
		return transferComments;
	}

	public void setTransferComments(String transferComments) {
		this.transferComments = transferComments;
	}

	public String getApprovalComments() {
		return approvalComments;
	}

	public void setApprovalComments(String approvalComments) {
		this.approvalComments = approvalComments;
	}

	public String getCreatedStaffName() {
		return createdStaffName;
	}

	public void setCreatedStaffName(String createdStaffName) {
		this.createdStaffName = createdStaffName;
	}

	public String getApproverStaffName() {
		return approverStaffName;
	}

	public void setApproverStaffName(String approverStaffName) {
		this.approverStaffName = approverStaffName;
	}
}
