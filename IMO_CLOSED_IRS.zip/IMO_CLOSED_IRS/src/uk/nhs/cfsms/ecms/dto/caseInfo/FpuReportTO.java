package uk.nhs.cfsms.ecms.dto.caseInfo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import uk.nhs.cfsms.ecms.data.common.LookupView;
import uk.nhs.cfsms.ecms.data.fpureport.FpuReportSubType;

public class FpuReportTO implements Serializable {

	private Long fpuReportId;

	private Long caseId;

	private Long informationId;

	private String systemWeaknessIdentified;

	private String healthBodyType;

	private String otherriskArea;

	private String systemWeaknessDetails;

	private String fraudProven;

	private String otherFraudType;

	private String lossesIdentified;

	private String localActionTaken;

	private String otherActionTaken;

	private String actionDetails;

	private String suggestions;

	private String otherSystemWeakness;

	private String riskAssesmentRating;

	private String otherHealthBodyType;

	private List<FpuReportSubType> reportSubTypes;

	private List<LookupView> fraudList;

	private List<LookupView> groupList;

	private List<LookupView> areaList;

	private List<LookupView> weaknessList;

	private List<LookupView> actionList;

	private String createdStaffId;

	private Date createdTime;

	private String orgCode;

	private String teamCode;

	private String fpuView;

	private String lossIdentified;
	
	private String recPreventiveAction;

	public String getFpuView() {
		return fpuView;
	}

	public void setFpuView(String fpuView) {
		this.fpuView = fpuView;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getOtherFraudType() {
		return otherFraudType;
	}

	public void setOtherFraudType(String otherFraudType) {
		this.otherFraudType = otherFraudType;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getFpuReportId() {
		return fpuReportId;
	}

	public void setFpuReportId(Long fpuReportId) {
		this.fpuReportId = fpuReportId;
	}

	public String getHealthBodyType() {
		return healthBodyType;
	}

	public void setHealthBodyType(String healthBodyType) {
		this.healthBodyType = healthBodyType;
	}

	public String getLocalActionTaken() {
		return localActionTaken;
	}

	public void setLocalActionTaken(String localActionTaken) {
		this.localActionTaken = localActionTaken;
	}

	public String getOtherActionTaken() {
		return otherActionTaken;
	}

	public void setOtherActionTaken(String otherActionTaken) {
		this.otherActionTaken = otherActionTaken;
	}

	public String getOtherriskArea() {
		return otherriskArea;
	}

	public void setOtherriskArea(String otherriskArea) {
		this.otherriskArea = otherriskArea;
	}

	public List<FpuReportSubType> getReportSubTypes() {
		return reportSubTypes;
	}

	public void setReportSubTypes(List<FpuReportSubType> reportSubTypes) {
		this.reportSubTypes = reportSubTypes;
	}

	public String getRiskAssesmentRating() {
		return riskAssesmentRating;
	}

	public void setRiskAssesmentRating(String riskAssesmentRating) {
		this.riskAssesmentRating = riskAssesmentRating;
	}

	public String getSystemWeaknessDetails() {
		return systemWeaknessDetails;
	}

	public void setSystemWeaknessDetails(String systemWeaknessDetails) {
		this.systemWeaknessDetails = systemWeaknessDetails;
	}

	public String getSystemWeaknessIdentified() {
		return systemWeaknessIdentified;
	}

	public void setSystemWeaknessIdentified(String systemWeaknessIdentified) {
		this.systemWeaknessIdentified = systemWeaknessIdentified;
	}

	public List<LookupView> getActionList() {
		return actionList;
	}

	public void setActionList(List<LookupView> actionList) {
		this.actionList = actionList;
	}

	public List<LookupView> getAreaList() {
		return areaList;
	}

	public void setAreaList(List<LookupView> areaList) {
		this.areaList = areaList;
	}

	public List<LookupView> getFraudList() {
		return fraudList;
	}

	public void setFraudList(List<LookupView> fraudList) {
		this.fraudList = fraudList;
	}

	public List<LookupView> getGroupList() {
		return groupList;
	}

	public void setGroupList(List<LookupView> groupList) {
		this.groupList = groupList;
	}

	public List<LookupView> getWeaknessList() {
		return weaknessList;
	}

	public void setWeaknessList(List<LookupView> weaknessList) {
		this.weaknessList = weaknessList;
	}

	public String getLossesIdentified() {
		return lossesIdentified;
	}

	public void setLossesIdentified(String lossesIdentified) {
		this.lossesIdentified = lossesIdentified;
	}

	public String getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}

	public String getActionDetails() {
		return actionDetails;
	}

	public void setActionDetails(String actionDetails) {
		this.actionDetails = actionDetails;
	}

	public String getFraudProven() {
		return fraudProven;
	}

	public void setFraudProven(String fraudProven) {
		this.fraudProven = fraudProven;
	}

	public String getOtherHealthBodyType() {
		return otherHealthBodyType;
	}

	public void setOtherHealthBodyType(String otherHealthBodyType) {
		this.otherHealthBodyType = otherHealthBodyType;
	}

	public String getOtherSystemWeakness() {
		return otherSystemWeakness;
	}

	public void setOtherSystemWeakness(String otherSystemWeakness) {
		this.otherSystemWeakness = otherSystemWeakness;
	}

	public Long getInformationId() {
		return informationId;
	}

	public void setInformationId(Long informationId) {
		this.informationId = informationId;
	}

	public String getLossIdentified() {
		return lossIdentified;
	}

	public void setLossIdentified(String lossIdentified) {
		this.lossIdentified = lossIdentified;
	}

	public String getRecPreventiveAction() {
		return recPreventiveAction;
	}

	public void setRecPreventiveAction(String recPreventiveAction) {
		this.recPreventiveAction = recPreventiveAction;
	}

}
