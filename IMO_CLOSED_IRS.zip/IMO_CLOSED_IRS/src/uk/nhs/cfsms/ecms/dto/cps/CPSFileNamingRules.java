package uk.nhs.cfsms.ecms.dto.cps;

import static java.util.regex.Pattern.compile;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Test;

public class CPSFileNamingRules {

	//@Test
	//public void test(){
	//System.setProperty("webdriver.chrome.driver","C:/Data/workspace/Selenium_Project/chromedriver.exe");
	//}

	@Test
	public void testNPA01RegEx() {
		/**
		 * NPA01 Defendant SURNAME (in capitals) First Name Example: NPA01 GORE
		 * John NPA01 GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(NPA01\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(NPA01\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(NPA01\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("NPA01 final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { 
				"NPA01 GORE John", 
				"NPA01 GORE Gore-John",
				"NPA01 GORE Gore John", 
				"NPA01 GORE-JOHN Gore-John",
				"NPA01 GORE-JOHN Gore John", 
				"NPA01 GORE-JOHN Gorejohn",
				"NPA01 GORE JOHN Gore-John", 
				"NPA01 GORE JOHN Gorejohn",
				"NPA01 GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("NPA01==nope");
			} else {
				System.out.println("NPA01==yes");
			}
		}
	}

	@Test
	public void testCFS13aRegEx() {
		/**
		 * CFS13a Defendant SURNAME (in capitals) First Name Example: CFS13a
		 * GORE John CFS13a GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(CFS13a\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(CFS13a\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(CFS13a\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("CFS13a final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "CFS13a GORE John", "CFS13a GORE Gore-John",
				"CFS13a GORE Gore John", "CFS13a GORE-JOHN Gore-John",
				"CFS13a GORE-JOHN Gore John", "CFS13a GORE-JOHN Gorejohn",
				"CFS13a GORE JOHN Gore-John", "CFS13a GORE JOHN Gorejohn",
				"CFS13a GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("CFS13a==nope");
			} else {
				System.out.println("CFS13a==yes");
			}
		}
	}
	
	@Test
	public void testCPIAAnnexForm1RegEx() {
		/**
		 * NPA01 Defendant SURNAME (in capitals) First Name Example: NPA01 GORE
		 * John NPA01 GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "([A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\sSTREAMLINED DISCLOSURE CERTIFICATE Form 1)";

		String finalRegEx = regEx1;
		System.out.println("CPIA Annex Form final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "GORE John STREAMLINED DISCLOSURE CERTIFICATE Form 1", };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("CPIAAnnexForm==nope");
			} else {
				System.out.println("CPIAAnnexForm==yes");
			}
		}
	}
	
	@Test
	public void testCPIAAnnexForm2RegEx() {
		/**
		 * NPA01 Defendant SURNAME (in capitals) First Name Example: NPA01 GORE
		 * John NPA01 GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "([A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\sSTREAMLINED DISCLOSURE CERTIFICATE Form 2)";

		String finalRegEx = regEx1;
		System.out.println("CPIA Annex Form final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "GORE John STREAMLINED DISCLOSURE CERTIFICATE Form 2", };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("CPIAAnnexForm==nope");
			} else {
				System.out.println("CPIAAnnexForm==yes");
			}
		}
	}

	@Test
	public void testCPIAAnnexForm3RegEx() {
		/**
		 * NPA01 Defendant SURNAME (in capitals) First Name Example: NPA01 GORE
		 * John NPA01 GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "([A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\sSTREAMLINED DISCLOSURE CERTIFICATE Form 3)";

		String finalRegEx = regEx1;
		System.out.println("CPIA Annex Form final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "GORE John STREAMLINED DISCLOSURE CERTIFICATE Form 3", };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("CPIAAnnexForm==nope");
			} else {
				System.out.println("CPIAAnnexForm==yes");
			}
		}
	}
	
	@Test
	public void testMG2RegEx() {
		/**
		 * MG2 Defendant SURNAME (in capitals) First Name Example: MG2 GORE John
		 * MG2 GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(MG2\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG2\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG2\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG2 final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG2 GORE John", "MG2 GORE Gore-John",
				"MG2 GORE Gore John", "MG2 GORE-JOHN Gore-John",
				"MG2 GORE-JOHN Gorejohn", "MG2 GORE-JOHN Gore John",
				"MG2 GORE JOHN Gore-John", "MG2 GORE JOHN Gorejohn",
				"MG2 GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG2==nope");
			} else {
				System.out.println("MG2==yes");
			}
		}
	}

	@Test
	public void testMG3RegEx() {
		/**
		 * MG3 Defendant SURNAME (in capitals) First Name Example: MG3 GORE John
		 * MG3 GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(MG3\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG3\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG3\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG3 final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG3 GORE John", "MG3 GORE Gore-John",
				"MG3 GORE Gore John", "MG3 GORE-JOHN Gore-John",
				"MG3 GORE-JOHN Gorejohn", "MG3 GORE-JOHN Gore John",
				"MG3 GORE JOHN Gore-John", "MG3 GORE JOHN Gorejohn",
				"MG3 GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG3==nope");
			} else {
				System.out.println("MG3==yes");
			}
		}
	}

	@Test
	public void testMG4RegEx() {
		/**
		 * MG4 Defendant SURNAME (in capitals) First Name Example: MG4 GORE John
		 * MG4 GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(MG4\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG4\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG4\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG4 final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG4 GORE John", "MG4 GORE Gore-John",
				"MG4 GORE Gore John", "MG4 GORE-JOHN Gore-John",
				"MG4 GORE-JOHN Gorejohn", "MG4 GORE-JOHN Gore John",
				"MG4 GORE JOHN Gore-John", "MG4 GORE JOHN Gore John",
				"MG4 GORE JOHN Gorejohn" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG4==nope");
			} else {
				System.out.println("MG4==yes");
			}
		}
	}

	@Test
	public void testMG4ARegEx() {
		/**
		 * MG4A Defendant SURNAME (in capitals) First Name Example: MG4A GORE
		 * John MG4A GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(MG4A\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG4A\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG4A\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG4A final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG4A GORE John", "MG4A GORE Gore-John",
				"MG4A GORE Gore John", "MG4A GORE-JOHN Gore-John",
				"MG4A GORE-JOHN Gorejohn", "MG4A GORE-JOHN Gore John",
				"MG4A GORE JOHN Gore-John", "MG4A GORE JOHN Gorejohn",
				"MG4A GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG4A==nope");
			} else {
				System.out.println("MG4A==yes");
			}
		}
	}

	@Test
	public void testMG4BRegEx() {
		/**
		 * MG4B Defendant SURNAME (in capitals) First Name Example: MG4B GORE
		 * John MG4B GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(MG4B\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG4B\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG4B\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG4B final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG4B GORE John", "MG4B GORE Gore-John",
				"MG4B GORE Gore John", "MG4B GORE-JOHN Gore-John",
				"MG4B GORE-JOHN Gorejohn", "MG4B GORE-JOHN Gore John",
				"MG4B GORE JOHN Gore-John", "MG4B GORE JOHN Gorejohn",
				"MG4B GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG4B==nope");
			} else {
				System.out.println("MG4B==yes");
			}
		}
	}

	@Test
	public void testMG4CRegEx() {
		/**
		 * MG4C Defendant SURNAME (in capitals) First Name Example: MG4C GORE
		 * John MG4C GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(MG4C\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG4C\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG4C\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG4C final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG4C GORE John", "MG4C GORE Gore-John",
				"MG4C GORE Gore John", "MG4C GORE-JOHN Gore-John",
				"MG4C GORE-JOHN Gorejohn", "MG4C GORE-JOHN Gore John",
				"MG4C GORE JOHN Gore-John", "MG4C GORE JOHN Gore John",
				"MG4C GORE JOHN Gorejohn" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG4C==nope");
			} else {
				System.out.println("MG4C==yes");
			}
		}
	}

	@Test
	public void testMG4DRegEx() {
		/**
		 * MG4D Defendant SURNAME (in capitals) First Name Example: MG4D GORE
		 * John MG4D GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(MG4D\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG4D\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG4D\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG4D final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG4D GORE John", "MG4D GORE Gore-John",
				"MG4D GORE Gore John", "MG4D GORE-JOHN Gore-John",
				"MG4D GORE-JOHN Gore John", "MG4D GORE-JOHN Gorejohn",
				"MG4D GORE JOHN Gore-John", "MG4D GORE JOHN Gorejohn",
				"MG4D GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG4D==nope");
			} else {
				System.out.println("MG4D==yes");
			}
		}
	}

	@Test
	public void testMG4ERegEx() {
		/**
		 * MG4E Defendant SURNAME (in capitals) First Name Example: MG4E GORE
		 * John MG4E GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(MG4E\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG4E\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG4E\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG4E final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG4E GORE John", "MG4E GORE Gore-John",
				"MG4E GORE Gore John", "MG4E GORE-JOHN Gore-John",
				"MG4E GORE-JOHN Gorejohn", "MG4E GORE-JOHN Gore John",
				"MG4E GORE JOHN Gore-John", "MG4E GORE JOHN Gorejohn",
				"MG4E GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG4E==nope");
			} else {
				System.out.println("MG4E==yes");
			}
		}
	}

	@Test
	public void testMG5RegEx() {
		/**
		 * MG5 Defendant SURNAME (in capitals) First Name Example: MG5 GORE John
		 * MG5 GORE-JOHN Gore-john
		 */

		String regEx1 = "(MG5\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG5\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG5\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG5 final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG5 GORE John", "MG5 GORE Gore-John",
				"MG5 GORE Gore John", "MG5 GORE-JOHN Gore-John",
				"MG5 GORE-JOHN Gorejohn", "MG5 GORE-JOHN Gore John",
				"MG5 GORE JOHN Gore-John", "MG5 GORE JOHN Gorejohn",
				"MG5 GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG5==nope");
			} else {
				System.out.println("MG5==yes");
			}
		}
	}

	@Test
	public void testMG6RegEx() {
		/**
		 * MG6 Defendant SURNAME (in capitals) First Name Example: MG6 GORE John
		 * MG6 GORE-JOHN Gore-john
		 */

		String regEx1 = "(MG6\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG6\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG6\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG6 final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG6 GORE John", "MG6 GORE Gore-John",
				"MG6 GORE Gore John", "MG6 GORE-JOHN Gore-John",
				"MG6 GORE-JOHN Gorejohn", "MG6 GORE-JOHN Gore John",
				"MG6 GORE JOHN Gore-John", "MG6 GORE JOHN Gore John",
				"MG6 GORE JOHN Gorejohn" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG6==nope");
			} else {
				System.out.println("MG6==yes");
			}
		}
	}

	@Test
	public void testMG6ARegEx() {
		/**
		 * MG6A Defendant SURNAME (in capitals) First Name Example: MG6A GORE
		 * John MG6A GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(MG6A\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG6A\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG6A\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG6A final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG6A GORE John", "MG6A GORE Gore-John",
				"MG6A GORE Gore John", "MG6A GORE-JOHN Gore-John",
				"MG6A GORE-JOHN Gorejohn", "MG6A GORE-JOHN Gore John",
				"MG6A GORE JOHN Gore-John", "MG6A GORE JOHN Gorejohn",
				"MG6A GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG6A==nope");
			} else {
				System.out.println("MG6A==yes");
			}
		}
	}

	@Test
	public void testMG6BRegEx() {
		/**
		 * MG6B Defendant SURNAME (in capitals) First Name Example: MG6B GORE
		 * John MG6B GORE-JOHN Gore-john
		 * 
		 */

		String regEx1 = "(MG6B\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG6B\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s])[A-Z]{1}[a-z]{1,}";
		String regEx2 = "(MG6B\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG6B final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG6B GORE John", "MG6B GORE Gore-John",
				"MG6B GORE Gore John", "MG6B GORE-JOHN Gore-John",
				"MG6B GORE-JOHN Gore John", "MG6B GORE-JOHN Gorejohn",
				"MG6B GORE JOHN Gore-John", "MG6B GORE JOHN Gorejohn",
				"MG6B GORE JOHN Gore John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG6B==nope");
			} else {
				System.out.println("MG6B==yes");
			}
		}
	}

	@Test
	public void testMG6CRegEx() {

		/**
		 * Example: MG6C GORE John document 1 of 3 MG6C GORE John page 1 of 3
		 * 
		 * If sending updated schedules add the word �updated� and the date
		 * 
		 * Example: MC6C GORE John updated DD.MM.YY Example: MG6C GORE John
		 * updated DD.MM.YY document 1 of 3 Example: MG6C GORE John updated
		 * DD.MM.YY page 1 of 3
		 */

		String regEx1 = "(MG6C\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG6C\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG6C\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx3 = "(MG6C\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";
		String regEx4 = "(MG6C\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx5 = "(MG6C\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String regEx6 = "(MG6C\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx7 = "(MG6C\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";
		String regEx8 = "(MG6C\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";

		String finalRegEx = regEx1 + "|" + regEx2 + "|" + regEx3 + "|" + regEx4
				+ "|" + regEx5 + "|" + regEx6 + "|" + regEx7 + "|" + regEx8;
		System.out.println("MG6C Final RegEx =" + finalRegEx);
		String[] test = { "MG6C GORE John", "MG6C GORE Gore-John",
				"MG6C GORE Gore John", "MG6C GORE John document 1 of 3",
				"MG6C GORE John page 1 of 3", "MG6C GORE-JOHN Gore-John",
				"MG6C GORE-JOHN Gorejohn", "MG6C GORE-JOHN Gore John",
				"MG6C GORE JOHN Gore John", "MG6C GORE JOHN Gore-John",
				"MG6C GORE JOHN Gorejohn", "MG6C GORE John updated 10.11.14",
				"MG6C GORE-JOHN Gore-John updated 10.11.14",
				"MG6C GORE-JOHN Gore John updated 10.11.14",
				"MG6C GORE-JOHN Gorejohn updated 10.11.14",
				"MG6C GORE JOHN Gore John updated 10.11.14",
				"MG6C GORE JOHN Gore-John updated 10.11.14",
				"MG6C GORE JOHN Gore-John updated 10.11.14",
				"MG6C GORE John updated 10.11.14 page 1 of 3",
				"MG6C GORE-JOHN Gore-John updated 10.11.14 page 1 of 3",
				"MG6C GORE-JOHN Gore John updated 10.11.14 page 1 of 3",
				"MG6C GORE-JOHN Gorejohn updated 10.11.14 page 1 of 3",
				"MG6C GORE JOHN Gore John updated 10.11.14 page 1 of 3",
				"MG6C GORE JOHN Gore-John updated 10.11.14 page 1 of 3",
				"MG6C GORE JOHN Gorejohn updated 10.11.14 page 1 of 3",
				"MG6C GORE John updated 10.11.14 document 1 of 3",
				"MG6C GORE-JOHN Gore-John updated 10.11.14 document 1 of 3",
				"MG6C GORE-JOHN Gore John updated 10.11.14 document 1 of 3",
				"MG6C GORE-JOHN Gorejohn updated 10.11.14 document 1 of 3",
				"MG6C GORE JOHN Gore John updated 10.11.14 document 1 of 3",
				"MG6C GORE JOHN Gore-John updated 10.11.14 document 1 of 3",
				"MG6C GORE JOHN Gorejohn updated 10.11.14 document 1 of 3" };
		Pattern pattern = compile(finalRegEx);
		for (String s : test) {
			Matcher matcher = pattern.matcher(s.trim());
			if (!matcher.matches()) {
				System.out.println("MG6C==nope");
			} else {
				System.out.println("MG6C==yes");
			}
		}
	}

	@Test
	public void testMG6DRegEx() {
		// Example: MG6D GORE John Nil Return

		String regEx1 = "(MG6D\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\sNil Return)|(MG6D\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,}\\sNil Return)";
		String regEx2 = "(MG6D\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\sNil Return)";

		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG6D final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);

		String names[] = { "MG6D GORE John Nil Return",
				"MG6D GORE Gore-John Nil Return",
				"MG6D GORE Gore John Nil Return",
				"MG6D GORE-JOHN Gore-John Nil Return",
				"MG6D GORE-JOHN Gore John Nil Return",
				"MG6D GORE-JOHN Gorejohn Nil Return",
				"MG6D GORE JOHN Gore John Nil Return",
				"MG6D GORE JOHN Gore-John Nil Return",
				"MG6D GORE JOHN Gorejohn Nil Return" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG6D==nope");
			} else {
				System.out.println("MG6D==yes");
			}
		}
	}

	@Test
	public void testMG6ERegEx() {
		/**
		 * MG6E Defendant SURNAME (in capitals) First Name Example: MG6E GORE
		 * John
		 * 
		 * If sending updated versions add the word updated and the date
		 * Example: MG6E GORE John updated DD.MM.YY
		 */

		String regEx1 = "(MG6E\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG6E\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG6E\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";
		String regEx3 = "(MG6E\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";
		String regEx4 = "(MG6E\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";

		String finalRegEx = regEx1 + "|" + regEx2 + "|" + regEx3 + "|" + regEx4;
		System.out.println("MG6E final RegEx=" + finalRegEx);

		String[] test = { "MG6E GORE John", "MG6E GORE Gore-John",
				"MG6E GORE Gore John", "MG6E GORE John updated 10.11.14",
				"MG6E GORE-JOHN Gore-John updated 10.11.14",
				"MG6E GORE-JOHN Gore John updated 10.11.14",
				"MG6E GORE-JOHN Gorejohn updated 10.11.14",
				"MG6E GORE JOHN Gore John updated 10.11.14",
				"MG6E GORE JOHN Gore-John updated 10.11.14",
				"MG6E GORE JOHN Gorejohn updated 10.11.14",
				"MG6E GORE-JOHN Gore-John", "MG6E GORE-JOHN Gore John",
				"MG6E GORE-JOHN Gorejohn", "MG6E GORE JOHN Gore John",
				"MG6E GORE JOHN Gore-John", "MG6E GORE JOHN Gorejohn" };

		Pattern pattern = compile(finalRegEx);
		for (String s : test) {
			Matcher matcher = pattern.matcher(s.trim());
			if (!matcher.matches()) {
				System.out.println("MG6E==nope");
			} else {
				System.out.println("MG6E==yes");
			}
		}
	}

	@Test
	public void testMG7RegEx() {
		/**
		 * Example: MG7 GORE John MG7 SMITH-JONES Toni-john
		 */

		String regEx1 = "(MG7\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG7\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG7\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";

		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG7 Final REGEX=" + finalRegEx);

		String names[] = { "MG7 GORE John", "MG7 GORE Gore-John",
				"MG7 GORE Gore John", "MG7 SMITH-JONESS Toni-John",
				"MG7 SMITH-JONESS Toni John", "MG7 SMITH-JONESS Tonijohn",
				"MG7 SMITH JONESS Toni John", "MG7 SMITH JONESS Toni-John",
				"MG7 SMITH JONESS Tonijohn" };
		Pattern pattern = compile(finalRegEx);
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG7==nope");
			} else {
				System.out.println("MG7==yes");
			}
		}
	}

	@Test
	public void testMG8RegEx() {
		/**
		 * Example: MG8 GORE John MG8 SMITH-JONESS Toni-john
		 */

		String regEx1 = "(MG8\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG8\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG8\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";

		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG8 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);

		String names[] = { "MG8 GORE John", "MG8 GORE Gore-John",
				"MG8 GORE Gore John", "MG8 SMITH-JONESS Toni-John",
				"MG8 SMITH-JONESS Toni John", "MG8 SMITH-JONESS Tonijohn",
				"MG8 SMITH JONESS Toni-John", "MG8 SMITH JONESS Toni John",
				"MG8 SMITH-JONESS Tonijohn" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG8==nope");
			} else {
				System.out.println("MG8==yes");
			}
		}
	}

	@Test
	public void testMG9RegEx() {
		/**
		 * MG9 Defendant SURNAME (in capitals) First Name Example: MG9 GORE John
		 * MG9 SMITH-JONESS Toni-john
		 * 
		 * If sending one document there is no need to number this
		 * 
		 * If sending multiple documents or separate individual pages add
		 * �document 1 of 3� OR �page 1 of 3� as appropriate If sending updated
		 * versions add the word updated and the date
		 * 
		 * See MG6C for examples
		 * 
		 * Example: MG9 GORE John document 1 of 3 Example: MG9 GORE John page 1
		 * of 3
		 * 
		 * If sending updated schedules add the word �updated� and the date
		 * 
		 * Example: MG9 GORE John updated DD.MM.YY Example: MG9 GORE John
		 * updated DD.MM.YY document 1 of 3 Example: MG9 GORE John updated
		 * DD.MM.YY page 1 of 3
		 */
		String regEx1 = "(MG9\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG9\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG9\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx3 = "(MG9\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";
		String regEx4 = "(MG9\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx5 = "(MG9\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String regEx6 = "(MG9\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx7 = "(MG9\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";
		String regEx8 = "(MG9\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";

		String finalRegEx = regEx1 + "|" + regEx2 + "|" + regEx3 + "|" + regEx4
				+ "|" + regEx5 + "|" + regEx6 + "|" + regEx7 + "|" + regEx8;
		System.out.println("MG9 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);

		String[] names = { "MG9 GORE John", "MG9 GORE Gore-John",
				"MG9 GORE Gore John", "MG9 SMITH-JONESS Toni-John",
				"MG9 SMITH-JONESS Toni John", "MG9 SMITH-JONESS Tonijohn",
				"MG9 SMITH JONESS Toni-John", "MG9 SMITH JONESS Toni John",
				"MG9 SMITH JONESS Tonijohn", "MG9 GORE John document 1 of 3",
				"MG9 SMITH-JONESS Toni-John document 1 of 3",
				"MG9 SMITH-JONESS Toni John document 1 of 3",
				"MG9 SMITH-JONESS Tonijohn document 1 of 3",
				"MG9 SMITH JONESS Toni John document 1 of 3",
				"MG9 SMITH JONESS Toni-John document 1 of 3",
				"MG9 SMITH JONESS Tonijohn document 1 of 3",
				"MG9 GORE John page 1 of 3",
				"MG9 SMITH-JONESS Toni-John page 1 of 3",
				"MG9 SMITH-JONESS Toni John page 1 of 3",
				"MG9 SMITH-JONESS Tonijohn page 1 of 3",
				"MG9 SMITH JONESS Toni-John page 1 of 3",
				"MG9 SMITH JONESS Toni John page 1 of 3",
				"MG9 SMITH JONESS Tonijohn page 1 of 3",
				"MG9 GORE John updated 10.11.14",
				"MG9 GORE-JOHN Gore-John updated 10.11.14",
				"MG9 GORE-JOHN Gore John updated 10.11.14",
				"MG9 GORE-JOHN Gorejohn updated 10.11.14",
				"MG9 GORE JOHN Gore-John updated 10.11.14",
				"MG9 GORE JOHN Gore John updated 10.11.14",
				"MG9 GORE JOHN Gorejohn updated 10.11.14",
				"MG9 GORE John updated 10.11.14 page 1 of 3",
				"MG9 GORE-JOHN Gore-John updated 10.11.14 page 1 of 3",
				"MG9 GORE-JOHN Gore John updated 10.11.14 page 1 of 3",
				"MG9 GORE-JOHN Gorejohn updated 10.11.14 page 1 of 3",
				"MG9 GORE JOHN Gore John updated 10.11.14 page 1 of 3",
				"MG9 GORE JOHN Gore-John updated 10.11.14 page 1 of 3",
				"MG9 GORE JOHN Gorejohn updated 10.11.14 page 1 of 3",
				"MG9 GORE John updated 10.11.14 document 1 of 3",
				"MG9 GORE-JOHN Gore-John updated 10.11.14 document 1 of 3",
				"MG9 GORE-JOHN Gore John updated 10.11.14 document 1 of 3",
				"MG9 GORE-JOHN Gorejohn updated 10.11.14 document 1 of 3",
				"MG9 GORE JOHN Gore-John updated 10.11.14 document 1 of 3",
				"MG9 GORE JOHN Gore John updated 10.11.14 document 1 of 3",
				"MG9 GORE JOHN Gorejohn updated 10.11.14 document 1 of 3" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG9==nope");
			} else {
				System.out.println("MG9==yes");
			}
		}
	}

	@Test
	public void testMG10RegEx() {
		/**
		 * MG10 Defendant SURNAME (in capitals) First Name Example: MG10 GORE
		 * John MG10 SMITH-JONESS Toni-john
		 * 
		 * 
		 * If sending one document there is no need to number this
		 * 
		 * If sending multiple documents or separate individual pages add
		 * �document 1 of 3� OR �page 1 of 3� as appropriate If sending updated
		 * versions add the word updated and the date
		 * 
		 * See MG6C for examples
		 * 
		 * Example: MG10 GORE John document 1 of 3 Example: MG10 GORE John page
		 * 1 of 3
		 * 
		 * If sending updated schedules add the word �updated� and the date
		 * 
		 * Example: MG10 GORE John updated DD.MM.YY Example: MG10 GORE John
		 * updated DD.MM.YY document 1 of 3 Example: MG10 GORE John updated
		 * DD.MM.YY page 1 of 3
		 */

		String regEx1 = "(MG10\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG10\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG10\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx3 = "(MG10\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";
		String regEx4 = "(MG10\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx5 = "(MG10\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String regEx6 = "(MG10\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx7 = "(MG10\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";
		String regEx8 = "(MG10\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";

		String finalRegEx = regEx1 + "|" + regEx2 + "|" + regEx3 + "|" + regEx4
				+ "|" + regEx5 + "|" + regEx6 + "|" + regEx7 + "|" + regEx8;
		System.out.println("MG10 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);

		String[] names = { "MG10 GORE John", "MG10 GORE Gore-John",
				"MG10 GORE Gore John", "MG10 SMITH-JONESS Toni-John",
				"MG10 SMITH-JONESS Tonijohn", "MG10 SMITH-JONESS Toni John",
				"MG10 SMITH JONESS Toni-John", "MG10 SMITH JONESS Toni John",
				"MG10 SMITH JONESS Tonijohn", "MG10 GORE John document 1 of 3",
				"MG10 SMITH-JONESS Toni-John document 1 of 3",
				"MG10 SMITH-JONESS Toni John document 1 of 3",
				"MG10 SMITH-JONESS Tonijohn document 1 of 3",
				"MG10 SMITH JONESS Toni-John document 1 of 3",
				"MG10 SMITH JONESS Tonijohn document 1 of 3",
				"MG10 SMITH JONESS Toni John document 1 of 3",
				"MG10 GORE John page 1 of 3",
				"MG10 GORE-JOHN Gore-John page 1 of 3",
				"MG10 GORE-JOHN Gore John page 1 of 3",
				"MG10 GORE-JOHN Gorejohn page 1 of 3",
				"MG10 GORE JOHN Gore John page 1 of 3",
				"MG10 GORE JOHN Gore-John page 1 of 3",
				"MG10 GORE JOHN Gorejohn page 1 of 3",
				"MG10 GORE John updated 10.11.14",
				"MG10 GORE-JOHN Gore-John updated 10.11.14",
				"MG10 GORE-JOHN Gore John updated 10.11.14",
				"MG10 GORE-JOHN Gorejohn updated 10.11.14",
				"MG10 GORE JOHN Gore-John updated 10.11.14",
				"MG10 GORE JOHN Gore John updated 10.11.14",
				"MG10 GORE JOHN Gorejohn updated 10.11.14",
				"MG10 GORE John updated 10.11.14 page 1 of 3",
				"MG10 GORE-JOHN Gore-John updated 10.11.14 page 1 of 3",
				"MG10 GORE-JOHN Gore John updated 10.11.14 page 1 of 3",
				"MG10 GORE-JOHN Gorejohn updated 10.11.14 page 1 of 3",
				"MG10 GORE JOHN Gore-John updated 10.11.14 page 1 of 3",
				"MG10 GORE JOHN Gore John updated 10.11.14 page 1 of 3",
				"MG10 GORE JOHN Gorejohn updated 10.11.14 page 1 of 3",
				"MG10 GORE John updated 10.11.14 document 1 of 3",
				"MG10 GORE-JOHN Gore-John updated 10.11.14 document 1 of 3",
				"MG10 GORE-JOHN Gore John updated 10.11.14 document 1 of 3",
				"MG10 GORE-JOHN Gorejohn updated 10.11.14 document 1 of 3",
				"MG10 GORE JOHN Gore-John updated 10.11.14 document 1 of 3",
				"MG10 GORE JOHN Gore John updated 10.11.14 document 1 of 3",
				"MG10 GORE JOHN Gorejohn updated 10.11.14 document 1 of 3" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG10==nope");
			} else {
				System.out.println("MG10==yes");
			}
		}
	}

	@Test
	public void testMG11Part1RegEx() {
		/**
		 * MG11 Witness SURNAME (in capitals) First name Statement number
		 * Example: MG11 SPENCER Julie
		 * 
		 * When a witness has made multiple statements add a number Example:
		 * MG11 SPENCER Julie 1 Example: MG11 SPENCER Julie 2 Example: MG11
		 * SPENCER Julie 3
		 * 
		 * Note: When a hand written MG11 has been obtained and a copy
		 * subsequently typed it is the typed copy that must be submitted. The
		 * SFD CPS also require that the name and date be typed in the signature
		 * sections. There is no need to scan and send the handwritten original
		 * unless it is contested.
		 */

		String regEx1 = "(MG11\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG11\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG11\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\s[1-9])";
		String regEx3 = "(MG11\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String regEx4 = "(MG11\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\s[1-9])";
		String regEx5 = "(MG11\\s[A-Z]{1,}\\s[A-Z]{1,}\\s[0-9]{1,})";

		String finalRegEx = regEx1 + "|" + regEx2 + "|" + regEx3 + "|" + regEx4+ "|" + regEx5;
		System.out.println("MG11 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);

		String[] names = { 
				"MG11 SPENCER Julie", 
				"MG11 SPENCER Spencer-Julie",
				"MG11 SPENCER Spencer Julie", 
				"MG11 SMITH-JONESS Toni-John",
				"MG11 SMITH-JONESS Toni John", 
				"MG11 SMITH-JONESS Tonijohn",
				"MG11 SMITH JONESS Toni-John", 
				"MG11 SMITH JONESS Toni John",
				"MG11 SMITH JONESS Tonijohn", 
				"MG11 SPENCER Julie 1",
				"MG11 SMITH-JONESS Toni-John 1",
				"MG11 SMITH-JONESS Toni John 1",
				"MG11 SMITH-JONESS Tonijohn 1",
				"MG11 SMITH JONESS Toni John 1",
				"MG11 SMITH JONESS Toni-John 1", 
				"MG11 SMITH JONESS Tonijohn 1",
				"MG11 SPENCER PC 12121212",
				"MG11 SPENCER PC 13170"};
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG11==nope");
			} else {
				System.out.println("MG11==yes");
			}
		}
	}

	@Test
	public void testMG11Part2RegEx() {
		/**
		 * MG11 part 2 Witness SURNAME (in capitals) First name
		 */

		String regEx1 = "(MG11\\spart 2\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG11\\spart 2\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG11\\spart 2\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\s[1-9])";
		String regEx3 = "(MG11\\spart 2\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String regEx4 = "(MG11\\spart 2\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\s[1-9])";

		String finalRegEx = regEx1 + "|" + regEx2 + "|" + regEx3 + "|" + regEx4;
		System.out.println("MG11 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);

		String[] names = { "MG11 part 2 SPENCER Julie",
				"MG11 part 2 SPENCER Spencer-Julie",
				"MG11 part 2 SPENCER Spencer Julie",
				"MG11 part 2 SMITH-JONESS Toni-John",
				"MG11 part 2 SMITH-JONESS Toni John",
				"MG11 part 2 SMITH-JONESS Tonijohn",
				"MG11 part 2 SMITH JONESS Toni-John",
				"MG11 part 2 SMITH JONESS Toni John",
				"MG11 part 2 SMITH JONESS Tonijohn",
				"MG11 part 2 SPENCER Julie 1",
				"MG11 part 2 SMITH-JONESS Toni-John 1",
				"MG11 part 2 SMITH-JONESS Toni John 1",
				"MG11 part 2 SMITH-JONESS Tonijohn 1",
				"MG11 part 2 SMITH JONESS Toni John 1",
				"MG11 part 2 SMITH JONESS Toni-John 1",
				"MG11 part 2 SMITH JONESS Tonijohn 1" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG11==nope");
			} else {
				System.out.println("MG11==yes");
			}
		}
	}

	@Test
	public void testMG12RegEx() {
		/**
		 * MG12 Defendant SURNAME (in capitals) First Name Example: MG12 GORE
		 * John MG12 SMITH-JONESS Toni-john
		 * 
		 * If sending one page there is no need to number this
		 * 
		 * If sending one document there is no need to number this
		 * 
		 * If sending multiple documents or separate individual pages add
		 * �document 1 of 3� OR �page 1 of 3� as appropriate
		 * 
		 * If sending updated versions add the word updated and the date
		 * 
		 * See MG6C for examples
		 */

		String regEx1 = "(MG12\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG12\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG12\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx3 = "(MG12\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";
		String regEx4 = "(MG12\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx5 = "(MG12\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String regEx6 = "(MG12\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";
		String regEx7 = "(MG12\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";
		String regEx8 = "(MG12\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\supdated\\s(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d\\s(document|page)\\s[1-9]{1,2}\\sof\\s[1-9]{1,2})";

		String finalRegEx = regEx1 + "|" + regEx2 + "|" + regEx3 + "|" + regEx4
				+ "|" + regEx5 + "|" + regEx6 + "|" + regEx7 + "|" + regEx8;
		System.out.println("MG12 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);

		String[] names = { "MG12 GORE John", "MG12 GORE Gore-John",
				"MG12 GORE Gore John", "MG12 SMITH-JONESS Toni-John",
				"MG12 SMITH-JONESS Toni-John", "MG12 SMITH-JONESS Toni John",
				"MG12 SMITH-JONESS Tonijohn", "MG12 SMITH JONESS Toni-John",
				"MG12 SMITH JONESS Toni John", "MG12 SMITH JONESS Tonijohn",
				"MG12 GORE John document 1 of 3",
				"MG12 SMITH-JONESS Toni-John document 1 of 3",
				"MG12 SMITH-JONESS Toni John document 1 of 3",
				"MG12 SMITH-JONESS Tonijohn document 1 of 3",
				"MG12 SMITH JONESS Toni John document 1 of 3",
				"MG12 SMITH JONESS Toni-John document 1 of 3",
				"MG12 SMITH JONESS Tonijohn document 1 of 3",
				"MG12 GORE John page 1 of 3",
				"MG12 GORE-JOHN Gore-John page 1 of 3",
				"MG12 GORE-JOHN Gore John page 1 of 3",
				"MG12 GORE-JOHN Gorejohn page 1 of 3",
				"MG12 GORE JOHN Gore John page 1 of 3",
				"MG12 GORE JOHN Gore-John page 1 of 3",
				"MG12 GORE JOHN Gorejohn page 1 of 3",
				"MG12 GORE John updated 10.11.14",
				"MG12 GORE-JOHN Gore-John updated 10.11.14",
				"MG12 GORE-JOHN Gore John updated 10.11.14",
				"MG12 GORE-JOHN Gorejohn updated 10.11.14",
				"MG12 GORE JOHN Gore John updated 10.11.14",
				"MG12 GORE JOHN Gore-John updated 10.11.14",
				"MG12 GORE JOHN Gorejohn updated 10.11.14",
				"MG12 GORE John updated 10.11.14 page 1 of 3",
				"MG12 GORE-JOHN Gore-John updated 10.11.14 page 1 of 3",
				"MG12 GORE-JOHN Gore John updated 10.11.14 page 1 of 3",
				"MG12 GORE-JOHN Gorejohn updated 10.11.14 page 1 of 3",
				"MG12 GORE JOHN Gore-John updated 10.11.14 page 1 of 3",
				"MG12 GORE JOHN Gore John updated 10.11.14 page 1 of 3",
				"MG12 GORE JOHN Gorejohn updated 10.11.14 page 1 of 3",
				"MG12 GORE John updated 10.11.14 document 1 of 3",
				"MG12 GORE-JOHN Gore-John updated 10.11.14 document 1 of 3",
				"MG12 GORE-JOHN Gore John updated 10.11.14 document 1 of 3",
				"MG12 GORE-JOHN Gorejohn updated 10.11.14 document 1 of 3",
				"MG12 GORE JOHN Gore-John updated 10.11.14 document 1 of 3",
				"MG12 GORE JOHN Gore John updated 10.11.14 document 1 of 3",
				"MG12 GORE JOHN Gorejohn updated 10.11.14 document 1 of 3" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG12==nope");
			} else {
				System.out.println("MG12==yes");
			}
		}
	}

	@Test
	public void testMG14RegEx() {
		/**
		 * Example: MG14 GORE John MG14 SMITH-JONESS Toni-john
		 */

		String regEx1 = "(MG14\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG14\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG14\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";

		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG14 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);

		String[] names = { "MG14 GORE John", "MG14 GORE Gore-John",
				"MG14 GORE Gore John", "MG14 SMITH-JONESS Toni-John",
				"MG14 SMITH-JONESS Toni John", "MG14 SMITH-JONESS Tonijohn",
				"MG14 SMITH JONESS Toni John", "MG14 SMITH JONESS Toni-John",
				"MG14 SMITH JONESS Tonijohn" };

		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG14==nope");
			} else {
				System.out.println("MG14==yes");
			}
		}
	}

	@Test
	public void testMG15RegEx() {
		/**
		 * MG15 Defendant SURNAME (in capitals) First Name Example: MG15 GORE
		 * John
		 * 
		 * If multiple interviews have taken place add the word �int� and a
		 * number Example: MG15 GORE John int 2
		 * 
		 * When there are multiple subjects use the surname of the individual
		 * interviewed Example: MG15 SMITH J
		 */

		String regEx1 = "(MG15\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG15\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG15\\s[A-Z]{1,}\\s[A-Z]{1})";
		String regEx3 = "(MG15\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\sint\\s[1-9])";
		String regEx4 = "(MG15\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String regEx5 = "(MG15\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\sint\\s[1-9])";

		String finalRegEx = regEx1 + "|" + regEx2 + "|" + regEx3 + "|" + regEx4
				+ "|" + regEx5;
		System.out.println("MG15 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);

		String[] names = { "MG15 GORE John", "MG15 GORE Gore-John",
				"MG15 GORE Gore John", "MG15 GORE John int 2",
				"MG15 GORE-JOHN Gore-John int 2",
				"MG15 GORE-JOHN Gore John int 2",
				"MG15 GORE-JOHN Gorejohn int 2",
				"MG15 GORE JOHN Gore-John int 2",
				"MG15 GORE JOHN Gore John int 2",
				"MG15 GORE JOHN Gorejohn int 2", "MG15 SMITH-JONESS Toni-John",
				"MG15 SMITH-JONESS Toni John", "MG15 SMITH-JONESS Tonijohn",
				"MG15 SMITH JONESS Toni-John", "MG15 SMITH JONESS Toni John",
				"MG15 SMITH JONESS Tonijohn", "MG15 GORE J" };
		for (String name : names) {
			final Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG15==nope");
			} else {
				System.out.println("MG15==yes");
			}
		}
	}

	@Test
	public void testMG16RegEx() {
		/**
		 * MG16 Defendant SURNAME (in capitals) First Name Example: MG16 GORE
		 * John
		 */

		String regEx1 = "(MG16\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG16\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG16\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";

		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG16 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG16 GORE John", "MG16 GORE Gore-John",
				"MG16 GORE Gore John", "MG16 SMITH-JONESS Toni-John",
				"MG16 SMITH-JONESS Toni John", "MG16 SMITH-JONESS Tonijohn",
				"MG16 SMITH JONESS Toni John", "MG16 SMITH JONESS Toni-John",
				"MG16 SMITH JONESS Tonijohn" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG16==nope");
			} else {
				System.out.println("MG16==yes");
			}
		}
	}

	@Test
	public void testMG17RegEx() {
		/**
		 * MG17 Defendant SURNAME (in capitals) First Name Example: MG17 GORE
		 * John MG17 SMITH-JONESS Toni-john
		 */

		String regEx1 = "(MG17\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG17\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG17\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";

		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG17 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);

		String names[] = { "MG17 GORE John", "MG17 GORE Gore-John",
				"MG17 GORE Gore John", "MG17 SMITH-JONESS Toni-John",
				"MG17 SMITH-JONESS Toni John", "MG17 SMITH-JONESS Tonijohn",
				"MG17 SMITH JONESS Toni-John", "MG17 SMITH JONESS Toni John",
				"MG17 SMITH JONESS Tonijohn" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG17==nope");
			} else {
				System.out.println("MG17==yes");
			}
		}
	}

	@Test
	public void testMG18RegEx() {
		/**
		 * MG18 Defendant SURNAME (in capitals) First Name Example: MG18 GORE
		 * John MG18 SMITH-JONESS Toni-john
		 */

		String regEx1 = "(MG18\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG18\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG18\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";

		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG18 Final RegEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String names[] = { "MG18 GORE John", "MG18 GORE Gore-John",
				"MG18 GORE Gore John", "MG18 SMITH-JONESS Toni-John",
				"MG18 SMITH-JONESS Tonijohn", "MG18 SMITH-JONESS Toni John",
				"MG18 SMITH JONESS Toni-John", "MG18 SMITH JONESS Tonijohn",
				"MG18 SMITH JONESS Toni John" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG18==nope");
			} else {
				System.out.println("MG18==yes");
			}
		}
	}

	@Test
	public void testMG19RegEx() {
		/**
		 * MG19 Defendant SURNAME (in capitals) First Name Example: MG19 GORE
		 * John MG19 SMITH-JONESS Toni-john
		 */

		String regEx1 = "(MG19\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG19\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG19\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";

		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG19 Final RegEx=" + finalRegEx);
		String names[] = { "MG19 GORE John", "MG19 GORE Gore-John",
				"MG19 GORE Gore John", "MG19 SMITH-JONESS Toni-John",
				"MG19 SMITH-JONESS Tonijohn", "MG19 SMITH-JONESS Toni John",
				"MG19 SMITH JONESS Toni-John", "MG19 SMITH JONESS Tonijohn",
				"MG19 SMITH JONESS Toni John" };
		Pattern pattern = compile(finalRegEx);
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG19==nope");
			} else {
				System.out.println("MG19==yes");
			}
		}
	}

	@Test
	public void testMG20RegEx() {
		/**
		 * MG20 Defendant SURNAME (in capitals) First Name Example: MG20 GORE
		 * John MG20 SMITH-JONESS Toni-john
		 */

		String regEx1 = "(MG20\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG20\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG20\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";

		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG20 Final RegEx=" + finalRegEx);
		String names[] = { "MG20 GORE John", "MG20 GORE Gore-John",
				"MG20 GORE Gore John", "MG20 SMITH-JONESS Toni-John",
				"MG20 SMITH-JONESS Toni John", "MG20 SMITH-JONESS Tonijohn",
				"MG20 SMITH JONESS Toni-John", "MG20 SMITH JONESS Toni John",
				"MG20 SMITH JONESS Tonijohn" };
		Pattern pattern = compile(finalRegEx);
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG20==nope");
			} else {
				System.out.println("MG20==yes");
			}
		}
	}

	@Test
	public void testMG21RegEx() {
		/**
		 * MG21 Defendant SURNAME (in capitals) First Name Example: MG21 GORE
		 * John MG21 SMITH-JONESS Toni-john
		 */

		String regEx1 = "(MG21\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG21\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG21\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";

		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG21 Final RegEx=" + finalRegEx);
		String names[] = { "MG21 GORE John", "MG21 GORE Gore-John",
				"MG21 GORE Gore John", "MG21 SMITH-JONESS Toni-John",
				"MG21 SMITH-JONESS Toni John", "MG21 SMITH-JONESS Tonijohn",
				"MG21 SMITH JONESS Toni-John", "MG21 SMITH JONESS Toni John",
				"MG21 SMITH JONESS Tonijohn" };
		Pattern pattern = compile(finalRegEx);
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG21==nope");
			} else {
				System.out.println("MG21==yes");
			}
		}
	}

	@Test
	public void testMG21ARegEx() {
		/**
		 * MG21A Defendant SURNAME (in capitals) First Name Example: MG21A GORE
		 * John MG21A SMITH-JONESS Toni-john
		 */

		String regEx1 = "(MG21A\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(MG21A\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,})";
		String regEx2 = "(MG21A\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,})))";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("MG21A Final RegEx=" + finalRegEx);
		String names[] = { "MG21A GORE John", "MG21A GORE Gore-John",
				"MG21A GORE Gore John", "MG21A SMITH-JONESS Toni-John",
				"MG21A SMITH-JONESS Toni John", "MG21A SMITH-JONESS Tonijohn",
				"MG21A SMITH JONESS Toni-John", "MG21A SMITH JONESS Toni John",
				"MG21A SMITH JONESS Tonijohn" };
		Pattern pattern = compile(finalRegEx);
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("MG21A==nope");
			} else {
				System.out.println("MG21A==yes");
			}
		}
	}

	@Test
	public void testExhibitsRegEx() {
		/**
		 * Example: 
		 * Ex. JS1 Timesheets SMITH John Example: 
		 * Ex. JS2 Nowhere hospital timesheet sheet policy document SMITH John 
		 * Ex. AJ1 salary payments DD.MM.YY-DD.MM.YY Example: 
		 * Ex. RH1 SCH.FP17.01 Schedule of DWP check results HUGHES Robert 
		 * Ex. AC2 expenses DD.MM.YY-DD.MM.YY tab1 JJC/40 HR32 HR40 HR43 RWM/2 CL 1 CL 2 Ex. AB
		 * */

		// String documentNamingRules =
		// "(Ex.\\s[A-Za-z]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}\\s\\W*(?:\\w+\\b\\W*){1,6}\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,})|(Ex.\\s[A-Za-z]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s{1}((0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d[\\-](0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d))|(Ex.\\s[A-Za-z]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}\\s([A-Z]{1,3}[\\.][A-Z]{1,3}[0-9]{1,2}[\\.][0-9]{1,2})\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,9}\\s[A-Z]{1}[a-z]{1,9})|(Ex.\\s[A-Za-z]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s{1}((0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d[\\-](0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)\\s[A-Za-z]{1,6}[1-9])";

		/*String regEx1 = "Ex[.]{1}\\s[[A-Za-z0-9]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}[\\.]{0,1}]{1,}\\s{1}(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}";
		
		String regEx2 = "Ex[.]{1}\\s[[A-Za-z0-9]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}[\\.]{0,1}]{1,}\\s{1}(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,}";

		String regEx3 = "Ex[.]{1}\\s[[A-Za-z0-9]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}[\\.]{0,1}]{1,}\\s{1}(\\W*(?:\\w+\\b\\W*){1,6})\\s{1}((0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d[\\-](0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";

		// String regEx3 =
		// "Ex[.]{1}\\s[A-Za-z]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}[\\.]{0,1}([A-Z]{1,}[0-9]{1,}[\\.][A-Z]{1,}[0-9]{1,}[\\.][0-9]{1,})\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}";
		String regEx4 = "Ex[.]{1}\\s[[A-Za-z0-9]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}[\\.]{0,1}]{1,}\\s{1}(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}";

		String regEx5 = "Ex[.]{1}\\s[[A-Za-z0-9]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}[\\.]{0,1}]{1,}\\s{1}(\\W*(?:\\w+\\b\\W*){1,6})\\s{1}((0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d[\\-](0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)\\s[A-Za-z]{1,6}[1-9]";

		String regEx6 = "Ex[.]{1}\\s[[A-Za-z0-9]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}[\\.]{0,1}]{1,}\\s{1}(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))";*/

		String regEx1 = "(Ex[\\.]\\s){1}([A-Z0-9\\.\\/]){1,}([A-Za-z0-9\\.\\/]){1,}\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}";
		
		String regEx2 = "(Ex[\\.]\\s){1}([A-Z0-9\\.\\/]){1,}([A-Za-z0-9\\.\\/]){1,}\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,}";

		String regEx3 = "(Ex[\\.]\\s){1}([A-Z0-9\\.\\/]){1,}([A-Za-z0-9\\.\\/]){1,}\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s{1}((0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d[\\-](0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)";

		// String regEx3 =
		// "Ex[.]{1}\\s[A-Za-z]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9}[\\.]{0,1}([A-Z]{1,}[0-9]{1,}[\\.][A-Z]{1,}[0-9]{1,}[\\.][0-9]{1,})\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}";
		String regEx4 = "(Ex[\\.]\\s){1}([A-Z0-9\\.\\/]){1,}([A-Za-z0-9\\.\\/]){1,}\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}";

		String regEx5 = "(Ex[\\.]\\s){1}([A-Z0-9\\.\\/]){1,}([A-Za-z0-9\\.\\/]){1,}\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s{1}((0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d[\\-](0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d)\\s[A-Za-z]{1,6}[1-9]";

		String regEx6 = "(Ex[\\.]\\s){1}([A-Z0-9\\.\\/]){1,}([A-Za-z0-9\\.\\/]){1,}\\s(\\W*(?:\\w+\\b\\W*){1,6})\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))";
		// String updateRegEx =
		// "(0[1-9]|[12][0-9]|3[01])[\\.](0[1-9]|1[012])[\\.]\\d\\d";

		String finalRegEx = "(" + regEx1 + ")" + "|" + "(" + regEx2 + ")" + "|"
				+ "(" + regEx3 + ")" + "|" + "(" + regEx4 + ")" + "|" + "("
				+ regEx5 + ")" + "|" + "(" + regEx6 + ")";
		System.out.println("Exhibits final RegEx==" + finalRegEx);
		String[] names = {
				"Ex. timesheet time RAJ Katla",
				"Ex. LC/40/41 Timesheets SMITH John",
				"Ex. JJC/40 Timesheets SMITH John",
				"Ex. JJC/40 Timesheets SMITH Smith-John",
				"Ex. JJC/40 Timesheets SMITH Smith John",
				"Ex. JJC/40 Timesheets SMITH-JONES Toni-Jane",
				"Ex. JJC/40 Timesheets SMITH-JONES Tonijane",
				"Ex. JJC/40 Timesheets SMITH-JONES Toni Jane",
				"Ex. JJC/40 Timesheets SMITH JONES Toni-Jane",
				"Ex. JJC/40 Timesheets SMITH JONES Tonijane",
				"Ex. JJC/40 Timesheets SMITH JONES Toni Jane",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH John",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH Smith-John",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH Smith John",
				"Ex. HR3.AB1.CD2.DD salary payments salary payments salary payments 11.12.14-10.01.14",
				"Ex. HR3.AB1.CD2.DD expenses 11.12.14-10.01.14 Tab1",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH John",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH Smith-John",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH Smith John",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH-JONES Toni-Jane",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH-JONES Tonijane",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH-JONES Toni Jane",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH JONES Toni-Jane",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH JONES Tonijane",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH JONES Toni Jane",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH John",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH Smith-John",
				"Ex. HR32 Nowhere hospital timesheet sheet policy document SMITH Smith John",
				"Ex. HR3.AB1.CD2.DD Nowhere hospital timesheet sheet policy document SMITH John",
				"Ex. HR3.AB1.CD2.DD Nowhere hospital timesheet sheet policy document SMITH Smith-John",
				"Ex. HR3.AB1.CD2.DD Nowhere hospital timesheet sheet policy document SMITH Smith John",
				"Ex. HR3.AB1.CD2.DD Nowhere hospital timesheet sheet policy document SMITH-JONES Toni-Jane",
				"Ex. HR3.AB1.CD2.DD Nowhere hospital timesheet sheet policy document SMITH-JONES Tonijane",
				"Ex. HR3.AB1.CD2.DD Nowhere hospital timesheet sheet policy document SMITH-JONES Toni Jane",
				"Ex. HR3.AB1.CD2.DD Nowhere hospital timesheet sheet policy document SMITH JONES Toni-Jane",
				"Ex. HR3.AB1.CD2.DD Nowhere hospital timesheet sheet policy document SMITH JONES Tonijane",
				"Ex. HR3.AB1.CD2.DD Nowhere hospital timesheet sheet policy document SMITH JONES Toni Jane",
				"Ex. HR1axxxa1121121.HasaR3.ABasa1.C1dfasdzdD2.D121dfasfD Nowhere hospital timesheet sheet policy document SMITH John",
				"Ex. HR1axxxa1121121.HasaR3.ABasa1.C1dfasdzdD2.D121dfasfD Nowhere hospital timesheet sheet policy document SMITH Smith-John",
				"Ex. HR1axxxa1121121.HasaR3.ABasa1.C1dfasdzdD2.D121dfasfD Nowhere hospital timesheet sheet policy document SMITH Smith John",
				"Ex. HR1axxxa1121121.HasaR3.ABasa1.C1dfasdzdD2.D121dfasfD Nowhere hospital timesheet sheet policy document SMITH-JONES Toni-Jane",
				"Ex. HR1axxxa1121121.HasaR3.ABasa1.C1dfasdzdD2.D121dfasfD Nowhere hospital timesheet sheet policy document SMITH-JONES Tonijane",
				"Ex. HR1axxxa1121121.HasaR3.ABasa1.C1dfasdzdD2.D121dfasfD Nowhere hospital timesheet sheet policy document SMITH-JONES Toni Jane",
				"Ex. HR1axxxa1121121.HasaR3.ABasa1.C1dfasdzdD2.D121dfasfD Nowhere hospital timesheet sheet policy document SMITH JONES Toni-Jane",
				"Ex. HR1axxxa1121121.HasaR3.ABasa1.C1dfasdzdD2.D121dfasfD Nowhere hospital timesheet sheet policy document SMITH JONES Tonijane",
				"Ex. HR1axxxa1121121.HasaR3.ABasa1.C1dfasdzdD2.D121dfasfD Nowhere hospital timesheet sheet policy document SMITH JONES Toni Jane" };
		Pattern pattern = compile(finalRegEx);
		for (String name : names) {
			Matcher matcher = pattern.matcher(name);
			if (!matcher.matches()) {
				System.out.println("ExhibitsRegEx==nope");
			} else {
				System.out.println("ExhibitsRegEx==yes");
			}
		}
	}

	@Test
	public void testExhibitLabelsRegEx() {
		/**
		 * Example: 
		 * EL1 GORE John Ex. JS1 
		 * EL1 GORE-JOHN Gore-john Ex. CL/2
		 */

		String regEx1 = "(EL1\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}\\sEx[.]{1}\\s[A-Za-z]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9})|(EL1\\s[A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}[\\-\\s][A-Z]{1}[a-z]{1,}\\sEx[.]{1}\\s[A-Za-z]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9})";
		String regEx2 = "(EL1\\s[A-Z]{1,}[\\-\\s][A-Z]{1,}\\s[A-Z]{1}[a-z]{1,}(([\\-\\s])([A-Z]{1}[a-z]{1,})|([a-z]{1,}))\\sEx[.]{1}\\s[A-Za-z]{1,9}\\s{0,1}[\\/]{0,1}[0-9]{1,9})";
		String finalRegEx = regEx1 + "|" + regEx2;
		System.out.println("ExhibitLabels final regEx=" + finalRegEx);
		Pattern pattern = compile(finalRegEx);
		String[] names = { 
				"Ex GORE John Ex. JS1",
				"EL1 GORE John Ex. JJC/40",
				"EL1 GORE Gore-John Ex. JJC/40",
				"EL1 GORE Gore John Ex. JJC/40",
				"EL1 GORE-JOHN Gore-John Ex. CL/2",
				"EL1 GORE-JOHN Gorejohn Ex. CL/2",
				"EL1 GORE-JOHN Gore John Ex. CL/2",
				"EL1 GORE JOHN Gore-John Ex. CL/2",
				"EL1 GORE JOHN Gorejohn Ex. CL/2",
				"EL1 GORE JOHN Gore John Ex. CL/2", "EL1 GORE John Ex. HR32",
				"EL1 GORE Gore-John Ex. HR32", "EL1 GORE Gore John Ex. HR32",
				"EL1 GORE-JOHN Gore-John Ex. HR32",
				"EL1 GORE-JOHN Gorejohn Ex. HR32",
				"EL1 GORE-JOHN Gore John Ex. HR32",
				"EL1 GORE JOHN Gore-John Ex. HR32",
				"EL1 GORE JOHN Gorejohn Ex. HR32",
				"EL1 GORE JOHN Gore John Ex. HR32", "EL1 GORE John Ex. CL/2",
				"EL1 GORE Gore-John Ex. CL/2", "EL1 GORE Gore John Ex. CL/2",
				"EL1 GORE John Ex. CL 1", "EL1 GORE Gore-John Ex. CL 1",
				"EL1 GORE Gore John Ex. CL 1", "EL1 GORE John Ex. AC2",
				"EL1 GORE Gore-John Ex. AC2", "EL1 GORE Gore John Ex. AC2" };
		for (String name : names) {
			Matcher matcher = pattern.matcher(name.trim());
			if (!matcher.matches()) {
				System.out.println("ExhibitLabels==nope");
			} else {
				System.out.println("ExhibitLabels==yes");
			}
		}
	}

}
