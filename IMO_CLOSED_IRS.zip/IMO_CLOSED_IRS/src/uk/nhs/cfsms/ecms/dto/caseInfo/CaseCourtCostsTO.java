package uk.nhs.cfsms.ecms.dto.caseInfo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import uk.nhs.cfsms.ecms.data.cim.ExpectedCourtCost;

public class CaseCourtCostsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 902060969941393455L;

	private Long caseId;
	
	private Date createdDate;

	private List<ExpectedCourtCost> costList;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public List<ExpectedCourtCost> getCostList() {
		return costList;
	}

	public void setCostList(List<ExpectedCourtCost> costList) {
		this.costList = costList;
	}	
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
}
