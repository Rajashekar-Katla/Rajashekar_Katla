package uk.nhs.cfsms.ecms.dto.cps;

import java.io.Serializable;
import java.sql.Timestamp;

public class CPSDocumentsViewDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String cpsReqId;

	private Long caseId;

	private String createdStaffId;

	private Timestamp createdTime;

	private String requesterMessage;

	private String approverStaffId;

	private Timestamp approverResponseTime;

	private String approverMessage;

	private String requestStatus;

	private String submissionType;

	private String documentType;

	private Long documentID;

	private String cpsDocReqId;

	private String createdStaffName;

	private String approverStaffName;

	private String requestedData;

	public String getCpsReqId() {
		return cpsReqId;
	}

	public void setCpsReqId(String cpsReqId) {
		this.cpsReqId = cpsReqId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	public String getRequesterMessage() {
		return requesterMessage;
	}

	public void setRequesterMessage(String requesterMessage) {
		this.requesterMessage = requesterMessage;
	}

	public String getApproverStaffId() {
		return approverStaffId;
	}

	public void setApproverStaffId(String approverStaffId) {
		this.approverStaffId = approverStaffId;
	}

	public Timestamp getApproverResponseTime() {
		return approverResponseTime;
	}

	public void setApproverResponseTime(Timestamp approverResponseTime) {
		this.approverResponseTime = approverResponseTime;
	}

	public String getApproverMessage() {
		return approverMessage;
	}

	public void setApproverMessage(String approverMessage) {
		this.approverMessage = approverMessage;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public Long getDocumentID() {
		return documentID;
	}

	public void setDocumentID(Long documentID) {
		this.documentID = documentID;
	}

	public String getCpsDocReqId() {
		return cpsDocReqId;
	}

	public void setCpsDocReqId(String cpsDocReqId) {
		this.cpsDocReqId = cpsDocReqId;
	}

	public String getCreatedStaffName() {
		return createdStaffName;
	}

	public void setCreatedStaffName(String createdStaffName) {
		this.createdStaffName = createdStaffName;
	}

	public String getApproverStaffName() {
		return approverStaffName;
	}

	public void setApproverStaffName(String approverStaffName) {
		this.approverStaffName = approverStaffName;
	}

	public String getRequestedData() {
		return requestedData;
	}

	public void setRequestedData(String requestedData) {
		this.requestedData = requestedData;
	}

	@Override
	public String toString() {
		return "CPSDocumentsViewDTO [cpsReqId=" + cpsReqId + ", caseId="
				+ caseId + ", createdStaffId=" + createdStaffId
				+ ", createdTime=" + createdTime + ", requesterMessage="
				+ requesterMessage + ", approverStaffId=" + approverStaffId
				+ ", approverResponseTime=" + approverResponseTime
				+ ", approverMessage=" + approverMessage + ", requestStatus="
				+ requestStatus + ", submissionType=" + submissionType
				+ ", documentType=" + documentType + ", documentID="
				+ documentID + ", cpsDocReqId=" + cpsDocReqId
				+ ", createdStaffName=" + createdStaffName
				+ ", approverStaffName=" + approverStaffName
				+ ", requestedData=" + requestedData + "]";
	}
	
	

}
