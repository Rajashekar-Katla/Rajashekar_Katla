package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;


/**
 * SubjectInformationTO is Transfer Object for the Information Subject.
 * 
 * @author schilukuri
 * 
 */

public class SubjectInformationTO  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4410649606172068820L;

	private Long subjectId;

	private Long informationTO;

	private Long caseId;

	private String subjectType;

	private PersonTO subjectPersonTO;

	private String isWitness;
	
	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getInformationTO() {
		return informationTO;
	}

	public void setInformationTO(Long informationTO) {
		this.informationTO = informationTO;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public PersonTO getSubjectPersonTO() {
		return subjectPersonTO;
	}

	public void setSubjectPersonTO(PersonTO subjectPersonTO) {
		if (subjectPersonTO!= null && subjectPersonTO.getPersonDescriptionTO()== null)
		{
			subjectPersonTO.setPersonDescriptionTO(new PersonDescriptionTO());
		}
		this.subjectPersonTO = subjectPersonTO;
	}

	public String getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}

	public String getIsWitness() {
		return isWitness;
	}

	public void setIsWitness(String isWitness) {
		this.isWitness = isWitness;
	}

	@Override
    public boolean equals(Object anObject) {
        if (null == anObject) {
            return false;
        } else if (this == anObject) {
            return true;
        } else if (anObject instanceof SubjectInformationTO) {
            final SubjectInformationTO aSubj = (SubjectInformationTO) anObject;
            Long aSubjId = aSubj.getSubjectId();
            if (null != aSubj) {
                return aSubjId.equals(subjectId);
            }
        }
        return false;
    }
}
