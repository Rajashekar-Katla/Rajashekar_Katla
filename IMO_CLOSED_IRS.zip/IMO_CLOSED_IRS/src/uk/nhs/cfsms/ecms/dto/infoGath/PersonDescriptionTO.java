package uk.nhs.cfsms.ecms.dto.infoGath;

import java.io.Serializable;


public class PersonDescriptionTO  implements Serializable{
	
	private Integer personDescriptionId;

	private String height;

	private String hairColour;

	private String hairStyle;
	
	private String otherHair;	

	private String facialHair;

	private String otherFacialHair;

	private String bodyType;

	private String otherBodyType;

	private String eyeColour;

	private String otherEyeColour;

	private String hairType;

	private String otherHairType;
	
	private String hairDescription;

	private String otherHairDescription;
	
	private String marks;

	private String features;

	private String additionalInformation;

	
	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}

	public String getEyeColour() {
		return eyeColour;
	}

	public void setEyeColour(String eyeColour) {
		this.eyeColour = eyeColour;
	}

	public String getFacialHair() {
		return facialHair;
	}

	public void setFacialHair(String facialHair) {
		this.facialHair = facialHair;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	public String getHairColour() {
		return hairColour;
	}

	public void setHairColour(String hairColour) {
		this.hairColour = hairColour;
	}

	public String getHairDescription() {
		return hairDescription;
	}

	public void setHairDescription(String hairDescription) {
		this.hairDescription = hairDescription;
	}

	public String getHairStyle() {
		return hairStyle;
	}

	public void setHairStyle(String hairStyle) {
		this.hairStyle = hairStyle;
	}

	public String getHairType() {
		return hairType;
	}

	public void setHairType(String hairType) {
		this.hairType = hairType;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getMarks() {
		return marks;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}

	public String getOtherBodyType() {
		return otherBodyType;
	}

	public void setOtherBodyType(String otherBodyType) {
		this.otherBodyType = otherBodyType;
	}

	public String getOtherEyeColour() {
		return otherEyeColour;
	}

	public void setOtherEyeColour(String otherEyeColour) {
		this.otherEyeColour = otherEyeColour;
	}

	public String getOtherFacialHair() {
		return otherFacialHair;
	}

	public void setOtherFacialHair(String otherFacialHair) {
		this.otherFacialHair = otherFacialHair;
	}

	public String getOtherHair() {
		return otherHair;
	}

	public void setOtherHair(String otherHair) {
		this.otherHair = otherHair;
	}

	public String getOtherHairDescription() {
		return otherHairDescription;
	}

	public void setOtherHairDescription(String otherHairDescription) {
		this.otherHairDescription = otherHairDescription;
	}

	public String getOtherHairType() {
		return otherHairType;
	}

	public void setOtherHairType(String otherHairType) {
		this.otherHairType = otherHairType;
	}

	public Integer getPersonDescriptionId() {
		return personDescriptionId;
	}

	public void setPersonDescriptionId(Integer personDescriptionId) {
		this.personDescriptionId = personDescriptionId;
	}

	
}
