package uk.nhs.cfsms.ecms.dto.mgforms;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import uk.nhs.cfsms.ecms.data.common.LookupView;


public class MGFormTO implements Serializable {

	private static final long serialVersionUID = 4939871235L;


	private Long mgFormId;


	private Long caseId;


	private String mgFormType;


	private byte[] mgForm;


	private Date createdTime;


	private String createdStaffId;


	private String fileName;


	private String fileType;


	private boolean selected;

	private List<LookupView> mgFormTypeList;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public byte[] getMgForm() {
		return mgForm;
	}

	public void setMgForm(byte[] mgForm) {
		this.mgForm = mgForm;
	}

	public Long getMgFormId() {
		return mgFormId;
	}

	public void setMgFormId(Long mgFormId) {
		this.mgFormId = mgFormId;
	}

	public String getMgFormType() {
		return mgFormType;
	}

	public void setMgFormType(String mgFormType) {
		this.mgFormType = mgFormType;
	}

	public List getMgFormTypeList() {
		return mgFormTypeList;
	}

	public void setMgFormTypeList(List mgFormTypeList) {
		this.mgFormTypeList = mgFormTypeList;
	}
	
	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}


}
