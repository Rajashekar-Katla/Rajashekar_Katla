package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import uk.nhs.cfsms.ecms.data.sanction.CourtAppearance;
import uk.nhs.cfsms.ecms.data.sanction.CriminalSanctionOutcome;

public class CriminalSanctionTO  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7906178817497663231L;
	
	private Long criminalSanctionId;
	private Long caseId;	
	private String subjectType;
	private String createdStaffId;
	private Date createdTime;	
	private String prosecutingAuthority;
	private String otherAuthority;
	private String state;
	private String nhsSubjectName;
	private String nonNhsSubjectName;
	private String personSubjectName;
	private Long subjectId;
	private String selectedSanctions;
	private String courtName;
	private List<CourtAppearance> courtAppearanceList;
	private CriminalSanctionOutcome outcome;
	private boolean appealExists;

	
	/**
	 * @return Returns the caseId.
	 */
	public Long getCaseId() {
		return caseId;
	}
	/**
	 * @param caseId The caseId to set.
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}
	/**
	 * @return Returns the createdStaffId.
	 */
	public String getCreatedStaffId() {
		return createdStaffId;
	}
	/**
	 * @param createdStaffId The createdStaffId to set.
	 */
	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}
	/**
	 * @return Returns the createdTime.
	 */
	public Date getCreatedTime() {
		return createdTime;
	}
	/**
	 * @param createdTime The createdTime to set.
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	/**
	 * @return Returns the criminalSanctionId.
	 */
	public Long getCriminalSanctionId() {
		return criminalSanctionId;
	}
	/**
	 * @param criminalSanctionId The criminalSanctionId to set.
	 */
	public void setCriminalSanctionId(Long criminalSanctionId) {
		this.criminalSanctionId = criminalSanctionId;
	}
	/**
	 * @return Returns the otherAuthority.
	 */
	public String getOtherAuthority() {
		return otherAuthority;
	}
	/**
	 * @param otherAuthority The otherAuthority to set.
	 */
	public void setOtherAuthority(String otherAuthority) {
		this.otherAuthority = otherAuthority;
	}
	/**
	 * @return Returns the prosecutingAuthority.
	 */
	public String getProsecutingAuthority() {
		return prosecutingAuthority;
	}
	/**
	 * @param prosecutingAuthority The prosecutingAuthority to set.
	 */
	public void setProsecutingAuthority(String prosecutingAuthority) {
		this.prosecutingAuthority = prosecutingAuthority;
	}
	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}
	
	/**
	 * @return Returns the subjectType.
	 */
	public String getSubjectType() {
		return subjectType;
	}
	/**
	 * @param subjectType The subjectType to set.
	 */
	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}
	/**
	 * @return Returns the nhsSubjectName.
	 */
	public String getNhsSubjectName() {
		return nhsSubjectName;
	}
	/**
	 * @param nhsSubjectName The nhsSubjectName to set.
	 */
	public void setNhsSubjectName(String nhsSubjectName) {
		this.nhsSubjectName = nhsSubjectName;
	}
	/**
	 * @return Returns the nonNhsSubjectName.
	 */
	public String getNonNhsSubjectName() {
		return nonNhsSubjectName;
	}
	/**
	 * @param nonNhsSubjectName The nonNhsSubjectName to set.
	 */
	public void setNonNhsSubjectName(String nonNhsSubjectName) {
		this.nonNhsSubjectName = nonNhsSubjectName;
	}
	/**
	 * @return Returns the personSubjectName.
	 */
	public String getPersonSubjectName() {
		return personSubjectName;
	}
	/**
	 * @param personSubjectName The personSubjectName to set.
	 */
	public void setPersonSubjectName(String personSubjectName) {
		this.personSubjectName = personSubjectName;
	}
	/**
	 * @return Returns the subjectId.
	 */
	public Long getSubjectId() {
		return subjectId;
	}
	/**
	 * @param subjectId The subjectId to set.
	 */
	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}
	public List<CourtAppearance> getCourtAppearanceList() {
		return courtAppearanceList;
	}
	public void setCourtAppearanceList(List<CourtAppearance> courtAppearanceList) {
		this.courtAppearanceList = courtAppearanceList;
	}
	public CriminalSanctionOutcome getOutcome() {
		return outcome;
	}
	public void setOutcome(CriminalSanctionOutcome outcome) {
		this.outcome = outcome;
	}
	
	public String getSelectedSanctions() {
		return selectedSanctions;
	}
	public void setSelectedSanctions(String selectedSanctions) {
		this.selectedSanctions = selectedSanctions;
	}
	
	public String getCourtName() {
		return courtName;
	}
	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}
	
	public boolean isAppealExists() {
		return appealExists;
	}
	public void setAppealExists(boolean appealExists) {
		this.appealExists = appealExists;
	} 
}
