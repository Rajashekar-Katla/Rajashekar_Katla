package uk.nhs.cfsms.ecms.dto.disciplinarysanction;

import java.util.Comparator;

public class DisciplinaryAppealSanctionComparator implements Comparator<DisciplinaryAppealSanctionTO>{
	
	public int compare(DisciplinaryAppealSanctionTO o1, DisciplinaryAppealSanctionTO o2) {
        return o2.getOutcomeDate().compareTo(o1.getOutcomeDate());
    }

}
