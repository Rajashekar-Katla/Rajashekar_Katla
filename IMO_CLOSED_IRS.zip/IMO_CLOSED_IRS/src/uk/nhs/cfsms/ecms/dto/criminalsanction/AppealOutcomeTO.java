package uk.nhs.cfsms.ecms.dto.criminalsanction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.apache.commons.lang.builder.ToStringBuilder;

import uk.nhs.cfsms.ecms.data.sanction.OutcomeAppliedSanction;

/**
 *	Criminal sanction outcome transfer object.  
 *
 */
public class AppealOutcomeTO  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4548430165474828275L;

	private Long outcomeId;
	
	private Long appealId;
	
	private Long parentAppealId;
	
	private Long parentSanctionId;
	
	private Date outcomeDate;
	
	private BigDecimal appliedInvCost;
	
	private BigDecimal awardedInvCost;
	
	private BigDecimal appliedProsCost;
	
	private BigDecimal awardedProsCost;
	
	private BigDecimal appliedCompensation;
	
	private String description;
	
	private String confiscationNumber;
	
	private BigDecimal criminalCofiscationCost;
	
	private BigDecimal awardedCompensation;
	
	private String sentenceImposed;
	
	private String compensationPayee;

	private String otherSanction;
	
	private String outcomeStatus;
	
	private String createdStaffId;
	
	private Date createdTime;
	
	private String otherSanctionImposed;
	
	private String sanctionsImposed;
	
	private String costsVaried;
	
	private String costsAwardedAgainst;
	
	private List<String> costAwardedAgainstList;
	
	private Date appearedDate;

	private List<OutcomeAppliedSanction> outcomeAppliedSanctions=LazyList.decorate(
			new ArrayList(), FactoryUtils
			.instantiateFactory(OutcomeAppliedSanction.class));

	private List<SanctionApplied> sanctionsImposedList;
	
	private List<SanctionApplied> unsuccessSanctionsImposedList;	
	
	private List<SanctionApplied> ordersImposedList;
	
	private List<SanctionApplied> allAppealSanctionsList;

	final static String[] SANCTION_NAMES = { 
		"ABSOLUTE DISCHARGE",		
		"ATTENDANCE CENTRE ORDER",
		"CAUTION", 
		"COMMUNITY ORDERS",
		"COMMUNITY PUNISHMENT AND REHABILITATION ORDER",
		"COMMUNITY REHABILITATION", 
		"CONDITIONAL CAUTION",
		"CONDITIONAL DISCHARGE", 
		"CURFEW ORDER",
		"CUSTODY PLUS",
		"DRUG TREATMENT AND TESTING ORDER",
		"FINE", 
		"IMPRISONMENT", 
		"IMPRISONMENT - SUSPENDED", 
		"INTERMITTENT CUSTODY", 
		"OTHER"
	};
	
	final static String[] UNSUCCESS_SANCTION_NAMES = { 
		"ACQUITTAL",
		"WITHDRAWAL"		
	};
	
	final static String[] APPEAL_SANCTION_NAMES = { 
		"ABSOLUTE DISCHARGE",
		"ACQUITTAL",
		"ATTENDANCE CENTRE ORDER",
		"CAUTION", 
		"COMMUNITY ORDERS",
		"COMMUNITY PUNISHMENT AND REHABILITATION ORDER",
		"COMMUNITY REHABILITATION", 
		"CONDITIONAL CAUTION",
		"CONDITIONAL DISCHARGE", 
		"CURFEW ORDER",
		"CUSTODY PLUS",
		"DRUG TREATMENT AND TESTING ORDER",
		"FINE", 
		"IMPRISONMENT", 
		"IMPRISONMENT - SUSPENDED", 
		"INTERMITTENT CUSTODY",
		"WITHDRAWAL",
		"OTHER"
	};
	 
	
	final static String[] ORDER_NAMES = { 
		"ANTI SOCIAL BEHAVIOUR ORDER",
		"COMPENSATION ORDER",
		"CONDITIONAL ORDER CAUTION",
		"CONFISCATION ORDER",
		"MENTAL HEALTH ACT ORDER",
		"PROTECTION FROM HARASSMENT ORDER"
		
	};
	
	 
	
	public AppealOutcomeTO() {
		
		//initialize 
		sanctionsImposedList= new ArrayList<SanctionApplied>();
		for (String name: SANCTION_NAMES) {
			SanctionApplied data = new SanctionApplied();
			data.setSanctionName(name);
			data.setChecked(false);
			sanctionsImposedList.add(data);
		}
		
		ordersImposedList= new ArrayList<SanctionApplied>();
		for (String name: ORDER_NAMES) {
			SanctionApplied data = new SanctionApplied();
			data.setSanctionName(name);
			data.setChecked(false);
			ordersImposedList.add(data);
		}
		
		unsuccessSanctionsImposedList= new ArrayList<SanctionApplied>();
		for (String name: UNSUCCESS_SANCTION_NAMES) {
			SanctionApplied data = new SanctionApplied();
			data.setSanctionName(name);
			data.setChecked(false);
			unsuccessSanctionsImposedList.add(data);
		}
		
		allAppealSanctionsList= new ArrayList<SanctionApplied>();
		
		for (String name: APPEAL_SANCTION_NAMES) {
			SanctionApplied data = new SanctionApplied();
			data.setSanctionName(name);
			data.setChecked(false);
			allAppealSanctionsList.add(data);
		}
	}

	public static String[] getORDER_NAMES() {
		return ORDER_NAMES;
	}
	
	public BigDecimal getAppliedCompensation() {
		return appliedCompensation == null
				? appliedCompensation
				: appliedCompensation.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAppliedCompensation(BigDecimal appliedCompensation) {
		this.appliedCompensation = appliedCompensation;
	}

	public BigDecimal getAppliedInvCost() {
		return appliedInvCost == null ? appliedInvCost : appliedInvCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAppliedInvCost(BigDecimal appliedInvCost) {
		this.appliedInvCost = appliedInvCost;
	}

	public BigDecimal getAppliedProsCost() {
		return appliedProsCost == null ? appliedProsCost : appliedProsCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAppliedProsCost(BigDecimal appliedProsCost) {
		this.appliedProsCost = appliedProsCost;
	}

	public BigDecimal getAwardedCompensation() {
		return awardedCompensation == null
				? awardedCompensation
				: awardedCompensation.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAwardedCompensation(BigDecimal awardedCompensation) {
		this.awardedCompensation = awardedCompensation;
	}

	public BigDecimal getAwardedInvCost() {
		return awardedInvCost == null ? awardedInvCost : awardedInvCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAwardedInvCost(BigDecimal awardedInvCost) {
		this.awardedInvCost = awardedInvCost;
	}

	public BigDecimal getAwardedProsCost() {
		return awardedProsCost == null ? awardedProsCost : awardedProsCost
				.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setAwardedProsCost(BigDecimal awardedProsCost) {
		this.awardedProsCost = awardedProsCost;
	}

	public String getCompensationPayee() {
		return compensationPayee;
	}

	public void setCompensationPayee(String compensationPayee) {
		this.compensationPayee = compensationPayee;
	}

	public String getConfiscationNumber() {
		return confiscationNumber;
	}

	public void setConfiscationNumber(String confiscationNumber) {
		this.confiscationNumber = confiscationNumber;
	}

	public String getCreatedStaffId() {
		return createdStaffId;
	}

	public void setCreatedStaffId(String createdStaffId) {
		this.createdStaffId = createdStaffId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public BigDecimal getCriminalCofiscationCost() {
		return criminalCofiscationCost == null
				? criminalCofiscationCost
				: criminalCofiscationCost.setScale(2, BigDecimal.ROUND_DOWN);
	}

	public void setCriminalCofiscationCost(BigDecimal criminalCofiscationCost) {
		this.criminalCofiscationCost = criminalCofiscationCost;
	}

	public Long getAppealId() {
		return appealId;
	}

	public void setAppealId(Long appealId) {
		this.appealId = appealId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<SanctionApplied> getOrdersImposedList() {
		return ordersImposedList;
	}

	public void setOrdersImposedList(List<SanctionApplied> ordersImposedList) {
		this.ordersImposedList = ordersImposedList;
	}

	public String getOtherSanction() {
		return otherSanction;
	}

	public void setOtherSanction(String otherSanction) {
		this.otherSanction = otherSanction;
	}

	public String getOtherSanctionImposed() {
		return otherSanctionImposed;
	}

	public void setOtherSanctionImposed(String otherSanctionImposed) {
		this.otherSanctionImposed = otherSanctionImposed;
	}

	public Date getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(Date outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long outcomeId) {
		this.outcomeId = outcomeId;
	}

	public String getOutcomeStatus() {
		return outcomeStatus;
	}

	public void setOutcomeStatus(String outcomeStatus) {
		this.outcomeStatus = outcomeStatus;
	}

	public String getSanctionsImposed() {
		return sanctionsImposed;
	}

	public void setSanctionsImposed(String sanctionsImposed) {
		this.sanctionsImposed = sanctionsImposed;
	}

	public List<SanctionApplied> getSanctionsImposedList() {
		return sanctionsImposedList;
	}

	public void setSanctionsImposedList(List<SanctionApplied> sanctionsImposedList) {
		if (this.sanctionsImposedList != null) {		
			this.sanctionsImposedList = sanctionsImposedList;
		}	
	}

	public String getSentenceImposed() {
		return sentenceImposed;
	}

	public void setSentenceImposed(String sentenceImposed) {
		
			this.sentenceImposed = sentenceImposed;
		}
	

	public List<SanctionApplied> getUnsuccessSanctionsImposedList() {
		return unsuccessSanctionsImposedList;
	}

	public void setUnsuccessSanctionsImposedList(
			List<SanctionApplied> unsuccessSanctionsImposedList) {
		if (this.unsuccessSanctionsImposedList != null) {
			this.unsuccessSanctionsImposedList = unsuccessSanctionsImposedList;
		}
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public List<OutcomeAppliedSanction> getOutcomeAppliedSanctions() {
		return outcomeAppliedSanctions;
	}

	public void setOutcomeAppliedSanctions(
			List<OutcomeAppliedSanction> outcomeAppliedSanctions) {
		this.outcomeAppliedSanctions = outcomeAppliedSanctions;
	}
	
	public Long getParentAppealId() {
		return parentAppealId;
	}

	public void setParentAppealId(Long parentAppealId) {
		this.parentAppealId = parentAppealId;
	}

	public Long getParentSanctionId() {
		return parentSanctionId;
	}

	public void setParentSanctionId(Long parentSanctionId) {
		this.parentSanctionId = parentSanctionId;
	}
	
	public String getCostsVaried() {
		return costsVaried;
	}

	public void setCostsVaried(String costsVaried) {
		this.costsVaried = costsVaried;
	}

	public String getCostsAwardedAgainst() {
		return costsAwardedAgainst;
	}

	public void setCostsAwardedAgainst(String costsAwardedAgainst) {
		this.costsAwardedAgainst = costsAwardedAgainst;
	}

	public List<String> getCostAwardedAgainstList() {
		return costAwardedAgainstList;
	}

	public void setCostAwardedAgainstList(List<String> costAwardedAgainstList) {
		this.costAwardedAgainstList = costAwardedAgainstList;
	}

	public List<SanctionApplied> getAllAppealSanctionsList() {
		return allAppealSanctionsList;
	}

	public void setAllAppealSanctionsList(
			List<SanctionApplied> allAppealSanctionsList) {
		if (this.allAppealSanctionsList != null) {
			this.allAppealSanctionsList = allAppealSanctionsList;
		}
	}
	
	public Date getAppearedDate() {
		return appearedDate;
	}

	public void setAppearedDate(Date appearedDate) {
		this.appearedDate = appearedDate;
	}

}
