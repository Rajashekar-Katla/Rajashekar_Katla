/** DAO Exceptions.
 */
package uk.nhs.nhsprotect.cpod.dao.exception;
