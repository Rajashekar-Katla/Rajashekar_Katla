/**
 * 
 */
package uk.nhs.nhsprotect.cpod.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.github.dandelion.datatables.core.ajax.ColumnDef;
import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;

/**
 * Class to provide utility methods for Dandelion Datatablse server-side
 * processing.
 * @author NTones
 */
public class DataTablesUtils {

    /**
     * Method to generate criteia strings to search ajaxwise for user entered
     * values.
     * @param criterias
     * @param alias
     * @return
     */
    public static StringBuilder getUserFiterQuery(
            final DatatablesCriterias criterias, final String alias) {

        StringBuilder queryBuilder = new StringBuilder();
        List<String> paramList = new ArrayList<String>();

        /*
         * Step 1.1: Global filtering
         */
        if (StringUtils.isNotBlank(criterias.getSearch())
                && criterias.hasOneFilterableColumn()
                && criterias.getSearch().length() > 2) {
            queryBuilder.append(" WHERE ");

            for (ColumnDef columnDef : criterias.getColumnDefs()) {
                if (columnDef.isFilterable()
                        && StringUtils.isBlank(columnDef.getSearch())) {

                    if (columnDef.getName().equals("fullname")) {
                        paramList.add("LOWER ("
                                + alias
                                + ".person.foreName"
                                + ") LIKE '%?%'".replace("?", criterias
                                        .getSearch().toLowerCase()));
                        paramList.add("LOWER ("
                                + alias
                                + ".person.surName"
                                + ") LIKE '%?%'".replace("?", criterias
                                        .getSearch().toLowerCase()));
                    } else if (columnDef.getName().equals("status")) {
                        // skip this as enabled column is integer so partial
                        // matches not possible
                    } else {
                        paramList.add("LOWER ("
                                + alias
                                + "."
                                + columnDef.getName()
                                + ") LIKE '%?%'".replace("?", criterias
                                        .getSearch().toLowerCase()));
                    }
                }
            }

            Iterator<String> iterator = paramList.iterator();
            while (iterator.hasNext()) {
                queryBuilder.append(iterator.next());
                if (iterator.hasNext()) {
                    queryBuilder.append(" OR ");
                }

            }
        }

        /*
         * Step 1.2: individual column filtering
         */
        if (criterias.hasOneFilterableColumn()
                && criterias.hasOneFilteredColumn()) {
            paramList = new ArrayList<String>();

            if (!queryBuilder.toString().contains("WHERE")) {
                queryBuilder.append(" WHERE ");
            } else {
                queryBuilder.append(" AND ");
            }

            for (ColumnDef columnDef : criterias.getColumnDefs()) {
                if (columnDef.isFilterable()) {
                    if (StringUtils.isNotBlank(columnDef.getSearch())) {

                        if (columnDef.getName().equals("status")) {

                            paramList
                                    .add(" "
                                            + alias
                                            + ".enabled = "
                                            + (columnDef.getSearch().equals(
                                                    "Enabled") ? "1" : "0"));
                        } else {
                            paramList.add(" LOWER("
                                    + alias
                                    + "."
                                    + columnDef.getName()
                                    + ") LIKE '%?%'".replace("?", columnDef
                                            .getSearch().toLowerCase()));
                        }
                    }
                }
            }

            Iterator<String> iterator = paramList.iterator();
            while (iterator.hasNext()) {
                queryBuilder.append(iterator.next());
                if (iterator.hasNext()) {
                    queryBuilder.append(" AND ");
                }

            }
        }

        return queryBuilder;
    }
}
