package uk.nhs.nhsprotect.cpod.dao.exception;

import uk.nhs.nhsprotect.cpod.exception.CpodException;

/**
 * Exception used to prevent access to DAO methods that are not implemented.
 * @author awheatley
 */
public class DaoNotImplementedException extends CpodException {

    /**
     * Default Serial ID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructor.
     */
    public DaoNotImplementedException() {
        super();

    }

    /**
     * @param message Returned Message
     * @param cause Exception type
     */
    public DaoNotImplementedException(String message, Throwable cause) {
        super(message, cause);

    }

    /**
     * @param message Returned Message
     */
    public DaoNotImplementedException(String message) {
        super(message);

    }

    /**
     * @param cause Exception Type
     */
    public DaoNotImplementedException(Throwable cause) {
        super(cause);

    }

}
