package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Class representing Person notes table (person_notes_TBL).
 * @author awheatley
 */
@Entity
@Table(name = "PERSON_NOTES_TBL")
public class PersonNote extends BaseEntity implements Serializable {
    /**
     * Serial version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key identifier.
     */
    @Id
    @Column(name = "person_notes_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "personNotesID")
    @GenericGenerator(strategy = "sequence", name = "personNotesID", parameters = { @Parameter(name = "sequence", value = "PERSON_NOTES_SEQ") })
    private Long id;

    /**
     * Note Date
     */
    @Column(name = "note_date")
    private Date noteDate;

    /**
     * Person ID
     */
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "person_id")
    private Person person;

    @Column(name = "person_id", updatable = false, insertable = false)
    private Long personId;
    
    /**
     * Note
     */
    @Column(name = "note")
    private String note;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the noteDate
     */
    public Date getNoteDate() {
        if (noteDate == null) {
            return null;
        } else {
            return new Date(noteDate.getTime());
        }
    }

    /**
     * @param noteDate the noteDate to set
     */
    public void setNoteDate(Date noteDate) {
        if (noteDate == null) {
            this.noteDate = null;
        } else {
            this.noteDate = new Date(noteDate.getTime());
        }
    }

    /**
     * @return the personId
     */
    public Long getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
 
        public void setPersonId(Long personId) {
            this.personId = personId;
            if (this.person == null) {
                this.setPerson(new Person());
            }
            this.person.setId(personId);
        }
    

    /**
     * @return the note
     */
    public String getNote() {
        return note;
    }

    /**
     * @param note the note to set
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * @return the person
     */
    public Person getPerson() {
        return person;
    }

    /**
     * @param person the person to set
     */
    public void setPerson(Person person) {
        this.person = person;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((note == null) ? 0 : note.hashCode());
        result = prime * result
                + ((noteDate == null) ? 0 : noteDate.hashCode());
        result = prime * result + ((person == null) ? 0 : person.hashCode());
        result = prime * result
                + ((personId == null) ? 0 : personId.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof PersonNote)) {
            return false;
        }
        PersonNote other = (PersonNote) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (note == null) {
            if (other.note != null) {
                return false;
            }
        } else if (!note.equals(other.note)) {
            return false;
        }
        if (noteDate == null) {
            if (other.noteDate != null) {
                return false;
            }
        } else if (!noteDate.equals(other.noteDate)) {
            return false;
        }
        if (person == null) {
            if (other.person != null) {
                return false;
            }
        } else if (!person.equals(other.person)) {
            return false;
        }
        if (personId == null) {
            if (other.personId != null) {
                return false;
            }
        } else if (!personId.equals(other.personId)) {
            return false;
        }
        return true;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PersonNote [id=");
        builder.append(id);
        builder.append(", noteDate=");
        builder.append(noteDate);
        builder.append(", person=");
        builder.append(person);
        builder.append(", personId=");
        builder.append(personId);
        builder.append(", note=");
        builder.append(note);
        builder.append("]");
        return builder.toString();
    }

}
