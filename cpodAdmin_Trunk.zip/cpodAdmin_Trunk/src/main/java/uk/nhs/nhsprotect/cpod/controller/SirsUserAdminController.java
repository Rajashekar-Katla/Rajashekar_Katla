/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.PersonNote;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.Responsibility;
import uk.nhs.nhsprotect.cpod.service.PersonRoleService;
import uk.nhs.nhsprotect.cpod.service.PersonService;
import uk.nhs.nhsprotect.cpod.service.ResponsibilityService;
import uk.nhs.nhsprotect.cpod.service.SirsAuthorityService;
import uk.nhs.nhsprotect.cpod.service.SirsUserService;
import uk.nhs.nhsprotect.cpod.service.SirsUserServiceRO;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;
import uk.nhs.nhsprotect.sirs.model.SirsAuthority;
import uk.nhs.nhsprotect.sirs.model.SirsUser;
import uk.nhs.nhsprotect.sirs.model.SirsUserAuthorities;
import uk.nhs.nhsprotect.sirs.model.SirsUserRO;

/**
 * Spring controller class to manage requests relating to CPOD user admin
 * functions.
 * 
 * @author ntones
 */
@Controller
public class SirsUserAdminController extends CpodBaseController {

    /**
     * Logger instance for CommonPagesController.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(SirsUserAdminController.class);

    @Autowired
    private SirsUserService sirsUserService;

    @Autowired
    private SirsAuthorityService sirsAuthorityService;

    @Autowired
    private PersonRoleService personRoleService;

    @Autowired
    private PersonService personService;

    @Autowired
    private SirsUserServiceRO sirsUserServiceRO;

    @Autowired
    private ResponsibilityService responsibilityService;

    @Autowired
    private PasswordEncoder md5PasswordEncoder;

    /**
     * Method to handle requests to delete a specific user.
     * 
     * @param modelMap
     *            the current model
     * @param userId
     *            the requested id for deletion
     * @return ResponseBody on success
     * @throws Exception
     *             on error.
     */
    @RequestMapping(value = { "/admin/sirs/deleteSirsUser" }, method = RequestMethod.POST)
    public @ResponseBody String deleteSirsUser(
            ModelMap modelMap,
            @RequestParam(value = "personId", required = true) Long personId,
            @RequestParam(value = "deleteSirs", required = true, defaultValue = "true") boolean deleteSirs,
            @RequestParam(value = "personInactive", required = true, defaultValue = "true") boolean personInactive,
            @RequestParam(value = "endDate", required = true) Date endDate,
            @RequestParam(value = "userRef") String userRef) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("deleteSirsUser with Options [personId: " + personId
                    + "deleteSirs: " + deleteSirs + "personInactive: "
                    + personInactive + "endDate: " + endDate + "]");
        }

        // log changes made to person record and user accounts as a note.
        StringBuffer noteBuffer = new StringBuffer();

        // Remove the SIRS User record in SIRS Database
        if (deleteSirs) {
            sirsUserService.deleteByUserName(userRef);
            // add note
            noteBuffer.append("User account [" + userRef
                    + "] deleted from SIRS.");
        }// else let the record be in SIRS database

        List<PersonRole> personRoles = personRoleService
                .findPersonRolesByRef(userRef);

        // end the person role and any responsibilities with the supplied end
        // date
        boolean respsEnded = false;
        for (PersonRole personRole : personRoles) {
            personRole.setEndDate(endDate);

            personRole.setReason("User Responsiblities ended in SIRS by "
                    + getUserConextUtil().getUsername());

            for (Responsibility responsibility : personRole
                    .getResponsibilities()) {
                responsibility.setEndDate(endDate);
                responsibilityService.saveOrUpdate(responsibility);
            }
            personRoleService.saveOrUpdate(personRole);
            respsEnded = true;
           
        }
        if (respsEnded){
            //add Note
            noteBuffer.append("All responsibilities ended for person role ["
                    + userRef + "]");
        }
        // Update person record
        Person person = personService.findById(personId);
        // Mark the status to inactive in Person record
        if (personInactive) {
            person.setStatus(CPODConstants.PERSON_STATUS_INACTIVE);
            //add note
            noteBuffer.append("Person [" + userRef + "] made inactive");
        }// else nothing leave it as Active

        // add person notes to reflect changes made
        PersonNote note = new PersonNote();
        note.setNoteDate(new Date());
        note.setNote(noteBuffer.toString());
        note.setModifiedByUser(getUserConextUtil().getUsername());
        
        // set the note on person and vice-versa for RI
        note.setPerson(person);
        person.getPersonNotes().add(note);

        personService.saveOrUpdate(person);

        // redirect to refresh search results
        if (LOG.isDebugEnabled()) {
            LOG.debug("User deleted successfully");
        }
        return "User Deleted";
    }

    /**
     * Method to handle requests to view users as part of SIRS User
     * Administration.
     * 
     * @param modelMap
     *            the current model
     * @param userId
     *            the requested id for edit
     * @return String tiles view name
     * @throws Exception
     *             on error
     */
    @RequestMapping(value = { "/admin/sirs/viewSirsUser" }, method = RequestMethod.GET)
    public String viewSirsUser(ModelMap modelMap,
            @RequestParam(value = "username", required = false) String username)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("viewSirsUser Username[ " + username + "]");
        }
        SirsUser sirsUser = null;
        if (null != username) {
            // TODO return to the specific user page
            sirsUser = sirsUserService.findByReferenceNumber(username);

            modelMap.put("sirsUser", sirsUser);
            return "sirs-user-view";
        } else {
            // return to the Front page to Create new SIRS User & Person record
            // or Enable the existing personrecord
            sirsUser = new SirsUser();

            modelMap.put("sirsUser", sirsUser);
            return "create_enable-sirs-user-view";
        }
    }

    /**
     * Method to handle requests to save or update a Sirs user object.
     * 
     * @param sirsUserModel
     *            the user object to save
     * @param modelMap
     *            the current model
     * @return String tiles view definition
     * @throws Exception
     *             on error
     */
    @RequestMapping(value = { "/admin/sirs/saveSirsUser" }, method = RequestMethod.POST)
    public String saveOrUpdateSirsUser(
            @ModelAttribute SirsUser sirsUserModel,
            ModelMap modelMap,
            @RequestParam(value = "createSirs", required = false, defaultValue = "false") boolean createSirs,
            @RequestParam(value = "external", required = false, defaultValue = "false") boolean external)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("saveOrUpdateSirsuser[" + sirsUserModel + "]");
        }

        SirsUser sirsUser = null;
        if (createSirs) {

            // throws CPODException if nothing found for supplied username
            Person person = personService.findPersonByRef(sirsUserModel
                    .getUsername());

            // internal users have MD5 password of 'changeit' but are forced to
            // change at first login TODO should use a stronger password
            // algorithm later. (BCrypt)...
            String password = md5PasswordEncoder.encodePassword(
                    CPODConstants.DEFAULT_PASSWORD, null);
            if (external) {
                // we are creating an external person
                password = CPODConstants.SIRS_EXTERNAL_DEFAULT_PASSWORD;
            }

            // Create new User in SIRS Database
            sirsUser = new SirsUser(sirsUserModel.getUsername(), password,
                    sirsUserModel.isEnable() ? 1 : 0, person.getId());

            if (!external) {
                // setting the active password = 1 means user will have to
                // create their own password on next entering SIRS
                sirsUser.setActivePassword(1);
                modelMap.put(
                        "infoMessage",
                        "Default password 'changeit' applied user will be prompted to change this at first login.");
            }

            // save sirsuserAuthorities
            List<SirsAuthority> sirsAssignedAuthorities = new ArrayList<SirsAuthority>(
                    1);

            Long sirsAuthorityId = CPODConstants.CPOD_PERSONTYPE_SIRS_USER_AUTHORITY_MAP
                    .get(sirsUserModel.getCpodRole());
            SirsAuthority sirsAuthority = sirsAuthorityService
                    .findById(sirsAuthorityId);
            sirsAssignedAuthorities.add(sirsAuthority);

            List<SirsUserAuthorities> sirsAssignedUserAuthorities = new ArrayList<SirsUserAuthorities>(
                    sirsAssignedAuthorities.size());
            for (SirsAuthority sirsAssignedUserAuthority : sirsAssignedAuthorities) {
                sirsAssignedUserAuthorities.add(new SirsUserAuthorities(
                        sirsUser, sirsAssignedUserAuthority));
            }

            sirsUser.setAuthorities(sirsAssignedUserAuthorities);
            sirsUserService.saveOrUpdate(sirsUser);

        } else {
            // Set the disable status in SIRS
            // User reference should exists in SIRSDB
            sirsUser = sirsUserService.findByReferenceNumber(sirsUserModel
                    .getUsername());
            if (null == sirsUser) {
                throw new CpodException(
                        "Unexpected SIRS UserName encountered = ["
                                + sirsUserModel.getUsername() + "]");
            }
            // TODO use NumericBooleanType
            sirsUser.setEnabled(sirsUserModel.getEnabled());

            sirsUserService.saveOrUpdate(sirsUser);
        }

        modelMap.put("sirsUser", sirsUser);
        modelMap.put("successMessage",
                "SIRS User [" + sirsUserModel.getUsername() + "] saved.");
        return "sirs-user-view";
    }

    /**
     * Handles the SirsUser Enable/Disable
     * 
     * @param modelMap
     *            the model map
     * @param personSearch
     *            the form backing object from the request
     * @return value of forward depending on query outcome
     * @throws Exception
     *             on error
     */
    @RequestMapping(value = { "/admin/sirs/updateSirsUserStatus" }, method = RequestMethod.POST)
    public @ResponseBody String updateSirsUserStatus(ModelMap modelMap,
            @RequestParam(value = "id", required = true) String userName,
            @RequestParam(value = "userStatus", required = true) int status)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Enable/Disable SIRS USER:" + userName);
        }

        SirsUser sirsUser = sirsUserService.findByReferenceNumber(userName);
        sirsUser.setEnabled(status);
        sirsUserService.saveOrUpdate(sirsUser);

        return "Sirs User [" + sirsUser.getUsername() + "] status updated.";

    }

    /**
     * Handles the request to reset internal SIRS user passwords.
     * 
     * 
     * @param modelMap
     *            the model map
     * @param userName
     *            to reset
     * @return value of forward depending on query outcome
     * @throws Exception
     *             on error
     */
    @RequestMapping(value = { "/admin/sirs/resetInternalSirsUserPassword" }, method = RequestMethod.POST)
    public @ResponseBody String resetInternalSirsUserPassword(
            ModelMap modelMap,
            @RequestParam(value = "id", required = true) String userName)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Password reset requested for user [" + userName + "]");
        }
        SirsUser sirsUser = sirsUserService.findByReferenceNumber(userName);
        sirsUser.setActivePassword(1);
        sirsUser.setPassword(md5PasswordEncoder.encodePassword(
                CPODConstants.DEFAULT_PASSWORD, null));
        sirsUserService.saveOrUpdate(sirsUser);

        //
        return "Sirs User [" + sirsUser.getUsername() + "] password reset.";

    }

    /**
     * Handles the request to edit SIRS users, returns a list of all current
     * SIRS users (enabled and disabled).
     * 
     * @param modelMap
     *            the current model map
     * @param request
     *            the current request
     * @return tile view for display
     * @throws Exception
     *             on error
     */
    @RequestMapping(value = { "/admin/sirs/sirsUsers" }, method = RequestMethod.GET)
    public String listSirsUsers()
            throws Exception {
       // Retrieval of the sirs user list is now handled ajax wise
        return "list-sirs-users";
    }

    /**
     * Handles request to view the SIRS users without any active
     * responsibilities.
     * 
     * @param modelMap
     *            the model map
     * @param personSearch
     *            the form backing object from the request
     * @return value of forward depending on query outcome
     * @throws Exception
     *             on error
     */
    @RequestMapping(value = { "/admin/sirs/sirsUsersNoResp" }, method = RequestMethod.GET)
    public String listSirsUsersWithoutResponsibilities(ModelMap modelMap,
            HttpServletRequest request) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("list SIRS USERS WITHOUT ACTIVE RESPONSIBILITIES");
        }

        List<SirsUserRO> sirsUsers = sirsUserServiceRO
                .findUsersWithoutResponsibilities();

        if (sirsUsers.isEmpty()) {
            modelMap.addAttribute("successMessage", getMessageSource()
                    .getMessage("sirsuser.inactive.none", null, null));
        } else {
            modelMap.addAttribute(
                    "warnMessage",
                    getMessageSource().getMessage("sirsuser.inactive.result",
                            null, null));
        }

        modelMap.addAttribute("sirsusers", sirsUsers);
        return "list-sirs-users";
    }
}
