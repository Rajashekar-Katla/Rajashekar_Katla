/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.SirsUserAuthoritiesDao;
import uk.nhs.nhsprotect.sirs.model.SirsUserAuthorities;

/**
 * Methods for managing User Authorities (permissions)
 * @author ntones
 */
@Repository("sirsUserAuthoritiesDao")
public class SirsUserAuthoritiesDaoImpl extends
        SirsAbstractDaoImpl<SirsUserAuthorities, Long> implements SirsUserAuthoritiesDao {

    /**
     * Logger instance for UserAuthoritiesDaoImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(SirsUserAuthoritiesDaoImpl.class);

    /**
     * @param persistentClass
     */
    public SirsUserAuthoritiesDaoImpl() {
        super(SirsUserAuthorities.class);
    }

    @Override
    public void deleteAuthoritiesForUser(String userRef) {
        StringBuilder buffer = new StringBuilder();
        buffer.append("Delete from SirsUserAuthorities sua where  sua.sirsUser.username = '");
        buffer.append(userRef);
        buffer.append("'");
        final String queryString = buffer.toString();
        int deletedRows = getCurrentSession().createQuery(queryString)
                .executeUpdate();
        if (LOG.isDebugEnabled()) {
            LOG.debug("Number of Rows deleted:" + deletedRows);
        }
        
    }
}
