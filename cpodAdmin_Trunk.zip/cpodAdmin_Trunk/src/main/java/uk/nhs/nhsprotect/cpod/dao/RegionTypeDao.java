package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.RegionType;

/**
 * Defines methods to be implemented for AddressType DAO functions.
 * @author awheatley
 */
public interface RegionTypeDao extends AbstractDao<RegionType, Long> {

    /**
     * Find Region Type by requesting Type.
     * @param type - 
     * @return - List of RegionType
     * @throws CpodException for error
     */
    List<RegionType> findAdressTypeByType(String type) throws CpodException;
}
