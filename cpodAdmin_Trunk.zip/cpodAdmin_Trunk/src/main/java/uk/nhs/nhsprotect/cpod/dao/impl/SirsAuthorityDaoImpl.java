/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.SirsAuthorityDao;
import uk.nhs.nhsprotect.sirs.model.SirsAuthority;

/**
 * Methods for managing SIRS User Authorities (permissions)
 * @author ibandi
 */
@Repository("sirsAuthorityDao")
public class SirsAuthorityDaoImpl extends
        SirsAbstractDaoImpl<SirsAuthority, Long> implements SirsAuthorityDao {

    /**
     * @param persistentClass
     */
    public SirsAuthorityDaoImpl() {
        super(SirsAuthority.class);
    }
}
