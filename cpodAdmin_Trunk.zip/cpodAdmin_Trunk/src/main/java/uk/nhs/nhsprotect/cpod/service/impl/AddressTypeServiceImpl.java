package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.AddressTypeDao;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.AddressType;
import uk.nhs.nhsprotect.cpod.service.AddressTypeService;

/**
 * @author AWheatley
 */
/**
 * @author awheatley
 */
@Service("addressTypeService")
@Transactional(readOnly = true)
public class AddressTypeServiceImpl extends
        AbstractServiceImpl<AddressType, Long> implements AddressTypeService {

    /**
     * Gives access to the AddressTypeDao.
     */
    @Autowired
    private AddressTypeDao addressTypeDao;

    @Override
    public AbstractDao<AddressType, Long> getDao() {
        return addressTypeDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AddressTypeService#findAddressTypeByType
     * (java.lang.String)
     */
    public AddressType findAddressTypeByType(String type) throws CpodException {
        List<AddressType> found = addressTypeDao.findAdressTypeByType(type);

        if (found != null && !found.isEmpty()) {
            // multiple records found
            if (found.size() > 1) {
                throw new CpodNonUniqueException(
                        "More than one AddressType with addressType = [" + type
                                + "]");
            } else {
                // one record found
                return found.get(0);
            }
        } else {
            // No results found
            throw new CpodNoResultsReturnedException(
                    "No results returned for AddressType with addressType = ["
                            + type + "]");
        }
    }
}
