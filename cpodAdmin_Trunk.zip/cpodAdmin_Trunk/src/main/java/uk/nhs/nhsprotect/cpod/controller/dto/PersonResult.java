/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

/**
 * Class used by ajax controller to present person results in a consumable form
 * for a typeahead text input field.
 * @author ntones
 */
@JsonPropertyOrder({ "personRef", "personId", "forename", "surname" ,"personRoleId","assignedRole"})
public class PersonResult implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String personRef;
    private Long personId;
    private String forename;
    private String surname;
    private Long personRoleId;
    private String assignedRole;
    
    /**
     * Default Constructor.
     */
    public PersonResult() {
        // default
    }

    /**
     * @return the personRef
     */
    public String getPersonRef() {
        return personRef;
    }

    /**
     * @param personRef the personRef to set
     */
    public void setPersonRef(String personRef) {
        this.personRef = personRef;
    }

    /**
     * @return the personId
     */
    public Long getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    /**
     * @return the forename
     */
    public String getForename() {
        return forename;
    }

    /**
     * @param forename the forename to set
     */
    public void setForename(String forename) {
        this.forename = forename;
    }

    /**
     * @return the surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * @param surname the surname to set
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * @return the personRoleId
     */
    public Long getPersonRoleId() {
        return personRoleId;
    }

    /**
     * @param personRoleId the personRoleId to set
     */
    public void setPersonRoleId(Long personRoleId) {
        this.personRoleId = personRoleId;
    }

    public String getAssignedRole() {
        return assignedRole;
    }

    public void setAssignedRole(String assignedRole) {
        this.assignedRole = assignedRole;
    }
    
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PersonResult [personRef=");
        builder.append(personRef);
        builder.append(", personId=");
        builder.append(personId);
        builder.append(", forename=");
        builder.append(forename);
        builder.append(", surname=");
        builder.append(surname);
        builder.append(", personRoleId=");
        builder.append(personRoleId);
        builder.append(", assignedRole=");
        builder.append(assignedRole);
        builder.append("]");
        return builder.toString();
    }
}
