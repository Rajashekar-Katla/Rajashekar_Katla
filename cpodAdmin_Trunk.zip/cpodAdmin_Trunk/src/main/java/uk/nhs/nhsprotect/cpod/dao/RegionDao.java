package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Region;

/**
 * Find Region by Region Code
 * @author awheatley
 */
public interface RegionDao extends AbstractDao<Region, Long> {
    List<Region> findRegionByRegionCode(String region) throws CpodException;
}
