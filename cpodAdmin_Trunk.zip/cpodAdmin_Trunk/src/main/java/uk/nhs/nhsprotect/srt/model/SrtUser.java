package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

/**
 * ORM class representing users of the SRT system
 * @author ntones
 */
@Entity
@Table(name = "USERS")
public class SrtUser implements Serializable {

    private static final long serialVersionUID = 5268792925956258160L;

    /**
     * PK column for the entity.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "userId")
    @GenericGenerator(strategy = "sequence", name = "userId", parameters = { @Parameter(name = "sequence", value = "USER_ID_SEQNO") })
    @Column(name = "USER_ID")
    private Long id;

    /**
     * The username of the entity.
     */
    @Column(name = "USERNAME")
    private String username;

    /**
     * The password of the entity - plaintext in SRT!
     */
    @Column(name = "PASSWORD")
    private String password;

    /**
     * Indicates if the user is enabled or not.
     */
    @Column(name = "ENABLED")
    private boolean enabled;

    /**
     * Number of failed login attempts user has made.
     */
    @Column(name = "FAILED_ATTEMPTS")
    private int failedAttempts;

    /**
     * Indicates if the default password has been changed.
     */
    @Column(name = "DEFAULT_PASSWORD_CHANGED")
    @Type(type = "yes_no")
    private boolean defaultPasswordChanged = false;

    /**
     * The ID of the person object - used for RI.
     */
    @Column(name = "person_id")
    private Long personId;

    /**
     * The SRTUserAuthorities granted to this user
     */
    @OneToMany(mappedBy = "srtUser", cascade = { CascadeType.ALL })
    private List<SrtUserAuthorities> userAuthorities = new ArrayList<SrtUserAuthorities>();

    /**
     * The list of authorities selected from the screen.
     */
    @Transient
    private List<SrtAuthority> authorities = new ArrayList<SrtAuthority>();

    /**
     * Default constructor.
     */
    public SrtUser() {
        // default
    }

    /**
     * Parameterised constructor.
     * @param username to set
     * @param password to set
     * @param enabled to set
     */
    public SrtUser(String username, String password, boolean enabled) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the enabled
     */
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * @param enabled the enabled to set
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * @return the failedAttempts
     */
    public int getFailedAttempts() {
        return failedAttempts;
    }

    /**
     * @param failedAttempts the failedAttempts to set
     */
    public void setFailedAttempts(int failedAttempts) {
        this.failedAttempts = failedAttempts;
    }

    /**
     * @return the defaultPasswordChanged
     */
    public boolean isDefaultPasswordChanged() {
        return defaultPasswordChanged;
    }

    /**
     * @param defaultPasswordChanged the defaultPasswordChanged to set
     */
    public void setDefaultPasswordChanged(boolean defaultPasswordChanged) {
        this.defaultPasswordChanged = defaultPasswordChanged;
    }

    /**
     * @return the userAuthorities
     */
    public List<SrtUserAuthorities> getUserAuthorities() {
        return userAuthorities;
    }

    /**
     * @param userAuthorities the userAuthorities to set
     */
    public void setUserAuthorities(List<SrtUserAuthorities> userAuthorities) {
        this.userAuthorities = userAuthorities;
    }

    /**
     * @return the personId
     */
    public Long getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SrtUser other = (SrtUser) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SrtUser [id=" + id + ", username=" + username + ", password="
                + password + ", enabled=" + enabled + ", failedAttempts="
                + failedAttempts + ", defaultPasswordChanged="
                + defaultPasswordChanged + ", personId=" + personId + "]";
    }

    /**
     * @return the authorities
     */
    public List<SrtAuthority> getAuthorities() {
        return authorities;
    }

    /**
     * @param authorities the authorities to set
     */
    public void setAuthorities(List<SrtAuthority> authorities) {
        this.authorities = authorities;
    }

    /**
     * Utility method to add an srtUserAuthorities object to this entity.
     * @param authorities to add
     */
    public void addSrtUserAuthority(SrtUserAuthorities authorities) {
        authorities.setSrtUser(this);
        this.userAuthorities.add(authorities);
    }

    /**
     * Utility method to remove an srtUserAuthorities object from this entity.
     * @param authorities to add
     */
    public void removeSrtUserAuthority(SrtUserAuthorities authorities) {
        authorities.setSrtUser(null);
        authorities.setSrtAuthority(null);
        this.userAuthorities.remove(authorities);
    }

}
