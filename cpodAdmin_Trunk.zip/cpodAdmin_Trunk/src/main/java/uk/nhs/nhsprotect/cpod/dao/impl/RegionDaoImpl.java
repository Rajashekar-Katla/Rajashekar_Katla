package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.RegionDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Region;

/**
 * @author AWheatley
 */
@Repository("regionDao")
public class RegionDaoImpl extends AbstractDaoImpl<Region, Long> implements
        RegionDao {

    /**
     * Logger instance for RegionDaoImpl.class.
     **/
    private static final Logger LOG = Logger.getLogger(RegionDaoImpl.class);

    /**
     * Regions DAO implementation.
     */
    protected RegionDaoImpl() {
        super(Region.class);

    }

    @Override
    public List<Region> findRegionByRegionCode(String region)
            throws CpodException {

        if (LOG.isDebugEnabled()) {
            LOG.debug("findRegionByRegionCode searching for region [" + region
                    + "]");
        }
        return findByCriteria(Restrictions.ilike("regionCode",
                region.toLowerCase(), MatchMode.START));
    }

}
