package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.AddressTypeDao;
import uk.nhs.nhsprotect.cpod.model.AddressType;

/**
 * Hibernate implementation of AddressTypeDao interface.
 * @author awheatley
 */
@Repository("addressTypeDao")
public class AddressTypeDaoImpl extends AbstractDaoImpl<AddressType, Long>
        implements AddressTypeDao {
    /**
     * Log4J instance for PersonDaoImpl.class.
     **/
    @SuppressWarnings("unused")
    private static final Logger LOG = Logger.getLogger(AddressType.class);

    /**
     * Address Type DAO.
     */
    protected AddressTypeDaoImpl() {
        super(AddressType.class);
    }

    @Override
    public List<AddressType> findAdressTypeByType(String type) {
        return findByCriteria(Restrictions.ilike("addressType",
                type.toLowerCase(), MatchMode.START));
    }
}
