/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.AddressLinkDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.AddressLink;
import uk.nhs.nhsprotect.cpod.service.AddressLinkService;

/**
 * Implementation of AddressLinkService.
 * @author ntones
 */
@Service("addressLinkService")
@Transactional(readOnly = true)
public class AddressLinkServiceImpl extends
        AbstractServiceImpl<AddressLink, Long> implements AddressLinkService {

    /**
     * addressLinkDao Represents the DAO for AddressLink.
     */
    @Autowired
    private AddressLinkDao addressLinkDao;

    @Override
    public AbstractDao<AddressLink, Long> getDao() {
        return addressLinkDao;
    }

    @Override
    @Transactional(readOnly = false)
    public void delete(AddressLink entity) throws CpodException {
        entity.removeAddress();
        super.delete(entity);
    }

}
