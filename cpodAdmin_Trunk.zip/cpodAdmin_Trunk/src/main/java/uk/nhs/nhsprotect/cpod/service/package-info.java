/** Service Interface.
 */
package uk.nhs.nhsprotect.cpod.service;
