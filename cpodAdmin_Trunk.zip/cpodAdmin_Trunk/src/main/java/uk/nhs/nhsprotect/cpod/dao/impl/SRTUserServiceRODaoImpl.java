/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.SRTUserServiceRODao;
import uk.nhs.nhsprotect.cpod.util.DataTablesUtils;
import uk.nhs.nhsprotect.srt.model.SrtUserRO;

import com.github.dandelion.datatables.core.ajax.ColumnDef;
import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;

/**
 * TODO could this and sirs user RO be refactored?
 * @author ntones
 */
@Repository("srtUserServiceRODao")
public class SRTUserServiceRODaoImpl extends AbstractDaoImpl<SrtUserRO, Long>
        implements SRTUserServiceRODao {

    /**
     * User Dao Implementation.
     */
    protected SRTUserServiceRODaoImpl() {
        super(SrtUserRO.class);
    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.dao.SIRSUserServiceRODao#
     * findSirsUsersWithDatatablesCriterias
     * (com.github.dandelion.datatables.core.ajax.DatatablesCriterias)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<SrtUserRO> findSrtUsersWithDatatablesCriterias(
            DatatablesCriterias criterias, boolean forScreenDisplav) {
        final String alias = "srtUser";
        StringBuilder queryBuilder = new StringBuilder("SELECT " + alias
                + " from SrtUserRO as " + alias + " ");

        // filter global and individual columns
        queryBuilder
                .append(DataTablesUtils.getUserFiterQuery(criterias, alias));

        // apply sorting
        if (criterias.hasOneSortedColumn()) {
            List<String> orderParams = new ArrayList<String>();
            queryBuilder.append(" ORDER BY ");

            for (ColumnDef columnDef : criterias.getSortingColumnDefs()) {
                if (columnDef.getName().equals("fullname")) {
                    orderParams.add(alias + ".person.surName "
                            + columnDef.getSortDirection());
                    orderParams.add(alias + ".person.foreName "
                            + columnDef.getSortDirection());

                } else if (columnDef.getName().equals("status")) {
                    orderParams.add(alias + ".enabled "
                            + columnDef.getSortDirection());
                } else {
                    orderParams.add(alias + "." + columnDef.getName() + " "
                            + columnDef.getSortDirection());
                }

            }

            Iterator<String> iterator = orderParams.iterator();
            while (iterator.hasNext()) {
                queryBuilder.append(iterator.next());
                if (iterator.hasNext()) {
                    queryBuilder.append(", ");
                }
            }
        }

        Query query = getCurrentSession().createQuery(queryBuilder.toString());

        if (forScreenDisplav) {
            // limit the query size to the current selected values, otherwise
            // retrieve the full list of users
            query.setFirstResult(criterias.getDisplayStart());
            query.setMaxResults(criterias.getDisplaySize());
        }

        return (List<SrtUserRO>) query.list();
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.dao.SIRSUserServiceRODao#getFilteredCount(com.
     * github.dandelion.datatables.core.ajax.DatatablesCriterias)
     */
    @Override
    public Long getFilteredCount(DatatablesCriterias criterias) {

        final String alias = "srtUser";
        StringBuilder queryBuilder = new StringBuilder("SELECT COUNT(" + alias
                + ") from SrtUserRO " + alias + " ");
        queryBuilder
                .append(DataTablesUtils.getUserFiterQuery(criterias, alias));
        return ((Long) getCurrentSession().createQuery(queryBuilder.toString())
                .uniqueResult());
    }
}
