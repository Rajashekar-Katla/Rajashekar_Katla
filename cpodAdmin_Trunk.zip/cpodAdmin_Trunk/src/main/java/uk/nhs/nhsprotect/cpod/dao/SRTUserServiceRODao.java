/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.srt.model.SrtUserRO;

import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;

/**
 * @author ntones
 */
public interface SRTUserServiceRODao extends AbstractDao<SrtUserRO, Long> {

    /**
     * Method to retrieve a 'chunk' of sirs users matching supplied datatables
     * criteria.
     * @param criterias used to filter records
     * @param forScreenDisplav indicates if the query is for an export or to be
     *            displayed on screen
     * @return List<SrtUserRO> matching results
     */
    List<SrtUserRO> findSrtUsersWithDatatablesCriterias(
            DatatablesCriterias criterias, boolean forScreenDisplav);

    /**
     * Query to return the number of filtered records. TODO we could put this on
     * abstract?
     * @param criterias used to filter records
     * @return the number of filtered records
     */
    Long getFilteredCount(DatatablesCriterias criterias);

}
