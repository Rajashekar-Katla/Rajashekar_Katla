package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.NHSPDepartmentDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.NHSPDepartment;


/**
 * @author awheatley
 */
@Repository("nhspDepartmentDao")
public class NHSPDepartmentDaoImpl extends
        AbstractDaoImpl<NHSPDepartment, Long> implements NHSPDepartmentDao {


    /**
     * Logger instance for NHSPDepartmentDaoImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(NHSPDepartmentDaoImpl.class);

    /**
     *  NHSP Department DAO Implementation.
     */
    protected NHSPDepartmentDaoImpl() {
        super(NHSPDepartment.class);
    }


    @Override
    public List<NHSPDepartment> findNhspDepartmentByCriteria(String departmentName)
            throws CpodException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("findNhspDepartmentByCriteria searching for department name ["
                    + departmentName + "]");
        }

        return findByCriteria(Restrictions.ilike("nhspDepartmentName",
                departmentName.toLowerCase(), MatchMode.START));
    }

}
