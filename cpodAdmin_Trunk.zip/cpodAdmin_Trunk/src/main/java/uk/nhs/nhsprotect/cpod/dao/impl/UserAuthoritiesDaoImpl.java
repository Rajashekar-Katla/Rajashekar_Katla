/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.UserAuthoritiesDao;
import uk.nhs.nhsprotect.cpod.model.authentication.UserAuthorities;

/**
 * Methods for managing User Authorities (permissions)
 * @author ntones
 */
@Repository("userAuthoritiesDao")
public class UserAuthoritiesDaoImpl extends
        AbstractDaoImpl<UserAuthorities, Long> implements UserAuthoritiesDao {

    /**
     * Logger instance for UserAuthoritiesDaoImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(UserAuthoritiesDaoImpl.class);

    /**
     * @param persistentClass
     */
    public UserAuthoritiesDaoImpl() {
        super(UserAuthorities.class);
    }

    @Override
    public void deleteAuthoritiesForUser(Long userId) {
        StringBuilder buffer = new StringBuilder();
        buffer.append("Delete from UserAuthorities ua where  ua.user.id = ");
        buffer.append(userId);
        final String queryString = buffer.toString();
        int deletedRows = getCurrentSession().createQuery(queryString)
                .executeUpdate();
        if (LOG.isDebugEnabled()) {
            LOG.debug("Number of Rows deleted:" + deletedRows);
        }

    }

}
