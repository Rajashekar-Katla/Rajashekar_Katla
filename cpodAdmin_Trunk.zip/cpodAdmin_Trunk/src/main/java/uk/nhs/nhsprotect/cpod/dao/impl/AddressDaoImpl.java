package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.AddressDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Address;

/**
 * @author AWheatley
 */
@Repository("addressDao")
public class AddressDaoImpl extends AbstractDaoImpl<Address, Long> implements
        AddressDao {

    /**
     * Logger instance for AddressDaoImpl.class.
     **/
    private static final Logger LOG = Logger.getLogger(AddressDaoImpl.class);

    /**
     * Address DAO.
     */
    protected AddressDaoImpl() {
        super(Address.class);
    }

    @Override
    public List<Address> findAddressByAndCriterias(Address address)
            throws CpodException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("findAddressByCriteria searcing for address vales ["
                    + address.toString() + "]");
        }

        String address1 = address.getAddress1();
        String address2 = address.getAddress2();
        String address3 = address.getAddress3();
        String address4 = address.getAddress4();
        String address5 = address.getAddress5();
        String postcode = address.getPostcode();

        Map<String, String> map = new HashMap<String, String>();
        map.put("address1", address1);
        map.put("address2", address2);
        map.put("address3", address3);
        map.put("address4", address4);
        map.put("address5", address5);
        map.put("postcode", postcode);

        return findByAndCriterias(map);
    }

    

}
