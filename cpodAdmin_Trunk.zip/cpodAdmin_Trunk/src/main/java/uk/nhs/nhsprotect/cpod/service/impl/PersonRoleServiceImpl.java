package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.PersonRoleDao;
import uk.nhs.nhsprotect.cpod.dao.ResponsibilityDao;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.Responsibility;
import uk.nhs.nhsprotect.cpod.service.PersonRoleService;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;
import uk.nhs.nhsprotect.cpod.util.CpodUtils;

/**
 * Implements PersonService.
 * @author awheatley
 * @version 0.1
 */
@Service("personRoleService")
@Transactional(readOnly = true)
public class PersonRoleServiceImpl extends
        AbstractServiceImpl<PersonRole, Long> implements PersonRoleService {

    /**
     * Logger instance for PersonServiceImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(PersonRoleServiceImpl.class);

    /**
     * personRoleDao Represents the DAO for Person.
     */
    @Autowired
    private PersonRoleDao personRoleDao;

   
    @Autowired
    private ResponsibilityDao responsibilityDao;

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.PersonService#findPersonByRef(java.lang
     * .String)
     */
    @Override
    public PersonRole findPersonRoleByRef(String personRef)
            throws CpodException {

        PersonRole result = null;
        List<PersonRole> personRoles = personRoleDao
                .findPersonRolesByPersonRef(personRef);

        // check results contain something
        if (!personRoles.isEmpty()) {

            // constraint on table "USERREFUNIQUE" prevents duplicates
            result = personRoles.get(0);

        } else {
            // No records returned
            throw new CpodNoResultsReturnedException(
                    "No Persons found with reference [" + personRef + "]");
        }
        return result;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.PersonService#findPersons(java.lang.String
     * )
     */
    @Override
    public List<PersonRole> findPersonRolesByRef(String personRef)
            throws CpodException {

        return personRoleDao.findPersonRolesByPersonRef(personRef);

    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#getDao()
     */
    @Override
    public AbstractDao<PersonRole, Long> getDao() {
        return personRoleDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#saveOrUpdate(
     * java.lang.Object)
     */
    @Override
    @Transactional(readOnly = false)
    public void saveOrUpdate(PersonRole personRole) throws CpodException {
        if (personRole.getId() == null) {
            // this is a save save the entity first before adding the other
            // objects...

            personRoleDao.saveOrUpdate(personRole);
            String personRef = null;
            // assign the person ref
            personRef = CpodUtils.getPersonTypeDescription(
                    personRole.getPersonType().getId()).toLowerCase();
            if (StringUtils.equalsIgnoreCase(personRef,
                    CPODConstants.PERSON_TYPE_EXTERNAL_DESC)) {
                // trim to 'ext'
                personRef = personRef.substring(0, 3);

            }
            personRef = personRef + personRole.getId();
            if (LOG.isDebugEnabled()) {
                LOG.debug("PersonRef for new entity is [" + personRef + "]");
            }
            personRole.setPersonRef(personRef);

        }

        personRoleDao.saveOrUpdate(personRole);

    }

    @Override
    public List<Responsibility> getResponsibilitiesForPersonRoleId(Long roleId) {

        return this.responsibilityDao.findResponsibilityByPersonRoleId(roleId);
    }

    @Override
    public List<PersonRole> findPersonRolesByPersonId(long personId)
            throws CpodException {

        List<PersonRole> personRoles = personRoleDao
                .findPersonRolesByPersonId(personId);
        return personRoles;
    }

}
