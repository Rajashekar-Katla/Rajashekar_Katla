/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.AddressLinkDao;
import uk.nhs.nhsprotect.cpod.model.AddressLink;

/**
 * AddressLinkDAO implementation.
 * @author ntones
 */
@Repository("addressLinkDao")
public class AddressLinkDaoImpl extends AbstractDaoImpl<AddressLink, Long>
        implements AddressLinkDao {
    /**
     * Address DAO.
     */
    protected AddressLinkDaoImpl() {
        super(AddressLink.class);
    }

    @Override
    public void saveOrUpdate(AddressLink entity) {
        entity = (AddressLink) getCurrentSession().merge(entity);
    }

}
