package uk.nhs.nhsprotect.cpod.controller.dto;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.sirs.model.SirsUserRO;
import uk.nhs.nhsprotect.srt.model.SrtUserRO;

/**
 * Transform object to allow easy displaying of SIRS User RO objects.
 * @author NTones
 */
@JsonPropertyOrder({ "status", "username", "personId", "fullname", "enabled",
        "email" })
public class SystemUserDTO implements Serializable {

    /**
     * Serial version UID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The user's username.
     */
    private String username;

    /**
     * The user's CPOD person Id.
     */
    private Long personId;

    /**
     * The user's fullname.
     */
    private String fullname;

    /**
     * The user's status.
     */
    private String status;

    /**
     * The user's email.
     */
    private String email;

    /**
     * The user enabled.
     */
    private int enabled;

    /**
     * The user ID. unique for a system
     */
    private Long userId;

    /**
     * Default no args constructor.
     */
    public SystemUserDTO() {
        // default
    }

    /**
     * Parameterised constructor.
     * @param username the username
     * @param personId the personId
     * @param fullname the fullname
     * @param status the status
     * @param email the email
     * @param enabled the enabled
     */
    public SystemUserDTO(final String username, final Long personId,
            final String fullname, final String status, final String email,
            final int enabled, final Long userId) {
        super();
        this.username = username;
        this.personId = personId;
        this.fullname = fullname;
        this.status = status;
        this.email = email;
        this.enabled = enabled;
        this.userId = userId;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the personId
     */
    public Long getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    /**
     * @return the fullname
     */
    public String getFullname() {
        return fullname;
    }

    /**
     * @param fullname the fullname to set
     */
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the enabled
     */
    public int getEnabled() {
        return enabled;
    }

    /**
     * @param enabled the enabled to set
     */
    public void setEnabled(int enabled) {
        this.enabled = enabled;
    }

    /**
     * @return the userId
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SystemUserDTO [username=" + username + ", personId=" + personId
                + ", fullname=" + fullname + ", status=" + status + ", email="
                + email + ", enabled=" + enabled + ", userId=" + userId + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((email == null) ? 0 : email.hashCode());
        result = prime * result + enabled;
        result = prime * result
                + ((fullname == null) ? 0 : fullname.hashCode());
        result = prime * result
                + ((personId == null) ? 0 : personId.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result
                + ((username == null) ? 0 : username.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SystemUserDTO other = (SystemUserDTO) obj;
        if (email == null) {
            if (other.email != null) {
                return false;
            }
        } else if (!email.equals(other.email)) {
            return false;
        }
        if (enabled != other.enabled) {
            return false;
        }
        if (fullname == null) {
            if (other.fullname != null) {
                return false;
            }
        } else if (!fullname.equals(other.fullname)) {
            return false;
        }
        if (personId == null) {
            if (other.personId != null) {
                return false;
            }
        } else if (!personId.equals(other.personId)) {
            return false;
        }
        if (status == null) {
            if (other.status != null) {
                return false;
            }
        } else if (!status.equals(other.status)) {
            return false;
        }
        if (username == null) {
            if (other.username != null) {
                return false;
            }
        } else if (!username.equals(other.username)) {
            return false;
        }
        return true;
    }

    /**
     * Utility method to create a SystemUserDTO instance from a SirsUserRO
     * object.
     * @param sirsUserRO the source object
     * @return a dto instance
     */
    public static SystemUserDTO createFromSirsUserRO(final SirsUserRO sirsUserRO) {
        SystemUserDTO dto = new SystemUserDTO();
        Person person = sirsUserRO.getPerson();
        if (person != null) {
            dto.setEmail(StringUtils.isEmpty(person.getEmailNHS()) ? person
                    .getEmailOther() : person.getEmailNHS());
            dto.setFullname(person.getfullName());
            dto.setPersonId(person.getId());
        }
        dto.setEnabled(sirsUserRO.getEnabled());
        dto.setStatus(sirsUserRO.getStatus());
        dto.setUsername(sirsUserRO.getUsername());
        return dto;

    }

    /**
     * Utility method to create a SystemUserDTO instance from a SrtUserRO
     * object.
     * @param srtUserRO the source object
     * @return a dto instance
     */
    public static SystemUserDTO createFromSrtUserRO(SrtUserRO srtUserRO) {
        // TODO refactor
        SystemUserDTO dto = new SystemUserDTO();
        Person person = srtUserRO.getPerson();
        if (person != null) {
            dto.setEmail(StringUtils.isEmpty(person.getEmailNHS()) ? person
                    .getEmailOther() : person.getEmailNHS());
            dto.setFullname(person.getfullName());
            dto.setPersonId(person.getId());
        }
        dto.setEnabled(srtUserRO.getEnabled());
        dto.setStatus(srtUserRO.getStatus());
        dto.setUsername(srtUserRO.getUsername());
        dto.setUserId(srtUserRO.getUserId());
        return dto;
    }
}
