package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * Class representing Person table (PERSON_TYPE_TBL).
 * @author awheatley
 */
@Entity
@Table(name = "PERSON_TYPE_TBL")
public class PersonType extends BaseEntity implements Serializable {

    /**
     * Serial Version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key identifier.
     */
    @Id
    @Column(name = "person_type_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "personTypeID")
    @GenericGenerator(strategy = "sequence", name = "personTypeID", parameters = { @Parameter(name = "sequence", value = "BE_ID_SEQNO") })
    private Long id;

    /**
     * Person Type.
     */
    @Column(name = "person_type")
    private String description;

    /**
     * Default Constructor.
     */
    public PersonType() {
        // default
    }

    /**
     * Parameterised Constructor.
     * @param id the person type id
     * @param description the description of person type
     */
    public PersonType(Long id, String description) {
        this.id = id;
        this.description = description;
    }

    /**
     * Parameterised Constructor. Uses the supplied string value as an id.
     * @param id the person type id
     */
    public PersonType(String id) {
        this.id = Long.parseLong(id);

    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Determines if person type is allowed to have responsibilities
     * @return Boolean if LCFS or LSMS
     */
    @Transient
    public boolean isAllowedResponsibility() {
        if (id.equals((long) CPODConstants.PERSON_TYPE_LCFS_ID)
                || id.equals((long) CPODConstants.PERSON_TYPE_LSMS_ID)
                || id.equals((long) CPODConstants.PERSON_TYPE_LSSP_ID)
                || id.equals((long) CPODConstants.PERSON_TYPE_LMS_ID)
                || id.equals((long) CPODConstants.PERSON_TYPE_SMD_ID)
                || id.equals((long) CPODConstants.PERSON_TYPE_SPEC_ID)) {
            return true;
        } else {
            return false;
        }
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        PersonType other = (PersonType) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "PersonType [id=" + id + ", description=" + description + "]";
    }

}
