package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.OrganisationType;

/**
 * Defines methods to be implemented for OrganisationType DAO functions.
 * @author awheatley
 */
public interface OrganisationTypeDao
    extends AbstractDao<OrganisationType, Long> {

    /**
     * Find Organisation Type by requesting Type.
     * @param type - e.g. NHS, NonNhs, HA, etc
     * @return - List of OrgnaisaionType
     * @throws CpodException for error
     */
    List<OrganisationType> findOrganisationTypeByType(String type)
            throws CpodException;
}
