package uk.nhs.nhsprotect.cpod.exception;

/**
 * Exception class for CPOD.
 * @author awheatley
 */

public class CpodException extends Exception {

    /**
     * SerialVersionUID for Serializable - NOT USED.
     */
    private static final long serialVersionUID = 1L;

    /**
     * CpodException Constructor.
     */
    public CpodException() {
    }

    /**
     * @param message message passed with exception.
     */
    public CpodException(String message) {
        super(message);

    }

    /**
     * @param cause Exception sent.
     */
    public CpodException(Throwable cause) {
        super(cause);

    }

    /**
     * @param message Message sent with exception
     * @param cause Exception Sent
     */
    public CpodException(String message, Throwable cause) {
        super(message, cause);

    }

}
