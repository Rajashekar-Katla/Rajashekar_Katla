package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Organisation Type.
 * @author AWheatley
 */
@Entity
@Table(name = "org_type_tbl")
public class OrganisationType extends BaseEntity implements Serializable {
    /**
     * Serial version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key identifier.
     */
    @Id
    @Column(name = "org_type_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "orgTypeId")
    @GenericGenerator(strategy = "sequence", name = "orgTypeId", parameters = { @Parameter(name = "sequence", value = "BE_ID_SEQNO") })
    private Long id;

    /**
     * OrganisationTypeName.
     */
    @Column(name = "org_name")
    private String organisationType;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the organisationType
     */
    public String getOrganisationType() {
        return organisationType;
    }

    /**
     * @param organisationType the organisationType to set
     */
    public void setOrganisationType(String organisationType) {
        this.organisationType = organisationType;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        OrganisationType other = (OrganisationType) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "OrganisationType [id=" + id + ", organisationType="
                + organisationType + "]";
    }

}
