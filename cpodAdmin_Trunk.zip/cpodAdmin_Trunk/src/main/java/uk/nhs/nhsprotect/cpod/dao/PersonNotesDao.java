package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.cpod.model.PersonNote;

/**
 * DAO for PersonNote Class.
 * @author awheatley
 */

public interface PersonNotesDao extends AbstractDao<PersonNote, Long> {
 

}
