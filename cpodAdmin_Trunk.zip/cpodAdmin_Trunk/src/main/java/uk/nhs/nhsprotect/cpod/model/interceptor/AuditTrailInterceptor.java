/**
 * 
 */
package uk.nhs.nhsprotect.cpod.model.interceptor;

import java.io.Serializable;
import java.util.Arrays;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.cpod.model.BaseEntity;
import uk.nhs.nhsprotect.cpod.security.UserContext;
import uk.nhs.nhsprotect.cpod.util.UserContextUtil;

/**
 * Intercepter that adds audit information to classes being modified. Class must
 * be a subclass of BaseEntity for intercepter to take effect.
 * @author ntones
 */
public class AuditTrailInterceptor extends EmptyInterceptor {

    private static final long serialVersionUID = -1019552502192151423L;
    @Autowired
    private UserContextUtil contextUtil;

    /*
     * (non-Javadoc)
     * @see org.hibernate.EmptyInterceptor#onFlushDirty(java.lang.Object,
     * java.io.Serializable, java.lang.Object[], java.lang.Object[],
     * java.lang.String[], org.hibernate.type.Type[])
     */
    @Override
    public boolean onFlushDirty(Object entity, Serializable id,
            Object[] currentState, Object[] previousState,
            String[] propertyNames, Type[] types) {
        if (entity instanceof BaseEntity) {

            if (null != contextUtil.getCurrentUser()) {
                setValue(currentState, propertyNames, "modifiedByUser",
                        contextUtil.getCurrentUser().getUsername());
            }
            return true;
        }
        return false;
    }

    /*
     * (non-Javadoc)
     * @see org.hibernate.EmptyInterceptor#onSave(java.lang.Object,
     * java.io.Serializable, java.lang.Object[], java.lang.String[],
     * org.hibernate.type.Type[])
     */
    @Override
    public boolean onSave(Object entity, Serializable id, Object[] state,
            String[] propertyNames, Type[] types) {
        if (entity instanceof BaseEntity) {
            if (null != UserContext.getCurrentUser()) {
                setValue(state, propertyNames, "modifiedByUser", UserContext
                        .getCurrentUser().getUsername());
            }
            return true;
        }
        return false;
    }

    /**
     * Method to replace a specified field value as desired.
     * @param currentState - the current object field values, each field held is
     *            an entry in the array.
     * @param propertyNames - the current objects field names, each field held
     *            is an entry in the array.
     * @param propertyToSet - the name of the field to replace
     * @param value - the new value to be applied to the specified field
     */
    private void setValue(Object[] currentState, String[] propertyNames,
            String propertyToSet, Object value) {
        if (propertyNames == null || propertyToSet == null) {
            return;
        }
        int index = Arrays.asList(propertyNames).indexOf(propertyToSet);
        if (index >= 0) {
            currentState[index] = value;
        }
    }

}
