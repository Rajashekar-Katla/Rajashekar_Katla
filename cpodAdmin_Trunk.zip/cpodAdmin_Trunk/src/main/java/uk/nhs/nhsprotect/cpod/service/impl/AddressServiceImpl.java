package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.AddressDao;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Address;
import uk.nhs.nhsprotect.cpod.service.AddressService;

/**
 * @author AWheatley
 */
@Service("addressService")
@Transactional(readOnly = true)
public class AddressServiceImpl extends AbstractServiceImpl<Address, Long>
        implements AddressService {
    /**
     * addressDao Represents the DAO for Address.
     */
    @Autowired
    private AddressDao addressDao;

    @Override
    public AbstractDao<Address, Long> getDao() {
        return addressDao;
    }

    @Override
    public Address findAddressByCriteria(Address address) throws CpodException {
        Address result = null;
        List<Address> addresses = addressDao.findAddressByAndCriterias(address);

        // check results contain something
        if (addresses != null && !addresses.isEmpty()) {
            // Some matches
            if (addresses.size() > 1) {
                // Non Unique set of result
                throw new CpodNonUniqueException(
                        "Multiple Addresses returned with reference ["
                                + address.toString() + "]");
            } else {
                // one record returned from database
                result = addresses.get(0);
            }
        } else {
            // No records returned
            throw new CpodNoResultsReturnedException(
                    "No Address found with reference [" + address.toString()
                            + "]");
        }
        return result;
    }

}
