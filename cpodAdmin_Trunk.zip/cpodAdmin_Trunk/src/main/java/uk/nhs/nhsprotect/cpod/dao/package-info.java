/** Dao Interface.
 */
package uk.nhs.nhsprotect.cpod.dao;
