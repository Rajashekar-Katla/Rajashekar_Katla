package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.NHSPSection;

/**
 * @author AWheatley
 */
public interface NHSPSectionService extends AbstractService<NHSPSection, Long> {
    /**
     * Find NHSPSection by Name.
     * @param name Address Type
     * @return NHSPSection
     * @throws CpodException on error
     **/
    NHSPSection findNhspSectionByName(String name) throws CpodException;
}
