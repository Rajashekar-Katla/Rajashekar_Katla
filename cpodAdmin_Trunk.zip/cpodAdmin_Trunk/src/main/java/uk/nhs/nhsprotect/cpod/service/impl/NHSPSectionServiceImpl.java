package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.NHSPSectionDao;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.NHSPSection;
import uk.nhs.nhsprotect.cpod.service.NHSPSectionService;

/**
 * @author AWheatley
 */
@Service("nhspSectionService")
@Transactional(readOnly = true)
public class NHSPSectionServiceImpl extends
        AbstractServiceImpl<NHSPSection, Long> implements NHSPSectionService {

    /**
     * nshpSectionDao Represents the DAO for NHSPSection.
     */
    @Autowired
    private NHSPSectionDao nhspSectionDao;

    @Override
    public AbstractDao<NHSPSection, Long> getDao() {
        return nhspSectionDao;
    }

    @Override
    public NHSPSection findNhspSectionByName(String name) throws CpodException {
        List<NHSPSection> found = nhspSectionDao
                .findNhspSectionByCriteria(name);

        if (found != null && !found.isEmpty()) {
            // multiple records found
            if (found.size() > 1) {
                throw new CpodNonUniqueException(
                        "More than one NHSPSection with SectionName = [" + name
                                + "]");
            } else {
                // one record found
                return found.get(0);
            }
        } else {
            // No results found
            throw new CpodNoResultsReturnedException(
                    "No results returned for NHSPSection with Sectionname = ["
                            + name + "]");
        }

    }

}
