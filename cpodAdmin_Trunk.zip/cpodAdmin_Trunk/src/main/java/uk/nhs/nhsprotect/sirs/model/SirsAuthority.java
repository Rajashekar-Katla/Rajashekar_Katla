package uk.nhs.nhsprotect.sirs.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "authorities_new")
public class SirsAuthority implements Serializable {

    private static final long serialVersionUID = 10000668L;

    @Id
    @Basic
    @Column(name = "AUTHORITY_ID")
    private Long authorityID;

    @Basic
    @Column(name = "AUTHORITY_NAME")
    private String authorityName;

    @Basic
    @Column(name = "AUTHORITY_DESCRIPTION")
    private String authorityDescription;

    public SirsAuthority() {
    }

    public Long getAuthorityID() {
        return authorityID;
    }

    public void setAuthorityID(Long authorityID) {
        this.authorityID = authorityID;
    }

    public String getAuthorityName() {
        return authorityName;
    }

    public void setAuthorityName(String authorityName) {
        this.authorityName = authorityName;
    }

    public String getAuthorityDescription() {
        return authorityDescription;
    }

    public void setAuthorityDescription(String authorityDescription) {
        this.authorityDescription = authorityDescription;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SirsAuthority [authorityID=" + authorityID + ", authorityName="
                + authorityName + ", authorityDescription="
                + authorityDescription + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime
                * result
                + ((authorityDescription == null) ? 0 : authorityDescription
                        .hashCode());
        result = prime * result
                + ((authorityID == null) ? 0 : authorityID.hashCode());
        result = prime * result
                + ((authorityName == null) ? 0 : authorityName.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof SirsAuthority)) {
            return false;
        }
        SirsAuthority other = (SirsAuthority) obj;
        if (authorityDescription == null) {
            if (other.authorityDescription != null) {
                return false;
            }
        } else if (!authorityDescription.equals(other.authorityDescription)) {
            return false;
        }
        if (authorityID == null) {
            if (other.authorityID != null) {
                return false;
            }
        } else if (!authorityID.equals(other.authorityID)) {
            return false;
        }
        if (authorityName == null) {
            if (other.authorityName != null) {
                return false;
            }
        } else if (!authorityName.equals(other.authorityName)) {
            return false;
        }
        return true;
    }

}
