package uk.nhs.nhsprotect.cpod.dao.exception;

import uk.nhs.nhsprotect.cpod.exception.CpodException;

/**
 * Exception to indicate that multiple results were returned when a single
 * unique result is expected.
 * @author awheatley
 */
public class CpodNonUniqueException extends CpodException {

    /**
     * Serial Number for Class.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Default Constructor.
     */
    public CpodNonUniqueException() {
        // default
    }

    /**
     * Constructor with passed in message.
     * @param message Description of Error
     */
    public CpodNonUniqueException(String message) {
        super(message);
    }

    /**
     * Constructor with cause of throwable.
     * @param cause type
     */
    public CpodNonUniqueException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor with cause of throwable.
     * @param message Description of Error
     * @param cause type
     */
    public CpodNonUniqueException(String message, Throwable cause) {
        super(message, cause);
    }

}
