/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.service.PersonRoleService;

/**
 * Spring controller class to provide links to roles related pages.
 * @author AWheatley
 */
@Controller
public class PersonRoleController extends CpodBaseController {

    /**
     * Logger instance for CommonPagesController.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(PersonRoleController.class);

    /**
     * PersonRole reference.
     */
    @Autowired
    private PersonRoleService personRoleService;

    /**
     * Method to handle requests to save or update a personRole object.
     * @param user the person object to save
     * @param modelMap the current model
     * @return String tiles view definition
     * @throws Exception on error
     */
    @RequestMapping(value = { "/savePersonRole" }, method = RequestMethod.POST)
    public String saveOrUpdatePersonRole(@ModelAttribute PersonRole personRole,
            ModelMap modelMap, RedirectAttributes redirectAttrs)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("saveOrUpdatePerson person [" + personRole + "]");
        }

        personRoleService.saveOrUpdate(personRole);
        redirectAttrs.addAttribute("id", personRole.getPersonId().toString());
        return "redirect:/viewPerson";
    }
}
