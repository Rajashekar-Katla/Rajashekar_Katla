package uk.nhs.nhsprotect.cpod.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Criterion;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.service.AbstractService;

/**
 * Service class to provide basic CRUD functions to SRT database entities.
 * @param <T> the Class type being used
 * @param <ID> the Class type of the PK
 * @author ntones
 */
@Transactional(value = "srtTransactionManager", readOnly = true, propagation = Propagation.REQUIRED)
public abstract class SrtAbstractServiceImpl<T, ID extends Serializable>
        implements AbstractService<T, ID> {

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#save(java.lang.Object)
     */
    @Override
    @Transactional(value = "srtTransactionManager", readOnly = false)
    public ID save(T entity) throws CpodException {
        return getDao().save(entity);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#delete(java.lang.Object)
     */
    @Override
    @Transactional(value = "srtTransactionManager", readOnly = false)
    public void delete(T entity) throws CpodException {
        getDao().delete(entity);

    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.AbstractService#findAll()
     */
    @Override
    @Transactional(value = "srtTransactionManager", readOnly = true)
    public List<T> findAll() throws CpodException {
        return getDao().findAll();
    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.AbstractService#deleteAll()
     */
    @Override
    @Transactional(value = "srtTransactionManager", readOnly = false)
    public void deleteAll() throws CpodException {
        throw new CpodException("Detele All SRT method is not implemented");

    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#saveOrUpdate(java.lang
     * .Object)
     */
    @Override
    @Transactional(value = "srtTransactionManager", readOnly = false)
    public void saveOrUpdate(T entity) throws CpodException {
        getDao().saveOrUpdate(entity);

    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#findById(java.io.Serializable
     * )
     */
    @Override
    public T findById(ID id) throws CpodException {
        T result = getDao().findById(id);
        // refresh
        if (result != null) {
            getDao().getCurrentSession().refresh(result);
        }
        return result;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#update(java.lang.Object)
     */
    @Override
    @Transactional(value = "srtTransactionManager", readOnly = false)
    public void update(T entity) throws CpodException {
        getDao().update(entity);

    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#findByCriteria(org.hibernate
     * .criterion.Criterion)
     */
    @Override
    @Transactional(value = "srtTransactionManager", readOnly = true)
    public List<T> findByCriteria(Criterion criterion) throws CpodException {
        return getDao().findByCriteria(criterion);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#findByCriterias(java.util
     * .Map)
     */
    @Override
    @Transactional(value = "srtTransactionManager", readOnly = true)
    public List<T> findByAndCriterias(Map<String, String> searchCriteria) {
        return getDao().findByAndCriterias(searchCriteria);
    }

    /**
     * Abstract method to return the typed Dao. Concrete instances of this class
     * must provide a valid implementation of this method
     * @return AbstractDao<T, ID> The Dao instance of the implementing class
     */
    public abstract AbstractDao<T, ID> getDao();

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#merge(java.lang.Object)
     */
    @Override
    @Transactional(value = "srtTransactionManager", readOnly = false)
    public T merge(T entity) {

        return getDao().merge(entity);
    }

}
