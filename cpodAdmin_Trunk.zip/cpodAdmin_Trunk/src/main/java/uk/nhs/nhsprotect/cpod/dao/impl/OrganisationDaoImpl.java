package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.controller.dto.OrganisationResult;
import uk.nhs.nhsprotect.cpod.dao.OrganisationDao;
import uk.nhs.nhsprotect.cpod.model.Organisation;

/**
 * @author awheatley
 */
@Repository("organisationDao")
public class OrganisationDaoImpl extends AbstractDaoImpl<Organisation, Long>
        implements OrganisationDao {

    /**
     * Logger instance for OrganisationDaoImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(OrganisationDaoImpl.class);

    /**
     * Organisation DAO Implementation Constructor.
     */
    protected OrganisationDaoImpl() {
        super(Organisation.class);

    }

    @Override
    public List<Organisation> findorganisationsByOrganisationsRef(String orgCode) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("findorganisationsByOrganisationsRef searching for ref ["
                    + orgCode + "]");
        }
        return findByCriteria(Restrictions.ilike("orgCode",
                orgCode.toLowerCase(), MatchMode.START));

    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.dao.OrganisationDao#
     * getOrganisationsForResponsibilities(java.lang.String, java.lang.Long)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<OrganisationResult> getOrganisationsForResponsibilities(
            String query, Long personId) {

        // restrict to those orgs not already in persons resps
        Query hibQuery = null;

        StringBuffer hqlBuffer = new StringBuffer();
        hqlBuffer
                .append("select orgName as orgName, orgCode as orgCode, id as orgId ");
        hqlBuffer
                .append("from Organisation as org where (lower(org.orgName) like :orgname or lower(org.orgCode) = :orgcode) ");
        hqlBuffer
                .append("and org.id not in (select resp.organisation from Responsibility as resp where resp.personRole.id = :personId) ");
        hqlBuffer.append("order by orgName asc");
        hibQuery = getCurrentSession().createQuery(hqlBuffer.toString());
        // use JPA-style parameter substitution
        hibQuery.setString("orgname", '%' + query.toLowerCase() + '%');
        hibQuery.setString("orgcode", query.toLowerCase());
        hibQuery.setLong("personId", personId);

        return (List<OrganisationResult>) hibQuery.setResultTransformer(
                Transformers.aliasToBean(OrganisationResult.class)).list();

    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.dao.OrganisationDao#
     * getOrganisationsForPersons(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<OrganisationResult> getOrganisationsForPersons(String query) {

        // restrict to those orgs not already in persons resps
        Query hibQuery = null;

        StringBuffer hqlBuffer = new StringBuffer();
        hqlBuffer
                .append("select orgName as orgName, orgCode as orgCode, id as orgId, ");
        hqlBuffer
                .append("address.address1 as address1, address.address2 as address2, address.address3 as address3, address.address4 as address4, address.address5 as address5, address.postcode as postcode ");
        hqlBuffer
                .append("from Organisation as org where (lower(org.orgName) like :orgname or lower(org.orgCode) = :orgcode) and org.closeDate > sysdate order by orgName asc");

        hibQuery = getCurrentSession().createQuery(hqlBuffer.toString());
        // use JPA-style parameter substitution
        hibQuery.setString("orgname", '%' + query.toLowerCase() + '%');
        hibQuery.setString("orgcode", query.toLowerCase());

        return (List<OrganisationResult>) hibQuery.setResultTransformer(
                Transformers.aliasToBean(OrganisationResult.class)).list();

    }
}
