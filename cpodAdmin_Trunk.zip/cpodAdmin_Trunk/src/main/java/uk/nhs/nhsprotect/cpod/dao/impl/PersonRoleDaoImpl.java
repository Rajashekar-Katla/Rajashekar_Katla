package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.PersonRoleDao;
import uk.nhs.nhsprotect.cpod.dao.exception.DaoNotImplementedException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.PersonRole;

/**
 * @author awheatley
 */
@Repository("personRoleDao")
public class PersonRoleDaoImpl extends AbstractDaoImpl<PersonRole, Long>
        implements PersonRoleDao {

    /**
     * Log4J instance for PersonDaoImpl.class.
     **/
    private static final Logger LOG = Logger.getLogger(PersonRoleDaoImpl.class);

    /**
     * Person DAO Implementation Constructor.
     */
    protected PersonRoleDaoImpl() {
        super(PersonRole.class);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.dao.PersonRoleDao#findPersonRolesByPersonRef(java
     * .lang.String)
     */
    @Override
    public List<PersonRole> findPersonRolesByPersonRef(String personRef)
            throws CpodException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("findPersonsByPersonRef searcing for person ref ["
                    + personRef + "]");
        }
        return findByCriteria(Restrictions.ilike("personRef", personRef,
                MatchMode.START));
    }

    public List<PersonRole> findPersonRolesByPersonId(Long personId) {

        return findByCriteria(Restrictions.eq("person.id", personId));

    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.dao.impl.AbstractDaoImpl#deleteAll()
     */
    @Override
    public int deleteAll() throws DaoNotImplementedException {
        throw new DaoNotImplementedException(
                "Not implemented for person object");
    }

}
