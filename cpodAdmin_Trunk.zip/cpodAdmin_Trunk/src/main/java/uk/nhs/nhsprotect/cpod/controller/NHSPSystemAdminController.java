/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.nhsprotect.cpod.model.NHSPSystem;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;
import uk.nhs.nhsprotect.cpod.service.NHSPSystemService;
import uk.nhs.nhsprotect.cpod.service.PersonTypeService;
import uk.nhs.nhsprotect.cpod.service.SystemPersonTypeService;

/**
 * Controller class for handling requests relating to system user
 * administration.
 * @author ntones
 */
@Controller
public class NHSPSystemAdminController extends CpodBaseController {

    /**
     * Logger instance for NHSPSystemAdminController.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(NHSPSystemAdminController.class);

    @Autowired
    private NHSPSystemService nhspSystemService;

    @Autowired
    private PersonTypeService personTypeService;

    @Autowired
    private SystemPersonTypeService systemPersonTypeService;

    /**
     * Handles the edit System request, performs search of all systems.
     * @param modelMap the model map
     * @return value of forward depending on query outcome
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/system/search" }, method = RequestMethod.GET)
    public String searchNHSPSystems(ModelMap modelMap) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("searchNHSPSystem starts ");
        }

        List<NHSPSystem> systems = nhspSystemService.findAll();

        if (systems.isEmpty()) {
            modelMap.addAttribute(
                    "warnMessage",
                    getMessageSource().getMessage("system.search.none", null,
                            null));
            return "system-results";
        }
        modelMap.addAttribute("systems", systems);

        // add elements for new system
        modelMap.addAttribute("nhspSystem", new NHSPSystem());
        List<PersonType> personTypes = personTypeService.findAll();
        modelMap.addAttribute("personTypes", personTypes);

        return "system-results";
    }

    /**
     * Handles the view System request
     * @param modelMap the model map
     * @return value of forward depending on query outcome
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/system/view/{systemId}" }, method = RequestMethod.GET)
    public String viewNHSPSystem(@PathVariable Long systemId, ModelMap modelMap)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("viewNHSPSystem starts ");
        }

        NHSPSystem nhspSystem = nhspSystemService.findById(systemId);

        if (nhspSystem == null) {
            modelMap.addAttribute(
                    "warnMessage",
                    getMessageSource().getMessage("system.search.none", null,
                            null));
            return "system-results";
        }
        modelMap.addAttribute("nhspSystem", nhspSystem);

        List<PersonType> personTypes = personTypeService.findAll();
        SystemPersonType systemPersonType = new SystemPersonType();
        modelMap.addAttribute("personTypes", personTypes);
        modelMap.addAttribute("systemPersonType", systemPersonType);

        return "system-view";
    }

    /**
     * Handles the view new System request
     * @param modelMap the model map
     * @return value of forward depending on query outcome
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/system/view" }, method = RequestMethod.GET)
    public String viewNewNHSPSystem(ModelMap modelMap) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("viewNewNHSPSystem starts ");
        }

        NHSPSystem nhspSystem = new NHSPSystem();

        modelMap.addAttribute("nhspSystem", nhspSystem);

        List<PersonType> personTypes = personTypeService.findAll();

        modelMap.addAttribute("personTypes", personTypes);

        modelMap.addAttribute("newSystem", true);

        return "system-new";
    }

    /**
     * Handles the save new System request
     * @param modelMap the model map
     * @return value of forward depending on query outcome
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/system/save" }, method = RequestMethod.POST)
    public ModelAndView saveNewNHSPSystem(
            @ModelAttribute NHSPSystem nhspSystem, ModelMap modelMap)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("saveNewNHSPSystem starts ");
        }

        nhspSystemService.save(nhspSystem);

        return new ModelAndView("redirect:/admin/system/search");
    }

    @RequestMapping(value = { "/admin/system/personType/edit" }, method = RequestMethod.POST)
    public @ResponseBody String editSystemPersonType(
            @ModelAttribute SystemPersonType systemPersonType) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("editSystemPersonType starts, Received from request"
                    + systemPersonType);
        }

        if (systemPersonType.getId() == null) {
            // this is a new object so need to add to system too
            NHSPSystem system = nhspSystemService.findById(systemPersonType
                    .getSystem().getId());
            system.addSystemPersonType(systemPersonType);
            nhspSystemService.saveOrUpdate(system);
        }
        // update
        try {
            systemPersonTypeService.saveOrUpdate(systemPersonType);
        } catch (DataIntegrityViolationException exception) {
            return "ERROR: entry already exists.";
        }

        return "Person Type Edited";
    }

    @RequestMapping(value = { "/admin/system/personType/delete" }, method = RequestMethod.POST)
    public @ResponseBody String deleteSystemPersonType(
            @ModelAttribute SystemPersonType systemPersonType) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("deleteSystemPersonType starts, Received from request"
                    + systemPersonType);
        }

        // update
        systemPersonTypeService.delete(systemPersonType);

        return "Person Type deleted";
    }

}
