package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.PersonType;

/** Person Type DAO Interface.
 * @author awheatley
 */
public interface PersonTypeDao extends AbstractDao<PersonType, Long> {


    /** Find Person Type record by specifying the type.
     * @param type Person Type (i.e. LCFS)
     * @return List of personType
     * @throws CpodException for error
     */
    List<PersonType> findPersonTypeByType(String type) throws CpodException;

}
