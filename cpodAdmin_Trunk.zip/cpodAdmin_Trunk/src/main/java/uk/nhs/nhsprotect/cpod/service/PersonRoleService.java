package uk.nhs.nhsprotect.cpod.service;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.Responsibility;

/**
 * Service Layer Methods for dealing with specific tasks for the Person Bean.
 * @author awheatley
 */

public interface PersonRoleService extends AbstractService<PersonRole, Long> {
    /**
     * Method to retrieve a person based on person reference. Throws non-unique
     * exceptions if multiple or no records found.
     * @param personRef - Person's knownas id - e.g lcfs1234
     * @return person if a single record is found
     * @throws CpodException on error
     */
    PersonRole findPersonRoleByRef(String personRef) throws CpodException;

    /**
     * Find Person Roles for a single Person ID
     * @param personId ID
     * @return List<PersonRole>
     * @throws CpodException
     */
    List<PersonRole> findPersonRolesByPersonId(long personId)
            throws CpodException;

    /**
     * Find all persons based on personRef.
     * @param personRef - Person's knownas id - e.g lcfs1234
     * @return List of persons
     * @throws CpodException for error
     */
    List<PersonRole> findPersonRolesByRef(String personRef)
            throws CpodException;

    /**
     * Get Responsibilities for PersonRole
     * @param roleId
     * @return List<Responsibility>
     */
    List<Responsibility> getResponsibilitiesForPersonRoleId(Long roleId);

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#saveOrUpdate(java.lang
     * .Object)
     */
    @Override
    void saveOrUpdate(PersonRole entity) throws CpodException;

}
