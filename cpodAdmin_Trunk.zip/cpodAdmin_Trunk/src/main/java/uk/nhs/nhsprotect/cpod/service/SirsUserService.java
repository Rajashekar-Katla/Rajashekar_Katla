/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.sirs.model.SirsUser;

/**
 * Methods for managing and maintaining SIRS user accounts.
 * @author ibandi
 */
public interface SirsUserService extends AbstractService<SirsUser, String> {

    /**
     * Find User by reference number.
     * @param referenceNumber
     * @return
     */
    SirsUser findByReferenceNumber(String referenceNumber);

    /**
     * @param userRef
     */
    void deleteByUserName(String userRef);

}
