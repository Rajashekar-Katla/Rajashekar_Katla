/**
 * 
 */
package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Represents an NHS Protect system.
 * @author ntones
 */
@Entity
@Table(name = "SYSTEM_TBL")
public class NHSPSystem implements Serializable {

    /**
     * serial version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key field.
     */
    @Id
    @Column(name = "system_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "systemId")
    @GenericGenerator(strategy = "sequence", name = "systemId", parameters = { @Parameter(name = "sequence", value = "SYSTEM_ID_SEQNO") })
    private Long id;

    /**
     * The name of the system.
     */
    @Column(name = "system_name")
    private String name;

    /**
     * List of permitted system personTypes.
     */
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "system", cascade = {
            CascadeType.REMOVE, CascadeType.PERSIST })
    private List<SystemPersonType> systemPersonTypes = new ArrayList<SystemPersonType>();

    @Transient
    private List<PersonType> personTypes = new ArrayList<PersonType>();

    @Transient
    private String selectedStatus;

    /**
     * Default constructor.
     */
    public NHSPSystem() {

    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the systemPersonTypes
     */
    public List<SystemPersonType> getSystemPersonTypes() {
        return systemPersonTypes;
    }

    /**
     * @param systemPersonTypes the systemPersonTypes to set
     */
    public void setSystemPersonTypes(List<SystemPersonType> systemPersonTypes) {
        this.systemPersonTypes = systemPersonTypes;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        NHSPSystem other = (NHSPSystem) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    /**
     * Utility method to add person type to this system.
     * @param personType to add.
     */
    public void addSystemPersonType(SystemPersonType personType) {
        personType.setSystem(this);
        this.getSystemPersonTypes().add(personType);
    }

    /**
     * Utility method to remove a person type from this system.
     * @param personType to remove
     */
    public void removeSystemPersonType(SystemPersonType personType) {
        personType.setSystem(null);
        this.getSystemPersonTypes().remove(personType);
    }

    /**
     * @return the personTypes
     */
    public List<PersonType> getPersonTypes() {
        return personTypes;
    }

    /**
     * @param personTypes the personTypes to set
     */
    public void setPersonTypes(List<PersonType> personTypes) {
        this.personTypes = personTypes;
    }

    /**
     * @return the selectedStatus
     */
    public String getSelectedStatus() {
        return selectedStatus;
    }

    /**
     * @param selectedStatus the selectedStatus to set
     */
    public void setSelectedStatus(String selectedStatus) {
        this.selectedStatus = selectedStatus;
    }

}
