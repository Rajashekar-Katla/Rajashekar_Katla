/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller;

import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import uk.nhs.nhsprotect.cpod.model.authentication.Authority;
import uk.nhs.nhsprotect.cpod.model.authentication.User;
import uk.nhs.nhsprotect.cpod.service.AuthorityService;
import uk.nhs.nhsprotect.cpod.service.UserService;

/**
 * Spring controller class to manage requests relating to CPOD user admin
 * functions.
 * @author ntones
 */
@Controller
public class CpodUserAdminController extends CpodBaseController {

    /**
     * Logger instance for CommonPagesController.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(CpodUserAdminController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private AuthorityService authorityService;

    /**
     * Handles the edit user request, performs search of all application users.
     * @param modelMap the model map
     * @return value of forward depending on query outcome
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/cpod/searchUser" }, method = RequestMethod.GET)
    public String searchUser(ModelMap modelMap) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("searchUser starts ");
        }

        List<User> users = userService.findAll();
        for (Iterator<User> iterator = users.iterator(); iterator.hasNext();) {
            User user = iterator.next();
            // do not allow the user delete/edit them self
            if (user.getUsername().equals(getUserConextUtil().getUsername())) {
                iterator.remove();
            }
        }
        if (users.isEmpty()) {
            modelMap.addAttribute(
                    "warnMessage",
                    getMessageSource().getMessage("user.search.none", null,
                            null));
            return "user-results";
        } else {
            if (users.size() == 1) {
                // send to the viewUser method to display single user page
                return viewUser(modelMap, users.get(0).getId());
            }
            modelMap.addAttribute("users", users);
        }

        return "user-results";
    }

    /**
     * Method to handle requests to delete a specific CPOD user.
     * @param modelMap the current model
     * @param userId the requested id for deletion
     * @return ResponseBody on success
     * @throws Exception on error.
     */
    @RequestMapping(value = { "/admin/cpod/deleteUser" }, method = RequestMethod.GET)
    public @ResponseBody
    String deleteUser(ModelMap modelMap, @RequestParam(value = "id") Long userId)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("deleteUser id [ " + userId + "]");
        }

        userService.delete(userId);
        // redirect to refresh search results
        return "User Deleted";
    }

    /**
     * Method to handle requests to edit CPOD users.
     * @param modelMap the current model
     * @param userId the requested id for edit
     * @return String tiles view name
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/cpod/viewUser" }, method = RequestMethod.GET)
    public String viewUser(ModelMap modelMap,
            @RequestParam(value = "id", required = false) Long userId)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("viewUser id[ " + userId + "]");
        }

        List<Authority> authorities = authorityService.findAll();
        modelMap.put("authorities", authorities);
        User user = null;
        if (userId != null && userId != 0) {
            user = userService.findById(userId);
        } else {
            user = new User();
        }
        // check that the user is not trying to edit them self
        if (StringUtils.isNotEmpty(user.getUsername())
                && user.getUsername().equals(getUserConextUtil().getUsername())) {
            LOG.error("Attempt to edit own user account.");
            modelMap.put("errorMessage", "Attempt to edit own user account.");
        } else {
            modelMap.put("user", user);
        }

        return "user-view";
    }

    /**
     * Method to handle requests to save or update a user object.
     * @param user the user object to save
     * @param modelMap the current model
     * @return String tiles view definition
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/cpod/saveUser" }, method = RequestMethod.POST)
    public String saveOrUpdateUser(@ModelAttribute User user, ModelMap modelMap)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("saveOrUpdateUser user [" + user + "]");
        }

        userService.saveOrUpdate(user);

        List<Authority> authorities = authorityService.findAll();
        modelMap.put("authorities", authorities);

        modelMap.put("user", user);
        modelMap.put("successMessage", "User saved.");

        return "user-view";
    }

    /**
     * Method to handle password reset requests ajaxwise for CPOD Users
     * @param userId of user to reset password for
     * @return Success message
     * @throws Exception on error
     */
    @RequestMapping(value = "admin/cpod/resetUserPassword", method = RequestMethod.GET)
    public @ResponseBody
    String resetUserPassword(@RequestParam(value = "id") Long userId)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("resetUserPassword id[ " + userId + "]");
        }

        userService.changePassword(userId, null);
        // redirect to refresh search results
        return "Password Reset";
    }

    /**
     * Method to handle initial request to change a password.
     * @param modelMap current modelmap
     * @return password-change ref
     * @throws Exception on error
     */
    @RequestMapping(value = "changePassword", method = RequestMethod.GET)
    public String prepareChangePassword(ModelMap modelMap) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("prepareChangePassword starts");
        }
        User user = getUserConextUtil().getCurrentUser().getUser();
        modelMap.put("user", user);

        return "password-change";
    }

    /**
     * Method to handle password change requests for all CPOD admin tool users.
     * @param modelMap current modelMap
     * @param userId for user changing password
     * @return password change page reference
     * @throws Exception on error
     */
    @RequestMapping(value = "changePassword", method = RequestMethod.POST)
    public String changePassword(@ModelAttribute User user, ModelMap modelMap,
            @RequestParam(value = "oldPassword") String oldPassword,
            @RequestParam(value = "confirmPassword") String confirmPassword)
            throws Exception {

        if (LOG.isDebugEnabled()) {
            LOG.debug("changePassword starts");
        }

        User oldUser = userService.findById(user.getId());

        if (!getPasswordEncoder().matches(oldPassword, oldUser.getPassword())) {
            modelMap.put("user", oldUser);
            modelMap.put(
                    "errorMessage",
                    getMessageSource().getMessage("password.error.oldpassword",
                            null, null));
            return "password-change";
        } else if (!StringUtils.equals(confirmPassword, user.getPassword())) {
            modelMap.put("user", oldUser);
            modelMap.put(
                    "errorMessage",
                    getMessageSource().getMessage("password.error.noconfirm",
                            null, null));
            return "password-change";
        } else if (oldPassword.equals(user.getPassword())) {
            modelMap.put("user", oldUser);
            modelMap.put(
                    "errorMessage",
                    getMessageSource().getMessage("password.error.nochange",
                            null, null));
            return "password-change";
        } else {
            if (!strongPassword(user.getPassword())) {
                modelMap.put("user", oldUser);
                modelMap.put(
                        "errorMessage",
                        getMessageSource().getMessage("password.error.complex",
                                null, null));
                return "password-change";
            }
        }

        userService.changePassword(user.getId(), user.getPassword());

        modelMap.put("successMessage",
                getMessageSource().getMessage("password.success", null, null));
        return "password-change";
    }

    /**
     * Utility method to ensure that the entered password meets the following
     * criteria: ( # Start of group (?=.*\d) # must contains one digit from 0-9
     * (?=.*[a-z]) # must contains one lowercase characters (?=.*[A-Z]) # must
     * contains one uppercase characters (?=.*[@#$%!]) # must contains one
     * special symbols in the list "@#$%" . # match anything with previous
     * condition checking {6,20} # length at least 6 characters and maximum of
     * 20 ) # End of group.
     * @param password to check
     * @return true if password is 'strong'
     */
    private boolean strongPassword(String password) {
        Pattern pattern = Pattern
                .compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%!]).{6,20})");
        Matcher matcher = pattern.matcher(password);

        return matcher.matches();
    }
}
