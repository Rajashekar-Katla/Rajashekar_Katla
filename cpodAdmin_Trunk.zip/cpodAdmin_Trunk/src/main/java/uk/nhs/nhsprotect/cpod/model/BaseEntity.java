/**
 * 
 */
package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * Base entity class that other classes extend to gain common attributes, i.e.
 * auditing.
 * 
 * @author ntones
 */
@MappedSuperclass
public abstract class BaseEntity implements Serializable {

    /**
     * serial UID
     */
    private static final long serialVersionUID = 1L;

    /**
     * User modifying record.
     */
    @Column(name = "MODIFIED_BY_USER")
    private String modifiedByUser;

    /**
     * @return the modifiedByUser
     */
    public String getModifiedByUser() {
        return modifiedByUser;
    }

    /**
     * @param modifiedByUser
     *            the modifiedByUser to set
     */
    public void setModifiedByUser(String modifiedByUser) {
        this.modifiedByUser = modifiedByUser;
    }

}
