package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.PersonTypeDao;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.service.PersonTypeService;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * @author AWheatley
 */
@Service("personTypeService")
@Transactional(readOnly = true)
public class PersonTypeServiceImpl extends
        AbstractServiceImpl<PersonType, Long> implements PersonTypeService {

    /**
     * Gives access to the personTypeDao.
     */
    @Autowired
    private PersonTypeDao personTypeDao;

    @Override
    public AbstractDao<PersonType, Long> getDao() {
        return personTypeDao;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * uk.nhs.nhsprotect.cpod.service.PersonTypeService#findPersonTypeByType
     * (java.lang.String)
     */
    @Override
    public PersonType findPersonTypeByType(String type) throws CpodException {
        List<PersonType> found = personTypeDao.findPersonTypeByType(type);

        if (found != null && !found.isEmpty()) {
            // multiple records found
            if (found.size() > 1) {
                throw new CpodNonUniqueException(
                        "More than one PersonType with PersonType = [" + type
                                + "]");
            } else {
                // one record found
                return found.get(0);
            }
        } else {
            // No results found
            throw new CpodNoResultsReturnedException(
                    "No results returned for PersonType with personType = ["
                            + type + "]");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * uk.nhs.nhsprotect.cpod.service.PersonTypeService#getPersonTypesForUser()
     */
    @Override
    public List<PersonType> getPersonTypesForUser() throws CpodException {
     
        //get the current logged in user
        Authentication auth = SecurityContextHolder.getContext()
                .getAuthentication();
        List<PersonType> allTypes = new ArrayList<PersonType>();
        for (GrantedAuthority authority : auth.getAuthorities()) {
            if (authority.getAuthority().equals(CPODConstants.SIRS_ADMIN_ROLE)) {
                // can add SIRS Trust user roles LMS, LSSP, SPEC, SMD
                allTypes.add(new PersonType(
                        (long) CPODConstants.PERSON_TYPE_LMS_ID,
                        CPODConstants.PERSON_TYPE_LMS_DESC));
                allTypes.add(new PersonType(
                        (long) CPODConstants.PERSON_TYPE_LSSP_ID,
                        CPODConstants.PERSON_TYPE_LSSP_DESC));
                allTypes.add(new PersonType(
                        (long) CPODConstants.PERSON_TYPE_SPEC_ID,
                        CPODConstants.PERSON_TYPE_SPEC_DESC));
                allTypes.add(new PersonType(
                        (long) CPODConstants.PERSON_TYPE_SMD_ID,
                        CPODConstants.PERSON_TYPE_SMD_DESC));

            } else if (authority.getAuthority()
                    .equals(CPODConstants.ADMIN_ROLE)) {
                // can add all roles
                return getDao().findAll();

            } else if (authority.getAuthority().equals(
                    CPODConstants.LSDS_ADMIN_ROLE)) {
                // can add LCFS/LSMS roles
                allTypes.add(new PersonType(
                        (long) CPODConstants.PERSON_TYPE_LSMS_ID,
                        CPODConstants.PERSON_TYPE_LSMS_DESC));
                allTypes.add(new PersonType(
                        (long) CPODConstants.PERSON_TYPE_LCFS_ID,
                        CPODConstants.PERSON_TYPE_LCFS_DESC));
            } else if (authority.getAuthority().equals(
                    CPODConstants.TRAINING_ADMIN_ROLE)) {
                allTypes.add(new PersonType(
                        (long) CPODConstants.PERSON_TYPE_EXTERNAL_ID,
                        CPODConstants.PERSON_TYPE_EXTERNAL_DESC));
            }
        }
        // TODO if we have a DB implementation of this.
        // = ((PersonTypeDao) getDao())
        // .getPersonTypesForUser(auth);

        return allTypes;

    }
}
