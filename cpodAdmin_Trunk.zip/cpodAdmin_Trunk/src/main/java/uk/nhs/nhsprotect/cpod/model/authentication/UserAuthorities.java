package uk.nhs.nhsprotect.cpod.model.authentication;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "USER_AUTHORITIES_TBL")
public class UserAuthorities implements Serializable {

    private static final long serialVersionUID = -6834191234536639905L;
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "userAuthorityId")
    @GenericGenerator(strategy = "sequence", name = "userAuthorityId", parameters = { @Parameter(name = "sequence", value = "USER_AUTHORITIES_ID_SEQNO") })
    @Column(name = "USER_AUTHORITIES_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "USER_ID", nullable = false)
    private User user;

    @OneToOne
    @JoinColumn(name = "AUTHORITIES_ID", nullable = false)
    private Authority authority;

    /**
     * 
     */
    public UserAuthorities() {
        // TODO Auto-generated constructor stub
    }

    /**
     * @param user
     * @param authority
     */
    public UserAuthorities(User user, Authority authority) {
        this.user = user;
        this.authority = authority;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the authority
     */
    public Authority getAuthority() {
        return authority;
    }

    /**
     * @param authority the authority to set
     */
    public void setAuthority(Authority authority) {
        this.authority = authority;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UserAuthorities [id=" + id + ", user=" + user + ", authority="
                + authority + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result
                + ((authority == null) ? 0 : authority.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((user == null) ? 0 : user.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        UserAuthorities other = (UserAuthorities) obj;
        if (authority == null) {
            if (other.authority != null)
                return false;
        } else if (!authority.equals(other.authority))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (user == null) {
            if (other.user != null)
                return false;
        } else if (!user.equals(other.user))
            return false;
        return true;
    }
}
