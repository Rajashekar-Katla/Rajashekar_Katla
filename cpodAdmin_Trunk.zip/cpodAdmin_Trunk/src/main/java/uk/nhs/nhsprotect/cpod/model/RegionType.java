package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Class representing region_type table (REGIONS_TYPE_TBL).
 * @author awheatley
 */
@Entity
@Table(name = "REGIONS_TYPE_TBL")
public class RegionType extends BaseEntity implements Serializable {
    /**
     * Serial version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key identifier.
     */
    @Id
    @Column(name = "region_type_id")
    private Long id;

    /**
     * Address Type.
     */
    @Column(name = "region_type")
    private String regionType;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the regionType
     */
    public String getRegionType() {
        return regionType;
    }

    /**
     * @param regionType the regionType to set
     */
    public void setRegionType(String regionType) {
        this.regionType = regionType;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result
                + ((regionType == null) ? 0 : regionType.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof RegionType)) {
            return false;
        }
        RegionType other = (RegionType) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (regionType == null) {
            if (other.regionType != null) {
                return false;
            }
        } else if (!regionType.equals(other.regionType)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "RegionType [id=" + id + ", regionType=" + regionType + "]";
    }

}
