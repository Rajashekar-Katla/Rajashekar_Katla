package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.controller.dto.PersonResult;
import uk.nhs.nhsprotect.cpod.controller.dto.PersonSearch;
import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.PersonDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Address;
import uk.nhs.nhsprotect.cpod.model.AddressLink;
import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;
import uk.nhs.nhsprotect.cpod.service.AddressLinkService;
import uk.nhs.nhsprotect.cpod.service.AddressService;
import uk.nhs.nhsprotect.cpod.service.PersonRoleService;
import uk.nhs.nhsprotect.cpod.service.PersonService;
import uk.nhs.nhsprotect.cpod.service.SystemPersonTypeService;
import uk.nhs.nhsprotect.cpod.service.UserService;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;
import uk.nhs.nhsprotect.cpod.util.UserContextUtil;

/**
 * Implements PersonService.
 * @author awheatley
 * @version 0.1
 */
@Service("personService")
@Transactional(value = "transactionManager", readOnly = true, propagation = Propagation.REQUIRED)
public class PersonServiceImpl extends AbstractServiceImpl<Person, Long>
        implements PersonService {

    /**
     * personDao Represents the DAO for Person.
     */
    @Autowired
    private PersonDao personDao;

    /**
     * Provides access to systemPersonTypeService.
     */
    @Autowired
    private SystemPersonTypeService systemPersonTypeService;

    /**
     * Provides access to userService.
     */
    @Autowired
    private UserService userService;

    /**
     * Provides access to addressService.
     */
    @Autowired
    private AddressService addressService;

    /**
     * Provides access to addressLinkService.
     */
    @Autowired
    private AddressLinkService addressLinkService;

    /**
     * Provides access to userContextUtil.
     */
    @Autowired
    private UserContextUtil userContextUtil;

    /**
     * Provides access to personRoleService.
     */
    @Autowired
    private PersonRoleService personRoleService;

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.PersonService#findPersonByRef(java.lang
     * .String)
     */
    @Override
    public Person findPersonByRef(String personRef) throws CpodException {

        Person personResult = null;
        PersonRole personRole = personRoleService
                .findPersonRoleByRef(personRef);

        personResult = personRole.getPerson();

        return personResult;
    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#getDao()
     */
    @Override
    public AbstractDao<Person, Long> getDao() {
        return personDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.PersonService#getNewUsers(java.lang.String
     * , java.lang.String)
     */
    @Override
    public List<PersonResult> getNewUsers(String query, String system)
            throws CpodException {

        List<SystemPersonType> systemPersonTypes = systemPersonTypeService
                .findBySystemName(system);
        return userService.getNewUsers(query, systemPersonTypes);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.PersonService#getPersonsForResponsibilities
     * (java.lang.String, java.lang.Long)
     */
    @Override
    public List<PersonResult> getPersonsForResponsibilities(String query,
            Long orgId) {
        return personDao.getPersonsForResponsibilities(query, orgId);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#saveOrUpdate(
     * java.lang.Object)
     */
    @Override
    @Transactional(value = "transactionManager", readOnly = false, propagation = Propagation.REQUIRED)
    public void saveOrUpdate(Person entity) throws CpodException {

        List<PersonRole> personRoles = entity.getPersonRoles();
        // If this is a new person, save it so a PersonID is generated.
        if (entity.getId() == null) {
            preparePersonSave(entity);
            personDao.saveOrUpdate(entity);
        }
        if (personRoles != null) {
            Iterator<PersonRole> personRoleIter = personRoles.iterator();
            while (personRoleIter.hasNext()) {
                PersonRole personRole = personRoleIter.next();
                personRole.setPerson(entity);
                personRoleService.saveOrUpdate(personRole);
            }
        }

        // save changes to addresses
        if (entity.getWorkAddress() != null
                && !entity.getWorkAddress().isEmpty()) {
            // get the address
            Address address = entity.getWorkAddress();
            // set the address type
            address.getAddressType().setId(CPODConstants.ADDRESS_TYPE_WORK_ID);
            addressService.saveOrUpdate(address);
            // ensure the address link is correct
            AddressLink addressLink = new AddressLink(
                    userContextUtil.getUsername(), entity, address);
            // use merge as object may exist in hibernate session due to prior
            // 'finds'
            addressLinkService.merge(addressLink);

        }
        if (entity.getHomeAddress() != null
                && !entity.getHomeAddress().isEmpty()) {
            Address address = entity.getHomeAddress();
            // set the address type
            address.getAddressType().setId(CPODConstants.ADDRESS_TYPE_HOME_ID);
            addressService.saveOrUpdate(address);
            // ensure the address link is correct
            AddressLink addressLink = new AddressLink(
                    userContextUtil.getUsername(), entity, address);
            // use merge as object may exist in hibernate session due to prior
            // 'finds'
            addressLinkService.merge(addressLink);

        }

        // save the address link
        preparePersonSave(entity);
        // use merge as object may exist in hibernate session due to prior
        // 'finds'
        personDao.merge(entity);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.PersonService#getNHSPStaff(java.lang.String
     * )
     */
    @Override
    public List<PersonResult> getNHSPStaff(String query) {
        return this.personDao.getNHSPStaff(query);
    }

    /**
     * Method to check that referenced objects are set correctly before
     * attempting save or update.
     * @param entity to prepare
     */
    private void preparePersonSave(Person entity) {
        // Organisation can be lazy initialised to an 'empty' organisation
        // leading to issues when persisting
        if (entity.getEmployerOrganisation() != null
                && entity.getEmployerOrganisation().getId() == null
                && StringUtils.isEmpty(entity.getEmployerOrganisationId())) {
            entity.setEmployerOrganisation(null);
        }

        // TODO for person roles check if any empty child objects exist

        // // non-nhsp staff may not have manager now exist on person role so to
        // check them
        // if (entity.getManager() != null) {
        // if (entity.getManager().getId() == null
        // && StringUtils.isEmpty(entity.getManagerId())) {
        // entity.setManager(null);
        // }
        // }
        // non-nhsp staff will not have nhsp section - this can also be lazy
        // initialised
        if (entity.getNhspSection() != null
                && entity.getNhspSection().getId() == null
                && StringUtils.isEmpty(entity.getNhspSectionId())) {
            entity.setNhspSection(null);
        }
    }

    @Override
    public List<Person> findPersonsByCriteria(PersonSearch personSearch) {

        return this.personDao.findPersonsByCriteria(personSearch);
    }

}
