/**
 * 
 */
package uk.nhs.nhsprotect.cpod.util;

import java.io.Serializable;
import java.util.List;
import java.util.Locale;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import uk.nhs.nhsprotect.cpod.model.authentication.CpodUser;
import uk.nhs.nhsprotect.cpod.security.UserContext;

/**
 * Utility class to get user informations in a request.
 * @author ntones
 */
@Component("userContext")
public class UserContextUtil implements Serializable {

    /**
     * Serializabel version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Getting the userName used in the authentification process
     * @return String userName
     */
    public String getUsername() {
        return UserContext.getUsername();
    }

    /**
     * Getting the current user first name & last Name
     * @return
     */
    public String getUserFullName() {
        return UserContext.getCurrentUser().getFullname();
    }

    /**
     * Checking if the current user is identified
     * @return
     */
    public boolean isAnonymousUser() {
        return "anonymousUser".equalsIgnoreCase(getUsername());
    }

    /**
     * Getting the current user local id (en, fr...)
     * @return
     */
    public Locale getLocale() {
        return LocaleContextHolder.getLocale();
    }

    /**
     * Getting the current user roles
     * @return
     */
    public static List<String> getRoles() {
        return UserContext.getRoles();
    }

    /**
     * Getting the current user person ID.
     * @return personId
     */
    public Long getPersonId() {
        return UserContext.getPersonId();
    }

    /**
     * Getting the current user ID.
     * @return userId
     */
    public Long getUserId() {
        return UserContext.getUserId();
    }

    /**
     * Get the current logged in user.
     * @return CpodUser logged in.
     */
    public CpodUser getCurrentUser() {
        return UserContext.getCurrentUser();
    }

}
