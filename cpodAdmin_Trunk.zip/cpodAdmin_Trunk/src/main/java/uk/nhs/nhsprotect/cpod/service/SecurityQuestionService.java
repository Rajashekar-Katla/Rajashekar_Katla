/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.model.SecurityQuestion;

/**
 * Service Interface for SecurityQuestions.
 * 
 * @author ntones
 * 
 */
public interface SecurityQuestionService extends
        AbstractService<SecurityQuestion, Long> {

}
