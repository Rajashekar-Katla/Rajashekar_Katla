package uk.nhs.nhsprotect.cpod.controller;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import uk.nhs.nhsprotect.cpod.controller.dto.Address;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class AddressLookupController {
    private static final String ALS_PATH = "/als/address/{jsonAddressString}";
    /**
     * Logger instance for AddressLookupController.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(AddressLookupController.class);

    private final RestTemplate restTemplate;

    private final ObjectMapper objectMapper;

    @SuppressWarnings("unused")
    private final ResponseEntity<Object> responseEntity; // This property used
                                                         // for junit testing

    @Autowired
    public AddressLookupController(RestTemplate restTemplate,
            ObjectMapper objectMapper, ResponseEntity<Object> responseEntity) {
        this.restTemplate = restTemplate;
        this.objectMapper = objectMapper;
        this.responseEntity = responseEntity;
    }

    @Value("${als.host}")
    private String alsHost;

    @Value("${als.port}")
    private String alsPort;

    @RequestMapping(value = { "/lookupAddress" }, method = RequestMethod.POST, produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<Address> LookupAddress(
            @RequestParam(value = "postCode", required = true) String postCode,
            @RequestParam(value = "addressLine1", required = true) String addressLine1,
            @RequestParam(value = "addressLine2", required = false) String addressLine2,
            @RequestParam(value = "addressLine3", required = false) String addressLine3,
            @RequestParam(value = "addressLine4", required = false) String addressLine4,
            @RequestParam(value = "addressLine5", required = false) String addressLine5,
            @RequestParam(value = "addressLine6", required = false) String addressLine6)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("LookupAddress For [" + postCode + ", " + addressLine1
                    + ", " + addressLine2 + ", " + addressLine3 + ", "
                    + addressLine4 + ", " + addressLine5 + ", " + addressLine6
                    + "]");
        }
        final Address address = new Address();
        address.setAddressLine1(addressLine1);
        address.setAddressLine2(addressLine2);
        address.setAddressLine3(addressLine3);
        address.setAddressLine4(addressLine4);
        address.setAddressLine5(addressLine5);
        address.setAddressLine6(addressLine6);
        address.setPostCode(postCode);

        return getAddressListFromALS(address);
    }

    private List<Address> getAddressListFromALS(final Address address) {
        List<Address> addressList = null;
        final HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        final HttpEntity<String> requestEntity = new HttpEntity<String>(headers);
        final String alsURL = alsHost + alsPort + ALS_PATH;

        if (LOG.isDebugEnabled()) {
            LOG.debug("ALS Rest Service URL:  [" + alsURL + "]");
        }
        try {
            final String jsonString = objectMapper.writeValueAsString(address);
            final ResponseEntity<String> result = restTemplate.exchange(alsURL,
                    HttpMethod.GET, requestEntity, String.class, jsonString);
            addressList = objectMapper.readValue(
                    result.getBody(),
                    objectMapper.getTypeFactory().constructCollectionType(
                            List.class, Address.class));
        } catch (JsonParseException e) {
            LOG.error("JsonParseException while invoking ALS rest service: "
                    + e.getStackTrace());
        } catch (JsonMappingException e) {
            LOG.error("JsonMappingException while invoking ALS rest service: "
                    + e.getStackTrace());
        } catch (RestClientException e) {
            LOG.error("RestClientException while invoking ALS rest service: "
                    + e.getStackTrace());
        } catch (IOException e) {
            LOG.error("IOException while invoking ALS rest service: "
                    + e.getStackTrace());
        }
        return addressList;
    }
}
