package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.controller.dto.OrganisationResult;
import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.OrganisationDao;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Organisation;
import uk.nhs.nhsprotect.cpod.service.OrganisationService;

/**
 * @author awheatley
 */
@Service("organisationService")
@Transactional(readOnly = true)
public class OrganisationServiceImpl extends
        AbstractServiceImpl<Organisation, Long> implements OrganisationService {

    /**
     * Gives access to the organisationDao.
     */
    @Autowired
    private OrganisationDao organisationDao;

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#getDao()
     */
    @Override
    public AbstractDao<Organisation, Long> getDao() {
        return organisationDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.OrganisationService#findOrgByOrgCode(java
     * .lang.String)
     */
    @Override
    public Organisation findOrgByOrgCode(String orgCode) throws CpodException {

        List<Organisation> found = organisationDao
                .findorganisationsByOrganisationsRef(orgCode);

        if (found != null && !found.isEmpty()) {
            // multiple records found
            if (found.size() > 1) {
                throw new CpodNonUniqueException(
                        "More than one Organisation found with Organisation Code ["
                                + orgCode + "]");
            } else {
                // one record found
                return found.iterator().next();
            }
        } else {
            // No results found
            throw new CpodNoResultsReturnedException(
                    "No Organisations found with Organisation Code [" + orgCode
                            + "]");
        }

    }

    /* (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.OrganisationService#getOrganisationsForResponsibilities(java.lang.String, java.lang.Long)
     */
    @Override
    public List<OrganisationResult> getOrganisationsForResponsibilities(
            String query, Long personId) {

        return organisationDao.getOrganisationsForResponsibilities(query,
                personId);
    }

    /* (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.OrganisationService#getOrganisationsForResponsibilities(java.lang.String, java.lang.Long)
     */
    @Override
    public List<OrganisationResult> getOrganisationsForPersons(
            String query) {

        return organisationDao.getOrganisationsForPersons(query);
    }
}
