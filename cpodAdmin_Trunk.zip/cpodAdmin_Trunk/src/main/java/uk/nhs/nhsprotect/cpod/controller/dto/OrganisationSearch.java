/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller.dto;

import java.io.Serializable;

/**
 * A POJO backing object to bind the organisationSearch form to.
 * @author ntones
 */
public class OrganisationSearch implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String orgName;
    private String orgCode;

    /**
     * @return the orgName
     */
    public String getOrgName() {
        return orgName;
    }

    /**
     * @param orgName the orgName to set
     */
    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    /**
     * @return the orgCode
     */
    public String getOrgCode() {
        return orgCode;
    }

    /**
     * @param orgCode the orgCode to set
     */
    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "OrganisationSearch [orgName=" + orgName + ", orgCode="
                + orgCode + "]";
    }

}
