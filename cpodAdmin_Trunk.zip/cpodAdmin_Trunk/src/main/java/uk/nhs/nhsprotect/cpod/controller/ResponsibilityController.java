/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Responsibility;
import uk.nhs.nhsprotect.cpod.service.OrganisationService;
import uk.nhs.nhsprotect.cpod.service.PersonRoleService;
import uk.nhs.nhsprotect.cpod.service.ResponsibilityService;
import uk.nhs.nhsprotect.cpod.util.CpodUtils;

/**
 * Spring controller class to provide links to responsibility related pages.
 * 
 * @author ntones
 */
@Controller
public class ResponsibilityController extends CpodBaseController {

	/**
	 * Logger instance for CommonPagesController.class.
	 **/
	private static final Logger LOG = Logger
			.getLogger(ResponsibilityController.class);

	/**
	 * ResponsibilityService reference.
	 */
	@Autowired
	private ResponsibilityService responsibilityService;

	/**
	 * PersonRoleService reference.
	 */
	@Autowired
	private PersonRoleService personRoleService;

	/**
	 * Organisation Service reference.
	 */
	@Autowired
	private OrganisationService organisationService;

	/**
	 * Handles requests to view a persons responsibilities.
	 * 
	 * @param modelMap
	 *            the model map
	 * @param id
	 *            value from the request parameter
	 * @return value of forward depending on query outcome
	 * @throws CpodException
	 *             if no personRole Found by findByID
	 * @throws Exception
	 *             on error
	 */

	@RequestMapping(value = { "/viewResponsibilities" }, method = RequestMethod.GET)
	public String viewResponsibilities(ModelMap modelMap,
			@RequestParam(value = "personRoleId") Long personRoleId,
			HttpServletRequest request) throws CpodException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("viewResponsibilities for  personRoleId [" + personRoleId
					+ "]");
		}

		List<Responsibility> responsibilities = null;

		responsibilities = personRoleService
				.getResponsibilitiesForPersonRoleId(personRoleId);

		// One of the responsibilities so reference can be made to
		// personRole/Person
		Responsibility responsibility = null;
		if (!responsibilities.isEmpty()) {
			responsibility = responsibilities.get(0);
			responsibility.setPersonRole(personRoleService
					.findById(personRoleId));
			responsibility.setPersonRoleId(personRoleId.toString());
		} else {
			// this should not happen but for safety will initialise object to
			// prevent possible NPE later.
			responsibility = new Responsibility();
		}

		modelMap.addAttribute("responsibilities", responsibilities);
		modelMap.addAttribute("responsibility", responsibility);
		modelMap.addAttribute("personRoleId", personRoleId);
		modelMap.addAttribute("canEdit", CpodUtils
				.isUserAbleToEditResponsibility(request, responsibilities));

		return "person-resp-view";
	}

	/**
	 * Updates a responsibility submitted ajaxwise.
	 * 
	 * @param map
	 *            the current modelMap
	 * @param responsibility
	 *            to be updated
	 * @return String response message
	 * @throws Exception
	 *             on error
	 */
	@RequestMapping(value = { "/updateResponsibility" }, method = RequestMethod.POST)
	public @ResponseBody
	String updateResponsibility(ModelMap map,
			@ModelAttribute Responsibility responsibility) throws Exception {
		if (LOG.isDebugEnabled()) {
			LOG.debug("updateResponsibility for responsibility ["
					+ responsibility + "]");
		}

		responsibilityService.saveOrUpdate(responsibility);

		return getMessageSource().getMessage("resp.edit.success", null, null);
	}

	/**
	 * Prepares a new responsibility for creation.
	 * 
	 * @param modelMap
	 *            the current ModelMap
	 * @param personId
	 *            - optional ID of person responsibility to involve.
	 * @param orgId
	 *            - optional ID of organisation responsibility to involve.
	 * @return String the view to forward to.
	 * @throws Exception
	 *             on error
	 */
	@RequestMapping(value = { "/addResponsibility" }, method = RequestMethod.GET)
	public String prepareAddResponsibility(
			ModelMap modelMap,
			@RequestParam(required = false, value = "personRoleId") String personRoleId,
			@RequestParam(required = false, value = "orgId") String orgId)
			throws Exception {
		if (LOG.isDebugEnabled()) {
			LOG.debug("prepareAddResponsibility for personRoleId ["
					+ personRoleId + "]");
		}
		// add a new responsibility to the model for editing
		Responsibility responsibility = new Responsibility();
		// adding org to person
		if (StringUtils.isNotEmpty(personRoleId)) {

			responsibility.setPersonRole(personRoleService.findById(Long
					.parseLong(personRoleId)));
			responsibility.setPersonRoleId(personRoleId);

		}
		// add person to org
		else if (StringUtils.isNotEmpty(orgId)) {
			responsibility.setOrganisationId(orgId);
			responsibility.setOrganisation(organisationService.findById(Long
					.parseLong(orgId)));
		}
		modelMap.put("responsibility", responsibility);

		return "add-resp-view";
	}

	/**
	 * Persists a responsibility.
	 * 
	 * @param modelMap
	 *            the current ModelMap
	 * @param responsibility
	 *            to be persisted
	 * @return String response message
	 * @throws Exception
	 *             on error
	 */
	@RequestMapping(value = { "/addResponsibility" }, method = RequestMethod.POST)
	public String addResponsibility(ModelMap modelMap,
			@ModelAttribute Responsibility responsibility) throws Exception {
		if (LOG.isDebugEnabled()) {
			LOG.debug("addResponsibility for responsibility [" + responsibility
					+ "]");
		}

		responsibilityService.saveOrUpdate(responsibility);

		modelMap.put("responsibility", responsibility);
		modelMap.put("successMessage",
				getMessageSource().getMessage("resp.edit.success", null, null));
		return "add-resp-view";
	}

}
