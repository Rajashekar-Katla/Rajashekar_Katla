package uk.nhs.nhsprotect.cpod.service;

import java.util.List;

import uk.nhs.nhsprotect.cpod.controller.dto.PersonResult;
import uk.nhs.nhsprotect.cpod.controller.dto.PersonSearch;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Person;

/**
 * Service Layer Methods for dealing with specific tasks for the Person Bean.
 * @author awheatley
 */

public interface PersonService extends AbstractService<Person, Long> {
    /**
     * Method to retrieve a person based on person reference. Throws non-unique
     * exceptions if multiple or no records found.
     * @param personRef - Person's knownas id - e.g lcfs1234
     * @return person if a single record is found
     * @throws CpodException on error
     */
    Person findPersonByRef(String personRef) throws CpodException;

    /**
     * Method to find potential users for NHS Protect systems. Uses the
     * NHSPSystemUsre entries - linked by system name.
     * @param query partial username to search with
     * @param system the system name to retrieve potential users
     * @return List<PersonResult> matching criteria
     * @throws CpodException
     */
    List<PersonResult> getNewUsers(String query, String system)
            throws CpodException;

    /**
     * Method to find potential persons for an organisation responsibility.
     * Criteria is that person is LCFS or LSMS, active and not already
     * responsible for Org ID.
     * @param query partial reference to search with
     * @param orgId the orgId for responsibility
     * @return List<PersonResult> matching criteria
     */
    List<PersonResult> getPersonsForResponsibilities(String query, Long orgId);

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#saveOrUpdate(java.lang
     * .Object)
     */
    @Override
    void saveOrUpdate(Person entity) throws CpodException;

    /**
     * Method to find all active NHSP staff
     * @param query the part of the staff name to search for
     * @return List<PersonResult> matching the query
     */
    List<PersonResult> getNHSPStaff(String query);

    /**
     * Method to search for Persons based on criteria entered in the person
     * search form.
     * @param personSearch object populated with screen values.
     * @return List<Person> matching entered criteria.
     */
    List<Person> findPersonsByCriteria(PersonSearch personSearch);
}
