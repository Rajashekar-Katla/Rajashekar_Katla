/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.SystemPersonTypeDao;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;
import uk.nhs.nhsprotect.cpod.service.SystemPersonTypeService;

/**
 * Implementation of SystemPersonTypeService.
 * @author ntones
 */
@Service("systemPersonTypeService")
@Transactional(value = "transactionManager", readOnly = true, propagation = Propagation.REQUIRED)
public class SystemPersonTypeServiceImpl extends
        AbstractServiceImpl<SystemPersonType, Long> implements
        SystemPersonTypeService {

    /**
     * systemPersonTypeDao Represents the DAO for SystemPersonType.
     */
    @Autowired
    private SystemPersonTypeDao systemPersonTypeDao;

    @Override
    public AbstractDao<SystemPersonType, Long> getDao() {

        return systemPersonTypeDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.SystemPersonTypeService#findBySystemName
     * (java.lang.String)
     */
    @Override
    public List<SystemPersonType> findBySystemName(String system) {
        return systemPersonTypeDao.findBySystemName(system);
    }

}
