/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.controller.dto.PersonResult;
import uk.nhs.nhsprotect.cpod.dao.UserServiceDao;
import uk.nhs.nhsprotect.cpod.model.NHSPSystem;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;
import uk.nhs.nhsprotect.cpod.model.authentication.User;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * @author ntones
 */
@Repository("userServiceDao")
public class UserServiceDaoImpl extends AbstractDaoImpl<User, Long> implements
        UserServiceDao {

    /**
     * Logger instance for UserServiceDaoImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(UserServiceDaoImpl.class);

    /**
     * User Dao Implementation.
     */
    protected UserServiceDaoImpl() {
        super(User.class);

    }

    @SuppressWarnings("unchecked")
    @Override
    public List<PersonResult> getNewUsers(String query,
            List<SystemPersonType> systemPersonTypes) {

        List<PersonResult> results = new ArrayList<PersonResult>();

        Query hibQuery = null; // , personRole.person.status as status
                               // ,personRole.personType.description as
                               // personType

        NHSPSystem system = systemPersonTypes.get(0).getSystem();
        String sysName = system.getName();
        String userTable = CPODConstants.SYSTEM_USER_OBJECTS.get(sysName);

        for (SystemPersonType systemPersonType : systemPersonTypes) {

            String hql = "select personRole.personRef as personRef, personRole.person.id as personId,personRole.id as personRoleId, personRole.personType.description as assignedRole "
                    + "from PersonRole as personRole "
                    + "where personRole.personType.description = :personTypeDesc "
                    + "and personRole.person.status = :personStatus "
                    + "and personRole.personRef like :query "
                    + "and personRole.person.id not in (select users.person from "
                    + userTable + " as users)";
            hibQuery = getCurrentSession().createQuery(hql);
            hibQuery.setString("personTypeDesc", systemPersonType
                    .getPersonType().getDescription());
            hibQuery.setString("personStatus", systemPersonType.getStatus());
            hibQuery.setString("query", query.toLowerCase() + '%');

            results.addAll((List<PersonResult>) hibQuery.setResultTransformer(
                    Transformers.aliasToBean(PersonResult.class)).list());

        }

        return results;

    }

    @Override
    public User findByReferenceNumber(String referenceNumber) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Searching for user with reference " + referenceNumber);
        }
        DetachedCriteria criteria = DetachedCriteria.forClass(
                getPersistentClass()).add(
                Restrictions.eq("username", referenceNumber));
        return (User) criteria.getExecutableCriteria(getCurrentSession())
                .uniqueResult();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<User> searchUsers(User user) {
        DetachedCriteria criteria = DetachedCriteria
                .forClass(getPersistentClass());

        criteria.createAlias("person", "person");

        if (user.getPerson() != null) {
            if (StringUtils.isNotEmpty(user.getPerson().getForeName())
                    || StringUtils.isNotEmpty(user.getPerson().getSurName())
            // TODO reference now on person role
            // || StringUtils.isNotEmpty(user.getPerson().getPersonRef())
            ) {

                if (StringUtils.isNotEmpty(user.getPerson().getForeName())) {
                    criteria.add(Restrictions.ilike("person.foreName", "%"
                            + user.getPerson().getForeName() + "%"));
                }
                if (StringUtils.isNotEmpty(user.getPerson().getSurName())) {
                    criteria.add(Restrictions.ilike("person.surName", "%"
                            + user.getPerson().getSurName() + "%"));
                }
                // TODO reference now on personrole
                // if (StringUtils.isNotEmpty(user.getPerson().getPersonRef()))
                // {
                // criteria.add(Restrictions.ilike("person.personRole.personRef",
                // "%"
                // + user.getPerson().getPersonRef() + "%"));
                //
                // }
                criteria.addOrder(Property.forName("person.surName").asc());
            } else {
                criteria.addOrder(Property.forName("person.surName").asc());
            }
        }
        criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        if (LOG.isDebugEnabled()) {
            LOG.debug("searchUsers - executing the following criteria:\n"
                    + criteria.toString());
        }
        return (List<User>) criteria.getExecutableCriteria(getCurrentSession())
                .list();
    }
}
