/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.SecurityQuestionDao;
import uk.nhs.nhsprotect.cpod.model.SecurityQuestion;

/**
 * Implementation of SecurityQuestionDao interface.
 * 
 * @author ntones
 * 
 */
@Repository("securityQuestionDao")
public class SecurityQuestionDaoImpl extends
        AbstractDaoImpl<SecurityQuestion, Long> implements SecurityQuestionDao {

    /**
     * Constructor for SecurityQuestionDaoImpl.
     * 
     * @param persistentClass
     */
    protected SecurityQuestionDaoImpl() {
        super(SecurityQuestion.class);
    }

}
