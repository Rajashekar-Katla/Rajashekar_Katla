package uk.nhs.nhsprotect.cpod.service.impl;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.SrtUserAuthoritiesDao;
import uk.nhs.nhsprotect.cpod.dao.SrtUserServiceDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.service.SrtUserService;
import uk.nhs.nhsprotect.srt.model.SrtAuthority;
import uk.nhs.nhsprotect.srt.model.SrtUser;
import uk.nhs.nhsprotect.srt.model.SrtUserAuthorities;

/**
 * Service class providing CRUD operations to SrtUser Entity.
 * @author ntones
 */
@Service("srtUserService")
@Transactional(value = "srtTransactionManager", readOnly = true, propagation = Propagation.REQUIRED)
public class SrtUserServiceImpl extends SrtAbstractServiceImpl<SrtUser, Long>
        implements SrtUserService {

    /**
     * srtUserServiceDao Represents the DAO for SrtUser.
     */
    @Autowired
    private SrtUserServiceDao srtUserServiceDao;

    @Autowired
    private SrtUserAuthoritiesDao srtUserAuthoritiesDao;

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#getDao()
     */
    @Override
    public AbstractDao<SrtUser, Long> getDao() {
        return srtUserServiceDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#saveOrUpdate
     * (java.lang.Object)
     */
    @Override
    @Transactional(value = "srtTransactionManager", readOnly = false)
    public void saveOrUpdate(SrtUser entity) throws CpodException {
        if (StringUtils.isEmpty(entity.getPassword())) {
            // generate password
            String password = srtUserServiceDao.getPassword();
            entity.setPassword(password);
        }

        // remove old authorities
        if (entity.getId() != null) {
            srtUserAuthoritiesDao.deleteBySrtUser(entity);
            entity.getUserAuthorities().clear();
        }

        // add new selections
        for (SrtAuthority authority : entity.getAuthorities()) {
            SrtUserAuthorities srtUserAuthorities = new SrtUserAuthorities(
                    entity, authority);
            entity.getUserAuthorities().add(srtUserAuthorities);
        }
        super.saveOrUpdate(entity);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#findById(java
     * .io.Serializable)
     */
    @Override
    public SrtUser findById(Long id) throws CpodException {

        SrtUser user = super.findById(id);
        for (SrtUserAuthorities srtUserAuthority : user.getUserAuthorities()) {
            user.getAuthorities().add(srtUserAuthority.getSrtAuthority());

        }
        return user;
    }
}
