package uk.nhs.nhsprotect.cpod.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Criterion;

import uk.nhs.nhsprotect.cpod.exception.CpodException;

/**
 * @author ntones
 * @param <T>
 * @param <ID>
 */
public interface AbstractService<T, ID extends Serializable> {

    /**
     * Save the record.
     * @param entity (generic)
     * @return DB PrimaryID for record
     * @throws CpodException for error
     */
    ID save(T entity) throws CpodException;

    /**
     * Delete the record.
     * @param entity (generic)
     * @throws CpodException for error
     */

    void delete(T entity) throws CpodException;

    /**
     * Find all records for the persistent class type.
     * @return - List of records
     * @throws CpodException for error
     */
    List<T> findAll() throws CpodException;

    /**
     * Delete all records from the database for the given class (generic).
     * @param clazz (generic)
     * @throws CpodException for error
     */
    void deleteAll() throws CpodException;

    /**
     * Save the record of update record if it exists.
     * @param entity (generic)
     * @throws CpodException for error
     */
    void saveOrUpdate(T entity) throws CpodException;

    /**
     * Find record based on Primary ID.
     * @param id (generic)
     * @return record (generic)
     * @throws CpodException for error
     */
    T findById(ID id) throws CpodException;

    /**
     * update the record.
     * @param entity (generic)
     * @throws CpodException for error
     */
    void update(T entity) throws CpodException;

    /**
     * Find all records by criteria.
     * @param criterion - Criterion
     * @return - All records (generic)
     * @throws CpodException for error
     */
    List<T> findByCriteria(Criterion criterion) throws CpodException;

    /**
     * Find all records by multiple 'AND' criteria.
     * @param searchCriteria - map containing key value pairs of criteria field
     *            name and value
     * @return - All matching records (generic)
     */
    List<T> findByAndCriterias(Map<String, String> searchCriteria);

    /**
     * Merge a record that may already be held within the hibernate session -
     * based in ID.
     * @param entity - the object to merge
     * @return - the updated object after merge
     */
    T merge(T entity);

}
