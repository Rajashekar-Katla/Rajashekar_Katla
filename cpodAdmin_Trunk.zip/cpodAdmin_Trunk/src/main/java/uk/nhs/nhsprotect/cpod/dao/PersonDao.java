package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.controller.dto.PersonResult;
import uk.nhs.nhsprotect.cpod.controller.dto.PersonSearch;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Person;

/**
 * DAO for Person Class.
 * @author AWheatley
 */
public interface PersonDao extends AbstractDao<Person, Long> {

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.dao.AbstractDao#deleteAll()
     */
    int deleteAll() throws CpodException;

    /**
     * Method to find potential persons for an organisation responsibility.
     * Criteria is that person is LCFS or LSMS, active and not already
     * responsible for Org ID.
     * @param query partial reference to search with
     * @param orgId the orgId for responsibility
     * @return List<PersonResult> matching criteria
     */
    List<PersonResult> getPersonsForResponsibilities(String query, Long orgId);

    /**
     * Method to find all active NHSP staff
     * @param query the part of the staff name to search for
     * @return List<PersonResult> matching the query
     */
    List<PersonResult> getNHSPStaff(String query);

    /**
     * Method to search for Persons based on criteria entered in the person
     * search form.
     * @param personSearch object populated with screen values.
     * @return List<Person> matching entered criteria.
     */
    List<Person> findPersonsByCriteria(PersonSearch personSearch);

}
