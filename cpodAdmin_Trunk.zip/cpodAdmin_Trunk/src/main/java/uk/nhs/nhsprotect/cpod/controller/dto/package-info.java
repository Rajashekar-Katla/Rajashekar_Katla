/** Data transform object package.
 */
package uk.nhs.nhsprotect.cpod.controller.dto;

