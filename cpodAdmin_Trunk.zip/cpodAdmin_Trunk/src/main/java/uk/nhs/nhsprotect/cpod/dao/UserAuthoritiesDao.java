/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.cpod.model.authentication.UserAuthorities;

/**
 * @author ntones
 */
public interface UserAuthoritiesDao extends AbstractDao<UserAuthorities, Long> {

    void deleteAuthoritiesForUser(Long userId);

}
