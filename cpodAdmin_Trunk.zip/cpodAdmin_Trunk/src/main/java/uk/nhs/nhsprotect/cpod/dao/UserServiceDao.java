package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.controller.dto.PersonResult;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;
import uk.nhs.nhsprotect.cpod.model.authentication.User;

/**
 * Methods related to maintenance and review of Users.
 * @author ntones
 */
public interface UserServiceDao extends AbstractDao<User, Long> {

    /**
     * Find potential users for the system. Staff who are not already existing
     * system users.
     * @param query the partial reference to search for
     * @param systemPersonTypes - type and status of potential users
     * @return List<PersonResult> matching query.
     */
    List<PersonResult> getNewUsers(String query,
            List<SystemPersonType> systemPersonTypes);

    /**
     * Method to locate a user based on their reference number.
     * @param referenceNumber - staff ID e.g. ops0259, lcfs0001, etc.
     * @return User the user matching the reference number
     */
    User findByReferenceNumber(String referenceNumber);

    /**
     * Search for matching users.
     * @param user criteria
     * @return List<User> matching criteria
     */
    List<User> searchUsers(User user);

}
