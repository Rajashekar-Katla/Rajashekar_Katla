/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.controller.dto.PersonResult;
import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.UserAuthoritiesDao;
import uk.nhs.nhsprotect.cpod.dao.UserServiceDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;
import uk.nhs.nhsprotect.cpod.model.authentication.Authority;
import uk.nhs.nhsprotect.cpod.model.authentication.User;
import uk.nhs.nhsprotect.cpod.model.authentication.UserAuthorities;
import uk.nhs.nhsprotect.cpod.service.UserService;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * @author ntones
 */
@Service("userService")
@Transactional(value = "transactionManager", readOnly = true, propagation = Propagation.REQUIRED)
public class UserServiceImpl extends AbstractServiceImpl<User, Long> implements
        UserService {

    /**
     * userServiceDao Represents the DAO for User.
     */
    @Autowired
    private UserServiceDao userServiceDao;

    /**
     * Reference the user authorities DAO.
     */
    @Autowired
    private UserAuthoritiesDao userAuthoritiesDao;

    /**
     * References the password encoder.
     */
    @Autowired
    private PasswordEncoder passwordEncoder;

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.UserService#findByReferenceNumber(java
     * .lang.String)
     */
    @Override
    public User findByReferenceNumber(String referenceNumber) {
        return userServiceDao.findByReferenceNumber(referenceNumber);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.UserService#searchUsers(uk.nhs.nhsprotect
     * .cpod.model.authentication.User)
     */
    @Override
    public List<User> searchUsers(User user) {
        return userServiceDao.searchUsers(user);
    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#getDao()
     */
    @Override
    public AbstractDao<User, Long> getDao() {
        return userServiceDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#delete(java.lang
     * .Object)
     */
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED)
    public void delete(Long userId) throws CpodException {

        // delete the authorities for the user
        userAuthoritiesDao.deleteAuthoritiesForUser(userId);

        User user = super.findById(userId);
        super.delete(user);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#findById(java
     * .io.Serializable)
     */
    @Override
    public User findById(Long id) throws CpodException {
        User user = super.findById(id);
        List<UserAuthorities> userAuthorities = user.getUserAuthorities();
        for (UserAuthorities ua : userAuthorities) {
            user.getAuthorities().add(ua.getAuthority());
        }
        return user;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#saveOrUpdate(
     * java.lang.Object)
     */
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED)
    public void saveOrUpdate(User entity) throws CpodException {
        final String DEFAULT_PASSWORD = passwordEncoder.encode("changeit");
        if (entity.getPersonId() != null) {
            // set the person reference
            entity.setPerson(new Person(entity.getPersonId()));
        }

        if (entity.getId() != null) {
            // this is an update so delete previous authorities before
            // attempting to insert new
            // delete the authorities for the user
            userAuthoritiesDao.deleteAuthoritiesForUser(entity.getId());
            entity.setUserAuthorities(null);
            super.saveOrUpdate(entity);

        } else {
            // create a new user with default password
            // TODO not using a salt or anything...
            entity.setPassword(DEFAULT_PASSWORD);
            entity.setDefaultPasswordChanged(false);
            super.saveOrUpdate(entity);
        }
        List<UserAuthorities> newUserAuthorities = new ArrayList<UserAuthorities>();
        List<Authority> selectedAuthorities = entity.getAuthorities();
        if (selectedAuthorities != null && !selectedAuthorities.isEmpty())
            for (Authority authority : selectedAuthorities) {
                UserAuthorities userAuthorities = new UserAuthorities(entity,
                        authority);
                newUserAuthorities.add(userAuthorities);
                userAuthoritiesDao.saveOrUpdate(userAuthorities);
            }
        entity.setUserAuthorities(newUserAuthorities);
        super.saveOrUpdate(entity);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.UserService#changePassword(java.lang.Long,
     * java.lang.String)
     */
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED)
    public void changePassword(Long userId, String password)
            throws CpodException {
        final String DEFAULT_PASSWORD = passwordEncoder
                .encode(CPODConstants.DEFAULT_PASSWORD);
        User toUpdate = findById(userId);
        if (StringUtils.isEmpty(password) || password.equals(DEFAULT_PASSWORD)) {
            password = DEFAULT_PASSWORD;
            toUpdate.setDefaultPasswordChanged(false);

        } else {
            // make an md5 of passed value
            toUpdate.setDefaultPasswordChanged(true);
            password = passwordEncoder.encode(password);
        }
        toUpdate.setPassword(password);
        saveOrUpdate(toUpdate);

    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.UserService#getNewUsers(java.lang.String,
     * java.util.List)
     */
    @Override
    public List<PersonResult> getNewUsers(String query,
            List<SystemPersonType> systemPersonTypes) {

        return userServiceDao.getNewUsers(query, systemPersonTypes);
    }
}
