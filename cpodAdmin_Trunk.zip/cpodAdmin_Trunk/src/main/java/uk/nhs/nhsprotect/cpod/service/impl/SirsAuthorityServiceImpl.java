/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.SirsAuthorityDao;
import uk.nhs.nhsprotect.cpod.service.SirsAuthorityService;
import uk.nhs.nhsprotect.sirs.model.SirsAuthority;

/**
 * @author ntones
 */

@Service("sirsAuthorityService")
@Transactional(value = "sirsTransactionManager", readOnly = true, propagation = Propagation.REQUIRED)
public class SirsAuthorityServiceImpl extends
        SirsAbstractServiceImpl<SirsAuthority, Long> implements
        SirsAuthorityService {

    /**
     * userServiceDao Represents the DAO for SirsUser.
     */
    @Autowired
    private SirsAuthorityDao sirsAuthorityDao;

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#getDao()
     */
    @Override
    public AbstractDao<SirsAuthority, Long> getDao() {
        return sirsAuthorityDao;
    }

}
