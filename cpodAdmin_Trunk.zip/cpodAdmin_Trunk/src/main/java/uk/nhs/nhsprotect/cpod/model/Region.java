package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Class representing Person table (REGIONS_TBL).
 * @author awheatley
 */
@Entity
@Table(name = "REGIONS_TBL")
public class Region extends BaseEntity implements Serializable {
    /**
     * Serial version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key identifier.
     */
    @Id
    @Column(name = "region_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "regionID")
    @GenericGenerator(strategy = "sequence", name = "regionID", parameters = { @Parameter(name = "sequence", value = "BE_ID_SEQNO") })
    private Long id;

    /**
     * Region Code.
     */
    @Column(name = "region_code")
    private String regionCode;

    /**
     * Region.
     */
    @Column(name = "region")
    private String region;

    /**
     * RegionType. Linked to RegionType
     */
    @ManyToOne(optional = false)
    @JoinColumn(name = "region_type_id", nullable = false)
    private PersonType regionType;

    /**
     * @return the regionType
     */
    public PersonType getRegionType() {
        return regionType;
    }

    /**
     * @param regionType the regionType to set
     */
    public void setRegionType(PersonType regionType) {
        this.regionType = regionType;
    }

    @OneToMany(mappedBy = "region")
    private Set<RegionLink> regionLinks = new HashSet<RegionLink>();

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the regionCode
     */
    public String getRegionCode() {
        return regionCode;
    }

    /**
     * @param regionCode the regionCode to set
     */
    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    /**
     * @return the region
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * @return the regionLinks
     */
    public Set<RegionLink> getRegionLinks() {
        return regionLinks;
    }

    /**
     * @param regionLinks the regionLinks to set
     */
    public void setRegionLinks(Set<RegionLink> regionLinks) {
        this.regionLinks = regionLinks;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((region == null) ? 0 : region.hashCode());
        result = prime * result
                + ((regionCode == null) ? 0 : regionCode.hashCode());
        result = prime * result
                + ((regionLinks == null) ? 0 : regionLinks.hashCode());
        result = prime * result
                + ((regionType == null) ? 0 : regionType.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Region)) {
            return false;
        }
        Region other = (Region) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (region == null) {
            if (other.region != null) {
                return false;
            }
        } else if (!region.equals(other.region)) {
            return false;
        }
        if (regionCode == null) {
            if (other.regionCode != null) {
                return false;
            }
        } else if (!regionCode.equals(other.regionCode)) {
            return false;
        }
        if (regionLinks == null) {
            if (other.regionLinks != null) {
                return false;
            }
        } else if (!regionLinks.equals(other.regionLinks)) {
            return false;
        }
        if (regionType == null) {
            if (other.regionType != null) {
                return false;
            }
        } else if (!regionType.equals(other.regionType)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Region [id=" + id + ", regionCode=" + regionCode + ", region="
                + region + ", regionType=" + regionType + ", regionLinks="
                + regionLinks + "]";
    }

}
