package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Class representing Person table (NHS_DEPARTMENT_TBL).
 * @author awheatley
 */
@Entity
@Table(name = "NHSP_DEPARTMENT_TBL")
public class NHSPDepartment extends BaseEntity implements Serializable {
    /**
     * Serial version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key identifier.
     */
    @Id
    @Column(name = "NHSP_Department_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "nhspDepartmentID")
    @GenericGenerator(strategy = "sequence", name = "nhspDepartmentID", parameters = { @Parameter(name = "sequence", value = "BE_ID_SEQNO") })
    private Long id;

    /**
     * NHSP Department Name.
     */
    @Column(name = "NHSP_Department_Name")
    private String nhspDepartmentName;

    /**
     * Manager ID.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "nhsp_department_manager")
    private Person manager;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the nhspDepartmentName
     */
    public String getNhspDepartmentName() {
        return nhspDepartmentName;
    }

    /**
     * @param nhspDepartmentName the nhspDepartmentName to set
     */
    public void setNhspDepartmentName(String nhspDepartmentName) {
        this.nhspDepartmentName = nhspDepartmentName;
    }

    /**
     * @return the manager
     */
    public Person getManager() {
        return manager;
    }

    /**
     * @param manager the manager to set
     */
    public void setManager(Person manager) {
        this.manager = manager;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((manager == null) ? 0 : manager.hashCode());
        result = prime
                * result
                + ((nhspDepartmentName == null) ? 0 : nhspDepartmentName
                        .hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        NHSPDepartment other = (NHSPDepartment) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (manager == null) {
            if (other.manager != null) {
                return false;
            }
        } else if (!manager.equals(other.manager)) {
            return false;
        }
        if (nhspDepartmentName == null) {
            if (other.nhspDepartmentName != null) {
                return false;
            }
        } else if (!nhspDepartmentName.equals(other.nhspDepartmentName)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "NHSPDepartment [id=" + id + ", nhspDepartmentName="
                + nhspDepartmentName + ", manager=" + manager + "]";
    }

}
