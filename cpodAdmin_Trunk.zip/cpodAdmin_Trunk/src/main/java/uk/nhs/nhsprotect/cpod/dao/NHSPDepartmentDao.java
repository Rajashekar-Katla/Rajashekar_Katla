package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.NHSPDepartment;

/**
 * @author awheatley
 */
public interface NHSPDepartmentDao extends AbstractDao<NHSPDepartment, Long> {
    /**
     * Find all NHSP Criteria by criteria by Name.
     * @param DepartmentName String Name of NHSP Section
     * @return - List of Sections.
     * @throws CpodException for error
     */
    List<NHSPDepartment> findNhspDepartmentByCriteria(String departmentName)
            throws CpodException;

}
