package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.NHSPSectionDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.NHSPSection;

/**
 * @author AWheatley
 */
@Repository("nhspSectionDao")
public class NHSPSectionDaoImpl extends AbstractDaoImpl<NHSPSection, Long>
        implements NHSPSectionDao {


    /**
     * Logger instance for NHSPSectionDaoImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(NHSPSectionDaoImpl.class);

    /**
     *  NHSP Section DAO Implementation.
     */
    protected NHSPSectionDaoImpl() {
        super(NHSPSection.class);
    }


    @Override
    public List<NHSPSection> findNhspSectionByCriteria(String sectionName)
            throws CpodException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("findNhspSectionByCriteria searching for section name ["
                    + sectionName + "]");
        }

        return findByCriteria(Restrictions.ilike("nhspSectionName",
                sectionName.toLowerCase(), MatchMode.START));
    }
}
