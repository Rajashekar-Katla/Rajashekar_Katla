package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Class representing Person table (ADDRESS_LINK_TBL).
 * @author awheatley
 */
@Entity
@Table(name = "ADDRESS_LINK_TBL")
public class AddressLink extends BaseEntity implements Serializable {
    /**
     * Serial Version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Inner class to represent the compound primary key in the
     * Address_link_tbl.
     * @author ntones
     */
    public static class Id implements Serializable {
        /**
         * serial UID.
         */
        private static final long serialVersionUID = -7894626882280964339L;

        /**
         * The Person foreign key ref.
         */
        @Column(name = "PERSON_ID")
        private Long personId;

        /**
         * The Address foreign key ref.
         */
        @Column(name = "ADDRESS_ID")
        private Long addressId;

        /**
         * Default constructor for creating Id instances.
         */
        public Id() {
            // default constructor
        }

        /**
         * Constructor for creating Id instances with parameters.
         * @param personId the person reference
         * @param addressId the address reference
         */
        public Id(Long personId, Long addressId) {
            this.personId = personId;
            this.addressId = addressId;
        }

        /*
         * (non-Javadoc)
         * @see java.lang.Object#hashCode()
         */
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result
                    + ((addressId == null) ? 0 : addressId.hashCode());
            result = prime * result
                    + ((personId == null) ? 0 : personId.hashCode());
            return result;
        }

        /*
         * (non-Javadoc)
         * @see java.lang.Object#equals(java.lang.Object)
         */
        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            Id other = (Id) obj;
            if (addressId == null) {
                if (other.addressId != null) {
                    return false;
                }
            } else if (!addressId.equals(other.addressId)) {
                return false;
            }
            if (personId == null) {
                if (other.personId != null) {
                    return false;
                }
            } else if (!personId.equals(other.personId)) {
                return false;
            }
            return true;
        }

    }

    @EmbeddedId
    private Id id = new Id();

    @ManyToOne
    @JoinColumn(name = "person_id", insertable = false, updatable = false)
    private Person person;

    @ManyToOne
    @JoinColumn(name = "address_id", insertable = false, updatable = false)
    private Address address;

    /**
     * Default constructor for creating addressLink objects.
     */
    public AddressLink() {
    }

    /**
     * @param modifiedByUser
     * @param person
     * @param address
     */
    public AddressLink(String modifiedByUser, Person person, Address address) {
        // set fields
        super.setModifiedByUser(modifiedByUser);
        this.person = person;
        this.address = address;

        // set id values
        this.id.addressId = address.getId();
        this.id.personId = person.getId();

        // Guarantee RI
        person.getAddressLinks().add(this);
        address.getAddressLinks().add(this);
    }

    /**
     * @return the id
     */
    public Id getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Id id) {
        this.id = id;
    }

    /**
     * @return the person
     */
    public Person getPerson() {
        return person;
    }

    /**
     * @param person the person to set
     */
    public void setPerson(Person person) {
        this.person = person;
    }

    /**
     * @return the address
     */
    public Address getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(Address address) {
        this.address = address;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof AddressLink)) {
            return false;
        }
        AddressLink other = (AddressLink) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    public void removeAddress() {
        person.getAddressLinks().remove(this);
        address.getAddressLinks().remove(this);
    }

}
