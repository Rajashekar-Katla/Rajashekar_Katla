/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.model.RegionLink;

/**
 * Provides methods for managing regionLinks
 * @author awheatley
 */
public interface RegionLinkService extends AbstractService<RegionLink, Long> {

}
