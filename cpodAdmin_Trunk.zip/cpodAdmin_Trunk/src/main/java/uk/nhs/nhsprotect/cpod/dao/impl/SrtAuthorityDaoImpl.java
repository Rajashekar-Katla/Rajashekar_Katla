package uk.nhs.nhsprotect.cpod.dao.impl;

import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.SrtAuthorityDao;
import uk.nhs.nhsprotect.srt.model.SrtAuthority;

/**
 * Methods for managing SRT User Authorities (permissions).
 * @author ntones
 */
@Repository("srtAuthorityDao")
public class SrtAuthorityDaoImpl extends SrtAbstractDaoImpl<SrtAuthority, Long>
        implements SrtAuthorityDao {

    /**
     * @param persistentClass
     */
    public SrtAuthorityDaoImpl() {
        super(SrtAuthority.class);
    }

}
