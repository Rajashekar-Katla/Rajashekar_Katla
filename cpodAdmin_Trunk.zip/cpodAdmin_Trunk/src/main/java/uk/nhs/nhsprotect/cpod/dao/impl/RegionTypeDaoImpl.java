package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.RegionTypeDao;
import uk.nhs.nhsprotect.cpod.model.RegionType;

/**
 * Hibernate implementation of RegionTypeDao interface.
 * @author awheatley
 */
@Repository("regionTypeDao")
public class RegionTypeDaoImpl extends AbstractDaoImpl<RegionType, Long>
        implements RegionTypeDao {
    /**
     * Log4J instance for PersonDaoImpl.class.
     **/
    @SuppressWarnings("unused")
    private static final Logger LOG = Logger.getLogger(RegionType.class);

    /**
     * Address Type DAO.
     */
    protected RegionTypeDaoImpl() {
        super(RegionType.class);
    }

    @Override
    public List<RegionType> findAdressTypeByType(String type) {
        return findByCriteria(Restrictions.ilike("regionType",
                type.toLowerCase(), MatchMode.START));
    }
}
