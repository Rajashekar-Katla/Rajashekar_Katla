package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Region;

/**
 * @author AWheatley
 */
public interface RegionService extends AbstractService<Region, Long> {
    /**
     * Find Region by Region Code.
     * @param Region Code
     * @return Region
     * @throws CpodException on error
     **/
    Region findRegionByRegionCode(String region) throws CpodException;
}
