package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.OrganisationTypeDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.OrganisationType;

/**
 * Hibernate implementation of OrganisationTypeDao interface.
 * @author awheatley
 */
@Repository("organisationTypeDao")
public class OrganisationTypeDaoImpl extends
        AbstractDaoImpl<OrganisationType, Long> implements OrganisationTypeDao {

    /**
     * Address Type DAO.
     */
    protected OrganisationTypeDaoImpl() {
        super(OrganisationType.class);
    }

    @Override
    public List<OrganisationType> findOrganisationTypeByType(String type)
            throws CpodException {
        return findByCriteria(Restrictions.ilike("organisationType",
                type.toLowerCase(), MatchMode.START));
    }
}
