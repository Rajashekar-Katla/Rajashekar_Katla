/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.sirs.model.SirsUserRO;

import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;

/**
 * @author ibandi
 */
public interface SIRSUserServiceRODao extends AbstractDao<SirsUserRO, Long> {

    List<SirsUserRO> findUsersWithoutResponsibilities();

    /**
     * Method to retrieve a 'chunk' of sirs users matching supplied datatables
     * criteria.
     * 
     * @param criterias
     *            used to filter records
     * @param forScreenDisplav
     *            indicates if the query is for an export or to be displayed on
     *            screen
     * @return List<SirsUserRO> matching results
     */
    List<SirsUserRO> findSirsUsersWithDatatablesCriterias(
            DatatablesCriterias criterias, boolean forScreenDisplav);

    /**
     * Query to return the number of filtered records. TODO we could put this on
     * abstract?
     * 
     * @param criterias
     *            used to filter records
     * 
     * @return the number of filtered records
     */
    Long getFilteredCount(DatatablesCriterias criterias);

}
