package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.srt.model.SrtUser;

/**
 * Methods for managing and maintaining SRT user accounts.
 * @author ntones
 */
public interface SrtUserService extends AbstractService<SrtUser, Long> {

}
