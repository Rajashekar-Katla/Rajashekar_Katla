/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller.dto;

import java.io.Serializable;

/**
 * A POJO backing object to bind the personSearch form to.
 * @author ntones
 */
public class PersonSearch implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String reference;
    private String forename;
    private String surname;
    private String status;
    private String personType;

    /**
     * @return the reference
     */
    public String getReference() {
        return reference;
    }

    /**
     * @param reference the reference to set
     */
    public void setReference(String reference) {
        this.reference = reference;
    }

    /**
     * @return the forename
     */
    public String getForename() {
        return forename;
    }

    /**
     * @param forename the forename to set
     */
    public void setForename(String forename) {
        this.forename = forename;
    }

    /**
     * @return the surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * @param surname the surname to set
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the personType
     */
    public String getPersonType() {
        return personType;
    }

    /**
     * @param personType the personType to set
     */
    public void setPersonType(String personType) {
        this.personType = personType;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "PersonSearch [reference=" + reference + ", forename="
                + forename + ", surname=" + surname + ", status=" + status
                + ", personType=" + personType + "]";
    }

}
