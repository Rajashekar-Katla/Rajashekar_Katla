package uk.nhs.nhsprotect.cpod.listener.authentication;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;

import uk.nhs.nhsprotect.cpod.model.authentication.CpodUser;
import uk.nhs.nhsprotect.cpod.model.authentication.User;
import uk.nhs.nhsprotect.cpod.service.UserService;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * Authentication Listener, listens to login events and invokes
 * onApplicationEvent method and passes the event as parameter.
 */
@SuppressWarnings("rawtypes")
public class AuthenticationListener implements ApplicationListener {

    /**
     * Logger instance for AuthenticationListener.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(AuthenticationListener.class);

    @Autowired
    private UserService userService;

    /**
     * Implementation method for handling login events
     */
    public void onApplicationEvent(ApplicationEvent event) {
        // If the user fails to login with a wrong credentialsupdate then,
        // increase the login attempt count. If the count reaches the max
        // allowed then disable the user account
        if (event instanceof AuthenticationFailureBadCredentialsEvent) {
            String userName = null;
            try {
                userName = ((UsernamePasswordAuthenticationToken) event
                        .getSource()).getPrincipal().toString();
                User user = userService.findByReferenceNumber(userName);
                if (user == null) {
                    return;
                }
                int loginAttempts = user.getFailedAttempts();
                ++loginAttempts;
                if (loginAttempts >= CPODConstants.MAX_UNSUCCESSFUL_LOGIN_ATTEMPTS_ALLOWED) {
                    user.setEnabled(false);
                    if (LOG.isDebugEnabled()) {
                        LOG.debug("User " + userName + " is being disabled.");
                    }
                }
                user.setFailedAttempts(loginAttempts);
                userService.update(user);
            } catch (Exception e) {
                LOG.error("Error occured attempting to authenticate for login user ["
                        + userName + "]:\n" + e.getMessage());
            }

        } else if (event instanceof AuthenticationSuccessEvent) {
            // If the user login successfully then,
            // set the login attempt count to zero.
            String userName = null;
            try {
                userName = ((CpodUser) ((UsernamePasswordAuthenticationToken) event
                        .getSource()).getPrincipal()).getUsername();
                User user = userService.findByReferenceNumber(userName);
                user.setFailedAttempts(0);
                userService.update(user);
            } catch (Exception e) {
                LOG.error("Error occured updating user after succseful logon ["
                        + userName + "]" + e.getMessage());
            }
        }
    }

}
