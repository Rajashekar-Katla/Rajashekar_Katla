package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * ORM class representing user authorities within SRT.
 * @author ntones
 */
@Entity
@Table(name = "USER_AUTHORITIES_TBL")
public class SrtUserAuthorities implements Serializable {

    /**
     * serial version uid.
     */
    private static final long serialVersionUID = -8228979633169682942L;

    /**
     * PK for SRT User Authority entity.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "userAuthorityId")
    @GenericGenerator(strategy = "sequence", name = "userAuthorityId", parameters = { @Parameter(name = "sequence", value = "USER_AUTHORITIES_ID_SEQNO") })
    @Column(name = "USER_AUTHORITIES_ID")
    private Long id;

    /**
     * The SRT User relating to this entity.
     */
    @ManyToOne
    @JoinColumn(name = "USER_ID", nullable = false)
    private SrtUser srtUser;

    /**
     * The SRT Authority relating to this entity.
     */
    @ManyToOne
    @JoinColumn(name = "AUTHORITIES_ID", nullable = false)
    private SrtAuthority srtAuthority;

    /**
     * Default constructor.
     */
    public SrtUserAuthorities() {
        // default
    }

    /**
     * Parameterised Constructor.
     * @param srtUser SrtUser to set
     * @param srtAuthority SrtAuthority to set
     */
    public SrtUserAuthorities(SrtUser srtUser, SrtAuthority srtAuthority) {
        this.srtUser = srtUser;
        this.srtAuthority = srtAuthority;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the srtUser
     */
    public SrtUser getSrtUser() {
        return srtUser;
    }

    /**
     * @param srtUser the srtUser to set
     */
    public void setSrtUser(SrtUser srtUser) {
        this.srtUser = srtUser;
    }

    /**
     * @return the srtAuthority
     */
    public SrtAuthority getSrtAuthority() {
        return srtAuthority;
    }

    /**
     * @param srtAuthority the srtAuthority to set
     */
    public void setSrtAuthority(SrtAuthority srtAuthority) {
        this.srtAuthority = srtAuthority;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SrtUserAuthorities other = (SrtUserAuthorities) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

}
