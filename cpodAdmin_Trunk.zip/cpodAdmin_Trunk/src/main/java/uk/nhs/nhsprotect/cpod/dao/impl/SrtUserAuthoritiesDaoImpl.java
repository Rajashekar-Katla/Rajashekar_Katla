package uk.nhs.nhsprotect.cpod.dao.impl;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.SrtUserAuthoritiesDao;
import uk.nhs.nhsprotect.srt.model.SrtUser;
import uk.nhs.nhsprotect.srt.model.SrtUserAuthorities;

/**
 * Methods for managing SRT User Authorities (permissions)
 * @author ntones
 */
@Repository("srtUserAuthoritiesDao")
public class SrtUserAuthoritiesDaoImpl extends
        SrtAbstractDaoImpl<SrtUserAuthorities, Long> implements
        SrtUserAuthoritiesDao {

    /**
     * Logger instance for UserAuthoritiesDaoImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(SrtUserAuthoritiesDaoImpl.class);

    /**
     * @param persistentClass
     */
    public SrtUserAuthoritiesDaoImpl() {
        super(SrtUserAuthorities.class);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.dao.SrtUserAuthoritiesDao#deleteBySrtUser(uk.nhs
     * .nhsprotect.srt.model.SrtUser)
     */
    @Override
    public void deleteBySrtUser(SrtUser entity) {
        StringBuilder buffer = new StringBuilder();
        buffer.append("Delete from SrtUserAuthorities sua where  sua.srtUser.id = :entityId");

        Query query = getCurrentSession().createQuery(buffer.toString());
        query.setLong("entityId", entity.getId());

        int deletedRows = query.executeUpdate();
        if (LOG.isDebugEnabled()) {
            LOG.debug("Number of Rows deleted:" + deletedRows);
        }
    }
}
