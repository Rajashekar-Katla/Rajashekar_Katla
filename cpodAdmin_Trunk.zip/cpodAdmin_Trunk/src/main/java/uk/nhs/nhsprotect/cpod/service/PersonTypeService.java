package uk.nhs.nhsprotect.cpod.service;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.PersonType;

/**
 * @author AWheatley
 */
public interface PersonTypeService extends AbstractService<PersonType, Long> {

    /**
     * Find PersonType by Type.
     * 
     * @param type
     *            . e.g. LCFS
     * @return PersonType
     * @throws CpodException
     *             for error
     */
    PersonType findPersonTypeByType(String type) throws CpodException;

    /**
     * Method to provide a list of person types the logged in user is able to
     * create/manage.
     * 
     * @return List<PersonType> types logged in user is able to manage.
     * @throws CpodException
     *             on error
     */
    List<PersonType> getPersonTypesForUser() throws CpodException;
}
