/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.model.AddressLink;

/**
 * Provides methods for managing addressLinks
 * @author ntones
 */
public interface AddressLinkService extends AbstractService<AddressLink, Long> {

}
