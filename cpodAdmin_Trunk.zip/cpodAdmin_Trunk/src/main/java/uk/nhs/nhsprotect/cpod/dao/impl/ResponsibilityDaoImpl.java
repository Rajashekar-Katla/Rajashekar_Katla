package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.ResponsibilityDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Responsibility;

/**
 * @author AWheatley
 */
@Repository("responsibilityDao")
public class ResponsibilityDaoImpl extends
        AbstractDaoImpl<Responsibility, Long> implements ResponsibilityDao {

    /**
     * Logger instance for RegionDaoImpl.class.
     **/
    private static final Logger LOG = Logger.getLogger(RegionDaoImpl.class);

    /**
     * Responsibility Dao Implementation.
     */
    protected ResponsibilityDaoImpl() {
        super(Responsibility.class);

    }

    @Override
    public List<Responsibility> findResponsibilityByOrgId(Long orgId)
            throws CpodException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("findResponsibilityByOrgId searching for responsibility ["
                    + orgId + "]");
        }
        return findByCriteria(Restrictions.eq("organisation.id", orgId));
    }

    @Override
    public List<Responsibility> findResponsibilityByPersonRoleId(Long personRoleId) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("findResponsibilityByPersonId searching for responsibility ["
                    + personRoleId + "]");
        }
        return findByCriteria(Restrictions.eq("personRole.id", personRoleId));
    }

}
