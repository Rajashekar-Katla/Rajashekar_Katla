package uk.nhs.nhsprotect.sirs.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * This is the 'read-only' SIRS User model class. It retrieves data from a CPOD
 * view.
 * @author ntones
 */
@Entity
@Table(name = "sirs_users")
public class SirsUserRO implements Serializable {

    private static final long serialVersionUID = 100005599L;

    @Id
    private String username;

    private String password;

    private int enabled;

    @Column(name = "FAILED_ATTEMPTS")
    private int failedAttempts;

    @Column(name = "ACTIVE_PASSWORD")
    private int activePassword;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PERSON_ID")
    private Person person;

    @Column(name = "PERSON_ID", insertable = false, nullable = false, updatable = false)
    private String personID;

    @Transient
    private String status;

    public SirsUserRO() {

    }

    public SirsUserRO(String username, String password, int enabled) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
    }

    public SirsUserRO(String username, String password, int enabled,
            int failedAttempts) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
        this.failedAttempts = failedAttempts;
    }

    public int getEnabled() {
        return enabled;
    }

    public void setEnabled(int enabled) {
        this.enabled = enabled;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public void setFailedAttempts(int failedAttempts) {
        this.failedAttempts = failedAttempts;
    }

    public int getActivePassword() {
        return activePassword;
    }

    public void setActivePassword(int activePassword) {
        this.activePassword = activePassword;
    }

    /**
     * @return the person
     */
    public Person getPerson() {
        return person;
    }

    /**
     * @param person the person to set
     */
    public void setPerson(Person person) {
        this.person = person;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        if (1 == this.enabled) {
            return CPODConstants.USER_ENABLED;
        } else {
            return CPODConstants.USER_DISABLED;
        }
    }

    /**
     * @return the personID
     */
    public String getPersonID() {
        return personID;
    }

    /**
     * @param personID the personID to set
     */
    public void setPersonID(String personID) {
        this.personID = personID;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SirsUserRO [username=" + username + ", password=" + password
                + ", enabled=" + enabled + ", failedAttempts=" + failedAttempts
                + ", activePassword=" + activePassword + ", personID="
                + personID + ", status=" + status + "]";
    }

}
