/**
 * 
 */
package uk.nhs.nhsprotect.cpod.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.nhsprotect.cpod.util.UserContextUtil;

/**
 * Exposes the 'userContext' bean to the view.
 * @author ntones
 */
@Service
public class UserContextInterceptor implements HandlerInterceptor {

    @Autowired
    UserContextUtil userContext;

    /*
     * (non-Javadoc)
     * @see
     * org.springframework.web.servlet.HandlerInterceptor#afterCompletion(javax
     * .servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
     * java.lang.Object, java.lang.Exception)
     */
    @Override
    public void afterCompletion(HttpServletRequest request,
            HttpServletResponse response, Object object, Exception exception)
            throws Exception {
        // do nothing

    }

    /*
     * (non-Javadoc)
     * @see
     * org.springframework.web.servlet.HandlerInterceptor#postHandle(javax.servlet
     * .http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
     * java.lang.Object, org.springframework.web.servlet.ModelAndView)
     */
    @Override
    public void postHandle(HttpServletRequest request,
            HttpServletResponse response, Object object,
            ModelAndView modelAndView) throws Exception {
        // do nothing

    }

    /*
     * (non-Javadoc)
     * @see
     * org.springframework.web.servlet.HandlerInterceptor#preHandle(javax.servlet
     * .http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
     * java.lang.Object)
     */
    @Override
    public boolean preHandle(HttpServletRequest request,
            HttpServletResponse response, Object object) throws Exception {
        // get the user context
        request.setAttribute("userContext", userContext);
        return true;
    }
}
