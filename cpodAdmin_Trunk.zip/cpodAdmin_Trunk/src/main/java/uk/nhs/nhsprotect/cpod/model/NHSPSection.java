package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Class representing Person table (NHSP_SECTION_TBL).
 * @author awheatley
 */
@Entity
@Table(name = "NHSP_SECTION_TBL")
public class NHSPSection extends BaseEntity implements Serializable {
    /**
     * Serial Version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key identifier.
     */
    @Id
    @Column(name = "nhsp_section_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "nhspSectionID")
    @GenericGenerator(strategy = "sequence", name = "nhspSectionID", parameters = { @Parameter(name = "sequence", value = "BE_ID_SEQNO") })
    private Long id;

    /**
     * Manager ID.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "nhsp_section_manager")
    private Person manager;

    /**
     * NHSPDepartment. Linked to NHSPDepartment
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "nhsp_department_id")
    private NHSPDepartment nhspDepartment;

    /**
     * NHSP Section Name.
     */
    @Column(name = "nhsp_section_name")
    private String nhspSectionName;

    /**
     * @return the nhspDepartment
     */
    public NHSPDepartment getNhspDepartment() {
        return nhspDepartment;
    }

    /**
     * @param nhspDepartment the nhspDepartment to set
     */
    public void setNhspDepartment(NHSPDepartment nhspDepartment) {
        this.nhspDepartment = nhspDepartment;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the manager
     */
    public Person getManager() {
        return manager;
    }

    /**
     * @param manager the manager to set
     */
    public void setManager(Person manager) {
        this.manager = manager;
    }

    /**
     * @return the nhspSectionName
     */
    public String getNhspSectionName() {
        return nhspSectionName;
    }

    /**
     * @param nhspSectionName the nhspSectionName to set
     */
    public void setNhspSectionName(String nhspSectionName) {
        this.nhspSectionName = nhspSectionName;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((manager == null) ? 0 : manager.hashCode());
        result = prime * result
                + ((nhspDepartment == null) ? 0 : nhspDepartment.hashCode());
        result = prime * result
                + ((nhspSectionName == null) ? 0 : nhspSectionName.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof NHSPSection)) {
            return false;
        }
        NHSPSection other = (NHSPSection) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (manager == null) {
            if (other.manager != null) {
                return false;
            }
        } else if (!manager.equals(other.manager)) {
            return false;
        }
        if (nhspDepartment == null) {
            if (other.nhspDepartment != null) {
                return false;
            }
        } else if (!nhspDepartment.equals(other.nhspDepartment)) {
            return false;
        }
        if (nhspSectionName == null) {
            if (other.nhspSectionName != null) {
                return false;
            }
        } else if (!nhspSectionName.equals(other.nhspSectionName)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "NHSPSection [id=" + id + ", manager=" + manager
                + ", nhspDepartment=" + nhspDepartment + ", nhspSectionName="
                + nhspSectionName + "]";
    }

}
