/**
 * 
 */
package uk.nhs.nhsprotect.cpod.util;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.common.collect.ImmutableMap;

/**
 * Holds constant values for use throughout CPOD application.
 * @author ntones
 */
public final class CPODConstants {

    /**
     * Private CPODConstants constructor. The caller references the constants
     * using <tt>Constsants.EMPTY_STRING</tt>, and so on. Thus, the caller
     * should be prevented from constructing objects of this class, by declaring
     * this private constructor.
     */
    private CPODConstants() {
        // private default constructor
    }

    /* String constants */
    /**
     * A default blank String = ''.
     */
    public static final String BLANK_STR = "";

    /**
     * A default space String = ' '.
     */
    public static final String SPACE_STR = " ";

    /* Model Constants */

    /**
     * Description of Address Type work = 'Work'.
     */
    public static final String ADDRESS_TYPE_WORK_DESC = "Work";

    /**
     * Id of Address Type work = 1.
     */
    public static final Long ADDRESS_TYPE_WORK_ID = Long.valueOf(1l);

    /**
     * Description of Address Type home = 'Home'.
     */
    public static final String ADDRESS_TYPE_HOME_DESC = "Home";

    /**
     * Id of Address Type work = 2.
     */
    public static final Long ADDRESS_TYPE_HOME_ID = Long.valueOf(2l);

    /* PERSON TYPE CONSTANTS */
    public static final int PERSON_TYPE_COMP_ID = 1;
    public static final String PERSON_TYPE_COMP_DESC = "COMP";
    public static final int PERSON_TYPE_CU_ID = 2;
    public static final String PERSON_TYPE_CU_DESC = "CU";
    public static final int PERSON_TYPE_OPS_ID = 3;
    public static final String PERSON_TYPE_OPS_DESC = "OPS";
    public static final int PERSON_TYPE_LCFS_ID = 4;
    public static final String PERSON_TYPE_LCFS_DESC = "LCFS";
    public static final int PERSON_TYPE_LSMS_ID = 5;
    public static final String PERSON_TYPE_LSMS_DESC = "LSMS";
    public static final int PERSON_TYPE_TEMP_ID = 6;
    public static final String PERSON_TYPE_TEMP_DESC = "TEMP";
    public static final int PERSON_TYPE_EXTERNAL_ID = 15;
    public static final String PERSON_TYPE_EXTERNAL_DESC = "EXTERNAL";
    public static final int PERSON_TYPE_LMS_ID = 20;
    public static final String PERSON_TYPE_LMS_DESC = "LMS";
    public static final int PERSON_TYPE_LSSP_ID = 21;
    public static final String PERSON_TYPE_LSSP_DESC = "LSSP";
    public static final int PERSON_TYPE_SMD_ID = 22;
    public static final String PERSON_TYPE_SMD_DESC = "SMD";
    public static final int PERSON_TYPE_SPEC_ID = 23;
    public static final String PERSON_TYPE_SPEC_DESC = "SPEC";

    /**
     * Map containing the person types that a SIRS Admin user is able to edit.
     * These are LMS, LSSP, SMD and SPEC.
     */
    public static final ImmutableMap<Long, String> SIRS_ADMIN_PERSON_TYPES_EDITABLE_MAP = ImmutableMap
            .<Long, String> builder()
            .put(Long.valueOf(PERSON_TYPE_LMS_ID), PERSON_TYPE_LMS_DESC)
            .put(Long.valueOf(PERSON_TYPE_LSSP_ID), PERSON_TYPE_LSSP_DESC)
            .put(Long.valueOf(PERSON_TYPE_SMD_ID), PERSON_TYPE_SMD_DESC)
            .put(Long.valueOf(PERSON_TYPE_SPEC_ID), PERSON_TYPE_SPEC_DESC)
            .build();

    /**
     * Map containing the person types that a SIRS Admin user is able to edit.
     * These are LMS, LSSP, SMD and SPEC.
     */
    public static final ImmutableMap<Long, String> SIRS_ADMIN_RESPONSIBILITIES_TYPES_EDITABLE_MAP = ImmutableMap
            .<Long, String> builder()
            .put(Long.valueOf(PERSON_TYPE_LMS_ID), PERSON_TYPE_LMS_DESC)
            .put(Long.valueOf(PERSON_TYPE_LSSP_ID), PERSON_TYPE_LSSP_DESC)
            .put(Long.valueOf(PERSON_TYPE_SMD_ID), PERSON_TYPE_SMD_DESC)
            .put(Long.valueOf(PERSON_TYPE_SPEC_ID), PERSON_TYPE_SPEC_DESC)
            .build();

    /**
     * Map containing the person types that an LSDS Admin user is able to edit.
     * These are LSMS and LCFS.
     */
    public static final ImmutableMap<Long, String> LSDS_ADMIN_PERSON_TYPES_EDITABLE_MAP = ImmutableMap
            .<Long, String> builder()
            .put(Long.valueOf(PERSON_TYPE_LSMS_ID), PERSON_TYPE_LSMS_DESC)
            .put(Long.valueOf(PERSON_TYPE_LCFS_ID), PERSON_TYPE_LCFS_DESC)
            .put(Long.valueOf(PERSON_TYPE_EXTERNAL_ID),
                    PERSON_TYPE_EXTERNAL_DESC).build();

    /**
     * Map containing the person types that an Training Admin user is able to
     * edit. EXTERNAL only.
     */
    public static final ImmutableMap<Long, String> TRAINING_ADMIN_PERSON_TYPES_EDITABLE_MAP = ImmutableMap
            .<Long, String> builder()
            .put(Long.valueOf(PERSON_TYPE_EXTERNAL_ID),
                    PERSON_TYPE_EXTERNAL_DESC)

            .build();

    /*
     * Map CPOD personType Description as Key and SIRS authority_ID as Value
     */
    public static final ImmutableMap<String, Long> CPOD_PERSONTYPE_SIRS_USER_AUTHORITY_MAP = ImmutableMap
            .<String, Long> builder().put("LSMS", 1l).put("LSSP", 2l)
            .put("LMS", 3l).put("OPS", 4l).put("CU", 5l).put("SMD", 6l)
            .put("SPEC", 7l).build();

    /**
     * Max number of attempts for user login
     */
    public static final int MAX_UNSUCCESSFUL_LOGIN_ATTEMPTS_ALLOWED = 3;

    /**
     * Default user account password, requires users to change at login.
     */
    public static final String DEFAULT_PASSWORD = "changeit";

    /**
     * SIRS External default complex NAM password as MD5 hash.
     */
    public static final String SIRS_EXTERNAL_DEFAULT_PASSWORD = "9ae8f2ff266050bd237a527f5f589f38";

    /**
     * Default username so that audit may still record some identity.
     */
    public static final String DEFAULT_USERNAME = "CPOD";

    /**
     * Value expected from option lists containing an ALL option.
     */
    public static final String ALL_OPTION = "ALL";

    /**
     * Date formate dd-MMM-yyyy e.g. 16-Feb-1982.
     */
    public static final String DD_MON_YYYY_DATE_FORMAT = "dd-MMM-yyyy";

    /**
     * Date format dd/mm/yyyy e.g. 16/02/1982 - safe for JavaScript dates.
     */
    public static final String DD_MM_YYYY_DATE_FORMAT = "dd/MM/yyyy";

    /*
     * Person statuses
     */
    public static final Map<String, String> PERSON_STATUSES;

    public static final String PERSON_STATUS_ACTIVE = "Y";
    public static final String PERSON_STATUS_INACTIVE = "N";
    public static final String PERSON_STATUS_PENDING = "P";

    public static final String PERSON_STATUS_ACTIVE_DESCRIPTION = "Active";
    public static final String PERSON_STATUS_INACTIVE_DESCRIPTION = "Inactive";
    public static final String PERSON_STATUS_PENDING_DESCRIPTION = "Pending";

    public static final String USER_ENABLED = "Enabled";

    public static final String USER_DISABLED = "Disabled";

    static {
        // initialise person status options - unmodifiable
        Map<String, String> localStatus = new LinkedHashMap<String, String>();
        localStatus.put(PERSON_STATUS_ACTIVE, PERSON_STATUS_ACTIVE_DESCRIPTION);
        localStatus.put(PERSON_STATUS_INACTIVE,
                PERSON_STATUS_INACTIVE_DESCRIPTION);
        localStatus.put(PERSON_STATUS_PENDING,
                PERSON_STATUS_PENDING_DESCRIPTION);
        PERSON_STATUSES = Collections.unmodifiableMap(localStatus);
    }

    public static final String USER_ROLE = "ROLE_USER";
    public static final String ADMIN_ROLE = "ROLE_ADMIN";
    public static final String LSDS_ADMIN_ROLE = "ROLE_LSDS_ADMIN";
    public static final String TRAINING_ADMIN_ROLE = "ROLE_TRAINING_ADMIN";
    public static final String SIRS_ADMIN_ROLE = "ROLE_SIRS_ADMIN";

    public static final String CPOD_USER_OBJECT = "User";
    public static final String SIRS_USER_OBJECT = "SirsUserRO";
    public static final String SRT_USER_OBJECT = "SrtUserRO";

    public static final String CPOD_SYSTEM = "CPOD";
    public static final String SIRS_SYSTEM = "SIRS";
    public static final String SRT_SYSTEM = "SRT";

    /**
     * Map containing the name of the user object for a given system, keyed by
     * system name.
     */
    public static final ImmutableMap<String, String> SYSTEM_USER_OBJECTS = ImmutableMap
            .<String, String> builder().put(CPOD_SYSTEM, CPOD_USER_OBJECT)
            .put(SIRS_SYSTEM, SIRS_USER_OBJECT)
            .put(SRT_SYSTEM, SRT_USER_OBJECT).build();

}
