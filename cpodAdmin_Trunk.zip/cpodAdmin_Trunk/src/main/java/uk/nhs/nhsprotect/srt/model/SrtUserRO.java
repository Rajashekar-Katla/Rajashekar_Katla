package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * This is the 'read-only' SRT User model class. It retrieves data from a CPOD
 * view.
 * @author ntones
 */
@Entity
@Table(name = "srt_users")
public class SrtUserRO implements Serializable {

    private static final long serialVersionUID = 100005599L;

    @Id
    private String username;

    private String password;

    private int enabled;

    @Column(name = "FAILED_ATTEMPTS")
    private int failedAttempts;

    @Column(name = "DEFAULT_PASSWORD_CHANGED")
    @Type(type = "yes_no")
    private boolean defaultPasswordChanged;

    @OneToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "PERSON_ID")
    private Person person;

    @Column(name = "PERSON_ID", insertable = false, nullable = false, updatable = false)
    private String personID;

    @Transient
    private String status;

    @Column(name = "USER_ID", insertable = false, nullable = false, updatable = false)
    private Long userId;

    public SrtUserRO() {

    }

    public SrtUserRO(String username, String password, int enabled) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
    }

    public SrtUserRO(String username, String password, int enabled,
            int failedAttempts) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
        this.failedAttempts = failedAttempts;
    }

    public int getEnabled() {
        return enabled;
    }

    public void setEnabled(int enabled) {
        this.enabled = enabled;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public void setFailedAttempts(int failedAttempts) {
        this.failedAttempts = failedAttempts;
    }

    /**
     * @return the defaultPasswordChanged
     */
    public boolean isDefaultPasswordChanged() {
        return defaultPasswordChanged;
    }

    /**
     * @param defaultPasswordChanged the defaultPasswordChanged to set
     */
    public void setDefaultPasswordChanged(boolean defaultPasswordChanged) {
        this.defaultPasswordChanged = defaultPasswordChanged;
    }

    /**
     * @return the person
     */
    public Person getPerson() {
        return person;
    }

    /**
     * @param person the person to set
     */
    public void setPerson(Person person) {
        this.person = person;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        if (1 == this.enabled) {
            return CPODConstants.USER_ENABLED;
        } else {
            return CPODConstants.USER_DISABLED;
        }
    }

    /**
     * @return the personID
     */
    public String getPersonID() {
        return personID;
    }

    /**
     * @param personID the personID to set
     */
    public void setPersonID(String personID) {
        this.personID = personID;
    }

    /**
     * @return the userId
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SrtUserRO [username=" + username + ", password=" + password
                + ", enabled=" + enabled + ", failedAttempts=" + failedAttempts
                + ", defaultPasswordChanged=" + defaultPasswordChanged
                + ", person=" + person + ", personID=" + personID + ", status="
                + status + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((personID == null) ? 0 : personID.hashCode());
        result = prime * result
                + ((username == null) ? 0 : username.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SrtUserRO other = (SrtUserRO) obj;
        if (personID == null) {
            if (other.personID != null) {
                return false;
            }
        } else if (!personID.equals(other.personID)) {
            return false;
        }
        if (username == null) {
            if (other.username != null) {
                return false;
            }
        } else if (!username.equals(other.username)) {
            return false;
        }
        return true;
    }

}
