package uk.nhs.nhsprotect.cpod.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Criterion;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.service.AbstractService;

/**
 * @author ibandi
 * @param <T> Class
 * @param <ID> id
 */
@Transactional(value = "sirsTransactionManager", readOnly = true, propagation = Propagation.REQUIRED)
public abstract class SirsAbstractServiceImpl<T, ID extends Serializable>
        implements AbstractService<T, ID> {

    @Override
    @Transactional(value = "sirsTransactionManager", readOnly = false)
    public ID save(T entity) throws CpodException {
        return getDao().save(entity);
    }

    @Override
    @Transactional(value = "sirsTransactionManager", readOnly = false)
    public void delete(T entity) throws CpodException {
        getDao().delete(entity);

    }

    @Override
    @Transactional(value = "sirsTransactionManager", readOnly = true)
    public List<T> findAll() throws CpodException {
        return getDao().findAll();
    }

    @Override
    @Transactional(value = "sirsTransactionManager", readOnly = false)
    public void deleteAll() throws CpodException {
        throw new CpodException(
                "Detele All SirsUsers method is not implemented");

    }

    @Override
    @Transactional(value = "sirsTransactionManager", readOnly = false)
    public void saveOrUpdate(T entity) throws CpodException {
        getDao().saveOrUpdate(entity);

    }

    @Override
    public T findById(ID id) throws CpodException {
        T result = getDao().findById(id);
        // refresh
        if (result != null) {
            getDao().getCurrentSession().refresh(result);
        }
        return result;
    }

    @Override
    @Transactional(value = "sirsTransactionManager", readOnly = false)
    public void update(T entity) throws CpodException {
        getDao().update(entity);

    }

    @Override
    public List<T> findByCriteria(Criterion criterion) throws CpodException {
        return getDao().findByCriteria(criterion);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#findByCriterias(java.util
     * .Map)
     */
    @Override
    public List<T> findByAndCriterias(Map<String, String> searchCriteria) {
        return getDao().findByAndCriterias(searchCriteria);
    }

    /**
     * Abstract method to return the typed Dao. Concrete instances of this class
     * must provide a valid implementation of this method
     * @return AbstractDao<T, ID> The Dao instance of the implementing class
     */
    public abstract AbstractDao<T, ID> getDao();

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#merge(java.lang.Object)
     */
    @Override
    @Transactional(value = "sirsTransactionManager", readOnly = false)
    public T merge(T entity) {

        return getDao().merge(entity);
    }

}
