/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.AuthorityDao;
import uk.nhs.nhsprotect.cpod.model.authentication.Authority;

/**
 * @author ntones
 */
@Repository("authorityDao")
public class AuthorityDaoImpl extends AbstractDaoImpl<Authority, Long>
        implements AuthorityDao {

    /**
     * Constructor.
     */
    protected AuthorityDaoImpl() {
        super(Authority.class);

    }

}
