/** CPOD Exceptions.
 */
package uk.nhs.nhsprotect.cpod.exception;
