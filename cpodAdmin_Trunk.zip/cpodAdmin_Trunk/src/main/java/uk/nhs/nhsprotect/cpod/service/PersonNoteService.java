package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.model.PersonNote;

public interface PersonNoteService extends AbstractService<PersonNote, Long> {

}
