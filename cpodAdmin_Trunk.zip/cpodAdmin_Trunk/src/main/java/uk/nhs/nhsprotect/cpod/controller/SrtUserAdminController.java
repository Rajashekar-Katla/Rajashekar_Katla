package uk.nhs.nhsprotect.cpod.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import uk.nhs.nhsprotect.cpod.service.SrtAuthorityService;
import uk.nhs.nhsprotect.cpod.service.SrtUserService;
import uk.nhs.nhsprotect.srt.model.SrtAuthority;
import uk.nhs.nhsprotect.srt.model.SrtUser;

/**
 * Spring controller class to manage requests relating to CPOD user admin
 * functions.
 * @author ntones
 */
@Controller
public class SrtUserAdminController extends CpodBaseController {

    /**
     * Reference to SrtAuthorityService.
     */
    @Autowired
    private SrtAuthorityService srtAuthorityService;

    /**
     * Reference to SrtUserService.
     */
    @Autowired
    private SrtUserService srtUserService;

    /**
     * Logger instance for CommonPagesController.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(SrtUserAdminController.class);

    /**
     * Handles the request to edit SRT users, returns a list of all current SRT
     * users (enabled and disabled).
     * @param modelMap the current model map @return tile view for display
     * @return name of view for display
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/srt/users" }, method = RequestMethod.GET)
    public String listSrtUsers(ModelMap modelMap) throws Exception {
        // now handled via ajax call

        return "srt-user-results";
    }

    /**
     * Handles the request to create a new SRT user.
     * @param modelMap the current model map
     * @return tile view for display
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/srt/user" }, method = RequestMethod.GET)
    public String createNewSrtUser(ModelMap modelMap) throws Exception {

        List<SrtAuthority> srtAuthorities = srtAuthorityService.findAll();
        SrtUser srtUser = new SrtUser();

        modelMap.put("srtUser", srtUser);
        modelMap.put("mode", "Create New");
        modelMap.put("srtAuthorities", srtAuthorities);

        return "srt-user-view";
    }

    /**
     * Handles the request to view an SRT user.
     * @param modelMap the current model map
     * @return tile view for display
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/srt/user/{userId}" }, method = RequestMethod.GET)
    public String viewSrtUser(ModelMap modelMap, @PathVariable Long userId)
            throws Exception {

        List<SrtAuthority> srtAuthorities = srtAuthorityService.findAll();
        SrtUser srtUser = srtUserService.findById(userId);

        modelMap.put("srtUser", srtUser);
        modelMap.put("mode", "Edit");
        modelMap.put("srtAuthorities", srtAuthorities);

        return "srt-user-view";
    }

    /**
     * Handles the submit from view SRT user page.
     * @param srtUserModel the model submitted
     * @param modelMap the current model map
     * @return tile view for display
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/srt/user", "/admin/srt/user/{userId}" }, method = RequestMethod.POST)
    public String saveOrUpdateSrtUser(@ModelAttribute SrtUser srtUserModel,
            ModelMap modelMap) throws Exception {

        if (LOG.isDebugEnabled()) {
            LOG.debug("received " + srtUserModel);
        }

        // save the instance ...
        srtUserService.saveOrUpdate(srtUserModel);

        return "redirect:/admin/srt/user/" + srtUserModel.getId();
    }

    /**
     * Handles the SRT User Enable/Disable.
     * @param modelMap the model map
     * @param userId the ID of the user to be altered
     * @param status the status to be updated
     * @return value of forward depending on query outcome
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/srt/updateUserStatus" }, method = RequestMethod.POST)
    public @ResponseBody String updateSrtUserStatus(ModelMap modelMap,
            @RequestParam(value = "id", required = true) Long userId,
            @RequestParam(value = "userStatus", required = true) boolean status)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Enable/Disable SRT USER:" + userId);
        }

        SrtUser srtUser = srtUserService.findById(userId);
        srtUser.setEnabled(status);
        srtUserService.saveOrUpdate(srtUser);

        return "SRT User [" + srtUser.getUsername() + "] status updated.";

    }

    /**
     * Handles the SRT User Delete.
     * @param modelMap the model map
     * @param userId the ID of the user to be deleted
     * @return value of forward depending on query outcome
     * @throws Exception on error
     */
    @RequestMapping(value = { "/admin/srt/deleteSrtUser" }, method = RequestMethod.POST)
    public @ResponseBody String deleteSrtUser(ModelMap modelMap,
            @RequestParam(value = "deleteUserId", required = true) Long userId)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Delete SRT USER:" + userId);
        }

        SrtUser srtUser = srtUserService.findById(userId);
        srtUserService.delete(srtUser);

        return "SRT User [" + userId + "] deleted.";

    }

}
