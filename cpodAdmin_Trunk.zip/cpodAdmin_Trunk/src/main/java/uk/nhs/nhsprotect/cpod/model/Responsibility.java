package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * Class representing Responsibility table (RESPONSIBILITIES_TBL).
 * @author awheatley
 */
@Entity
@Table(name = "RESPONSIBILITIES_TBL")
public class Responsibility extends BaseEntity implements
        Comparable<Responsibility>, Serializable {

    /**
     * Serial Version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key identifier.
     */
    @Id
    @Column(name = "resp_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "respID")
    @GenericGenerator(strategy = "sequence", name = "respID", parameters = { @Parameter(name = "sequence", value = "RESP_ID_SEQ") })
    private Long id;

    /**
     * Is personRole a lead.
     */
    @Column(name = "lead")
    @Type(type = "yes_no")
    private boolean lead;

    /**
     * Start Date.
     */
    @Column(name = "start_date")
    private Date startDate;

    /**
     * End Date.
     */
    @Column(name = "end_date")
    private Date endDate;

    /**
     * Organisation ID.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "org_id")
    private Organisation organisation;

    @Column(name = "org_id", updatable = false, insertable = false)
    private String organisationId;

    /**
     * Person Role ID
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "person_role_id")
    private PersonRole personRole;

    @Column(name = "person_role_id", updatable = false, insertable = false)
    private String personRoleId;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the startDate
     */
    public Date getStartDate() {
        if (startDate == null) {
            return null;
        } else {
            return new Date(startDate.getTime());
        }
    }

    /**
     * @param startDate the startDate to set
     */
    public void setStartDate(Date startDate) {
        if (startDate == null) {
            this.startDate = null;
        } else {
            this.startDate = new Date(startDate.getTime());
        }
    }

    /**
     * @return the endDate
     */
    public Date getEndDate() {
        if (endDate == null) {
            return null;
        } else {
            return new Date(endDate.getTime());
        }
    }

    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(Date endDate) {
        if (endDate == null) {
            this.endDate = null;
        } else {
            this.endDate = new Date(endDate.getTime());
        }
    }

    /**
     * @return the lead
     */
    public boolean isLead() {
        return lead;
    }

    /**
     * @param lead the lead to set
     */
    public void setLead(boolean lead) {
        this.lead = lead;
    }

    /**
     * @return the organisation
     */
    public Organisation getOrganisation() {
        return organisation;
    }

    /**
     * @param organisation the organisation to set
     */
    public void setOrganisation(Organisation organisation) {
        this.organisation = organisation;
    }

    /**
     * @return the personRole
     */
    public PersonRole getPersonRole() {
        return personRole;
    }

    /**
     * @param person Role to set
     */
    public void setPersonRole(PersonRole personRole) {
        this.personRole = personRole;
    }

    /**
     * @return the organisationId
     */
    public String getOrganisationId() {
        return organisationId;
    }

    /**
     * @param organisationId the organisationId to set
     */
    public void setOrganisationId(String organisationId) {
        this.organisationId = organisationId;
    }

    /**
     * @return the personRoleId
     */
    public String getPersonRoleId() {
        return personRoleId;
    }

    /**
     * @param personRoleId the personRoleId to set
     */
    public void setPersonRoleId(String personRoleId) {
        this.personRoleId = personRoleId;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + (lead ? 1231 : 1237);
        result = prime * result
                + ((organisationId == null) ? 0 : organisationId.hashCode());
        result = prime * result
                + ((personRoleId == null) ? 0 : personRoleId.hashCode());
        result = prime * result
                + ((startDate == null) ? 0 : startDate.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Responsibility)) {
            return false;
        }
        Responsibility other = (Responsibility) obj;
        if (endDate == null) {
            if (other.endDate != null) {
                return false;
            }
        } else if (endDate.getTime() != other.endDate.getTime()) {
            return false;
        }
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (lead != other.lead) {
            return false;
        }
        if (organisationId == null) {
            if (other.organisationId != null) {
                return false;
            }
        } else if (!organisationId.equals(other.organisationId)) {
            return false;
        }
        if (personRoleId == null) {
            if (other.personRoleId != null) {
                return false;
            }
        } else if (!personRoleId.equals(other.personRoleId)) {
            return false;
        }
        if (startDate == null) {
            if (other.startDate != null) {
                return false;
            }
        } else if (startDate.getTime() != other.startDate.getTime()) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Responsibility [id=" + id + ", lead=" + lead + ", startDate="
                + startDate + ", endDate=" + endDate + ", organisationId="
                + organisationId + ", personRoleId=" + personRoleId + "]";
    }

    // Collections of this class are ordered by startDate then OrgName
    @Override
    public int compareTo(Responsibility other) {
        int result = 0;
        // order by startdate
        result = this.getStartDate().compareTo(other.getStartDate());
        if (result == 0) {
            // order by org name if start dates equal
            result = this.getOrganisation().getOrgName()
                    .compareTo(other.getOrganisation().getOrgName());
        }
        return result;
    }

    @Transient
    public String getStartDateString() {
        return new SimpleDateFormat(CPODConstants.DD_MM_YYYY_DATE_FORMAT)
                .format(startDate);
    }

    @Transient
    public String getEndDateString() {
        return new SimpleDateFormat(CPODConstants.DD_MM_YYYY_DATE_FORMAT)
                .format(endDate);
    }
}
