/** Interceptor Model package.
 */
package uk.nhs.nhsprotect.cpod.model.interceptor;

