/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.sirs.model.SirsAuthority;

/**
 * @author ntones
 */
public interface SirsAuthorityService extends
        AbstractService<SirsAuthority, Long> {

}
