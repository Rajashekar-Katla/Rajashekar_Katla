package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.PersonRole;

/**
 * DAO for PersonRole Class.
 * @author AWheatley
 */
public interface PersonRoleDao extends AbstractDao<PersonRole, Long> {

    /**
     * Find all PersonRoles with matching personRef.
     * @param personRef Person's reference number e.g. LCFS1234
     * @return - List of PersonRoles with matching PersonRef
     * @throws CpodException for error
     */
    List<PersonRole> findPersonRolesByPersonRef(String personRef)
            throws CpodException;

    /**
     * Find all PersonRole matching Person Id
     * @param personId Id of Person
     * @return list of person roles
     */
    List<PersonRole> findPersonRolesByPersonId(Long personId)
            throws CpodException;

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.dao.AbstractDao#deleteAll()
     */
    int deleteAll() throws CpodException;

}
