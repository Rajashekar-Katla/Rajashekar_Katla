package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.controller.dto.OrganisationResult;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Organisation;

/**
 * DAO for Organisation class.
 * @author awheatley
 */
public interface OrganisationDao extends AbstractDao<Organisation, Long> {

    /**
     * Find all organisations with matching organisationRef.
     * @param orgCode - e.g. RX1
     * @return - List of Organisations
     * @throws CpodException for error
     */
    List<Organisation> findorganisationsByOrganisationsRef(String orgCode)
            throws CpodException;

    /**
     * Method used to generate a list of organisations matching the typed query.
     * @param query to search for
     * @param personId to search for
     * @return List<OrganisationResult> matching query
     */
    List<OrganisationResult> getOrganisationsForResponsibilities(String query,
            Long personId);

    /**
     * Method used to generate a list of active organisations matching the typed query.
     * @param query to search for
     * @return List<OrganisationResult> matching query
     */
    List<OrganisationResult> getOrganisationsForPersons(String query);
}
