package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.srt.model.SrtUser;

/**
 * DAO interface offering methods for SrtUser objects.
 * @author ntones
 */
public interface SrtUserServiceDao extends AbstractDao<SrtUser, Long> {

    /**
     * Method to retrieve a password value from the SRT database function.
     * @return String password
     * @throws CpodException on error
     */
    String getPassword() throws CpodException;

}
