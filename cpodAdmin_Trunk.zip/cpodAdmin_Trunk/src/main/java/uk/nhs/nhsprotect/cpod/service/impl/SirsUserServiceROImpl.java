/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.controller.dto.SystemUserDTO;
import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.SIRSUserServiceRODao;
import uk.nhs.nhsprotect.cpod.service.SirsUserServiceRO;
import uk.nhs.nhsprotect.sirs.model.SirsUserRO;

import com.github.dandelion.datatables.core.ajax.DataSet;
import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;

/**
 * @author ntones
 */
@Service("sirsUserServiceRO")
@Transactional(propagation = Propagation.REQUIRED, value = "transactionManager", readOnly = true)
public class SirsUserServiceROImpl extends
        AbstractServiceImpl<SirsUserRO, Long> implements SirsUserServiceRO {

    @Autowired
    private SIRSUserServiceRODao sirsUserServiceRODao;

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.SirsUserServiceRO#
     * findUsersWithoutResponsibilities()
     */
    @Override
    public List<SirsUserRO> findUsersWithoutResponsibilities() {
        return ((SIRSUserServiceRODao) getDao())
                .findUsersWithoutResponsibilities();
    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.SirsUserServiceRO#
     * findSirsUsersWithDatatablesCriterias
     * (com.github.dandelion.datatables.core.ajax.DatatablesCriterias, boolean)
     */
    @Override
    public DataSet<SystemUserDTO> findSirsUsersWithDatatablesCriterias(
            DatatablesCriterias criterias, boolean forScreenDisplav) {
        List<SirsUserRO> users = ((SIRSUserServiceRODao) getDao())
                .findSirsUsersWithDatatablesCriterias(criterias,
                        forScreenDisplav);

        List<SystemUserDTO> userDTOs = new ArrayList<SystemUserDTO>();
        for (SirsUserRO ro : users) {
            userDTOs.add(SystemUserDTO.createFromSirsUserRO(ro));
        }

        Long count = sirsUserServiceRODao.getTotalCount();
        Long countFiltered = sirsUserServiceRODao.getFilteredCount(criterias);

        return new DataSet<SystemUserDTO>(userDTOs, count, countFiltered);
    }

    @Override
    public AbstractDao<SirsUserRO, Long> getDao() {

        return sirsUserServiceRODao;
    }

}
