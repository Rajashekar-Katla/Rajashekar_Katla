/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.MessageSource;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import uk.nhs.nhsprotect.cpod.util.CPODConstants;
import uk.nhs.nhsprotect.cpod.util.UserContextUtil;

/**
 * Controller declaring resources that can be accessed by all extending classes.
 * @author ntones
 */
public abstract class CpodBaseController {

    /**
     * Access the message.properties file through this reference.
     */
    @Autowired
    private MessageSource messageSource;

    /**
     * Access the session user through this reference.
     */
    @Autowired
    private UserContextUtil userConextUtil;

    /**
     * Access the password encoder through this reference
     */
    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * Bind all date objects to a formatted dates string.
     * @param binder
     */
    @InitBinder
    private void dateBinder(WebDataBinder binder) {
        // The date format to parse or output your dates
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                CPODConstants.DD_MM_YYYY_DATE_FORMAT);
        // Create a new CustomDateEditor
        CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
        // Register it as custom editor for the Date type
        binder.registerCustomEditor(Date.class, editor);
    }

    /**
     * @return the messageSource
     */
    public MessageSource getMessageSource() {
        return messageSource;
    }

    /**
     * @return the userConextUtil
     */
    public UserContextUtil getUserConextUtil() {
        return userConextUtil;
    }

    /**
     * @return the passwordEncoder
     */
    public PasswordEncoder getPasswordEncoder() {
        return passwordEncoder;
    }

}
