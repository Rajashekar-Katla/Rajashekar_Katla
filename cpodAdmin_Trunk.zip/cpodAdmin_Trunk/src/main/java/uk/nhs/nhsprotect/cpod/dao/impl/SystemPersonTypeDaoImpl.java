package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.SystemPersonTypeDao;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;

/**
 * Hibernate implementation of SystemPersonTypeDao.
 * @author ntones
 */
@Repository("systemPersonTypeDao")
public class SystemPersonTypeDaoImpl extends
        AbstractDaoImpl<SystemPersonType, Long> implements SystemPersonTypeDao {

    /**
     * SystemPersonType DAO.
     */
    protected SystemPersonTypeDaoImpl() {
        super(SystemPersonType.class);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<SystemPersonType> findBySystemName(String system) {
        DetachedCriteria criteria = DetachedCriteria
                .forClass(getPersistentClass());
        criteria.createAlias("system", "system").add(
                Restrictions.ilike("system.name", system));
        return (List<SystemPersonType>) criteria.getExecutableCriteria(
                getCurrentSession()).list();
    }
}
