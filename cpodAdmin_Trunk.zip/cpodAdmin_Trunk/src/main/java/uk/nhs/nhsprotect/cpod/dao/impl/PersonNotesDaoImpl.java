package uk.nhs.nhsprotect.cpod.dao.impl;

import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.PersonNotesDao;
import uk.nhs.nhsprotect.cpod.model.PersonNote;

/**
 * @author AWheatley
 */
@Repository("personNotesDao")
public class PersonNotesDaoImpl extends AbstractDaoImpl<PersonNote, Long>
        implements PersonNotesDao {

    /**
     * PersonNote DAO.
     */
    protected PersonNotesDaoImpl() {
        super(PersonNote.class);
    }

}
