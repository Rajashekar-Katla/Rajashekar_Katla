/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.model.SystemPersonType;

/**
 * Interface defining DAO operation for SystemPersonType objects.
 * @author ntones
 */
public interface SystemPersonTypeDao extends
        AbstractDao<SystemPersonType, Long> {

    /**
     * Method to retrieve SystemPersonType records for the named system.
     * @param system to lookup
     * @return systemPersonTypes for system
     */
    List<SystemPersonType> findBySystemName(String system);

}
