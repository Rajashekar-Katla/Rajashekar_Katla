/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.sirs.model.SirsUser;

/**
 * @author ibandi
 */
public interface SirsUserServiceDao extends AbstractDao<SirsUser, String> {

    SirsUser findByReferenceNumber(String referenceNumber);

    void deleteByUserName(String userRef);
}
