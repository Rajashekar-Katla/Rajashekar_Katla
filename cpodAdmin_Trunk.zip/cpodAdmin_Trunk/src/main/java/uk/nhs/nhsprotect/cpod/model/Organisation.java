package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringEscapeUtils;

/**
 * Class representing Organisation table (ORGANISATIONS_TBL).
 * 
 * @author awheatley
 */

@Entity
@Table(name = "ORGANISATIONS_TBL")
public class Organisation extends BaseEntity implements
        Comparable<Organisation>, Serializable {
    /**
     * Serial Version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key identifier.
     */
    @Id
    @Column(name = "org_id")
    private Long id;

    /**
     * OrgCode for organisation.
     */
    @Column(name = "org_code")
    private String orgCode;

    /**
     * Organisation Type. Linked to OrganisationType
     */
    @ManyToOne
    @JoinColumn(name = "org_type_id")
    private OrganisationType organisationType;

    /**
     * Organisation Name.
     */
    @Column(name = "org_name")
    private String orgName;

    /**
     * date organisation created.
     */
    @Column(name = "open_date")
    private Date openDate;

    /**
     * date organisation closed.
     */
    @Column(name = "close_date")
    private Date closeDate;

    /**
     * Status of Organisation O - open. C - closed.
     */
    @Column(name = "sub_type_code")
    private String subTypeCode;

    /**
     * number of medical staff at the organisation.
     */
    @Column(name = "medical_staff_qty")
    private Integer medicalStaffQty;

    /**
     * number of NON-medical staff at the organisation.
     */
    @Column(name = "non_medical_staff_qty")
    private Integer nonMedicalStaffQty;

    /**
     * Address. Linked to Address
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "address_id")
    private Address address;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "organisation")
    private Set<Responsibility> responsibilities = new HashSet<Responsibility>();

    // @OneToMany(mappedBy = "organisation")
    // private Set<AddressLink> addressLinks = new HashSet<AddressLink>();

    @OneToMany(mappedBy = "organisation")
    private Set<RegionLink> regionLinks = new HashSet<RegionLink>();

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the orgCode
     */
    public String getOrgCode() {
        return orgCode;
    }

    /**
     * @param orgCode
     *            the orgCode to set
     */
    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    /**
     * @return the organisationType
     */
    public OrganisationType getOrganisationType() {
        return organisationType;
    }

    /**
     * @param organisationType
     *            the organisationType to set
     */
    public void setOrganisationType(OrganisationType organisationType) {
        this.organisationType = organisationType;
    }

    /**
     * @return the orgName
     */
    public String getOrgName() {
        return orgName;
    }

    /**
     * @param orgName
     *            the orgName to set
     */
    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    /**
     * @return the openDate
     */
    public Date getOpenDate() {
        if (openDate == null) {
            return null;
        } else {
            return new Date(openDate.getTime());
        }
    }

    /**
     * @param openDate
     *            the openDate to set
     */
    public void setOpenDate(Date openDate) {
        if (openDate == null) {
            this.openDate = null;
        } else {
            this.openDate = new Date(openDate.getTime());
        }
    }

    /**
     * @return the closeDate
     */
    public Date getCloseDate() {
        if (closeDate == null) {
            return null;
        } else {
            return new Date(closeDate.getTime());
        }
    }

    /**
     * @param closeDate
     *            the closeDate to set
     */
    public void setCloseDate(Date closeDate) {
        if (closeDate == null) {
            this.closeDate = null;
        } else {
            this.closeDate = new Date(closeDate.getTime());
        }
    }

    /**
     * @return the subTypeCode
     */
    public String getSubTypeCode() {
        return subTypeCode;
    }

    /**
     * @param subTypeCode
     *            the subTypeCode to set
     */
    public void setSubTypeCode(String subTypeCode) {
        this.subTypeCode = subTypeCode;
    }

    /**
     * @return the medicalStaffQty
     */
    public Integer getMedicalStaffQty() {
        return medicalStaffQty;
    }

    /**
     * @param medicalStaffQty
     *            the medicalStaffQty to set
     */
    public void setMedicalStaffQty(Integer medicalStaffQty) {
        this.medicalStaffQty = medicalStaffQty;
    }

    /**
     * @return the nonMedicalStaffQty
     */
    public Integer getNonMedicalStaffQty() {
        return nonMedicalStaffQty;
    }

    /**
     * @param nonMedicalStaffQty
     *            the nonMedicalStaffQty to set
     */
    public void setNonMedicalStaffQty(Integer nonMedicalStaffQty) {
        this.nonMedicalStaffQty = nonMedicalStaffQty;
    }

    /**
     * @return the address
     */
    public Address getAddress() {
        return address;
    }

    /**
     * @param address
     *            the address to set
     */
    public void setAddress(Address address) {
        this.address = address;
    }

    /**
     * @return the responsibilities
     */
    public Set<Responsibility> getResponsibilities() {
        return responsibilities;
    }

    /**
     * @param responsibilities
     *            the responsibilities to set
     */
    public void setResponsibilities(Set<Responsibility> responsibilities) {
        this.responsibilities = responsibilities;
    }

    // /**
    // * @return the addressLinks
    // */
    // public Set<AddressLink> getAddressLinks() {
    // return addressLinks;
    // }
    //
    // /**
    // * @param addressLinks the addressLinks to set
    // */
    // public void setAddressLinks(Set<AddressLink> addressLinks) {
    // this.addressLinks = addressLinks;
    // }

    /**
     * @return the regionLinks
     */
    public Set<RegionLink> getRegionLinks() {
        return regionLinks;
    }

    /**
     * @param regionLinks
     *            the regionLinks to set
     */
    public void setRegionLinks(Set<RegionLink> regionLinks) {
        this.regionLinks = regionLinks;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((address == null) ? 0 : address.hashCode());
        result = prime * result
                + ((closeDate == null) ? 0 : closeDate.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result
                + ((medicalStaffQty == null) ? 0 : medicalStaffQty.hashCode());
        result = prime
                * result
                + ((nonMedicalStaffQty == null) ? 0 : nonMedicalStaffQty
                        .hashCode());
        result = prime * result
                + ((openDate == null) ? 0 : openDate.hashCode());
        result = prime * result + ((orgCode == null) ? 0 : orgCode.hashCode());
        result = prime * result + ((orgName == null) ? 0 : orgName.hashCode());
        result = prime
                * result
                + ((organisationType == null) ? 0 : organisationType.hashCode());

        result = prime * result
                + ((subTypeCode == null) ? 0 : subTypeCode.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Organisation)) {
            return false;
        }
        Organisation other = (Organisation) obj;
        if (address == null) {
            if (other.address != null) {
                return false;
            }
        } else if (!address.equals(other.address)) {
            return false;
        }
        if (closeDate == null) {
            if (other.closeDate != null) {
                return false;
            }
        } else if (!closeDate.equals(other.closeDate)) {
            return false;
        }
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (medicalStaffQty == null) {
            if (other.medicalStaffQty != null) {
                return false;
            }
        } else if (!medicalStaffQty.equals(other.medicalStaffQty)) {
            return false;
        }
        if (nonMedicalStaffQty == null) {
            if (other.nonMedicalStaffQty != null) {
                return false;
            }
        } else if (!nonMedicalStaffQty.equals(other.nonMedicalStaffQty)) {
            return false;
        }
        if (openDate == null) {
            if (other.openDate != null) {
                return false;
            }
        } else if (!openDate.equals(other.openDate)) {
            return false;
        }
        if (orgCode == null) {
            if (other.orgCode != null) {
                return false;
            }
        } else if (!orgCode.equals(other.orgCode)) {
            return false;
        }
        if (orgName == null) {
            if (other.orgName != null) {
                return false;
            }
        } else if (!orgName.equals(other.orgName)) {
            return false;
        }
        if (organisationType == null) {
            if (other.organisationType != null) {
                return false;
            }
        } else if (!organisationType.equals(other.organisationType)) {
            return false;
        }

        if (subTypeCode == null) {
            if (other.subTypeCode != null) {
                return false;
            }
        } else if (!subTypeCode.equals(other.subTypeCode)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Organisation [id=" + id + ", orgCode=" + orgCode
                + ", organisationType=" + organisationType + ", orgName="
                + orgName + ", openDate=" + openDate + ", closeDate="
                + closeDate + ", statusCode=" + subTypeCode
                + ", medicalStaffQty=" + medicalStaffQty
                + ", nonMedicalStaffQty=" + nonMedicalStaffQty;
    }

    @Override
    public int compareTo(Organisation other) {
        int result = 0;
        // order by orgName
        result = this.getOrgName().compareTo(other.getOrgName());

        return result;
    }

    @Transient
    public String getOrgNameStatus() {
        return getOrgName() + " - " + subTypeCode;
    }

    /**
     * Returns the orgName with suitable replacements to escape the values for
     * use in JavaScript calls. I.e. apostrophe ' becomes \'
     * 
     * @return String JavaScript safe orgName
     */
    @Transient
    public String getEscapedOrgName() {
        return StringEscapeUtils.escapeJavaScript(getOrgName());
    }

}
