package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import uk.nhs.nhsprotect.cpod.model.authentication.Authority;

/**
 * ORM class for SRT authority.
 * @author ntones
 */
/**
 * @author ntones
 */
@Entity
@Table(name = "Authorities_tbl")
public class SrtAuthority implements Serializable {

    /**
     * serial uid.
     */
    private static final long serialVersionUID = -3905892286456073002L;

    /**
     * The PK for the SRT Authority entity.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "authorityId")
    @GenericGenerator(strategy = "sequence", name = "authorityId", parameters = { @Parameter(name = "sequence", value = "AUTHORITY_ID_SEQNO") })
    @Column(name = "AUTHORITY_ID")
    private Long id;

    /**
     * The name of this authority.
     */
    @Column(name = "AUTHORITY_ROLE", nullable = false)
    private String authority;

    /**
     * The description of this authority.
     */
    @Column(name = "AUTHORITY_DESC", nullable = false)
    private String authorityDescription;

    /**
     * Default constructor.
     */
    public SrtAuthority() {// default
    }

    /**
     * @param id to set
     */
    public SrtAuthority(String id) {
        this.id = Long.valueOf(id);
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the authority
     */
    public String getAuthority() {
        return authority;
    }

    /**
     * @param authority the authority to set
     */
    public void setAuthority(String authority) {
        this.authority = authority;
    }

    /**
     * @return the authorityDescription
     */
    public String getAuthorityDescription() {
        return authorityDescription;
    }

    /**
     * @param authorityDescription the authorityDescription to set
     */
    public void setAuthorityDescription(String authorityDescription) {
        this.authorityDescription = authorityDescription;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Authority [id=" + id + ", authority=" + authority
                + ", authorityDescription=" + authorityDescription + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Authority)) {
            return false;
        }
        SrtAuthority other = (SrtAuthority) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

}
