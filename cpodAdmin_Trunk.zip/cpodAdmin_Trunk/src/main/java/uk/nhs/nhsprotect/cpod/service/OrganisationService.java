package uk.nhs.nhsprotect.cpod.service;

import java.util.List;

import uk.nhs.nhsprotect.cpod.controller.dto.OrganisationResult;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Organisation;

/**
 * @author awheatley
 */
public interface OrganisationService extends
        AbstractService<Organisation, Long> {

    /**
     * Find Organisation by its Org Code.
     * @param orgCode Organisation Code
     * @return Organisation type
     * @throws CpodException on error
     **/
    Organisation findOrgByOrgCode(String orgCode) throws CpodException;

    /**
     * Method used to generate a list of organisations matching the typed query.
     * @param query to search for
     * @param personId to search for
     * @return List<OrganisationResult> matching query
     */
    List<OrganisationResult> getOrganisationsForResponsibilities(String query,
            Long personId);
    
    List<OrganisationResult> getOrganisationsForPersons(String query);

}
