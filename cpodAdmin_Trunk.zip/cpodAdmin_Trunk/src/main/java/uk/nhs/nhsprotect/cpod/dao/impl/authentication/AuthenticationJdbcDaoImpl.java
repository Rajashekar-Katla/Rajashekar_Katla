/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl.authentication;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.model.authentication.CpodUser;
import uk.nhs.nhsprotect.cpod.model.authentication.User;
import uk.nhs.nhsprotect.cpod.model.authentication.UserAuthorities;

/**
 * Custom authentication implementation.
 * @author ntones
 */
@Repository("userDetailsService")
public class AuthenticationJdbcDaoImpl implements UserDetailsService {

    /**
     * Logger instance for AuthenticationJdbcDaoImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(AuthenticationJdbcDaoImpl.class);

    @Autowired
    private SessionFactory sessionFactory;

    /*
     * (non-Javadoc)
     * @see org.springframework.security.core.userdetails.UserDetailsService#
     * loadUserByUsername(java.lang.String)
     */
    @Override
    public UserDetails loadUserByUsername(String username) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("** loadUserByUsername=" + username.toString());
        }
        Session session = null;
        try {
            session = sessionFactory.openSession();
            StringBuffer sb = new StringBuffer("from User");
            sb.append(" where username = '").append(username).append("'");
            User user = (User) session.createQuery(sb.toString())
                    .uniqueResult();

            if (user != null) {
                if (LOG.isDebugEnabled()) {
                    LOG.debug("UserDetails =" + user.getUsername()
                            + " : Authorities=" + user.getUserAuthorities());
                }
                List<UserAuthorities> authorities = user.getUserAuthorities();
                List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
                for (int iCounter = 0; iCounter < authorities.size(); iCounter++) {
                    grantedAuthorities.add(authorities.get(iCounter)
                            .getAuthority());
                }
                return new CpodUser(user.getUsername(), user.getPassword(),
                        true, true, true, user.isEnabled(), grantedAuthorities,
                        user);
            } else {
                throw new UsernameNotFoundException("Username " + username
                        + "not found.");
            }
        } finally {
            if (session != null && session.isOpen()) {
                session.close();
            }
        }
    }

}
