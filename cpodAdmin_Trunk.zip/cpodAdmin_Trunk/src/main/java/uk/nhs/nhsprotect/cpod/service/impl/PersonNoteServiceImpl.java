package uk.nhs.nhsprotect.cpod.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.PersonNotesDao;
import uk.nhs.nhsprotect.cpod.model.PersonNote;
import uk.nhs.nhsprotect.cpod.service.PersonNoteService;

/**
 * @author AWheatley
 */
@Service("personNotesService")
@Transactional(readOnly = true)
public class PersonNoteServiceImpl extends AbstractServiceImpl<PersonNote, Long>
        implements PersonNoteService {
    /**
     * personNotesDao Represents the DAO for PersonNote.
     */
    @Autowired
    private PersonNotesDao personNotesDao;

    @Override
    public AbstractDao<PersonNote, Long> getDao() {
        return personNotesDao;
    }

 

}
