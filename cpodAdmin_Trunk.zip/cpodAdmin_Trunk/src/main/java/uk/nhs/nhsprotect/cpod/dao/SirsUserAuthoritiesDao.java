/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.sirs.model.SirsUserAuthorities;

/**
 * @author ntones
 */
public interface SirsUserAuthoritiesDao extends AbstractDao<SirsUserAuthorities, Long> {

    void deleteAuthoritiesForUser(String userRef);


}
