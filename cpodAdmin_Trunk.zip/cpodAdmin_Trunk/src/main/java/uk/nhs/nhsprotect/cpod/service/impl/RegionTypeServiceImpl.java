package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.RegionTypeDao;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.RegionType;
import uk.nhs.nhsprotect.cpod.service.RegionTypeService;


 
/**
 * @author awheatley
 */
@Service("regionTypeService")
@Transactional(readOnly = true)
public class RegionTypeServiceImpl extends
        AbstractServiceImpl<RegionType, Long> implements RegionTypeService {

    /**
     * Gives access to the RegionTypeDao.
     */
    @Autowired
    private RegionTypeDao regionTypeDao;

    @Override
    public AbstractDao<RegionType, Long> getDao() {
        return regionTypeDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.RegionTypeService#findRegionTypeByType
     * (java.lang.String)
     */
    public RegionType findRegionTypeByType(String type) throws CpodException {
        List<RegionType> found = regionTypeDao.findAdressTypeByType(type);

        if (found != null && !found.isEmpty()) {
            // multiple records found
            if (found.size() > 1) {
                throw new CpodNonUniqueException(
                        "More than one RegionType with regionType = [" + type
                                + "]");
            } else {
                // one record found
                return found.get(0);
            }
        } else {
            // No results found
            throw new CpodNoResultsReturnedException(
                    "No results returned for RegionType with regionType = ["
                            + type + "]");
        }
    }
}
