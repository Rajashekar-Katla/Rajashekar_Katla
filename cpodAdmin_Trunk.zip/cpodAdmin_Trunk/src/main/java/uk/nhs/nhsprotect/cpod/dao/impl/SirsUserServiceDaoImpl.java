/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.SirsUserServiceDao;
import uk.nhs.nhsprotect.sirs.model.SirsUser;

/**
 * @author ibandi
 */
@Repository("sirsUserServiceDao")
public class SirsUserServiceDaoImpl extends
        SirsAbstractDaoImpl<SirsUser, String> implements SirsUserServiceDao {

    /**
     * Logger instance for UserServiceDaoImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(SirsUserServiceDaoImpl.class);

    /**
     * User Dao Implementation.
     */
    protected SirsUserServiceDaoImpl() {
        super(SirsUser.class);

    }

    @Override
    public SirsUser findByReferenceNumber(String referenceNumber) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Searching for user with reference " + referenceNumber);
        }
        DetachedCriteria criteria = DetachedCriteria.forClass(
                getPersistentClass()).add(
                Restrictions.eq("username", referenceNumber));
        return (SirsUser) criteria.getExecutableCriteria(getCurrentSession())
                .uniqueResult();
    }

    @Override
    public void deleteByUserName(String userRef) {
        StringBuilder buffer = new StringBuilder();
        buffer.append("Delete from SirsUser sirsUser where  sirsUser.username = '");
        buffer.append(userRef);
        buffer.append("'");
        final String queryString = buffer.toString();
        int deletedRows = getCurrentSession().createQuery(queryString)
                .executeUpdate();
        if (LOG.isDebugEnabled()) {
            LOG.debug("Number of Rows deleted:" + deletedRows);
        }

    }

}
