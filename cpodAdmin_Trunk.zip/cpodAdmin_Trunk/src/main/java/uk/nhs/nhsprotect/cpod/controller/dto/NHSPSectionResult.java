/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

/**
 * Class used by ajax controller to present person results in a consumable form
 * for a typeahead text input field.
 * @author ntones
 */
@JsonPropertyOrder({ "nhspSectionName", "id" })
public class NHSPSectionResult implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String nhspSectionName;
    private Long id;

    /**
     * Default Constructor.
     */
    public NHSPSectionResult() {
        // default
    }

    /**
     * @param nhspSectionName
     * @param id
     */
    public NHSPSectionResult(String nhspSectionName, Long id) {
        this.nhspSectionName = nhspSectionName;
        this.id = id;
    }

    /**
     * @return the nhspSectionName
     */
    public String getNhspSectionName() {
        return nhspSectionName;
    }

    /**
     * @param nhspSectionName the nhspSectionName to set
     */
    public void setNhspSectionName(String nhspSectionName) {
        this.nhspSectionName = nhspSectionName;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "NHSPSectionResult [nhspSectionName=" + nhspSectionName
                + ", id=" + id + "]";
    }

}
