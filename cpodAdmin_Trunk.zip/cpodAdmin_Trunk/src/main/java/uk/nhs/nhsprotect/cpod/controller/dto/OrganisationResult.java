/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

/**
 * Class used by ajax controller to display organisations in a consumable form
 * for a typeahead text input box.
 * @author ntones
 */
@JsonPropertyOrder({ "orgCode", "orgName", "orgId", "addressLine1",
        "addressLine2", "addressLine3", "addressLine4", "addressLine5",
        "addressPostcode" })
public class OrganisationResult implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String orgName;
    private String orgCode;
    private Long orgId;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String address5;
    private String postcode;

    /**
     * Default Constructor.
     */
    public OrganisationResult() {
        // default
    }

    /**
     * @return the orgName
     */
    public String getOrgName() {
        return orgName;
    }

    /**
     * @param orgName the orgName to set
     */
    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    /**
     * @return the orgId
     */
    public Long getOrgId() {
        return orgId;
    }

    /**
     * @param orgId the orgId to set
     */
    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }

    /**
     * @return the orgCode
     */
    public String getOrgCode() {
        return orgCode;
    }

    /**
     * @param orgCode the orgCode to set
     */
    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    /**
     * @return the address1
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * @param address1 the address1 to set
     */
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    /**
     * @return the address2
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * @param address2 the address2 to set
     */
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    /**
     * @return the address3
     */
    public String getAddress3() {
        return address3;
    }

    /**
     * @param address3 the address3 to set
     */
    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    /**
     * @return the address4
     */
    public String getAddress4() {
        return address4;
    }

    /**
     * @param address4 the address4 to set
     */
    public void setAddress4(String address4) {
        this.address4 = address4;
    }

    /**
     * @return the address5
     */
    public String getAddress5() {
        return address5;
    }

    /**
     * @param address5 the address5 to set
     */
    public void setAddress5(String address5) {
        this.address5 = address5;
    }

    /**
     * @return the postcode
     */
    public String getPostcode() {
        return postcode;
    }

    /**
     * @param postcode the postcode to set
     */
    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "OrganisationResult [orgName=" + orgName + ", orgCode="
                + orgCode + ", orgId=" + orgId + ", address1=" + address1
                + ", address2=" + address2 + ", address3=" + address3
                + ", address4=" + address4 + ", address5=" + address5
                + ", postcode=" + postcode + "]";
    }

}
