package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.controller.dto.PersonResult;
import uk.nhs.nhsprotect.cpod.controller.dto.PersonSearch;
import uk.nhs.nhsprotect.cpod.dao.PersonDao;
import uk.nhs.nhsprotect.cpod.dao.exception.DaoNotImplementedException;
import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * @author awheatley
 */
@Repository("personDao")
public class PersonDaoImpl extends AbstractDaoImpl<Person, Long> implements
        PersonDao {

    /**
     * Log4J instance for PersonDaoImpl.class.
     **/
    @SuppressWarnings("unused")
    private static final Logger LOG = Logger.getLogger(PersonDaoImpl.class);

    /**
     * Person DAO Implementation Constructor.
     */
    protected PersonDaoImpl() {
        super(Person.class);
    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.dao.impl.AbstractDaoImpl#deleteAll()
     */
    @Override
    public int deleteAll() throws DaoNotImplementedException {
        throw new DaoNotImplementedException(
                "Not implemented for person object");
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.dao.PersonDao#getPersonsForResponsibilities(java
     * .lang.String, java.lang.Long)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<PersonResult> getPersonsForResponsibilities(String query,
            Long orgId) {
        Query hibQuery = null;

        String hql = "select personRole.id as personRoleId, personRole.personRef as personRef, personRole.personId as personId from PersonRole as personRole where personRole.personType.description in ('LSMS','LCFS','LMS','LSSP','SPEC','SMD') and personRole.person.status = 'Y' and lower(personRole.personRef) like ? and personRole not in (select resp.personRole from Responsibility as resp where resp.organisation.id = ?) order by personRole.personRef asc";
        hibQuery = getCurrentSession().createQuery(hql);
        hibQuery.setString(0, query.toLowerCase() + '%');
        hibQuery.setLong(1, orgId);
        return (List<PersonResult>) hibQuery.setResultTransformer(
                Transformers.aliasToBean(PersonResult.class)).list();
    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.dao.PersonDao#getNHSPStaff(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<PersonResult> getNHSPStaff(String query) {
        Query hibQuery = null;

        StringBuffer buffer = new StringBuffer();
        buffer.append(
                "select personRole.personRef as personRef, personRole.personId as personId, personRole.person.surName as surname, personRole.person.foreName as forename from PersonRole as personRole ")
                .append(" where personRole.personType.description in ('CU','COMP','OPS') and personRole.person.status = 'Y' and lower(personRole.person.foreName) like :query OR lower(personRole.person.surName) like :query")
                .append(" order by personRole.personRef, personRole.person.surName asc");

        hibQuery = getCurrentSession().createQuery(buffer.toString());
        hibQuery.setString("query", '%' + query.toLowerCase() + '%');
        return (List<PersonResult>) hibQuery.setResultTransformer(
                Transformers.aliasToBean(PersonResult.class)).list();

    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Person> findPersonsByCriteria(PersonSearch personSearch) {
        // check which criteria has been entered i.e. personType != ALL
        // (default) status != ALL (default) surname not empty forename not
        // empty and reference not empty

        Criteria crit = getCurrentSession().createCriteria(Person.class,
                "person");
        crit.createAlias("personRoles", "roles"); // Create alias for
                                                  // personRoles
        if (StringUtils.isNotEmpty(personSearch.getReference())) {
            crit.add(Restrictions.ilike("roles.personRef",
                    "%" + personSearch.getReference() + "%"));
        }
        if (StringUtils.isNotEmpty(personSearch.getForename())) {
            crit.add(Restrictions.ilike("foreName",
                    "%" + personSearch.getForename() + "%"));
        }
        if (StringUtils.isNotEmpty(personSearch.getSurname())) {
            crit.add(Restrictions.ilike("surName",
                    "%" + personSearch.getSurname() + "%"));
        }
        if (!StringUtils.equalsIgnoreCase(personSearch.getStatus(),
                CPODConstants.ALL_OPTION)) {
            crit.add(Restrictions.ilike("status",
                    "%" + personSearch.getStatus() + "%"));
        }
        if (!StringUtils.equalsIgnoreCase(personSearch.getPersonType(),
                CPODConstants.ALL_OPTION)) {
            crit.add(Restrictions.eq("roles.personType.id",
                    Long.valueOf(personSearch.getPersonType())));
        }
        // continue method

        // Build query based on selection - sort?
        crit.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
        return (List<Person>) crit.list();
    }
}
