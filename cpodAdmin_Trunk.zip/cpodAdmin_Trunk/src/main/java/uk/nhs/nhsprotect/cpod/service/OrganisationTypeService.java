package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.OrganisationType;

/**
 * @author AWheatley
 */
public interface OrganisationTypeService
    extends AbstractService<OrganisationType, Long> {

    /**
     * Find Organisation Type by Type.
     * @param type Organisation Type
     * @return Organisation type
     * @throws CpodException on error
     **/
    OrganisationType findOrganisationTypeByType(String type)
            throws CpodException;
}
