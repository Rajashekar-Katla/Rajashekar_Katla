/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.model.authentication.Authority;

/**
 * @author ntones
 */
public interface AuthorityService extends AbstractService<Authority, Long> {

}
