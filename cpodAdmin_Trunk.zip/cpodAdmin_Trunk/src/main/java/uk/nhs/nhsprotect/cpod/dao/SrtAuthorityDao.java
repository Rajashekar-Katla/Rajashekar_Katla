package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.srt.model.SrtAuthority;

/**
 * Interface declaring DAO methods for SrtAuthority objects.
 * @author ntones
 */
public interface SrtAuthorityDao extends AbstractDao<SrtAuthority, Long> {

}
