/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service;

import java.util.List;

import uk.nhs.nhsprotect.cpod.controller.dto.PersonResult;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;
import uk.nhs.nhsprotect.cpod.model.authentication.User;

/**
 * Methods for managing and maintaining CPOD user accounts.
 * @author ntones
 */
public interface UserService extends AbstractService<User, Long> {

    /**
     * Find User by reference number.
     * @param referenceNumber to search for
     * @return User matching user
     */
    User findByReferenceNumber(String referenceNumber);

    /**
     * Find all users matching criteria expressed by parameter.
     * @param user criteria to filter by
     * @return List of matching users
     */
    List<User> searchUsers(User user);

    /**
     * Method to delete a CPOD user account.
     * @param userId to be deleted
     * @throws CpodException on error
     */
    void delete(Long userId) throws CpodException;

    /**
     * Method to change a users password to the value specified or default if
     * none supplied.
     * @param userId user to update
     * @param password to use
     * @throws CpodException on error
     */
    void changePassword(Long userId, String password) throws CpodException;

    /**
     * Method to retrieve potential users for a given system.
     * @param query full or part username
     * @param systemPersonTypes the allowed 
     * @return
     */
    List<PersonResult> getNewUsers(String query,
            List<SystemPersonType> systemPersonTypes);

}
