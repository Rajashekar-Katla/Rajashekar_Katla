package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.controller.dto.SystemUserDTO;
import uk.nhs.nhsprotect.srt.model.SrtUserRO;

import com.github.dandelion.datatables.core.ajax.DataSet;
import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;

/**
 * @author ntones
 */
public interface SrtUserServiceRO extends AbstractService<SrtUserRO, Long> {

    /**
     * Method to return a list of SystemUserDTO object for the supplied
     * criteria.
     * @param criterias
     * @param forScreenDisplav indicates if the query is for an export or to be
     *            displayed on screen
     * @return {@link DataSet} matching records
     */
    DataSet<SystemUserDTO> findSrtUsersWithDatatablesCriterias(
            DatatablesCriterias criterias, boolean forScreenDisplay);

}
