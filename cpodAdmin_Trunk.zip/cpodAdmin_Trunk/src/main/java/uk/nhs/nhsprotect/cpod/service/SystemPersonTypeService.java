package uk.nhs.nhsprotect.cpod.service;

import java.util.List;

import uk.nhs.nhsprotect.cpod.model.SystemPersonType;

/**
 * Interface defining methods for SystemPersonType objects.
 * @author ntones
 */
public interface SystemPersonTypeService extends
        AbstractService<SystemPersonType, Long> {

    /**
     * Method to retrieve a systemPersonTypes by a system name.
     * @param system to find entries for
     * @return List<SystemPersonTypes> for system
     */
    List<SystemPersonType> findBySystemName(String system);

}
