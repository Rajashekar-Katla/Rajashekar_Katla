package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.AddressType;

/**
 * @author AWheatley
 */
public interface AddressTypeService extends AbstractService<AddressType, Long> {

    /**
     * Find Address Type by Type.
     * @param type Address Type
     * @return Address type
     * @throws CpodException on error
     **/
    AddressType findAddressTypeByType(String type) throws CpodException;
}
