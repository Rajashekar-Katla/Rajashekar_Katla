/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.model.NHSPSystem;

/**
 * Interface defining methods for NHSP System objects.
 * @author ntones
 */
public interface NHSPSystemService extends AbstractService<NHSPSystem, Long> {

}
