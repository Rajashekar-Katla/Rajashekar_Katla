package uk.nhs.nhsprotect.cpod.controller.export;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import uk.nhs.nhsprotect.cpod.controller.dto.SystemUserDTO;
import uk.nhs.nhsprotect.cpod.service.SirsUserServiceRO;
import uk.nhs.nhsprotect.cpod.service.SrtUserServiceRO;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;
import com.github.dandelion.datatables.core.exception.ExportException;
import com.github.dandelion.datatables.core.export.CsvExport;
import com.github.dandelion.datatables.core.export.ExportConf;
import com.github.dandelion.datatables.core.export.ExportType;
import com.github.dandelion.datatables.core.export.ExportUtils;
import com.github.dandelion.datatables.core.export.HtmlTableBuilder;
import com.github.dandelion.datatables.core.html.HtmlTable;
import com.github.dandelion.datatables.extras.export.itext.PdfExport;
import com.github.dandelion.datatables.extras.export.poi.XlsxExport;
import com.github.dandelion.datatables.extras.spring3.ajax.DatatablesParams;

/**
 * Controller class used to provide export functionality for the ajax generated
 * User list - SIRS and SRT currently.
 * @author NTones
 */
@Controller
public class UserExportController {

    @Autowired
    private SirsUserServiceRO sirsUserServiceRO;

    @Autowired
    private SrtUserServiceRO srtUserServiceRO;

    /**
     * Request Handler to generate CSV export of SIRS User list.
     * @param criterias current applied criteria
     * @param request current request
     * @param response current response
     * @throws ExportException on export error
     */
    @RequestMapping(value = "/export/csv/{systemName}", produces = "text/csv")
    public void csv(@DatatablesParams DatatablesCriterias criterias,
            HttpServletRequest request, HttpServletResponse response,
            @PathVariable String systemName) throws ExportException {

        ExportConf exportCsvConf = new ExportConf.Builder(ExportType.CSV)
                .header(true).exportClass(new CsvExport()).build();

        ExportUtils.renderExport(
                generateHtmlTableContent(exportCsvConf, request, criterias,
                        systemName), exportCsvConf, response);

    }

    /**
     * Request Handler to generate XLSX export of SIRS User list.
     * @param criterias current applied criteria
     * @param request current request
     * @param response current response
     * @throws ExportException on export error
     */
    @RequestMapping(value = "export/xlsx/{systemName}", produces = "application/vnd.ms-excel")
    public void xlsx(@DatatablesParams DatatablesCriterias criterias,
            HttpServletRequest request, HttpServletResponse response,
            @PathVariable String systemName) throws ExportException {

        ExportConf exportXlsxConf = new ExportConf.Builder(ExportType.XLSX)
                .header(true).exportClass(new XlsxExport()).build();

        ExportUtils.renderExport(
                generateHtmlTableContent(exportXlsxConf, request, criterias,
                        systemName), exportXlsxConf, response);

    }

    /**
     * Request Handler to generate PDF export of SIRS User list.
     * @param criterias current applied criteria
     * @param request current request
     * @param response current response
     * @throws ExportException on export error
     */
    @RequestMapping(value = "export/pdf/{systemName}", produces = "application/pdf")
    public void pdf(@DatatablesParams DatatablesCriterias criterias,
            HttpServletRequest request, HttpServletResponse response,
            @PathVariable String systemName) throws ExportException {

        ExportConf exportPdfConf = new ExportConf.Builder(ExportType.PDF)
                .header(true).exportClass(new PdfExport()).build();

        ExportUtils.renderExport(
                generateHtmlTableContent(exportPdfConf, request, criterias,
                        systemName), exportPdfConf, response);

    }

    /**
     * Builds the HtmlTable for export.
     * @param exportConf the current export type
     * @param request the current request
     * @param criterias used for search
     */
    private HtmlTable generateHtmlTableContent(ExportConf exportConf,
            HttpServletRequest request, DatatablesCriterias criterias,
            String systemName) {

        List<SystemUserDTO> list = null;

        if (systemName.equalsIgnoreCase(CPODConstants.SIRS_SYSTEM)) {

            // get the list to export
            list = sirsUserServiceRO.findSirsUsersWithDatatablesCriterias(
                    criterias, false).getRows();
        } else if (systemName.equalsIgnoreCase(CPODConstants.SRT_SYSTEM)) {
            list = srtUserServiceRO.findSrtUsersWithDatatablesCriterias(
                    criterias, false).getRows();
        }

        HtmlTable table = new HtmlTableBuilder<SystemUserDTO>()
                .newBuilder("tableId", list, request).column()
                .fillWithProperty("username").title("Reference").column()
                .fillWithProperty("fullname").title("Name").column()
                .fillWithProperty("status").title("Account Status").column()
                .fillWithProperty("email").title("Mail")
                .configureExport(exportConf).build();

        return table;
    }
}
