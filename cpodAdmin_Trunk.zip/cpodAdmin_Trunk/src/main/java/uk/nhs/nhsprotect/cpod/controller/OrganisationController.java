/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import uk.nhs.nhsprotect.cpod.controller.dto.OrganisationSearch;
import uk.nhs.nhsprotect.cpod.model.Organisation;
import uk.nhs.nhsprotect.cpod.service.OrganisationService;

/**
 * Spring controller class to provide links to organisation related pages.
 * @author ntones
 */
@Controller
public class OrganisationController extends CpodBaseController {

    /**
     * Logger instance for CommonPagesController.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(OrganisationController.class);

    /**
     * Organisation service reference.
     */
    @Autowired
    private OrganisationService organisationService;

    /**
     * Common pages controller reference.
     */
    @Autowired
    private CommonPagesController commonPagesController;

    /**
     * Handles the person search form submit.
     * @param modelMap the model map
     * @param personSearch the form backing object from the request
     * @return value of forward depending on query outcome
     * @throws Exception on error
     */
    @RequestMapping(value = { "/organisationSearch" }, method = RequestMethod.GET)
    public String organisationSearch(ModelMap modelMap,
            @ModelAttribute() OrganisationSearch organisationSearch)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("doPersonSearch for organisationSearch ["
                    + organisationSearch + "]");
        }

        // build criteria object
        Map<String, String> searchStrings = new HashMap<String, String>();
        searchStrings.put("orgName", organisationSearch.getOrgName());
        searchStrings.put("orgCode", organisationSearch.getOrgCode());

        List<Organisation> orgs = organisationService
                .findByAndCriterias(searchStrings);
        if (orgs.isEmpty()) {
            modelMap.addAttribute(
                    "warnMessage",
                    getMessageSource().getMessage("search.result.empty", null,
                            null));
            return commonPagesController.prepareSearch(modelMap);
        }
        modelMap.addAttribute("orgs", orgs);
        return "search-results";
    }

    /**
     * Handles requests to view an org.
     * @param modelMap the model map
     * @param id value from the request parameter
     * @return value of forward depending on query outcome
     * @throws Exception on error
     */
    @RequestMapping(value = { "/viewOrganisation" }, method = RequestMethod.GET)
    public String viewOrganisation(ModelMap modelMap,
            @RequestParam(value = "id") Long orgId) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("viewOrganisation for id [" + orgId);
        }

        Organisation organisation = null;
        if (orgId != null) {
            organisation = organisationService.findById(orgId);
        }

        modelMap.addAttribute("organisation", organisation);
        return "organisation-view";
    }
}
