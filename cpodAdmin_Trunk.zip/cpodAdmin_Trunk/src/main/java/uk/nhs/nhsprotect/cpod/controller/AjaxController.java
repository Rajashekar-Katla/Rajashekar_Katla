package uk.nhs.nhsprotect.cpod.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import uk.nhs.nhsprotect.cpod.controller.dto.NHSPSectionResult;
import uk.nhs.nhsprotect.cpod.controller.dto.OrganisationResult;
import uk.nhs.nhsprotect.cpod.controller.dto.PersonResult;
import uk.nhs.nhsprotect.cpod.controller.dto.SystemUserDTO;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.NHSPSection;
import uk.nhs.nhsprotect.cpod.service.NHSPSectionService;
import uk.nhs.nhsprotect.cpod.service.OrganisationService;
import uk.nhs.nhsprotect.cpod.service.PersonService;
import uk.nhs.nhsprotect.cpod.service.SirsUserServiceRO;
import uk.nhs.nhsprotect.cpod.service.SrtUserServiceRO;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

import com.github.dandelion.datatables.core.ajax.DataSet;
import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;
import com.github.dandelion.datatables.core.ajax.DatatablesResponse;
import com.github.dandelion.datatables.extras.spring3.ajax.DatatablesParams;

/**
 * handles all Ajax method calls. DOES NOT extend CpodBaseController as request
 * mappings cannot be inherited.
 * @author ntones
 */
@Controller
public class AjaxController {

    /**
     * Logger instance for AjaxController.class.
     **/
    private static final Logger LOG = Logger.getLogger(AjaxController.class);

    @Autowired
    private OrganisationService organisationService;

    @Autowired
    private PersonService personService;

    @Autowired
    private NHSPSectionService nhspSectionService;

    @Autowired
    private SirsUserServiceRO sirsUserServiceRO;

    @Autowired
    private SrtUserServiceRO srtUserServiceRO;

    /**
     * Ajax method to get the list of potential CPOD users.
     * @param query the string entered for typeahead
     * @return List of PersonResult matching query
     * @throws CpodException
     */
    @RequestMapping(value = "admin/getUsersAjax/{system}", method = RequestMethod.GET, headers = "Accept=application/json")
    public @ResponseBody List<PersonResult> getUsersAjax(
            @PathVariable String system,
            @RequestParam(value = "query", required = false) String query)
            throws CpodException {

        if (LOG.isDebugEnabled()) {
            LOG.debug("getUsersAjax query for System " + system
                    + ", query =  [" + query + "]");
        }

        List<PersonResult> result = personService.getNewUsers(query, system);

        return result;
    }

    /**
     * Ajax method to provide pagination of SystemUserDTO users results set
     * currently used by SIRS and SRT
     * @param criterias the criteria selected by the user (sort/filter etc.)
     * @param system the name of the system to look up users for
     * @return DatatablesResponse
     */
    @RequestMapping(value = "admin/listUsers/{system}")
    public @ResponseBody DatatablesResponse<SystemUserDTO> listUsers(
            @DatatablesParams DatatablesCriterias criterias,
            @PathVariable String system) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Calling listUsers ajaxwise for system [" + system
                    + "] with criterias [" + criterias + "]");
        }
        DataSet<SystemUserDTO> dataSet = null;

        if (system.equalsIgnoreCase(CPODConstants.SIRS_SYSTEM)) {
            dataSet = sirsUserServiceRO.findSirsUsersWithDatatablesCriterias(
                    criterias, true);
        } else if (system.equalsIgnoreCase(CPODConstants.SRT_SYSTEM)) {
            dataSet = srtUserServiceRO.findSrtUsersWithDatatablesCriterias(
                    criterias, true);
        }
        if (LOG.isDebugEnabled()) {
            LOG.debug("Returning DataSet for system: " + system);
        }
        return DatatablesResponse.build(dataSet, criterias);
    }

    /**
     * Ajax method to get the list of organisations for responsibilities.
     * @param query the string entered for typeahead
     * @return List of OrganisationResult matching query
     */
    @RequestMapping(value = "getOrganisationsForRespsAjax", method = RequestMethod.GET, headers = "Accept=application/json")
    public final @ResponseBody List<OrganisationResult> getOrganisationsForRespsAjax(
            @RequestParam(value = "query", required = false) String query,
            @RequestParam(value = "personId", required = false) Long personId) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("getOrganisationsForRespsAjax query [" + query
                    + "] personId [" + personId + "]");
        }
        List<OrganisationResult> result = organisationService
                .getOrganisationsForResponsibilities(query, personId);

        return result;
    }

    /**
     * Ajax method to get the list of organisations for persons.
     * @param query the string entered for typeahead
     * @return List of OrganisationResult matching query
     */
    @RequestMapping(value = "getOrganisationsForPersAjax", method = RequestMethod.GET, headers = "Accept=application/json")
    public final @ResponseBody List<OrganisationResult> getOrganisationsForPersAjax(
            @RequestParam(value = "query", required = false) String query) {

        if (LOG.isDebugEnabled()) {
            LOG.debug("getOrganisationsForPersAjax query [" + query + "] ");
        }
        List<OrganisationResult> result = organisationService
                .getOrganisationsForPersons(query);

        return result;
    }

    /**
     * Ajax method to get the list of persons available for responsibilities.
     * @param query the string entered for typeahead
     * @return List of PersonResult matching query
     */
    @RequestMapping(value = "getPersonsForRespsAjax", method = RequestMethod.GET, headers = "Accept=application/json")
    public final @ResponseBody List<PersonResult> getPersonsForRespsAjax(
            @RequestParam(value = "query", required = false) String query,
            @RequestParam(value = "orgId", required = false) Long orgId) {

        if (LOG.isDebugEnabled()) {
            LOG.debug("getPersonsForRespsAjax query [" + query + "] orgId ["
                    + orgId + "]");
        }
        List<PersonResult> result = personService
                .getPersonsForResponsibilities(query, orgId);

        return result;
    }

    /**
     * Ajax method to get the list of NHSP Sections.
     * @param query the string entered for typeahead
     * @return List of NHSPSectionResult matching query
     * @throws Exception on error
     */
    @RequestMapping(value = "getNHSPSectionsAjax", method = RequestMethod.GET, headers = "Accept=application/json")
    public final @ResponseBody List<NHSPSectionResult> getNHSPSectionsAjax(
            @RequestParam(value = "query", required = false) String query)
            throws Exception {

        if (LOG.isDebugEnabled()) {
            LOG.debug("getNHSPSectionsAjax query [" + query + "]");
        }
        List<NHSPSectionResult> result = new ArrayList<NHSPSectionResult>();

        List<NHSPSection> allList = nhspSectionService.findAll();
        for (NHSPSection section : allList) {
            if (StringUtils.containsIgnoreCase(section.getNhspSectionName(),
                    query)) {
                result.add(new NHSPSectionResult(section.getNhspSectionName(),
                        section.getId()));
            }
        }

        Collections.sort(result, new Comparator<NHSPSectionResult>() {

            @Override
            public int compare(NHSPSectionResult o1, NHSPSectionResult o2) {

                return o1.getNhspSectionName().compareTo(
                        o2.getNhspSectionName());
            }
        });
        return result;
    }

    /**
     * Ajax method to get the list of NHSP Staff.
     * @param query the string entered for typeahead
     * @return List of PersonResult matching query
     */
    @RequestMapping(value = "getNHSPStaffAjax", method = RequestMethod.GET, headers = "Accept=application/json")
    public final @ResponseBody List<PersonResult> getNHSPStaffAjax(
            @RequestParam(value = "query", required = false) String query) {

        if (LOG.isDebugEnabled()) {
            LOG.debug("getNHSPSectionsAjax query [" + query + "]");
        }
        List<PersonResult> result = personService.getNHSPStaff(query);
        return result;
    }
}
