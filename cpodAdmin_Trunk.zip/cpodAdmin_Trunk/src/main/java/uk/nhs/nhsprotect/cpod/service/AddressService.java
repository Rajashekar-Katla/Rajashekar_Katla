package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Address;

public interface AddressService extends AbstractService<Address, Long> {

    /**
     * Find database address matching passed in address
     * @author AWheatley
     */
    Address findAddressByCriteria(Address address) throws CpodException;
}
