/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.cpod.model.authentication.Authority;

/**
 * @author ntones
 */
public interface AuthorityDao extends AbstractDao<Authority, Long> {

}
