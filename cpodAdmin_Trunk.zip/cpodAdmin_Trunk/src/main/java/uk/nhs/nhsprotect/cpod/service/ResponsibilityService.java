package uk.nhs.nhsprotect.cpod.service;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Responsibility;

/**
 * @author AWheatley
 */
public interface ResponsibilityService extends
        AbstractService<Responsibility, Long> {

    /**
     * Find Responsibility by Person ID.
     * @param personId Person ID
     * @return Responsibility
     **/
    List<Responsibility> findResponsibilityByPersonRoleId(Long personRoleId);

    /**
     * Find Responsibility by Organisation ID.
     * @param orgId Organisation ID
     * @return Responsibility
     * @throws CpodException on error
     **/
    List<Responsibility> findResponsibilityByOrgId(Long orgId)
            throws CpodException;

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.AbstractService#saveOrUpdate(java.lang
     * .Object)
     */
    @Override
    void saveOrUpdate(Responsibility entity) throws CpodException;
}
