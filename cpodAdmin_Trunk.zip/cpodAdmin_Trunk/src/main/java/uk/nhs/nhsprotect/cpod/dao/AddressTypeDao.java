package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.AddressType;

/**
 * Defines methods to be implemented for AddressType DAO functions.
 * @author awheatley
 */
public interface AddressTypeDao extends AbstractDao<AddressType, Long> {

    /**
     * Find Address Type by requesting Type.
     * @param type - e.g. Home or Work
     * @return - List of AddressType
     * @throws CpodException for error
     */
    List<AddressType> findAdressTypeByType(String type) throws CpodException;
}
