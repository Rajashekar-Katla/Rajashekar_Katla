/** SIRS Model package.
 */
package uk.nhs.nhsprotect.sirs.model;

