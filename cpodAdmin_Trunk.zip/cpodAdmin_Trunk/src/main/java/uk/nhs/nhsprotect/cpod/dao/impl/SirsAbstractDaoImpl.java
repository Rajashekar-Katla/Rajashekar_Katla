package uk.nhs.nhsprotect.cpod.dao.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;

/**
 * @author ibandi
 * @param <T> Class
 * @param <ID> id
 */
public class SirsAbstractDaoImpl<T, ID extends Serializable> implements
        AbstractDao<T, ID> {

    /**
     * The type of class that requires DAO methods.
     */
    private Class<T> persistentClass;

    /**
     * Access to sessioinFactory.
     */
    @Autowired
    private SessionFactory sirsSessionFactory;

    /**
     * Creates the DAO implementation for the supplied class.
     * @param persistentClass - to persist
     */
    protected SirsAbstractDaoImpl(Class<T> persistentClass) {
        this.persistentClass = persistentClass;
    }

    /**
     * Returns the current hibernate session or creates a new one. managed by
     * Spring.
     * @return current session
     */
    @Override
    public Session getCurrentSession() {
        return sirsSessionFactory.getCurrentSession();
    }

    @Override
    public void delete(T entity) {
        this.getCurrentSession().delete(entity);
    }

    @SuppressWarnings("unchecked")
    @Override
    public T findById(ID id) {
        return (T) this.getCurrentSession().get(persistentClass, id);
    }

    @Override
    @SuppressWarnings("unchecked")
    public ID save(T entity) {
        return (ID) this.getCurrentSession().save(entity);
    }

    @Override
    public void saveOrUpdate(T entity) {

        this.getCurrentSession().saveOrUpdate(entity);

    }

    @Override
    public void update(T entity) {
        this.getCurrentSession().update(entity);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByCriteria(Criterion criterion) {
        Criteria criteria = getCurrentSession().createCriteria(persistentClass);
        criteria.add(criterion);
        return (List<T>) criteria.list();
    }

    @Override
    public int deleteAll() throws CpodException {

        String entityName = persistentClass.getName();

        // HQL query using entity type to delete all
        final String query = "Delete " + entityName;

        int rowsDeleted = getCurrentSession().createQuery(query)
                .executeUpdate();
        return rowsDeleted;

    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findAll() {
        String entityName = getPersistentClass().getName();
        final String query = "From " + entityName;
        Query exQuery = getCurrentSession().createQuery(query);

        return exQuery.list();

    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByAndCriterias(Map<String, String> searchCriteria) {
        Criteria criteria = getCurrentSession().createCriteria(persistentClass);

        for (Map.Entry<String, String> entry : searchCriteria.entrySet()) {

            String fieldValue = entry.getValue();
            String fieldName = entry.getKey();
            if (StringUtils.isNotEmpty(fieldValue)) {
                if (StringUtils.endsWith(fieldName.toLowerCase(), "id")) {
                    // this is an id field parse to a Long
                    Long idField = Long.parseLong(fieldValue);
                    criteria.add(Restrictions.and(Restrictions.eq(fieldName,
                            idField)));

                } else {
                    criteria.add(Restrictions.and(Restrictions.ilike(fieldName,
                            fieldValue, MatchMode.ANYWHERE)));
                }
            }

        }
        return (List<T>) criteria.list();
    }

    /**
     * @return the persistentClass
     */
    public Class<T> getPersistentClass() {
        return persistentClass;
    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.dao.AbstractDao#merge(java.lang.Object)
     */
    @SuppressWarnings("unchecked")
    @Override
    public T merge(T entity) {
        return entity = (T) getCurrentSession().merge(entity);

    }

    /*
     * (non-Javadoc)
     * 
     * @see uk.nhs.nhsprotect.cpod.dao.AbstractDao#getTotalCount()
     */
    @Override
    public Long getTotalCount() {

        return (Long) getCurrentSession().createCriteria(getPersistentClass())
                .setProjection(Projections.rowCount()).uniqueResult();
    }
}
