package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Address;

/**
 * DAO for Address Class.
 * @author awheatley
 */

public interface AddressDao extends AbstractDao<Address, Long> {
    /**
     * Find all addresses by multiple 'AND' criteria.
     * @param address the address for basis of comparison
     * @return - List of Addresses matching comparison criteria.
     * @throws CpodException for error
     */
    List<Address> findAddressByAndCriterias(Address address)
            throws CpodException;

}
