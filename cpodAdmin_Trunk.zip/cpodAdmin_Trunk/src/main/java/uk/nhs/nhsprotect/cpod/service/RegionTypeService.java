package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.RegionType;

/**
 * @author AWheatley
 */
public interface RegionTypeService extends AbstractService<RegionType, Long> {

    /**
     * Find Address Type by Type.
     * @param type Address Type
     * @return Address type
     * @throws CpodException on error
     **/
    RegionType findRegionTypeByType(String type) throws CpodException;
}
