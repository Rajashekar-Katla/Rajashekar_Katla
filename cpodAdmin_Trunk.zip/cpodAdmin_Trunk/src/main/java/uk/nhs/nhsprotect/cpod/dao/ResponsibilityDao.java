package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Responsibility;

/**
 * DAO access to responsibilities table
 * @author awheatley
 */
public interface ResponsibilityDao extends AbstractDao<Responsibility, Long> {

    /**
     * Find Responsibility by Organisation ID.
     * @param orgId Organisation ID
     * @return List of Responsibilities
     * @throws CpodException for error
     */
    List<Responsibility> findResponsibilityByOrgId(Long orgId)
            throws CpodException;

    /**
     * Find Responsibility by Person ID.
     * @param personId Person ID
     * @return List of Responsibilities
     */
    List<Responsibility> findResponsibilityByPersonRoleId(Long personId);
    
    
}
