/**
 * 
 */
package uk.nhs.nhsprotect.cpod.util;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.model.Responsibility;

/**
 * @author ntones
 */
public final class CpodUtils {

    private CpodUtils() {
        // private constructor static only methods.
    }

    /**
     * Method to determine if the current logged in user is able to edit the
     * pesron record requested.
     * 
     * @param request
     *            current running request
     * @param person
     *            to be viewed
     * @return boolean true if user has rights to edit person record
     */
    public static boolean isUserAbleToEditPerson(HttpServletRequest request,
            Person person) {
        boolean result = false;
        if (request.isUserInRole(CPODConstants.ADMIN_ROLE)) {
            // ISD admin can edit any record
            result = true;
        } else if (request.isUserInRole(CPODConstants.SIRS_ADMIN_ROLE)) {
            // check if the person is of a type that SIRS admin account can edit
            // LMS, LSSP, SPEC, SMD
            for (PersonRole role : person.getPersonRoles()) {

                if (CPODConstants.SIRS_ADMIN_PERSON_TYPES_EDITABLE_MAP
                        .containsKey(role.getPersonType().getId())) {
                    result = true;
                    break;
                }
            }

        } else if (request.isUserInRole(CPODConstants.LSDS_ADMIN_ROLE)) {
            // check if the person is of a type that LSDS admin account can edit
            // LSMS/LCFS
            for (PersonRole role : person.getPersonRoles()) {

                if (CPODConstants.LSDS_ADMIN_PERSON_TYPES_EDITABLE_MAP
                        .containsKey(role.getPersonType().getId())) {
                    result = true;
                    break;
                }
            }

        }

        else if (request.isUserInRole(CPODConstants.TRAINING_ADMIN_ROLE)
                && person.getPersonRoles().size() == 1) {
            // check if the person only has the person type that training admin
            // account can edit
            // i.e EXT only

            for (PersonRole role : person.getPersonRoles()) {

                if (CPODConstants.TRAINING_ADMIN_PERSON_TYPES_EDITABLE_MAP
                        .containsKey(role.getPersonType().getId())) {
                    result = true;
                    break;
                }
            }

        }
        return result;
    }

    /**
     * Method to determine if the current logged in user is able to edit the
     * responsibilities requested.
     * 
     * @param request
     *            current running request
     * @param responsibilities
     *            to be viewed
     * @return boolean true if user has rights to edit person record
     */
    public static boolean isUserAbleToEditResponsibility(
            HttpServletRequest request, List<Responsibility> responsibilities) {
        boolean result = false;
        if (request.isUserInRole("ROLE_ADMIN")) {
            // ISD admin can edit any record
            result = true;
        } else if (request.isUserInRole("ROLE_SIRS_ADMIN")) {
            // check if the person is of a type that SIRS admin account can edit
            // LMS, LSSP, SPEC, SMD

            for (Responsibility responsibility : responsibilities) {

                if (CPODConstants.SIRS_ADMIN_RESPONSIBILITIES_TYPES_EDITABLE_MAP
                        .containsKey(responsibility.getPersonRole()
                                .getPersonType().getId())) {
                    result = true;
                    break;
                }
            }

        } else if (request.isUserInRole("ROLE_LSDS_ADMIN")) {
            // check if the person is of a type that LSDS admin account can edit
            // LSMS/LCFS
            for (Responsibility responsibility : responsibilities) {

                if (CPODConstants.LSDS_ADMIN_PERSON_TYPES_EDITABLE_MAP
                        .containsKey(responsibility.getPersonRole()
                                .getPersonType().getId())) {
                    result = true;
                    break;
                }
            }

        }
        return result;
    }

    /**
     * Method to return the description of a person type.
     * 
     * @param personTypeId
     *            to lookup description
     * @return String description
     * @throws CpodException
     *             if personTypeId cannot be resolved
     */
    public static String getPersonTypeDescription(Long personTypeId)
            throws CpodException {
        String description = null;
        switch (personTypeId.intValue()) {
        case CPODConstants.PERSON_TYPE_COMP_ID:
            description = CPODConstants.PERSON_TYPE_COMP_DESC;
            break;
        case CPODConstants.PERSON_TYPE_CU_ID:
            description = CPODConstants.PERSON_TYPE_CU_DESC;
            break;
        case CPODConstants.PERSON_TYPE_OPS_ID:
            description = CPODConstants.PERSON_TYPE_OPS_DESC;
            break;
        case CPODConstants.PERSON_TYPE_LCFS_ID:
            description = CPODConstants.PERSON_TYPE_LCFS_DESC;
            break;
        case CPODConstants.PERSON_TYPE_LSMS_ID:
            description = CPODConstants.PERSON_TYPE_LSMS_DESC;
            break;
        case CPODConstants.PERSON_TYPE_TEMP_ID:
            description = CPODConstants.PERSON_TYPE_TEMP_DESC;
            break;
        case CPODConstants.PERSON_TYPE_EXTERNAL_ID:
            description = CPODConstants.PERSON_TYPE_EXTERNAL_DESC;
            break;
        case CPODConstants.PERSON_TYPE_LMS_ID:
            description = CPODConstants.PERSON_TYPE_LMS_DESC;
            break;
        case CPODConstants.PERSON_TYPE_LSSP_ID:
            description = CPODConstants.PERSON_TYPE_LSSP_DESC;
            break;
        case CPODConstants.PERSON_TYPE_SMD_ID:
            description = CPODConstants.PERSON_TYPE_SMD_DESC;
            break;
        case CPODConstants.PERSON_TYPE_SPEC_ID:
            description = CPODConstants.PERSON_TYPE_SPEC_DESC;
            break;
        default:
            throw new CpodException("Unexpected person type encountered = ["
                    + personTypeId + "]");

        }
        return description;
    }

    /**
     * Method to generate a new Person object with default status for given
     * person type.
     * 
     * @param personTypeId
     *            the person type id to generate new instance for
     * @return Person new person
     * @throws CpodException
     *             if unexpected person type encountered
     */
    public static Person prepareNewPerson(Long personTypeId)
            throws CpodException {
        Person newPerson = new Person();

        switch (personTypeId.intValue()) {
        case CPODConstants.PERSON_TYPE_COMP_ID:
            // fall through
        case CPODConstants.PERSON_TYPE_CU_ID:
            // fall through
        case CPODConstants.PERSON_TYPE_OPS_ID:
            // fall through
        case CPODConstants.PERSON_TYPE_LCFS_ID:
            // fall through
        case CPODConstants.PERSON_TYPE_LSMS_ID:
            // status = pending
            newPerson.setStatus(CPODConstants.PERSON_STATUS_PENDING);
            break;
        case CPODConstants.PERSON_TYPE_TEMP_ID:
            // fall through
        case CPODConstants.PERSON_TYPE_LMS_ID:
            // fall through
        case CPODConstants.PERSON_TYPE_LSSP_ID:
            // fall through
        case CPODConstants.PERSON_TYPE_SMD_ID:
            // fall through
        case CPODConstants.PERSON_TYPE_SPEC_ID:
            // fall through
        case CPODConstants.PERSON_TYPE_EXTERNAL_ID:
            // status = active
            newPerson.setStatus(CPODConstants.PERSON_STATUS_ACTIVE);
            break;

        default:
            throw new CpodException("Unexpected person type encountered = ["
                    + personTypeId + "]");

        }

        // newPerson.setPersonRef(CpodUtils.getPersonTypeDescription(personTypeId)
        // .toLowerCase());
        // TODO need to create a new personRole based on the the personType
        return newPerson;

    }

    public static PersonRole prepareNewPersonRole(Long personTypeId)
            throws CpodException {
        PersonType personType = new PersonType();
        personType.setId(personTypeId);
        personType.setDescription(getPersonTypeDescription(personTypeId));

        PersonRole personRole = new PersonRole();
        personRole.setPersonType(personType);
        return personRole;
    }

    public enum PersonStatus {
        PENDING("P"), ACTIVE("Y"), INACTIVE("N");

        private String statusCode;

        private PersonStatus(String s) {
            statusCode = s;
        }

        public String getStatusCode() {
            return statusCode;
        }
    }

}
