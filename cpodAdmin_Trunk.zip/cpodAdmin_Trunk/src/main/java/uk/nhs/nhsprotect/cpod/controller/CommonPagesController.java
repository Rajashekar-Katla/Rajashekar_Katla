/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import uk.nhs.nhsprotect.cpod.controller.dto.OrganisationSearch;
import uk.nhs.nhsprotect.cpod.controller.dto.PersonSearch;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.model.authentication.User;
import uk.nhs.nhsprotect.cpod.service.PersonTypeService;
import uk.nhs.nhsprotect.cpod.service.UserService;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * Spring controller class to provide links to common pages.
 * 
 * @author ntones
 */
@Controller
public class CommonPagesController extends CpodBaseController {

    /**
     * Logger instance for CommonPagesController.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(CommonPagesController.class);

    /**
     * UserService reference.
     */
    @Autowired
    private UserService userService;

    @Autowired
    private PersonTypeService personTypeService;

    /**
     * CpodUserAdminController reference.
     */
    @Autowired
    private CpodUserAdminController cpodUserAdminController;

    /**
     * Handles requests to /login.
     * 
     * @return String login page ref.
     */
    @RequestMapping(value = { "/login" })
    public String getLoginPage() {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Calling Login page");
        }
        return "login";
    }

    /**
     * Prepares request items for search page.
     * 
     * @param modelMap
     *            the model map
     * @return value of forward depending on query outcome
     * @throws Exception
     *             on error
     */
    @RequestMapping(value = { "/prepareSearch" }, method = RequestMethod.GET)
    public String prepareSearch(ModelMap modelMap) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("prepareSearch starts ");
        }

        // build option lists
        List<PersonType> personTypes = personTypeService.findAll();
        List<PersonType> personTypesToCreate = personTypeService
                .getPersonTypesForUser();

        modelMap.put("personTypes", personTypes);
        modelMap.put("personTypesToCreate", personTypesToCreate);
        modelMap.put("statuses", CPODConstants.PERSON_STATUSES);
        // form backing object for person search
        PersonSearch personSearch = new PersonSearch();
        modelMap.put("personSearch", personSearch);
        // form backing object for org search
        OrganisationSearch organisationSearch = new OrganisationSearch();
        modelMap.put("organisationSearch", organisationSearch);
        return "search-view";
    }

    /**
     * Handles requests to /index or / to redirect to homepage.
     * 
     * @return String home page ref or password change page if required
     * @param modelMap
     *            the current modelMapt
     * @throws Exception
     */
    @RequestMapping(value = { "/index", "/" }, method = RequestMethod.GET)
    public String getHomePage(ModelMap modelMap) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Calling home page");
        }
        User user = userService.findById(getUserConextUtil().getUserId());
        if (user.isDefaultPasswordChanged()) {
            return prepareSearch(modelMap);
        } else {
            return cpodUserAdminController.prepareChangePassword(modelMap);
        }

    }

}
