/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.cpod.model.SecurityQuestion;

/**
 * DAO interface for SecurityQuestion entity methods.
 * 
 * @author ntones
 * 
 */
public interface SecurityQuestionDao extends
        AbstractDao<SecurityQuestion, Long> {

}
