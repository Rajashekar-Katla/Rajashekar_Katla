package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.srt.model.SrtUser;
import uk.nhs.nhsprotect.srt.model.SrtUserAuthorities;

/**
 * Interface declaring methods to manage SrtUserAuthorities objects.
 * @author ntones
 */
public interface SrtUserAuthoritiesDao extends
        AbstractDao<SrtUserAuthorities, Long> {

    /**
     * Method to delete all the granted SRT User Authorities for the supplied
     * user.
     * @param entity to remove authorities of
     */
    void deleteBySrtUser(SrtUser entity);

}
