/**
 * 
 */
package uk.nhs.nhsprotect.cpod.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import uk.nhs.nhsprotect.cpod.controller.dto.PersonSearch;
import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.PersonNote;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.model.SecurityQuestion;
import uk.nhs.nhsprotect.cpod.service.PersonNoteService;
import uk.nhs.nhsprotect.cpod.service.PersonService;
import uk.nhs.nhsprotect.cpod.service.PersonTypeService;
import uk.nhs.nhsprotect.cpod.service.SecurityQuestionService;
import uk.nhs.nhsprotect.cpod.service.SirsAuthorityService;
import uk.nhs.nhsprotect.cpod.service.SirsUserService;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;
import uk.nhs.nhsprotect.cpod.util.CpodUtils;
import uk.nhs.nhsprotect.sirs.model.SirsAuthority;
import uk.nhs.nhsprotect.sirs.model.SirsUser;
import uk.nhs.nhsprotect.sirs.model.SirsUserAuthorities;

/**
 * Spring controller class to provide links to person related pages.
 * 
 * @author ntones
 */
@Controller
public class PersonController extends CpodBaseController {

    /**
     * Logger instance for CommonPagesController.class.
     **/
    private static final Logger LOG = Logger.getLogger(PersonController.class);

    /**
     * PersonService reference.
     */
    @Autowired
    private PersonService personService;

    /**
     * PersonTypeService reference.
     */
    @Autowired
    private PersonTypeService personTypeService;

    @Autowired
    private CommonPagesController commonPagesController;

    @Autowired
    private SirsAuthorityService sirsAuthorityService;

    @Autowired
    private PersonNoteService personNoteService;
    /**
     * References the sirs user service.
     */
    @Autowired
    private SirsUserService sirsUserService;

    @Autowired 
    private SecurityQuestionService securityQuestionService;

    /**
     * Handles the person search form submit.
     * 
     * @param modelMap
     *            the model map
     * @param personSearch
     *            the form backing object from the request
     * @return value of forward depending on query outcome
     * @throws Exception
     *             on error
     */
    @RequestMapping(value = { "/personSearch" }, method = RequestMethod.GET)
    public String personSearch(ModelMap modelMap,
            @ModelAttribute() PersonSearch personSearch,
            HttpServletRequest request) throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("doPersonSearch for personSearch [" + personSearch + "]");
        }

        List<Person> persons = personService
                .findPersonsByCriteria(personSearch);
        if (persons.isEmpty()) {
            modelMap.addAttribute(
                    "warnMessage",
                    getMessageSource().getMessage("search.result.empty", null,
                            null));
            return commonPagesController.prepareSearch(modelMap);
        } else if (persons.size() == 1) {

            // go to the individual page
            return viewPerson(modelMap, persons.get(0).getId(), null, false,
                    null, null, null, null, request);

        }
        modelMap.addAttribute("persons", persons);
        return "search-results";
    }

    /**
     * Handles requests to view a person.
     * 
     * @param modelMap
     *            the model map
     * @param id
     *            value from the request parameter
     * @return value of forward depending on query outcome
     * @throws Exception
     *             on error
     */

    @RequestMapping(value = { "/viewPerson" }, method = RequestMethod.GET)
    public String viewPerson(
            ModelMap modelMap,
            @RequestParam(value = "id", required = false) Long personId,
            @RequestParam(value = "personTypeId", required = false) Long personTypeId,
            @RequestParam(value = "createSirs", required = false) boolean createSirs,
            @RequestParam(value = "successMessage", required = false) String successMessage,
            @RequestParam(value = "infoMessage", required = false) String infoMessage,
            @RequestParam(value = "errorMessage", required = false) String errorMessage,
            @RequestParam(value = "warnMessage", required = false) String warnMessage,
            HttpServletRequest request)

    throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("viewPerson for id [" + personId + "] and personTypeId ["
                    + personTypeId + "]");
        }

        // get the security questions
        List<SecurityQuestion> securityQuestions = securityQuestionService
                .findAll();
        // set the security questions in the request for access on screen.
        modelMap.addAttribute("securityQuestions", securityQuestions);

        // filter the person types depending on the current user type
        List<PersonType> personTypes = personTypeService
                .getPersonTypesForUser();

        Person person = null;
        PersonRole personRole = null;
        if (personId != null) {
            person = personService.findById(personId);
        } else {
            // use utility method to prepare new instance
            person = CpodUtils.prepareNewPerson(personTypeId);
            personRole = CpodUtils.prepareNewPersonRole(personTypeId);

            // add selected role to person
            person.getPersonRoles().add(personRole);

        }

        // determine what roles a person already has
        List<PersonRole> personRoles = person.getPersonRoles();
        List<PersonType> currentTypes = new ArrayList<PersonType>();

        for (PersonRole role : personRoles) {
            currentTypes.add(role.getPersonType());
        }

        // remove the current types from all
        personTypes.removeAll(currentTypes);

        // set the available types in the model for selection on screen.
        modelMap.addAttribute("personTypes", personTypes);

        modelMap.put("statuses", CPODConstants.PERSON_STATUSES);

        modelMap.addAttribute("person", person);
        if (StringUtils.isNotEmpty(successMessage)) {
            modelMap.addAttribute("successMessage", successMessage);
        }
        if (StringUtils.isNotEmpty(warnMessage)) {
            modelMap.addAttribute("warnMessage", warnMessage);
        }

        if (StringUtils.isNotEmpty(infoMessage)) {
            modelMap.addAttribute("infoMessage", infoMessage);
        }
        if (StringUtils.isNotEmpty(errorMessage)) {
            modelMap.addAttribute("errorMessage", errorMessage);
        }

        if (CpodUtils.isUserAbleToEditPerson(request, person)) {
            return "person-view";
        } else {
            return "person-viewRO";
        }
    }

    /**
     * Method to handle requests to save or update a user object.
     * 
     * @param user
     *            the person object to save
     * @param modelMap
     *            the current model
     * @return String tiles view definition
     * @throws Exception
     *             on error
     */
    @RequestMapping(value = { "/savePerson" }, method = RequestMethod.POST)
    public String saveOrUpdatePerson(
            @RequestParam(value = "createSirs", required = false, defaultValue = "false") boolean createSirs,
            @RequestParam(value = "external", required = false, defaultValue = "false") boolean external,
            @ModelAttribute Person person, ModelMap modelMap,
            RedirectAttributes redirectAttrs, HttpServletRequest request)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("saveOrUpdatePerson person [" + person + "]");
        }

        personService.saveOrUpdate(person);

        if (createSirs) {
            // SIRS User records save it to SIRS DB
            // Create new User in SIRS Database
            String sirsUserName = CPODConstants.BLANK_STR;
            List<PersonRole> personRoles = person.getPersonRoles();
            List<SirsAuthority> sirsAssignedAuthorities = new ArrayList<SirsAuthority>(
                    1);
            for (PersonRole personRole : personRoles) {
                sirsUserName = personRole.getPersonRef();
                PersonType personType = personRole.getPersonType();
                PersonType personTypeHibernate = personTypeService
                        .findById(personType.getId());
                Long sirsAuthorityId = CPODConstants.CPOD_PERSONTYPE_SIRS_USER_AUTHORITY_MAP
                        .get(personTypeHibernate.getDescription());
                SirsAuthority sirsAuthority = sirsAuthorityService
                        .findById(sirsAuthorityId);
                sirsAssignedAuthorities.add(sirsAuthority);
            }

            String password = getPasswordEncoder().encode(
                    CPODConstants.DEFAULT_PASSWORD);
            if (external) {
                // we are creating an external person
                password = CPODConstants.SIRS_EXTERNAL_DEFAULT_PASSWORD;
            }
            SirsUser sirsUserEntity = new SirsUser(sirsUserName, password, 1,
                    person.getId());
            List<SirsUserAuthorities> sirsAssignedUserAuthorities = new ArrayList<SirsUserAuthorities>(
                    sirsAssignedAuthorities.size());
            for (SirsAuthority sirsAssignedUserAuthority : sirsAssignedAuthorities) {
                sirsAssignedUserAuthorities.add(new SirsUserAuthorities(
                        sirsUserEntity, sirsAssignedUserAuthority));
            }

            sirsUserEntity.setAuthorities(sirsAssignedUserAuthorities);

            sirsUserService.saveOrUpdate(sirsUserEntity);
            redirectAttrs
                    .addAttribute("infoMessage",
                            "Please ensure that responsibilities are created for this user.");
        }
        redirectAttrs.addAttribute("id", person.getId());
        redirectAttrs.addAttribute("roles", person.getCsvPersonRef());
        // provide feedback of success
        String[] params = { person.getCsvPersonRef() };
        redirectAttrs.addAttribute("successMessage", getMessageSource()
                .getMessage("person.edit.success", params, null));
        return "redirect:/viewPerson";
    }

    @RequestMapping(value = { "/savePersonNote" }, method = RequestMethod.POST)
    public String saveOrUpdatePersonNote(@ModelAttribute PersonNote personNote,
            ModelMap modelMap, RedirectAttributes redirectAttrs)
            throws Exception {
        if (LOG.isDebugEnabled()) {
            LOG.debug("saveOrUpdatePerson person [" + personNote + "]");
        }
        personNote.setNoteDate(new Date());
        personNoteService.saveOrUpdate(personNote);
        redirectAttrs.addAttribute("id", personNote.getPersonId().toString());
        redirectAttrs.addAttribute("successMessage", "Person Note Created");

        return "redirect:/viewPerson";
    }
}
