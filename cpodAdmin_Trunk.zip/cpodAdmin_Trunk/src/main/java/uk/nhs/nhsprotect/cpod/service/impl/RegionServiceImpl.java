package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.RegionDao;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Region;
import uk.nhs.nhsprotect.cpod.service.RegionService;

/**
 * @author AWheatley
 */

@Service("regionService")
@Transactional(readOnly = true)
public class RegionServiceImpl extends AbstractServiceImpl<Region, Long>
        implements RegionService {

    
    /**
     * Gives access to the RegionDao.
     */
    @Autowired
    private RegionDao regionDao;
    
    
    @Override
    public AbstractDao<Region, Long> getDao() {
        return regionDao;
    }
    
    

    @Override
    public Region findRegionByRegionCode(String region) throws CpodException {
        List<Region> found = regionDao.findRegionByRegionCode(region);

        if (found != null && !found.isEmpty()) {
            // multiple records found
            if (found.size() > 1) {
                throw new CpodNonUniqueException(
                        "More than one AddressType with addressType = [" + region
                                + "]");
            } else {
                // one record found
                return found.get(0);
            }
        } else {
            // No results found
            throw new CpodNoResultsReturnedException(
                    "No results returned for AddressType with addressType = ["
                            + region+ "]");
        }
    }

}
