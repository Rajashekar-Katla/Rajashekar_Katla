package uk.nhs.nhsprotect.cpod.dao.impl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import javax.sql.DataSource;

import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.SrtUserServiceDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.srt.model.SrtUser;

/**
 * Implementation of SrtUserServiceDao offering abstract implementation and any
 * custom methods for entity.
 * @author ntones
 */
@Repository("srtUserServiceDao")
public class SrtUserServiceDaoImpl extends SrtAbstractDaoImpl<SrtUser, Long>
        implements SrtUserServiceDao {

    /**
     * Instantiates the implementation for SrtUser classes.
     */
    protected SrtUserServiceDaoImpl() {
        super(SrtUser.class);
    }

    @Override
    public String getPassword() throws CpodException {

        DataSource dataSource = SessionFactoryUtils
                .getDataSource(getCurrentSession().getSessionFactory());

        CallableStatement stmt = null;
        String result = null;
        try {
            stmt = dataSource.getConnection().prepareCall(
                    "{ ? = call generate_password() }");
            stmt.registerOutParameter(1, Types.CHAR);
            stmt.executeUpdate();
            result = stmt.getString(1);
        } catch (SQLException e) {
            throw new CpodException(e);
        } finally {
            try {
                dataSource.getConnection().close();
            } catch (SQLException e) {
                throw new CpodException(e);
            }
        }

        return result;
    }
}
