/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.RegionLinkDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.RegionLink;
import uk.nhs.nhsprotect.cpod.service.RegionLinkService;

/**
 * Implementation of RegionLinkService.
 * @author awheatley
 */
@Service("regionLinkService")
@Transactional(readOnly = true)
public class RegionLinkServiceImpl extends
        AbstractServiceImpl<RegionLink, Long> implements RegionLinkService {

    /**
     * regionLinkDao Represents the DAO for RegionLink.
     */
    @Autowired
    private RegionLinkDao regionLinkDao;

    @Override
    public AbstractDao<RegionLink, Long> getDao() {
        return regionLinkDao;
    }

    @Override
    @Transactional(readOnly = false)
    public void delete(RegionLink entity) throws CpodException {
        entity.removeRegion();
        super.delete(entity);
    }

}
