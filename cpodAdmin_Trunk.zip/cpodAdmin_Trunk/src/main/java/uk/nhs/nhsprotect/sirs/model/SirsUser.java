package uk.nhs.nhsprotect.sirs.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;

@Entity
@Table(name = "USERS")
public class SirsUser implements Serializable {

    private static final long serialVersionUID = 100005599L;

    @Id
    private String username;

    private String password;

    private int enabled;

    @Column(name = "FAILED_ATTEMPTS")
    private int failedAttempts;

    @Column(name = "ACTIVE_PASSWORD")
    private int activePassword;

    @OneToMany(mappedBy = "sirsUser", cascade = { CascadeType.ALL })
    private List<SirsUserAuthorities> sirsUserAuthorities = new ArrayList<SirsUserAuthorities>();

    @Column(name = "PERSON_ID")
    private Long personId;

    @Transient
    private String cpodRole;

    @Transient
    private boolean enable;

    public SirsUser() {

    }

    public SirsUser(String username, String password, int enabled) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
    }

    public SirsUser(String username, String password, int enabled,
            int failedAttempts) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
        this.failedAttempts = failedAttempts;
    }

    public SirsUser(String username, String password, int enabled, Long personId) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
        this.personId = personId;
    }

    public int getEnabled() {
        return enabled;
    }

    public void setEnabled(int enabled) {
        this.enabled = enabled;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public void setFailedAttempts(int failedAttempts) {
        this.failedAttempts = failedAttempts;
    }

    public int getActivePassword() {
        return activePassword;
    }

    public void setActivePassword(int activePassword) {
        this.activePassword = activePassword;
    }

    public List<SirsUserAuthorities> getAuthorities() {
        return sirsUserAuthorities;
    }

    public void setAuthorities(List<SirsUserAuthorities> authorities) {
        this.sirsUserAuthorities = authorities;
    }

    /**
     * @return the cpodRole
     */
    public String getCpodRole() {
        return cpodRole;
    }

    /**
     * @param cpodRole
     *            the cpodRole to set
     */
    public void setCpodRole(String cpodRole) {
        this.cpodRole = cpodRole;
    }

    /**
     * @return the enable
     */
    public boolean isEnable() {
        if (1 == this.getEnabled()) {
            this.enable = true;
            return true;
        } else {
            this.enable = false;
            return false;
        }
    }

    /**
     * @param enable
     *            the enable to set
     */
    public void setEnable(boolean enable) {
        if (enable)
            this.setEnabled(1);
        else
            this.setEnabled(0);
        this.enable = enable;
    }

    /**
     * @return the personId
     */
    public Long getPersonId() {
        return personId;
    }

    /**
     * @param personId
     *            the personId to set
     */
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    /**
     * @return the csvGrantedAuthorities
     */
    @Transient
    public String getCsvGrantedAuthorities() {
        List<SirsUserAuthorities> list = this.getAuthorities();
        StringBuilder csvGrantedAuthorities = new StringBuilder();
        for (SirsUserAuthorities sirsUserAuthority : list) {
            csvGrantedAuthorities.append(sirsUserAuthority.getAuthority()
                    .getAuthorityDescription());
            csvGrantedAuthorities.append(",");
        }
        if (csvGrantedAuthorities.length() == 0) {
            return csvGrantedAuthorities.toString();

        } else {
            return csvGrantedAuthorities.substring(0,
                    csvGrantedAuthorities.length() - 1);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SirsUser [username=" + username + ", password=" + password
                + ", enabled=" + enabled + ", failedAttempts=" + failedAttempts
                + ", activePassword=" + activePassword + ", personId="
                + personId + ", cpodRole=" + cpodRole + ", enable=" + enable
                + "]";
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((personId == null) ? 0 : personId.hashCode());
        result = prime * result
                + ((username == null) ? 0 : username.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof SirsUser)) {
            return false;
        }
        SirsUser other = (SirsUser) obj;
        if (personId == null) {
            if (other.personId != null) {
                return false;
            }
        } else if (!personId.equals(other.personId)) {
            return false;
        }
        if (username == null) {
            if (other.username != null) {
                return false;
            }
        } else if (!username.equals(other.username)) {
            return false;
        }
        return true;
    }

    /**
     * Tests if the AUTHORITY name contains NHSP.
     * 
     * @return true if the authority name contains NHSP
     */
    @Transient
    public boolean isNHSPStaff() {
        if (getAuthorities() != null && !getAuthorities().isEmpty()) {
            for (SirsUserAuthorities authorities : getAuthorities()) {
                String description = authorities.getAuthority()
                        .getAuthorityName();
                if (StringUtils.containsIgnoreCase(description, "NHSP")) {
                    return true;
                }
            }
        }
        return false;
    }
}
