package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.NHSPDepartment;


/**
 * @author AWheatley
 */
public interface NHSPDepartmentService extends
        AbstractService<NHSPDepartment, Long> {

    /**
     * Find NHSPDepartment by Name.
     * @param name Address Type
     * @return NHSPDepartment
     * @throws CpodException on error
     **/
    NHSPDepartment findNhspDepartmentByName(String name) throws CpodException;
}
