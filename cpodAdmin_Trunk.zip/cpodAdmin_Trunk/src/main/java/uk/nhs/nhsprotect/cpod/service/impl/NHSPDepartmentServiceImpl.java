package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.NHSPDepartmentDao;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.NHSPDepartment;
import uk.nhs.nhsprotect.cpod.service.NHSPDepartmentService;

/**
 * @author AWheatley
 */
@Service("nhspDepartmentService")
@Transactional(readOnly = true)
public class NHSPDepartmentServiceImpl extends
        AbstractServiceImpl<NHSPDepartment, Long> implements
        NHSPDepartmentService {

    /**
     * nshpDepartmentDao Represents the DAO for NHSPDepartment.
     */
    @Autowired
    private NHSPDepartmentDao nhspDepartmentDao;

    @Override
    public AbstractDao<NHSPDepartment, Long> getDao() {
        return nhspDepartmentDao;
    }

    @Override
    public NHSPDepartment findNhspDepartmentByName(String name)
            throws CpodException {
        List<NHSPDepartment> found = nhspDepartmentDao
                .findNhspDepartmentByCriteria(name);

        if (found != null && !found.isEmpty()) {
            // multiple records found
            if (found.size() > 1) {
                throw new CpodNonUniqueException(
                        "More than one NHSPDepartment with DepartmentName = ["
                                + name + "]");
            } else {
                // one record found
                return found.get(0);
            }
        } else {
            // No results found
            throw new CpodNoResultsReturnedException(
                    "No results returned for NHSPDepartment with Departmentname = ["
                            + name + "]");
        }

    }

}
