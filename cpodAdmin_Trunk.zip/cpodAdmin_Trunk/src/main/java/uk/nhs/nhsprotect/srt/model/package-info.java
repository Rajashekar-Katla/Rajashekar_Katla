/** SRT Model package.
 */
package uk.nhs.nhsprotect.srt.model;

