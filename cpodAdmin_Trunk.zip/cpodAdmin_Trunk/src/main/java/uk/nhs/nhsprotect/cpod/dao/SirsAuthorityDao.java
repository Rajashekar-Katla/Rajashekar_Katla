/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.sirs.model.SirsAuthority;

/**
 * @author ibandi
 */
public interface SirsAuthorityDao extends AbstractDao<SirsAuthority, Long> {

}
