package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.PersonTypeDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.PersonType;

/**
 * @author AWheatley
 */
@Repository("personTypeDao")
public class PersonTypeDaoImpl extends AbstractDaoImpl<PersonType, Long>
        implements PersonTypeDao {

    /**
     * Logger instance for PersonTypeDaoImpl.class.
     **/
    @SuppressWarnings("unused")
    private static final Logger LOG = Logger.getLogger(PersonTypeDaoImpl.class);

    /**
     * Person Type Dao Implementation.
     */
    protected PersonTypeDaoImpl() {
        super(PersonType.class);
    }

    @Override
    public List<PersonType> findPersonTypeByType(String type)
            throws CpodException {
        return findByCriteria(Restrictions.ilike("description",
                type.toLowerCase(), MatchMode.START));
    }

}
