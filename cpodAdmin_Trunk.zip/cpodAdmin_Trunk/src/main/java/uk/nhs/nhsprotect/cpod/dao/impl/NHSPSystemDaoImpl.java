package uk.nhs.nhsprotect.cpod.dao.impl;

import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.NHSPSystemDao;
import uk.nhs.nhsprotect.cpod.model.NHSPSystem;

/**
 * Hibernate Implementation for NHSPSystemDao.
 * @author ntones
 */
@Repository("nhspSystemDao")
public class NHSPSystemDaoImpl extends AbstractDaoImpl<NHSPSystem, Long>
        implements NHSPSystemDao {

    /**
     * PersonNote DAO.
     */
    protected NHSPSystemDaoImpl() {
        super(NHSPSystem.class);
    }

}
