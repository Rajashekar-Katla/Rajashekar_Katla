package uk.nhs.nhsprotect.cpod.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.SrtAuthorityDao;
import uk.nhs.nhsprotect.cpod.service.SrtAuthorityService;
import uk.nhs.nhsprotect.srt.model.SrtAuthority;

/**
 * Implementation of {@link SrtAuthorityService}
 * @author ntones
 */

@Service("srtAuthorityService")
@Transactional(value = "srtTransactionManager", readOnly = true, propagation = Propagation.REQUIRED)
public class SrtAuthorityServiceImpl extends
        SrtAbstractServiceImpl<SrtAuthority, Long> implements
        SrtAuthorityService {

    /**
     * srtAuthorityDao Represents the DAO for SrtAuthority.
     */
    @Autowired
    private SrtAuthorityDao srtAuthorityDao;

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#getDao()
     */
    @Override
    public AbstractDao<SrtAuthority, Long> getDao() {
        return srtAuthorityDao;
    }

}
