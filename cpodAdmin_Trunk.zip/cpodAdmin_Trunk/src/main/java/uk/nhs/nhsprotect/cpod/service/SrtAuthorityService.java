package uk.nhs.nhsprotect.cpod.service;

import uk.nhs.nhsprotect.srt.model.SrtAuthority;

/**
 * Interface for SrtAuthority Service methods.
 * @author ntones
 */
public interface SrtAuthorityService extends
        AbstractService<SrtAuthority, Long> {

}
