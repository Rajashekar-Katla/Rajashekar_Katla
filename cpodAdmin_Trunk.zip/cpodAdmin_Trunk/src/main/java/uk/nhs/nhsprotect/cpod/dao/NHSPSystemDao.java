/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.cpod.model.NHSPSystem;

/**
 * Interface defining methods for NHSPSystem objects.
 * @author ntones
 */
public interface NHSPSystemDao extends AbstractDao<NHSPSystem, Long> {

}
