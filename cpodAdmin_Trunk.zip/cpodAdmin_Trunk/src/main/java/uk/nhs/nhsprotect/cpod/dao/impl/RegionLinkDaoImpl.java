/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.RegionLinkDao;
import uk.nhs.nhsprotect.cpod.model.RegionLink;

/**
 * AddressLinkDAO implementation.
 * @author awheatley
 */
@Repository("regionLinkDao")
public class RegionLinkDaoImpl extends AbstractDaoImpl<RegionLink, Long>
        implements RegionLinkDao {
    /**
     * Region DAO.
     */
    protected RegionLinkDaoImpl() {
        super(RegionLink.class);
    }

}
