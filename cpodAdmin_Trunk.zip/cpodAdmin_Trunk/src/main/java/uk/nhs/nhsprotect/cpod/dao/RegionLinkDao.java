/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.cpod.model.RegionLink;

/**
 * Provides DAO methods for managing AddressLinks.
 * @author awheatley
 */
public interface RegionLinkDao extends AbstractDao<RegionLink, Long> {

}
