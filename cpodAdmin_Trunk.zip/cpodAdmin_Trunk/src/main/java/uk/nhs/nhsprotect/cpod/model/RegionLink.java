package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Class representing Organisation table (REGION_LINK_TBL).
 * @author awheatley
 */
@Entity
@Table(name = "REGIONS_LINK_TBL")
public class RegionLink extends BaseEntity implements Serializable {
    /**
     * Serial version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Inner class to represent the compound primary key in the Region_link_tbl.
     * @author ntones
     */
    public static class Id implements Serializable {
        /**
         * serial UID.
         */
        private static final long serialVersionUID = -7894626882280964339L;

        /**
         * The Organisation foreign key ref.
         */
        @Column(name = "ORG_ID")
        private Long organisationId;

        /**
         * The Region foreign key ref.
         */
        @Column(name = "REGION_ID")
        private Long regionId;

        /**
         * Default constructor for creating Id instances.
         */
        public Id() {
            // default constructor
        }

        /**
         * Constructor for creating Id instances with parameters.
         * @param organisationId the organisation reference
         * @param regionId the region reference
         */
        public Id(Long organisationId, Long regionId) {
            this.organisationId = organisationId;
            this.regionId = regionId;
        }

        /*
         * (non-Javadoc)
         * @see java.lang.Object#hashCode()
         */
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result
                    + ((regionId == null) ? 0 : regionId.hashCode());
            result = prime
                    * result
                    + ((organisationId == null) ? 0 : organisationId.hashCode());
            return result;
        }

        /*
         * (non-Javadoc)
         * @see java.lang.Object#equals(java.lang.Object)
         */
        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            Id other = (Id) obj;
            if (regionId == null) {
                if (other.regionId != null) {
                    return false;
                }
            } else if (!regionId.equals(other.regionId)) {
                return false;
            }
            if (organisationId == null) {
                if (other.organisationId != null) {
                    return false;
                }
            } else if (!organisationId.equals(other.organisationId)) {
                return false;
            }
            return true;
        }

    }

    @EmbeddedId
    private Id id = new Id();

    @ManyToOne
    @JoinColumn(name = "org_id", insertable = false, updatable = false)
    private Organisation organisation;

    @ManyToOne
    @JoinColumn(name = "region_id", insertable = false, updatable = false)
    private Region region;

    /**
     * Default constructor for creating regionLink objects.
     */
    public RegionLink() {
    }

    /**
     * @param modifiedByUser
     * @param organisation
     * @param region
     */
    public RegionLink(String modifiedByUser, Organisation organisation,
            Region region) {
        // set fields
        super.setModifiedByUser(modifiedByUser);
        this.organisation = organisation;
        this.region = region;

        // set id values
        this.id.regionId = region.getId();
        this.id.organisationId = organisation.getId();

        // Guarantee RI
        organisation.getRegionLinks().add(this);
        region.getRegionLinks().add(this);
    }

    /**
     * @return the id
     */
    public Id getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Id id) {
        this.id = id;
    }

    /**
     * @return the organisation
     */
    public Organisation getOrganisation() {
        return organisation;
    }

    /**
     * @param organisation the organisation to set
     */
    public void setOrganisation(Organisation organisation) {
        this.organisation = organisation;
    }

    /**
     * @return the region
     */
    public Region getRegion() {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(Region region) {
        this.region = region;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof RegionLink)) {
            return false;
        }
        RegionLink other = (RegionLink) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    public void removeRegion() {
        region.getRegionLinks().remove(this);
        organisation.getRegionLinks().remove(this);
    }

}
