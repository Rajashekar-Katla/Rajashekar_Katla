package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Class representing Person table (ADDRESS_TBL).
 * @author awheatley
 */
@Entity
@Table(name = "ADDRESS_TBL")
public class Address extends BaseEntity implements Serializable {
    /**
     * Serial version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key identifier.
     */
    @Id
    @Column(name = "address_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "addressID")
    @GenericGenerator(strategy = "sequence", name = "addressID", parameters = { @Parameter(name = "sequence", value = "BE_ID_SEQNO") })
    private Long id;

    /**
     * Address 1.
     */
    @Column(name = "address_line1")
    private String address1;

    /**
     * Address 2.
     */
    @Column(name = "address_line2")
    private String address2;

    /**
     * Address 3.
     */
    @Column(name = "address_line3")
    private String address3;

    /**
     * Address 4.
     */
    @Column(name = "address_line4")
    private String address4;

    /**
     * Address 5.
     */
    @Column(name = "address_line5")
    private String address5;

    /**
     * Postcode.
     */
    @Column(name = "postcode")
    private String postcode;

    /**
     * Address Type. Linked to AddressType
     */
    @ManyToOne
    @JoinColumn(name = "address_type_id")
    private AddressType addressType;

    /**
     * Link to persons via link table.
     */
    @OneToMany(mappedBy = "address", fetch = FetchType.LAZY)
    private Set<AddressLink> addressLinks = new HashSet<AddressLink>();

    /**
     * Link to organisations.
     */
    @OneToMany(mappedBy = "address", fetch = FetchType.LAZY)
    private Set<Organisation> organisations = new HashSet<Organisation>();

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the address1
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * @param address1 the address1 to set
     */
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    /**
     * @return the address2
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * @param address2 the address2 to set
     */
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    /**
     * @return the address3
     */
    public String getAddress3() {
        return address3;
    }

    /**
     * @param address3 the address3 to set
     */
    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    /**
     * @return the address4
     */
    public String getAddress4() {
        return address4;
    }

    /**
     * @param address4 the address4 to set
     */
    public void setAddress4(String address4) {
        this.address4 = address4;
    }

    /**
     * @return the address5
     */
    public String getAddress5() {
        return address5;
    }

    /**
     * @param address5 the address5 to set
     */
    public void setAddress5(String address5) {
        this.address5 = address5;
    }

    /**
     * @return the postcode
     */
    public String getPostcode() {
        return postcode;
    }

    /**
     * @param postcode the postcode to set
     */
    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    /**
     * @return the addressType
     */
    public AddressType getAddressType() {
        return addressType;
    }

    /**
     * @param addressType the addressType to set
     */
    public void setAddressType(AddressType addressType) {
        this.addressType = addressType;
    }

    /**
     * @return the addressLinks
     */
    public Set<AddressLink> getAddressLinks() {
        return addressLinks;
    }

    /**
     * @param addressLinks the addressLinks to set
     */
    public void setAddressLinks(Set<AddressLink> addressLinks) {
        this.addressLinks = addressLinks;
    }

    /**
     * @return the organisations
     */
    public Set<Organisation> getOrganisations() {
        return organisations;
    }

    /**
     * @param organisations the organisations to set
     */
    public void setOrganisations(Set<Organisation> organisations) {
        this.organisations = organisations;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((address1 == null) ? 0 : address1.hashCode());
        result = prime * result
                + ((address2 == null) ? 0 : address2.hashCode());
        result = prime * result
                + ((address3 == null) ? 0 : address3.hashCode());
        result = prime * result
                + ((address4 == null) ? 0 : address4.hashCode());
        result = prime * result
                + ((address5 == null) ? 0 : address5.hashCode());
        result = prime * result
                + ((addressType == null) ? 0 : addressType.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result
                + ((postcode == null) ? 0 : postcode.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Address other = (Address) obj;
        if (address1 == null) {
            if (other.address1 != null) {
                return false;
            }
        } else if (!address1.equals(other.address1)) {
            return false;
        }
        if (address2 == null) {
            if (other.address2 != null) {
                return false;
            }
        } else if (!address2.equals(other.address2)) {
            return false;
        }
        if (address3 == null) {
            if (other.address3 != null) {
                return false;
            }
        } else if (!address3.equals(other.address3)) {
            return false;
        }
        if (address4 == null) {
            if (other.address4 != null) {
                return false;
            }
        } else if (!address4.equals(other.address4)) {
            return false;
        }
        if (address5 == null) {
            if (other.address5 != null) {
                return false;
            }
        } else if (!address5.equals(other.address5)) {
            return false;
        }
        if (addressType == null) {
            if (other.addressType != null) {
                return false;
            }
        } else if (!addressType.equals(other.addressType)) {
            return false;
        }
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (postcode == null) {
            if (other.postcode != null) {
                return false;
            }
        } else if (!postcode.equals(other.postcode)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Address [id=" + id + ", address1=" + address1 + ", address2="
                + address2 + ", address3=" + address3 + ", address4="
                + address4 + ", address5=" + address5 + ", postcode="
                + postcode + ", addressType=" + addressType + "]";
    }

    /**
     * Gets the list of persons linked to this address, returns empty list if
     * none.
     * @return List persons.
     */
    @Transient
    public List<Person> getPersons() {
        List<Person> personsAtAddress = new ArrayList<Person>();
        for (AddressLink addressLink : addressLinks) {
            personsAtAddress.add(addressLink.getPerson());
        }

        return personsAtAddress;
    }

    /**
     * Method to identify is an address is empty i.e. all address lines are not
     * completed.
     * @return boolean - true if all address fields empty (regardless of id
     *         value).
     */
    @Transient
    public boolean isEmpty() {
        return StringUtils.isEmpty(postcode) && StringUtils.isEmpty(address2)
                && StringUtils.isEmpty(address3)
                && StringUtils.isEmpty(address4)
                && StringUtils.isEmpty(address5)
                && StringUtils.isEmpty(postcode) && null == id;
    }

}
