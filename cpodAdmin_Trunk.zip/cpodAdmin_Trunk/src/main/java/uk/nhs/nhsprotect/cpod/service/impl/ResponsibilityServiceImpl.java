package uk.nhs.nhsprotect.cpod.service.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.OrganisationDao;
import uk.nhs.nhsprotect.cpod.dao.PersonRoleDao;
import uk.nhs.nhsprotect.cpod.dao.ResponsibilityDao;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Organisation;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.Responsibility;
import uk.nhs.nhsprotect.cpod.service.ResponsibilityService;

/**
 * @author AWheatley
 */

@Service("responsibilityService")
@Transactional(readOnly = true)
public class ResponsibilityServiceImpl extends
        AbstractServiceImpl<Responsibility, Long> implements
        ResponsibilityService {

    /**
     * Gives access to the ResponsbilityDao.
     */
    @Autowired
    private ResponsibilityDao responsbilityDao;

    /**
     * Access to organisationDao.
     */
    @Autowired
    private OrganisationDao organisationDao;

    @Autowired
    private PersonRoleDao personRoleDao;

    @Override
    public AbstractDao<Responsibility, Long> getDao() {
        return responsbilityDao;
    }

    @Override
    public List<Responsibility> findResponsibilityByPersonRoleId(
            Long personRoleId) {

        return responsbilityDao.findResponsibilityByPersonRoleId(personRoleId);

    }

    @Override
    public List<Responsibility> findResponsibilityByOrgId(Long orgId)
            throws CpodException {

        List<Responsibility> found = responsbilityDao
                .findResponsibilityByOrgId(orgId);

        if (found != null && !found.isEmpty()) {

            return found;
        } else {
            // No results found
            throw new CpodNoResultsReturnedException(
                    "No results returned for Responsibility with orgId = ["
                            + orgId + "]");
        }
    }

    @Override
    @Transactional(readOnly = false)
    public void saveOrUpdate(Responsibility entity) throws CpodException {

        // need to set the IDs if present
        if (StringUtils.isNotEmpty(entity.getPersonRoleId())
                && entity.getPersonRole() == null) {
            PersonRole personRole = personRoleDao.findById(Long.valueOf(entity
                    .getPersonRoleId()));
            entity.setPersonRole(personRole);
        }
        if (StringUtils.isNotEmpty(entity.getOrganisationId())
                && entity.getOrganisation() == null) {
            Organisation organisation = organisationDao.findById(Long
                    .valueOf(entity.getOrganisationId()));

            entity.setOrganisation(organisation);
        }

        super.saveOrUpdate(entity);
    }
}
