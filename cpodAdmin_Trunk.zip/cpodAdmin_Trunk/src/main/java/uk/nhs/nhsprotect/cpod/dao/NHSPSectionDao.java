package uk.nhs.nhsprotect.cpod.dao;

import java.util.List;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.NHSPSection;

/**
 * NHSP Section DAO.
 * @author awheatley
 */
public interface NHSPSectionDao extends AbstractDao<NHSPSection, Long> {
    /**
     * Find all NHSP Criteria by criteria by Name.
     * @param sectionName String Name of NHSP Section
     * @return - List of Sections.
     * @throws CpodException for error
     */
    List<NHSPSection> findNhspSectionByCriteria(String sectionName)
            throws CpodException;

}
