/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.SirsUserAuthoritiesDao;
import uk.nhs.nhsprotect.cpod.dao.SirsUserServiceDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.service.SirsUserService;
import uk.nhs.nhsprotect.sirs.model.SirsUser;

/**
 * @author ibandi
 */
@Service("sirsUserService")
@Transactional(value = "sirsTransactionManager", readOnly = true, propagation = Propagation.REQUIRED)
public class SirsUserServiceImpl extends
        SirsAbstractServiceImpl<SirsUser, String> implements SirsUserService {

    /**
     * userServiceDao Represents the DAO for SirsUser.
     */
    @Autowired
    private SirsUserServiceDao sirsUserServiceDao;

    /**
     * 
     */
    @Autowired
    private SirsUserAuthoritiesDao sirsuserAuthoritiesDao;

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#getDao()
     */
    @Override
    public AbstractDao<SirsUser, String> getDao() {
        return sirsUserServiceDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.SirsUserService#findByReferenceNumber(
     * java.lang.String)
     */
    @Override
    public SirsUser findByReferenceNumber(String referenceNumber) {
        return ((SirsUserServiceDao) getDao())
                .findByReferenceNumber(referenceNumber);
    }

    @Override
    @Transactional(value = "sirsTransactionManager", readOnly = false, propagation = Propagation.REQUIRED)
    public void deleteByUserName(String userRef) {
        // delete the authorities
        sirsuserAuthoritiesDao.deleteAuthoritiesForUser(userRef);
        ((SirsUserServiceDao) getDao()).deleteByUserName(userRef);
    }

    @Override
    @Transactional(value = "sirsTransactionManager", readOnly = false)
    public void delete(SirsUser sirsUser) throws CpodException {
        // delete the authorities
        sirsuserAuthoritiesDao.deleteAuthoritiesForUser(sirsUser.getUsername());
        super.delete(sirsUser);
    }

}
