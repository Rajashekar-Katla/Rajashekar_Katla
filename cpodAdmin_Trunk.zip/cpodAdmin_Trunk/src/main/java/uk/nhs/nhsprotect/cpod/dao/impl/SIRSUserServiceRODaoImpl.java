/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.cpod.dao.SIRSUserServiceRODao;
import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.Responsibility;
import uk.nhs.nhsprotect.cpod.util.DataTablesUtils;
import uk.nhs.nhsprotect.sirs.model.SirsUserRO;

import com.github.dandelion.datatables.core.ajax.ColumnDef;
import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;

/**
 * @author ibandi
 */
@Repository("sirsUserServiceRODao")
public class SIRSUserServiceRODaoImpl extends AbstractDaoImpl<SirsUserRO, Long>
        implements SIRSUserServiceRODao {

    /**
     * User Dao Implementation.
     */
    protected SIRSUserServiceRODaoImpl() {
        super(SirsUserRO.class);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<SirsUserRO> findUsersWithoutResponsibilities() {

        List<SirsUserRO> resultList = new ArrayList<SirsUserRO>();
        // check sisrs user roles for responsibilities with end dates less than
        // today
        // get the responsibilities for all active sirsUserRO objects
        DetachedCriteria criteria = DetachedCriteria.forClass(SirsUserRO.class);
        criteria.add(Restrictions.eq("enabled", 1));// all enabled users

        List<SirsUserRO> enabledUsers = criteria.getExecutableCriteria(
                getCurrentSession()).list();

        // TODO see if we can get a better implementation - show a count of
        // active resps?
        for (SirsUserRO sirsUserRO : enabledUsers) {
            Person person = sirsUserRO.getPerson();
            if (person != null) {
                List<PersonRole> personRoles = person.getPersonRoles();
                if (personRoles != null) {
                    if (personRoles.isEmpty()) {
                        resultList.add(sirsUserRO);
                    } else {
                        for (PersonRole role : personRoles) {
                            if (role.getPersonType().isAllowedResponsibility()) {
                                if (role.getPersonRef().equalsIgnoreCase(
                                        sirsUserRO.getUsername())) {

                                    Set<Responsibility> responsibilities = role
                                            .getResponsibilities();
                                    if (responsibilities != null
                                            && !responsibilities.isEmpty()) {
                                        int totalResps = responsibilities
                                                .size();
                                        int inactiveResps = 0;
                                        for (Responsibility responsibility : responsibilities) {
                                            if (responsibility.getEndDate()
                                                    .before(new Date())) {
                                                inactiveResps++;
                                            }

                                        }
                                        if (inactiveResps == totalResps) {
                                            // all resps inactive
                                            resultList.add(sirsUserRO);
                                        }
                                    }
                                } else {
                                    resultList.add(sirsUserRO);
                                }

                            }
                        }
                    }
                }
            }
        }

        return resultList;
    }

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.dao.SIRSUserServiceRODao#
     * findSirsUsersWithDatatablesCriterias
     * (com.github.dandelion.datatables.core.ajax.DatatablesCriterias)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<SirsUserRO> findSirsUsersWithDatatablesCriterias(
            DatatablesCriterias criterias, boolean forScreenDisplav) {
        final String alias = "sirsUser";
        StringBuilder queryBuilder = new StringBuilder("SELECT " + alias
                + " from SirsUserRO as " + alias + " ");

        // filter global and individual columns
        queryBuilder
                .append(DataTablesUtils.getUserFiterQuery(criterias, alias));

        // apply sorting
        if (criterias.hasOneSortedColumn()) {
            List<String> orderParams = new ArrayList<String>();
            queryBuilder.append(" ORDER BY ");

            for (ColumnDef columnDef : criterias.getSortingColumnDefs()) {
                if (columnDef.getName().equals("fullname")) {
                    orderParams.add(alias + ".person.surName "
                            + columnDef.getSortDirection());
                    orderParams.add(alias + ".person.foreName "
                            + columnDef.getSortDirection());

                } else if (columnDef.getName().equals("status")) {
                    orderParams.add(alias + ".enabled "
                            + columnDef.getSortDirection());
                } else {
                    orderParams.add(alias + "." + columnDef.getName() + " "
                            + columnDef.getSortDirection());
                }

            }

            Iterator<String> iterator = orderParams.iterator();
            while (iterator.hasNext()) {
                queryBuilder.append(iterator.next());
                if (iterator.hasNext()) {
                    queryBuilder.append(", ");
                }
            }
        }

        Query query = getCurrentSession().createQuery(queryBuilder.toString());

        if (forScreenDisplav) {
            // limit the query size to the current selected values, otherwise
            // retrieve the full list of users
            query.setFirstResult(criterias.getDisplayStart());
            query.setMaxResults(criterias.getDisplaySize());
        }

        return (List<SirsUserRO>) query.list();
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.dao.SIRSUserServiceRODao#getFilteredCount(com.
     * github.dandelion.datatables.core.ajax.DatatablesCriterias)
     */
    @Override
    public Long getFilteredCount(DatatablesCriterias criterias) {

        final String alias = "sirsUser";
        StringBuilder queryBuilder = new StringBuilder("SELECT COUNT(" + alias
                + ") from SirsUserRO " + alias + " ");
        queryBuilder
                .append(DataTablesUtils.getUserFiterQuery(criterias, alias));
        return ((Long) getCurrentSession().createQuery(queryBuilder.toString())
                .uniqueResult());
    }
}
