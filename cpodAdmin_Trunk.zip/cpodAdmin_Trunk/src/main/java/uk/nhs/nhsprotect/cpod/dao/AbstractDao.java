package uk.nhs.nhsprotect.cpod.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Criterion;

import uk.nhs.nhsprotect.cpod.exception.CpodException;

/**
 * AbstractDAO interface to be extended by typed DAO implementations.
 * @author awheatley
 * @param <T> the class type that requires DAO
 * @param <ID> the type of the ID within the class T
 */

/**
 * @author awheatley
 * @param <T>
 * @param <ID>
 */
public interface AbstractDao<T, ID extends Serializable> {

    /**
     * Method to persist an object to the database and return the created
     * object.
     * @param entity the entity to save
     * @return ID for entity
     * @throws CpodException if error occurs
     */
    ID save(T entity) throws CpodException;

    /**
     * Method to update a persistent entity.
     * @param entity to update
     * @throws CpodException if error occurs
     */
    void update(T entity) throws CpodException;

    /**
     * Method to save or update an entity, if not present on the database a save
     * occurs, otherwise existing entry is added.
     * @param entity to save or update
     * @throws CpodException if error occurs
     */
    void saveOrUpdate(T entity) throws CpodException;

    /**
     * Method to delete the entity supplied.
     * @param entity to be deleted
     * @throws CpodException if error occurs
     */
    void delete(T entity) throws CpodException;

    /**
     * Method to retrieve an object from the database by it's ID.
     * @param id criteria to search with
     * @return T matching class for ID
     * @throws CpodException if error occurs
     */
    T findById(ID id) throws CpodException;

    /**
     * Method to search for classes based on the criteria supplied.
     * @param criterion to search for classes
     * @return List of objects matching criterion
     * @throws CpodException if error occurs
     */
    List<T> findByCriteria(Criterion criterion) throws CpodException;

    /**
     * Method to delete all records of the provided class.
     * @param clazz class to delete
     * @return int number of rows deleted.
     * @throws CpodException if error occurs
     */
    int deleteAll() throws CpodException;

    /**
     * Method to find all records for underlying persistent Class.
     * @return List of all entities
     * @throws CpodException if error occurs
     */
    List<T> findAll() throws CpodException;

    /**
     * Find all records by multiple 'and' criteria.
     * @param searchCriteria - map containing key value pairs of criteria field
     *            name and value
     * @return - All matching records (generic)
     */
    List<T> findByAndCriterias(Map<String, String> searchCriteria);

    Session getCurrentSession();

    /**
     * Merges an entity with any object in the session with the matching ID
     * @param entity to merge
     * @return the updated entity
     */
    T merge(T entity);

    /**
     * Returns the total count of records.
     * 
     * @return number of records
     */
    Long getTotalCount();

}
