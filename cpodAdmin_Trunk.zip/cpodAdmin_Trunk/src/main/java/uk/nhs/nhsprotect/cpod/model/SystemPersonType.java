/**
 * 
 */
package uk.nhs.nhsprotect.cpod.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Represents the person types allowed to access an NHS protect System.
 * @author ntones
 */
@Entity
@Table(name = "SYSTEM_PERSON_TYPE_TBL")
public class SystemPersonType implements Serializable {

    /**
     * Default serial version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Primary key field.
     */
    @Id
    @Column(name = "SYS_PERSON_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "systemPersonId")
    @GenericGenerator(strategy = "sequence", name = "systemPersonId", parameters = { @Parameter(name = "sequence", value = "SYSTEM_PERSON_ID_SEQNO") })
    private Long id;

    /**
     * The system this person type applies to.
     */
    @ManyToOne(cascade = { CascadeType.PERSIST })
    @JoinColumn(name = "system_id")
    private NHSPSystem system;

    /**
     * The person type.
     */
    @ManyToOne
    @JoinColumn(name = "person_type_id")
    private PersonType personType;

    /**
     * The permitted status of the person type.
     */
    @Column(name = "status", nullable = false)
    private String status;

    /**
     * Default constructor.
     */
    public SystemPersonType() {
        // default
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the system
     */
    public NHSPSystem getSystem() {
        return system;
    }

    /**
     * @param system the system to set
     */
    public void setSystem(NHSPSystem system) {
        this.system = system;
    }

    /**
     * @return the personType
     */
    public PersonType getPersonType() {
        return personType;
    }

    /**
     * @param personType the personType to set
     */
    public void setPersonType(PersonType personType) {
        this.personType = personType;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((personType == null) ? 0 : personType.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((system == null) ? 0 : system.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SystemPersonType other = (SystemPersonType) obj;
        if (personType == null) {
            if (other.personType != null) {
                return false;
            }
        } else if (!personType.equals(other.personType)) {
            return false;
        }
        if (status == null) {
            if (other.status != null) {
                return false;
            }
        } else if (!status.equals(other.status)) {
            return false;
        }
        if (system == null) {
            if (other.system != null) {
                return false;
            }
        } else if (!system.equals(other.system)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SystemPersonType [id=" + id + ", system=" + system
                + ", personType=" + personType + ", status=" + status + "]";
    }

}
