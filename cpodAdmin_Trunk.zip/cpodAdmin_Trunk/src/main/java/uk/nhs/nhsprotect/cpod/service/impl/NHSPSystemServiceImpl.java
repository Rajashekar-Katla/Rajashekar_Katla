package uk.nhs.nhsprotect.cpod.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.NHSPSystemDao;
import uk.nhs.nhsprotect.cpod.dao.SystemPersonTypeDao;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.NHSPSystem;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;
import uk.nhs.nhsprotect.cpod.service.NHSPSystemService;

/**
 * Implementation of NHSPSystemService.
 * @author ntones
 */
@Service("nhspSystemService")
@Transactional(readOnly = true)
public class NHSPSystemServiceImpl extends
        AbstractServiceImpl<NHSPSystem, Long> implements NHSPSystemService {

    /**
     * Logger instance for NHSPSystemServiceImpl.class.
     **/
    private static final Logger LOG = Logger
            .getLogger(NHSPSystemServiceImpl.class);
    /**
     * nhspSystemDao Represents the DAO for NHSPSystem.
     */
    @Autowired
    private NHSPSystemDao nhspSystemDao;

    @Autowired
    private SystemPersonTypeDao systemPersonTypeDao;

    @Override
    public AbstractDao<NHSPSystem, Long> getDao() {
        return nhspSystemDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#save(java.lang
     * .Object)
     */
    @Override
    @Transactional(readOnly = false)
    public Long save(NHSPSystem entity) throws CpodException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Saving entity " + entity);
        }
        if (entity.getId() == null) {
            //assign an ID to the system
            super.save(entity);
            if (entity.getPersonTypes() != null) {
                for (PersonType personType : entity.getPersonTypes()) {
                    SystemPersonType systemPersonType = new SystemPersonType();
                    systemPersonType.setPersonType(personType);
                    systemPersonType.setStatus(entity.getSelectedStatus());
                    entity.addSystemPersonType(systemPersonType);
                    systemPersonTypeDao.saveOrUpdate(systemPersonType);
                }
            }
        }
        return super.save(entity);
    }

}
