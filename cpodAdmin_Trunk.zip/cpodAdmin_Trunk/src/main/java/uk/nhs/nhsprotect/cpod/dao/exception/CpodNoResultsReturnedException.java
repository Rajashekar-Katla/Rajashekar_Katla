package uk.nhs.nhsprotect.cpod.dao.exception;

import uk.nhs.nhsprotect.cpod.exception.CpodException;

/**
 * Exception indicating that no results were returned when a result is expected.
 * @author awheatley
 */
public class CpodNoResultsReturnedException extends CpodException {

    /**
     * Serial Number for Class.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Default Constructor.
     */
    public CpodNoResultsReturnedException() {
        // default constructor
    }

    /**
     * Constructor with passed in message.
     * @param message Description of Error
     */
    public CpodNoResultsReturnedException(String message) {
        super(message);
    }

    /**
     * Constructor with cause of throwable.
     * @param cause type
     */
    public CpodNoResultsReturnedException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor with cause of throwable.
     * @param message Description of Error
     * @param cause type
     */
    public CpodNoResultsReturnedException(String message, Throwable cause) {
        super(message, cause);
    }

}
