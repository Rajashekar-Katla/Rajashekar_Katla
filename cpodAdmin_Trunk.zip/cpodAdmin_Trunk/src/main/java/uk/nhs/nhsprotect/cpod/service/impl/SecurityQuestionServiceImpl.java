/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.SecurityQuestionDao;
import uk.nhs.nhsprotect.cpod.model.SecurityQuestion;
import uk.nhs.nhsprotect.cpod.service.SecurityQuestionService;

/**
 * Implementation of SecurityQuestionService.
 * 
 * @author ntones
 * 
 */
@Service("securityQuestionService")
public class SecurityQuestionServiceImpl extends
        AbstractServiceImpl<SecurityQuestion, Long> implements
        SecurityQuestionService {

    /**
     * DAO instance used by service.
     */
    @Autowired
    private SecurityQuestionDao securityQuestionDao;

    /*
     * (non-Javadoc)
     * 
     * @see uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#getDao()
     */
    @Override
    public AbstractDao<SecurityQuestion, Long> getDao() {

        return securityQuestionDao;
    }

}
