/**
 * 
 */
package uk.nhs.nhsprotect.cpod.dao;

import uk.nhs.nhsprotect.cpod.model.AddressLink;

/**
 * Provides DAO methods for managaing AddressLinks.
 * @author ntones
 */
public interface AddressLinkDao extends AbstractDao<AddressLink, Long> {

}
