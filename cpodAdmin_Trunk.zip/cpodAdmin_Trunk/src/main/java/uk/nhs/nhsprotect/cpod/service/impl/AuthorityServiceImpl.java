/**
 * 
 */
package uk.nhs.nhsprotect.cpod.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import uk.nhs.nhsprotect.cpod.dao.AbstractDao;
import uk.nhs.nhsprotect.cpod.dao.AuthorityDao;
import uk.nhs.nhsprotect.cpod.model.authentication.Authority;
import uk.nhs.nhsprotect.cpod.service.AuthorityService;

/**
 * @author ntones
 */
@Service("authorityService")
public class AuthorityServiceImpl extends AbstractServiceImpl<Authority, Long>
        implements AuthorityService {

    @Autowired
    private AuthorityDao authorityDao;

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.cpod.service.impl.AbstractServiceImpl#getDao()
     */
    @Override
    public AbstractDao<Authority, Long> getDao() {
        return authorityDao;
    }

}
