package uk.nhs.nhsprotect.cpod.service;

import java.util.List;

import uk.nhs.nhsprotect.cpod.controller.dto.SystemUserDTO;
import uk.nhs.nhsprotect.sirs.model.SirsUserRO;

import com.github.dandelion.datatables.core.ajax.DataSet;
import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;

/**
 * @author ntones
 */
public interface SirsUserServiceRO extends AbstractService<SirsUserRO, Long> {

    /**
     * Method to identify SIRS users without any active responsibilities.
     * @return List<SirsUserRO> users
     */
    List<SirsUserRO> findUsersWithoutResponsibilities();

    /**
     * Method to return a list of SirsUserRO object for the supplied criteria.
     * @param criterias
     * @param forScreenDisplav indicates if the query is for an export or to be
     *            displayed on screen
     * @return {@link DataSet} matching records
     */
    DataSet<SystemUserDTO> findSirsUsersWithDatatablesCriterias(
            DatatablesCriterias criterias, boolean forScreenDisplay);

}
