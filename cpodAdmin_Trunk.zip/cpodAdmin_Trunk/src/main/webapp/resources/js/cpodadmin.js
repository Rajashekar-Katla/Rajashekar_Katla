/*!
 * cpodadmin.js
 * Holds site specific javascript methods
 */

/**
 * trim method for IE8 as it does not support default .trim() as other browsers
 * do.
 */
if (typeof String.prototype.trim != "function") {
	String.prototype.trim = function() {
		return this.replace(/^\s+|\s+$/g, '');
	};
}

// Sets the default end date i.e. 31-DEC-9999
function setDefaultEndDate(fieldName) {
	if (fieldName == null) {
		$("#endDate").val('31/12/9999');
	} else {
		$("#" + fieldName + "endDate").val('31/12/9999');
	}

}

// sirsUser datatable callback - called when table is finished rendering
function drawCallback(nRow, aData, iDataIndex) {
	// enable JS tooltip on table items.
	$("[rel=tooltip]").tooltip({
		placement : "right",
		trigger : "hover",
		container : "body"
	});
}

// customRender function used to generate clickable link in reference column for
// ajax user table.
function renderUserReference(data, type, full) {

	var refHTML = full.username;
	if (full.personId != null) {
		var refHTML = '<a rel="tooltip" ';
		refHTML += 'title="Click to vew user Person Record"';
		refHTML += 'href='+window.location.origin+'/cpodAdmin/viewPerson?id='
				+ full.personId + '>' + full.username + '</a>';
	}
	return refHTML;
}



