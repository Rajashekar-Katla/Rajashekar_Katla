--delete from user authorities
delete from user_authorities;
--delete from authorities
delete from authorities_new;
--delete from users
delete users;




--insert authorities
Insert into AUTHORITIES_NEW (AUTHORITY_ID,AUTHORITY_NAME,AUTHORITY_DESCRIPTION) values (1,'ROLE_LSMS','LSMS User');
Insert into AUTHORITIES_NEW (AUTHORITY_ID,AUTHORITY_NAME,AUTHORITY_DESCRIPTION) values (2,'ROLE_LSSP','LSMS Support Plus User');
Insert into AUTHORITIES_NEW (AUTHORITY_ID,AUTHORITY_NAME,AUTHORITY_DESCRIPTION) values (3,'ROLE_LMS','LSMS Support User');
Insert into AUTHORITIES_NEW (AUTHORITY_ID,AUTHORITY_NAME,AUTHORITY_DESCRIPTION) values (4,'ROLE_NHSP_OPS','NHS Protect OPS User');
Insert into AUTHORITIES_NEW (AUTHORITY_ID,AUTHORITY_NAME,AUTHORITY_DESCRIPTION) values (5,'ROLE_NHSP_CU','NHS Protect CU User');
Insert into AUTHORITIES_NEW (AUTHORITY_ID,AUTHORITY_NAME,AUTHORITY_DESCRIPTION) values (6,'ROLE_SMD','SMD User');


--insert into users
Insert into USERS (USERNAME,PASSWORD,ENABLED,FAILED_ATTEMPTS,ACTIVE_PASSWORD,PERSON_ID) values ('lsms0246','657f8b8da628ef83cf69101b6817150a',1,0,1,1);
Insert into USERS (USERNAME,PASSWORD,ENABLED,FAILED_ATTEMPTS,ACTIVE_PASSWORD,PERSON_ID) values ('lsms0657','657f8b8da628ef83cf69101b6817150a',1,0,1,4);


--insert user authorities

Insert into USER_AUTHORITIES (USERNAME,ID,AUTHORITY_ID) values ('lsms0246',1,1);
Insert into USER_AUTHORITIES (USERNAME,ID,AUTHORITY_ID) values ('lsms0657',2,1);




