--delete from user authorities
delete from user_authorities_tbl;
--delete from authorities
delete from authorities_tbl;
--delete from users
delete users;




--insert authorities
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (1,'ROLE_ADMIN','admin');
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (2,'ROLE_LCFS','LCFS');
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (3,'ROLE_LSMS','LSMS');
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (5,'ROLE_CORP_LSMS','CORPORTATE LSMS');
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (4,'ROLE_CORP_LCFS','CORPORATE LCFS');

--insert into users

Insert into USERS (USERNAME,PASSWORD,ENABLED,FAILED_ATTEMPTS,DEFAULT_PASSWORD_CHANGED,USER_ID,PERSON_ID) values ('lsms0134','pass123',1,0,'N',2338,1);
Insert into USERS (USERNAME,PASSWORD,ENABLED,FAILED_ATTEMPTS,DEFAULT_PASSWORD_CHANGED,USER_ID,PERSON_ID) values ('lsms0138','pass123',1,0,'N',2339,4);


--insert user authorities

Insert into USER_AUTHORITIES_tbl (USER_ID,USER_AUTHORITIES_ID,AUTHORITIES_ID) values (2338,1,3);
Insert into USER_AUTHORITIES_tbl (USER_ID,USER_AUTHORITIES_ID,AUTHORITIES_ID) values (2339,2,3);




