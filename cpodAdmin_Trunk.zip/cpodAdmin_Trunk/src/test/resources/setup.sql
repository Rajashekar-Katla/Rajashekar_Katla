--teardown

delete from cpodjunit.SYSTEM_PERSON_TYPE_TBL;

delete from cpodjunit.SYSTEM_TBL;

-- 16
delete from cpodjunit.USER_AUTHORITIES_TBL;
--15
delete from cpodjunit.authorities_tbl;
--14
delete from CPODJUNIT.USERS;


-- 11
Delete from cpodjunit.responsibilities_tbl;
-- 10
Delete from cpodjunit.address_link_tbl;
-- 9
Delete from cpodjunit.nhsp_section_tbl;
-- 8
Delete from cpodjunit.nhsp_department_tbl;
-- 7a
Delete from CPODJUNIT.PERSON_ROLE_TBL;
-- 7aa
Delete from CPODJUNIT.PERSON_NOTES_TBL;
-- 7
Delete from cpodjunit.person_tbl;
-- 6
Delete from cpodjunit.person_type_tbl;
-- 5a
Delete from CPODJUNIT.REGIONS_LINK_TBL;
-- 5
Delete from cpodjunit.organisations_tbl;
-- 4
Delete from cpodjunit.org_type_tbl;
-- 3a
Delete from cpodjunit.regions_tbl;
-- 3
Delete from cpodjunit.regions_type_tbl;
-- 2
Delete from cpodjunit.address_tbl;
-- 1
delete from cpodjunit.address_type_tbl;
--12
delete from cpodjunit.SECURITY_QUESTIONS_TBL;



--set escape on

--12 Security questions table
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (0,'Not Specified','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (1,'What was the name of your first pet?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (2,'What was the make of your first car?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (3,'What was the name of your first school?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (4,'Where did you go on your honeymoon?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (5,'Who was your best friend at school?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (6,'What was the first music single you bought?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (7,'Where is your favourite holiday destination?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (8,'Where did you first meet your partner?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (9,'What is your favourite pastime?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (10,'What is your favourite film?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (11,'What was the name of your first employer?','CPOD');
Insert into SECURITY_QUESTIONS_TBL (ID,QUESTION,MODIFIED_BY_USER) values (12,'What is your favourite food?','CPOD');

  


-- 1. Insert Address Type

Insert into CPODJUNIT.ADDRESS_TYPE_TBL
   (ADDRESS_TYPE_ID, ADDRESS_TYPE, MODIFIED_BY_USER)
 Values
   (1, 'Work', 'ETL');
Insert into CPODJUNIT.ADDRESS_TYPE_TBL
   (ADDRESS_TYPE_ID, ADDRESS_TYPE, MODIFIED_BY_USER)
 Values
   (2, 'Home', 'ETL');


-- 2. Address Table



Insert into cpodjunit.ADDRESS_TBL
   (ADDRESS_ID, ADDRESS_LINE1, ADDRESS_LINE2, ADDRESS_LINE3, ADDRESS_LINE4, POSTCODE, ADDRESS_TYPE_ID, MODIFIED_BY_USER)
 Values
   (1, 'Quality Directorate', 'Weston House', '246 High Holborn', 'London', 'WC1V 7EX', 1, 'ETL');

Insert into cpodjunit.ADDRESS_TBL
   (ADDRESS_ID, ADDRESS_LINE1, ADDRESS_LINE2, ADDRESS_LINE3, ADDRESS_LINE4, ADDRESS_LINE5, POSTCODE, ADDRESS_TYPE_ID, MODIFIED_BY_USER)
 Values
   (2, 'South Coast Audit', 'Wallsend House', 'Richmond Road', 'Pevensey Bay', 'East Sussex', 'BN24 6AU', 2, 'ETL');

Insert into cpodjunit.ADDRESS_TBL 
    (ADDRESS_ID,ADDRESS_LINE1,ADDRESS_LINE2,ADDRESS_LINE3,ADDRESS_LINE4,ADDRESS_LINE5,POSTCODE,ADDRESS_TYPE_ID,MODIFIED_BY_USER) 
values 
    (5927,'2nd Floor','Weston House','246 High Holborn','London',null,'WC1V 7EX',1,'JPEARSON-ETL');


--3 Regions Type

Insert into cpodjunit.regions_type_tbl (region_type_id, region_type, modified_by_user) values
(1,'A Type','ETL');
Insert into cpodjunit.regions_type_tbl (region_type_id, region_type, modified_by_user) values
(2,'B Type', 'ETL');


--3a. Regions Table

Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y01', 'NORTHERN YORKS REGIONAL OFFICE', 1, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('W00', 'HEALTH SOLUTIONS WALES', 2, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y07', 'WEST MIDLANDS REGIONAL OFFICE', 3, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y08', 'NORTH WEST REGIONAL OFFICE', 4, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y09', 'EASTERN REGIONAL', 5, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y10', 'LONDON REGIONAL OFFICE', 6, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y11', 'SOUTH EAST REGIONAL OFFICE', 7, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y12', 'SOUTH WEST REGIONAL OFFICE', 8, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y21', 'DHSC (LONDON)', 9, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y22', 'DHSC (MIDLANDS AND EASTERN)', 10, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y23', 'DHSC (NORTH)', 11, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y02', 'EAST MIDLANDS REGIONAL OFFICE', 12, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y24', 'DHSC (SOUTH)', 13, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y99', 'NON REGIONAL NHS ORGANISATIONS', 14, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Z99', 'NON REGIONAL NON NHS ORGANISATIONS', 15, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y51', 'THE NORTH MIDLANDS AND EAST PROGRAMME FOR IT (NMEPFIT)', 16, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('W01', 'NATIONAL ASSEMBLY FOR WALES', 17, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y52', 'THE SOUTHERN PROGRAMME FOR IT (SPFIT)', 18, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y53', 'THE LONDON PROGRAMME FOR IT (LPFIT)', 19, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('ETL_AW', 'NO REGION FOUND', 999999999, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));


-- 4. org_type_tbl

Insert into CPODJUNIT.ORG_TYPE_TBL
   (ORG_TYPE_ID, ORG_NAME, MODIFIED_BY_USER)
 Values
   (7, 'HA', 'ETL');
Insert into CPODJUNIT.ORG_TYPE_TBL
   (ORG_TYPE_ID, ORG_NAME, MODIFIED_BY_USER)
 Values
   (8, 'NHS', 'ETL');
Insert into CPODJUNIT.ORG_TYPE_TBL
   (ORG_TYPE_ID, ORG_NAME, MODIFIED_BY_USER)
 Values
   (9, 'NonNHS', 'ETL');
Insert into CPODJUNIT.ORG_TYPE_TBL
   (ORG_TYPE_ID, ORG_NAME, MODIFIED_BY_USER)
 Values
   (10, 'PCT', 'ETL');
Insert into CPODJUNIT.ORG_TYPE_TBL
   (ORG_TYPE_ID, ORG_NAME, MODIFIED_BY_USER)
 Values
   (11, 'SPHA', 'ETL');
Insert into CPODJUNIT.ORG_TYPE_TBL
   (ORG_TYPE_ID, ORG_NAME, MODIFIED_BY_USER)
 Values
   (12, 'Trust', 'ETL');



-- 5. Organisations_tbl;


Insert into cpodjunit.ORGANISATIONS_TBL
   (ORG_ID, org_type_id, ORG_CODE, ADDRESS_ID, OPEN_DATE, CLOSE_DATE, SUB_TYPE_CODE, ORG_NAME, MODIFIED_BY_USER)
 Values
   (5448, 7, '5F8', 1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'C', 'BEBINGTON AND WEST WIRRAL PCT', 'ETL');
Insert into cpodjunit.ORGANISATIONS_TBL
   (ORG_ID, org_type_id, ORG_CODE, ADDRESS_ID, OPEN_DATE, CLOSE_DATE, SUB_TYPE_CODE, ORG_NAME, MODIFIED_BY_USER)
 Values
   (5449, 8, '5F9', 2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'C', 'SOUTHPORT AND FORMBY PCT', 'ETL');
Insert into cpodjunit.ORGANISATIONS_TBL 
    (ORG_ID,ORG_CODE,ADDRESS_ID,OPEN_DATE,CLOSE_DATE,SUB_TYPE_CODE,MEDICAL_STAFF_QTY,NON_MEDICAL_STAFF_QTY,ORG_NAME,MODIFIED_BY_USER,ORG_TYPE_ID,IMPORT_FILE) 
values 
    (5927,'T1350',5927,to_date('09-MAR-2006','DD-MON-YYYY'),to_date('31-DEC-9999','DD-MON-YYYY'),'A',null,null,'NHS Protect','JPEARSON-ETL',11,null);


-- 5a Regions Link Table

Insert into cpodjunit.regions_link_tbl
    (region_id, org_id, modified_by_user) values
        (1, 5448, 'ETL');
Insert into cpodjunit.regions_link_tbl
    (region_id, org_id, modified_by_user) values
        (2, 5448, 'ETL');
Insert into cpodjunit.regions_link_tbl
    (region_id, org_id, modified_by_user) values
        (3, 5449, 'ETL');
Insert into cpodjunit.regions_link_tbl
    (region_id, org_id, modified_by_user) values
        (4, 5449, 'ETL');
Insert into cpodjunit.regions_link_tbl
    (region_id, org_id, modified_by_user) values
        (5, 5449, 'ETL');        


-- 6. Person Type


Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (1, 'COMP', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (2, 'CU', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (3, 'OPS', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (4, 'LCFS', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (5, 'LSMS', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (6, 'TEMP', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (15, 'EXTERNAL', 'ETL');
--new person types for SIRS
Insert into PERSON_TYPE_TBL (PERSON_TYPE_ID,PERSON_TYPE,MODIFIED_BY_USER) values (20,'LMS','NTONES');
Insert into PERSON_TYPE_TBL (PERSON_TYPE_ID,PERSON_TYPE,MODIFIED_BY_USER) values (21,'LSSP','NTONES');
Insert into PERSON_TYPE_TBL (PERSON_TYPE_ID,PERSON_TYPE,MODIFIED_BY_USER) values (22,'SMD','NTONES');
Insert into PERSON_TYPE_TBL (PERSON_TYPE_ID,PERSON_TYPE,MODIFIED_BY_USER) values (23,'SPEC','NTONES');



-- 7 Person
Insert into CPODJUNIT.PERSON_TBL
   (PERSON_ID, ORG_ID, TITLE, FORENAME, SURNAME, KNOWN_AS, MODIFIED_BY_USER, STATUS,  EMAIL_NHS, TELEPHONE, MOBILE, PROPRIETRY_COMPLETE, FRAUD_COMPLETE, SECURITY_COMPLETE, ACCREDITED_TRAINING_COMPLETE)
 Values
   (1, 5448, 'Ms', 'Janet', 'Smith', 'Jan', 'ETL', 'Y', 'jan.smith@awp.nhs.uk', '01225 731785', '07788 437844',  'Y', 'N', 'N', 'N');
Insert into CPODJUNIT.PERSON_TBL
   (PERSON_ID, ORG_ID, TITLE, FORENAME, SURNAME, KNOWN_AS, MODIFIED_BY_USER, STATUS, EMAIL_NHS, TELEPHONE, MOBILE, PROPRIETRY_COMPLETE, FRAUD_COMPLETE, SECURITY_COMPLETE, ACCREDITED_TRAINING_COMPLETE)
 Values
   (2, 5449, 'Mrs', 'Eleni', 'Brown', 'El', 'ETL', 'Y', 'eleni.brown@nsft.nhs.uk', '01603 421537', '0111 11111',  'Y', 'Y','N', 'Y');
Insert into CPODJUNIT.PERSON_TBL
   (PERSON_ID, ORG_ID, TITLE, FORENAME, SURNAME, KNOWN_AS, MODIFIED_BY_USER, STATUS, EMAIL_NHS, TELEPHONE, MOBILE, PROPRIETRY_COMPLETE, FRAUD_COMPLETE, SECURITY_COMPLETE, ACCREDITED_TRAINING_COMPLETE)
 Values
   (2058, 5449, 'Mr', 'Nick', 'Tones', 'Nick', 'ETL', 'Y', 'nick@nsft.nhs.uk', '0191 2046200', '0111 22222',  'Y', 'Y','Y', 'Y');
Insert into CPODJUNIT.PERSON_TBL
   (PERSON_ID, ORG_ID, TITLE, FORENAME, SURNAME, KNOWN_AS, MODIFIED_BY_USER, STATUS,  EMAIL_NHS, TELEPHONE, MOBILE, PROPRIETRY_COMPLETE, FRAUD_COMPLETE, SECURITY_COMPLETE, ACCREDITED_TRAINING_COMPLETE)
 Values
   (4, 5448, 'Ms', 'JanetSIRSADMIN', 'SmithSIRSADMIN', 'Jan', 'ETL', 'N', 'jan.smithsirsadmin@awp.nhs.uk', '01225 731785', '07788 437844',  'Y', 'N', 'N', 'N');
   

Insert into CPODJUNIT.PERSON_TBL 
	(PERSON_ID,ORG_ID,ESR_ID,TITLE,FORENAME,FORENAME2,SURNAME,KNOWN_AS,DOB,MODIFIED_BY_USER,STATUS,EMAIL_NHS,EMAIL_OTHER,TELEPHONE,TELEPHONE2,EXT,FAX,MOBILE,PROPRIETRY_COMPLETE,PROPRIETRY_DATE,FRAUD_COMPLETE,FRAUD_DATE,SECURITY_COMPLETE,SECURITY_DATE,ACCREDITED_TRAINING_COMPLETE,NHSP_SECTION_ID,SECURITY_ACCREDITATION_DATE,FRAUD_ACCREDITATION_DATE,SEC_QUESTION_1,SEC_QUESTION_2,SEC_ANSWER_1,SEC_ANSWER_2) 
	values (1929,5449,10867702,'Mr','Alan',null,'Wheatley','Alan',null,'ops0259','Y','alan.bowstead@nhsprotect.gsi.gov.uk',null,'0191 204 6313',null,'6313','01912046320','07775 703642','Y',null,null,null,null,null,'N',null,null,null,3,6,'HTUkW7CEon5CYDNHTvgXGLwloQ5Aanl3','gePqbRIgk/B9BWnpXugHCL6HupYkzHKZ');



   
  -- 7aa Person Notes
  
  Insert into cpodjunit.person_notes_tbl
  	(person_notes_id, note, person_id, modified_by_user)
   values
   	(1,'Some Data', 1, 'ETL');
   
   -- 7a Person Role
Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(1,1,'lsms0246', 5, null, TO_DATE('11/03/2004 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LSMS','NA');

Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(2,2,'lcfs1538', 4, null, TO_DATE('08/06/2012 15:28:43', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LCFS', 'NA');

Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(3,2,'lsms9999', 5, null, TO_DATE('12/08/2010 15:28:43', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LSMS Lead', 'NA');

Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(4,2058,'ops0259', 3, null, TO_DATE('12/08/2010 15:28:43', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LSMS Lead', 'NA');

	-- SIRS User Administration
Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(5,4,'lsms0657', 5, null, TO_DATE('11/03/2004 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('11/08/2004 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LSMS','NA');

--LSDS admin user
Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(6,2058,'lsdsAdmin', 3, null, TO_DATE('12/08/2010 15:28:43', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LSDS Admin', 'NA');

--Training admin user
Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(7,2058,'trainingAdmin', 3, null, TO_DATE('12/08/2010 15:28:43', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'Training Admin', 'NA');

--Potential CPOD user
Insert into CPODJUNIT.PERSON_ROLE_TBL 
	(PERSON_ROLE_ID,USER_REF,PERSON_TYPE,START_DATE,END_DATE,PERSON_ID,MODIFIED_BY_USER,JOB_TITLE,REASON,MANAGER_ID) 
values 
	(8,'ops0106',3,to_date('05-FEB-2004','DD-MON-YYYY'),to_date('31-DEC-9999','DD-MON-YYYY'),1929,'ops0259','Database Specialist','ETL',null);


 -- 8 NHSP Department 
Insert into cpodjunit.NHSP_DEPARTMENT_TBL
   (NHSP_DEPARTMENT_ID, NHSP_DEPARTMENT_NAME, MODIFIED_BY_USER, NHSP_DEPARTMENT_MANAGER)
 Values
   (6846, 'Deterrence and Engagement', 'ETL',2);
Insert into cpodjunit.NHSP_DEPARTMENT_TBL
   (NHSP_DEPARTMENT_ID, NHSP_DEPARTMENT_NAME, MODIFIED_BY_USER, NHSP_DEPARTMENT_MANAGER)
 Values
   (6847, 'Information and Intelligence Unit', 'ETL',2);
Insert into cpodjunit.NHSP_DEPARTMENT_TBL
   (NHSP_DEPARTMENT_ID, NHSP_DEPARTMENT_NAME, MODIFIED_BY_USER, NHSP_DEPARTMENT_MANAGER)
 Values
   (6848, 'Information Security and Systems', 'ETL',2);
Insert into cpodjunit.NHSP_DEPARTMENT_TBL
   (NHSP_DEPARTMENT_ID, NHSP_DEPARTMENT_NAME, MODIFIED_BY_USER, NHSP_DEPARTMENT_MANAGER)
 Values
   (6849, 'Local Support and Development Services', 'ETL',2);
Insert into cpodjunit.NHSP_DEPARTMENT_TBL
   (NHSP_DEPARTMENT_ID, NHSP_DEPARTMENT_NAME, MODIFIED_BY_USER, NHSP_DEPARTMENT_MANAGER)
 Values
   (6850, 'National Investigations Service','ETL',2);
Insert into cpodjunit.NHSP_DEPARTMENT_TBL
   (NHSP_DEPARTMENT_ID, NHSP_DEPARTMENT_NAME, MODIFIED_BY_USER, NHSP_DEPARTMENT_MANAGER)
 Values
   (6851, 'NHS CFS Wales', 'ETL',2);
Insert into cpodjunit.NHSP_DEPARTMENT_TBL
   (NHSP_DEPARTMENT_ID, NHSP_DEPARTMENT_NAME, MODIFIED_BY_USER, NHSP_DEPARTMENT_MANAGER)
 Values
   (6852, 'Policy and Standards', 'ETL',2);

   
-- 9. NHSP Section Table
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6873, 'Deterrence and Engagement','ETL',1, 6846);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6853, 'Intelligence and Research','ETL',1, 6846);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6854, 'Information Analytics', 'ETL',1, 6847);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6855, 'Systems Support', 'ETL',1, 6847);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6856, 'Systems Security','ETL',1, 6848);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6857, 'Systems Development', 'ETL',1, 6848);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6859, 'Lone Worker Services', 'ETL',1, 6849);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6860, 'LSDS Security Management ', 'ETL',1, 6849);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6861, 'LSDS Anti Fraud', 'ETL',1, 6850);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6862, 'Legal Protection Unit', 'ETL',1, 6850);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6863, 'NIS Special Operations', 'ETL',1, 6851);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6864, 'Financial Investigations', 'ETL',1, 6851);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6865, 'NIS North', 'ETL',1, 6852);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6866, 'NIS South', 'ETL',1, 6852);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6867, 'Forensic Computing Unit', 'ETL',1, 6852);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6868, 'National Investigations Service', 'ETL',1, 6852);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6869, 'NHS CFS Wales', 'ETL',1, 6852);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6870, 'Quality and Compliance', 'ETL',1, 6852);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6871, 'Training', 'ETL',1, 6852);
Insert into cpodjunit.NHSP_SECTION_TBL
   (NHSP_SECTION_ID, NHSP_SECTION_NAME, MODIFIED_BY_USER, NHSP_SECTION_MANAGER, NHSP_DEPARTMENT_ID)
 Values
   (6872, 'Policy and Prevention', 'ETL',1, 6852);


-- 10. Address Link Table

Insert into cpodjunit.ADDRESS_LINK_TBL
   (PERSON_ID, ADDRESS_ID,MODIFIED_BY_USER)
 Values
   (1, 1,'ETL');
Insert into cpodjunit.ADDRESS_LINK_TBL
   (PERSON_ID, ADDRESS_ID,MODIFIED_BY_USER)
 Values
   (2, 2,'ETL');
Insert into cpodjunit.ADDRESS_LINK_TBL
   (PERSON_ID, ADDRESS_ID,MODIFIED_BY_USER)
 Values
   (1, 2,'ETL');


   
-- 11. Responsibilities Table

Insert into cpodjunit.RESPONSIBILITIES_TBL
   (PERSON_role_ID, START_DATE, END_DATE, ORG_ID, RESP_ID, MODIFIED_BY_USER, LEAD)
 Values
   (1, TO_DATE('03/01/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 5448, 1095, 'ETL', 'N');
Insert into cpodjunit.RESPONSIBILITIES_TBL
   (PERSON_role_iD, START_DATE, END_DATE, ORG_ID, RESP_ID, MODIFIED_BY_USER, LEAD)
 Values
   (2, TO_DATE('05/27/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 5449, 1096, 'ETL', 'N');
Insert into cpodjunit.RESPONSIBILITIES_TBL
   (PERSON_role_ID, START_DATE, END_DATE, ORG_ID, RESP_ID, MODIFIED_BY_USER, LEAD)
 Values
   (2, TO_DATE('05/27/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 5448, 1097, 'ETL', 'N');
Insert into cpodjunit.RESPONSIBILITIES_TBL
   (PERSON_role_ID, START_DATE, END_DATE, ORG_ID, RESP_ID, MODIFIED_BY_USER, LEAD)
 Values
   (1, TO_DATE('05/27/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 5449, 1098, 'ETL', 'Y');
   
Insert into cpodjunit.RESPONSIBILITIES_TBL
   (PERSON_role_ID, START_DATE, END_DATE, ORG_ID, RESP_ID, MODIFIED_BY_USER, LEAD)
 Values
   (5, TO_DATE('05/27/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('05/28/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 5449, 1099, 'ETL', 'Y');   




   
   
-- 14. Users Table
Insert into USERS (USERNAME,PASSWORD,ENABLED,FAILED_ATTEMPTS,DEFAULT_PASSWORD_CHANGED,USER_ID,PERSON_ID) values ('lsms0246','$2a$10$MKMjTXmKj4xiURR.K0OpreliHFGilPjfC0o9wY2MAZWkPCILUo.US',1,0,'N',1,1);
Insert into USERS (USERNAME,PASSWORD,ENABLED,FAILED_ATTEMPTS,DEFAULT_PASSWORD_CHANGED,USER_ID,PERSON_ID) values ('lcfs1538','$2a$10$MKMjTXmKj4xiURR.K0OpreliHFGilPjfC0o9wY2MAZWkPCILUo.US',1,0,'Y',2,2);
Insert into USERS (USERNAME,PASSWORD,ENABLED,FAILED_ATTEMPTS,DEFAULT_PASSWORD_CHANGED,USER_ID,PERSON_ID) values ('lsms0657','$2a$10$MKMjTXmKj4xiURR.K0OpreliHFGilPjfC0o9wY2MAZWkPCILUo.US',1,0,'Y',3,5);
Insert into USERS (USERNAME,PASSWORD,ENABLED,FAILED_ATTEMPTS,DEFAULT_PASSWORD_CHANGED,USER_ID,PERSON_ID) values ('lsdsAdmin','$2a$10$MKMjTXmKj4xiURR.K0OpreliHFGilPjfC0o9wY2MAZWkPCILUo.US',1,0,'Y',4,2058);
Insert into USERS (USERNAME,PASSWORD,ENABLED,FAILED_ATTEMPTS,DEFAULT_PASSWORD_CHANGED,USER_ID,PERSON_ID) values ('trainingAdmin','$2a$10$MKMjTXmKj4xiURR.K0OpreliHFGilPjfC0o9wY2MAZWkPCILUo.US',1,0,'Y',5,2058);



--15. Authorities Table
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (1,'ROLE_ADMIN','Administrator');
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (2,'ROLE_USER','User');
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (3,'ROLE_LSDS_ADMIN','LSDS Admin');
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (4,'ROLE_TRAINING_ADMIN','Training Admin');
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (5,'ROLE_SIRS_ADMIN','User able to maintain SIRS Users and their account');
Insert into AUTHORITIES_TBL (AUTHORITY_ID,AUTHORITY_ROLE,AUTHORITY_DESC) values (6,'ROLE_ADMIN_MONITOR','ISD Admin able to access monitoring URL');




--16. User Authorities Table
Insert into USER_AUTHORITIES_TBL (USER_AUTHORITIES_ID,AUTHORITIES_ID,USER_ID) values (2,5,3);
Insert into USER_AUTHORITIES_TBL (USER_AUTHORITIES_ID,AUTHORITIES_ID,USER_ID) values (1,1,2);
Insert into USER_AUTHORITIES_TBL (USER_AUTHORITIES_ID,AUTHORITIES_ID,USER_ID) values (3,2,1);
Insert into USER_AUTHORITIES_TBL (USER_AUTHORITIES_ID,AUTHORITIES_ID,USER_ID) values (4,3,4);
Insert into USER_AUTHORITIES_TBL (USER_AUTHORITIES_ID,AUTHORITIES_ID,USER_ID) values (5,4,5);


--17.  Insert into system table - only 2 systems so far SRT and SIRS
Insert into SYSTEM_TBL (SYSTEM_ID,SYSTEM_NAME) values (1,'SRT');
Insert into SYSTEM_TBL (SYSTEM_ID,SYSTEM_NAME) values (2,'SIRS');
Insert into SYSTEM_TBL (SYSTEM_ID,SYSTEM_NAME) values (3,'CPOD');

--18.  Insert into system person type table - SRT active LSMS/LCFS - SIRS active OPS, CU, LSMS, LSSP, LMS, SMD, SPEC - CPOD Active ops - cu - temp
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (1,'Y',1,5);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (2,'Y',1,4);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (3,'Y',2,3);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (4,'Y',2,21);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (5,'Y',2,22);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (6,'Y',2,23);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (7,'Y',2,2);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (8,'Y',2,5);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (9,'Y',2,20);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (10,'Y',3,2);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (11,'Y',3,3);
Insert into SYSTEM_PERSON_TYPE_TBL (SYS_PERSON_ID,STATUS,SYSTEM_ID,PERSON_TYPE_ID) values (12,'Y',3,6);

 



