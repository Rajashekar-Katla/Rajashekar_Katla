--teardown


delete from cpodjunit.SYSTEM_PERSON_TYPE_TBL;

delete from cpodjunit.SYSTEM_TBL;

-- 16
delete from cpodjunit.USER_AUTHORITIES_TBL;
--15
delete from cpodjunit.authorities_tbl;
--14
delete from CPODJUNIT.USERS;


-- 11
Delete from cpodjunit.responsibilities_tbl;
-- 10
Delete from cpodjunit.address_link_tbl;
-- 9
Delete from cpodjunit.nhsp_section_tbl;
-- 8
Delete from cpodjunit.nhsp_department_tbl;
-- 7a
Delete from CPODJUNIT.PERSON_ROLE_TBL;
-- 7aa
Delete from cpodjunit.person_notes_tbl;
-- 7
Delete from cpodjunit.person_tbl;
-- 6
Delete from cpodjunit.person_type_tbl;
-- 5a
Delete from CPODJUNIT.REGIONS_LINK_TBL;
-- 5
Delete from cpodjunit.organisations_tbl;
-- 4
Delete from cpodjunit.org_type_tbl;
-- 3a
Delete from cpodjunit.regions_tbl;
-- 3
Delete from cpodjunit.regions_type_tbl;
-- 2
Delete from cpodjunit.address_tbl;
-- 1
delete from cpodjunit.address_type_tbl;

--12
delete from cpodjunit.SECURITY_QUESTIONS_TBL;