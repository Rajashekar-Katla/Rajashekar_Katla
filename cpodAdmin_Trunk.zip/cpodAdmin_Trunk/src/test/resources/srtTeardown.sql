--delete from user authorities
delete from user_authorities_tbl;
--delete from authorities
delete from authorities_tbl;
--delete from users
delete users;

