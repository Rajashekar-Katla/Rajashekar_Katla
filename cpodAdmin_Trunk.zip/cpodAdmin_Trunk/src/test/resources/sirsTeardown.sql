--delete from user authorities
delete from user_authorities;
--delete from authorities
delete from authorities_new;
--delete from users
delete users;

