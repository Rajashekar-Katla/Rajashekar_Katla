package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.model.OrganisationType;
import uk.nhs.nhsprotect.cpod.service.OrganisationTypeService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;

/**
 * @author awheatley
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class OrganisationTypeServiceTest {

    /**
     * Gives access to OrganisationTypeService.
     */
    @Autowired
    private OrganisationTypeService organisationTypeService;

    /**
     * Gives access to Organisation Class.
     */
    @SuppressWarnings("unused")
    private OrganisationType organisationType;

    /**
     * Setup for each test that runs.
     * @throws Exception for error
     */
    @Before
    public void setUp() throws Exception {

    }

    /**
     * Teardown of data after tests complete.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws Exception {

    }

    /**
     * Find organisation based on org_code = "5F8".
     * @throws Exception for error
     */
    @Test
    public void testFindOrganisationTypeByType() throws Exception {

        // find record
        OrganisationType found = organisationTypeService
                .findOrganisationTypeByType("HA");

        // create expected instance
        OrganisationType expected = new OrganisationType();
        expected.setId(7L);
        expected.setOrganisationType("HA");

        // compare results
        assertEquals(found, expected);

    }

    /**
     * Find non Organisation Type. CpodNoResultsReturnedException should be
     * thrown.
     * @throws Exception for error
     */
    @Test(expected = CpodNoResultsReturnedException.class)
    public void testFindOrganisationTypeByNonTypes() throws Exception {

        @SuppressWarnings("unused")
        OrganisationType found = organisationTypeService
                .findOrganisationTypeByType("XXX");
    }

    /**
     * Find multiple records for OrganisationType. Exception
     * CpodNonUniqueException should be thrown
     * @throws Exception on error
     */
    @Test(expected = CpodNonUniqueException.class)
    public void testFindOrganisationMultipleResultsByOrgCode() throws Exception {

        // Change Organisation Type of HOME to WORK, so two records exist with
        // same
        // Organisation Type.
        OrganisationType existing = organisationTypeService
                .findOrganisationTypeByType("NHS");
        existing.setOrganisationType("HA");
        organisationTypeService.saveOrUpdate(existing);

        @SuppressWarnings("unused")
        OrganisationType found = organisationTypeService
                .findOrganisationTypeByType("HA");
    }

}
