package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.model.Organisation;
import uk.nhs.nhsprotect.cpod.service.OrganisationService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;

/**
 * @author awheatley
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class OrganisationServiceTest {

    /**
     * Gives access to ORGANISATIONSERVICE.
     */
    @Autowired
    private OrganisationService organisationService;

    /**
     * Gives access to Organisation Class.
     */
    @SuppressWarnings("unused")
    private Organisation organisation;

    /**
     * Setup for each test that runs.
     * @throws Exception for error
     */
    @Before
    public void setUp() throws Exception {

    }

    /**
     * Teardown of data after tests complete.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws Exception {

    }

    /**
     * Find organisation based on org_code = "5F8".
     * @throws Exception for error
     */
    @Test
    public void testFindOrganisationByOrgCode() throws Exception {

        Organisation found = organisationService.findOrgByOrgCode("5F8");

        // TODO COMPARE to static object. Does this satisfy it???
        assertEquals(found, organisationService.findOrgByOrgCode("5F8"));
        assertEquals(found.getOrgCode(), "5F8");
    }

    /**
     * Find non existing org. CpodNoResultsReturnedException should be thrown.
     * @throws Exception for error
     */
    @Test(expected = CpodNoResultsReturnedException.class)
    public void testFindOrganisationByNonExistingOrgCode() throws Exception {

        @SuppressWarnings("unused")
        Organisation found = organisationService.findOrgByOrgCode("XXX");
    }

    /**
     * Find muliple records for OrgCode. Exception CpodNonUniqueException should
     * be thrown
     * @throws Exception on error
     */
    @Test(expected = CpodNonUniqueException.class)
    public void testFindOrganisationMultipleResultsByOrgCode() throws Exception {

        // Change Org code of 5F9 to 5F8, so two records exist with same
        // orgCode.
        Organisation existing = organisationService.findOrgByOrgCode("5F9");
        existing.setOrgCode("5F8");
        organisationService.saveOrUpdate(existing);

        @SuppressWarnings("unused")
        Organisation found = organisationService.findOrgByOrgCode("5F8");
    }

}
