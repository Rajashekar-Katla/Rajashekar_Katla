package uk.nhs.nhsprotect.cpod.test.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@ContextConfiguration(locations = { "classpath:spring/applicationContext.xml",
        "classpath:spring/hibernateContext.xml" })
@ActiveProfiles("junit")
@Transactional
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public @interface CpodAdminServiceTest {

}
