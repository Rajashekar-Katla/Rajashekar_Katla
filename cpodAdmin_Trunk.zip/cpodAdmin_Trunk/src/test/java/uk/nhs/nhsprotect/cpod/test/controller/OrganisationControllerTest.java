package uk.nhs.nhsprotect.cpod.test.controller;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.model.Organisation;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminWebTest;
import uk.nhs.nhsprotect.cpod.test.utils.SecurityRequestPostProcessors;

/**
 * Test class to exercise the PersonController.
 * 
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminWebTest
public class OrganisationControllerTest {

    /**
     * The web application context as managed by Spring.
     */
    @Autowired
    private WebApplicationContext wac;

    /**
     * The message source used within the app.
     */
    @Autowired
    private MessageSource messageSource;

    /**
     * The mocked SpringMVC application instance.
     */
    private MockMvc mockMvc;

    /**
     * The Spring Security filter that intercepts application URLs.
     */
    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    /**
     * The non-admin user to use for testing with.
     */
    private final String user = "lsms0246";

    /**
     * Method to run before all test methods to create test environemnt.
     */
    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
                .addFilters(this.springSecurityFilterChain).build();
        ;
    }

    /**
     * Tests the organisation search function with all parameters supplied but
     * no matches on DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void organisationSearchNoMatchesTest() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/organisationSearch").param("orgCode", "xxxx")
                .param("orgName", "xxxx")
                .with(SecurityRequestPostProcessors.userDetailsService(user));

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the message for empty results is populated
                        String message = (String) mvcResult.getModelAndView()
                                .getModel().get("warnMessage");
                        assertEquals(messageSource.getMessage(
                                "search.result.empty", null, null), message);

                    }
                }).andExpect(MockMvcResultMatchers.view().name("search-view"));
    }

    /**
     * Tests the organisation search function with orgCode supplied and matches
     * on DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void organisationSearchMatchCodeTest() throws Exception {
        final String code = "5F";
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/organisationSearch").param("orgCode", code)
                .with(SecurityRequestPostProcessors.userDetailsService(user));

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.model().attributeExists("orgs"))
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // expect 2 orgs match with orgCode 5F from setup
                        List<Organisation> orgs = (List<Organisation>) mvcResult
                                .getModelAndView().getModel().get("orgs");
                        assertNotNull(orgs);
                        assertEquals(2, orgs.size());

                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("search-results"));
    }

    /**
     * Tests the organisation search function with name supplied and matches on
     * DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void organisationSearchMatchNameTest() throws Exception {
        final String name = "bebi";
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/organisationSearch").param("orgName", name)
                .with(SecurityRequestPostProcessors.userDetailsService(user));

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.model().attributeExists("orgs"))
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // expect 2 orgs match with orgCode 5F from setup
                        List<Organisation> orgs = (List<Organisation>) mvcResult
                                .getModelAndView().getModel().get("orgs");
                        assertNotNull(orgs);
                        assertEquals(1, orgs.size());
                        assertEquals("BEBINGTON AND WEST WIRRAL PCT",
                                orgs.get(0).getOrgName());

                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("search-results"));
    }

    /**
     * Tests the organisation view function with id supplied and matches on DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void viewOrganisationTest() throws Exception {
        final String orgId = "5448";
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/viewOrganisation").param("id", orgId)
                .with(SecurityRequestPostProcessors.userDetailsService(user));
        
        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.model().attributeExists(
                                "organisation"))
                .andExpect(new ResultMatcher() {
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // expect 1 orgs match id from setup
                        Organisation org = (Organisation) mvcResult
                                .getModelAndView().getModel()
                                .get("organisation");
                        assertNotNull(org);
                        assertEquals(Long.valueOf(orgId), org.getId());
                        assertEquals("BEBINGTON AND WEST WIRRAL PCT",
                                org.getOrgName());
                    }
                })
                .andExpect(
                        MockMvcResultMatchers.view().name("organisation-view"));
    }

}
