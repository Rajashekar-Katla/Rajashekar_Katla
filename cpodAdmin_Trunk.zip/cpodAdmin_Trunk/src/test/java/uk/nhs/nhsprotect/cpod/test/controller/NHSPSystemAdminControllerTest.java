package uk.nhs.nhsprotect.cpod.test.controller;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.model.NHSPSystem;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;
import uk.nhs.nhsprotect.cpod.service.NHSPSystemService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminWebTest;
import uk.nhs.nhsprotect.cpod.test.utils.SecurityRequestPostProcessors;

/**
 * Test class for NHSPSystemAdminController.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminWebTest
public class NHSPSystemAdminControllerTest {

    /**
     * The non-admin user to use for testing with.
     */
    private final String nonAdminUser = "lsms0246";

    /**
     * The admin user to use for testing.
     */
    private final String adminUser = "lcfs1538";

    /**
     * The web application context as managed by Spring.
     */
    @Autowired
    private WebApplicationContext wac;

    /**
     * The message source used within the app.
     */
    @Autowired
    private MessageSource messageSource;

    /**
     * The mocked SpringMVC application instance.
     */
    private MockMvc mockMvc;

    /**
     * The Spring Security filter that intercepts application URLs.
     */
    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    /**
     * Reference to NHSPSystemService.
     */
    @Autowired
    private NHSPSystemService nhspSystemService;

    /**
     * @throws java.lang.Exception on error
     */
    @Before
    public void setUp() throws Exception {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
                .addFilters(this.springSecurityFilterChain).build();
    }

    /**
     * Test method to check attempted access to secured methods by non-admin
     * user .
     * @throws Exception on error
     */
    @Test
    public final void testNonAdminAccess() throws Exception {
        RequestBuilder builder = MockMvcRequestBuilders.get(
                "/admin/system/search").with(
                SecurityRequestPostProcessors.userDetailsService(nonAdminUser));
        mockMvc.perform(builder).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isForbidden());

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.controller.NHSPSystemAdminController#searchNHSPSystems(org.springframework.ui.ModelMap)}
     * .
     * @throws Exception on error
     */
    @Test
    public final void testSearchNHSPSystems() throws Exception {
        RequestBuilder builder = MockMvcRequestBuilders.get(
                "/admin/system/search").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));
        mockMvc.perform(builder).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.view().name("system-results"))
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult result) throws Exception {
                        List<NHSPSystem> systems = (List<NHSPSystem>) result
                                .getModelAndView().getModel().get("systems");
                        assertNotNull(systems);
                        assertEquals(3, systems.size());
                    }

                });

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.controller.NHSPSystemAdminController#searchNHSPSystems(org.springframework.ui.ModelMap)}
     * .
     * @throws Exception on error
     */
    @Test
    public final void testSearchNHSPSystemsNoRresults() throws Exception {

        for (NHSPSystem system : nhspSystemService.findAll()) {
            nhspSystemService.delete(system);
        }
        RequestBuilder builder = MockMvcRequestBuilders.get(
                "/admin/system/search").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));
        mockMvc.perform(builder).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.view().name("system-results"))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult result) throws Exception {
                        String message = (String) result.getModelAndView()
                                .getModel().get("warnMessage");
                        assertNotNull(message);
                        assertEquals(
                                "There are no NHSP Systems available for editing.",
                                message);
                    }

                });

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.controller.NHSPSystemAdminController#viewNHSPSystem(java.lang.Long, org.springframework.ui.ModelMap)}
     * .
     * @throws Exception on error
     */
    @Test
    public final void testViewNHSPSystem() throws Exception {
        RequestBuilder builder = MockMvcRequestBuilders.get(
                "/admin/system/view/1").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));
        mockMvc.perform(builder).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.view().name("system-view"))
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult result) throws Exception {
                        NHSPSystem system = (NHSPSystem) result
                                .getModelAndView().getModel().get("nhspSystem");
                        assertNotNull(system);
                        assertEquals(Long.valueOf(1L), system.getId());
                        List<PersonType> personTypes = (List<PersonType>) result
                                .getModelAndView().getModel()
                                .get("personTypes");
                        assertNotNull(personTypes);
                        assertEquals(11, personTypes.size());
                        SystemPersonType systemPersonType = (SystemPersonType) result
                                .getModelAndView().getModel()
                                .get("systemPersonType");
                        assertNotNull(systemPersonType);
                    }

                });

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.controller.NHSPSystemAdminController#viewNHSPSystem(java.lang.Long, org.springframework.ui.ModelMap)}
     * .
     * @throws Exception on error
     */
    @Test
    public final void testViewNHSPSystemNoResults() throws Exception {
        for (NHSPSystem system : nhspSystemService.findAll()) {
            nhspSystemService.delete(system);
        }
        RequestBuilder builder = MockMvcRequestBuilders.get(
                "/admin/system/view/1").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));
        mockMvc.perform(builder).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.view().name("system-results"))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult result) throws Exception {
                        String message = (String) result.getModelAndView()
                                .getModel().get("warnMessage");
                        assertNotNull(message);
                        assertEquals(
                                "There are no NHSP Systems available for editing.",
                                message);
                    }

                });

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.controller.NHSPSystemAdminController#viewNewNHSPSystem(org.springframework.ui.ModelMap)}
     * .
     * @throws Exception on error
     */
    @Test
    public final void testViewNewNHSPSystem() throws Exception {
        RequestBuilder builder = MockMvcRequestBuilders.get(
                "/admin/system/view").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));
        mockMvc.perform(builder).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.view().name("system-new"))
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult result) throws Exception {
                        NHSPSystem system = (NHSPSystem) result
                                .getModelAndView().getModel().get("nhspSystem");
                        assertNotNull(system);
                        assertEquals(null, system.getId());
                        List<PersonType> personTypes = (List<PersonType>) result
                                .getModelAndView().getModel()
                                .get("personTypes");
                        assertNotNull(personTypes);
                        assertEquals(11, personTypes.size());
                        Boolean newSystem = (Boolean) result.getModelAndView()
                                .getModel().get("newSystem");
                        assertNotNull(newSystem);
                        assertEquals(Boolean.TRUE, newSystem);
                    }

                });
    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.controller.NHSPSystemAdminController#saveNewNHSPSystem(uk.nhs.nhsprotect.cpod.model.NHSPSystem, org.springframework.ui.ModelMap)}
     * .
     * @throws Exception on error
     */
    @Test
    public final void testSaveNewNHSPSystem() throws Exception {
        RequestBuilder builder = MockMvcRequestBuilders
                .post("/admin/system/save")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("name", "NEW+SYSTEM").param("personTypes", "2", "3")
                .param("_personTypes", "1").param("selectedStatus", "Y");
        mockMvc.perform(builder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.view().name(
                                "redirect:/admin/system/search"));

    }
    
    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.controller.NHSPSystemAdminController#saveNewNHSPSystem(uk.nhs.nhsprotect.cpod.model.NHSPSystem, org.springframework.ui.ModelMap)}
     * .
     * @throws Exception on error
     */
    @Test
    public final void testSaveNewNHSPSystemDuplicate() throws Exception {
        RequestBuilder builder = MockMvcRequestBuilders
                .post("/admin/system/save")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("name", "SRT").param("personTypes", "4", "5")
                .param("_personTypes", "1").param("selectedStatus", "Y");
        mockMvc.perform(builder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.view().name(
                                "redirect:/admin/system/search"));

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.controller.NHSPSystemAdminController#editSystemPersonType(uk.nhs.nhsprotect.cpod.model.SystemPersonType)}
     * .
     * @throws Exception on error
     */
    @Test
    public final void testEditSystemPersonTypeNew() throws Exception {

        RequestBuilder builder = MockMvcRequestBuilders
                .post("/admin/system/personType/edit")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("system.id", "1")
                .param("system.name", "NEW+SYSTEM").param("personType.id", "5")
                .param("status", "P").param("id", "");
        mockMvc.perform(builder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.content().string(
                                "Person Type Edited"));

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.controller.NHSPSystemAdminController#editSystemPersonType(uk.nhs.nhsprotect.cpod.model.SystemPersonType)}
     * .
     * @throws Exception on error
     */
    @Test
    public final void testEditSystemPersonType() throws Exception {
        RequestBuilder builder = MockMvcRequestBuilders
                .post("/admin/system/personType/edit")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("system.id", "1")
                .param("system.name", "NEW+SYSTEM").param("personType.id", "4")
                .param("status", "P").param("id", "1");
        mockMvc.perform(builder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.content().string(
                                "Person Type Edited"));

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.controller.NHSPSystemAdminController#deleteSystemPersonType(uk.nhs.nhsprotect.cpod.model.SystemPersonType)}
     * .
     * @throws Exception on error
     */
    @Test
    public final void testDeleteSystemPersonType() throws Exception {
        RequestBuilder builder = MockMvcRequestBuilders
                .post("/admin/system/personType/delete")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("system.id", "1")
                .param("system.name", "NEW+SYSTEM").param("personType.id", "4")
                .param("status", "P").param("id", "1");
        mockMvc.perform(builder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.content().string(
                                "Person Type deleted"));
    }

}
