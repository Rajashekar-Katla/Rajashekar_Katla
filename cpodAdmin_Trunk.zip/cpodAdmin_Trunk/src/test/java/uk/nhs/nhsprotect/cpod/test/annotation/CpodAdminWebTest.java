package uk.nhs.nhsprotect.cpod.test.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

/**
 * Custom Annotation for CPOD Admin web tests.
 * 
 * @see http 
 *      ://java.dzone.com/articles/avoid-spring-annotation-code-smell-use-spring3
 *      -custom-annotations
 * @author ntones
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@WebAppConfiguration(value = "src/main/webapp")
@ContextConfiguration(locations = { "classpath:spring/applicationContext.xml",
		"classpath:spring/hibernateContext.xml",
		"file:src/main/webapp/WEB-INF/spring/spring-servlet.xml",
		"file:src/main/webapp/WEB-INF/spring/spring-security.xml",
		"file:src/main/webapp/WEB-INF/spring/spring-tiles.xml" })
@ActiveProfiles("junit")
@Transactional
@TransactionConfiguration(defaultRollback = true)
public @interface CpodAdminWebTest {

}
