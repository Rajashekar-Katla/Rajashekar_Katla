package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.service.SrtUserService;
import uk.nhs.nhsprotect.cpod.test.utils.SystemUserUtil;
import uk.nhs.nhsprotect.srt.model.SrtUser;

/**
 * Class to test SrtAbstractServiceImpl methods.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/applicationContext.xml",
        "classpath:spring/hibernateContext.xml" })
@ActiveProfiles("junit")
@TransactionConfiguration(transactionManager = "srtTransactionManager")
@Transactional
public class SrtAbstractServiceImplTest {

    /**
     * SirsUserService reference.
     */
    @Autowired
    private SrtUserService srtUserService;

    @Autowired
    private SessionFactory srtSessionFactory;

    /**
     * User ID for user created in SrtSetup script (2338).
     */
    private final Long lsms0134userId = Long.valueOf(2338L);

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#save(java.lang.Object)}
     * .
     * @throws Exception omn error
     */
    @Test
    public void testSave() throws Exception {
        SrtUser srtUser = new SrtUser("newUser", "pass123", true);
        srtUser.setUserAuthorities(SystemUserUtil
                .getSRTLSMSUserAuthorities(srtUser));
        srtUserService.save(srtUser);
        Assert.assertNotNull(srtUser.getId());
        assertEquals(3, srtUserService.findAll().size());

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#delete(java.lang.Object)}
     * .
     * @throws Exception on error
     */
    @Test
    public void testDelete() throws Exception {
        SrtUser toDelete = SystemUserUtil.getSRTLSMSUser("lsms0138");
        srtUserService.delete(toDelete);
        assertEquals(1, srtUserService.findAll().size());

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#findAll()}
     * .
     * @throws Exception on error
     */
    @Test
    public void testFindAll() throws Exception {
        assertEquals(2, srtUserService.findAll().size());

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#deleteAll()}
     * .
     * @throws Exception on error
     */
    @Test(expected = CpodException.class)
    public void testDeleteAll() throws Exception {
        srtUserService.deleteAll();

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#saveOrUpdate(java.lang.Object)}
     * .
     * @throws Exception on error
     */
    @Test
    public void testSaveOrUpdateAsUpdate() throws Exception {
        SrtUser existing = srtUserService.findById(lsms0134userId);
        existing.setFailedAttempts(3);
        srtUserService.saveOrUpdate(existing);
        srtSessionFactory.getCurrentSession().flush();
        SrtUser updated = srtUserService.findById(lsms0134userId);
        assertEquals(existing.getFailedAttempts(), updated.getFailedAttempts());

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#findById(java.io.Serializable)}
     * .
     * @throws Exception
     */
    @Test
    public void testFindById() throws Exception {
        SrtUser expected = SystemUserUtil.getSRTLSMSUser("lsms0134");
        SrtUser actual = srtUserService.findById(lsms0134userId);
        assertEquals(expected, actual);

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#update(java.lang.Object)}
     * .
     * @throws Exception
     */
    @Test
    public void testUpdate() throws Exception {
        SrtUser actual = srtUserService.findById(lsms0134userId);
        actual.setUsername("UPDATED");
        srtUserService.update(actual);
        assertEquals(actual, srtUserService.findById(lsms0134userId));

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#findByCriteria(org.hibernate.criterion.Criterion)}
     * .
     * @throws Exception
     */
    @Test
    public void testFindByCriteria() throws Exception {
        List<SrtUser> actual = srtUserService.findByCriteria(Restrictions
                .ilike("username", "lsms", MatchMode.START));
        assertEquals(2, actual.size());

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#findByAndCriterias(java.util.Map)}
     * .
     */
    @Test
    public void testFindByAndCriterias() {
        Map<String, String> searchCriteria = new HashMap<String, String>();
        searchCriteria.put("username", "lsms");
        searchCriteria.put("password", "pass123");
        searchCriteria.put("personId", "4");
        List<SrtUser> actual = srtUserService
                .findByAndCriterias(searchCriteria);
        assertEquals(1, actual.size());// lsms0138 matches

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SrtAbstractServiceImpl#merge(java.lang.Object)}
     * .
     * @throws Exception
     */
    @Test
    public void testMerge() throws Exception {
        SrtUser actual = srtUserService.findById(lsms0134userId);
        actual.setUsername("UPDATED");
        srtUserService.merge(actual);
        assertEquals(actual, srtUserService.findById(lsms0134userId));

    }

}
