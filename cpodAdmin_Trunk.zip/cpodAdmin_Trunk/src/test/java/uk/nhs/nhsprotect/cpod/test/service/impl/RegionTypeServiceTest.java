package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.model.RegionType;
import uk.nhs.nhsprotect.cpod.service.RegionTypeService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;

/**
 * @author awheatley
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class RegionTypeServiceTest {

    /**
     * Gives access to RegionTypeService.
     */
    @Autowired
    private RegionTypeService regionTypeService;

    /**
     * Gives access to Organisation Class.
     */
    @SuppressWarnings("unused")
    private RegionType regionType;

    /**
     * Setup for each test that runs.
     * @throws Exception for error
     */
    @Before
    public void setUp() throws Exception {

    }

    /**
     * Teardown of data after tests complete.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws Exception {

    }

    /**
     * Find organisation based on org_code = "5F8".
     * @throws Exception for error
     */
    @Test
    public void testFindRegionTypeByType() throws Exception {

        // find record
        RegionType found = regionTypeService.findRegionTypeByType("B Type");

        // create expected instance
        RegionType expected = new RegionType();
        expected.setId(2L);
        expected.setRegionType("B Type");

        // compare results
        assertEquals(found, expected);

    }

    /**
     * Find non Region Type. CpodNoResultsReturnedException should be thrown.
     * @throws Exception for error
     */
    @Test(expected = CpodNoResultsReturnedException.class)
    public void testFindRegionTypeByNonTypes() throws Exception {

        @SuppressWarnings("unused")
        RegionType found = regionTypeService.findRegionTypeByType("XXX");
    }

    /**
     * Find multiple records for RegionType. Exception CpodNonUniqueException
     * should be thrown
     * @throws Exception on error
     */
    @Test(expected = CpodNonUniqueException.class)
    public void testFindRegionMultipleResultsByRegionType() throws Exception {

        // Change Region Type of HOME to WORK, so two records exist with same
        // Region Type.
        RegionType existing = regionTypeService.findRegionTypeByType("A Type");
        existing.setRegionType("B Type");
        regionTypeService.saveOrUpdate(existing);

        @SuppressWarnings("unused")
        RegionType found = regionTypeService.findRegionTypeByType("B Type");
    }

}
