/**
 * 
 */
package uk.nhs.nhsprotect.cpod.test.utils;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Trivial class to allow a hash to be generated using the BCrypt password
 * encoder implementation.
 * @see http 
 *      ://stackoverflow.com/questions/8521251/spring-securitypassword-encoding
 *      -in-db-and-in-applicationconext/8528804#8528804
 * @see http://www.mindrot.org/projects/jBCrypt/
 * @author ntones
 */
public class PasswordHashGenerator {

    /**
     * @param args
     */
    public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext(
                "classpath:spring/applicationContext.xml",
                "classpath:spring/hibernateContext.xml");
        PasswordEncoder hashGenerator = (PasswordEncoder) context
                .getBean("passwordEncoder");

        // the plain text value to be hashed
        String plainText = "P@ssw0rd1!";
        String encrpytOnce = hashGenerator.encode(plainText);
        boolean decrypts = hashGenerator.matches(plainText, encrpytOnce);

        System.out.println("Entered plain text [" + plainText
                + "] which is encrypted to [" + encrpytOnce
                + "] - can this be decrypted? [" + decrypts
                + "] \n If we encrypt again we get a different value every time for the same plain text!!! ["
                + hashGenerator.encode(plainText) + "]");

    }

}
