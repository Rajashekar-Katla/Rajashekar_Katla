package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.PersonNote;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.service.PersonService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;
import uk.nhs.nhsprotect.cpod.test.utils.PersonUtils;

import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * @author awheatley Class to test the methods offered by the Person Service
 *         interface.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class PersonServiceTest {

    /**
     * Gives access to person service.
     */
    @Autowired
    private PersonService personService;

    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Gives access to person.
     */
    private Person person;

    /**
     * Sets up environment for testing.
     * @throws Exception for errors
     */
    @Before
    public void setUp() throws Exception {
        tearDown();
        person = PersonUtils.createPersonSteveJobs();
        personService.save(person);
    }

    /**
     * Tears down data from testing.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws Exception {
        if (person != null) {
            personService.delete(person);
        }

    }

    /**
     * Checks one record is returned by PersonRef.
     * @throws Exception to catch DateUtils.parseDate
     */
    @Test
    public void testFindPersonsById() throws Exception {

        Person found = personService.findById(1l);
        assertEquals((Long) 1l, found.getId());

    }

    @Test
    public void testFindPersonByPersonRef() throws Exception {

        Person found = personService.findPersonByRef("lsms0246");
        assertEquals(1, found.getPersonRoles().size());
        for (PersonRole personRole : found.getPersonRoles()) {
            assertEquals(CPODConstants.PERSON_TYPE_LSMS_DESC, personRole
                    .getPersonType().getDescription());
        }

        assertEquals((Long) 1l, found.getId());

    }

    /**
     * Tests Exception thrown when no records found by PersonRef.
     * @throws Exception when no records found.
     */
    @Test(expected = CpodNoResultsReturnedException.class)
    public void testFindPersonsByRefWithNoResults() throws Exception {
        Person found = personService.findPersonByRef("XXXXX");

        assertEquals((Long) 1l, found.getId());
    }

    /**
     * Tests null conditions
     */
    @Test
    public void testPersonNulls() {
        Person nullPerson = new Person();
        // Test Setters using null
        nullPerson.setSecurityDate(null);
        nullPerson.setProprietryDate(null);
        nullPerson.setFraudDate(null);
        nullPerson.setDob(null);

        // Get results expecting null
        assertEquals(null, nullPerson.getSecurityDate());
        assertEquals(null, nullPerson.getProprietryDate());
        assertEquals(null, nullPerson.getFraudDate());
        assertEquals(null, nullPerson.getDob());

    }

    /**
     * Test constructor that accepts person ID only
     */
    @Test
    public void testConstructorId() {
        Person constructor = new Person(1l);
        assertEquals(Long.valueOf(1), constructor.getId());
    }

    /**
     * Tests if person has responsibility
     * @throws CpodException if no person found
     */
    @Test
    public void testIsResponsibleType() throws CpodException {
        Person found = personService.findById(1l);
        assertEquals(true, found.isResponsibleType());
    }

    /**
     * Tests if person is NHSPStaff
     * @throws CpodException if no person found
     */
    @Test
    public void testIsNHSPStaff() throws CpodException {
        Person found = personService.findById(1l);
        assertEquals(false, found.isNHSPStaff());
    }

    /**
     * Adds a second record and test that two records are returned. matching the
     * personRef
     * @throws Exception for errors
     */
    @Test
    public void testFindPersons() throws Exception {
        // insert a duplicate person
        this.personService.save(PersonUtils.createPersonBillGates());

        // 2 x steve jobs created and 5 persons in setup.sql
        List<Person> persons = personService.findAll();
        assertEquals(7, persons.size());

    }

    /**
     * Tests PersonNotesByPersonId.
     * @throws Exception for error
     */
    @Test
    public void testFindPersonNotesByPersonId() throws Exception {

        List<PersonNote> personNote;
        Person person = personService.findById(1l);
        personNote = person.getPersonNotes();
        assertEquals(1, personNote.size());
        assertEquals("Some Data", personNote.get(0).getNote());
    }

    /*
     * SIRS USER Roles and Administration Tests
     */
    @Test
    public void testAssignLSMSRoleExistingPerson() throws Exception {
        Person found = personService.findPersonByRef("lsms0657");
        assertEquals(1, found.getPersonRoles().size());
        for (PersonRole personRole : found.getPersonRoles()) {
            assertEquals(CPODConstants.PERSON_TYPE_LSMS_DESC, personRole
                    .getPersonType().getDescription());
            boolean active = personRole.getEndDate().after(new Date());
            assertEquals(false, active);
            String status = found.getStatus();
            assertEquals("N", status);
            // sett the role in PersonRole and teh status to Y in the person
            // table
            personRole.setEndDate(new SimpleDateFormat("yyyyMMdd")
                    .parse("99990520"));
            found.setStatus("Y");
            // save/update the person and the role
            personService.saveOrUpdate(found);
            // assert true
            active = personRole.getEndDate().after(new Date());
            assertEquals(true, active);
            status = found.getStatus();
            assertEquals("Y", status);
        }
        assertEquals((Long) 4l, found.getId());
    }

    @Test(expected = CpodNoResultsReturnedException.class)
    public void testAssignLSMSRoleNonExistingPerson() throws Exception {
        personService.findPersonByRef("lsms069");
    }

}
