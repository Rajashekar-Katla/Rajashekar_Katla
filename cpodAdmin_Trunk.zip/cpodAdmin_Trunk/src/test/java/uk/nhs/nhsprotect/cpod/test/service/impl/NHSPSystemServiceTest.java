package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.model.NHSPSystem;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.model.SystemPersonType;
import uk.nhs.nhsprotect.cpod.service.NHSPSystemService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;

/**
 * Test class for the SystemService interface implementation.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class NHSPSystemServiceTest {

    /**
     * Gives access to SystemService.
     */

    @Autowired
    private NHSPSystemService nhspSystemService;

    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Tests findsFindSystemByID
     * @throws Exception for error
     */
    @Test
    public void testFindNHSPSystemByID() throws Exception {

        NHSPSystem nhspSystem = nhspSystemService.findById(1l);
        assertEquals("SRT", nhspSystem.getName());
        assertEquals(2, nhspSystem.getSystemPersonTypes().size());
    }

    /**
     * Tests addNewSystesm
     * @throws Exception for error
     */
    @Test
    public void addNewNHSPSystem() throws Exception {

        NHSPSystem system = new NHSPSystem();
        system.setName("FUTURE");

        // test adding person types
        SystemPersonType personTypeLCFS = new SystemPersonType();
        personTypeLCFS.setPersonType(new PersonType(4l, "LCFS"));
        personTypeLCFS.setStatus("A");
        system.addSystemPersonType(personTypeLCFS);
        SystemPersonType personTypeLSMS = new SystemPersonType();
        personTypeLSMS.setPersonType(new PersonType(5l, "LSMS"));
        personTypeLSMS.setStatus("A");
        system.addSystemPersonType(personTypeLSMS);

        nhspSystemService.saveOrUpdate(system);
        sessionFactory.getCurrentSession().flush();

        Assert.assertNotNull("ID should be populated after saveOrUpdate",
                system.getId());
        assertEquals(2, system.getSystemPersonTypes().size());

        // test removing person types
        system.removeSystemPersonType(personTypeLSMS);
        nhspSystemService.saveOrUpdate(system);
        sessionFactory.getCurrentSession().flush();

        assertEquals(1, system.getSystemPersonTypes().size());

    }
}
