package uk.nhs.nhsprotect.cpod.test.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.controller.AddressLookupController;
import uk.nhs.nhsprotect.cpod.controller.dto.Address;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ TypeFactory.class, CollectionType.class })
public class AddressLookupControllerTest {

    private MockMvc mockMvc;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    ObjectMapper objectMapper;

    private final String result = "[{\"addressLine1\":\"MEADOWBANK\",\"addressLine2\":\"CULLIVOE\","
            + "\"addressLine3\":null,\"addressLine4\":null,\"addressLine5\":null,\"addressLine6\":null,\"postCode\":\"ZE2 9DD\","
            + "\"district\":null,\"organisation\":null}]";

    private ResponseEntity<Object> entity;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Before
    public void setUp() {
        entity = new ResponseEntity<Object>(result, HttpStatus.OK);
        mockMvc = MockMvcBuilders
                .standaloneSetup(
                        new AddressLookupController(restTemplate, objectMapper,
                                entity)).build();
    }

    @Test
    public void testALSRestCall() throws Exception {
        final TypeFactory typeFactory = PowerMockito.mock(TypeFactory.class);
        final CollectionType collectionType = PowerMockito
                .mock(CollectionType.class);
        when(objectMapper.readValue(anyString(), any(JavaType.class)))
                .thenReturn(getAddressList());
        when(objectMapper.getTypeFactory()).thenReturn(typeFactory);
        when(
                typeFactory.constructCollectionType(
                        Mockito.<Class<? extends Collection<String>>> any(),
                        Mockito.<Class<Object>> any())).thenReturn(
                collectionType);
        when(
                restTemplate.exchange(anyString(),
                        Mockito.<HttpMethod> eq(HttpMethod.GET),
                        Mockito.<HttpEntity<String>> any(),
                        Mockito.<Class<Object>> any(), anyString()))
                .thenReturn(entity);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/lookupAddress").param("postCode", "ZE2 9DD")
                .param("addressLine1", "MEADOWBANK")
                .param("addressLine2", "null").param("addressLine3", "null")
                .param("addressLine4", "null").param("addressLine5", "null")
                .param("addressLine6", "null");
        MvcResult mvcResult = mockMvc
                .perform(requestBuilder)
                .andExpect(status().isOk())
                .andExpect(
                        content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].addressLine1", is("MEADOWBANK")))
                .andExpect(jsonPath("$[0].addressLine2", is("CULLIVOE")))
                .andExpect(jsonPath("$[0].addressLine3", is(nullValue())))
                .andExpect(jsonPath("$[0].addressLine4", is(nullValue())))
                .andExpect(jsonPath("$[0].addressLine5", is(nullValue())))
                .andExpect(jsonPath("$[0].addressLine6", is(nullValue())))
                .andExpect(jsonPath("$[0].postCode", is("ZE2 9DD")))
                .andDo(print()).andReturn();

        assertThat(mvcResult.getResponse().getContentAsString(),
                equalTo(result));

        verify(typeFactory).constructCollectionType(
                Mockito.<Class<? extends Collection<String>>> any(),
                Mockito.<Class<Object>> any());

        verify(restTemplate).exchange(anyString(),
                Mockito.<HttpMethod> eq(HttpMethod.GET),
                Mockito.<HttpEntity<String>> any(),
                Mockito.<Class<Object>> any(), anyString());

        verify(objectMapper).readValue(anyString(), any(JavaType.class));
    }

    private List<Address> getAddressList() throws JsonParseException,
            JsonMappingException, IOException {
        final ObjectMapper objectMapper = new ObjectMapper();
        List<Address> addressList = objectMapper.readValue(
                result,
                objectMapper.getTypeFactory().constructCollectionType(
                        List.class, Address.class));
        return addressList;
    }

}
