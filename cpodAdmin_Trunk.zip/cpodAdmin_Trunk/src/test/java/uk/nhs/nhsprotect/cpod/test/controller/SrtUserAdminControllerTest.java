package uk.nhs.nhsprotect.cpod.test.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.service.ResponsibilityService;
import uk.nhs.nhsprotect.cpod.service.SirsUserService;
import uk.nhs.nhsprotect.cpod.test.utils.SecurityRequestPostProcessors;
import uk.nhs.nhsprotect.srt.model.SrtUser;

/**
 * Test class to exercise the SrtUserAdminController.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration(value = "src/main/webapp")
@ContextConfiguration(locations = { "classpath:spring/applicationContext.xml",
        "classpath:spring/hibernateContext.xml",
        "file:src/main/webapp/WEB-INF/spring/spring-servlet.xml",
        "file:src/main/webapp/WEB-INF/spring/spring-tiles.xml",
        "file:src/main/webapp/WEB-INF/spring/spring-security.xml" })
@ActiveProfiles("junit")
@Transactional()
public class SrtUserAdminControllerTest {

    /**
     * The web application context as managed by Spring.
     */
    @Autowired
    private WebApplicationContext wac;

    /**
     * The Spring Security filter that intercepts application URLs.
     */
    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    /**
     * reference to responsibility service.
     */
    @Autowired
    private ResponsibilityService responsibilityService;

    /**
     * reference to SirsUserService service.
     */
    @Autowired
    private SirsUserService sirsUserService;

    /**
     * The message source used within the app.
     */
    @Autowired
    private MessageSource messageSource;

    /**
     * The mocked SpringMVC application instance.
     */
    private MockMvc mockMvc;

    /**
     * The non-admin user to use for testing with.
     */
    private final String user = "lsms0246";

    /**
     * The admin user to use for testing.
     */
    private final String adminUser = "lcfs1538";

    /**
     * Method to run before all test methods to create test environment.
     */
    @Before
    public void setup() {

        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
                .addFilters(this.springSecurityFilterChain).build();
    }

    /**
     * Test method to ensure users without ISD admin or SRT admin roles cannot
     * access method.
     * @throws Exception on error
     */
    @Test
    public void testSrtAdminMethodsNonAdminAccess() throws Exception {

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/admin/srt/users").with(
                SecurityRequestPostProcessors.userDetailsService(user));
        this.mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isForbidden());

    }

    /**
     * Test the view srt users method.
     * @throws Exception
     */
    @Test
    public void testSrtUsers() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/admin/srt/users").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));

        this.mockMvc
                .perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.view().name("srt-user-results"));

    }

    /**
     * Test create new SRT user controller test.
     * @throws Exception on error
     */
    @Test
    public void createNewSrtUserTest() throws Exception {

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/admin/srt/user").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));
        this.mockMvc
                .perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult result) throws Exception {
                        assertNotNull(result.getModelAndView().getModelMap()
                                .get("srtUser"));
                        assertNotNull(result.getModelAndView().getModelMap()
                                .get("mode"));
                        assertEquals("Create New", (String) result
                                .getModelAndView().getModelMap().get("mode"));
                        assertNotNull(result.getModelAndView().getModelMap()
                                .get("srtAuthorities"));
                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("srt-user-view"));

    }

    /**
     * Test view SRT user controller test.
     * @throws Exception on error
     */
    @Test
    public void viewSrtUserTest() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/admin/srt/user/2338").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));

        this.mockMvc
                .perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult result) throws Exception {
                        assertNotNull(result.getModelAndView().getModelMap()
                                .get("srtUser"));
                        assertEquals(Long.valueOf(2338L),
                                ((SrtUser) result.getModelAndView()
                                        .getModelMap().get("srtUser")).getId());
                        assertNotNull(result.getModelAndView().getModelMap()
                                .get("mode"));
                        assertEquals("Edit", (String) result.getModelAndView()
                                .getModelMap().get("mode"));
                        assertNotNull(result.getModelAndView().getModelMap()
                                .get("srtAuthorities"));
                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("srt-user-view"));
    }

    /**
     * Test update SRT user controller test.
     * @throws Exception on error
     */
    @Test
    public void updateSrtUserStatusTest() throws Exception {

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/admin/srt/updateUserStatus")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("id", "2338")
                .param("userStatus", "false");

        this.mockMvc
                .perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.content().string(
                                "SRT User [lsms0134] status updated."));

    }

    /**
     * Test delete SRT user controller test.
     * @throws Exception on error
     */
    @Test
    public void deleteSrtUserTest() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/admin/srt/deleteSrtUser")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("deleteUserId", "2338");

        this.mockMvc
                .perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.content().string(
                                "SRT User [2338] deleted."));

    }

    /**
     * Test saveOrUpdate SRT user controller test.
     * @throws Exception on error
     */
    @Test
    public void saveOrUpdateSrtUserTest() throws Exception {

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/admin/srt/user")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("username", "lsms9999").param("personId", "2")
                .param("password", "").param("enabled", "true")
                .param("authorities", "2");

        // save the instance ...
        MvcResult result = this.mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isMovedTemporarily())
                .andReturn();

        MockHttpServletResponse response = result.getResponse();

        String location = response.getHeader("Location");

        assertTrue("URL does not match expected [/admin/srt/user/xxxx] was ["
                + location + "]",
                StringUtils.contains(location, "/admin/srt/user/"));

    }
}
