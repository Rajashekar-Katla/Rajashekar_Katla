package uk.nhs.nhsprotect.cpod.test.utils;

import java.util.ArrayList;
import java.util.List;

import uk.nhs.nhsprotect.sirs.model.SirsAuthority;
import uk.nhs.nhsprotect.sirs.model.SirsUser;
import uk.nhs.nhsprotect.sirs.model.SirsUserAuthorities;
import uk.nhs.nhsprotect.srt.model.SrtAuthority;
import uk.nhs.nhsprotect.srt.model.SrtUser;
import uk.nhs.nhsprotect.srt.model.SrtUserAuthorities;

/**
 * Class to hold methods to support testing of system user functions.
 * @author ntones
 */
public final class SystemUserUtil {

    /**
     * private default constructor. Class cannot be initialised.
     */
    private SystemUserUtil() {
        // private default constructor
    }

    /**
     * Creates a class representing Sirs User sirsUser created in sirsSetup.sql.
     * @param username of user to create
     * @return SirsUser sirsUser
     */
    public static SirsUser getSIRSLSMSUser(final String username) {
        SirsUser sirsUser = generateNewDefaultSirsUser(username);

        // create the authorities for the user

        sirsUser.setAuthorities(getSIRSLSMSUserAuthorities(sirsUser));

        return sirsUser;
    }

    /**
     * Creates a SirsUserAuthorities list with LSMS role granted.
     * @param user to assign authority to
     * @return List<SirsUserAuthorities> with LSMS role
     */
    public static List<SirsUserAuthorities> getSIRSLSMSUserAuthorities(
            final SirsUser user) {

        // create the authorities for the user
        List<SirsUserAuthorities> authorities = new ArrayList<SirsUserAuthorities>();
        SirsUserAuthorities userAuthorities = new SirsUserAuthorities(user,
                getSIRSLSMSAuthority());
        userAuthorities.setId(Long.valueOf(user.getPersonId()));
        authorities.add(userAuthorities);

        return authorities;
    }

    /**
     * Creates a SrtUserAuthorities list with LSMS role granted.
     * @param user to add authority to
     * @return List<SrtUserAuthorities> with LSMS role
     */
    public static List<SrtUserAuthorities> getSRTLSMSUserAuthorities(
            final SrtUser user) {

        // create the authorities for the user
        List<SrtUserAuthorities> authorities = new ArrayList<SrtUserAuthorities>();
        SrtUserAuthorities userAuthorities = new SrtUserAuthorities(user,
                getSRTLSMSAuthority());
        if (user.getPersonId() != null) {
            userAuthorities.setId(Long.valueOf(user.getPersonId()));
        }
        authorities.add(userAuthorities);

        return authorities;
    }

    /**
     * Creates a SirsAuthority for LSMS role.
     * @return SirsAuthority LSMS
     */
    public static SirsAuthority getSIRSLSMSAuthority() {
        SirsAuthority grantedAuthority = new SirsAuthority();
        grantedAuthority.setAuthorityID(Long.valueOf(1));
        grantedAuthority.setAuthorityDescription("LSMS User");
        grantedAuthority.setAuthorityName("ROLE_LSMS");
        return grantedAuthority;
    }

    /**
     * Creates a SirsAuthority for LSMS role.
     * @return SirsAuthority LSMS
     */
    public static SrtAuthority getSRTLSMSAuthority() {
        SrtAuthority grantedAuthority = new SrtAuthority();
        grantedAuthority.setId(Long.valueOf(1));
        grantedAuthority.setAuthority("ROLE_LSMS");
        grantedAuthority.setAuthorityDescription("LSMS");
        return grantedAuthority;
    }

    /**
     * Creates a SirsUser LSMS instance with the desired username.
     * @param username to create
     * @return SirsUser
     */
    private static SirsUser generateNewDefaultSirsUser(final String username) {
        SirsUser sirsUser = new SirsUser();
        sirsUser.setUsername(username);
        sirsUser.setActivePassword(1);
        sirsUser.setPassword("657f8b8da628ef83cf69101b6817150a");
        sirsUser.setEnabled(1);
        sirsUser.setFailedAttempts(0);
        sirsUser.setPersonId(Long.valueOf(1L));
        return sirsUser;
    }

    /**
     * Creates a class representing Srt LSMS User sirsUser created in
     * srtSetup.sql.
     * @param username of user to create
     * @return SrtUser
     */
    public static SrtUser getSRTLSMSUser(final String username) {
        SrtUser srtUser = generateNewSRTLSMS(username);
        srtUser.setPersonId(Long.valueOf(1L));
        srtUser.setId(Long.valueOf(2338L));

        // create the authorities for the user

        srtUser.setUserAuthorities(getSRTLSMSUserAuthorities(srtUser));

        return srtUser;

    }

    /**
     * Creates a SrtUser LSMS instance with the desired username.
     * @param username of user to create
     * @return SrtUser
     */
    private static SrtUser generateNewSRTLSMS(final String username) {
        SrtUser srtUser = new SrtUser();
        srtUser.setUsername(username);
        srtUser.setDefaultPasswordChanged(true);
        srtUser.setEnabled(true);
        srtUser.setFailedAttempts(0);
        srtUser.setPersonId(Long.valueOf(1L));
        srtUser.setPassword("pass123");
        return srtUser;
    }
}
