package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.service.SirsUserService;
import uk.nhs.nhsprotect.cpod.test.utils.SystemUserUtil;
import uk.nhs.nhsprotect.sirs.model.SirsUser;
import uk.nhs.nhsprotect.sirs.model.SirsUserAuthorities;

/**
 * Methods to test the SIRS User Service.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/applicationContext.xml",
        "classpath:spring/hibernateContext.xml" })
@ActiveProfiles("junit")
@TransactionConfiguration(transactionManager = "sirsTransactionManager", defaultRollback = true)
@Transactional
public class SirsUserServiceImplTest {

    @Autowired
    SirsUserService sirsUserService;

    /**
     * Reference Number for user created in SirsSetup script.
     */
    private final String referenceNumber = "lsms0246";

    /**
     * Test the findByReferenceNumber method.
     * @throws Exception on error
     */
    @Test
    public void testFindByReferenceNumber() throws Exception {
        SirsUser actual = sirsUserService
                .findByReferenceNumber(referenceNumber);
        List<SirsUserAuthorities> actualAuthorities = actual.getAuthorities();

        assertEquals(SystemUserUtil.getSIRSLSMSUser(referenceNumber), actual);
        assertEquals(SystemUserUtil.getSIRSLSMSUser(referenceNumber)
                .getAuthorities().size(), actualAuthorities.size());

    }

    /**
     * Test the deleteByUserName method.
     * @throws Exception on error
     */
    @Test
    public void testDeleteByUserName() throws Exception {
        SirsUser expected = null;
        sirsUserService.deleteByUserName(referenceNumber);
        SirsUser actual = sirsUserService
                .findByReferenceNumber(referenceNumber);
        assertEquals(expected, actual);

    }
}
