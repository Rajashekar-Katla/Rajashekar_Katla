package uk.nhs.nhsprotect.cpod.test.utils;

import uk.nhs.nhsprotect.cpod.model.Organisation;
import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.PersonType;

/**
 * @author awheatley
 */
public final class PersonUtils {

    /**
     * Default Constructor. Can't instantiate class
     */
    private PersonUtils() {
    }

    /**
     * ESR ID Number.
     */
    private static final Long ESRID45676 = 4567L;

    /**
     * MODIFIEDBYUSER9999 ID.
     */
    private static final String MODIFIEDBYUSER9999 = "JUNIT";

    /**
     * Person Type LCFS.
     */
    private static final PersonType PERSON_TYPE_LCFS = new PersonType(1L,
            "LCFS");

    // /**
    // * Creates a Manager as type Person.
    // * @return Manager (Person)
    // * @throws Exception
    // */
    // public static Person createMANAGER9() throws Exception {
    //
    //
    // Organisation organisation = organisationService.findById(5448l);
    // Person manager = personService.findById(1l);
    //
    //
    // return new Person(organisation, ESRID45676, "lcfs1234",
    // PERSON_TYPE_LCFS, "Mr",
    // "Peter", "", "Parker", "Spiderman",
    // DateUtils.parseDate("01/02/1950"), "Crime Fighter",
    // MODIFIEDBYUSER9999, "A", "New Person", manager,
    // "spiderman@nhs.com", "spiderman@apple.com", "0191 123 123",
    // "0191 321 321", "4566", "0191 444 4444", "07999 999999",
    // DateUtils.parseDate("01/02/1980"),
    // DateUtils.parseDate("01/02/9999"), "Y",
    // DateUtils.parseDate("01/02/1950"), "Y",
    // DateUtils.parseDate("01/02/1950"), "Y",
    // DateUtils.parseDate("01/02/1950"));
    //
    // }

    /**
     * Utility method to create Steve Jobs
     * @return Person Steve Jobs
     * @throws Exception to catch DateUtils.parseDate
     */
    public static Person createPersonSteveJobs() throws Exception {

        Organisation organisation = new Organisation();
        organisation.setId(5448L);

        return new Person(organisation, ESRID45676, "Mr", "Steve", "P", "Jobs",
                "Ste", DateUtils.parseDate("01/02/1950"),
                MODIFIEDBYUSER9999, "A", "steve.jobs@nhs.com",
                "steve.jobs@apple.com", "0191 123 123", "0191 321 321", "4566",
                "0191 444 4444", "07999 999999", Boolean.TRUE,
                DateUtils.parseDate("01/02/1950"), Boolean.TRUE,
                DateUtils.parseDate("01/02/1950"), Boolean.TRUE,
                DateUtils.parseDate("01/02/1950"));

    }

    /**
     * Utility method to create a person Bill Gates
     * @return Person Bill Gates
     * @throws Exception to catch DateUtils.parseDate
     */
    public static Person createPersonBillGates() throws Exception {
        Organisation organisation = new Organisation();
        organisation.setId(5448L);

        Person manager = new Person();
        manager.setId(2L);

        return new Person(organisation, ESRID45676, "Mr", "Steve", "P", "Jobs",
                "Ste", DateUtils.parseDate("01/02/1950"), 
                MODIFIEDBYUSER9999, "A", "steve.jobs@nhs.com",
                "steve.jobs@apple.com", "0191 123 123", "0191 321 321", "4566",
                "0191 444 4444", "07999 999999", Boolean.TRUE,
                DateUtils.parseDate("01/02/1950"), Boolean.TRUE,
                DateUtils.parseDate("01/02/1950"), Boolean.TRUE,
                DateUtils.parseDate("01/02/1950"));
    }

    /**
     * Method to create an LCFS PersonRole
     * @param id - the person ID role is assigned to
     * @return PersonRole (LCFS1234)
     * @throws Exception
     */
    public static PersonRole PersonRolelcfs1234(Long id) throws Exception {
 

        Person person = new Person();
        person.setId(id);

        PersonRole personRole = new PersonRole("lcfs1234", PERSON_TYPE_LCFS,
                "Alan", DateUtils.parseDate("01/02/1950"),
                DateUtils.parseDate("01/02/1950"));
        personRole.setPerson(person);
        return personRole;

    }
    
    /**
     * Method to create an LCFS PersonRole
     * @param id - the person ID role is assigned to
     * @return PersonRole (LCFS1234)
     * @throws Exception
     */
    public static PersonRole PersonRolelcfs4321(Long id) throws Exception {
 

        Person person = new Person();
        person.setId(id);

        PersonRole personRole = new PersonRole("lcfs4321", PERSON_TYPE_LCFS,
                "Fred", DateUtils.parseDate("01/02/1960"),
                DateUtils.parseDate("01/02/1970"));
        personRole.setPerson(person);
        return personRole;

    }
}
