package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import java.util.HashSet;

import org.apache.commons.beanutils.BeanUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.model.Address;
import uk.nhs.nhsprotect.cpod.model.AddressLink;
import uk.nhs.nhsprotect.cpod.model.Organisation;
import uk.nhs.nhsprotect.cpod.service.AddressService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;

/**
 * @author awheatley
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class AddressServiceTest {

    /**
     * Gives access to addressService.
     */
    @Autowired
    private AddressService addressService;

    /**
     * Tests findsAddressByCriteria for Address matching one record.
     * @throws Exception for error
     */
    @Test
    public void testFindAddressByCriteria() throws Exception {

        Address address = addressService.findById(1L);
        // create a new object to test equals method of Address class
        Address forComparison = new Address();
        BeanUtils.copyProperties(forComparison, address);

        Address actual = addressService.findAddressByCriteria(forComparison);

        // COMPARE to static object. Exercises equals method
        assertEquals(forComparison, actual);

    }

    /**
     * Tests findsAddressByCriteria for Address matching one record.
     * @throws Exception for error
     */
    @Test(expected = CpodNoResultsReturnedException.class)
    public void testFindAddressByCriteriaNoReults() throws Exception {

        Address address = addressService.findById(1L);
        // create a new object to test equals method of Address class
        Address forComparison = new Address();
        BeanUtils.copyProperties(forComparison, address);
        forComparison.setAddress1("XXXXX");

        @SuppressWarnings("unused")
        Address actual = addressService.findAddressByCriteria(forComparison);

        // fail if we get this far
        Assert.fail("CpodNoResultsReturnedException expected");

    }

    /**
     * Tests find AddressByCriteria for Address matching multiple records.
     * @throws Exception for error
     */
    @SuppressWarnings("unused")
    @Test(expected = CpodNonUniqueException.class)
    public void testFindAddressByCriteriaMultiple() throws Exception {

        Address address = addressService.findById(1L);
        // create a new object to test equals method of Address class
        Address forComparison = new Address();
        BeanUtils.copyProperties(forComparison, address);
        forComparison.setId(9999L);
        forComparison.setAddressLinks(new HashSet<AddressLink>());
        forComparison.setOrganisations(new HashSet<Organisation>());
        addressService.save(forComparison);

        Address actual = addressService.findAddressByCriteria(forComparison);

        // fail if we get this far
        Assert.fail("CpodNonUniqueException expected");

    }

}
