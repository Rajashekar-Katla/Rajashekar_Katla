package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.controller.dto.SystemUserDTO;
import uk.nhs.nhsprotect.cpod.service.SirsUserServiceRO;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;
import uk.nhs.nhsprotect.sirs.model.SirsUserRO;

import com.github.dandelion.datatables.core.ajax.DataSet;
import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;
import com.github.dandelion.datatables.core.constants.DTConstants;

/**
 * Methods to test the SIRS User Service Read Only.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class SirsUserROServiceImplTest {

    private MockHttpServletRequest request;

    @Autowired
    SirsUserServiceRO sirsUserServiceRO;

    @Before
    public void init() {
        request = new MockHttpServletRequest();
    }

    /**
     * Test the findSirsUsersWithDatatablesCriterias method. Uses default
     * criteria no sorting.
     * @throws Exception on error
     */
    @Test
    public void testFindSirsUsersWithDatatablesCriterias() throws Exception {
        request.addParameter(DTConstants.DT_S_ECHO, "1");
        request.addParameter(DTConstants.DT_I_COLUMNS, "4");
        request.addParameter(DTConstants.DT_I_DISPLAY_START, "0");
        request.addParameter(DTConstants.DT_I_DISPLAY_LENGTH, "10");
        request.addParameter(DTConstants.DT_M_DATA_PROP + 0, "username");
        request.addParameter(DTConstants.DT_B_SEARCHABLE + 0, "true");
        request.addParameter(DTConstants.DT_B_SORTABLE + 0, "true");
        request.addParameter(DTConstants.DT_M_DATA_PROP + 1, "fullname");
        request.addParameter(DTConstants.DT_B_SEARCHABLE + 1, "true");
        request.addParameter(DTConstants.DT_B_SORTABLE + 1, "true");
        request.addParameter(DTConstants.DT_M_DATA_PROP + 2, "status");
        request.addParameter(DTConstants.DT_B_SEARCHABLE + 2, "true");
        request.addParameter(DTConstants.DT_B_SORTABLE + 2, "true");
        request.addParameter(DTConstants.DT_M_DATA_PROP + 3, "3");
        request.addParameter(DTConstants.DT_B_SEARCHABLE + 3, "false");
        request.addParameter(DTConstants.DT_B_SORTABLE + 3, "false");

        DatatablesCriterias criterias = DatatablesCriterias
                .getFromRequest(request);
        DataSet<SystemUserDTO> actual = sirsUserServiceRO
                .findSirsUsersWithDatatablesCriterias(criterias, false);
        List<SirsUserRO> expected = sirsUserServiceRO.findAll();

        assertEquals(expected.size(), actual.getRows().size());

    }

}
