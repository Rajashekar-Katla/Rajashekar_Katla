package uk.nhs.nhsprotect.cpod.test.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author awheatley
 */
public final class DateUtils {

    /**
     * private constructor class is never instantiated.
     */
    private DateUtils() {
    }

    /**
     * Stores date format - dd/mm/yyyy.
     */
    private static final String DATE_FORMAT = "dd/MM/yyyy";
    /**
     * Date Format.
     */
    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat(
            DATE_FORMAT);

    /**
     * Method to return a date from a String.
     * @param dateToParse - expected format is dd/mm/yyyy
     * @return Date
     * @throws ParseException for error
     */
    public static Date parseDate(String dateToParse) throws ParseException {
        return DATE_FORMATTER.parse(dateToParse);

    }

}
