package uk.nhs.nhsprotect.cpod.test.controller;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.model.Responsibility;
import uk.nhs.nhsprotect.cpod.service.ResponsibilityService;
import uk.nhs.nhsprotect.cpod.service.SirsUserService;
import uk.nhs.nhsprotect.cpod.test.utils.DateUtils;
import uk.nhs.nhsprotect.cpod.test.utils.SecurityRequestPostProcessors;
import uk.nhs.nhsprotect.sirs.model.SirsUser;
import uk.nhs.nhsprotect.sirs.model.SirsUserRO;

/**
 * Test class to exercise the SirsUserAdminController.
 * 
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration(value = "src/main/webapp")
@ContextConfiguration(locations = { "classpath:spring/applicationContext.xml",
		"classpath:spring/hibernateContext.xml",
		"file:src/main/webapp/WEB-INF/spring/spring-servlet.xml",
		"file:src/main/webapp/WEB-INF/spring/spring-tiles.xml",
		"file:src/main/webapp/WEB-INF/spring/spring-security.xml" })
@ActiveProfiles("junit")
@Transactional()
public class SirsUserAdminControllerTest {

	/**
	 * The web application context as managed by Spring.
	 */
	@Autowired
	private WebApplicationContext wac;

	/**
	 * The Spring Security filter that intercepts application URLs.
	 */
	@Autowired
	private FilterChainProxy springSecurityFilterChain;

	/**
	 * reference to responsibility service.
	 */
	@Autowired
	private ResponsibilityService responsibilityService;

	/**
	 * reference to SirsUserService service.
	 */
	@Autowired
	private SirsUserService sirsUserService;

	/**
	 * The message source used within the app.
	 */
	@Autowired
	private MessageSource messageSource;

	/**
	 * The mocked SpringMVC application instance.
	 */
	private MockMvc mockMvc;

	/**
	 * The non-admin user to use for testing with.
	 */
	private final String user = "lsms0246";

	/**
	 * The admin user to use for testing.
	 */
	private final String adminUser = "lcfs1538";

	/**
	 * Method to run before all test methods to create test environment.
	 */
	@Before
	public void setup() {

		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.addFilters(this.springSecurityFilterChain).build();
	}

	/**
	 * Test method to retrieve SIRS users with no active responsibilities - one
	 * user has active resps (lsms0246) one does not (lsms0657)
	 * 
	 * @throws Exception
	 */
	@Test
	public void testListSirsUsersWithoutResponsibilities() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/admin/sirs/sirsUsersNoResp").with(
				SecurityRequestPostProcessors.userDetailsService(adminUser));
		mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
				.andExpect(new ResultMatcher() {

					@SuppressWarnings("unchecked")
					@Override
					public void match(MvcResult mvcResult) throws Exception {
						assertEquals(messageSource.getMessage(
								"sirsuser.inactive.result", null, null),
								(String) mvcResult.getModelAndView().getModel()
										.get("warnMessage"));
						assertNotNull(mvcResult.getModelAndView().getModel()
								.get("sirsusers"));
						List<SirsUserRO> sirsUserROs = (List<SirsUserRO>) mvcResult
								.getModelAndView().getModel().get("sirsusers");
						assertEquals(1, sirsUserROs.size());

					}
				});

	}

	/**
	 * Test method to retrieve SIRS users with no active responsibilities - no
	 * results expected
	 * 
	 * @throws Exception
	 */
	@Test
	public void testListSirsUsersWithoutResponsibilitiesNoResults()
			throws Exception {
		// get roles for lsms0246 and make them inactive
		List<Responsibility> responsibilities = responsibilityService
				.findResponsibilityByPersonRoleId(5L);

		for (Responsibility responsibility : responsibilities) {
			// set the responsibility to active (was previously inactive)
			responsibility.setEndDate(DateUtils.parseDate("31/12/9999"));
			responsibilityService.saveOrUpdate(responsibility);

		}

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/admin/sirs/sirsUsersNoResp").with(
				SecurityRequestPostProcessors.userDetailsService(adminUser));
		mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
				.andExpect(new ResultMatcher() {

					@SuppressWarnings("unchecked")
					@Override
					public void match(MvcResult mvcResult) throws Exception {
						assertEquals(messageSource.getMessage(
								"sirsuser.inactive.none", null, null),
								(String) mvcResult.getModelAndView().getModel()
										.get("successMessage"));
						assertNotNull(mvcResult.getModelAndView().getModel()
								.get("sirsusers"));
						List<SirsUserRO> sirsUserROs = (List<SirsUserRO>) mvcResult
								.getModelAndView().getModel().get("sirsusers");
						assertEquals(0, sirsUserROs.size());

					}
				});

	}

	/**
	 * Test method to ensure users without ISD admin or SIRS admin roles cannot
	 * access method.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSirsAdminMethodsNonAdminAccess() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/admin/sirs/sirsUsersNoResp").with(
				SecurityRequestPostProcessors.userDetailsService(user));
		this.mockMvc.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isForbidden());

	}

	/**
	 * Test view sirs user method for an existing user.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testViewSirsUserExistingUser() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.get("/admin/sirs/viewSirsUser")
				.param("username", "lsms0246")
				.with(SecurityRequestPostProcessors
						.userDetailsService(adminUser));

		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(new ResultMatcher() {

					@Override
					public void match(MvcResult result) throws Exception {

						SirsUser actual = (SirsUser) result.getModelAndView()
								.getModel().get("sirsUser");
						assertNotNull("Expected SirsUser object not in model.",
								actual);

						assertEquals("lsms0246", actual.getUsername());

					}
				})
				.andExpect(MockMvcResultMatchers.view().name("sirs-user-view"));

	}

	/**
	 * Test view sirs user method for a new SIRS user.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testViewSirsUserNewUser() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/admin/sirs/viewSirsUser").with(
				SecurityRequestPostProcessors.userDetailsService(adminUser));

		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(new ResultMatcher() {

					@Override
					public void match(MvcResult result) throws Exception {
						SirsUser actual = (SirsUser) result.getModelAndView()
								.getModel().get("sirsUser");
						assertNotNull("Expected SirsUser object not in model.",
								actual);

						assertEquals(null, actual.getUsername());
					}
				})
				.andExpect(
						MockMvcResultMatchers.view().name(
								"create_enable-sirs-user-view"));

	}

	/**
	 * Test update sirs user status.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testUpdateSirsUserStatus() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/admin/sirs/updateSirsUserStatus")
				.param("id", "lsms0246")
				.param("userStatus", "0")
				.with(SecurityRequestPostProcessors
						.userDetailsService(adminUser));

		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(
						MockMvcResultMatchers.content().string(
								"Sirs User [lsms0246] status updated."));

	}

	/**
	 * Test the view sirs users method.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSirsUsers() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/admin/sirs/sirsUsers").with(
				SecurityRequestPostProcessors.userDetailsService(adminUser));

		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.view().name("list-sirs-users"));

	}

	/**
	 * Test method to save SIRS users with an existing person record.
	 */
	@Test
	public void testSaveSirsUserCreateEnabledExternalUser() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/admin/sirs/saveSirsUser")
				.param("createSirs", "true")
				.param("external", "true")
				.param("username", "lcfs1538")
				.param("enable", "1")
				.param("cpodRole", "LSMS")
				.with(SecurityRequestPostProcessors
						.userDetailsService(adminUser));

		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(new ResultMatcher() {

					@Override
					public void match(MvcResult result) throws Exception {
						SirsUser user = (SirsUser) result.getModelAndView()
								.getModel().get("sirsUser");
						assertNotNull(user);
						assertEquals(1, user.getAuthorities().size());
						assertEquals(1, user.getEnabled());

						String message = (String) result.getModelAndView()
								.getModel().get("successMessage");

						assertEquals(message, "SIRS User [lcfs1538] saved.");

					}
				})
				.andExpect(MockMvcResultMatchers.view().name("sirs-user-view"));
	}

	/**
	 * Test method to save SIRS users with an existing person record.
	 */
	@Test
	public void testSaveSirsUserCreateDisabledInternalUser() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/admin/sirs/saveSirsUser")
				.param("createSirs", "true")
				.param("external", "false")
				.param("username", "ops0259")
				.param("enable", "0")
				.param("cpodRole", "OPS")
				.with(SecurityRequestPostProcessors
						.userDetailsService(adminUser));

		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(new ResultMatcher() {

					@Override
					public void match(MvcResult result) throws Exception {
						SirsUser user = (SirsUser) result.getModelAndView()
								.getModel().get("sirsUser");
						assertNotNull(user);
						assertEquals(1, user.getAuthorities().size());
						assertEquals(0, user.getEnabled());

						String message = (String) result.getModelAndView()
								.getModel().get("successMessage");

						assertEquals(message, "SIRS User [ops0259] saved.");

					}
				})
				.andExpect(MockMvcResultMatchers.view().name("sirs-user-view"));
	}

	/**
	 * Test method to save SIRS users with an existing person record.
	 */
	@Test
	public void testSaveSirsUserUpdateExistingUser() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/admin/sirs/saveSirsUser")
				.param("createSirs", "false")
				.param("external", "true")
				.param("username", "lcfs1538")
				.param("enable", "0")
				.param("cpodRole", "LSMS")
				.with(SecurityRequestPostProcessors
						.userDetailsService(adminUser));

		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(new ResultMatcher() {

					@Override
					public void match(MvcResult result) throws Exception {
						SirsUser user = (SirsUser) result.getModelAndView()
								.getModel().get("sirsUser");
						assertNotNull(user);
						assertEquals(0, user.getEnabled());

						String message = (String) result.getModelAndView()
								.getModel().get("successMessage");

						assertEquals(message, "SIRS User [lcfs1538] saved.");

					}
				})
				.andExpect(MockMvcResultMatchers.view().name("sirs-user-view"));
	}

	/**
	 * Test method to save SIRS users with an existing person record.
	 */
	@Test
	public void testSaveSirsUserInvalidPerson() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/admin/sirs/saveSirsUser")
				.param("createSirs", "true")
				.param("external", "true")
				.param("username", "xxx1234")
				.param("enable", "1")
				.param("cpodRole", "LSMS")
				.with(SecurityRequestPostProcessors
						.userDetailsService(adminUser));

		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(
						MockMvcResultMatchers.view().name("exception-caught"));
	}

	/**
	 * Test method to save SIRS users with an existing person record.
	 */
	@Test
	public void testSaveSirsUserUpdateInvalid() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/admin/sirs/saveSirsUser")
				.param("createSirs", "false")
				.param("external", "true")
				.param("username", "xxx1234")
				.param("enable", "1")
				.param("cpodRole", "LSMS")
				.with(SecurityRequestPostProcessors
						.userDetailsService(adminUser));

		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(
						MockMvcResultMatchers.view().name("exception-caught"));
	}

	/**
	 * Test method to exercise delete sirs user method.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testDeleteSirsUserFullDelete() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/admin/sirs/deleteSirsUser")
				.param("personId", "4")
				.param("userRef", "lcfs1538")
				.param("deleteSirs", "true")
				.param("personInactive", "true")
				.param("endDate", "01/01/2014")
				.with(SecurityRequestPostProcessors
						.userDetailsService(adminUser));
		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(
						MockMvcResultMatchers.content().string("User Deleted"));

	}

	/**
	 * Test method to exercise delete sirs user method.
	 * 
	 * @throws Exception
	 */
	@Test
	@DirtiesContext
	public void testDeleteSirsUserNoSIRSelete() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/admin/sirs/deleteSirsUser")
				.param("personId", "2058")
				.param("userRef", "ops0259")
				.param("deleteSirs", "false")
				.param("personInactive", "true")
				.param("endDate", "01/01/2014")
				.with(SecurityRequestPostProcessors
						.userDetailsService(adminUser));
		this.mockMvc
				.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(
						MockMvcResultMatchers.content().string("User Deleted"));

	}

	/**
	 * Test method to exercise reset password for sirs user method.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testResetInternalSirsUserPassword() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/admin/sirs/resetInternalSirsUserPassword")
				.with(SecurityRequestPostProcessors
						.userDetailsService(adminUser)).param("id", "lsms0246");

		mockMvc.perform(requestBuilder)
				.andDo(MockMvcResultHandlers.print())
				.andExpect(
						MockMvcResultMatchers.content().string(
								"Sirs User [lsms0246] password reset."));
	}
}
