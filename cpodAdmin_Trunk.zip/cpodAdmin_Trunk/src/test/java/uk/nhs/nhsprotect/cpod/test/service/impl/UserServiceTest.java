package uk.nhs.nhsprotect.cpod.test.service.impl;

import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.authentication.User;
import uk.nhs.nhsprotect.cpod.service.PersonService;
import uk.nhs.nhsprotect.cpod.service.UserService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;

/**
 * Test class for UserService methods
 * @author NTones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class UserServiceTest {

    /**
     * Gives access to UserService.
     */
    @Autowired
    private UserService userService;

    @Autowired
    private PersonService personService;

    /**
     * Find User based on person ref.
     * @throws Exception for error
     */
    @Test
    public void testFindByReferenceNumber() throws Exception {

        final String referenceNumber = "lsms0246";
        // find record
        User user = userService.findByReferenceNumber(referenceNumber);
        assertNotNull(user);
        assertEquals(referenceNumber, user.getUsername());
        assertEquals(Long.valueOf(1l), user.getId());
        assertEquals(1, user.getUserAuthorities().size());

    }

    /**
     * Find users based on User criteria
     * @throws Exception for error
     */
    @Test
    public void testSearchUsersAll() throws Exception {

        User toSearch = new User(null, null, true);
        toSearch.setPerson(new Person());
        // find record
        List<User> found = userService.searchUsers(toSearch);
        assertEquals(4, found.size());
    }

    @Test
    public void testSearchUsersLsms0246() throws Exception {

        User toSearch = new User(null, null, true);
        toSearch.setPerson(personService.findPersonByRef("lsms0246"));
        // find record
        List<User> found = userService.searchUsers(toSearch);
        assertEquals(1, found.size());
        assertEquals(1, found.get(0).getUserAuthorities().size());
    }
}
