/** Dao Interface.
 */
package uk.nhs.nhsprotect.cpod.test.service.impl;
