package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;

import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.DaoNotImplementedException;
import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.model.Responsibility;
import uk.nhs.nhsprotect.cpod.service.PersonRoleService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;
import uk.nhs.nhsprotect.cpod.test.utils.PersonUtils;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class PersonRoleServiceTest {

    /**
     * Gives access to person service.
     */
    @Autowired
    private PersonRoleService personRoleService;

    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Gives access to person.
     */
    private PersonRole personRole;

    /**
     * Sets up environment for testing.
     * @throws Exception for errors
     */
    @Before
    public void setUp() throws Exception {
        tearDown();
        personRole = PersonUtils.PersonRolelcfs1234(1L);
        personRoleService.save(personRole);
    }

    /**
     * Tears down data from testing.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws Exception {
        if (personRole != null) {
            personRoleService.delete(personRole);
        }

    }

    /**
     * Checks one record is returned by PersonRef.
     * @throws Exception to catch DateUtils.parseDate
     */
    @Test
    public void testFindPersonRolesByRef() throws Exception {

        PersonRole found = personRoleService.findPersonRoleByRef(personRole
                .getPersonRef());
        assertEquals(found.getPersonRef(), personRole.getPersonRef());

    }

    /**
     * Tests Exception thrown when no records found by PersonRef.
     * @throws Exception when no records found.
     */
    @Test(expected = CpodNoResultsReturnedException.class)
    public void testFindPersonRolesByRefWithNoResults() throws Exception {
        @SuppressWarnings("unused")
        PersonRole found = personRoleService.findPersonRoleByRef("XXXXX");
    }

    /**
     * Add a second person to db with same userRef
     * @throws Exception to catch DateUtils.parseDate
     * @throws org.hibernate.exception.ConstraintViolationException for unique
     *             constraint
     */
    @Test(expected = org.hibernate.exception.ConstraintViolationException.class)
    public void FailTryingAddingSameUserRef() throws Exception {
        // add a PersonRole
        this.personRoleService.save(PersonUtils.PersonRolelcfs1234(1L));
        // add the same PersonRole
        this.personRoleService.save(PersonUtils.PersonRolelcfs1234(1L));
        sessionFactory.getCurrentSession().flush();
        // should throw constraint exception
    }

    /**
     * Test Responsibilities exist for given PersonRoleId
     */
    @Test
    public void testFindResponsibilitiesByPersonRoleId() {

        List<Responsibility> responsibilities = personRoleService
                .getResponsibilitiesForPersonRoleId(1L);

        assertEquals(2, responsibilities.size());

        Collections.sort(responsibilities);

    }

    @Test
    public void testFindPersonRolesByPersonId() throws CpodException,
            ParseException {
        List<PersonRole> personRoles = personRoleService
                .findPersonRolesByPersonId(2l);

        assertEquals(2, personRoles.size());
        // TODO Collection sort doesn't work???
        // Collections.sort(personRoles);

        // set dates for PersonRole
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
        java.util.Date sd = df.parse("08-12-2010 15:28:43");
        java.util.Date ed = df.parse("31-12-9999 00:00:00");

        // create Person Type
        PersonType personType = new PersonType();
        personType.setId((long) CPODConstants.PERSON_TYPE_LSMS_ID);
        personType.setDescription(CPODConstants.PERSON_TYPE_LSMS_DESC);

        // Create Person Role
        PersonRole personRole = new PersonRole();
        personRole.setId(3l);
        personRole.setPersonId(Long.valueOf(2l));
        personRole.setPersonRef("lsms9999");
        personRole.setStartDate(sd);
        personRole.setEndDate(ed);
        personRole.setPersonType(personType);
        personRole.setResponsibilities(null);
        personRole.setReason("NA");
        personRole.setJobTitle("LSMS Lead");

        assertEquals(personRole, personRoles.get(0));

    }

    /**
     * Deletes all persons and check no results are returned. personRef
     * @throws Exception on error
     */
    @Test
    public void testFindPersonRolesNoResults() throws Exception {

        List<PersonRole> personRoles = personRoleService
                .findPersonRolesByRef(personRole.getPersonRef());
        for (PersonRole personLocal : personRoles) {
            personRoleService.delete(personLocal);
        }

        personRoles = personRoleService.findPersonRolesByRef(personRole
                .getPersonRef());
        assertEquals(0, personRoles.size());

    }

    /**
     * Test SaveOrUpdate method
     * @throws ParseException for invalid dates
     * @throws CpodException
     */
    @Test
    public void testSaveorUpdatePersonRole() throws ParseException,
            CpodException {
        // set dates for PersonRole
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
        java.util.Date sd = df.parse("08-12-2010 15:28:43");
        java.util.Date ed = df.parse("31-12-9999 00:00:00");

        // create Person Type
        PersonType personType = new PersonType();
        personType.setId((long) CPODConstants.PERSON_TYPE_LSMS_ID);
        personType.setDescription(CPODConstants.PERSON_TYPE_LSMS_DESC);

        // Create Person Role
        PersonRole personRole = new PersonRole();
        personRole.setPersonId(Long.valueOf(2l));
        personRole.setPersonRef("lsms9999");
        personRole.setStartDate(sd);
        personRole.setEndDate(ed);
        personRole.setPersonType(personType);
        personRole.setResponsibilities(null);
        personRole.setReason("NA");
        personRole.setJobTitle("LSMS Lead");

        personRoleService.saveOrUpdate(personRole);

        assertNotNull(personRole.getId());

    }

    /**
     * Test SaveOrUpdate method external
     * @throws ParseException for invalid dates
     * @throws CpodException
     */
    @Test
    public void testSaveorUpdatePersonRoleExternal() throws ParseException,
            CpodException {
        // set dates for PersonRole
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
        java.util.Date sd = df.parse("08-12-2010 15:28:43");
        java.util.Date ed = df.parse("31-12-9999 00:00:00");

        // create Person Type
        PersonType personType = new PersonType();
        personType.setId((long) CPODConstants.PERSON_TYPE_EXTERNAL_ID);
        personType.setDescription(CPODConstants.PERSON_TYPE_EXTERNAL_DESC);

        // Create Person Role
        PersonRole personRole = new PersonRole();
        personRole.setPersonId(Long.valueOf(2l));
        personRole.setPersonRef("lsms9999");
        personRole.setStartDate(sd);
        personRole.setEndDate(ed);
        personRole.setPersonType(personType);
        personRole.setResponsibilities(null);
        personRole.setReason("NA");
        personRole.setJobTitle("External");

        personRoleService.saveOrUpdate(personRole);

        assertNotNull(personRole.getId());

    }

    /**
     * Method to test deleteAll - should throw not implemented exception
     * @throws Exception
     */
    @Test(expected = DaoNotImplementedException.class)
    public void testDeleteAll() throws Exception {
        personRoleService.deleteAll();
    }

}
