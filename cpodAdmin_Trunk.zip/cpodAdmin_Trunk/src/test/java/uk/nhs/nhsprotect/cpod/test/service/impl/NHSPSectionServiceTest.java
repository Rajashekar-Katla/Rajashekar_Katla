package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.model.NHSPSection;
import uk.nhs.nhsprotect.cpod.service.NHSPSectionService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;

/**
 * @author awheatley
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class NHSPSectionServiceTest {

    /**
     * Gives access to NHSPSectionService.
     */
    @Autowired
    private NHSPSectionService nhspSectionService;

    /**
     * Gives access to NHSPSection Class.
     */
    @SuppressWarnings("unused")
    private NHSPSection nhspSection;

    /**
     * Setup for each test that runs.
     * @throws Exception for error
     */
    @Before
    public void setUp() throws Exception {

    }

    /**
     * Teardown of data after tests complete.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws Exception {

    }

    /**
     * Find NHSPSection by Section Name. Expects one result to be returned
     * @throws Exception for error
     */
    @Test
    public void testFindNHSPSectionByName() throws Exception {

        // find record
        NHSPSection found = nhspSectionService
                .findNhspSectionByName("Deterrence and Engagement");

        // create expected instance
        NHSPSection expected = nhspSectionService.findById(6873L);

        // compare results
        assertEquals(found, expected);

    }

    /**
     * Find non NHSP Section. CpodNoResultsReturnedException should be thrown.
     * @throws Exception for error
     */
    @Test(expected = CpodNoResultsReturnedException.class)
    public void testFindNHSPSectionByNoResults() throws Exception {

        @SuppressWarnings("unused")
        NHSPSection found = nhspSectionService.findNhspSectionByName("XXX");
    }

    /**
     * Find multiple records for NHSPSection. Exception CpodNonUniqueException
     * should be thrown
     * @throws Exception on error
     */
    @Test(expected = CpodNonUniqueException.class)
    public void testFindNhspSectionByNameNoResults() throws Exception {

        // Change Address Type of HOME to WORK, so two records exist with same
        // Address Type.
        NHSPSection existing = nhspSectionService
                .findNhspSectionByName("Intelligence and Research");
        existing.setNhspSectionName("Deterrence and Engagement");
        nhspSectionService.saveOrUpdate(existing);

        @SuppressWarnings("unused")
        NHSPSection found = nhspSectionService
                .findNhspSectionByName("Deterrence and Engagement");
    }

}
