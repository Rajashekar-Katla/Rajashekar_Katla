package uk.nhs.nhsprotect.cpod.test.controller.export;

import java.nio.charset.Charset;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminWebTest;
import uk.nhs.nhsprotect.cpod.test.utils.SecurityRequestPostProcessors;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;

/**
 * test class for UserExportController.
 * @author ntones
 */
@CpodAdminWebTest
@RunWith(SpringJUnit4ClassRunner.class)
public class UserExportControllerTest {

    /**
     * The web application context as managed by Spring.
     */
    @Autowired
    private WebApplicationContext wac;

    /**
     * The Spring Security filter that intercepts application URLs.
     */
    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    /**
     * The mocked SpringMVC application instance.
     */
    private MockMvc mockMvc;

    /**
     * The admin user to use for testing.
     */
    private final String adminUser = "lcfs1538";

    /**
     * Media type of CSV.
     */
    public static final MediaType CSV = new MediaType("text", "csv",
            Charset.forName("utf-8"));

    /**
     * Media type of PDF.
     */
    public static final MediaType PDF = new MediaType("application", "pdf",
            Charset.forName("utf-8"));

    /**
     * Media type of XLSX.
     */
    public static final MediaType XLSX = new MediaType("application",
            "vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            Charset.defaultCharset());

    /**
     * Method to run before all test methods to create test environment.
     */
    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
                .addFilters(this.springSecurityFilterChain).build();
    }

    /**
     * Tests the export request for CSV.
     * @throws Exception on error
     */
    @Test
    public void testExportSRTCSV() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/export/csv/SRT")
                .contentType(CSV)
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("sEcho", "1")
                .param("iColumns", "3").param("sColumns", "")
                .param("iDisplayStart", "0").param("iDisplayLength", "10")
                .param("mDataProp_0", "username")
                .param("mDataProp_1", "fullname")
                .param("mDataProp_2", "status").param("sSearch", "")
                .param("bRegex", "false").param("sSearch_0", "")
                .param("bRegex_0", "false").param("bSearchable_0", "true")
                .param("sSearch_1", "").param("bRegex_1", "false")
                .param("bSearchable_1", "true").param("sSearch_2", "")
                .param("bRegex_2", "false").param("bSearchable_2", "true")
                .param("iSortCol_0", "0").param("sSortDir_0", "asc")
                .param("iSortingCols", "1").param("bSortable_0", "true")
                .param("bSortable_1", "true").param("bSortable_2", "true");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.content()
                                .contentTypeCompatibleWith(CSV))
                .andExpect(
                        MockMvcResultMatchers
                                .content()
                                .string("Reference;Name;Account Status;Mail;\n"
                                        + "lsms0134;Ms Janet Smith;Enabled;jan.smith@awp.nhs.uk;\n"
                                        + "lsms0138;Ms JanetSIRSADMIN SmithSIRSADMIN;Enabled;jan.smithsirsadmin@awp.nhs.uk;\n"));
    }

    /**
     * Tests the export request for PDF.
     * @throws Exception on error
     */
    @Test
    public void testExportSIRSPDF() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/export/pdf/SIRS")
                .contentType(PDF)
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("sEcho", "1")
                .param("iColumns", "3").param("sColumns", "")
                .param("iDisplayStart", "0").param("iDisplayLength", "10")
                .param("mDataProp_0", "username")
                .param("mDataProp_1", "fullname")
                .param("mDataProp_2", "status").param("sSearch", "")
                .param("bRegex", "false").param("sSearch_0", "")
                .param("bRegex_0", "false").param("bSearchable_0", "true")
                .param("sSearch_1", "").param("bRegex_1", "false")
                .param("bSearchable_1", "true").param("sSearch_2", "")
                .param("bRegex_2", "false").param("bSearchable_2", "true")
                .param("iSortCol_0", "0").param("sSortDir_0", "asc")
                .param("iSortingCols", "1").param("bSortable_0", "true")
                .param("bSortable_1", "true").param("bSortable_2", "true");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.content()
                                .contentTypeCompatibleWith(PDF))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult result) throws Exception {
                        String contentDisp = result.getResponse().getHeader(
                                "Content-Disposition");
                        assertNotNull(contentDisp);
                        assertEquals("attachment; filename=\"export.pdf\"",
                                contentDisp);
                    }
                });
    }

    /**
     * Tests the export request for XLSX.
     * @throws Exception on error
     */
    @Test
    public void testExportSRTXLSX() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/export/xlsx/SRT")
                .contentType(XLSX)
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("sEcho", "1")
                .param("iColumns", "3").param("sColumns", "")
                .param("iDisplayStart", "0").param("iDisplayLength", "10")
                .param("mDataProp_0", "username")
                .param("mDataProp_1", "fullname")
                .param("mDataProp_2", "status").param("sSearch", "")
                .param("bRegex", "false").param("sSearch_0", "")
                .param("bRegex_0", "false").param("bSearchable_0", "true")
                .param("sSearch_1", "").param("bRegex_1", "false")
                .param("bSearchable_1", "true").param("sSearch_2", "")
                .param("bRegex_2", "false").param("bSearchable_2", "true")
                .param("iSortCol_0", "0").param("sSortDir_0", "asc")
                .param("iSortingCols", "1").param("bSortable_0", "true")
                .param("bSortable_1", "true").param("bSortable_2", "true");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.content()
                                .contentTypeCompatibleWith(XLSX))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult result) throws Exception {
                        String contentDisp = result.getResponse().getHeader(
                                "Content-Disposition");
                        assertNotNull(contentDisp);
                        assertEquals("attachment; filename=\"export.xlsx\"",
                                contentDisp);
                    }
                });
    }
}
