package uk.nhs.nhsprotect.cpod.test.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminWebTest;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * Test class to exercise the PersonRoleControllerTest.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminWebTest
public class PersonRoleControllerTest {

    /**
     * The web application context as managed by Spring.
     */
    @Autowired
    private WebApplicationContext wac;

    /**
     * The message source used within the app.
     */
    @Autowired
    private MessageSource messageSource;

    /**
     * The mocked SpringMVC application instance.
     */
    private MockMvc mockMvc;

    /**
     * Method to run before all test methods to create test environemnt.
     */
    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
    }

    /**
     * Tests the person role savePersonRole function for a new person role
     * object.
     * @throws Exception on error
     */
    @Test
    public void testSaveOrUpdatePersonRoleSave() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/savePersonRole")
                .param("personId", "1")
                .param("managerId", "")
                .param("reason", "New role")
                .param("jobTitle", "LCFS")
                .param("personType.id", "4")
                .param("startDate",
                        new SimpleDateFormat(
                                CPODConstants.DD_MM_YYYY_DATE_FORMAT)
                                .format(new Date()))
                .param("endDate",
                        new SimpleDateFormat(
                                CPODConstants.DD_MM_YYYY_DATE_FORMAT)
                                .format(new Date()));
        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.model().attributeExists("id"))
                .andExpect(
                        MockMvcResultMatchers.redirectedUrl("/viewPerson?id=1"));
    }
}
