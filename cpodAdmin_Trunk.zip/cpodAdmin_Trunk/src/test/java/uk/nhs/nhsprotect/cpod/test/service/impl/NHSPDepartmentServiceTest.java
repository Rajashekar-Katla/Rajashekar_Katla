package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.model.NHSPDepartment;
import uk.nhs.nhsprotect.cpod.service.NHSPDepartmentService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;

/**
 * @author awheatley
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class NHSPDepartmentServiceTest {

    /**
     * Gives access to NHSPDepartmentService.
     */
    @Autowired
    private NHSPDepartmentService nhspDepartmentService;

    /**
     * Gives access to NHSPSection Class.
     */
    @SuppressWarnings("unused")
    private NHSPDepartment nhspDepartment;

    /**
     * Setup for each test that runs.
     * @throws Exception for error
     */
    @Before
    public void setUp() throws Exception {

    }

    /**
     * Teardown of data after tests complete.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws Exception {

    }

    /**
     * Find NHSP Department by Department Name. Expects one result to be
     * returned
     * @throws Exception for error
     */
    @Test
    public void testFindNHSPDepartmentByName() throws Exception {

        // find record
        NHSPDepartment found = nhspDepartmentService
                .findNhspDepartmentByName("Information Security and Systems");

        // create expected instance
        NHSPDepartment expected = nhspDepartmentService.findById(6848L);

        // compare results
        assertEquals(found, expected);

    }

    /**
     * Find non NHSP Department. CpodNoResultsReturnedException should be
     * thrown.
     * @throws Exception for error
     */
    @Test(expected = CpodNoResultsReturnedException.class)
    public void testFindNHSPDepartmentByNoResults() throws Exception {

        @SuppressWarnings("unused")
        NHSPDepartment found = nhspDepartmentService
                .findNhspDepartmentByName("XXX");
    }

    /**
     * Find multiple records for NHSPDepartment. Exception
     * CpodNonUniqueException should be thrown
     * @throws Exception on error
     */
    @Test(expected = CpodNonUniqueException.class)
    public void testFindNhspDepartmentByNameNoResults() throws Exception {

        // Change Address Type of HOME to WORK, so two records exist with same
        // Address Type.
        NHSPDepartment existing = nhspDepartmentService
                .findNhspDepartmentByName("Information Security and Systems");
        existing.setNhspDepartmentName("Deterrence and Engagement");
        nhspDepartmentService.saveOrUpdate(existing);

        @SuppressWarnings("unused")
        NHSPDepartment found = nhspDepartmentService
                .findNhspDepartmentByName("Deterrence and Engagement");
    }

}
