package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.dao.exception.CpodNonUniqueException;
import uk.nhs.nhsprotect.cpod.model.Region;
import uk.nhs.nhsprotect.cpod.service.RegionService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;

/**
 * @author awheatley
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class RegionsServiceTest {

    /**
     * Gives access to AddressTypeService.
     */
    @Autowired
    private RegionService regionService;

    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Gives access to Organisation Class.
     */
    @SuppressWarnings("unused")
    private Region region;

    /**
     * Setup for each test that runs.
     * @throws Exception for error
     */
    @Before
    public void setUp() throws Exception {

    }

    /**
     * Teardown of data after tests complete.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws Exception {

    }

    /**
     * Find Region based on region_code = "Y01".
     * @throws Exception for error
     */
    @Test
    public void testRegionByRegionCode() throws Exception {

        // find record
        Region found = regionService.findRegionByRegionCode("Y01");

        // create expected instance
        Region expected = new Region();

        expected = regionService.findById(1L);

        // compare results
        assertEquals(found, expected);
        sessionFactory.getCurrentSession().flush();
    }

    /**
     * Find non existing Region Code CpodNoResultsReturnedException should be
     * thrown.
     * @throws Exception for error
     */
    @Test(expected = CpodNoResultsReturnedException.class)
    public void testRegionbyRegionCodeNoReulsts() throws Exception {

        @SuppressWarnings("unused")
        Region found = regionService.findRegionByRegionCode("XXX");
    }

    /**
     * Find multiple records for RegionCode Exception CpodNonUniqueException
     * should be thrown.
     * @throws Exception
     */
    @Test(expected = CpodNonUniqueException.class)
    public void testFindRegionMultipleResultsByRegionCode() throws Exception {

        // Change Address Type of W00 to Y01, so two records exist with same
        // Region Code.
        Region existing = regionService.findRegionByRegionCode("W00");
        existing.setRegionCode("Y01");
        regionService.saveOrUpdate(existing);

        @SuppressWarnings("unused")
        Region found = regionService.findRegionByRegionCode("Y01");
    }

}
