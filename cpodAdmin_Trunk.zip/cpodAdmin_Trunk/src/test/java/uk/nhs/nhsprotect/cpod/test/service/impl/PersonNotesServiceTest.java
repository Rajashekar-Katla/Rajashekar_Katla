package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import org.hibernate.SessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.PersonNote;
import uk.nhs.nhsprotect.cpod.service.PersonNoteService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;
import uk.nhs.nhsprotect.cpod.test.utils.DateUtils;

/**
 * @author awheatley
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class PersonNotesServiceTest {

    /**
     * Gives access to PersonNoteService.
     */

    @Autowired
    private PersonNoteService personNoteService;
    
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Tests findsNotesByPersonId.
     * @throws Exception for error
     */
    @Test
    public void testFindNotesByPersonId() throws Exception {

        PersonNote personNote = personNoteService.findById(1l);
        assertEquals("Some Data", personNote.getNote());
    }

    /**
     * Tests addNewPersonNote.
     * @throws Exception for error
     */
    @Test
    public void addNewPersonNote() throws Exception {

        PersonNote personNote = new PersonNote();
        personNote.setNote("New Note");
        personNote.setModifiedByUser("JUNIT");
        personNote.setNoteDate(DateUtils.parseDate("01/01/2014"));
        personNote.setPerson(new Person(1l));
        
        Long noteId = this.personNoteService.save(personNote);
        sessionFactory.getCurrentSession().flush();
        PersonNote note = this.personNoteService.findById(noteId);
         
        assertEquals(personNote, note);
    }
}
