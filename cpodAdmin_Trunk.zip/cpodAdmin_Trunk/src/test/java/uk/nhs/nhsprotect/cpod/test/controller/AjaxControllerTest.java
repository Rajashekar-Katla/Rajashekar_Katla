package uk.nhs.nhsprotect.cpod.test.controller;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminWebTest;
import uk.nhs.nhsprotect.cpod.test.utils.SecurityRequestPostProcessors;

/**
 * Test class to exercise the AjaxController.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminWebTest
public class AjaxControllerTest {

    /**
     * The web application context as managed by Spring.
     */
    @Autowired
    private WebApplicationContext wac;

    /**
     * The Spring Security filter that intercepts application URLs.
     */
    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    /**
     * The mocked SpringMVC application instance.
     */
    private MockMvc mockMvc;

    /**
     * The admin user to use for testing.
     */
    private final String adminUser = "lcfs1538";

    /**
     * Method to run before all test methods to create test environment.
     */
    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
                .addFilters(this.springSecurityFilterChain).build();
    }

    /**
     * Tests the ajax request get potential new users.
     * @throws Exception
     */
    @Test
    public void testGetUsersAjax() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/getUsersAjax/CPOD")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("query", "");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath(".personRef[0]", is("ops0106")));
    }

    /**
     * Tests the ajax request get potential new SIRS users.
     * @throws Exception
     */
    @Test
    public void testGetSirsUsersAjax() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/getUsersAjax/SIRS")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("query", "lsms");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath(".personRef[0]", is("lsms9999")));
    }

    /**
     * Tests the ajax request get potential organisations for resps.
     * @throws Exception
     */
    @Test
    public void testGetOrganisationsForRespsAjax() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/getOrganisationsForRespsAjax")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("personId", "2058").param("query", "pct");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));
    }

    /**
     * Tests the ajax request get potential persons for resps.
     * @throws Exception
     */
    @Test
    public void testGetPersonsForRespsAjax() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/getPersonsForRespsAjax")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("orgId", "5927")
                .param("query", "lsms");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));
    }

    /**
     * Test the ajax request for getting employer organisations for a person
     * (used on person page).
     * @throws Exception
     */
    @Test
    public void testGetOrganisationdsForPersAjax() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/getOrganisationsForPersAjax")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("orgId", "5927")
                .param("query", "prot");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath(".orgCode[0]", is("T1350")))
                .andExpect(jsonPath("$", hasSize(1)));
    }

    /**
     * Tests the ajax request get NHSP staff (used for selecting manager on
     * person page).
     * @throws Exception
     */
    @Test
    public void testGetNHSPStaffAjax() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/getNHSPStaffAjax")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("query", "nic");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(3)));
    }

    /**
     * Tests the request to get NHSP Section (used on person page).
     * @throws Exception
     */
    @Test
    public void testGetNHSPSectionsAjax() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/getNHSPSectionsAjax")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("query", "sys");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(3)));
    }

    /**
     * Tests the request to get a list of SIRS users ajax-wise.
     * @throws Exception
     */
    @Test
    public void testListSirsUsersAjax() throws Exception {
        // TODO probably could do with this as a utility class
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/listUsers/SIRS")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("sEcho", "1")
                .param("iColumns", "4").param("sColumns", "")
                .param("iDisplayStart", "0").param("iDisplayLength", "10")
                .param("mDataProp_0", "username")
                .param("mDataProp_1", "fullname")
                .param("mDataProp_2", "status").param("mDataProp_3", "3")
                .param("sSearch", "").param("bRegex", "false")
                .param("sSearch_0", "").param("bRegex_0", "false")
                .param("bSearchable_0", "true").param("sSearch", "")
                .param("bRegex", "false").param("sSearch_0", "")
                .param("bRegex_0", "false").param("bSearchable_0", "true")
                .param("sSearch_1", "").param("bRegex_1", "false")
                .param("bSearchable_1", "true").param("sSearch_2", "")
                .param("bRegex_2", "false").param("bSearchable_2", "true")
                .param("sSearch_3", "").param("bRegex_3", "false")
                .param("bSearchable_3", "false").param("iSortCol_0", "0")
                .param("sSortDir_0", "asc").param("iSortingCols", "1")
                .param("bSortable_0", "true").param("bSortable_1", "true")
                .param("bSortable_2", "true").param("bSortable_3", "true")
                .param("_", "1408535859490");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.iTotalRecords", is(2)))
                .andExpect(jsonPath("$.aaData", hasSize(2)));
    }

    /**
     * Tests the request to get a list of SIRS users ajax-wise. Sorting by
     * column 1 = fullname
     * @throws Exception
     */
    @Test
    public void testListSirsUsersAjaxSortByName() throws Exception {
        // TODO probably could do with this as a utility class
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/listUsers/SIRS")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("sEcho", "1")
                .param("iColumns", "4").param("sColumns", "")
                .param("iDisplayStart", "0").param("iDisplayLength", "10")
                .param("mDataProp_0", "username")
                .param("mDataProp_1", "fullname")
                .param("mDataProp_2", "status").param("mDataProp_3", "3")
                .param("sSearch", "").param("bRegex", "false")
                .param("sSearch_0", "").param("bRegex_0", "false")
                .param("bSearchable_0", "true").param("sSearch", "")
                .param("bRegex", "false").param("sSearch_0", "")
                .param("bRegex_0", "false").param("bSearchable_0", "true")
                .param("sSearch_1", "").param("bRegex_1", "false")
                .param("bSearchable_1", "true").param("sSearch_2", "")
                .param("bRegex_2", "false").param("bSearchable_2", "true")
                .param("sSearch_3", "").param("bRegex_3", "false")
                .param("bSearchable_3", "false").param("iSortCol_0", "1")
                .param("sSortDir_0", "asc").param("iSortingCols", "1")
                .param("bSortable_0", "true").param("bSortable_1", "true")
                .param("bSortable_2", "true").param("bSortable_3", "true")
                .param("_", "1408535859490");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.iTotalRecords", is(2)))
                .andExpect(jsonPath("$.aaData", hasSize(2)));
    }

    /**
     * Tests the request to get a list of SIRS users ajax-wise. Sorting by
     * Column 2 = status
     * @throws Exception
     */
    @Test
    public void testListSirsUsersAjaxSortByStatus() throws Exception {
        // TODO probably could do with this as a utility class
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/listUsers/SIRS")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("sEcho", "1")
                .param("iColumns", "4").param("sColumns", "")
                .param("iDisplayStart", "0").param("iDisplayLength", "10")
                .param("mDataProp_0", "username")
                .param("mDataProp_1", "fullname")
                .param("mDataProp_2", "status").param("mDataProp_3", "3")
                .param("sSearch", "").param("bRegex", "false")
                .param("sSearch_0", "").param("bRegex_0", "false")
                .param("bSearchable_0", "true").param("sSearch", "")
                .param("bRegex", "false").param("sSearch_0", "")
                .param("bRegex_0", "false").param("bSearchable_0", "true")
                .param("sSearch_1", "").param("bRegex_1", "false")
                .param("bSearchable_1", "true").param("sSearch_2", "")
                .param("bRegex_2", "false").param("bSearchable_2", "true")
                .param("sSearch_3", "").param("bRegex_3", "false")
                .param("bSearchable_3", "false").param("iSortCol_0", "2")
                .param("sSortDir_0", "asc").param("iSortingCols", "1")
                .param("bSortable_0", "true").param("bSortable_1", "true")
                .param("bSortable_2", "true").param("bSortable_3", "true")
                .param("_", "1408535859490");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.iTotalRecords", is(2)))
                .andExpect(jsonPath("$.aaData", hasSize(2)));
    }

    /**
     * Tests the request to get a list of SRT users ajax-wise.
     * @throws Exception on error
     */
    @Test
    public void testListSrtUsersAjax() throws Exception {
        // TODO probably could do with this as a utility class
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/listUsers/SRT")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("sEcho", "1")
                .param("iColumns", "4").param("sColumns", "")
                .param("iDisplayStart", "0").param("iDisplayLength", "10")
                .param("mDataProp_0", "username")
                .param("mDataProp_1", "fullname")
                .param("mDataProp_2", "status").param("mDataProp_3", "3")
                .param("sSearch", "").param("bRegex", "false")
                .param("sSearch_0", "").param("bRegex_0", "false")
                .param("bSearchable_0", "true").param("sSearch", "")
                .param("bRegex", "false").param("sSearch_0", "")
                .param("bRegex_0", "false").param("bSearchable_0", "true")
                .param("sSearch_1", "").param("bRegex_1", "false")
                .param("bSearchable_1", "true").param("sSearch_2", "")
                .param("bRegex_2", "false").param("bSearchable_2", "true")
                .param("sSearch_3", "").param("bRegex_3", "false")
                .param("bSearchable_3", "false").param("iSortCol_0", "0")
                .param("sSortDir_0", "asc").param("iSortingCols", "1")
                .param("bSortable_0", "true").param("bSortable_1", "true")
                .param("bSortable_2", "true").param("bSortable_3", "true")
                .param("_", "1408535859490");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.iTotalRecords", is(2)))
                .andExpect(jsonPath("$.aaData", hasSize(2)));
    }

    /**
     * Tests the request to get a list of SRT users ajax-wise. Sorting by column
     * 1 = fullname
     * @throws Exception on error
     */
    @Test
    public void testListSrtUsersAjaxSortByName() throws Exception {
        // TODO probably could do with this as a utility class
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/listUsers/SRT")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("sEcho", "1")
                .param("iColumns", "4").param("sColumns", "")
                .param("iDisplayStart", "0").param("iDisplayLength", "10")
                .param("mDataProp_0", "username")
                .param("mDataProp_1", "fullname")
                .param("mDataProp_2", "status").param("mDataProp_3", "3")
                .param("sSearch", "").param("bRegex", "false")
                .param("sSearch_0", "").param("bRegex_0", "false")
                .param("bSearchable_0", "true").param("sSearch", "")
                .param("bRegex", "false").param("sSearch_0", "")
                .param("bRegex_0", "false").param("bSearchable_0", "true")
                .param("sSearch_1", "").param("bRegex_1", "false")
                .param("bSearchable_1", "true").param("sSearch_2", "")
                .param("bRegex_2", "false").param("bSearchable_2", "true")
                .param("sSearch_3", "").param("bRegex_3", "false")
                .param("bSearchable_3", "false").param("iSortCol_0", "1")
                .param("sSortDir_0", "asc").param("iSortingCols", "1")
                .param("bSortable_0", "true").param("bSortable_1", "true")
                .param("bSortable_2", "true").param("bSortable_3", "true")
                .param("_", "1408535859490");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.iTotalRecords", is(2)))
                .andExpect(jsonPath("$.aaData", hasSize(2)));
    }

    /**
     * Tests the request to get a list of SRT users ajax-wise. Sorting by Column
     * 2 = status
     * @throws Exception on error
     */
    @Test
    public void testListSrtUsersAjaxSortByStatus() throws Exception {
        // TODO probably could do with this as a utility class
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/listUsers/SRT")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("sEcho", "1")
                .param("iColumns", "4").param("sColumns", "")
                .param("iDisplayStart", "0").param("iDisplayLength", "10")
                .param("mDataProp_0", "username")
                .param("mDataProp_1", "fullname")
                .param("mDataProp_2", "status").param("mDataProp_3", "3")
                .param("sSearch", "").param("bRegex", "false")
                .param("sSearch_0", "").param("bRegex_0", "false")
                .param("bSearchable_0", "true").param("sSearch", "")
                .param("bRegex", "false").param("sSearch_0", "")
                .param("bRegex_0", "false").param("bSearchable_0", "true")
                .param("sSearch_1", "").param("bRegex_1", "false")
                .param("bSearchable_1", "true").param("sSearch_2", "")
                .param("bRegex_2", "false").param("bSearchable_2", "true")
                .param("sSearch_3", "").param("bRegex_3", "false")
                .param("bSearchable_3", "false").param("iSortCol_0", "2")
                .param("sSortDir_0", "asc").param("iSortingCols", "1")
                .param("bSortable_0", "true").param("bSortable_1", "true")
                .param("bSortable_2", "true").param("bSortable_3", "true")
                .param("_", "1408535859490");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.iTotalRecords", is(2)))
                .andExpect(jsonPath("$.aaData", hasSize(2)));
    }
}
