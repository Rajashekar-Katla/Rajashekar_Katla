package uk.nhs.nhsprotect.cpod.test.controller;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.service.SirsUserService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminWebTest;
import uk.nhs.nhsprotect.cpod.test.utils.SecurityRequestPostProcessors;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * Test class to exercise the PersonController.
 * 
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminWebTest
public class PersonControllerTest {

    /**
     * The web application context as managed by Spring.
     */
    @Autowired
    private WebApplicationContext wac;

    /**
     * The message source used within the app.
     */
    @Autowired
    private MessageSource messageSource;

    /**
     * The mocked SpringMVC application instance.
     */
    private MockMvc mockMvc;

    /**
     * The Spring Security filter that intercepts application URLs.
     */
    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    @Autowired
    private SirsUserService sirsUserService;

    /**
     * The non-admin user to use for testing.
     */
    private final String nonAdminUser = "lsms0246";

    /**
     * The admin user to use for testing.
     */
    private final String adminUser = "lcfs1538";

    /**
     * The SIRS admin user for testing
     */
    private String sirsAdminUser = "lsms0657";

    /**
     * The LSDS admin user for testing
     */
    private String lsdsAdminUser = "lsdsAdmin";

    /**
     * The training admin user for testing
     */
    private String trainingAdminUser = "trainingAdmin";

    /**
     * Method to run before all test methods to create test environemnt.
     */
    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
                .addFilters(this.springSecurityFilterChain).build();
    }

    /**
     * Tests the person search function with all parameters supplied but no
     * matches on DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testPersonSearchNoMatchesAdminUser() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/personSearch")
                .param("forename", "xxxx")
                .param("surname", "xxxx")
                .param("reference", "xxxx")
                .param("personType", "ALL")
                .param("status", "ALL")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser));
        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the message for empty results is populated
                        String message = (String) mvcResult.getModelAndView()
                                .getModel().get("warnMessage");
                        assertEquals(messageSource.getMessage(
                                "search.result.empty", null, null), message);
                        assertNotNull(
                                "Expected list of users to create ",
                                mvcResult.getModelAndView().getModel()
                                        .get("personTypesToCreate"));
                        // can create all i.e. 11
                        assertEquals(11,
                                ((List<PersonType>) mvcResult.getModelAndView()
                                        .getModel().get("personTypesToCreate"))
                                        .size());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("search-view"));
    }

    /**
     * Tests the person search function with all parameters supplied but no
     * matches on DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testPersonSearchNoMatchesNonAdminUser() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/personSearch")
                .param("forename", "xxxx")
                .param("surname", "xxxx")
                .param("reference", "xxxx")
                .param("personType", "ALL")
                .param("status", "ALL")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(nonAdminUser));
        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the message for empty results is populated
                        String message = (String) mvcResult.getModelAndView()
                                .getModel().get("warnMessage");
                        assertEquals(messageSource.getMessage(
                                "search.result.empty", null, null), message);
                        assertNotNull(
                                "Expected list of users to create ",
                                mvcResult.getModelAndView().getModel()
                                        .get("personTypesToCreate"));
                        // can't create any
                        assertEquals(0,
                                ((List<PersonType>) mvcResult.getModelAndView()
                                        .getModel().get("personTypesToCreate"))
                                        .size());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("search-view"));
    }

    /**
     * Tests the person search function with all parameters supplied but no
     * matches on DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testPersonSearchNoMatchesSirsAdminUser() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/personSearch")
                .param("forename", "xxxx")
                .param("surname", "xxxx")
                .param("reference", "xxxx")
                .param("personType", "ALL")
                .param("status", "ALL")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(sirsAdminUser));
        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the message for empty results is populated
                        String message = (String) mvcResult.getModelAndView()
                                .getModel().get("warnMessage");
                        assertEquals(messageSource.getMessage(
                                "search.result.empty", null, null), message);
                        assertNotNull(
                                "Expected list of users to create ",
                                mvcResult.getModelAndView().getModel()
                                        .get("personTypesToCreate"));
                        // can create spec, smd, lms and lssp i.e. 4
                        assertEquals(4,
                                ((List<PersonType>) mvcResult.getModelAndView()
                                        .getModel().get("personTypesToCreate"))
                                        .size());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("search-view"));
    }

    /**
     * Tests the person search function with all parameters supplied but no
     * matches on DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testPersonSearchNoMatchesLsdsAdminUser() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/personSearch")
                .param("forename", "xxxx")
                .param("surname", "xxxx")
                .param("reference", "xxxx")
                .param("personType", "ALL")
                .param("status", "ALL")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(lsdsAdminUser));
        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the message for empty results is populated
                        String message = (String) mvcResult.getModelAndView()
                                .getModel().get("warnMessage");
                        assertEquals(messageSource.getMessage(
                                "search.result.empty", null, null), message);
                        assertNotNull(
                                "Expected list of users to create ",
                                mvcResult.getModelAndView().getModel()
                                        .get("personTypesToCreate"));
                        // can create lsms and lcfs i.e. 2
                        assertEquals(2,
                                ((List<PersonType>) mvcResult.getModelAndView()
                                        .getModel().get("personTypesToCreate"))
                                        .size());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("search-view"));
    }

    /**
     * Tests the person search function with all parameters supplied but no
     * matches on DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testPersonSearchNoMatchesTrainingAdminUser() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/personSearch")
                .param("forename", "xxxx")
                .param("surname", "xxxx")
                .param("reference", "xxxx")
                .param("personType", "ALL")
                .param("status", "ALL")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(trainingAdminUser));
        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the message for empty results is populated
                        String message = (String) mvcResult.getModelAndView()
                                .getModel().get("warnMessage");
                        assertEquals(messageSource.getMessage(
                                "search.result.empty", null, null), message);
                        assertNotNull(
                                "Expected list of users to create ",
                                mvcResult.getModelAndView().getModel()
                                        .get("personTypesToCreate"));
                        // can create ext i.e. 1
                        assertEquals(1,
                                ((List<PersonType>) mvcResult.getModelAndView()
                                        .getModel().get("personTypesToCreate"))
                                        .size());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("search-view"));
    }

    /**
     * Tests the person search function with all parameters supplied and
     * multiple matches on DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testPersonSearchMultipleMatches() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/personSearch")
                .param("forename", "")
                .param("surname", "")
                .param("reference", "")
                .param("personType", "ALL")
                .param("status", "ALL")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(nonAdminUser));
        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.model()
                                .attributeExists("persons"))
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        List<Person> persons = (List<Person>) mvcResult
                                .getModelAndView().getModel().get("persons");

                        assertNotNull(persons);
                        assertEquals(5, persons.size());// 5 persons setup in
                                                        // script

                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("search-results"));
    }

    /**
     * Tests the person search function with reference supplied and matches on
     * DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testPersonSearchMatchesReferenceSingleResult() throws Exception {
        final String reference = "lsms0246";
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/personSearch")
                .param("forename", "")
                .param("surname", "")
                .param("reference", reference)
                .param("personType", "ALL")
                .param("status", "ALL")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser));
        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.model().attributeExists("person"))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        Person person = (Person) mvcResult.getModelAndView()
                                .getModel().get("person");

                        // TODO dangerous should have a utility method to return
                        // the person references properly.
                        assertEquals(reference, person.getPersonRoles().get(0)
                                .getPersonRef());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("person-view"));
    }

    /**
     * Tests the person search function with reference supplied and matches on
     * DB.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testPersonSearchMatchesStatusAndTypeSingleResult()
            throws Exception {
        // build search for active lcfs
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/personSearch")
                .param("status", "Y")
                .param("personType",
                        Integer.toString((CPODConstants.PERSON_TYPE_LCFS_ID)))
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser));
        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.model().attributeExists("person"))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        Person person = (Person) mvcResult.getModelAndView()
                                .getModel().get("person");

                        // setup creates one active lcfs - but has two roles
                        // lsms and lcfs
                        assertEquals(2, person.getPersonRoles().size());

                        assertEquals(
                                Long.valueOf((long) CPODConstants.PERSON_TYPE_LSMS_ID),
                                person.getPersonRoles().get(0).getPersonType()
                                        .getId());
                        assertEquals(
                                Long.valueOf((long) CPODConstants.PERSON_TYPE_LCFS_ID),
                                person.getPersonRoles().get(1).getPersonType()
                                        .getId());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("person-view"));
    }

    /**
     * Method to test the prepare a new person request
     * 
     * @throws Exception
     */
    @Test
    public void testViewPersonNewPerson() throws Exception {

        // create a new LCFS
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/viewPerson")
                .param("personTypeId", "4")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser));
        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.model().attributeExists("person"))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        Person person = (Person) mvcResult.getModelAndView()
                                .getModel().get("person");

                        // TODO person ref now on personRole
                        // assertEquals(Long.valueOf(4l), person.getPersonType()
                        // .getId());
                        assertEquals(CPODConstants.PERSON_STATUS_PENDING,
                                person.getStatus());
                    }
                }).andExpect(MockMvcResultMatchers.view().name("person-view"));

    }

    /**
     * Method to test the view person request as a RO user
     * 
     * @throws Exception
     */
    @Test
    public void testViewPersonROUser() throws Exception {

        // create a new LCFS
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/viewPerson")
                .param("personTypeId", "4")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(nonAdminUser));
        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.model().attributeExists("person"))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        Person person = (Person) mvcResult.getModelAndView()
                                .getModel().get("person");

                        // TODO person ref now on personRole
                        // assertEquals(Long.valueOf(4l), person.getPersonType()
                        // .getId());
                        assertEquals(CPODConstants.PERSON_STATUS_PENDING,
                                person.getStatus());
                    }
                })

                .andExpect(MockMvcResultMatchers.view().name("person-viewRO"));

    }

    /**
     * Method to test the creation of a new LCFS
     * 
     * @throws Exception
     */
    @Test
    public void testSaveOrUpdatePersonNewPerson() throws Exception {
        // create a new EXTERNAL
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/savePerson")
                .param("_fraudComplete", "on")
                .param("_proprietryComplete", "on")
                .param("_securityComplete", "on")
                .param("personRoles[0].endDate", "31/12/9999")
                .param("foreName", "EXTERNAL")
                .param("homeAddress.address1", "TEST HOME 1")
                .param("homeAddress.postcode", "NE14WH")
                .param("homeAddress.addressType.id", "")
                .param("knownAs", "EXTERNAL")
                .param("personRoles[0].personRef", "EXTERNAL")
                .param("personRoles[0].personType.id",
                        Integer.toString(CPODConstants.PERSON_TYPE_EXTERNAL_ID))
                .param("personRoles[0].startDate", "19/08/2013")
                .param("personRoles[0].reason", "NEW EXTERNAL")
                .param("personRoles[0].manager.id", "")
                .param("status", "P")
                .param("surName", "TEST")
                .param("title", "Mr")
                .param("workAddress.address1", "TEST WORK 1")
                .param("workAddress.postcode", "NE14WH")
                .param("workAddress.addressType.id", "")
                .param("employerOrganisation.id", "")
                .param("nhspSection.id", "")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.model().attributeExists("id"))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        String id = (String) mvcResult.getModelAndView()
                                .getModel().get("id");
                        String roles = (String) mvcResult.getModelAndView()
                                .getModel().get("roles");

                        assertNotNull(id);
                        assertNotNull(roles);
                        String[] params = { roles };
                        assertEquals(messageSource.getMessage(
                                "person.edit.success", params, null),
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("successMessage"));

                    }
                }).andExpect(
                // redirectedUrl("viewPerson")
                        status().isMovedTemporarily()).andReturn();

        MockHttpServletResponse response = result.getResponse();

        String location = response.getHeader("Location");

        assertTrue("URL does not match expected [/viewPerson?id=xxxx] was ["
                + location + "]",
                StringUtils.contains(location, "/viewPerson?id="));
    }

    /**
     * Method to test the creation of a new LMS
     * 
     * @throws Exception
     */
    @Test
    @DirtiesContext
    public void testSaveOrUpdatePersonNewSirsPerson() throws Exception {

        int initialCount = sirsUserService.findAll().size();

        // create a new EXTERNAL
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/savePerson")
                .param("_fraudComplete", "on")
                .param("_proprietryComplete", "on")
                .param("_securityComplete", "on")
                .param("personRoles[0].endDate", "31/12/9999")
                .param("foreName", "LMS")
                .param("homeAddress.address1", "TEST HOME 1")
                .param("homeAddress.postcode", "NE14WH")
                .param("homeAddress.addressType.id", "")
                .param("knownAs", "EXTERNAL")
                .param("personRoles[0].personRef", "LMS")
                .param("personRoles[0].personType.id",
                        Integer.toString(CPODConstants.PERSON_TYPE_LMS_ID))
                .param("personRoles[0].startDate", "19/08/2013")
                .param("personRoles[0].reason", "NEW EXTERNAL")
                .param("personRoles[0].manager.id", "")
                .param("status", "P")
                .param("surName", "LMS")
                .param("title", "Mr")
                .param("workAddress.address1", "TEST WORK 1")
                .param("workAddress.postcode", "NE14WH")
                .param("workAddress.addressType.id", "")
                .param("employerOrganisation.id", "")
                .param("nhspSection.id", "")
                .param("createSirs", "true")
                .param("external", "true")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.model().attributeExists("id"))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        String id = (String) mvcResult.getModelAndView()
                                .getModel().get("id");
                        String roles = (String) mvcResult.getModelAndView()
                                .getModel().get("roles");

                        assertNotNull(id);
                        assertNotNull(roles);
                        String[] params = { roles };
                        assertEquals(messageSource.getMessage(
                                "person.edit.success", params, null),
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("successMessage"));

                    }
                }).andExpect(
                // redirectedUrl("viewPerson")
                        status().isMovedTemporarily()).andReturn();

        MockHttpServletResponse response = result.getResponse();

        String location = response.getHeader("Location");

        assertTrue("URL does not match expected [/viewPerson?id=xxxx] was ["
                + location + "]",
                StringUtils.containsAny(location, "/viewPerson?id="));

        // check that a new SIRS user has been created
        int afterCount = sirsUserService.findAll().size();
        assertEquals(afterCount, initialCount + 1);

    }

    /**
     * Method to test the prepare a new person request tests that all messages
     * are redirected correctly.
     * 
     * @throws Exception
     */
    @Test
    public void testViewPersonAfterSaveOrUpdate() throws Exception {

        // create a new LCFS
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/viewPerson")
                .param("id", "4")
                .param("successMessage",
                        messageSource.getMessage("person.edit.success", null,
                                null))
                .param("infoMessage", "infoMessage")
                .param("warnMessage", "warnMessage")
                .param("errorMessage", "errorMessage")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser));
        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.model().attributeExists("person"))
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        Person person = (Person) mvcResult.getModelAndView()
                                .getModel().get("person");

                        // TODO person ref now on personRole
                        // assertEquals(Long.valueOf(4l), person.getPersonType()
                        // .getId());
                        assertEquals(CPODConstants.PERSON_STATUS_INACTIVE,
                                person.getStatus());
                        assertEquals(messageSource.getMessage(
                                "person.edit.success", null, null),
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("successMessage"));
                        assertEquals("infoMessage", (String) mvcResult
                                .getModelAndView().getModel()
                                .get("infoMessage"));
                        assertEquals("warnMessage", (String) mvcResult
                                .getModelAndView().getModel()
                                .get("warnMessage"));
                        assertEquals("errorMessage",
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("errorMessage"));

                    }
                }).andExpect(MockMvcResultMatchers.view().name("person-view"));

    }

    /**
     * Tests the person role savePersonRole function for a new person role
     * object.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testSavePersonNote() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/savePersonNote")
                .param("personId", "1")
                .param("note", "testing")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser));

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.model().attributeExists("id"))
                .andExpect(
                        MockMvcResultMatchers.model().attributeExists(
                                "successMessage"))
                .andExpect(
                        MockMvcResultMatchers
                                .redirectedUrl("/viewPerson?id=1&successMessage=Person+Note+Created"));
    }
}
