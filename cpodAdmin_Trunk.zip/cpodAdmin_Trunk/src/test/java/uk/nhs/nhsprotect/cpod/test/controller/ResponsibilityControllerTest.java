package uk.nhs.nhsprotect.cpod.test.controller;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.model.Responsibility;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminWebTest;
import uk.nhs.nhsprotect.cpod.test.utils.DateUtils;
import uk.nhs.nhsprotect.cpod.test.utils.SecurityRequestPostProcessors;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * Test class to exercise the ResponsibilityController.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminWebTest
public class ResponsibilityControllerTest {

    /**
     * The web application context as managed by Spring.
     */
    @Autowired
    private WebApplicationContext wac;

    /**
     * The Spring Security filter that intercepts application URLs.
     */
    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    /**
     * The mocked SpringMVC application instance.
     */
    private MockMvc mockMvc;

    /**
     * The admin user to use for testing.
     */
    private final String adminUser = "lcfs1538";

    /**
     * Message Source for message property file access.
     */
    @Autowired
    private MessageSource messageSource;

    /**
     * Method to run before all test methods to create test environment.
     */
    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
                .addFilters(this.springSecurityFilterChain).build();
    }

    /**
     * Tests the method to view responsibilities for a person.
     * @throws Exception
     */
    @Test
    public void viewResponsibilitiesTest() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/viewResponsibilities")
                .param("personRoleId", "1")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser));

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the resp results are expected i.e. 2 from setup
                        // script
                        List<Responsibility> resps = (List<Responsibility>) mvcResult
                                .getModelAndView().getModel()
                                .get("responsibilities");
                        assertNotNull(resps);
                        assertEquals(2, resps.size());
                        assertEquals(Long.valueOf(1l),
                                (Long) mvcResult.getModelAndView().getModel()
                                        .get("personRoleId"));

                    }
                })
                .andExpect(
                        MockMvcResultMatchers.view().name("person-resp-view"));
    }

    /**
     * Tests the method to view responsibilities for a person where no
     * responsibilities exist.
     * @throws Exception
     */
    @Test
    public void viewResponsibilitiesNoResponsibilitiesTest() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/viewResponsibilities")
                .param("personRoleId", "999999")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser));

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the resp results are expected i.e. 0
                        List<Responsibility> resps = (List<Responsibility>) mvcResult
                                .getModelAndView().getModel()
                                .get("responsibilities");
                        assertNotNull(resps);
                        assertEquals(0, resps.size());
                    }
                })
                .andExpect(
                        MockMvcResultMatchers.view().name("person-resp-view"));
    }

    /**
     * Tests the method to add responsibility for a person.
     * @throws Exception
     */
    @Test
    public void addResponsibilityTest() throws Exception {
        // adds a new lead resp to NHS Protect org from setup script
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/addResponsibility")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("lead", "true")
                .param("personId", "1")
                .param("organisationId", "5927")
                .param("startDate",
                        new SimpleDateFormat(
                                CPODConstants.DD_MM_YYYY_DATE_FORMAT)
                                .format(new Date()))
                .param("endDate",
                        new SimpleDateFormat(
                                CPODConstants.DD_MM_YYYY_DATE_FORMAT)
                                .format(new Date()));

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the resp is created - i.e. has an Id
                        Responsibility resp = (Responsibility) mvcResult
                                .getModelAndView().getModel()
                                .get("responsibility");
                        assertNotNull(resp);
                        assertNotNull(resp.getId());
                        assertEquals(messageSource.getMessage(
                                "resp.edit.success", null, null),
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("successMessage"));

                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("add-resp-view"));
    }

    /**
     * Tests the method to update responsibility for a person.
     * @throws Exception
     */
    @Test
    public void updateResponsibilityTest() throws Exception {
        // edits lead resp to NHS Protect org from setup script
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/updateResponsibility")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("lead", "true")
                .param("personId", "1")
                .param("organisationId", "5448")
                .param("id", "1095")
                .param("startDate",
                        new SimpleDateFormat(
                                CPODConstants.DD_MM_YYYY_DATE_FORMAT)
                                .format(DateUtils.parseDate("03/01/2010")))
                .param("endDate",
                        new SimpleDateFormat(
                                CPODConstants.DD_MM_YYYY_DATE_FORMAT)
                                .format(new Date()));

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())

                .andExpect(
                        MockMvcResultMatchers.content().string(
                                messageSource.getMessage("resp.edit.success",
                                        null, null)));
    }

    /**
     * Tests the prepare method for adding responsibility for a person.
     * @throws Exception
     */
    @Test
    public void prepareAddResponsibilityFromPersonTest() throws Exception {
        // adds a new lead resp to NHS Protect org from setup script
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/addResponsibility")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("personRoleId", "1");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the resp is created - i.e. a new resp
                        // assosciated to person
                        Responsibility resp = (Responsibility) mvcResult
                                .getModelAndView().getModel()
                                .get("responsibility");
                        assertNotNull(resp);
                        assertEquals(null, resp.getId());
                        // TODO person id now on personRole
                        // assertEquals("1", resp.getPersonId());
                        assertEquals(null, resp.getOrganisationId());
                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("add-resp-view"));
    }

    /**
     * Tests the prepare method for adding responsibility for a person.
     * @throws Exception
     */
    @Test
    public void prepareAddResponsibilityFromOrganisationTest() throws Exception {
        // adds a new lead resp to NHS Protect org from setup script
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/addResponsibility")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("orgId", "5448");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the resp is created - i.e. a new resp
                        // assosciated to person
                        Responsibility resp = (Responsibility) mvcResult
                                .getModelAndView().getModel()
                                .get("responsibility");
                        assertNotNull(resp);
                        assertEquals(null, resp.getId());
                        // TODO person id now on personRole
                        // assertEquals(null, resp.getPersonId());
                        assertEquals("5448", resp.getOrganisationId());
                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("add-resp-view"));
    }

}
