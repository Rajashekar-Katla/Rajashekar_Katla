package uk.nhs.nhsprotect.cpod.test.controller;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.model.authentication.User;
import uk.nhs.nhsprotect.cpod.service.ResponsibilityService;
import uk.nhs.nhsprotect.cpod.service.UserService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminWebTest;
import uk.nhs.nhsprotect.cpod.test.utils.SecurityRequestPostProcessors;

/**
 * Test class to exercise the PersonController.
 * 
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminWebTest
public class CpodUserAdminControllerTest {

    @Autowired
    private UserService userService;

    @Autowired
    private ResponsibilityService responsibilityService;
    /**
     * The web application context as managed by Spring.
     */
    @Autowired
    private WebApplicationContext wac;

    /**
     * The Spring Security filter that intercepts application URLs.
     */
    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    /**
     * The message source used within the app.
     */
    @Autowired
    private MessageSource messageSource;

    /**
     * 
     */
    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * The mocked SpringMVC application instance.
     */
    private MockMvc mockMvc;

    @Autowired
    private SessionFactory sessionFactory;

    /**
     * The non-admin user to use for testing with.
     */
    private final String user = "lsms0246";

    /**
     * The admin user to use for testing.
     */
    private final String adminUser = "lcfs1538";

    /**
     * Method to run before all test methods to create test environment.
     */
    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
                .addFilters(this.springSecurityFilterChain).build();
    }

    /**
     * Tests attempt to access admin function from non-admin account.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testUserSearchNonAdminAccess() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/admin/cpod/searchUser").with(
                SecurityRequestPostProcessors.userDetailsService(user));

        this.mockMvc.perform(requestBuilder).andExpect(
                MockMvcResultMatchers.status().isForbidden());
    }

    /**
     * Tests the user search function.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testSearchUserMultipleUsers() throws Exception {
        // add a new user to get a list size of two
        User user = new User();
        user.setPersonId(2058L);
        user.setUsername("ops0259");
        userService.saveOrUpdate(user);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/admin/cpod/searchUser").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));
        ;
        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the user results are expected i.e. 5 as user not
                        // allowed to edit own account
                        List<User> users = (List<User>) mvcResult
                                .getModelAndView().getModel().get("users");
                        assertEquals(5, users.size());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("user-results"));
    }

    /**
     * Tests the user search function.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testSearchUserSingleUser() throws Exception {

        // delete the other users
        userService.delete(Long.valueOf(3L));
        userService.delete(Long.valueOf(4L));
        userService.delete(Long.valueOf(5L));

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/admin/cpod/searchUser").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the user results are expected i.e. 1 as user not
                        // allowed to edit own account
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("user"));

                    }
                }).andExpect(MockMvcResultMatchers.view().name("user-view"));
    }

    /**
     * Tests the user search function with no matches.
     * 
     * @throws Exception
     *             on error
     */
    @Test
    public void testSearchUserNoMatches() throws Exception {

        // delete the 'other' users
        userService.delete(Long.valueOf(1L));
        userService.delete(Long.valueOf(3L));
        userService.delete(Long.valueOf(4L));
        userService.delete(Long.valueOf(5L));

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/admin/cpod/searchUser").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));
        ;
        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("warnMessage"));
                        assertEquals(messageSource.getMessage(
                                "user.search.none", null, null),
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("warnMessage"));

                    }
                }).andExpect(MockMvcResultMatchers.view().name("user-results"));
    }

    /**
     * Tests the view user function for an existing user.
     * 
     * @throws Exception
     */
    @Test
    public void testViewUser() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/cpod/viewUser")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("id", "1");
        ;
        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the user results are expected i.e. 1 as user not
                        // allowed to edit own account

                        User user = (User) mvcResult.getModelAndView()
                                .getModel().get("user");
                        assertNotNull(user.getId());
                        assertEquals(Long.valueOf(1l), user.getId());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("user-view"));
    }

    /**
     * Tests the view user function with an attempt to view own user details
     * 
     * @throws Exception
     */
    @Test
    public void testViewUserOwnAccount() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/cpod/viewUser")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("id", "2");
        ;
        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the user results are expected i.e. 1 as user not
                        // allowed to edit own account
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("errorMessage"));

                    }
                }).andExpect(MockMvcResultMatchers.view().name("user-view"));
    }

    /**
     * Tests the view user function for new users.
     * 
     * @throws Exception
     */
    @Test
    public void testViewNewAccount() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/admin/cpod/viewUser").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));
        ;
        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        // test the user results are expected i.e. 1 as user not
                        // allowed to edit own account
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("user"));
                        User user = (User) mvcResult.getModelAndView()
                                .getModel().get("user");
                        assertEquals(null, user.getId());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("user-view"));
    }

    /**
     * Tests requests to reset users password to default.
     * 
     * @throws Exception
     */
    @Test
    public void testResetPassword() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/cpod/resetUserPassword")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("id", "1");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.content()
                                .string("Password Reset"));
    }

    /**
     * Tests the request to delete a user.
     * 
     * @throws Exception
     */
    @Test
    public void testDeleteUser() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/admin/cpod/deleteUser")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser)).param("id", "1");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(
                        MockMvcResultMatchers.content().string("User Deleted"));
    }

    /**
     * Tests the save user request for a new user.
     * 
     * @throws Exception
     */
    @Test
    public void testSaveNewUser() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/admin/cpod/saveUser")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("username", "ops0259").param("enabled", "true")
                .param("personId", "2058").param("_enabled", "on")
                .param("authorities", "1").param("authorities", "2")
                .param("_authorities", "on");

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("user"));
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("successMessage"));
                        User user = (User) mvcResult.getModelAndView()
                                .getModel().get("user");
                        // an id has been assigned
                        assertNotNull(user.getId());
                        assertEquals(2, user.getUserAuthorities().size());
                        assertEquals(false, user.isDefaultPasswordChanged());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("user-view"));
    }

    /**
     * Tests the save user request for an existing user.
     * 
     * @throws Exception
     */
    @Test
    public void testUpdateUser() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/admin/cpod/saveUser")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("username", "lcfs1538").param("id", "2")
                .param("personId", "2").param("_enabled", "on")
                .param("_authorities", "on")
                .param("password", passwordEncoder.encode("test"));

        mockMvc.perform(requestBuilder).andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("user"));
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("successMessage"));
                        User user = (User) mvcResult.getModelAndView()
                                .getModel().get("user");
                        // an id has been assigned
                        assertEquals(Long.valueOf(2L), user.getId());
                        assertEquals(0, user.getUserAuthorities().size());
                        assertEquals(false, user.isDefaultPasswordChanged());
                        assertEquals(false, user.isEnabled());

                    }
                }).andExpect(MockMvcResultMatchers.view().name("user-view"));
    }

    /**
     * Tests the prepare password change request.
     * 
     * @throws Exception
     */
    @Test
    public void testPreparePasswordChange() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/changePassword").with(
                SecurityRequestPostProcessors.userDetailsService(adminUser));

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("user"));
                        User user = (User) mvcResult.getModelAndView()
                                .getModel().get("user");
                        assertEquals(Long.valueOf(2L), user.getId());
                        assertEquals(adminUser, user.getUsername());
                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("password-change"));
    }

    /**
     * Tests the change password request for valid input.
     * 
     * @throws Exception
     */
    @Test
    public void testPasswordChangeSuccess() throws Exception {
        // mock submit of successful password change - note old password value
        // from update test above
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/changePassword")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("oldPassword", "help")
                .param("confirmPassword", "C0mplex1!")
                .param("defaultPasswordChanged", "true")
                .param("enabled", "true").param("id", "2")
                .param("personId", "2").param("password", "C0mplex1!");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("successMessage"));
                        assertEquals(messageSource.getMessage(
                                "password.success", null, null),
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("successMessage"));
                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("password-change"));

    }

    /**
     * Tests the change password request for invalid input (old password).
     * 
     * @throws Exception
     */
    @Test
    public void testPasswordChangeFailOldPassword() throws Exception {
        // mock submit of new user with admin and user permissions - old
        // password from above
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/changePassword")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("oldPassword", "anything")
                .param("confirmPassword", "changeit")
                .param("defaultPasswordChanged", "true")
                .param("enabled", "true").param("id", "2")
                .param("personId", "2").param("password", "changeit");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("user"));
                        User user = (User) mvcResult.getModelAndView()
                                .getModel().get("user");
                        assertEquals(Long.valueOf(2L), user.getId());
                        assertEquals(adminUser, user.getUsername());
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("errorMessage"));
                        assertEquals(messageSource.getMessage(
                                "password.error.oldpassword", null, null),
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("errorMessage"));
                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("password-change"));

    }

    /**
     * Tests the change password request for invalid input (no changes).
     * 
     * @throws Exception
     */
    @Test
    public void testPasswordChangeFailNoChange() throws Exception {
        // mock submit of new user with admin and user permissions - old
        // password from above
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/changePassword")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("oldPassword", "help").param("confirmPassword", "help")
                .param("defaultPasswordChanged", "true")
                .param("enabled", "true").param("id", "2")
                .param("personId", "2").param("password", "help");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("user"));
                        User user = (User) mvcResult.getModelAndView()
                                .getModel().get("user");
                        assertEquals(Long.valueOf(2L), user.getId());
                        assertEquals(adminUser, user.getUsername());
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("errorMessage"));
                        assertEquals(messageSource.getMessage(
                                "password.error.nochange", null, null),
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("errorMessage"));
                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("password-change"));

    }

    /**
     * Tests the change password request for invalid input (complexity).
     * 
     * @throws Exception
     */
    @Test
    public void testPasswordChangeFailComplexity() throws Exception {
        // mock submit of new user with admin and user permissions - old
        // password from above
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/changePassword")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("oldPassword", "help")
                .param("confirmPassword", "changeit")
                .param("defaultPasswordChanged", "true")
                .param("enabled", "true").param("id", "2")
                .param("personId", "2").param("password", "changeit");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("user"));
                        User user = (User) mvcResult.getModelAndView()
                                .getModel().get("user");
                        assertEquals(Long.valueOf(2L), user.getId());
                        assertEquals(adminUser, user.getUsername());
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("errorMessage"));
                        assertEquals(messageSource.getMessage(
                                "password.error.complex", null, null),
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("errorMessage"));
                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("password-change"));

    }

    /**
     * Tests the change password request for invalid input (confirm value).
     * 
     * @throws Exception
     */
    @Test
    public void testPasswordChangeFailConfirm() throws Exception {
        // mock submit of new user with admin and user permissions - old
        // password from above
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/changePassword")
                .with(SecurityRequestPostProcessors
                        .userDetailsService(adminUser))
                .param("oldPassword", "help")
                .param("confirmPassword", "changeit1")
                .param("defaultPasswordChanged", "true")
                .param("enabled", "true").param("id", "2")
                .param("personId", "2").param("password", "changeit");

        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(new ResultMatcher() {

                    @Override
                    public void match(MvcResult mvcResult) throws Exception {
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("user"));
                        User user = (User) mvcResult.getModelAndView()
                                .getModel().get("user");
                        assertEquals(Long.valueOf(2L), user.getId());
                        assertEquals(adminUser, user.getUsername());
                        assertNotNull(mvcResult.getModelAndView().getModel()
                                .get("errorMessage"));
                        assertEquals(messageSource.getMessage(
                                "password.error.noconfirm", null, null),
                                (String) mvcResult.getModelAndView().getModel()
                                        .get("errorMessage"));
                    }
                })
                .andExpect(MockMvcResultMatchers.view().name("password-change"));

    }
}
