/**
 * 
 */
package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.cpod.exception.CpodException;
import uk.nhs.nhsprotect.cpod.service.SirsUserService;
import uk.nhs.nhsprotect.cpod.test.utils.SystemUserUtil;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;
import uk.nhs.nhsprotect.sirs.model.SirsUser;

/**
 * Class to SirsAbstractServiceImpl methods.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/applicationContext.xml",
        "classpath:spring/hibernateContext.xml" })
@ActiveProfiles("junit")
@TransactionConfiguration(transactionManager = "sirsTransactionManager")
@Transactional
public class SirsAbstractServiceImplTest {

    /**
     * SirsUserService reference.
     */
    @Autowired
    private SirsUserService sirsUserService;

    /**
     * Reference Number for user created in SirsSetup script.
     */
    private final String referenceNumber = "lsms0246";

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#save(java.lang.Object)}
     * .
     * @throws Exception
     */
    @Test
    public void testSave() throws Exception {
        SirsUser newSirsUser = new SirsUser("lcfs1538",
                CPODConstants.SIRS_EXTERNAL_DEFAULT_PASSWORD, 1, 0);
        newSirsUser.setPersonId(Long.valueOf(2l));
        newSirsUser.setAuthorities(SystemUserUtil
                .getSIRSLSMSUserAuthorities(newSirsUser));
        sirsUserService.save(newSirsUser);

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#delete(java.lang.Object)}
     * .
     * @throws Exception
     */
    @Test
    public void testDelete() throws Exception {
        SirsUser toDelete = SystemUserUtil.getSIRSLSMSUser("lsms0657");
        sirsUserService.delete(toDelete);
        assertEquals(1, sirsUserService.findAll().size());

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#findAll()}
     * .
     * @throws Exception
     */
    @Test
    public void testFindAll() throws Exception {
        assertEquals(2, sirsUserService.findAll().size());

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#deleteAll()}
     * .
     * @throws Exception
     */
    @Test(expected = CpodException.class)
    public void testDeleteAll() throws Exception {
        sirsUserService.deleteAll();

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#saveOrUpdate(java.lang.Object)}
     * .
     * @throws Exception
     */
    @Test
    public void testSaveOrUpdateAsUpdate() throws Exception {
        SirsUser existing = sirsUserService.findById(referenceNumber);
        existing.setFailedAttempts(3);
        sirsUserService.saveOrUpdate(existing);
        SirsUser updated = sirsUserService.findById(referenceNumber);
        assertEquals(existing.getFailedAttempts(), updated.getFailedAttempts());

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#findById(java.io.Serializable)}
     * .
     * @throws Exception
     */
    @Test
    public void testFindById() throws Exception {
        SirsUser expected = SystemUserUtil.getSIRSLSMSUser("lsms0246");
        SirsUser actual = sirsUserService.findById(referenceNumber);
        assertEquals(expected, actual);

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#update(java.lang.Object)}
     * .
     * @throws Exception
     */
    @Test
    public void testUpdate() throws Exception {
        SirsUser actual = sirsUserService.findById(referenceNumber);
        actual.setUsername("UPDATED");
        sirsUserService.update(actual);
        assertEquals(actual, sirsUserService.findById(referenceNumber));

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#findByCriteria(org.hibernate.criterion.Criterion)}
     * .
     * @throws Exception
     */
    @Test
    public void testFindByCriteria() throws Exception {
        List<SirsUser> actual = sirsUserService.findByCriteria(Restrictions
                .ilike("username", "lsms", MatchMode.START));
        assertEquals(2, actual.size());

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#findByAndCriterias(java.util.Map)}
     * .
     */
    @Test
    public void testFindByAndCriterias() {
        Map<String, String> searchCriteria = new HashMap<String, String>();
        searchCriteria.put("username", "lsms");
        searchCriteria.put("password", "657f8b8da628ef83cf69101b6817150a");
        searchCriteria.put("personId", "4");
        List<SirsUser> actual = sirsUserService
                .findByAndCriterias(searchCriteria);
        assertEquals(1, actual.size());// lsms0657 matches

    }

    /**
     * Test method for
     * {@link uk.nhs.nhsprotect.cpod.service.impl.SirsAbstractServiceImpl#merge(java.lang.Object)}
     * .
     * @throws Exception
     */
    @Test
    public void testMerge() throws Exception {
        SirsUser actual = sirsUserService.findById(referenceNumber);
        actual.setUsername("UPDATED");
        sirsUserService.merge(actual);
        assertEquals(actual, sirsUserService.findById(referenceNumber));

    }

}
