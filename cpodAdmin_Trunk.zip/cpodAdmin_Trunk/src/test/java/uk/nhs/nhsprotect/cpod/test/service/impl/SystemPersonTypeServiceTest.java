package uk.nhs.nhsprotect.cpod.test.service.impl;

import org.hibernate.SessionFactory;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.service.SystemPersonTypeService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;

/**
 * Test class for the SystemPersonTypeService interface implementation.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
@Ignore
public class SystemPersonTypeServiceTest {

    /**
     * Gives access to SystemService.
     */

    @Autowired
    private SystemPersonTypeService systemPersonTypeService;

    @Autowired
    private SessionFactory sessionFactory;

    // TODO what are we going to check?
}
