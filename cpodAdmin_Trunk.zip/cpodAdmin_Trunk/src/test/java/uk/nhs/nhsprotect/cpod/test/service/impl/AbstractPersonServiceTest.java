package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.DaoNotImplementedException;
import uk.nhs.nhsprotect.cpod.model.Address;
import uk.nhs.nhsprotect.cpod.model.AddressLink;
import uk.nhs.nhsprotect.cpod.model.AddressType;
import uk.nhs.nhsprotect.cpod.model.NHSPSection;
import uk.nhs.nhsprotect.cpod.model.Organisation;
import uk.nhs.nhsprotect.cpod.model.Person;
import uk.nhs.nhsprotect.cpod.model.PersonNote;
import uk.nhs.nhsprotect.cpod.model.PersonRole;
import uk.nhs.nhsprotect.cpod.model.PersonType;
import uk.nhs.nhsprotect.cpod.service.AddressLinkService;
import uk.nhs.nhsprotect.cpod.service.AddressService;
import uk.nhs.nhsprotect.cpod.service.OrganisationService;
import uk.nhs.nhsprotect.cpod.service.PersonRoleService;
import uk.nhs.nhsprotect.cpod.service.PersonService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;
import uk.nhs.nhsprotect.cpod.test.utils.DateUtils;
import uk.nhs.nhsprotect.cpod.test.utils.PersonUtils;
import uk.nhs.nhsprotect.cpod.util.CPODConstants;

/**
 * Class to test the methods offered by the AbstractService<T, ID> interface.
 * @author awheatley
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class AbstractPersonServiceTest {

    /**
     * Gives access to personService.
     */
    @Autowired
    private PersonService personService;

    /**
     * Gives access to personService.
     */
    @Autowired
    private PersonRoleService personRoleService;

    /**
     * Gives access to addressLinkService.
     */
    @Autowired
    private AddressLinkService addressLinkService;

    /**
     * Gives access to addressService.
     */
    @Autowired
    private AddressService addressService;

    /**
     * Access the organisationService.
     */
    @Autowired
    private OrganisationService organisationService;

    /**
     * Access the sessionFactory.
     */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Person1 instance for testing.
     */
    private Person person;

    /**
     * Person2 instance for testing.
     */
    private Person person2;

    /**
     * Setup for each test.
     * @throws Exception for error
     */

    /**
     * Person Role instance for testing.
     */
    private PersonRole personRole;

    private List<PersonRole> personRoles = new ArrayList<PersonRole>();
    /**
     * Person2 Role instance for testing.
     */
    private PersonRole personRole2;

    /**
     * Setup for each test.
     * @throws Exception for error
     */

    @Before
    public void setUp() throws Exception {
        tearDown();
        // TODO do we insert this as part of setup?
        person = PersonUtils.createPersonSteveJobs();
        personService.save(person);
        // verify database

        personRole = new PersonRole();
        personRole = PersonUtils.PersonRolelcfs1234(person.getId());
        personRoleService.save(personRole);

        personRoles.add(personRole);

        person.setPersonRoles(personRoles);

        personService.save(person);

        sessionFactory.getCurrentSession().flush();
        // fully populate references
        sessionFactory.getCurrentSession().refresh(person);

    }

    /**
     * Remove test data after tests complete.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws Exception {
        if (person != null) {
            personService.delete(person);
        }
        if (person2 != null) {
            personService.delete(person2);
        }
    }

    /**
     * Method to test the findById function.
     * @throws Exception for error
     */
    @SuppressWarnings({ "unchecked", "null" })
    @Test
    public void testFindById() throws Exception {
        Person person01 = personService.findById(person.getId());
        // test manager relationship
        List<PersonRole> personRoles = person01.getPersonRoles();
        List<Person> personManagers = new ArrayList<Person>();

        // for (@SuppressWarnings("unused") PersonRole personRole : personRoles)
        // {
        // personManagers.add(person.getPersonRoles().getManager());
        // }

        assertEquals(person, person01);

        // //TODO Possible multiple managers so is test relevant?

        // Set<Person> subs = managers.get(0).getSubordinates();
        // assertEquals(1, subs.size());
        // assertEquals(person01, (Person) subs.toArray()[0]);
        // assertEquals(person, person01);
        // test fullname utility method

        assertEquals("Mr Steve Jobs", person01.getfullName());

        // //TODO MANAGER STUFF
        // // test responsibilities - manager has them
        // Set<Responsibility> resps = manager.getResponsibilities();
        // List responsibilities = Arrays.asList(resps.toArray());
        // Collections.sort(responsibilities);
        //
        // assertEquals(2, responsibilities.size());
        //
        // Responsibility responsibility1 = (Responsibility) responsibilities
        // .get(0);
        // // test org is OK
        // assertEquals(Long.valueOf(5448L), responsibility1.getOrganisation()
        // .getId());
        // assertEquals(manager.getId(), responsibility1.getPerson().getId());
        // assertEquals(false, responsibility1.isLead());// test lead
        // assertEquals(Long.valueOf(1097L), responsibility1.getId());
        //
        // Responsibility responsibility2 = (Responsibility) responsibilities
        // .get(1);
        // // test org is OK
        // assertEquals(Long.valueOf(5449L), responsibility2.getOrganisation()
        // .getId());
        // assertEquals(manager.getId(), responsibility2.getPerson().getId());
        // assertEquals(Long.valueOf(1096L), responsibility2.getId());
        // assertEquals(false, responsibility2.isLead());// test lead
        //
        // // test address links
        // Set<AddressLink> addresses = manager.getAddressLinks();
        // List addressList = Arrays.asList(addresses.toArray());
        // AddressLink addressLink = (AddressLink) addressList.get(0);
        // assertEquals(1, addressList.size());
        // assertEquals(Long.valueOf("2"), addressLink.getAddress().getId());
        // assertEquals(CPODConstants.ADDRESS_TYPE_HOME_ID, addressLink
        // .getAddress().getAddressType().getId());
        // // test address utility - no work addresses but 1 home
        // Address workAddress = manager.getWorkAddress();
        // assertEquals(true, workAddress.isEmpty());
        // Address homeAddress = manager.getHomeAddress();
        // assertEquals(false, homeAddress.isEmpty());
        // assertEquals(Long.valueOf("2"), homeAddress.getId());
        // assertEquals(CPODConstants.ADDRESS_TYPE_HOME_ID, homeAddress
        // .getAddressType().getId());

        // verify database
        sessionFactory.getCurrentSession().flush();

    }

    /**
     * Saved Person is searched for in DB and compared to the data used to save
     * it. Checks if a record is found based on the PersonId.
     * @throws Exception for error
     */
    @Test
    public void testSave() throws Exception {

        // TODO
        // find all test size
        // create new person and insert
        // find all and test size increased
        Person found = personService.findById(person.getId());
        assertEquals(person, found);
        // ensure that DB state can be verified
        sessionFactory.getCurrentSession().flush();

    }

    /**
     * Adds second person to database and returns all records associated with
     * the Person class. checks that four records are returned
     * @throws Exception for error
     */
    @Test
    public void testFindAll() throws Exception {
        person2 = PersonUtils.createPersonBillGates();
        personService.save(person2);

        // we insert 5 persons with setup and we insert two further records in
        // this test - one in local setup and the one above - expect 7
        List<Person> persons = personService.findAll();
        assertEquals(7, persons.size());

        sessionFactory.getCurrentSession().flush();
    }

    /**
     * Delete User Test.
     * @throws Exception for error
     */
    @Test
    public void testDelete() throws Exception {
        Person toDelete = PersonUtils.createPersonBillGates();
        personService.save(toDelete);
        personService.delete(toDelete);
        assertNull(personService.findById(toDelete.getId()));
        // ensure that DB state can be verified
        sessionFactory.getCurrentSession().flush();

    }

    /**
     * Delete All Users test. not implemented for Person objects so expect
     * exception.
     * @throws Exception for error
     */
    @Test(expected = DaoNotImplementedException.class)
    public void testDeleteAll() throws Exception {
        personService.deleteAll();
        // ensure that DB state can be verified
        sessionFactory.getCurrentSession().flush();

    }

    /**
     * Save or Update User Changes forename and surname of person. and saves to
     * database. Then nulls the ID so the database should save(insert) a new
     * record instead of updating it Checks database to confirm new record
     * exists were applied.
     * @throws Exception for error
     */
    @Test
    public void testSaveOrUpdateAsUpdate() throws Exception {

        Person person01 = personService.findById(person.getId());
        assertNotNull(person01);
        assertEquals(person.getForeName(), person01.getForeName());
        assertEquals(person.getSurName(), person01.getSurName());

        person01.setForeName("Bill");
        person01.setSurName("Gates");
        // should be an update
        personService.saveOrUpdate(person01);
        // commit
        sessionFactory.getCurrentSession().flush();

        // TODO do find all to check that the person has not been inserted.
        Person found = personService.findById(person01.getId());
        assertNotNull(found);
        assertEquals("Bill", found.getForeName());
        assertEquals("Gates", found.getSurName());
        // ensure that DB state can be verified
        sessionFactory.getCurrentSession().flush();

    }

    /**
     * Save or Update User Changes forename and surname of person. and saves to
     * database. Then nulls the ID so the database should save(insert) a new
     * record instead of updating it Checks database to confirm new record
     * exists were applied.
     * @throws Exception for error
     */
    @Test
    public void testSaveOrUpdateAsSave() throws Exception {

        // Person person01 = new Person();

        Person person01 = new Person();

        // replicate what we will get from the screen. TODO
        BeanUtils.copyProperties(person, person01);

        person01.setForeName("Nick");
        person01.setSurName("Tones");
        person01.setId(null);
        // person01.setSubordinates(null);
        person01.setAddressLinks(new HashSet<AddressLink>());

        PersonType personType = new PersonType(
                (long) CPODConstants.PERSON_TYPE_LCFS_ID,
                CPODConstants.PERSON_TYPE_LCFS_DESC);
        PersonRole lcfsRole = new PersonRole(null, personType, "NTONES",
                DateUtils.parseDate("01/01/0001"),
                DateUtils.parseDate("31/12/9999"));

        List<PersonRole> personRole1 = new ArrayList<PersonRole>();
        personRole1.add(lcfsRole);

        person01.setPersonRoles(personRole1);

        // Add a link to and address new address or an existing.
        Address newAddress = new Address();

        newAddress.setAddress1("Line 1");
        newAddress.setAddress2("Line 2");
        newAddress.setAddress3("Line 3");
        newAddress.setAddress4("Line 4");
        newAddress.setAddress5("Line 5");
        newAddress.setPostcode("postcode");
        newAddress.setAddressType(new AddressType(
                CPODConstants.ADDRESS_TYPE_WORK_ID));
        newAddress.setModifiedByUser("JUNIT");

        person01.setWorkAddress(newAddress);

        // need to remove reference to original persons personNotes list.
        person01.setPersonNotes(new ArrayList<PersonNote>());
        // TODO add required fields
        // should be an update
        personService.saveOrUpdate(person01);
        // commit the insert
        sessionFactory.getCurrentSession().flush();

        // TODO do find all to check that the person has not been inserted.
        Person found = personService.findById(person01.getId());
        assertNotNull(found);
        assertEquals("Nick", found.getForeName());
        assertEquals("Tones", found.getSurName());
        // ensure that DB state can be verified
        sessionFactory.getCurrentSession().flush();

    }

    /**
     * Update User Test.
     * @throws Exception for error
     */
    @Test
    public void testUpdate() throws Exception {

        Person person01 = personService.findById(person.getId());
        assertNotNull(person01);
        assertEquals(person, person01);

        // Create a date
        String strDate = "13/09/2011";
        Date date = DateUtils.parseDate(strDate);

        // Reference an existing organisation
        Organisation organisation = new Organisation();
        organisation.setId(5448L);

        // Reference an existing Person as Manager
        Person manager = new Person();
        manager.setId(2L);

        // Reference an nhspDepartment
        NHSPSection nhspSection = new NHSPSection();
        nhspSection.setId(6873L);

        // Reference a person type
        PersonType personType = new PersonType();
        personType.setId(1L);

        // Set all attributes (except ID) to proce update and coverage
        person01.setDob(date);
        person01.setEmailNHS("bill.gates@microsoft.com");
        person01.setEmailOther("billy@msdn.com");
        person01.setEmployerOrganisation(organisation);
        // person01.setEndDate(date);
        person01.setEsrID(9876L);
        person01.setExt("1234");
        person01.setFax("2345");
        person01.setForeName("Bill");
        person01.setForeName2("Ben");
        person01.setFraudComplete(Boolean.TRUE);
        person01.setFraudDate(date);
        // person01.setId(person.getId());
        // person01.setJobTitle("CEO");
        person01.setKnownAs("Bill");
        // person01.setManager(manager);
        person01.setMobile("07777777");
        person01.setModifiedByUser("Alan");
        person01.setNhspSection(nhspSection);
        // person01.setPersonRef("CC");
        // person01.setPersonType(personType);
        person01.setProprietryComplete(Boolean.TRUE);
        person01.setProprietryDate(date);
        // person01.setReason("Just testing");
        // person01.setRegion(region);
        person01.setSecurityComplete(Boolean.TRUE);
        person01.setSecurityDate(date);
        // person01.setStartDate(date);
        person01.setStatus("A");
        person01.setSurName("Gates");
        person01.setTelephone("5543");
        person01.setTelephone2("9897");
        person01.setTitle("Mr");

        // Update Person01
        personService.update(person01);

        // commit
        sessionFactory.getCurrentSession().flush();

        // Reload Person as found
        Person found = personService.findById(person01.getId());

        // Person should equal found
        assertEquals(person01, found);

        // All found attributes checked for uddate test and coverage
        assertEquals(date, found.getDob());
        assertEquals("bill.gates@microsoft.com", found.getEmailNHS());
        assertEquals("billy@msdn.com", found.getEmailOther());
        assertEquals(organisation.getId(), found.getEmployerOrganisation()
                .getId());
        // assertEquals(date, found.getEndDate());
        assertEquals((Long) 9876L, found.getEsrID());
        assertEquals("1234", found.getExt());
        assertEquals("2345", found.getFax());
        assertEquals("Bill", found.getForeName());
        assertEquals("Ben", found.getForeName2());
        assertEquals(Boolean.TRUE, found.getFraudComplete());
        assertEquals(date, found.getFraudDate());
        // assertEquals(getId(person.getId()));
        // assertEquals("CEO", found.getJobTitle());
        assertEquals("Bill", found.getKnownAs());
        // assertEquals(manager.getId(), found.getManager().getId());
        assertEquals("07777777", found.getMobile());
        assertEquals("Alan", found.getModifiedByUser());
        assertEquals(nhspSection.getId(), found.getNhspSection().getId());
        // assertEquals("CC", found.getPersonRef());
        // assertEquals(personType, found.getPersonType());
        assertEquals(Boolean.TRUE, found.getProprietryComplete());
        assertEquals(date, found.getProprietryDate());
        // assertEquals("Just testing", found.getReason());
        assertEquals(Boolean.TRUE, found.getSecurityComplete());
        assertEquals(date, found.getSecurityDate());
        // assertEquals(date, found.getStartDate());
        assertEquals("A", found.getStatus());
        assertEquals("Gates", found.getSurName());
        assertEquals("5543", found.getTelephone());
        assertEquals("9897", found.getTelephone2());
        assertEquals("Mr", found.getTitle());

        // TODO Test lazy loading of Orgname - FAILS at the moment

        // // //Method1
        // // Organisation org = new Organisation();
        // // org =
        // //
        // organisationService.findById(person01.getEmployerOrganisation().getId());
        // // String x = org.getOrgName();
        // //
        // //
        // // //Method2
        //
        // String name = person01.getEmployerOrganisation().getOrgName();
        // name = name + "";
        //
        // Person person02 = personService.findById(person.getId());
        // name = person02.getEmployerOrganisation().getOrgName();
        //
        // // NOT implemented error
        // // Organisation org =
        //
        // // Check ToString
        // assertEquals(
        // "Person [id="
        // + person01.getId()
        // +
        // ", employerOrganisation=Organisation [id=5448, orgCode=null, organisationType=null, orgName=null, openDate=null, closeDate=null, statusCode=null, medicalStaffQty=null, nonMedicalStaffQty=null, region=null, address=null], esrID=9876, personRef=CC, personType=PersonType [id=1, description=null], title=Mr, foreName=Bill, foreName2=Ben, surName=Gates, knownAs=Bill, dob=Tue Sep 13 00:00:00 BST 2011, jobTitle=CEO, modifiedByUser=Alan, status=A, reason=Just testing, emailNHS=bill.gates@microsoft.com, emailOther=billy@msdn.com, telephone=5543, telephone2=9897, ext=1234, fax=2345, mobile=07777777, startDate=Tue Sep 13 00:00:00 BST 2011, endDate=Tue Sep 13 00:00:00 BST 2011, proprietryComplete=Y, proprietryDate=Tue Sep 13 00:00:00 BST 2011, fraudComplete=Y, fraudDate=Tue Sep 13 00:00:00 BST 2011, securityComplete=Y, securityDate=Tue Sep 13 00:00:00 BST 2011, personType=PersonType [id=1, description=null], region=Region [id=1, regionCode=null, region=null], manager=Person [id=2, employerOrganisation=null, esrID=null, personRef=null, personType=null, title=null, foreName=null, foreName2=null, surName=null, knownAs=null, dob=null, jobTitle=null, modifiedByUser=null, status=null, reason=null, emailNHS=null, emailOther=null, telephone=null, telephone2=null, ext=null, fax=null, mobile=null, startDate=null, endDate=null, proprietryComplete=null, proprietryDate=null, fraudComplete=null, fraudDate=null, securityComplete=null, securityDate=null, personType=null, region=null, manager=null]]",
        // found.toString());

        // ensure that DB state can be verified
        sessionFactory.getCurrentSession().flush();

    }

    /**
     * Test for all records based on first two characters of forename.
     * @throws Exception for error
     */
    @Test
    public void testFindByCriteria() throws Exception {

        Criterion criterion = Restrictions.ilike("foreName", person
                .getForeName().substring(0, 2), MatchMode.START);
        List<Person> persons = personService.findByCriteria(criterion);
        assertEquals(1, persons.size());
        assertEquals(person, persons.iterator().next());
        // ensure that DB state can be verified
        sessionFactory.getCurrentSession().flush();

    }

    /**
     * Test for all records based on first two characters of forename and
     * surname using and criteria.
     * @throws Exception for error
     */
    @Test
    public void testFindByAndCriteria() throws Exception {

        Map<String, String> criteriaMap = new HashMap<String, String>();
        criteriaMap.put("foreName", person.getForeName().substring(0, 2));
        criteriaMap.put("surName", person.getSurName().substring(0, 2));
        criteriaMap.put("id", Long.toString(person.getId()));
        List<Person> persons = personService.findByAndCriterias(criteriaMap);
        assertEquals(1, persons.size());
        assertEquals(person, persons.iterator().next());
        // ensure that DB state can be verified
        sessionFactory.getCurrentSession().flush();

    }
}
