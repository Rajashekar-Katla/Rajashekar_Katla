package uk.nhs.nhsprotect.cpod.test.controller;

import static org.junit.Assert.assertEquals;

import javax.servlet.http.HttpSession;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminWebTest;
import uk.nhs.nhsprotect.cpod.test.utils.SecurityRequestPostProcessors;

/**
 * Test class to exercise the CommonPagesController.
 * @author ntones
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminWebTest
public class CommonPagesControllerAuthenticationTest {
    private static String SEC_CONTEXT_ATTR = HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY;

    /**
     * The Spring Security filter that intercepts application URLs.
     */
    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    /**
     * The web application context as managed by Spring.
     */
    @Autowired
    private WebApplicationContext wac;

    /**
     * The mocked SpringMVC application instance.
     */
    private MockMvc mockMvc;

    /**
     * The user to use for testing with 'user' access level.
     */
    private final String user = "lsms0246";

    /**
     * Method to run before all test methods to create test environemnt.
     */
    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
                .addFilters(this.springSecurityFilterChain).build();
    }

    /**
     * Test that attempts to access /login redirects correctly.
     * @throws Exception on error
     */
    @Test
    public void testCommonPagesControllerLogin() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/login");
        this.mockMvc.perform(requestBuilder).andExpect(
                MockMvcResultMatchers.view().name("login"));
    }

    /**
     * Test that attempts to access a URL that require authentication are
     * redirected to enforce login.
     * @throws Exception on error
     */
    @Test
    public void requiresAuthentication() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/");

        mockMvc.perform(requestBuilder).andExpect(
                MockMvcResultMatchers.redirectedUrl("http://localhost/login"));
    }

    /**
     * Test that an authenticated user is allowed access to restricted
     * resources.
     * @throws Exception on error
     */
    @Test
    public void accessGranted() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/").with(
                SecurityRequestPostProcessors.userDetailsService("lcfs1538"));
        this.mockMvc.perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("search-view"));
    }

    /**
     * Test that a user without correct permission is unable to access
     * restricted resources.
     * @throws Exception on error
     */
    @Test
    public void accessDenied() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/admin/cpod")
                .with(SecurityRequestPostProcessors.userDetailsService(user));
        this.mockMvc.perform(requestBuilder).andExpect(
                MockMvcResultMatchers.status().isForbidden());
    }

    /**
     * Test to check that a valid user is authenticated and security context
     * created appropriately.
     * @throws Exception on error
     */
    @Test
    public void testSpringSecurityLogin() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/resources/j_spring_security_check")
                .param("j_username", "lcfs1538").param("j_password", "help");

        mockMvc.perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.redirectedUrl("/"))
                .andExpect(new ResultMatcher() {
                    public void match(final MvcResult mvcResult)
                            throws Exception {
                        HttpSession session = mvcResult.getRequest()
                                .getSession();
                        SecurityContext securityContext = (SecurityContext) session
                                .getAttribute(SEC_CONTEXT_ATTR);
                        assertEquals("lcfs1538", securityContext
                                .getAuthentication().getName());
                        assertEquals(1, securityContext.getAuthentication()
                                .getAuthorities().size());
                    }
                });
    }

    /**
     * Test to check that an invalid user is not authenticated and security
     * context created appropriately.
     * @throws Exception on error
     */
    @Test
    public void testSpringSecurityLoginFailureInvalidPassword()
            throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/resources/j_spring_security_check")
                .param("j_username", user)
                .param("j_password", "invalidPassword");

        mockMvc.perform(requestBuilder)
                .andExpect(
                        MockMvcResultMatchers
                                .redirectedUrl("/login?login_error=t"))
                .andExpect(new ResultMatcher() {
                    public void match(final MvcResult mvcResult)
                            throws Exception {
                        HttpSession session = mvcResult.getRequest()
                                .getSession();
                        SecurityContext securityContext = (SecurityContext) session
                                .getAttribute(SEC_CONTEXT_ATTR);
                        Assert.assertNull(securityContext);
                    }
                });
    }

    /**
     * Test to check that an invalid user is not authenticated and security
     * context created appropriately.
     * @throws Exception on error
     */
    @Test
    public void testSpringSecurityLoginFailureInvalidUser() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/resources/j_spring_security_check")
                .param("j_username", "unknown").param("j_password", "help");

        mockMvc.perform(requestBuilder)
                .andExpect(
                        MockMvcResultMatchers
                                .redirectedUrl("/login?login_error=t"))
                .andExpect(new ResultMatcher() {
                    public void match(final MvcResult mvcResult)
                            throws Exception {
                        HttpSession session = mvcResult.getRequest()
                                .getSession();
                        SecurityContext securityContext = (SecurityContext) session
                                .getAttribute(SEC_CONTEXT_ATTR);
                        Assert.assertNull(securityContext);
                    }
                });
    }

    /**
     * Test to check that an invalid user is not authenticated and security
     * context created appropriately.
     * @throws Exception on error
     */
    @Test
    public void testLoginUserDefaultPasswordChange() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/index")
                .with(SecurityRequestPostProcessors.userDetailsService(user));
        mockMvc.perform(requestBuilder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.view().name("password-change"))
                .andExpect(new ResultMatcher() {
                    public void match(final MvcResult mvcResult)
                            throws Exception {

                        HttpSession session = mvcResult.getRequest()
                                .getSession();
                        SecurityContext securityContext = (SecurityContext) session
                                .getAttribute(SEC_CONTEXT_ATTR);
                        Assert.assertNotNull(securityContext);
                        assertEquals(securityContext.getAuthentication()
                                .getName(), user);
                        assertEquals(securityContext.getAuthentication()
                                .getAuthorities().size(), 1);
                    }
                });
    }
}
