package uk.nhs.nhsprotect.cpod.test.service.impl;

import static org.junit.Assert.assertEquals;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import uk.nhs.nhsprotect.cpod.dao.exception.CpodNoResultsReturnedException;
import uk.nhs.nhsprotect.cpod.model.Responsibility;
import uk.nhs.nhsprotect.cpod.service.ResponsibilityService;
import uk.nhs.nhsprotect.cpod.test.annotation.CpodAdminServiceTest;
import uk.nhs.nhsprotect.cpod.test.utils.DateUtils;

/**
 * @author awheatley
 */
@RunWith(SpringJUnit4ClassRunner.class)
@CpodAdminServiceTest
public class ResponsbilityServiceTest {

    /**
     * Gives access to ResponsibilityService.
     */
    @Autowired
    private ResponsibilityService responsibilityService;

    /**
     * Gives access to Organisation Class.
     */
    @SuppressWarnings("unused")
    private Responsibility responsibility;

    /**
     * Setup for each test that runs.
     * @throws Exception for error
     */
    @Before
    public void setUp() throws Exception {

    }

    /**
     * Teardown of data after tests complete.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws Exception {

    }

    /**
     * Find Responsibility based on personId = 1.
     * @throws Exception for error
     */
    @Test
    public void testResponsibilityByPersonRoleId() throws Exception {

        // find record
        List<Responsibility> found = responsibilityService
                .findResponsibilityByPersonRoleId(1L);

        // Sort List by startDate, organisationName
        Collections.sort(found);

        assertEquals(2, found.size());

        Date startDate = DateUtils.parseDate("01/03/2010");
        Date endDate = DateUtils.parseDate("31/12/9999");

        // create expected instances
        Responsibility expectedPerson1Responsibility1 = new Responsibility();
        expectedPerson1Responsibility1.setId(1095L);
        expectedPerson1Responsibility1.setPersonRoleId("1");
        expectedPerson1Responsibility1.setOrganisationId("5448");
        expectedPerson1Responsibility1.setStartDate(startDate);
        expectedPerson1Responsibility1.setEndDate(endDate);
        expectedPerson1Responsibility1.setLead(false);

        Responsibility expectedPerson1Responsibility2 = new Responsibility();
        expectedPerson1Responsibility2.setId(1098L);
        expectedPerson1Responsibility2.setPersonRoleId("1");
        expectedPerson1Responsibility2.setOrganisationId("5449");
        expectedPerson1Responsibility2.setStartDate(DateUtils
                .parseDate("27/05/2010"));
        expectedPerson1Responsibility2.setEndDate(endDate);
        expectedPerson1Responsibility2.setLead(true);

        // compare results
        assertEquals(expectedPerson1Responsibility1, found.get(0));
        assertEquals(expectedPerson1Responsibility2, found.get(1));
    }

    /**
     * Test Save or Update
     * @throws Exception for error
     */
    @Test
    public void testResponsibilitySaveOrUpdate() throws Exception {

        Responsibility savingNewResp = new Responsibility();

        Date startDate = DateUtils.parseDate("11/04/2000");
        Date endDate = DateUtils.parseDate("31/12/9999");

        // savingNewResp.setId(1095L);
        savingNewResp.setPersonRoleId("1");
        savingNewResp.setOrganisationId("5448");
        savingNewResp.setStartDate(startDate);
        savingNewResp.setEndDate(endDate);
        savingNewResp.setLead(false);
        savingNewResp.setModifiedByUser("alan");
        responsibilityService.saveOrUpdate(savingNewResp);

        // find record
        List<Responsibility> found = responsibilityService
                .findResponsibilityByPersonRoleId(1L);

        // Sort List by startDate, organisationName
        Collections.sort(found);

        assertEquals(3, found.size());
        // compare results
        assertEquals(savingNewResp, found.get(0));

    }

    /**
     * Find Responsibility based on orgId = 5448
     * @throws Exception for error
     */
    @Test
    public void testResponsibilityByOrgId() throws Exception {

        // find record
        List<Responsibility> found = responsibilityService
                .findResponsibilityByOrgId(5448L);

        // Sort List by startDate, organisationName
        Collections.sort(found);

        assertEquals(found.size(), 2);

        // create expected instances
        Date startDate = DateUtils.parseDate("01/03/2010");
        Date endDate = DateUtils.parseDate("31/12/9999");

        Responsibility expectedOrg1Responsibility1 = new Responsibility();
        expectedOrg1Responsibility1.setId(1095L);
        expectedOrg1Responsibility1.setPersonRoleId("1");
        expectedOrg1Responsibility1.setOrganisationId("5448");
        expectedOrg1Responsibility1.setStartDate(startDate);
        expectedOrg1Responsibility1.setEndDate(endDate);
        expectedOrg1Responsibility1.setLead(false);

        Responsibility expectedOrg1Responsibility2 = new Responsibility();
        expectedOrg1Responsibility2.setId(1097L);
        expectedOrg1Responsibility2.setPersonRoleId("2");
        expectedOrg1Responsibility2.setOrganisationId("5448");
        expectedOrg1Responsibility2.setStartDate(DateUtils
                .parseDate("27/05/2010"));
        expectedOrg1Responsibility2.setEndDate(endDate);
        expectedOrg1Responsibility2.setLead(false);

        // compare results
        assertEquals(found.get(0), expectedOrg1Responsibility1);
        assertEquals(found.get(1), expectedOrg1Responsibility2);
    }

    /**
     * Find non existing Responsibility for findBy OrgID
     * CpodNoResultsReturnedException should be thrown.
     * @throws Exception for error
     */
    @Test(expected = CpodNoResultsReturnedException.class)
    public void testResponsibilitybyOrgIdNoReulsts() throws Exception {

        @SuppressWarnings("unused")
        List<Responsibility> found = responsibilityService
                .findResponsibilityByOrgId(99999L);
    }

    /**
     * Find non existing Responsibility for findBy PersonID
     * @throws Exception for error
     */
    public void testResponsibilitybyPersonIdNoReulsts() throws Exception {
        List<Responsibility> found = responsibilityService
                .findResponsibilityByPersonRoleId(99999L);
        assertEquals(0, found.size());
    }
}
