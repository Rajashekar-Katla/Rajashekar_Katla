-- Tear down the existing data in database tables for future tests.

Delete from RESULTS_TBL;

Delete from QUESTIONNAIRE_RATING_TBL;

Delete from QUESTIONNAIRE_TBL;

Delete from REGION_ORG_TBL;

Delete from SRT_STATUS_TBL;

Delete from ANNUAL_BUDGET_TBL;

Delete from STAFF_HEADCOUNT_TBL;

Delete from  SRT_YEAR_RANGE_TBL;

delete from USER_AUTHORITIES_TBL;

delete from users;

delete from authorities_tbl;

delete from regions_tbl;

delete from ORGANISATION_TYPE_TBL;

delete from SECTION_TBL;

