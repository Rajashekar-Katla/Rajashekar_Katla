--teardown

-- 11
Delete from cpodjunit.responsibilities_tbl;
-- 10
Delete from cpodjunit.address_link_tbl;
Delete from CPODJUNIT.PERSON_ROLE_TBL;
-- 7
Delete from cpodjunit.person_tbl;
-- 6
Delete from cpodjunit.person_type_tbl;
-- 5a
Delete from CPODJUNIT.REGIONS_LINK_TBL;
-- 5
Delete from cpodjunit.organisations_tbl;
-- 4
Delete from cpodjunit.org_type_tbl;
-- 3a
Delete from cpodjunit.regions_tbl;
-- 3
Delete from cpodjunit.regions_type_tbl;
-- 2
Delete from cpodjunit.address_tbl;
-- 1
delete from cpodjunit.address_type_tbl;



--set escape on

-- 1. Insert Address Type

Insert into CPODJUNIT.ADDRESS_TYPE_TBL
   (ADDRESS_TYPE_ID, ADDRESS_TYPE, MODIFIED_BY_USER)
 Values
   (1, 'Work', 'ETL');
Insert into CPODJUNIT.ADDRESS_TYPE_TBL
   (ADDRESS_TYPE_ID, ADDRESS_TYPE, MODIFIED_BY_USER)
 Values
   (2, 'Home', 'ETL');


Insert into cpodjunit.ADDRESS_TYPE_TBL (ADDRESS_TYPE_ID,ADDRESS_TYPE,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (3,'ORGANISATION','jpearson',to_timestamp('13-APR-2015 11.29.10.680720000','DD-MON-YYYY HH24.MI.SSXFF'));

-- 2. Address Table



Insert into cpodjunit.ADDRESS_TBL
   (ADDRESS_ID, ADDRESS_LINE1, ADDRESS_LINE2, ADDRESS_LINE3, ADDRESS_LINE4, POSTCODE, ADDRESS_TYPE_ID, MODIFIED_BY_USER)
 Values
   (1, 'Quality Directorate', 'Weston House', '246 High Holborn', 'London', 'WC1V 7EX', 1, 'ETL');

Insert into cpodjunit.ADDRESS_TBL
   (ADDRESS_ID, ADDRESS_LINE1, ADDRESS_LINE2, ADDRESS_LINE3, ADDRESS_LINE4, ADDRESS_LINE5, POSTCODE, ADDRESS_TYPE_ID, MODIFIED_BY_USER)
 Values
   (2, 'South Coast Audit', 'Wallsend House', 'Richmond Road', 'Pevensey Bay', 'East Sussex', 'BN24 6AU', 2, 'ETL');

Insert into cpodjunit.ADDRESS_TBL 
    (ADDRESS_ID,ADDRESS_LINE1,ADDRESS_LINE2,ADDRESS_LINE3,ADDRESS_LINE4,ADDRESS_LINE5,POSTCODE,ADDRESS_TYPE_ID,MODIFIED_BY_USER) 
values 
    (5927,'2nd Floor','Weston House','246 High Holborn','London',null,'WC1V 7EX',1,'JPEARSON-ETL');
   
Insert into cpodjunit.ADDRESS_TBL (ADDRESS_ID,ADDRESS_LINE1,ADDRESS_LINE2,ADDRESS_LINE3,ADDRESS_LINE4,ADDRESS_LINE5,POSTCODE,ADDRESS_TYPE_ID,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (5511,'UNIVERSAL HOUSE','ERF WAY','POCHIN WAY','MIDDLEWICH','CHESHIRE','CW10 0TE',3,'HSCIC 06-2014',null);

Insert into ADDRESS_TBL (ADDRESS_ID,ADDRESS_LINE1,ADDRESS_LINE2,ADDRESS_LINE3,ADDRESS_LINE4,ADDRESS_LINE5,POSTCODE,ADDRESS_TYPE_ID,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (15737,'CROWN BUILDING','CATHAYS PARK',null,'CARDIFF','SOUTH GLAMORGAN','CF10 3NQ',1,'HSCIC 06-2014',null);


--3 Regions Type

Insert into cpodjunit.regions_type_tbl (region_type_id, region_type, modified_by_user) values
(1,'A Type','ETL');
Insert into cpodjunit.regions_type_tbl (region_type_id, region_type, modified_by_user) values
(2,'B Type', 'ETL');


--3a. Regions Table

Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y01', 'NORTHERN YORKS REGIONAL OFFICE', 1, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('W00', 'HEALTH SOLUTIONS WALES', 2352, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y07', 'WEST MIDLANDS REGIONAL OFFICE', 3, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y08', 'NORTH WEST REGIONAL OFFICE', 4, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y09', 'EASTERN REGIONAL', 5, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y10', 'LONDON REGIONAL OFFICE', 6, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y11', 'SOUTH EAST REGIONAL OFFICE', 7, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y12', 'SOUTH WEST REGIONAL OFFICE', 8, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y21', 'DHSC (LONDON)', 9, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y22', 'DHSC (MIDLANDS AND EASTERN)', 10, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y23', 'DHSC (NORTH)', 11, 'ETL' ,1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y02', 'EAST MIDLANDS REGIONAL OFFICE', 12, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y24', 'DHSC (SOUTH)', 13, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y99', 'NON REGIONAL NHS ORGANISATIONS', 14, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Z99', 'NON REGIONAL NON NHS ORGANISATIONS', 15, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y51', 'THE NORTH MIDLANDS AND EAST PROGRAMME FOR IT (NMEPFIT)', 16, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('W01', 'NATIONAL ASSEMBLY FOR WALES', 2368, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y52', 'THE SOUTHERN PROGRAMME FOR IT (SPFIT)', 18, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('Y53', 'THE LONDON PROGRAMME FOR IT (LPFIT)', 19, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into cpodjunit.REGIONS_TBL
   (REGION_CODE, REGION, REGION_ID, MODIFIED_BY_USER, REGION_TYPE_ID, open_date, close_date)
 Values
   ('ETL_AW', 'NO REGION FOUND', 999999999, 'ETL' ,2, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/30/2006 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));


-- 4. org_type_tbl
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (7,'HA','ntones',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (8,'NHS','ntones',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (9,'NonNHS','ntones',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (10,'PCT','ntones',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (11,'SPHA','ntones',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (12,'TRUST','ntones',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (17,'SocE','ntones',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (18,'NHSE Area Team','JPEARSON-ORG-UPDATE',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (19,'NHSE CCG','JPEARSON-ORG-UPDATE',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (20,'NHSE CSU','JPEARSON-ORG-UPDATE',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (21,'WLHB','JPEARSON-ORG-UPDATE',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (22,'NAX Non NHS Organisations','JPearson',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (23,'NHSP added Organisations','JPEARSON',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (24,'Independent Sector Healthcare Providers','JPEARSON',null);
Insert into cpodjunit.ORG_TYPE_TBL (ORG_TYPE_ID,ORG_NAME,MODIFIED_BY_USER,MODIFIED_TIMESTAMP) values (25,'NHS Support Agencies and Shared Services','JPearson',null);




-- 5. Organisations_tbl;


Insert into cpodjunit.ORGANISATIONS_TBL
   (ORG_ID, org_type_id, ORG_CODE, ADDRESS_ID, OPEN_DATE, CLOSE_DATE, SUB_TYPE_CODE, ORG_NAME, MODIFIED_BY_USER,DOF_PERSON_ID)
 Values
   (5448, 7, '5F8', 1, TO_DATE('04/01/2001 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'C', 'BEBINGTON AND WEST WIRRAL PCT', 'ETL', 2058);
Insert into cpodjunit.ORGANISATIONS_TBL (ORG_ID,ORG_CODE,ADDRESS_ID,OPEN_DATE,CLOSE_DATE,SUB_TYPE_CODE,MEDICAL_STAFF_QTY,NON_MEDICAL_STAFF_QTY,ORG_NAME,MODIFIED_BY_USER,ORG_TYPE_ID,IMPORT_FILE,TOTAL_STAFF,STAFF_FIGURE_DATE,MODIFIED_TIMESTAMP,DOF_PERSON_ID) values (5511,'5NP',5511,to_date('01-OCT-2006','DD-MON-YYYY'),to_date('31-MAR-2013','DD-MON-YYYY'),null,null,null,'CENTRAL AND EASTERN CHESHIRE PCT','HSCIC 06-2014',10,'epctcur.csv',null,null,null,2058);


--Welsh ORG
Insert into ORGANISATIONS_TBL (ORG_ID,ORG_CODE,ADDRESS_ID,OPEN_DATE,CLOSE_DATE,SUB_TYPE_CODE,MEDICAL_STAFF_QTY,NON_MEDICAL_STAFF_QTY,ORG_NAME,MODIFIED_BY_USER,ORG_TYPE_ID,IMPORT_FILE,NAX_UPDATE_DATE,TOTAL_STAFF,STAFF_FIGURE_DATE,MODIFIED_TIMESTAMP,DOF_PERSON_ID,SMD_PERSON_ID) values (8639,'W01',15737,to_date('01-APR-2003','DD-MON-YYYY'),to_date('31-DEC-9999','DD-MON-YYYY'),null,null,null,'WELSH GOVERNMENT','HSCIC 06-2014',18,'eautham.csv',to_date('01-MAY-2014','DD-MON-YYYY'),null,null,null,null,null);

-- 5a Regions Link Table

Insert into cpodjunit.regions_link_tbl
    (region_id, org_id, modified_by_user) values
        (1, 5448, 'ETL');
        
        Insert into cpodjunit.regions_link_tbl
    (region_id, org_id, modified_by_user) values
        (2352, 8639, 'ETL');

  


-- 6. Person Type


Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (1, 'COMP', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (2, 'CU', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (3, 'OPS', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (4, 'LCFS', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (5, 'LSMS', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (6, 'TEMP', 'ETL');
Insert into cpodjunit.person_type_tbl
   (PERSON_TYPE_ID, PERSON_TYPE, MODIFIED_BY_USER)
 Values
   (15, 'EXTERNAL', 'ETL');
--new person types for SIRS
Insert into PERSON_TYPE_TBL (PERSON_TYPE_ID,PERSON_TYPE,MODIFIED_BY_USER) values (20,'LMS','NTONES');
Insert into PERSON_TYPE_TBL (PERSON_TYPE_ID,PERSON_TYPE,MODIFIED_BY_USER) values (21,'LSSP','NTONES');
Insert into PERSON_TYPE_TBL (PERSON_TYPE_ID,PERSON_TYPE,MODIFIED_BY_USER) values (22,'SMD','NTONES');
Insert into PERSON_TYPE_TBL (PERSON_TYPE_ID,PERSON_TYPE,MODIFIED_BY_USER) values (23,'SPEC','NTONES');
Insert into PERSON_TYPE_TBL (PERSON_TYPE_ID,PERSON_TYPE,MODIFIED_BY_USER) values (24,'DOF','NTONES');



-- 7 Person
Insert into CPODJUNIT.PERSON_TBL
   (PERSON_ID, ORG_ID, TITLE, FORENAME, SURNAME, KNOWN_AS, MODIFIED_BY_USER, STATUS,  EMAIL_NHS, TELEPHONE, MOBILE, PROPRIETRY_COMPLETE, FRAUD_COMPLETE, SECURITY_COMPLETE, ACCREDITED_TRAINING_COMPLETE)
 Values
   (1, 5448, 'Ms', 'Janet', 'Smith', 'Jan', 'ETL', 'Y', 'jan.smith@awp.nhs.uk', '01225 731785', '07788 437844',  'Y', 'N', 'N', 'N');
Insert into CPODJUNIT.PERSON_TBL
   (PERSON_ID, ORG_ID, TITLE, FORENAME, SURNAME, KNOWN_AS, MODIFIED_BY_USER, STATUS, EMAIL_NHS, TELEPHONE, MOBILE, PROPRIETRY_COMPLETE, FRAUD_COMPLETE, SECURITY_COMPLETE, ACCREDITED_TRAINING_COMPLETE)
 Values
   (2, 5448, 'Mrs', 'Eleni', 'Brown', 'El', 'ETL', 'Y', 'eleni.brown@nsft.nhs.uk', '01603 421537', '0111 11111',  'Y', 'Y','N', 'Y');
Insert into CPODJUNIT.PERSON_TBL
   (PERSON_ID, ORG_ID, TITLE, FORENAME, SURNAME, KNOWN_AS, MODIFIED_BY_USER, STATUS, EMAIL_NHS, TELEPHONE, MOBILE, PROPRIETRY_COMPLETE, FRAUD_COMPLETE, SECURITY_COMPLETE, ACCREDITED_TRAINING_COMPLETE)
 Values
   (2058, 5448, 'Mr', 'Nick', 'Tones', 'Nick', 'ETL', 'Y', 'nick@nsft.nhs.uk', '0191 2046200', '0111 22222',  'Y', 'Y','Y', 'Y');
Insert into CPODJUNIT.PERSON_TBL
   (PERSON_ID, ORG_ID, TITLE, FORENAME, SURNAME, KNOWN_AS, MODIFIED_BY_USER, STATUS,  EMAIL_NHS, TELEPHONE, MOBILE, PROPRIETRY_COMPLETE, FRAUD_COMPLETE, SECURITY_COMPLETE, ACCREDITED_TRAINING_COMPLETE)
 Values
   (4, 5448, 'Ms', 'JanetSIRSADMIN', 'SmithSIRSADMIN', 'Jan', 'ETL', 'N', 'jan.smithsirsadmin@awp.nhs.uk', '01225 731785', '07788 437844',  'Y', 'N', 'N', 'N');
   

Insert into CPODJUNIT.PERSON_TBL 
	(PERSON_ID,ORG_ID,ESR_ID,TITLE,FORENAME,FORENAME2,SURNAME,KNOWN_AS,DOB,MODIFIED_BY_USER,STATUS,EMAIL_NHS,EMAIL_OTHER,TELEPHONE,TELEPHONE2,EXT,FAX,MOBILE,PROPRIETRY_COMPLETE,PROPRIETRY_DATE,FRAUD_COMPLETE,FRAUD_DATE,SECURITY_COMPLETE,SECURITY_DATE,ACCREDITED_TRAINING_COMPLETE,NHSP_SECTION_ID,SECURITY_ACCREDITATION_DATE,FRAUD_ACCREDITATION_DATE,SEC_QUESTION_1,SEC_QUESTION_2,SEC_ANSWER_1,SEC_ANSWER_2) 
	values (1929,5448,10867702,'Mr','Alan',null,'Wheatley','Alan',null,'ops0259','Y','alan.bowstead@nhsprotect.gsi.gov.uk',null,'0191 204 6313',null,'6313','01912046320','07775 703642','Y',null,null,null,null,null,'N',null,null,null,null,null,'','');

Insert into CPODJUNIT.PERSON_TBL (PERSON_ID,ORG_ID,ESR_ID,TITLE,FORENAME,FORENAME2,SURNAME,KNOWN_AS,DOB,MODIFIED_BY_USER,STATUS,EMAIL_NHS,EMAIL_OTHER,TELEPHONE,TELEPHONE2,EXT,FAX,MOBILE,PROPRIETRY_COMPLETE,PROPRIETRY_DATE,FRAUD_COMPLETE,FRAUD_DATE,SECURITY_COMPLETE,SECURITY_DATE,ACCREDITED_TRAINING_COMPLETE,NHSP_SECTION_ID,SECURITY_ACCREDITATION_DATE,FRAUD_ACCREDITATION_DATE,SEC_QUESTION_1,SEC_QUESTION_2,SEC_ANSWER_1,SEC_ANSWER_2,MODIFIED_TIMESTAMP) values (1139,5448,null,'Ms','Diane',null,'Yates','Diane',null,'ops0292','Y','diane.yates1@nhs.net',null,'01270 37668',null,null,null,'07771 387550','Y',null,'N',null,'Y',to_date('19-SEP-2005','DD-MON-YYYY'),'Y',null,null,null,null,null,null,null,to_timestamp('10-FEB-2015 14.50.51.521000000','DD-MON-YYYY HH24.MI.SSXFF'));


  
   -- 7a Person Role
Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(1,1,'lsms0246', 5, null, TO_DATE('11/03/2004 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LSMS','NA');

Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(2,2,'lcfs1538', 4, null, TO_DATE('08/06/2012 15:28:43', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LCFS', 'NA');

Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(3,2,'lsms9999', 5, null, TO_DATE('12/08/2010 15:28:43', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LSMS Lead', 'NA');

Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(4,2058,'ops0259', 3, null, TO_DATE('12/08/2010 15:28:43', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LSMS Lead', 'NA');

--srt test user
Insert into CPODJUNIT.PERSON_ROLE_TBL (PERSON_ROLE_ID,USER_REF,PERSON_TYPE,START_DATE,END_DATE,PERSON_ID,MODIFIED_BY_USER,JOB_TITLE,REASON,MANAGER_ID,MODIFIED_TIMESTAMP) values (8501,'lsms0138',5,to_date('10-AUG-2004','DD-MON-YYYY'),to_date('31-DEC-9999','DD-MON-YYYY'),1139,'ops0292','Security Manager','ETL',null,to_timestamp('10-FEB-2015 14.50.51.520000000','DD-MON-YYYY HH24.MI.SSXFF'));

Insert into CPODJUNIT.PERSON_ROLE_TBL (PERSON_ROLE_ID,USER_REF,PERSON_TYPE,START_DATE,END_DATE,PERSON_ID,MODIFIED_BY_USER,JOB_TITLE,REASON,MANAGER_ID,MODIFIED_TIMESTAMP) values (8502,'dof1234',24,to_date('10-AUG-2004','DD-MON-YYYY'),to_date('31-DEC-9999','DD-MON-YYYY'),2058,'ops0292','Security Manager','ETL',null,to_timestamp('10-FEB-2015 14.50.51.520000000','DD-MON-YYYY HH24.MI.SSXFF'));


	-- SIRS User Administration
Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(5,4,'lsms0657', 5, null, TO_DATE('11/03/2004 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('11/08/2004 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LSMS','NA');

--LSDS admin user
Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(6,2058,'lsdsAdmin', 3, null, TO_DATE('12/08/2010 15:28:43', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'LSDS Admin', 'NA');

--Training admin user
Insert into cpodjunit.person_role_tbl
(person_role_id, person_id, user_ref, person_type, manager_id, start_date, end_date,job_title, reason)
values
(7,2058,'trainingAdmin', 3, null, TO_DATE('12/08/2010 15:28:43', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'),'Training Admin', 'NA');

--Potential CPOD user
Insert into CPODJUNIT.PERSON_ROLE_TBL 
	(PERSON_ROLE_ID,USER_REF,PERSON_TYPE,START_DATE,END_DATE,PERSON_ID,MODIFIED_BY_USER,JOB_TITLE,REASON,MANAGER_ID) 
values 
	(8,'ops0106',3,to_date('05-FEB-2004','DD-MON-YYYY'),to_date('31-DEC-9999','DD-MON-YYYY'),1929,'ops0259','Database Specialist','ETL',null);




-- 10. Address Link Table

Insert into cpodjunit.ADDRESS_LINK_TBL
   (PERSON_ID, ADDRESS_ID,MODIFIED_BY_USER)
 Values
   (1, 1,'ETL');
Insert into cpodjunit.ADDRESS_LINK_TBL
   (PERSON_ID, ADDRESS_ID,MODIFIED_BY_USER)
 Values
   (2, 2,'ETL');
Insert into cpodjunit.ADDRESS_LINK_TBL
   (PERSON_ID, ADDRESS_ID,MODIFIED_BY_USER)
 Values
   (1, 2,'ETL');


   
-- 11. Responsibilities Table

Insert into cpodjunit.RESPONSIBILITIES_TBL
   (PERSON_role_ID, START_DATE, END_DATE, ORG_ID, RESP_ID, MODIFIED_BY_USER, LEAD)
 Values
   (1, TO_DATE('03/01/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 5448, 1095, 'ETL', 'N');
Insert into cpodjunit.RESPONSIBILITIES_TBL
   (PERSON_role_ID, START_DATE, END_DATE, ORG_ID, RESP_ID, MODIFIED_BY_USER, LEAD)
 Values
   (2, TO_DATE('05/27/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/9999 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 5448, 1097, 'ETL', 'N');
Insert into cpodjunit.RESPONSIBILITIES_TBL
   (PERSON_role_ID, START_DATE, END_DATE, ORG_ID, RESP_ID, MODIFIED_BY_USER, LEAD)
 Values
   (5, TO_DATE('05/27/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('05/28/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 5448, 1099, 'ETL', 'Y');   

 



