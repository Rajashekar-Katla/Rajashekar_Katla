package uk.nhs.nhsprotect.srt.test.service;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.srt.config.SrtJunitBaseTest;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Result;
import uk.nhs.nhsprotect.srt.service.ResultsService;

/**
 * @author bvaidya
 */
public class ResultServiceTest extends SrtJunitBaseTest {

  @Autowired
  private ResultsService resultsService;

  private void setupResults() throws Exception {
    List<Result> list = new ArrayList<Result>();
    // 2014 lsms
    Result results = new Result();
    results.setComments("Second Junit Test");
    results.setCreatedBy("lsms6928");
    results.setCreatedDate(new Date());
    results.setModifiedDate(new Date());
    results.setModifiedBy("lsms692888");
    results.setOrgCode("5PW");
    results.setQuestionId(new Long(1));
    results.setSrtType("lsms");
    results.setScore(4);
    // 2014 lsms
    Result results1 = new Result();
    results1.setComments("Second Junit Test");
    results1.setCreatedBy("lsms6927");
    results1.setCreatedDate(new Date());
    results1.setModifiedDate(new Date());
    results1.setModifiedBy("lsms69277");
    results1.setOrgCode("5PW");
    results1.setQuestionId(new Long(1));
    results1.setScore(3);
    results.setSrtType("lsms");
    // 2014 lcfs
    Result results2 = new Result();
    results2.setComments("Third Junit Test");
    results2.setCreatedBy("lcfs6929");
    results2.setCreatedDate(new Date());
    results2.setModifiedDate(new Date());
    results2.setModifiedBy("lcfs6929");
    results2.setOrgCode("5PW");
    results2.setQuestionId(new Long(1));
    results2.setScore(3);
    results2.setSrtType("lcfs");
    // 2015 lcfs
    Result results3 = new Result();
    results3.setComments("Third Junit Test");
    results3.setCreatedBy("lcfs6929");
    results3.setCreatedDate(new Date());
    results3.setModifiedDate(new Date());
    results3.setModifiedBy("lcfs6929");
    results3.setOrgCode("5PW");
    results3.setQuestionId(new Long(94));
    results3.setScore(3);
    results3.setSrtType("lcfs");
    list.add(results);
    list.add(results1);
    list.add(results2);
    list.add(results3);
    resultsService.saveAll(list);
  }

  /**
   * Test to persist the single record in database.
   * @throws SrtException
   */
  @Test
  public void testSave() throws SrtException {
    Result results = new Result();
    results.setComments("First Junit Test");
    results.setCreatedBy("lcfs6928");
    results.setCreatedDate(new Date());
    results.setModifiedDate(new Date());
    results.setModifiedBy("lcfs6928");
    results.setOrgCode("5PW");
    results.setQuestionId(new Long(45));
    results.setSrtType("lcfs");
    results.setScore(6);
    resultsService.save(results);
  }

  /**
   * Test to persist the list of records in database.
   * @throws SrtException
   */
  @Test
  public void testSaveAll() throws SrtException {
    List<Result> list = new ArrayList<Result>();
    // 2014 lsms
    Result results = new Result();
    results.setComments("Second Junit Test");
    results.setCreatedBy("lsms6928");
    results.setCreatedDate(new Date());
    results.setModifiedDate(new Date());
    results.setModifiedBy("lsms692888");
    results.setOrgCode("5PW");
    results.setQuestionId(new Long(1));
    results.setSrtType("lsms");
    results.setScore(4);
    // 2014 lsms
    Result results1 = new Result();
    results1.setComments("Second Junit Test");
    results1.setCreatedBy("lsms6927");
    results1.setCreatedDate(new Date());
    results1.setModifiedDate(new Date());
    results1.setModifiedBy("lsms69277");
    results1.setOrgCode("5PW");
    results1.setQuestionId(new Long(1));
    results1.setScore(3);
    results.setSrtType("lsms");
    // 2014 lcfs
    Result results2 = new Result();
    results2.setComments("Third Junit Test");
    results2.setCreatedBy("lcfs6929");
    results2.setCreatedDate(new Date());
    results2.setModifiedDate(new Date());
    results2.setModifiedBy("lcfs6929");
    results2.setOrgCode("5PW");
    results2.setQuestionId(new Long(1));
    results2.setScore(3);
    results2.setSrtType("lcfs");
    // 2015 lcfs
    Result results3 = new Result();
    results3.setComments("Third Junit Test");
    results3.setCreatedBy("lcfs6929");
    results3.setCreatedDate(new Date());
    results3.setModifiedDate(new Date());
    results3.setModifiedBy("lcfs6929");
    results3.setOrgCode("5PW");
    results3.setQuestionId(new Long(94));
    results3.setScore(3);
    results3.setSrtType("lcfs");
    list.add(results);
    list.add(results1);
    list.add(results2);
    list.add(results3);
    resultsService.saveAll(list);
  }

  /**
   * Test to get answered questions list for current year and srt type lsms.
   * Criteria is organisation code, srt type and year.
   * @throws SrtException
   */
  @Test
  public void testSMSAnsweredQuestionsListForCurrentYear() throws Exception {
    setupResults();
    // TODO 2015 changes...
    List<Result> list = resultsService.getAnsweredQuestionsList("5PW", "lsms", "2014");
    assertNotNull(list);
  }

  /**
   * Test to get answered questions list for current year and srt type lcfs.
   * Criteria is organisation code, srt type and year.
   * @throws SrtException
   */
  @Test
  public void testFraudAnsweredQuestionsListForCurrentYear() throws Exception {
    setupResults();
    List<Result> list = resultsService.getAnsweredQuestionsList("5PW", "lcfs", "2015");
    assertNotNull(list);
  }

  /**
   * Test to get answered questions list for previous year and srt type lsms.
   * @throws SrtException
   */
  @Test
  public void testSMSAnsweredQuestionsListForPreviousYear() throws Exception {
    setupResults();
    List<Result> list = resultsService.getAnsweredQuestionsList("5PW", "lsms", "2014");
    assertNotNull(list);
  }

  /**
   * Test to get answered questions list for previous year and srt type lcfs.
   * @throws SrtException
   */
  @Test
  public void testFraudAnsweredQuestionsListForPreviousYear() throws Exception {
    setupResults();
    List<Result> list = resultsService.getAnsweredQuestionsList("5PW", "lcfs", "2014");
    assertNotNull(list);
  }

}
