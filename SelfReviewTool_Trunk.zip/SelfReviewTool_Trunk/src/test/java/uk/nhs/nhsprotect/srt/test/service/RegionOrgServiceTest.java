/**
 * 
 */
package uk.nhs.nhsprotect.srt.test.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.srt.config.SrtJunitBaseTest;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.OrganisationByTypeCCG;
import uk.nhs.nhsprotect.srt.model.OrganisationType;
import uk.nhs.nhsprotect.srt.model.RegionOrgMapping;
import uk.nhs.nhsprotect.srt.model.Regions;
import uk.nhs.nhsprotect.srt.service.RegionOrgService;

/**
 * @author bvaidya
 */
public class RegionOrgServiceTest extends SrtJunitBaseTest {

    @Autowired
    private RegionOrgService regionOrgService;

    private RegionOrgMapping regionOrgMapping;

    /**
     * Test to verify region code as per given organization.
     * @throws SrtException
     */
    @Test
    public void testRegionCodeByOrganization() throws SrtException {
        regionOrgMapping = regionOrgService.getRegionCodeByOrganization("W01");
        assertNotNull(regionOrgMapping);
        assertEquals("WARO", regionOrgMapping.getRegionCode());
    }

    /**
     * Test to verify there is no region code for given organization
     * @throws SrtException
     */
    @Test
    public void testNoRegionCodeEmptyByOrganization() throws SrtException {
        regionOrgMapping = regionOrgService.getRegionCodeByOrganization("5NP");
        assertNotNull(regionOrgMapping);
        assertNotSame("", regionOrgMapping.getRegionCode());
    }


    /**
     * Test to verify the region list
     * @throws SrtException
     */
    @Test
    public void testRegionList() throws SrtException {
        List<Regions> list = regionOrgService.getRegionList("lcfs", "2014", "NHSP");
        assertNotNull(list);
        assertEquals(9, list.size());
    }

    /**
     * Test to verify the provider type list
     * @throws SrtException
     */
    @Test
    public void testProviderTypeList() throws SrtException {
        List<OrganisationType> list = regionOrgService.getOrganisationTypes("lcfs", "2014");
        assertNotNull(list);
        assertEquals(12, list.size());
        list = regionOrgService.getOrganisationTypes("lcfscom", "2015");
        assertNotNull(list);
        assertEquals(5, list.size());
    }

    /**
     * Test to verify the CCG provider type list
     * @throws SrtException
     */
    @Test
    public void testCCGProviderTypeList() throws SrtException {
        List<OrganisationByTypeCCG> list = regionOrgService.getProviderTypeListForCCG();
        assertNotNull(list);
    }
}
