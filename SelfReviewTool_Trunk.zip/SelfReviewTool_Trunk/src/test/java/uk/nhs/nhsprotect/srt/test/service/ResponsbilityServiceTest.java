package uk.nhs.nhsprotect.srt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.srt.config.SrtJunitBaseTest;
import uk.nhs.nhsprotect.srt.dto.ResponsibilityDTO;
import uk.nhs.nhsprotect.srt.model.Responsibility;
import uk.nhs.nhsprotect.srt.service.ResponsibilityService;

/**
 * @author bvaidya
 */

public class ResponsbilityServiceTest extends SrtJunitBaseTest {

  /**
   * Access to ResponsibilityService.
   */
  @Autowired
  private ResponsibilityService responsibilityService;

  /**
   * Access to Responsibility model Class.
   */
  @SuppressWarnings("unused")
  private Responsibility responsibility;

  /**
   * To test responsibilities for given staff id.
   * @throws Exception
   */
  @Test
  public void testResponsibilityByStaffId() throws Exception {
    List<ResponsibilityDTO> list = responsibilityService.getResponsibilitiesByStaffId("lcfs1538");
    assertNotNull(list);
    assertEquals(1, list.size());
  }

  @Test
  public void testGetResponsibilitiesByOrgCode() throws Exception {
    List<ResponsibilityDTO> list = responsibilityService.getResponsibilitiesByOrgCode("5F8");
    assertNotNull(list);
    assertEquals(2, list.size());
  }

  @Test
  public void testGetResponsibilityByPersonAndOrg() throws Exception {
    List<ResponsibilityDTO> list = responsibilityService.getResponsibilityByPersonAndOrg("lcfs1538", "5F8");
    assertNotNull(list);
    assertEquals(1, list.size());
  }

}
