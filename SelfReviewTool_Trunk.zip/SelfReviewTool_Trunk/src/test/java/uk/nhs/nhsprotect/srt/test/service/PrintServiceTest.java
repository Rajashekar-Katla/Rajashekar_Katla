/**
 * 
 */
package uk.nhs.nhsprotect.srt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.File;

import org.apache.commons.io.FilenameUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.srt.config.SrtJunitBaseTest;
import uk.nhs.nhsprotect.srt.service.PrintService;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRTExportType;

/**
 * @author bvaidya
 */
public class PrintServiceTest extends SrtJunitBaseTest {

  @Autowired
  PrintService printService;

  /**
   * Test method to generate pdf for status SUBMITTED.
   * @throws Exception on error.
   */
  @Test
  public void testGenerationOfXLS() throws Exception {

    File file = printService.generateSRTSummary("5NP", "lcfs", "2014", SRTExportType.XLS);
    assertNotNull(file);
    assertEquals(FilenameUtils.getExtension(file.getName()).toUpperCase(), "XLS");

  }

  /**
   * Test method to generate pdf for status SUBMITTED.
   * @throws Exception on error
   */
  @Test
  public void testGenerationOfPDF() throws Exception {

    File file = printService.generateSRTSummary("5PW", "lcfs", "2014", SRTExportType.PDF);
    assertNotNull(file);
    assertEquals(FilenameUtils.getExtension(file.getName()).toUpperCase(), "PDF");

  }

}
