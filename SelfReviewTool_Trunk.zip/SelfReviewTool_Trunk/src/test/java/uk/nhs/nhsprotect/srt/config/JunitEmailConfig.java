/**
 * 
 */
package uk.nhs.nhsprotect.srt.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

/**
 * @author nmarsh
 */
@Configuration
@PropertySources(value = {
        @PropertySource("classpath:test.properties")
})
public class JunitEmailConfig {
    /**
     * The current application environment.
     */
    @Autowired
    private Environment env;

    /**
     * The name of the email host environment variable.
     */
    private static final String EMAIL_HOST = "email.host";

    /**
     * The name of the email port environment variable.
     */
    private static final String EMAIL_PORT = "email.port";

    /**
     * JavaMailSender instance.
     * @param emailHost - from application.properties email.host
     * @param emailPort - from application.properties email.port
     * @return configured mailSender
     */
    @Bean
    public JavaMailSender mailSender() {
        final JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(this.env.getProperty(EMAIL_HOST));
        mailSender.setPort(Integer.parseInt(this.env.getProperty(EMAIL_PORT)));
        return mailSender;
    }

    /**
     * Template SimpleMailMessage for email sending.
     * @param emailFrom - from application.properties email.from
     * @param emailSubject - from application.properties email.from
     * @return SimpleMailMessage template
     */
    @Bean
    public SimpleMailMessage simpleMailMessage(@Value("${email.from}") final String emailFrom,
            @Value("${email.subject}") final String emailSubject) {
        final SimpleMailMessage templateMessage = new SimpleMailMessage();
        templateMessage.setFrom(emailFrom);
        templateMessage.setSubject(emailSubject);
        return templateMessage;
    }

    /**
     * PropertySourcesPlaceholderConfigurer allows @value expression to check
     * property files for values.
     * @return PropertySourcesPlaceholderConfigurer.
     */
    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }
}
