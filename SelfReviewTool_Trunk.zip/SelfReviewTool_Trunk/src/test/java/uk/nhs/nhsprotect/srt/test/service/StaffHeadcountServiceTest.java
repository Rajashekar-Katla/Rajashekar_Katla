/**
 * 
 */
package uk.nhs.nhsprotect.srt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.srt.config.SrtJunitBaseTest;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.StaffHeadcount;
import uk.nhs.nhsprotect.srt.service.StaffHeadcountService;

/**
 * @author bvaidya
 */
public class StaffHeadcountServiceTest extends SrtJunitBaseTest {

    @Autowired
    StaffHeadcountService staffHeadcountService;

    /**
     * Test to get staff head count options list.
     * @throws SrtException
     */
    @Test
    public void testStaffHeadcountOptions() throws SrtException {
        List<StaffHeadcount> list = staffHeadcountService.getListOfStaffHeadcountOptions("2014", "lcfs");
        assertNotNull(list);
        assertEquals(5, list.size());
        // 2015 lcfs options
        list = staffHeadcountService.getListOfStaffHeadcountOptions("2015", "lcfs");
        assertNotNull(list);
        assertEquals(6, list.size());
        // 2015 lcfscom options
        list = staffHeadcountService.getListOfStaffHeadcountOptions("2015", "lcfscom");
        assertNotNull(list);
        assertEquals(6, list.size());
    }

}
