package uk.nhs.nhsprotect.srt.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/**
 * The data source config that can be used in integration tests.
 */
@Configuration
@PropertySources(value = {
        @PropertySource("classpath:junitpersistence.properties")
})
public class JunitDataSourceConfig {

    /**
     * The name of the datasource driver environment property.
     */
    private static final String DATASOURCE_DRIVER = "dataSource.driverClassName";

    /**
     * The name of the datasource url environment property.
     */
    private static final String JUNIT_DATASOURCE_URL = "dataSource.url";

    /**
     * The name of the srt datasource user environment property.
     */
    private static final String SRT_DATASOURCE_USER = "srt.dataSource.username";

    /**
     * The name of the srt datasource password environment property.
     */
    private static final String SRT_DATASOURCE_PASSWORD = "srt.dataSource.password";

    /**
     * The name of the cpod datasource user environment property.
     */
    private static final String CPOD_DATASOURCE_USER = "cpod.dataSource.username";

    /**
     * The name of the cpod datasource password environment property.
     */
    private static final String CPOD_DATASOURCE_PASSWORD = "cpod.dataSource.password";

    /**
     * The current application environment.
     */
    @Autowired
    private Environment env;

    /**
     * Method to configure and return Extranet DataSource.
     * @return DataSource configured
     */
    @Bean(name = "dataSource")
    public DataSource dataSource() {
        final HikariConfig config = new HikariConfig();
        config.setDriverClassName(this.env.getProperty(DATASOURCE_DRIVER));
        config.setJdbcUrl(this.env.getProperty(JUNIT_DATASOURCE_URL));
        config.setUsername(this.env.getProperty(SRT_DATASOURCE_USER));
        config.setPassword(this.env.getProperty(SRT_DATASOURCE_PASSWORD));

        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        config.addDataSourceProperty("useServerPrepStmts", "true");

        return new HikariDataSource(config);
    }

    /**
     * Method to configure and return CPOD DataSource.
     * @return DataSource configured
     */
    @Bean
    public DataSource cpodDataSource() {
        final HikariConfig config = new HikariConfig();
        config.setDriverClassName(this.env.getProperty(DATASOURCE_DRIVER));
        config.setJdbcUrl(this.env.getProperty(JUNIT_DATASOURCE_URL));
        config.setUsername(this.env.getProperty(CPOD_DATASOURCE_USER));
        config.setPassword(this.env.getProperty(CPOD_DATASOURCE_PASSWORD));
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        config.addDataSourceProperty("useServerPrepStmts", "true");

        return new HikariDataSource(config);
    }

    /**
     * DataSourceIntializer can run DB scripts to populate DB with specific
     * values. FOR JUNIT ONLY!!!
     * @return DataSourceInitializer
     */
    @Bean
    public DataSourceInitializer dataSourceInitializer() {
        DataSourceInitializer dataSourceInitializer = new DataSourceInitializer();
        dataSourceInitializer.setDataSource(this.dataSource());
        ResourceDatabasePopulator setup = new ResourceDatabasePopulator(new ClassPathResource("setup.sql"));
        ResourceDatabasePopulator teardown = new ResourceDatabasePopulator(new ClassPathResource("teardown.sql"));
        dataSourceInitializer.setDatabasePopulator(setup);
        dataSourceInitializer.setDatabaseCleaner(teardown);
        dataSourceInitializer.setEnabled(true);
        return dataSourceInitializer;
    }

    /**
     * DataSourceIntializer can run DB scripts to populate DB with specific
     * values. FOR JUNIT ONLY!!!
     * @return DataSourceInitializer
     */
    @Bean
    public DataSourceInitializer cpodDataSourceInitializer() {
        DataSourceInitializer dataSourceInitializer = new DataSourceInitializer();
        dataSourceInitializer.setDataSource(this.cpodDataSource());
        ResourceDatabasePopulator setup = new ResourceDatabasePopulator(new ClassPathResource("cpodSetup.sql"));
        ResourceDatabasePopulator teardown = new ResourceDatabasePopulator(new ClassPathResource("cpodTeardown.sql"));
        dataSourceInitializer.setDatabasePopulator(setup);
        dataSourceInitializer.setDatabaseCleaner(teardown);
        dataSourceInitializer.setEnabled(true);
        return dataSourceInitializer;
    }
}
