/**
 * 
 */
package uk.nhs.nhsprotect.srt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.srt.config.SrtJunitBaseTest;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTStatus;
import uk.nhs.nhsprotect.srt.service.SRTStatusService;

/**
 * @author bvaidya
 */
public class SrtStatusServiceTest extends SrtJunitBaseTest {

    @Autowired
    private SRTStatusService srtStatusService;

    private SRTStatus srtStatus;

    /**
     * Test to verify the status of SRT process.
     * @throws SrtException
     */
    @Test
    public void testStatusOfSRTProcess() throws SrtException {
        srtStatus = srtStatusService.getSRTStatusByOrgCodeAndType("5NP", "lcfs", "2014");
        assertNotNull(srtStatus);
        assertEquals("SUBMITTED", srtStatus.getStatus());
    }

}
