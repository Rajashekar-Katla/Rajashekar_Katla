/**
 * 
 */
package uk.nhs.nhsprotect.srt.test.service;

import java.util.List;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.srt.config.SrtJunitBaseTest;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Questionnaire;
import uk.nhs.nhsprotect.srt.service.QuestionnaireService;

/**
 * @author bvaidya
 */
public class QuestionnaireServiceTest extends SrtJunitBaseTest {

    @Autowired
    private QuestionnaireService questionnaireService;

    /**
     * Test to get question list for current year for srt type lsms.
     * @throws SrtException
     */
    @Test
    public void testSMSQuestionnaireListForCurrentYear() throws SrtException {
        List<Questionnaire> list = questionnaireService.findQuessionnaireListForCurrentYear("", "lsms");
        assertNotNull(list);
        assertEquals(52, list.size());
    }

    /**
     * Test to get question list for previous years for srt type lsms.
     * @throws SrtException
     */
    @Test
    public void testSMSQuestionnaireListForPreviousYears() throws SrtException {
        List<Questionnaire> list = questionnaireService.findQuessionnaireListForPreviousYears("", "lsms", "2014");
        assertNotNull(list);
        assertEquals(49, list.size());
    }

    /**
     * Test to get question list for current year for srt type lcfs.
     * @throws SrtException
     */
    @Test
    public void testFraudQuestionnaireListForCurrentYear() throws SrtException {
        List<Questionnaire> list = questionnaireService.findQuessionnaireListForCurrentYear("WARO", "lcfs");
        assertNotNull(list);
        assertEquals(41, list.size());
    }

    /**
     * Test to get question list for previous years for srt type lcfs.
     * @throws SrtException
     */
    @Test
    public void testFraudQuestionnaireListForPreviousYears() throws SrtException {
        List<Questionnaire> list = questionnaireService.findQuessionnaireListForPreviousYears("", "lcfs", "2014");
        assertNotNull(list);
        assertEquals(42, list.size());
    }

    /**
     * Test to get question list for current year for no region.
     * @throws SrtException
     */
    @Test
    public void testQuestionnaireListForCurrentYearWithNoRegion() throws SrtException {
        List<Questionnaire> list = questionnaireService.findQuessionnaireListForCurrentYear("", "lcfs");
        assertNotNull(list);
        assertEquals(43, list.size());
    }

    /**
     * Test to get question list for previous years for no region.
     * @throws SrtException
     */
    @Test
    public void testQuestionnaireListForPreviousYearsWithNoRegion() throws SrtException {
        List<Questionnaire> list = questionnaireService.findQuessionnaireListForPreviousYears("", "lcfs", "2014");
        assertNotNull(list);
        assertEquals(42, list.size());
    }

}
