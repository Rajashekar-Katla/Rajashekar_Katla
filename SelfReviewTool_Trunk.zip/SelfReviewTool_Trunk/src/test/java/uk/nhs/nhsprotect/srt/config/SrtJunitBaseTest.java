package uk.nhs.nhsprotect.srt.config;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import uk.nhs.nhsprotect.srt.exception.SrtException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {
        ApplicationConfig.class, JunitDataSourceConfig.class, PersistenceConfig.class, JunitEmailConfig.class
})
@Transactional
public abstract class SrtJunitBaseTest {

    /**
     * Setup for each test that runs.
     * @throws Exception for error
     */
    @Before
    public void setUp() throws SrtException {

    }

    /**
     * Teardown of data after tests complete.
     * @throws Exception for error
     */
    @After
    public void tearDown() throws SrtException {

    }
}
