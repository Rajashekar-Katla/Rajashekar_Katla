/**
 * 
 */
package uk.nhs.nhsprotect.srt.test.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.srt.config.SrtJunitBaseTest;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTYearRange;
import uk.nhs.nhsprotect.srt.service.SRTYearRangeService;

/**
 * @author bvaidya
 */
public class SRTYearRangeServiceTest extends SrtJunitBaseTest {

    @Autowired
    private SRTYearRangeService srtYearRangeService;

    /**
     * Method to test year range
     * @throws SrtException
     */
    @Test
    public void testYearRange() throws SrtException {
        SRTYearRange srtYearRange = srtYearRangeService.getYearRange("2014", "lsms");
        assertNotNull(srtYearRange);
    }

    /**
     * Method to test year list
     * @throws SrtException
     */
    @Test
    public void testDistinctYearList() throws SrtException {
        List<String> list = srtYearRangeService.getDistinctListOfYears("lsms");
        assertNotNull(list);
        assertEquals(3, list.size());
    }
}
