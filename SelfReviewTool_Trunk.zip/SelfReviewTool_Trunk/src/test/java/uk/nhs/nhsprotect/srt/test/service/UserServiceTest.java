/**
 * 
 */
package uk.nhs.nhsprotect.srt.test.service;

import org.junit.Test;
import static org.junit.Assert.*;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.srt.config.SrtJunitBaseTest;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.model.authentication.User;
import uk.nhs.nhsprotect.srt.service.UserService;

/**
 * @author bvaidya
 */
public class UserServiceTest extends SrtJunitBaseTest {

    @Autowired
    private UserService userService;

    private Person person;

    private User user;

    /**
     * Test to verify person details.
     * @throws SrtException
     */
    @Test
    public void testPersonDetails() throws SrtException {
        person = userService.getUserDetails("lcfs1538");
        assertNotNull(person);
        assertEquals(new Long(2), person.getPersonId());
    }

    /**
     * Test to find the user details
     * @throws SrtException
     */
    @Test
    public void testToFindByUserName() throws SrtException {
        user = userService.findByUserName("lcfs1538");
        assertNotNull(user);
        assertEquals(new Long(2), user.getPersonId());
    }
}
