/**
 * 
 */
package uk.nhs.nhsprotect.srt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.nhs.nhsprotect.srt.config.SrtJunitBaseTest;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.AnnualBudget;
import uk.nhs.nhsprotect.srt.service.AnnualBudgetService;

/**
 * @author bvaidya
 */
public class AnnualBudgetServiceTest extends SrtJunitBaseTest {

    @Autowired
    private AnnualBudgetService annualBudgetService;

    /**
     * Test to get annual budget options list.
     * @throws SrtException
     */
    @Test
    public void testAnnualBudgetOptions() throws SrtException {
        List<AnnualBudget> list = annualBudgetService.getListOfBudgetOptions("2014", "lcfs");
        assertNotNull(list);
        assertEquals(8, list.size());
        // 2015 lcfs standards introduced new options
        list = annualBudgetService.getListOfBudgetOptions("2015", "lcfs");
        assertNotNull(list);
        assertEquals(10, list.size());
        // 2014 lcfscom standards test
        list = annualBudgetService.getListOfBudgetOptions("2015", "lcfscom");
        assertNotNull(list);
        assertEquals(6, list.size());
    }

}
