/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.AnnualBudgetDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.AnnualBudget;

/**
 * @author bvaidya
 */
@Repository("annualBudgetDao")
public class AnnualBudgetDaoImpl extends SRTHibernateDaoSupportImpl implements AnnualBudgetDao {

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.dao.AnnualBudgetDao#getListOfBudgetOptions(java
     * .lang.String, java.lang.String)
     */
    @SuppressWarnings("unchecked")
    public List<AnnualBudget> getListOfBudgetOptions(String year, String srtType) throws SrtException {
        try {
            Query query = getCurrentSession()
                    .createQuery("from AnnualBudget where year = :year and srtType = :srtType order by displayOrder");
            query.setString("year", year);
            query.setString("srtType", srtType);
            List<AnnualBudget> list = query.list();
            if (null != list && !list.isEmpty()) {
                return list;
            } else {
                return null;
            }
        } catch (HibernateException he) {
            throw new SrtException(he);
        } catch (Exception e) {
            throw new SrtException(e);
        }
    }
}
