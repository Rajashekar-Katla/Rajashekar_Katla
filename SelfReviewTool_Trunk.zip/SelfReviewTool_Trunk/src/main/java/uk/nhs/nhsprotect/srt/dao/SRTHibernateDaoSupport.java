/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import org.hibernate.Session;

/**
 * @author bvaidya
 */
public interface SRTHibernateDaoSupport {

  /**
   * Retrieves session object from session factory.
   * @return Session current session
   */
  Session getCurrentSession();
}
