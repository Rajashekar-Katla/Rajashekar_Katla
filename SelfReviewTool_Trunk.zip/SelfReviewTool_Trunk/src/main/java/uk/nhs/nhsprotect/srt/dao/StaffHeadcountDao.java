/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.StaffHeadcount;

/**
 * @author bvaidya
 */
public interface StaffHeadcountDao {

    /**
     * Retrieves the list of staff head count options.
     * @param year the year to retrieve options for
     * @param srtType the SRT type to retrieve options for
     * @return List<StaffHeadcount> for the supplied year
     * @throws SrtException
     */
    List<StaffHeadcount> getListOfStaffHeadcountOptions(String year, String srtType) throws SrtException;
}
