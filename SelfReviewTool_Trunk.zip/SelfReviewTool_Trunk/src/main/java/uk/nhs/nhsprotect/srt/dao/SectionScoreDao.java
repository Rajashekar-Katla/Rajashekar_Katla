package uk.nhs.nhsprotect.srt.dao;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SectionScore;

@FunctionalInterface
public interface SectionScoreDao {
	public List<SectionScore> getSectionScoreData() throws SrtException;
}
