/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import java.util.List;

import uk.nhs.nhsprotect.srt.model.Result;

/**
 * @author bvaidya
 */
public interface ResultsDao {

  /**
   * Method to persist single object of type Results.
   * @param result to save
   */
  void save(Result result);

  /**
   * Method to persist list of objects of type Results.
   * @param results to save
   */
  void saveAll(List<Result> results);

  /**
   * Method to get the list of questions with answered comments and ratings.
   * @param orgCode organisation of SRT
   * @param srtType type of SRT
   * @param year of SRT
   * @return List<Result>
   */
  List<Result> getAnsweredQuestionsList(String orgCode, String srtType, String year);
}
