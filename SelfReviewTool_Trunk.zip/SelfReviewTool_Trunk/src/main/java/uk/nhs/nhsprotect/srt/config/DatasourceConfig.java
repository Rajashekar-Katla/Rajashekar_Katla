/**
 * 
 */
package uk.nhs.nhsprotect.srt.config;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/**
 * Spring configuration class for SRT datasource.
 * @author ntones
 */
@Configuration
public class DatasourceConfig {

    /**
     * The name of the datasource driver environment property.
     */
    private static final String DATASOURCE_DRIVER = "dataSource.driverClassName";

    /**
     * The name of the datasource url environment property.
     */
    private static final String DATASOURCE_URL = "dataSource.url";

    /**
     * The name of the datasource user environment property.
     */
    private static final String DATASOURCE_USER = "dataSource.username";

    /**
     * The name of the datasource password environment property.
     */
    private static final String DATASOURCE_PASSWORD = "dataSource.password";// NOSONAR

    /**
     * The current application environment.
     */
    @Autowired
    private Environment env;

    /**
     * Method to configure and return DataSource.
     * @param encryptor {@see ApplicationConfig#encryptor()}.
     * @return DataSource configured
     */
    @Bean
    @Autowired
    public DataSource dataSource(final StandardPBEStringEncryptor encryptor) {
        final HikariConfig config = new HikariConfig();
        config.setDriverClassName(this.env.getProperty(DATASOURCE_DRIVER));
        config.setJdbcUrl(this.env.getProperty(DATASOURCE_URL));
        config.setUsername(this.env.getProperty(DATASOURCE_USER));
        
        System.out.println("DATASOURCE_URL=="+env.getProperty(DATASOURCE_URL));
        System.out.println("DATASOURCE_USER=="+env.getProperty(DATASOURCE_USER));

        final String password = this.env.getProperty(DATASOURCE_PASSWORD);
         // may be empty if using in-memory DB
        if (StringUtils.isEmpty(password)) {
            config.setPassword(password);
        } else {
            // decrypt the password using Jasypt - required JCE unlimited
            // strength encryption in executing
            // JVM
            config.setPassword(encryptor.decrypt(password));
        }
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        config.addDataSourceProperty("useServerPrepStmts", "true");

        return new HikariDataSource(config);
    }

}
