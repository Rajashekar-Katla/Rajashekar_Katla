/**
 * 
 */
package uk.nhs.nhsprotect.srt.config;

import java.util.Locale;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import uk.nhs.nhsprotect.srt.Application;

/**
 * Spring configuration class for SRT application.
 * @author ntones
 */
@Configuration
@ComponentScan(basePackageClasses = Application.class, excludeFilters = @Filter({
        Controller.class, Configuration.class
}))
@PropertySources(value = {
        @PropertySource("classpath:application.properties"), 
        @PropertySource("classpath:persistence.properties")
})

public class ApplicationConfig {

    /**
     * The current application environment.
     */
    @Autowired
    private Environment env;

    /**
     * Location of message file(s).
     */
    private static final String MESSAGE_SOURCE = "/i18n/usermsg";

    /**
     * The name of the encryptor passphrase environment variable.
     */
    private static final String ENCRYPTOR_PASSPHRASE = "encryptor.passphrase";

    /**
     * Creates a MessageSource for providing text to View.
     * @return MessageSource
     */
    @Bean(name = "messageSource")
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasename(MESSAGE_SOURCE);
        messageSource.setDefaultEncoding("UTF8");
        messageSource.setCacheSeconds(5);
        return messageSource;
    }

    @Bean
    public LocaleResolver localeResolver() {
        SessionLocaleResolver resolver = new SessionLocaleResolver();
        resolver.setDefaultLocale(new Locale("en"));
        return resolver;
    }

    /**
     * PropertySourcesPlaceholderConfigurer allows @value expression to check
     * property files for values.
     * @return PropertySourcesPlaceholderConfigurer.
     */
    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    /**
     * Jasypt encryptor using BCrypt algorithm. Requires unrestricted encryption
     * in executing JVM.
     * @return {@link StandardPBEStringEncryptor}
     */
    @Bean
    public StandardPBEStringEncryptor encryptor() {
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(this.env.getProperty(ENCRYPTOR_PASSPHRASE));
        return encryptor;
    }

    /**
     * Returns a PasswordEncoder instance.
     * @return PasswordEncoder
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
