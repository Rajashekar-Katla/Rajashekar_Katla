package uk.nhs.nhsprotect.srt.model;

import static org.apache.commons.lang.builder.ToStringBuilder.reflectionToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SECTION_SCORE_TBL")
public class SectionScore {

	@Id
	@Column(name = "ID")
	private long id;

	@Column(name = "SRT_TYPE")
	private String srtType;

	@Column(name = "YEAR")
	private String year;

	@Column(name = "RATING_TYPE")
	private String ratingType;

	@Column(name = "SECTION_NAME")
	private String sectionName;

	@Column(name = "QUESTION_ORDER_NUMBERS")
	private String questionOrderNos;

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the srtType
	 */
	public String getSrtType() {
		return srtType;
	}

	/**
	 * @param srtType
	 *            the srtType to set
	 */
	public void setSrtType(String srtType) {
		this.srtType = srtType;
	}

	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}

	/**
	 * @param year
	 *            the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * @return the ratingType
	 */
	public String getRatingType() {
		return ratingType;
	}

	/**
	 * @param ratingType
	 *            the ratingType to set
	 */
	public void setRatingType(String ratingType) {
		this.ratingType = ratingType;
	}

	/**
	 * @return the sectionName
	 */
	public String getSectionName() {
		return sectionName;
	}

	/**
	 * @param sectionName
	 *            the sectionName to set
	 */
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	/**
	 * @return the questionOrderNos
	 */
	public String getQuestionOrderNos() {
		return questionOrderNos;
	}

	/**
	 * @param questionOrderNos
	 *            the questionOrderNos to set
	 */
	public void setQuestionOrderNos(String questionOrderNos) {
		this.questionOrderNos = questionOrderNos;
	}

	@Override
	public String toString() {
		return reflectionToString(this);
	}

}
