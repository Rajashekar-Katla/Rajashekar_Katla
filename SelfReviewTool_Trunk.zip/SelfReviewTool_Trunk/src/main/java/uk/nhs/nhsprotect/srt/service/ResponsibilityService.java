/**
 * 
 */
package uk.nhs.nhsprotect.srt.service;

import java.util.List;

import uk.nhs.nhsprotect.srt.dto.ResponsibilityDTO;
import uk.nhs.nhsprotect.srt.exception.SrtException;

/**
 * @author bvaidya
 */

public interface ResponsibilityService {

  /**
   * Get list of Responsibilities by staffId.
   * @param staffId
   * @return
   * @throws SrtException
   */
  List<ResponsibilityDTO> getResponsibilitiesByStaffId(String staffId) throws SrtException;

  /**
   * Get responsibility by user name and orgCode.
   * @param userRef the user name
   * @param orgCode the organisation code
   * @return
   * @throws SrtException
   */
  List<ResponsibilityDTO> getResponsibilityByPersonAndOrg(String userRef, String orgCode) throws SrtException;

  /**
   * Get responsibility by orgCode.
   * @param orgToken
   * @return
   * @throws SrtException
   */
  List<ResponsibilityDTO> getResponsibilitiesByOrgCode(String orgCode) throws SrtException;

}
