/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.StaffHeadcountDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.StaffHeadcount;
import uk.nhs.nhsprotect.srt.service.StaffHeadcountService;

/**
 * @author bvaidya
 */
@Service("staffHeadcountService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class StaffHeadcountServiceImpl implements StaffHeadcountService {

    @Autowired
    StaffHeadcountDao staffHeadcountDao;

    /**
     * @param staffHeadcountDao the staffHeadcountDao to set
     */
    public void setStaffHeadcountDao(StaffHeadcountDao staffHeadcountDao) {
        this.staffHeadcountDao = staffHeadcountDao;
    }

    /*
     * Service method to retrieve the list of staff head count options.
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.srt.service.StaffHeadcountService#
     * getListOfStaffHeadcountOptions()
     */
    @Cacheable(cacheNames = {
            "headcounts"
    }, key = "{#srtType, #year}")
    public List<StaffHeadcount> getListOfStaffHeadcountOptions(final String year, final String srtType)
            throws SrtException {
        return staffHeadcountDao.getListOfStaffHeadcountOptions(year, srtType);
    }

}
