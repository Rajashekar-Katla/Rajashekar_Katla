/**
 * Copyright (C) 2017 NHS Counter Fraud Authority ISA Information Security Analytics
 * Project: NHSPextranet
 */
package uk.nhs.nhsprotect.srt.config;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.Filter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import ro.isdc.wro.http.ConfigurableWroFilter;

/**
 * Configuration Class for Web Resource Optimiser (WRO4J).
 * @author ntones
 */
@Configuration
class Wro4jConfig {

  /**
   * "false".
   */
  private static final String STRING_FALSE = "false";

  /**
   * "true".
   */
  private static final String STRING_TRUE = "true";

  /**
   * Method to create a map of Wro4j properties.
   * @return Map<String, String> map of config properties.
   */
  private static Map<String, String> getWro4jProperties() {
    Map<String, String> properties = new HashMap<>();
    properties.put("debug", STRING_TRUE);
    properties.put("gzipEnabled", STRING_TRUE);
    properties.put("cacheGzippedContent", STRING_TRUE);
    properties.put("jmxEnabled", STRING_FALSE);
    properties.put("mbeanName", "wro");
    properties.put("cacheUpdatePeriod", "0");
    properties.put("modelUpdatePeriod", "0");
    properties.put("disableCache", STRING_FALSE);
    properties.put("encoding", "UTF-8");
    properties.put("managerFactoryClassName", "ro.isdc.wro.manager.factory.ConfigurableWroManagerFactory");
    properties.put("preProcessors", "cssUrlRewriting,cssImport,semicolonAppender,conformColors");
    properties.put("postProcessors", "yuiCssMin,googleClosureSimple");
    properties.put("uriLocators", "servletContext,uri,classpath");
    properties.put("hashStrategy", "CRC32");
    properties.put("namingStrategy", "hashEncoder");
    properties.put("connectionTimeout", "30000");
    properties.put("resourceWatcherUpdatePeriod", "0");
    properties.put("header",
        "Server: NHS CFA | Cache-Control: max-age=315556926 | Pragma: | X-Frame-Options: SAMEORIGIN"
            + " | X-XSS-Protection: 1; mode=block | x-content-type-options: nosniff");

    return properties;
  }

  /**
   * Method to configure the Wro4j filter to optimise web resources.
   * @return ConfigurableWroFilter
   * @throws IOException on error
   */
  @Bean(name = "wroFilter")
  public Filter wroFilter() throws IOException {
    ConfigurableWroFilter filter = new ConfigurableWroFilter();
    Properties properties = new Properties();
    properties.putAll(getWro4jProperties());
    filter.setProperties(properties);
    return filter;
  }
}