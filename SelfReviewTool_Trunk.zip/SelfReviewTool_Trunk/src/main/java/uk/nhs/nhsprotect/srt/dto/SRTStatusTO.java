package uk.nhs.nhsprotect.srt.dto;

import java.io.Serializable;
import java.util.Date;

import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.model.SRTStatus;

public class SRTStatusTO implements Serializable {

  /**
   * Default version UID.
   */
  private static final long serialVersionUID = 1L;

  private Long id;

  private String orgCode;

  private String status;

  private String overallScore;

  private Person submittedBy;

  private Date submittedDate;

  private String srtType;

  private String year;

  /**
   * no-args constructor.
   */
  public SRTStatusTO() {
    // default constructor.
  }

  /**
   * Method to create an {@link SRTStatusTO} based on a source {@link SRTStatus}
   * object.
   * @param srtStatus source
   */
  public SRTStatusTO(final SRTStatus srtStatus) {
    this.id = srtStatus.getId();
    this.orgCode = srtStatus.getOrgCode();
    this.overallScore = srtStatus.getOverallScore();
    this.srtType = srtStatus.getSrtType();
    this.status = srtStatus.getStatus();
    this.submittedBy = srtStatus.getSubmittedBy();
    this.submittedDate = srtStatus.getSubmittedDate();
    this.year = srtStatus.getYear();
  }

  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id the id to set
   */
  public void setId(Long id) {
    this.id = id;
  }

  /**
   * @return the orgCode
   */
  public String getOrgCode() {
    return orgCode;
  }

  /**
   * @param orgCode the orgCode to set
   */
  public void setOrgCode(String orgCode) {
    this.orgCode = orgCode;
  }

  /**
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * @param status the status to set
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * @return the overallScore
   */
  public String getOverallScore() {
    return overallScore;
  }

  /**
   * @param overallScore the overallScore to set
   */
  public void setOverallScore(String overallScore) {
    this.overallScore = overallScore;
  }

  /**
   * @return the submittedBy
   */
  public Person getSubmittedBy() {
    return submittedBy;
  }

  /**
   * @param submittedBy the submittedBy to set
   */
  public void setSubmittedBy(Person submittedBy) {
    this.submittedBy = submittedBy;
  }

  /**
   * @return the submittedDate
   */
  public Date getSubmittedDate() {
    return submittedDate;
  }

  /**
   * @param submittedDate the submittedDate to set
   */
  public void setSubmittedDate(Date submittedDate) {
    this.submittedDate = submittedDate;
  }

  /**
   * @return the srtType
   */
  public String getSrtType() {
    return srtType;
  }

  /**
   * @param srtType the srtType to set
   */
  public void setSrtType(String srtType) {
    this.srtType = srtType;
  }

  /**
   * @return the year
   */
  public String getYear() {
    return year;
  }

  /**
   * @param year the year to set
   */
  public void setYear(String year) {
    this.year = year;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    return result;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    SRTStatusTO other = (SRTStatusTO) obj;
    if (id == null) {
      if (other.id != null) {
        return false;
      }
    } else if (!id.equals(other.id)) {
      return false;
    }
    return true;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "SRTStatusTO [id=" + id + ", orgCode=" + orgCode + ", status=" + status + ", overallScore=" + overallScore
        + ", submittedBy=" + submittedBy + ", submittedDate=" + submittedDate + ", srtType=" + srtType + ", year="
        + year + "]";
  }

}
