/**
 * 
 */
package uk.nhs.nhsprotect.srt.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import com.itextpdf.text.Anchor;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.ChapterAutoNumber;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import uk.nhs.nhsprotect.srt.dto.SRTSummary;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTStatus;

/**
 * @author bvaidya
 */
@Repository
public class PDFGenerationUtility {

  public File generateSRTProcessSummaryPDF(List<SRTSummary> list, SRTStatus status) throws SrtException {

    Document document = new Document();

    List<SRTSummary> generalTabList = new ArrayList<SRTSummary>();

    List<SRTSummary> sgovernanceTabList = new ArrayList<SRTSummary>();

    List<SRTSummary> informinvolveTabList = new ArrayList<SRTSummary>();

    List<SRTSummary> preventdeterTabList = new ArrayList<SRTSummary>();

    List<SRTSummary> holdtoaccountTabList = new ArrayList<SRTSummary>();

    File tempFile = null;
    try {
      tempFile = File.createTempFile("SRT_" + status.getOrgCode() + "_" + status.getYear() + "_" + status.getSrtType(),
          ".pdf");

      FileGenerationUtility.populateQuestionListBySections(list, generalTabList, sgovernanceTabList,
          informinvolveTabList, preventdeterTabList, holdtoaccountTabList);

      PdfWriter.getInstance(document, new FileOutputStream(tempFile));

      // Open the pdf document
      document.open();

      // Add header
      if (null != status) {
        createHeaderPage(document, status.getOverallScore(), status.getOrgCode(), status.getStatus(),
            (null != status.getSubmittedBy() ? status.getSubmittedBy().getFullname() : ""), status.getSubmittedDate());
      }
      // Create section main menus
      createSectionMenu(document);

      // Populate table with all questions info by each section
      createTableToShowSummaryByEachTab(document, generalTabList, sgovernanceTabList, informinvolveTabList,
          preventdeterTabList, holdtoaccountTabList);

    } catch (IOException | DocumentException e) {
      throw new SrtException(e);
    } finally {
      // Close the pdf document
      document.close();
    }

    return tempFile;

  }

  /**
   * Helper method to generate header part of summary pdf including overall
   * score.
   * @param document
   * @throws DocumentException
   */
  private void createHeaderPage(Document document, String overallScore, String orgCode, String status, String userName,
      Date submittedDate) throws DocumentException {
    Font font = new Font(FontFamily.HELVETICA, 20, Font.BOLD, BaseColor.BLACK);
    Phrase phrase = new Phrase("SRT Process Summary", font);
    Paragraph paragraph = new Paragraph(phrase);
    paragraph.setAlignment(Element.ALIGN_CENTER);
    document.add(paragraph);
    if (null != overallScore) {
      int score = Integer.parseInt(overallScore);
      String colour = SRTUtil.getColorFromRatingValue(score);
      if (colour.equals("RED")) {
        font = new Font(FontFamily.HELVETICA, 13, Font.BOLD, BaseColor.RED);
      } else if (colour.equals("GREEN")) {
        font = new Font(FontFamily.HELVETICA, 13, Font.BOLD, BaseColor.GREEN);
      } else if (colour.equals("AMBER")) {
        font = new Font(FontFamily.HELVETICA, 13, Font.BOLD, BaseColor.ORANGE);
      } else {
        font = new Font(FontFamily.HELVETICA, 13, Font.BOLD, BaseColor.BLACK);
      }
      phrase = new Phrase(colour, font);
      paragraph = new Paragraph("Overall Score : ");
      paragraph.add(phrase);
      paragraph.setAlignment(Element.ALIGN_CENTER);
      document.add(paragraph);
      Paragraph emptyParagraph = new Paragraph(" ");
      document.add(emptyParagraph);
      if (null != status && status.equals("SUBMITTED")) {
        paragraph = new Paragraph("Submitted By : " + userName);
        paragraph.setAlignment(Element.ALIGN_CENTER);
        document.add(paragraph);
        if (null != submittedDate) {
          paragraph = new Paragraph("Submitted Date : " + SRTUtil.DATE_TIME_FORMAT.format(submittedDate));
          paragraph.setAlignment(Element.ALIGN_CENTER);
          document.add(paragraph);
        }
      } else {
        paragraph = new Paragraph("Status: Draft");
        paragraph.setAlignment(Element.ALIGN_CENTER);
        document.add(paragraph);
      }
    }

  }

  /**
   * Helper method to generate tables to populate question info by each section.
   * @param document
   * @param generalTabList
   * @param sgovernanceTabList
   * @param informinvolveTabList
   * @param preventdeterTabList
   * @param holdtoaccountTabList
   * @throws DocumentException
   */
  private void createTableToShowSummaryByEachTab(Document document, List<SRTSummary> generalTabList,
      List<SRTSummary> sgovernanceTabList, List<SRTSummary> informinvolveTabList, List<SRTSummary> preventdeterTabList,
      List<SRTSummary> holdtoaccountTabList) throws DocumentException {
    if (null != generalTabList && !generalTabList.isEmpty()) {
      addTargetSectionHeader("General", "generalTable", document);
      createTableToShowSummaryForGeneralTab(generalTabList, document);
    }

    if (null != sgovernanceTabList && !sgovernanceTabList.isEmpty()) {
      addTargetSectionHeader("Strategic Governance", "sgovernanceTable", document);
      createTableToShowSummaryByEachTab(sgovernanceTabList, document, "1.");
    }

    if (null != informinvolveTabList && !informinvolveTabList.isEmpty()) {
      addTargetSectionHeader("Inform and Involve", "informinvolveTable", document);
      createTableToShowSummaryByEachTab(informinvolveTabList, document, "2.");
    }

    if (null != preventdeterTabList && !preventdeterTabList.isEmpty()) {
      addTargetSectionHeader("Prevent and Deter", "preventdeterTable", document);
      createTableToShowSummaryByEachTab(preventdeterTabList, document, "3.");
    }

    if (null != holdtoaccountTabList && !holdtoaccountTabList.isEmpty()) {
      addTargetSectionHeader("Hold to Account", "holdtoaccountTable", document);
      createTableToShowSummaryByEachTab(holdtoaccountTabList, document, "4.");
    }

  }

  /**
   * Helper method to generate section menus.
   * @param document
   * @throws DocumentException
   */
  private void createSectionMenu(Document document) throws DocumentException {
    Font font1 = new Font(FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.BLACK);
    Chapter chapter = new ChapterAutoNumber(new Paragraph(new Phrase("Sections", font1)));
    chapter.addSection(createSection("General", "#generalTable"));
    chapter.addSection(createSection("Strategic Governance", "#sgovernanceTable"));
    chapter.addSection(createSection("Inform and Involve", "#informinvolveTable"));
    chapter.addSection(createSection("Prevent and Deter", "#preventdeterTable"));
    chapter.addSection(createSection("Hold to Account", "#holdtoaccountTable"));

    document.add(chapter);
  }

  /**
   * Helper method to generate section menus.
   * @param anchorName
   * @param targetReference
   * @return
   * @throws DocumentException
   */
  private Paragraph createSection(String anchorName, String targetReference) throws DocumentException {

    Font font = new Font(FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
    Anchor anchor = new Anchor(anchorName, font);
    anchor.setReference(targetReference);
    Paragraph paragraph = new Paragraph();
    paragraph.add(anchor);
    return paragraph;
  }

  /**
   * Helper method to generate target section header on table per section.
   * @param sectionName
   * @param targetTableName
   * @param document
   * @throws DocumentException
   */
  private void addTargetSectionHeader(String sectionName, String targetTableName, Document document)
      throws DocumentException {

    Font font = new Font(FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
    Anchor anchor = new Anchor(sectionName, font);
    anchor.setName(targetTableName);
    Paragraph paragraph = new Paragraph();
    paragraph.add(anchor);
    paragraph.setSpacingBefore(10f);
    document.add(paragraph);
  }

  /**
   * Helper method to generate tables to populate question info by each section.
   * @param list
   * @param document
   * @throws DocumentException
   */
  private void createTableToShowSummaryByEachTab(List<SRTSummary> list, Document document, String indexRef)
      throws DocumentException {

    createHeaderTable(document);
    PdfPTable table = new PdfPTable(4); // 4 columns.
    table.setWidthPercentage(100);
    float[] columnWidths = {
        0.3f, 3f, 0.5f, 1f
    };
    table.setWidths(columnWidths);

    int x = 1;

    for (SRTSummary srtSummary : list) {
      table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);

      table.addCell(indexRef + x);

      Font font = null;
      font = new Font(FontFamily.HELVETICA, 10, Font.NORMAL);
      if (!StringUtils.isEmpty(srtSummary.getQuestionText())) {
        table.addCell(new PdfPCell(new Paragraph(new Phrase(srtSummary.getQuestionText() + "", font))));
      } else {
        table.addCell(new PdfPCell(new Paragraph(new Phrase(srtSummary.getQuestionText() + ""))));
      }
      String colour = null;
      Paragraph colorParagraph;

      if (null != srtSummary.getScore()) {

        colour = SRTUtil.getColorFromRatingValue(srtSummary.getScore());

        if (null != colour) {

          if (colour.equals("RED")) {
            font = new Font(FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.RED);
          } else if (colour.equals("GREEN")) {
            font = new Font(FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.GREEN);
          } else if (colour.equals("AMBER")) {
            font = new Font(FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.ORANGE);
          } else {
            font = new Font(FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
          }
          colorParagraph = new Paragraph(new Phrase(colour, font));
          colorParagraph.setAlignment(Element.ALIGN_CENTER);
          table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
          table.addCell(colorParagraph);
        }

      } else {
        table.addCell(new PdfPCell(new Paragraph(new Phrase(colour))));
      }
      if (!StringUtils.isEmpty(srtSummary.getComments())) {
        font = new Font(FontFamily.HELVETICA, 10, Font.NORMAL);
        table.addCell(new PdfPCell(new Paragraph(new Phrase(srtSummary.getComments(), font))));
      } else {
        table.addCell(new PdfPCell(new Paragraph(new Phrase(srtSummary.getComments()))));
      }
      x = x + 1;
    }

    document.add(table);
  }

  /**
   * Helper method to generate table to populate question info for general
   * section.
   * @param list
   * @param document
   * @throws DocumentException
   */
  private void createTableToShowSummaryForGeneralTab(List<SRTSummary> list, Document document)
      throws DocumentException {
    createHeaderTableForGeneralTab(document);
    PdfPTable table = new PdfPTable(2); // 2 columns.
    table.setWidthPercentage(100);
    float[] columnWidths = {
        3f, 1f
    };
    table.setWidths(columnWidths);
    for (SRTSummary srtSummary : list) {
      Font font = null;
      font = new Font(FontFamily.HELVETICA, 10, Font.NORMAL);
      if (!StringUtils.isEmpty(srtSummary.getQuestionText())) {
        table.addCell(new PdfPCell(new Paragraph(new Phrase(srtSummary.getQuestionText() + "", font))));
      } else {
        table.addCell(new PdfPCell(new Paragraph(new Phrase(srtSummary.getQuestionText() + ""))));
      }

      if (!StringUtils.isEmpty(srtSummary.getComments())) {
        font = new Font(FontFamily.HELVETICA, 10, Font.NORMAL);
        table.addCell(new PdfPCell(new Paragraph(new Phrase(srtSummary.getComments(), font))));
      } else {
        table.addCell(new PdfPCell(new Paragraph(new Phrase(srtSummary.getComments()))));
      }
    }
    document.add(table);
  }

  /**
   * Helper method to generate heading for table to populate question info for
   * general section.
   * @param document
   * @throws DocumentException
   */
  private void createHeaderTableForGeneralTab(Document document) throws DocumentException {
    PdfPTable headerTable = new PdfPTable(2);
    headerTable.setWidthPercentage(100);
    float[] columnWidths = {
        3f, 1f
    };
    headerTable.setWidths(columnWidths);
    headerTable.setSpacingBefore(15f);
    Font font = new Font(FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
    headerTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
    Phrase phrase = new Phrase("Standard", font);
    headerTable.addCell(phrase);
    headerTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
    phrase = new Phrase("Comments", font);
    headerTable.addCell(phrase);
    document.add(headerTable);
  }

  /**
   * Helper method to generate headings for tables to populate question info per
   * each section.
   * @param document
   * @throws DocumentException
   */
  private void createHeaderTable(Document document) throws DocumentException {

    PdfPTable headerTable = new PdfPTable(4);
    headerTable.setWidthPercentage(100);
    float[] columnWidths = {
        0.3f, 3f, 0.5f, 1f
    };
    headerTable.setWidths(columnWidths);
    headerTable.setSpacingBefore(15f);
    Font font = new Font(FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
    headerTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
    Phrase phrase = new Phrase("No", font);
    headerTable.addCell(phrase);
    headerTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
    phrase = new Phrase("Standard", font);
    headerTable.addCell(phrase);
    headerTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
    phrase = new Phrase("Rating", font);
    headerTable.addCell(phrase);
    headerTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
    phrase = new Phrase("Comments", font);
    headerTable.addCell(phrase);
    document.add(headerTable);
  }

}
