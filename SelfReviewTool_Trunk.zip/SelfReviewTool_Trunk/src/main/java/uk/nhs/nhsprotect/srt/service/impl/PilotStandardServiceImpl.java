package uk.nhs.nhsprotect.srt.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import uk.nhs.nhsprotect.srt.dao.PilotStandardDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.PilotStandard;
import uk.nhs.nhsprotect.srt.service.PilotStandardService;

@Service(value = "pilotStandardService")
public class PilotStandardServiceImpl implements PilotStandardService {

	@Autowired
	private PilotStandardDao pilotStandardDao;

	@Override
	public void getPilotStandardData(final Map<String, Long> pilotStandardMap) throws SrtException {
		final List<PilotStandard> pilotStandardList = pilotStandardDao
				.getPilotStandardData(pilotStandardMap);

		pilotStandardList.stream().forEach(pilotStandard -> {
			final String year = pilotStandard.getYear();
			final Long questionId = pilotStandard.getQuestionId();

			pilotStandardMap.put(year, questionId);
		});

	}
}
