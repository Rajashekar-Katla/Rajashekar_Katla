/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import uk.nhs.nhsprotect.srt.util.SRTUtil;

/**
 * @author bvaidya
 */
@Entity
@Table(name = "REGION_ORG_VIEW_JP")
public class RegionOrgMapping implements Serializable{

    /**
     * Default Serial Version.
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "TEAM_ORG_ID")
    private Long teamOrgId;
    @Column(name = "REGION_CODE")
    private String regionCode;
    @Column(name = "ORG_CODE")
    private String orgCode;

    /**
     * @return the teamOrgId
     */
    public Long getTeamOrgId() {
        return teamOrgId;
    }

    /**
     * @param teamOrgId the teamOrgId to set
     */
    public void setTeamOrgId(Long teamOrgId) {
        this.teamOrgId = teamOrgId;
    }

    /**
     * @return the regionCode
     */
    public String getRegionCode() {
        return regionCode;
    }

    /**
     * @param regionCode the regionCode to set
     */
    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    /**
     * @return the orgCode
     */
    public String getOrgCode() {
        return orgCode;
    }

    /**
     * @param orgCode the orgCode to set
     */
    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public boolean isWelshRegion() {
        return SRTUtil.WELSH_REGION_CODE.equals(this.regionCode);
    }

}
