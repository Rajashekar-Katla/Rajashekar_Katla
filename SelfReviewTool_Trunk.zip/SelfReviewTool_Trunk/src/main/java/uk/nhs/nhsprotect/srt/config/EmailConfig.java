package uk.nhs.nhsprotect.srt.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

/**
 * Configuration class for email services.
 * @author nmarsh
 */
@Configuration
public class EmailConfig {

    /**
     * The current application environment.
     */
    @Autowired
    private Environment env;

    /**
     * The name of the email host environment variable.
     */
    private static final String EMAIL_HOST = "email.host";

    /**
     * The name of the email port environment variable.
     */
    private static final String EMAIL_PORT = "email.port";

    /**
     * JavaMailSender instance.
     * @return configured mailSender
     */
    @Bean
    public JavaMailSender mailSender() {
        final JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(this.env.getProperty(EMAIL_HOST));
        mailSender.setPort(Integer.parseInt(this.env.getProperty(EMAIL_PORT)));
        return mailSender;
    }

    /**
     * Template SimpleMailMessage for email sending.
     * @return SimpleMailMessage template.
     */
    @Bean
    public SimpleMailMessage simpleMailMessage() {
        final SimpleMailMessage templateMessage = new SimpleMailMessage();
        templateMessage.setFrom(env.getProperty("email.from"));
        templateMessage.setSubject(env.getProperty("email.subject"));
        return templateMessage;
    }

}
