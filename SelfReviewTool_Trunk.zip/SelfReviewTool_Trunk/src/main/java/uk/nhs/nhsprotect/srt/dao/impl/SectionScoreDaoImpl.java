package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.SectionScoreDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SectionScore;

@Repository(value = "sectionScoreDao")
public class SectionScoreDaoImpl extends SRTHibernateDaoSupportImpl implements
		SectionScoreDao {

	@Override
	public List<SectionScore> getSectionScoreData() throws SrtException {
		final Query<SectionScore> query = getCurrentSession().createQuery(
				"from SectionScore s order by s.id asc", SectionScore.class);
		final List<SectionScore> queryResult = query.getResultList();
		return queryResult;
	}

}
