package uk.nhs.nhsprotect.srt.util;

import java.util.List;
import java.util.Map;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.nhs.nhsprotect.srt.dto.ChoiceQuestion;
import uk.nhs.nhsprotect.srt.dto.SRTForm;
import uk.nhs.nhsprotect.srt.enums.PilotStandardMap;
import uk.nhs.nhsprotect.srt.enums.ScoreThresholdMap;
import uk.nhs.nhsprotect.srt.enums.SectionScoreMap;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SCORE;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRT_SECTION;

/**
 * Class containing methods to assist or perform SRT score calculations.
 * 
 * @author ntones
 */
public class SRTCalculationsUtil {

	private static final String OR_SYMBOL = "||";

	private static final String DOUBLE_AMPERSAND = "&&";

	private static final String OR = "OR";

	private static final String AND = "AND";

	private static final String JAVA_SCRIPT = "JavaScript";

	/**
	 * Class logger instance.
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SRTCalculationsUtil.class);

	private static final String NEUTRAL = "NEUTRAL";

	private static final String RED = "RED";

	private static final String AMBER = "AMBER";

	/**
	 * The singleton instance of SRTCalculationsUtil.
	 */
	private static SRTCalculationsUtil instance = null;

	private Map<String, String> sectionScoreMap = null;

	private Map<String, Float> scoreThresholdMap = null;

	private Map<String, Long> pilotStandardMap = null;

	private static final String SECTION_RATING_TYPE = "SECTION";

	private static final String SUPER_RATING_TYPE = "SUPER";

	/**
	 * Constructor for singleton.
	 * 
	 * @throws SrtException
	 */
	private SRTCalculationsUtil() throws SrtException {
		// prevent instantiation outside of getInstance method
		sectionScoreMap = getSectionScoreMap();
		scoreThresholdMap = getScoreThresholdMap();
		pilotStandardMap = getPilotStandardMap();
	}

	/**
	 * Provides the instance of SRTCalculationsUtil or generates a new instance
	 * if required.
	 * 
	 * @return SRTCalculationsUtil instance
	 * @throws SrtException
	 */
	public static SRTCalculationsUtil getInstance() throws SrtException {
		if (instance == null) {
			instance = new SRTCalculationsUtil();
		}
		return instance;
	}

	private Map<String, String> getSectionScoreMap() throws SrtException {

		final Map<String, String> sectionScoreMap = SectionScoreMap.MAP
				.getSectionScoreMap();

		return sectionScoreMap;
	}

	private Map<String, Float> getScoreThresholdMap() throws SrtException {

		final Map<String, Float> sectionScoreMap = ScoreThresholdMap.MAP
				.getScoreThresholdMap();

		return sectionScoreMap;
	}

	private Map<String, Long> getPilotStandardMap() throws SrtException {

		final Map<String, Long> pilotStandardMap = PilotStandardMap.MAP
				.getPilotStandardMap();

		return pilotStandardMap;
	}

	/**
	 * Method to apply business defined weighting to SRT scores.
	 * 
	 * @param form
	 *            SRT to be weighted
	 * @param year
	 *            SRT year
	 * @param srtType
	 *            SRT type
	 * @throws SrtException
	 * @throws ScriptException
	 */
	public void updateScores(final SRTForm form, final String srtType,
			final String year) throws SrtException {

		try {
			if (checkSuperRatingApplies(form, srtType, year)) {
				setAllSectionsToRed(form);
				return;
			}

			// create a new calculations object for this form
			SRTCalculationHolder calculationHolder = createSRTCalculationHolder(
					form, srtType, year);

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Result of calculation: " + calculationHolder);
			}

			form.setStrgSecScore(calculationHolder.getStrgSecScore());
			form.setINISecScore(calculationHolder.getIniSecScore());
			form.setPNDSecScore(calculationHolder.getPndSecScore());
			form.setHTASecScore(calculationHolder.getHtaSecScore());
			form.setTotalScore(calculationHolder.getTotalScore());
		} catch (ScriptException ex) {
			throw new SrtException(ex);
		}

	}

	/**
	 * Method to determine if super rating applies to this form.
	 * 
	 * @param form
	 *            to be checked
	 * @param srtType
	 *            srt type
	 * @param year
	 *            srt year
	 * @return true if an appropriate super rating field is populated.
	 * @throws ScriptException
	 */

	private boolean checkSuperRatingApplies(final SRTForm form,
			final String srtType, final String year) throws ScriptException {

		boolean superRatingApplies = false;
		boolean finalScore = false;

		final String questionOrderNo = getValuesFromSectionScoreMap(
				SRT_SECTION.STRATEGIC_GOVERNANCE.toString(), srtType, year,
				SUPER_RATING_TYPE);

		if (null != questionOrderNo) {
			finalScore = getFinalScore(form, SRT_SECTION.STRATEGIC_GOVERNANCE,
					questionOrderNo);
		}

		if (finalScore) {
			superRatingApplies = true;
		}
		return superRatingApplies;
	}

	private String getValuesFromSectionScoreMap(final String sectionName,
			final String srtType, final String year, final String ratingType) {

		final String key = sectionName + srtType + year + ratingType;
		final String value = this.sectionScoreMap.get(key);
		return value;
	}

	/**
	 * Method to calculate the overall score of an SRT.
	 * 
	 * @param year
	 *            year of SRT
	 * @param scores
	 *            from each section.
	 * @return String overall rating
	 */
	private String calculateScore(final String year, final String... scores) {

		int totalScore = 0;
		float averageScore = 0f;

		for (String score : scores) {

			totalScore += Integer.valueOf(score);
		}

		if (totalScore != 0) {

			averageScore = (float) totalScore / (float) scores.length;
		}

		// apply rounding
		String roundedScore = roundScore(averageScore, year);

		if (LOGGER.isDebugEnabled()) {

			LOGGER.debug(" calculateScore - totalScore: " + totalScore
					+ "numberOfElements " + scores.length + " averageScore "
					+ averageScore + " rounded score " + roundedScore);
		}

		return roundedScore;
	}

	/**
	 * Method to calculate the overall rating for a group of questions.
	 * 
	 * @param choiceQuestions
	 *            questions to be included in calculation
	 * @param year
	 *            the year of the SRT
	 * @return String rating result.
	 */
	private String calculateScore(final List<ChoiceQuestion> choiceQuestions,
			final String year) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Calculating average score for questions using "
					+ year + " weighting.");
		}
		int totalScore = 0;
		float averageScore = 0f;
		int divisor = 0;

		for (ChoiceQuestion choiceQuestion : choiceQuestions) {

			// do not include neutral or not applicable responses in calculation
			// also ignore pilot standard 2.7 - 2015 Security SRT and standard
			// 2.6 - 2016 Security provider SRT.
			//choiceQuestion.setQuestionValue(randomInt());

			if (choiceQuestion.getQuestionValue() > 0
					&& !pilotStandardMap.containsValue(choiceQuestion
							.getQuestionId())) {
				totalScore += choiceQuestion.getQuestionValue();
				divisor++;
			}
		}

		if (totalScore > 0 && divisor > 0) {

			averageScore = (float) totalScore / (float) divisor;
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Average score before weighting. =" + averageScore);
		}
		return roundScore(averageScore, year);
	}

	/**
	 * Method to apply business defined weighting to an average score.
	 * 
	 * @param averageScore
	 *            to be weighted
	 * @param year
	 *            year of SRT
	 * @return weighted result
	 */
	private String roundScore(final float averageScore, final String year) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Rounding average score [" + averageScore
					+ "] for using " + year + " weighting.");
		}

		int roundedScore = 0;
		final String neutralScoreKey = year + "_" + NEUTRAL;
		final String redScoreKey = year + "_" + RED;
		final String amberScoreKey = year + "_" + AMBER;

		if (scoreThresholdMap.containsKey(neutralScoreKey)
				&& averageScore < scoreThresholdMap.get(neutralScoreKey)) {
			roundedScore = SCORE.NEUTRAL.getValue();
		} else if (scoreThresholdMap.containsKey(redScoreKey)
				&& averageScore < scoreThresholdMap.get(redScoreKey)) {
			roundedScore = SCORE.RED.getValue();
		} else if (scoreThresholdMap.containsKey(amberScoreKey)
				&& averageScore < scoreThresholdMap.get(amberScoreKey)) {
			roundedScore = SCORE.AMBER.getValue();
		} else {
			roundedScore = SCORE.GREEN.getValue();
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Result of rounding = " + roundedScore);
		}

		return String.valueOf(roundedScore);
	}

	/**
	 * Method to set all form sections to RED rating.
	 * 
	 * @param form
	 *            to set
	 */
	private void setAllSectionsToRed(final SRTForm form) {
		form.setStrgSecScore(String.valueOf(SCORE.RED.getValue()));
		form.setINISecScore(String.valueOf(SCORE.RED.getValue()));
		form.setPNDSecScore(String.valueOf(SCORE.RED.getValue()));
		form.setHTASecScore(String.valueOf(SCORE.RED.getValue()));
		form.setTotalScore(String.valueOf(SCORE.RED.getValue()));

	}

	/**
	 * Method to retrieve a questions score from a section given it's order.
	 * 
	 * @param srtForm
	 *            form to query
	 * @param section
	 *            section to query
	 * @param questionOrderNo
	 *            position of question to extract
	 * @return value of question answer or -1 if none found
	 */
	private int getScoreByQuestionOrderNo(final SRTForm srtForm,
			final SRT_SECTION section, final int questionOrderNo) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Attempting to retieve response for section ["
					+ section + "] standard [" + questionOrderNo + "]");
		}
		ChoiceQuestion choiceQuestion = null;

		int response = -1;

		Map<Integer, ChoiceQuestion> sectionQuestionMap = getSectionQuestionMap(
				srtForm, section);

		if (sectionQuestionMap != null) {
			choiceQuestion = sectionQuestionMap.get(Integer
					.valueOf(questionOrderNo));
		}

		if (choiceQuestion != null) {
			response = choiceQuestion.getQuestionValue();
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Returning score for question: " + response);
		}
		return response;
	}

	/**
	 * Method to provide the questions for the supplied section as a map of
	 * questions keyed on question order.
	 * 
	 * @param srtForm
	 *            holding questions
	 * @param section
	 *            SRT section to retrieve questions for
	 * @return Map<Integer, ChoiceQuestion>
	 */
	private Map<Integer, ChoiceQuestion> getSectionQuestionMap(
			final SRTForm srtForm, final SRT_SECTION section) {
		Map<Integer, ChoiceQuestion> sectionQuestionMap = null;

		switch (section) {
		case STRATEGIC_GOVERNANCE:
			sectionQuestionMap = srtForm.getStrgSecQuestionsKeyedByOrder();
			break;
		case INFORM_AND_INVOLVE:
			sectionQuestionMap = srtForm.getINISecQuestionsKeyedByOrder();
			break;
		case PREVENT_AND_DETER:
			sectionQuestionMap = srtForm.getPNDSecQuestionsKeyedByOrder();
			break;
		case HOLD_TO_ACCOUNT:
			sectionQuestionMap = srtForm.getHTASecQuestionsKeyedByOrder();
			break;

		default:
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("No matching section for " + section);
			}
			break;
		}

		return sectionQuestionMap;

	}

	/**
	 * Method to calculate the section score for the current selected section
	 * within an SRT Form.
	 * 
	 * @param srtForm
	 *            basis of calculation
	 * @return String section score
	 * @throws ScriptException
	 */
	public String calculateSectionScore(final SRTForm srtForm)
			throws ScriptException {

		String year = srtForm.getSrtStatus().getYear();
		String srtType = srtForm.getSrtStatus().getSrtType();
		if (checkSuperRatingApplies(srtForm, srtType, year)) {
			return String.valueOf(SCORE.RED.getValue());
		}
		String sectionScore = null;
		String currentSection = srtForm.getCurrentSection();

		if (currentSection.equals(SRTUtil.SRT_SECTION.STRATEGIC_GOVERNANCE
				.getTabRef())) {
			sectionScore = calculateSGSectionScore(srtForm,
					srtForm.getStrgSecQuestions(), year, srtType,
					SRT_SECTION.STRATEGIC_GOVERNANCE, SECTION_RATING_TYPE);
		} else if (currentSection.equals(SRTUtil.SRT_SECTION.INFORM_AND_INVOLVE
				.getTabRef())) {
			sectionScore = calculateINISectionScore(srtForm,
					srtForm.getINISecQuestions(), year, srtType,
					SRT_SECTION.INFORM_AND_INVOLVE, SECTION_RATING_TYPE);
		} else if (currentSection.equals(SRTUtil.SRT_SECTION.HOLD_TO_ACCOUNT
				.getTabRef())) {
			sectionScore = calculateHTASectionScore(srtForm,
					srtForm.getHTASecQuestions(), year, srtType,
					SRTUtil.SRT_SECTION.HOLD_TO_ACCOUNT, SECTION_RATING_TYPE);
		} else if (currentSection.equals(SRTUtil.SRT_SECTION.PREVENT_AND_DETER
				.getTabRef())) {
			sectionScore = calculatePNDSectionScore(srtForm,
					srtForm.getPNDSecQuestions(), year, srtType,
					SRTUtil.SRT_SECTION.PREVENT_AND_DETER, SECTION_RATING_TYPE);
		}

		return sectionScore;

	}

	/**
	 * Method to calculate the Strategic Governance section score for an SRT.
	 * 
	 * @param srtForm
	 *            the form providing details
	 * @param year
	 *            the year of the srt
	 * @param srtType
	 *            the type of srt
	 * @return calculated section score
	 * @throws ScriptException
	 */
	private String calculateSGSectionScore(final SRTForm srtForm,
			final List<ChoiceQuestion> choiceQuestions, final String year,
			final String srtType, final SRT_SECTION sectionName,
			final String ratingType) throws ScriptException {
		return calculateScoreForSection(srtForm, choiceQuestions, year,
				srtType, sectionName, ratingType);
	}

	/**
	 * Method to calculate the Inform and Involve section score for an SRT.
	 * 
	 * @param srtForm
	 *            the form providing details
	 * @param year
	 *            the year of the srt
	 * @param srtType
	 *            the srt type
	 * @return calculated section score
	 * @throws ScriptException
	 */
	private String calculateINISectionScore(final SRTForm srtForm,
			final List<ChoiceQuestion> choiceQuestions, final String year,
			final String srtType, final SRT_SECTION sectionName,
			final String ratingType) throws ScriptException {
		return calculateScoreForSection(srtForm, choiceQuestions, year,
				srtType, sectionName, ratingType);
	}

	/**
	 * Method to calculate the overall section score for Prevent and Deter.
	 * 
	 * @param srtForm
	 *            to be calculated
	 * @param year
	 *            of srt
	 * @param srtType
	 *            the srt type
	 * @return String value of section score
	 * @throws ScriptException
	 */
	private String calculatePNDSectionScore(final SRTForm srtForm,
			final List<ChoiceQuestion> choiceQuestions, final String year,
			final String srtType, final SRT_SECTION sectionName,
			final String ratingType) throws ScriptException {
		return calculateScoreForSection(srtForm, choiceQuestions, year,
				srtType, sectionName, ratingType);
	}

	/**
	 * @param srtForm
	 * @param year
	 * @param srtType
	 * @param sectionName
	 * @return
	 * @throws ScriptException
	 */
	private String calculateScoreForSection(final SRTForm srtForm,
			final List<ChoiceQuestion> choiceQuestion, final String year,
			final String srtType, final SRT_SECTION sectionName,
			final String ratingType) throws ScriptException {

		String score = null;

		boolean finalScore = false;

		final String questionOrderNo = getValuesFromSectionScoreMap(
				sectionName.toString(), srtType, year, ratingType);

		if (null != questionOrderNo) {
			finalScore = getFinalScore(srtForm, sectionName, questionOrderNo);
		}

		if (finalScore) {
			score = Integer.toString(SCORE.RED.getValue());
		}

		if (StringUtils.isEmpty(score)) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Calculating PND Score - standard calculation");
			}
			score = calculateScore(choiceQuestion, year);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("PND Score = " + score);
		}
		return score;
	}

	/**
	 * Method to calculate the Hold to Account section score for an SRT.
	 * 
	 * @param srtForm
	 *            the form providing details
	 * @param year
	 *            the year of the srt
	 * @param srtType
	 *            the type of srt
	 * @return calculated section score
	 * @throws ScriptException
	 */
	private String calculateHTASectionScore(final SRTForm srtForm,
			final List<ChoiceQuestion> choiceQuestions, final String year,
			final String srtType, final SRT_SECTION sectionName,
			final String ratingType) throws ScriptException {
		return calculateScoreForSection(srtForm, choiceQuestions, year,
				srtType, sectionName, ratingType);
	}

	/**
	 * Method to calculate the overall SRT score for a form.
	 * 
	 * @param srtForm
	 *            to be calculated
	 * @return String total score.
	 * @throws SrtException
	 * 
	 */
	public String calculateSRTScore(final SRTForm srtForm) throws SrtException {
		String srtType = srtForm.getSrtStatus().getSrtType();
		String year = srtForm.getSrtStatus().getYear();
		// Create a new calculation object
		SRTCalculationHolder calculationHolder = null;
		try {
			calculationHolder = createSRTCalculationHolder(srtForm, srtType,
					year);
		} catch (ScriptException e) {
			throw new SrtException(e);
		}

		return calculationHolder.getTotalScore();

	}

	/**
	 * Method to generate an SRTCalculationHolder object populated with the
	 * provided forms contents.
	 * 
	 * @param srtForm
	 *            to form the basis of the calculation
	 * @param srtType
	 *            type of SRT
	 * @param year
	 *            year of SRT
	 * @return SRTCalculaionHolder populated with srtForm
	 * @throws ScriptException
	 */
	private SRTCalculationHolder createSRTCalculationHolder(
			final SRTForm srtForm, final String srtType, final String year)
			throws ScriptException {
		String strgSecScore = String.valueOf(SCORE.RED.getValue());
		String iniSecScore = String.valueOf(SCORE.RED.getValue());
		String pndSecScore = String.valueOf(SCORE.RED.getValue());
		String htaSecScore = String.valueOf(SCORE.RED.getValue());

		if (!checkSuperRatingApplies(srtForm, srtType, year)) {

			// default calculations
			strgSecScore = calculateSGSectionScore(srtForm,
					srtForm.getStrgSecQuestions(), year, srtType,
					SRT_SECTION.STRATEGIC_GOVERNANCE, SECTION_RATING_TYPE);
			iniSecScore = calculateINISectionScore(srtForm,
					srtForm.getINISecQuestions(), year, srtType,
					SRT_SECTION.INFORM_AND_INVOLVE, SECTION_RATING_TYPE);
			pndSecScore = calculatePNDSectionScore(srtForm,
					srtForm.getPNDSecQuestions(), year, srtType,
					SRTUtil.SRT_SECTION.PREVENT_AND_DETER, SECTION_RATING_TYPE);
			htaSecScore = calculateHTASectionScore(srtForm,
					srtForm.getHTASecQuestions(), year, srtType,
					SRTUtil.SRT_SECTION.HOLD_TO_ACCOUNT, SECTION_RATING_TYPE);
		}

		String totalScore = calculateScore(year, strgSecScore, iniSecScore,
				pndSecScore, htaSecScore);

		// create a new calculation object
		return new SRTCalculationHolder(strgSecScore, iniSecScore, pndSecScore,
				htaSecScore, totalScore);

	}

	/**
	 * Inner class for holding section and SRT scores.
	 * 
	 * @author ntones
	 */

	private class SRTCalculationHolder {
		/**
		 * Strategic Governance Section Score.
		 */
		private String strgSecScore;
		/**
		 * Inform and Involve Section Score.
		 */
		private String iniSecScore;
		/**
		 * Prevent and Deter Section Score.
		 */
		private String pndSecScore;
		/**
		 * Hold To Account Section Score.
		 */
		private String htaSecScore;

		/**
		 * Total SRT Score.
		 */
		private String totalScore;

		/**
		 * Default constructor.
		 */
		SRTCalculationHolder() {
			// Default
		}

		/**
		 * Creates an instance of SRTCalculationHolde with specified value.
		 * 
		 * @param strgSecScore
		 *            to set
		 * @param iniSecScore
		 *            to set
		 * @param pndSecScore
		 *            to set
		 * @param htaSecScore
		 *            to set
		 * @param totalScore
		 *            to set
		 */
		SRTCalculationHolder(final String strgSecScore,
				final String iniSecScore, final String pndSecScore,
				final String htaSecScore, final String totalScore) {
			this.strgSecScore = strgSecScore;
			this.iniSecScore = iniSecScore;
			this.pndSecScore = pndSecScore;
			this.htaSecScore = htaSecScore;
			this.totalScore = totalScore;
		}

		/**
		 * @return the strgSecScore
		 */
		public String getStrgSecScore() {
			return strgSecScore;
		}

		/**
		 * @param strgSecScore
		 *            the strgSecScore to set
		 */
		public void setStrgSecScore(final String strgSecScore) {
			this.strgSecScore = strgSecScore;
		}

		/**
		 * @return the iniSecScore
		 */
		public String getIniSecScore() {
			return iniSecScore;
		}

		/**
		 * @param iniSecScore
		 *            the iniSecScore to set
		 */
		public void setIniSecScore(final String iniSecScore) {
			this.iniSecScore = iniSecScore;
		}

		/**
		 * @return the pndSecScore
		 */
		public String getPndSecScore() {
			return pndSecScore;
		}

		/**
		 * @param pndSecScore
		 *            the pndSecScore to set
		 */
		public void setPndSecScore(final String pndSecScore) {
			this.pndSecScore = pndSecScore;
		}

		/**
		 * @return the htaSecScore
		 */
		public String getHtaSecScore() {
			return htaSecScore;
		}

		/**
		 * @param htaSecScore
		 *            the htaSecScore to set
		 */
		public void setHtaSecScore(final String htaSecScore) {
			this.htaSecScore = htaSecScore;
		}

		/**
		 * @return the totalScore
		 */
		public String getTotalScore() {
			return totalScore;
		}

		/**
		 * @param totalScore
		 *            the totalScore to set
		 */
		public void setTotalScore(final String totalScore) {
			this.totalScore = totalScore;
		}

		/*
		 * (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "SRTCalculationHolder [strgSecScore=" + strgSecScore
					+ ", iniSecScore=" + iniSecScore + ", pndSecScore="
					+ pndSecScore + ", htaSecScore=" + htaSecScore
					+ ", totalScore=" + totalScore + "]";
		}

	}

	private boolean getFinalScore(final SRTForm form,
			final SRT_SECTION sectionName, final String questionOrderNo)
			throws ScriptException {

		final ScriptEngine engine = new ScriptEngineManager()
				.getEngineByName(JAVA_SCRIPT);

		final StringBuilder builder = new StringBuilder();

		final String[] array = questionOrderNo.trim().split(",");

		for (String string : array) {

			boolean isDigit = Character.isDigit(string.charAt(0));

			if (string.contains("(")) {
				final StringBuilder builder2 = new StringBuilder();
				final String substring = getSubStringValue(string);

				final String[] strings = substring.split(" ");

				for (String questionOrder : strings) {

					char someChar = questionOrder.charAt(0);
					boolean isDigit_2 = Character.isDigit(someChar);

					if (isDigit_2) {
						boolean flag = getScoreByQuestionOrderNo(form,
								sectionName, Integer.valueOf(questionOrder)) == SCORE.RED
								.getValue();
						builder2.append(flag);
					} else {
						questionOrder = setLogicalOperands(questionOrder);
						builder2.append(questionOrder);
					}
				}

				builder.append(engine.eval(builder2.toString()));

			} else if (isDigit) {
				boolean flag = getScoreByQuestionOrderNo(form, sectionName,
						Integer.valueOf(string)) == SCORE.RED.getValue();
				builder.append(flag);
			} else {
				builder.append(setLogicalOperands(string));
			}
		}

		return (Boolean) engine.eval(builder.toString());
	}

	private String setLogicalOperands(String s3) {
		if (s3.trim().equalsIgnoreCase(AND)) {
			s3 = DOUBLE_AMPERSAND;
		} else if (s3.trim().equalsIgnoreCase(OR)) {
			s3 = OR_SYMBOL;
		}
		return s3;
	}

	/**
	 * @param string
	 * @return
	 */
	private String getSubStringValue(final String string) {
		final String substring = string.substring(string.indexOf('(') + 1,
				string.indexOf(')'));
		return substring;
	}
}
