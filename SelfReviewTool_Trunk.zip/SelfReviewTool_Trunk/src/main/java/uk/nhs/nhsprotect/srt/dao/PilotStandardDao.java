package uk.nhs.nhsprotect.srt.dao;

import java.util.List;
import java.util.Map;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.PilotStandard;

@FunctionalInterface
public interface PilotStandardDao {

	public List<PilotStandard> getPilotStandardData(final Map<String, Long> map)throws SrtException;

}
