package uk.nhs.nhsprotect.srt.service;

import uk.nhs.nhsprotect.srt.dto.SRTForm;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTStatus;

public interface SRTService {

	SRTForm retrieveSRTForm(String orgCode, String srtType, String staffId, String year) throws SrtException;

	void sumbitSRTForm(SRTForm sRTForm, String orgCode, String srtType, String staffId) throws SrtException;

	void draftSRTForm(SRTForm sRTForm, String orgCode, String srtType, String staffId) throws SrtException;

	SRTStatus retrieveSRTStatus(String orgCode, String srtType, String year) throws SrtException;

}
