/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.ResultsDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Result;
import uk.nhs.nhsprotect.srt.service.ResultsService;

/**
 * @author bvaidya
 */
@Service("resultsService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class ResultsServiceImpl implements ResultsService {

  @Autowired
  ResultsDao resultsDao;

  /*
   * Service impl method to persist single object of type Results (non-Javadoc)
   * @see
   * uk.nhs.nhsprotect.srt.service.ResultsService#save(uk.nhs.nhsprotect.srt.
   * model.Results)
   */
  @Transactional(readOnly = false)
  public void save(Result results) {

    resultsDao.save(results);
  }

  /*
   * Service impl method to persist list of objects of type Results
   * (non-Javadoc)
   * @see uk.nhs.nhsprotect.srt.service.ResultsService#saveAll(java.util.List)
   */
  @Transactional(readOnly = false)
  public void saveAll(List<Result> list) {

    resultsDao.saveAll(list);
  }

  /*
   * Service impl method to get the list of questions with answered comments and
   * ratings. (non-Javadoc)
   * @see uk.nhs.nhsprotect.srt.service.ResultsService#getAnsweredQuestionsList(
   * java.lang.String)
   */
  public List<Result> getAnsweredQuestionsList(String orgCode, String srtType, String year) {
    return resultsDao.getAnsweredQuestionsList(orgCode, srtType, year);
  }

}
