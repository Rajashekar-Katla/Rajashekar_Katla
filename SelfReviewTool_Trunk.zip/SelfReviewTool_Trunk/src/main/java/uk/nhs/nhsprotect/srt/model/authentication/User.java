package uk.nhs.nhsprotect.srt.model.authentication;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import uk.nhs.nhsprotect.srt.model.Person;

@Entity
@Table(name = "USERS")
public class User implements Serializable {

    private static final long serialVersionUID = 5268792925956258160L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "userId")
    @GenericGenerator(strategy = "sequence", name = "userId", parameters = {
            @Parameter(name = "sequence", value = "USER_ID_SEQNO")
    })
    @Column(name = "USER_ID")
    private Long id;

    @Column(name = "USERNAME")
    private String username;

    @Column(name = "PASSWORD")
    private String password;

    @Column(name = "ENABLED")
    private boolean enabled;

    @Column(name = "FAILED_ATTEMPTS")
    private int failedAttempts;

    @Column(name = "DEFAULT_PASSWORD_CHANGED")
    @Type(type = "yes_no")
    private boolean defaultPasswordChanged = false;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "person_id")
    private Person person;

    @Column(name = "person_id", insertable = false, updatable = false)
    private Long personId;

    @OneToMany(mappedBy = "user")
    private List<UserAuthorities> userAuthorities = new ArrayList<UserAuthorities>();

    @Transient
    private List<Authority> authorities = new ArrayList<Authority>();

    public User() {

    }

    public User(String username, String password, boolean enabled) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the enabled
     */
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * @param enabled the enabled to set
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * @return the failedAttempts
     */
    public int getFailedAttempts() {
        return failedAttempts;
    }

    /**
     * @param failedAttempts the failedAttempts to set
     */
    public void setFailedAttempts(int failedAttempts) {
        this.failedAttempts = failedAttempts;
    }

    /**
     * @return the defaultPasswordChanged
     */
    public boolean isDefaultPasswordChanged() {
        return defaultPasswordChanged;
    }

    /**
     * @param defaultPasswordChanged the defaultPasswordChanged to set
     */
    public void setDefaultPasswordChanged(boolean defaultPasswordChanged) {
        this.defaultPasswordChanged = defaultPasswordChanged;
    }

    /**
     * @return the person
     */
    public Person getPerson() {
        return person;
    }

    /**
     * @param person the person to set
     */
    public void setPerson(Person person) {
        this.person = person;
    }

    /**
     * @return the userAuthorities
     */
    public List<UserAuthorities> getUserAuthorities() {
        return userAuthorities;
    }

    /**
     * @param userAuthorities the userAuthorities to set
     */
    public void setUserAuthorities(List<UserAuthorities> userAuthorities) {
        this.userAuthorities = userAuthorities;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "User [id=" + id + ", username=" + username + ", enabled=" + enabled + ", failedAttempts="
                + failedAttempts + ", defaultPasswordChanged=" + defaultPasswordChanged + "]";
    }

    /**
     * @return the authorities
     */
    public List<Authority> getAuthorities() {
        return authorities;
    }

    /**
     * @param authorities the authorities to set
     */
    public void setAuthorities(List<Authority> authorities) {
        this.authorities = authorities;
    }

    /**
     * @return the personId
     */
    public Long getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

}
