package uk.nhs.nhsprotect.srt.enums;

import java.util.HashMap;
import java.util.Map;

public enum SectionScoreMap {
	MAP;

	private SectionScoreMap() {
	}

	final Map<String, String> map = new HashMap<String, String>();

	public Map<String, String> getSectionScoreMap() {
		return map;
	}
}
