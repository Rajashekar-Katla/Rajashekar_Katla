/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.ResultsDao;
import uk.nhs.nhsprotect.srt.model.Result;

/**
 * @author bvaidya
 */
@Repository("resultsDao")
public class ResultsDaoImpl extends SRTHibernateDaoSupportImpl implements ResultsDao {

  /*
   * Method to persist single object of type Result (non-Javadoc)
   * @see uk.nhs.nhsprotect.srt.dao.ResultsDao#save(uk.nhs.nhsprotect.srt.model
   * .Result)
   */
  public void save(final Result results) {
    getCurrentSession().saveOrUpdate(results);
  }

  /*
   * Method to persist list of objects of type Result (non-Javadoc)
   * @see uk.nhs.nhsprotect.srt.dao.ResultsDao#saveAll(java.util.List)
   */
  public void saveAll(final List<Result> list) {

    list.stream().forEach(f -> save(f));

  }

  /*
   * Method to get the list of questions with comments and ratings.
   * (non-Javadoc)
   * @see
   * uk.nhs.nhsprotect.srt.dao.ResultsDao#getAnsweredQuestionsList(java.lang
   * .String, java.lang.String)
   */
  @SuppressWarnings("unchecked")
  public List<Result> getAnsweredQuestionsList(final String orgCode, final String srtType, final String year) {

    DetachedCriteria criteria = DetachedCriteria.forClass(Result.class);
    criteria.createAlias("questionnaire", "qa").add(Restrictions.eq("qa.year", year))
        .add(Restrictions.eq("srtType", srtType)).add(Restrictions.eq("orgCode", orgCode));
    return criteria.getExecutableCriteria(getCurrentSession()).list();

  }

}
