/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Questionnaire;
import uk.nhs.nhsprotect.srt.model.QuestionnaireAndRatingScoreAndResultsModel;
import uk.nhs.nhsprotect.srt.model.SectionScore;

/**
 * @author bvaidya
 */
public interface QuestionnaireDao {

    /**
     * Get the question list for current year
     * @param region
     * @param srtType
     * @return
     * @throws SrtException
     */
    List<Questionnaire> findQuessionnaireListForCurrentYear(String region, String srtType) throws SrtException;

    /**
     * Get the question list for previous years
     * @param region
     * @param srtType
     * @param year
     * @return
     * @throws SrtException
     */
    List<Questionnaire> findQuessionnaireListForPreviousYears(String region, String srtType, String year)
            throws SrtException;
    
    public List<QuestionnaireAndRatingScoreAndResultsModel> getQuessionnaireAndResultsList(
			final String region, final String srtType, final String year,final String orgCode)
			throws SrtException;
    
    public List<SectionScore> getSectionScoreData() throws SrtException;

}
