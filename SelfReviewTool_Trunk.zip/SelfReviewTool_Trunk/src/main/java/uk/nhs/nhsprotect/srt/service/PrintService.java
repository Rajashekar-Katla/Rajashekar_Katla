/**
 * 
 */
package uk.nhs.nhsprotect.srt.service;

import java.io.File;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRTExportType;

/**
 * @author bvaidya
 */

public interface PrintService {

  /**
   * Method to generate an export file containing a particular SRT.
   * @param orgCode the organisation code
   * @param srtType the SRT type
   * @param year the year of the SRT
   * @param srtExportType the SRT Export type to be created (PDF or XLS)
   * @throws SrtException on error
   */
  File generateSRTSummary(String orgCode, String srtType, String year, SRTExportType srtExportType) throws SrtException;

}
