package uk.nhs.nhsprotect.srt.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import uk.nhs.nhsprotect.srt.dao.SectionScoreDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SectionScore;
import uk.nhs.nhsprotect.srt.service.SectionScoreService;

@Service(value = "sectionScoreService")
public class SectionScoreServiceImpl implements SectionScoreService {

	@Autowired
	private SectionScoreDao sectionScoreDao;

	@Override
	public void getSectionScoreData(final Map<String, String> sectionScoreMap)
			throws SrtException {
		final List<SectionScore> sectionScoreList = sectionScoreDao
				.getSectionScoreData();

		sectionScoreList.stream()
				.forEach(
						score -> {
							final String questionOrderNos = String
									.valueOf(score.getQuestionOrderNos());
							final String ratingType = score.getRatingType();

							// KEY = Section Name + SRT Type + Year + Rating Type

							// VALUE = Question Order no's

							final String key = score.getSectionName()
									+ score.getSrtType() + score.getYear()
									+ ratingType;

							sectionScoreMap.put(key, questionOrderNos);
						});
	}

}
