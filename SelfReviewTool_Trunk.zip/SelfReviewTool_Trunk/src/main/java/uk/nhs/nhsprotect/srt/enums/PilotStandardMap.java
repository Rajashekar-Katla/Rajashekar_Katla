package uk.nhs.nhsprotect.srt.enums;

import java.util.HashMap;
import java.util.Map;

public enum PilotStandardMap {
	MAP;

	private PilotStandardMap() {
	}

	final Map<String, Long> map = new HashMap<String, Long>();

	public Map<String, Long> getPilotStandardMap() {
		return map;
	}

}
