package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import uk.nhs.nhsprotect.srt.util.SRTUtil.ORG_TYPE;

/**
 * Class representing a CPOD Organisation entity.
 * 
 * @author ntones
 */
@Entity
@Table(name = "CPOD_ALL_ORG_CODES_VIEW")
public class Organisation implements Serializable {

	/**
	 * Default Serial Version.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * CPOD Organisation ID - Primary Key.
	 */
	@Id
	@Column(name = "ORG_ID")
	private Long orgId;

	/**
	 * CPOD Organisation Code.
	 */
	@Column(name = "ORG_CODE")
	private String orgCode;

	/**
	 * CPOD Organisation Name.
	 */
	@Column(name = "ORG_NAME")
	private String name;

	/**
	 * Organisation Type as {@link ORG_TYPE}.
	 */
	@Column(name = "ORG_TYPE_ID")
	@Type(type = "uk.nhs.nhsprotect.srt.hibernate.enums.OrgTypeUserType")
	private ORG_TYPE orgType;

	/**
	 * CPOD Organisation Open Date
	 */
	@Column(name = "OPEN_DATE")
	private String openDate;

	/**
	 * CPOD Organisation Closed Date
	 */
	@Column(name = "CLOSE_DATE")
	private Date closeDate;

	/**
	 * CPOD Organisation - DOF linked by PERSON_ID to {@link Person#getPersonId()}.
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DOF_PERSON_ID", referencedColumnName = "ID")
	private Person dofPerson;

	/**
	 * CPOD Organisation DOF Person ID for debugging.
	 */
	@Column(name = "DOF_PERSON_ID", insertable = false, updatable = false)
	private Long dofPersonId;

	/**
	 * @return the orgId
	 */
	public Long getOrgId() {
		return orgId;
	}

	/**
	 * @param orgId
	 *            the orgId to set
	 */
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	/**
	 * @return the orgCode
	 */
	public String getOrgCode() {
		return orgCode;
	}

	/**
	 * @param orgCode
	 *            the orgCode to set
	 */
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the orgType
	 */
	public ORG_TYPE getOrgType() {
		return orgType;
	}

	/**
	 * @param orgType
	 *            the orgType to set
	 */
	public void setOrgType(ORG_TYPE orgType) {
		this.orgType = orgType;
	}

	/**
	 * @return the openDate
	 */
	public String getOpenDate() {
		return openDate;
	}

	/**
	 * @param openDate
	 *            the openDate to set
	 */
	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}

	/**
	 * @return the closeDate
	 */
	public Date getCloseDate() {
		return closeDate;
	}

	/**
	 * @param closeDate
	 *            the closeDate to set
	 */
	public void setCloseDate(Date closeDate) {
		this.closeDate = closeDate;
	}

	/**
	 * @return the dofPerson
	 */
	public Person getDofPerson() {
		return dofPerson;
	}

	/**
	 * @param dofPerson
	 *            the dofPerson to set
	 */
	public void setDofPerson(Person dofPerson) {
		this.dofPerson = dofPerson;
	}

	/**
	 * @return the dofPersonId
	 */
	public Long getDofPersonId() {
		return dofPersonId;
	}

	/**
	 * @param dofPersonId
	 *            the dofPersonId to set
	 */
	public void setDofPersonId(Long dofPersonId) {
		this.dofPersonId = dofPersonId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orgId == null) ? 0 : orgId.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Organisation other = (Organisation) obj;
		if (orgId == null) {
			if (other.orgId != null) {
				return false;
			}
		} else if (!orgId.equals(other.orgId)) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Organisation [orgId=" + orgId + ", orgCode=" + orgCode + ", name=" + name + ", orgType=" + orgType
				+ ", openDate=" + openDate + ", closeDate=" + closeDate + ",  dofPersonId=" + dofPersonId + "]";
	}

	/**
	 * Identifies if the current organisation is a CCG.
	 * 
	 * @return true if OrgType = CCG
	 */
	@Transient
	public boolean isCCG() {
		return this.getOrgType().equals(ORG_TYPE.NHSE_CCG);
	}

	/**
	 * Identifies if the current organisation is a CSU.
	 * 
	 * @return true if OrgType = CSU
	 */
	@Transient
	public boolean isCSU() {
		return this.getOrgType().equals(ORG_TYPE.NHSE_CSU);
	}

	/**
	 * Identifies if the current organisation is a NHSE_AREA_TEAM.
	 * 
	 * @return true if OrgType = NHSE_AREA_TEAM
	 */
	@Transient
	public boolean isNHSEAreaTeam() {
		return this.getOrgType().equals(ORG_TYPE.NHSE_AREA_TEAM);
	}

	/**
	 * Identifies if the current organisation is an NHS Commissioning Organisation.
	 * 
	 * @return true if OrgType = NHSE_AREA_TEAM or CSU or CCG
	 */
	@Transient
	public boolean isCommissioningOrg() {
		return this.isCCG() || this.isCSU() || this.isNHSEAreaTeam();
	}

}
