/**
 * 
 */
package uk.nhs.nhsprotect.srt.exception;

/**
 * Exception class for SRT.
 * @author bvaidya
 */
public class SrtException extends Exception {

    /**
    	 * 
    	 */
    private static final long serialVersionUID = 7986114912947929450L;

    /**
    	 * 
    	 */
    public SrtException() {
    }

    /**
     * @param message
     */
    public SrtException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public SrtException(Throwable cause) {
        super(cause);
    }

    /**
     * @param message
     * @param cause
     */
    public SrtException(String message, Throwable cause) {
        super(message, cause);
    }

}
