/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.RegionOrgDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.OrganisationByTypeCCG;
import uk.nhs.nhsprotect.srt.model.OrganisationType;
import uk.nhs.nhsprotect.srt.model.RegionOrgMapping;
import uk.nhs.nhsprotect.srt.model.Regions;
import uk.nhs.nhsprotect.srt.service.RegionOrgService;

/**
 * @author bvaidya
 */
@Service("regionOrgService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class RegionOrgServiceImpl implements RegionOrgService {

    @Autowired
    private RegionOrgDao regionOrgDao;

    /*
     * Service method to get region code value for given organization code
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.srt.service.RegionOrgService#
     * getRegionCodeAsPerOrganization (java.lang.String)
     */
    @Override
    @Cacheable(cacheNames = {
            "regionCodeForOrg"
    }, key = "{#orgCode}")
    public RegionOrgMapping getRegionCodeByOrganization(final String orgCode) throws SrtException {
        return regionOrgDao.getRegionCodeByOrganization(orgCode);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.service.RegionOrgService#getOrganisationTypes(java
     * .lang.String, java.lang.String)
     */
    @Override
    @Cacheable(cacheNames = {
            "orgTypes"
    }, key = "{#srtType, #year}")
    public List<OrganisationType> getOrganisationTypes(final String srtType, final String year) throws SrtException {
        // check if the list is cached
        return regionOrgDao.getOrganisationTypes(srtType, year);
    }

    /*
     * Get the list of organisation/provider type for organisation type NHSE CCG
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.service.RegionOrgService#getProviderTypeListForCCG
     * ()
     */
    @Override
    @Cacheable(cacheNames = {
            "providerTypes"
    })
    public List<OrganisationByTypeCCG> getProviderTypeListForCCG() throws SrtException {

        return regionOrgDao.getProviderTypeListForCCG();

    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.service.RegionOrgService#getRegionList(java.lang
     * .String, java.lang.String)
     */
    @Override
    @Cacheable(cacheNames = {
            "regions"
    }, key = "{#srtType, #year, #regionType}")
    public List<Regions> getRegionList(final String srtType, final String year, final String regionType)
            throws SrtException {

        return regionOrgDao.getRegionList(srtType, year, regionType);

    }

}
