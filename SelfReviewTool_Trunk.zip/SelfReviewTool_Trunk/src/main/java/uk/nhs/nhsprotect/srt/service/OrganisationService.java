/**
 * 
 */
package uk.nhs.nhsprotect.srt.service;

import uk.nhs.nhsprotect.srt.model.Organisation;

/**
 * Interface defining methods for Organisation interactions.
 * @author ntones
 */
public interface OrganisationService {

  /**
   * Method to retrieve on organisation based on its Organisation Code.
   * @param orgCode the value to lookup
   * @return Organisation entity or null if non found.
   */
  Organisation findOrganisationByCode(String orgCode);

}
