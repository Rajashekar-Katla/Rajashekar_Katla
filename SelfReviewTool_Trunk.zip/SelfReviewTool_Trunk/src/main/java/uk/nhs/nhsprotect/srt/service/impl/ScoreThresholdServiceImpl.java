package uk.nhs.nhsprotect.srt.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import uk.nhs.nhsprotect.srt.dao.ScoreThresholdDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.ScoreThreshold;
import uk.nhs.nhsprotect.srt.service.ScoreThresholdService;

@Service(value = "scoreThresholdService")
public class ScoreThresholdServiceImpl implements ScoreThresholdService {
	
	@Autowired
	private ScoreThresholdDao scoreThresholdDao;
	

	@Override
	public void getScoreThresholdData(Map<String, Float> scoreThresholdMap)
			throws SrtException {
		
		final List<ScoreThreshold> scoreThresholdList = scoreThresholdDao
				.getScoreThresholdData();

		scoreThresholdList.stream()
				.forEach(
						scoreThreshold -> {
							final String year = scoreThreshold.getYear();
							final String type = scoreThreshold.getThresholdType();
							final float value = scoreThreshold.getThresholdValue();
							
							final String key = year+"_"+type;

							scoreThresholdMap.put(key, value);
						});
	}

}
