package uk.nhs.nhsprotect.srt.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dto.ChoiceQuestion;
import uk.nhs.nhsprotect.srt.dto.SRTForm;
import uk.nhs.nhsprotect.srt.dto.SRTStatusTO;
import uk.nhs.nhsprotect.srt.dto.TextQuestion;
import uk.nhs.nhsprotect.srt.enums.SectionNameMap;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.AnnualBudget;
import uk.nhs.nhsprotect.srt.model.Organisation;
import uk.nhs.nhsprotect.srt.model.OrganisationByTypeCCG;
import uk.nhs.nhsprotect.srt.model.OrganisationType;
import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.model.QuestionnaireAndRatingScoreAndResultsModel;
import uk.nhs.nhsprotect.srt.model.RatingScore;
import uk.nhs.nhsprotect.srt.model.RegionOrgMapping;
import uk.nhs.nhsprotect.srt.model.Regions;
import uk.nhs.nhsprotect.srt.model.Result;
import uk.nhs.nhsprotect.srt.model.SRTStatus;
import uk.nhs.nhsprotect.srt.model.StaffHeadcount;
import uk.nhs.nhsprotect.srt.service.AnnualBudgetService;
import uk.nhs.nhsprotect.srt.service.OrganisationService;
import uk.nhs.nhsprotect.srt.service.QuestionnaireService;
import uk.nhs.nhsprotect.srt.service.RegionOrgService;
import uk.nhs.nhsprotect.srt.service.ResultsService;
import uk.nhs.nhsprotect.srt.service.SRTEmailService;
import uk.nhs.nhsprotect.srt.service.SRTService;
import uk.nhs.nhsprotect.srt.service.SRTStatusService;
import uk.nhs.nhsprotect.srt.service.StaffHeadcountService;
import uk.nhs.nhsprotect.srt.service.UserService;
import uk.nhs.nhsprotect.srt.util.SRTCalculationsUtil;
import uk.nhs.nhsprotect.srt.util.SRTUtil;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRT_SECTION;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRT_TYPES;

@Service("SRTService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class SRTServiceImpl implements SRTService {

	/**
	 * Class logger instance.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(SRTServiceImpl.class);

	private static final String STATUS_DRAFT = "DRAFT";

	private static final String STATUS_SUBMIT = "SUBMIT";

	@Autowired
	private QuestionnaireService questionnaireService;
	@Autowired
	private SRTStatusService sRTStatusService;
	@Autowired
	private ResultsService resultsService;
	@Autowired
	private RegionOrgService regionOrgService;

	@Autowired
	private AnnualBudgetService annualBudgetService;
	@Autowired
	private StaffHeadcountService staffHeadcountService;
	@Autowired
	private UserService userService;

	@Autowired
	private OrganisationService organisationService;

	@Autowired
	private SRTEmailService srtEmailService;

	private Calendar calendar2016;

	/**
	 * Default constructor.
	 * 
	 * @throws SrtException
	 */
	public SRTServiceImpl() throws SrtException {
		calendar2016 = Calendar.getInstance();
		calendar2016.set(Calendar.YEAR, 2016);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * uk.nhs.nhsprotect.srt.service.SRTService#retrieveSRTForm(java.lang.String ,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	@Cacheable(cacheNames = "srtForms", key = "{#orgCode, #srtType, #staffId, #year}")
	public SRTForm retrieveSRTForm(final String orgCode, final String srtType, final String staffId, final String year)
			throws SrtException {

		final RegionOrgMapping regionOrgMapping = getRegionCode(orgCode);
		final String regionCode = regionOrgMapping.getRegionCode();
		Calendar questionnaireCalendar = Calendar.getInstance();
		questionnaireCalendar.set(Calendar.YEAR, Integer.parseInt(year));
		SRTForm form = null;
		if (LOGGER.isDebugEnabled()) {

			LOGGER.debug(
					"retrieveSRTForm Region code= " + regionCode + ",srtType= " + srtType + ",orgCode= " + orgCode);
		}

		final List<QuestionnaireAndRatingScoreAndResultsModel> questionnaireAndRatingScoreAndResultsModel = questionnaireService
				.getQuessionnaireAndResultsList(regionCode, srtType, year, orgCode);

		form = populateSRTFormWithQuestionsAndAnswers(questionnaireAndRatingScoreAndResultsModel, orgCode,
				regionOrgMapping.isWelshRegion(), srtType.contains("lcfs"));

		form.setRegionCode(regionCode);

		SRTCalculationsUtil.getInstance().updateScores(form, srtType, year);

		SRTStatus srtStatus = sRTStatusService.getSRTStatusByOrgCodeAndType(orgCode, srtType, year);

		SRTStatusTO srtStatusTO = new SRTStatusTO();
		try {
			convertToDTO(srtStatusTO, srtStatus);
		} catch (Exception e) {
			throw new SrtException(e.getMessage());
		}

		form.setSrtStatus(srtStatusTO);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("srtStatus is null ?: " + (srtStatus == null));
		}
		// this would override the calculated form total score from the one from
		// database. ???
		updateSRTStatus2Form(form, srtStatus);

		return form;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see uk.nhs.nhsprotect.srt.service.SRTService#sumbitSRTForm(uk.nhs.nhsprotect
	 * .srt.dto.SRTForm, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	@Transactional(readOnly = false)
	@Caching(evict = {
			@CacheEvict(cacheNames = "srtForms", key = "{#orgCode,#srtType,#staffId,#srtForm.srtStatus.year}"),
			@CacheEvict(cacheNames = "srtStatus", key = "{#orgCode,#srtType,#staffId,#srtForm.srtStatus.year}"),
			@CacheEvict(cacheNames = "srtSummary", key = "{#orgCode, #srtType, #srtForm.srtStatus.year}") })
	public void sumbitSRTForm(SRTForm srtForm, String orgCode, String srtType, String staffId) throws SrtException {
		saveSRTForm(srtForm, orgCode, srtType, staffId, STATUS_SUBMIT);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see uk.nhs.nhsprotect.srt.service.SRTService#draftSRTForm(uk.nhs.nhsprotect
	 * .srt.dto.SRTForm, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Transactional(readOnly = false)
	@Caching(evict = {
			@CacheEvict(cacheNames = "srtForms", key = "{#orgCode,#srtType,#staffId,#srtForm.srtStatus.year}"),
			@CacheEvict(cacheNames = "srtStatus", key = "{#orgCode,#srtType,#staffId,#srtForm.srtStatus.year}"),
			@CacheEvict(cacheNames = "srtSummary", key = "{#orgCode, #srtType, #srtForm.srtStatus.year}") })
	public void draftSRTForm(SRTForm srtForm, String orgCode, String srtType, String staffId) throws SrtException {
		saveSRTForm(srtForm, orgCode, srtType, staffId, STATUS_DRAFT);
	}

	@Override
	@Cacheable(cacheNames = "srtStatus", key = "{#orgCode, #srtType, #year}")
	public SRTStatus retrieveSRTStatus(String orgCode, String srtType, String year) throws SrtException {

		SRTStatus status = sRTStatusService.getSRTStatusByOrgCodeAndType(orgCode, srtType, year);

		if (null == status) {
			status = new SRTStatus();

		}
		return status;
	}

	private void saveSRTForm(SRTForm sRTForm, String orgCode, String srtType, String staffId, String submitType)
			throws SrtException {

		String srtTotalScore = sRTForm.getTotalScore();

		if (srtTotalScore == null) {
			SRTCalculationsUtil.getInstance().updateScores(sRTForm, srtType, sRTForm.getSrtStatus().getYear());
			srtTotalScore = sRTForm.getTotalScore();
		}

		if (LOGGER.isDebugEnabled()) {

			LOGGER.debug("saveSRTForm - staffId " + staffId + "totalscore " + srtTotalScore
					+ " strategic section score " + sRTForm.getStrgSecScore() + " submitType " + submitType
					+ " StatusId " + sRTForm.getStatusId() + " orgCode " + orgCode);
		}

		List<Result> results = prepareResults(sRTForm, srtType, staffId, orgCode, submitType);
		resultsService.saveAll(results);

		SRTStatusTO statusTO = sRTForm.getSrtStatus();

		SRTStatus status = sRTStatusService.getSRTStatusByOrgCodeAndType(statusTO.getOrgCode(), statusTO.getSrtType(),
				statusTO.getYear());

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("is srtStatus null " + (status == null));
		}

		if (null == status) {
			status = new SRTStatus();
		}
		status.setOrgCode(orgCode);

		if (orgCode.equals(status.getOrgCode())) {
			status.setSrtType(statusTO.getSrtType());
			status.setYear(statusTO.getYear());
			// TODO: check you have the correct year.
			if (null == status.getYear()) {
				status.setYear(SRTUtil.YEAR_FORMAT.format(new Date()));
			}
			status.setOverallScore(srtTotalScore);
			// from 2015 SRT we want to save the section scores...
			status.setStrategicGovernanceSectionScore(sRTForm.getStrgSecScore());
			status.setInformAndInvolveSectionScore(sRTForm.getINISecScore());
			status.setPrventAndDeterSectionScore(sRTForm.getPNDSecScore());
			status.setHoldToAccountSectionScore(sRTForm.getHTASecScore());
			if (sRTForm.getStatusId() != 0L) {
				status.setId(sRTForm.getStatusId());
			}

		}
		if (SRTUtil.SUBMIT_TYPE_SUBMIT.equalsIgnoreCase(submitType)) {
			status.setStatus(SRTUtil.SRTStatus.SUBMITTED.toString());
			Person submittedBy = null;
			if (StringUtils.isNotEmpty(staffId)) {
				submittedBy = userService.getUserDetails(staffId);
			}
			status.setSubmittedBy(submittedBy);
			status.setSubmittedDate(new Date());

		} else {
			status.setStatus(SRTUtil.SRTStatus.DRAFT.toString());
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("saveSRTForm - OrgCode " + status.getOrgCode() + " SubmittedBy " + status.getSubmittedBy()
					+ " SubmittedDate" + status.getSubmittedDate() + " OverallScore " + status.getOverallScore()
					+ " StausId " + status.getId());
		}
		sRTStatusService.saveSRTStatus(status);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("saveSRTForm - SRT Submission successfull");
		}
	}

	private void convertToDTO(SRTStatusTO dto, SRTStatus object) {
		dto.setId(object.getId());
		dto.setOrgCode(object.getOrgCode());
		dto.setOverallScore(object.getOverallScore());
		dto.setSrtType(object.getSrtType());
		dto.setStatus(object.getStatus());
		dto.setSubmittedBy(object.getSubmittedBy());
		dto.setSubmittedDate(object.getSubmittedDate());
		dto.setYear(object.getYear());
	}

	private List<Result> prepareResults(SRTForm sRTForm, String srtType, String staffId, String orgCode,
			String submitType) {

		List<Result> results = new ArrayList<>();

		List<Result> genralResults = prepareResultsFromTextSection(sRTForm.getGeneralQuestions(), srtType, staffId,
				orgCode, sRTForm.isWelshRegion(), submitType);
		List<Result> strgResults = prepareResultsFromChoiceSection(sRTForm.getStrgSecQuestions(), srtType, staffId,
				orgCode);
		List<Result> htaResults = prepareResultsFromChoiceSection(sRTForm.getHTASecQuestions(), srtType, staffId,
				orgCode);
		List<Result> iniResults = prepareResultsFromChoiceSection(sRTForm.getINISecQuestions(), srtType, staffId,
				orgCode);
		List<Result> pndResults = prepareResultsFromChoiceSection(sRTForm.getPNDSecQuestions(), srtType, staffId,
				orgCode);
		List<Result> excvResults = prepareResultsFromChoiceSection(sRTForm.getExcvSecQuestions(), srtType, staffId,
				orgCode);

		results.addAll(genralResults);
		results.addAll(strgResults);
		results.addAll(htaResults);
		results.addAll(iniResults);
		results.addAll(pndResults);
		results.addAll(excvResults);

		return results;
	}

	private List<Result> prepareResultsFromChoiceSection(List<ChoiceQuestion> choiceQuestions, String srtType,
			String staffId, String orgCode) {

		List<Result> results = new ArrayList<Result>();

		for (ChoiceQuestion choiceQuestion : choiceQuestions) {

			Result result = prepareResultFromChoiceQuestion(choiceQuestion, srtType, staffId, orgCode);
			results.add(result);
		}

		return results;
	}

	private Result prepareResultFromChoiceQuestion(ChoiceQuestion question, String srtType, String staffId,
			String orgCode) {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Wrap results Org code " + orgCode + "srtType " + srtType);
		}
		Result result = new Result();
		result.setQuestionId(question.getQuestionId());
		result.setComments(question.getComment());
		result.setCreatedBy(staffId);
		result.setModifiedDate(new Date());
		result.setCreatedDate(new Date());
		result.setModifedBy(staffId);
		result.setScore(question.getQuestionValue());
		result.setOrgCode(orgCode);
		result.setSrtType(srtType);

		if (question.getResultId() != null) {
			result.setResultId(question.getResultId());
		}

		return result;
	}

	private List<Result> prepareResultsFromTextSection(List<TextQuestion> generalQuestions, String srtType,
			String staffId, String orgCode, boolean isWelsh, String submitType) {

		List<Result> results = new ArrayList<Result>();

		for (TextQuestion genquestion : generalQuestions) {

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("prepareGenSectionResults - QuestionId" + genquestion.getQuestionId());
				LOGGER.debug("prepareGenSectionResults - QuestionText " + genquestion.getQuestionText());
				LOGGER.debug("prepareGenSectionResults - QuestionValue " + genquestion.getQuestionValue());
				LOGGER.debug("prepareGenSectionResults - srtType is " + srtType);
				LOGGER.debug("prepareGenSectionResults - ResultId is " + genquestion.getResultId());
			}
			Result result = new Result();
			result.setQuestionId(genquestion.getQuestionId());
			// TODO do we need to validate this to prevent null responses
			result.setComments(genquestion.getQuestionValue());
			result.setCreatedBy(staffId);
			result.setModifiedDate(new Date());
			result.setCreatedDate(new Date());
			result.setModifedBy(staffId);
			result.setSrtType(srtType);
			result.setOrgCode(orgCode);
			if (genquestion.getResultId() != 0L) {
				result.setResultId(genquestion.getResultId());
			}
			results.add(result);

			// verify if SMD/DOF value different from that in CPOD - only for submits not
			// drafts
			if (StringUtils.equalsIgnoreCase(submitType, "submit") && !isWelsh
					&& genquestion.getElementName().equalsIgnoreCase(SRTUtil.RESPONSIBLE_EXECUTIVE_QUESTION)) {
				verifyResponsiblePerson(orgCode, genquestion.getQuestionValue(), srtType, staffId);
			}

		}
		return results;
	}

	private void verifyResponsiblePerson(String orgCode, String questionValue, String srtType, String userName) {
		Organisation organisation = organisationService.findOrganisationByCode(orgCode);
		Person personToCheck = null;
		personToCheck = organisation.getDofPerson();

		String executiveName = "NONE";
		if (personToCheck != null) {
			executiveName = personToCheck.getFullname();
		}

		if (!executiveName.equalsIgnoreCase(questionValue)) {
			try {
				srtEmailService.notifyResponsiblePersonVerificationFail(srtType, organisation, executiveName,
						questionValue, userName);
			} catch (MailException exception) {
				LOGGER.error(
						"Exception occured sending email message to notify of executive person verification: expected ["
								+ executiveName + "] but was [" + questionValue + "]",
						exception);
			}
		}

	}

	private RegionOrgMapping getRegionCode(final String orgCode) throws SrtException {

		RegionOrgMapping regionDetails = regionOrgService.getRegionCodeByOrganization(orgCode);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Get Region Code for org:" + orgCode + "," + regionDetails.getRegionCode());
		}
		return regionDetails;
	}

	/**
	 * Updating form total score from SRTStatus. Set as archived for SRT for the
	 * previous years.
	 * 
	 * @param form
	 * @param srtStatus
	 * @throws SrtException
	 */
	private void updateSRTStatus2Form(final SRTForm form, final SRTStatus srtStatus) throws SrtException {

		String totalScore = null;

		if (null != form && null != srtStatus) {

			if (LOGGER.isDebugEnabled()) {

				LOGGER.debug("updateFormStatus STATUS=" + srtStatus.getStatus());
			}

			if (SRTUtil.SRTStatus.SUBMITTED.toString().equalsIgnoreCase(srtStatus.getStatus())) {

				form.setSubmitted(true);
			} else {

				form.setSubmitted(false);
			}

			if (null != srtStatus.getId()) {
				form.setStatusId(srtStatus.getId());
			}

			totalScore = srtStatus.getOverallScore();

			if (null != totalScore) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("updateFormStatus Overall Score=" + srtStatus.getOverallScore());
				}
				form.setTotalScore(srtStatus.getOverallScore());
			}

			// set as archived for SRT for the previous years.
			if (null != srtStatus.getYear() && srtStatus.getYear().equals(SRTUtil.YEAR_FORMAT.format(new Date()))) {

				form.setArchived(false);
			} else {
				form.setArchived(true);
			}
		}
	}

	private SRTForm populateSRTFormWithQuestionsAndAnswers(
			List<QuestionnaireAndRatingScoreAndResultsModel> questionsAndRatingScoreAndResults, String orgCode,
			boolean isWelsh, boolean isFraud) throws SrtException {

		final Organisation srtOrg = organisationService.findOrganisationByCode(orgCode);

		final Map<Integer, List<QuestionnaireAndRatingScoreAndResultsModel>> questionnaireBySection = groupBySection(
				questionsAndRatingScoreAndResults);

		final List<QuestionnaireAndRatingScoreAndResultsModel> generalSectionList = getGeneralSectionData(
				questionnaireBySection);

		final List<QuestionnaireAndRatingScoreAndResultsModel> strategicGovernanceSectionList = getStrategicGovSectionData(
				questionnaireBySection);

		final List<QuestionnaireAndRatingScoreAndResultsModel> informAndInvolveSectionList = getInformAndInvolveSectionData(
				questionnaireBySection);

		final List<QuestionnaireAndRatingScoreAndResultsModel> preventAndDeterSectionList = getPreventAndDeterSectionData(
				questionnaireBySection);

		final List<QuestionnaireAndRatingScoreAndResultsModel> holdToAccountQuestions = getHoldToAccountSectionData(
				questionnaireBySection);

		final List<QuestionnaireAndRatingScoreAndResultsModel> executiveAuthorisationQuestions = getExecutiveAuthSectionData(
				questionnaireBySection);

		final List<TextQuestion> general = extractGeneralSection(generalSectionList, srtOrg, isWelsh, isFraud);

		final List<ChoiceQuestion> sgovernance = extractChoiceSection(strategicGovernanceSectionList,
				SRT_SECTION.STRATEGIC_GOVERNANCE.getName());

		final List<ChoiceQuestion> informandinvolve = extractChoiceSection(informAndInvolveSectionList,
				SRT_SECTION.INFORM_AND_INVOLVE.getName());

		final List<ChoiceQuestion> preventanddeter = extractChoiceSection(preventAndDeterSectionList,
				SRT_SECTION.PREVENT_AND_DETER.getName());

		final List<ChoiceQuestion> holdtoaccount = extractChoiceSection(holdToAccountQuestions,
				SRT_SECTION.HOLD_TO_ACCOUNT.getName());

		final List<ChoiceQuestion> excvauthorisation = extractChoiceSection(executiveAuthorisationQuestions,
				SRT_SECTION.EXECUTIVE_AUTHORISATION.getName());

		SRTForm form = new SRTForm();

		form.setGeneralQuestions(general);
		form.setStrgSecQuestions(sgovernance);
		form.setINISecQuestions(informandinvolve);
		form.setPNDSecQuestions(preventanddeter);
		form.setHTASecQuestions(holdtoaccount);
		form.setExcvSecQuestions(excvauthorisation);

		return form;

	}

	/**
	 * @param questionnaireBySection
	 * @return
	 */
	private List<QuestionnaireAndRatingScoreAndResultsModel> getExecutiveAuthSectionData(
			final Map<Integer, List<QuestionnaireAndRatingScoreAndResultsModel>> questionnaireBySection) {
		final List<QuestionnaireAndRatingScoreAndResultsModel> executiveAuthorisationQuestions = questionnaireBySection
				.entrySet().stream().filter(k -> k.getKey() == SectionNameMap.EXECUTIVE_AUTHORISATION.getSectionValue())
				.map(v -> v.getValue()).collect(Collectors.toList()).stream().iterator().next();
		return executiveAuthorisationQuestions;
	}

	/**
	 * @param questionnaireBySection
	 * @return
	 */
	private List<QuestionnaireAndRatingScoreAndResultsModel> getHoldToAccountSectionData(
			final Map<Integer, List<QuestionnaireAndRatingScoreAndResultsModel>> questionnaireBySection) {
		final List<QuestionnaireAndRatingScoreAndResultsModel> holdToAccountQuestions = questionnaireBySection
				.entrySet().stream().filter(k -> k.getKey() == SectionNameMap.HOLD_TO_ACCOUNT.getSectionValue())
				.map(v -> v.getValue()).collect(Collectors.toList()).stream().iterator().next();
		return holdToAccountQuestions;
	}

	/**
	 * @param questionnaireBySection
	 * @return
	 */
	private List<QuestionnaireAndRatingScoreAndResultsModel> getPreventAndDeterSectionData(
			final Map<Integer, List<QuestionnaireAndRatingScoreAndResultsModel>> questionnaireBySection) {
		final List<QuestionnaireAndRatingScoreAndResultsModel> preventAndDeterQuestions = questionnaireBySection
				.entrySet().stream().filter(k -> k.getKey() == SectionNameMap.PREVENT_AND_DETER.getSectionValue())
				.map(v -> v.getValue()).collect(Collectors.toList()).stream().iterator().next();
		return preventAndDeterQuestions;
	}

	/**
	 * @param questionnaireBySection
	 * @return
	 */
	private List<QuestionnaireAndRatingScoreAndResultsModel> getInformAndInvolveSectionData(
			final Map<Integer, List<QuestionnaireAndRatingScoreAndResultsModel>> questionnaireBySection) {
		final List<QuestionnaireAndRatingScoreAndResultsModel> informAndInvolveQuestions = questionnaireBySection
				.entrySet().stream().filter(k -> k.getKey() == SectionNameMap.INFORM_AND_INVOLVE.getSectionValue())
				.map(v -> v.getValue()).collect(Collectors.toList()).stream().iterator().next();
		return informAndInvolveQuestions;
	}

	/**
	 * @param questionnaireBySection
	 * @return
	 */
	private List<QuestionnaireAndRatingScoreAndResultsModel> getStrategicGovSectionData(
			final Map<Integer, List<QuestionnaireAndRatingScoreAndResultsModel>> questionnaireBySection) {
		final List<QuestionnaireAndRatingScoreAndResultsModel> strategicGovernanceQuestions = questionnaireBySection
				.entrySet().stream().filter(k -> k.getKey() == SectionNameMap.STRATEGIC_GOVERNANCE.getSectionValue())
				.map(v -> v.getValue()).collect(Collectors.toList()).stream().iterator().next();
		return strategicGovernanceQuestions;
	}

	/**
	 * @param questionnaireBySection
	 * @return
	 */
	private List<QuestionnaireAndRatingScoreAndResultsModel> getGeneralSectionData(
			final Map<Integer, List<QuestionnaireAndRatingScoreAndResultsModel>> questionnaireBySection) {
		final List<QuestionnaireAndRatingScoreAndResultsModel> generalQuestions = questionnaireBySection.entrySet()
				.stream().filter(k -> k.getKey() == SectionNameMap.GENERAL.getSectionValue()).map(v -> v.getValue())
				.collect(Collectors.toList()).stream().iterator().next();
		return generalQuestions;
	}

	/**
	 * @param questionsAndRatingScoreAndResults
	 * @return
	 */
	private Map<Integer, List<QuestionnaireAndRatingScoreAndResultsModel>> groupBySection(
			List<QuestionnaireAndRatingScoreAndResultsModel> questionsAndRatingScoreAndResults) {
		final Map<Integer, List<QuestionnaireAndRatingScoreAndResultsModel>> questionnaireBySection = questionsAndRatingScoreAndResults
				.parallelStream()
				.collect(Collectors.groupingBy(QuestionnaireAndRatingScoreAndResultsModel::getSectionId));
		return questionnaireBySection;
	}

	private List<TextQuestion> extractGeneralSection(
			final List<QuestionnaireAndRatingScoreAndResultsModel> questionsAndRatingScoreAndResults,
			final Organisation srtOrg, final boolean isWelsh, final boolean isFraud) throws SrtException {

		final List<TextQuestion> generalQuestions = new ArrayList<>();

		questionsAndRatingScoreAndResults.forEach(item -> {

			final TextQuestion textQuestion = new TextQuestion();

			final String elementName = item.getElementName();

			textQuestion.setQuestionText(item.getQuestionText());
			textQuestion.setValidationType(item.getValidationType());
			textQuestion.setQuestionId(item.getQuestionId());
			textQuestion.setQuestionOrderNo(item.getQuestionOrderNo());
			textQuestion.setHelptext(item.getHelpText());
			textQuestion.setElementName(elementName);

			if (item.getResultId() != null && item.getResultId() > 0L) {
				textQuestion.setQuestionValue(item.getComments());
				textQuestion.setResultId(item.getResultId());
			}

			if (SRTUtil.ORGANISATION_NAME.equalsIgnoreCase(elementName)) {
				textQuestion.setQuestionValue(srtOrg.getName());
				textQuestion.setDisabled(true);
			} else if (SRTUtil.ORGANISATION_CODE.equalsIgnoreCase(elementName)) {
				textQuestion.setQuestionValue(srtOrg.getOrgCode());
				textQuestion.setDisabled(true);
			}

			// use CPOD SMD and DOF values if no other value entered - i.e. first time
			// only.
			if (!isWelsh && SRTUtil.RESPONSIBLE_EXECUTIVE_QUESTION.equalsIgnoreCase(elementName)
					&& StringUtils.isEmpty(textQuestion.getQuestionValue())) {
				if (isFraud) {
					textQuestion
							.setQuestionValue(srtOrg.getDofPerson() == null ? "" : srtOrg.getDofPerson().getFullname());
				}
			}
			if (isWelsh && SRTUtil.COMPLETION_DATE_OF_REVIEW.equalsIgnoreCase(elementName)) {

				textQuestion.setDisabled(true);

				if (item.getResultId() == null && StringUtils.isEmpty(item.getComments())) {
					String currentDate = SRTUtil.DATE_FORMAT.format(new Date());
					textQuestion.setQuestionValue(currentDate);
				}
			} else if (!isWelsh && SRTUtil.COMPLETION_DATE_OF_REVIEW.equalsIgnoreCase(elementName)) {
				textQuestion.setDisabled(true);

				if (item.getResultId() == null && StringUtils.isEmpty(item.getComments())) {
					String currentDate = SRTUtil.DATE_FORMAT.format(new Date());
					textQuestion.setQuestionValue(currentDate);
				}
			}

			try {
				generalQuestionSetup(textQuestion, item);
				generalQuestions.add(textQuestion);

			} catch (Exception e) {
				LOGGER.error("Exception while extracting general section data: " + ExceptionUtils.getFullStackTrace(e));
			}
		});

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("extractGenSection - no of questions added to the general section " + generalQuestions.size());
		}

		return generalQuestions;
	}

	/**
	 * General question setup for post 2016 SRT.
	 * 
	 * @param textQuestion
	 *            the current question
	 * @param questionnaireAndRatingScoreAndResultsModel
	 *            the current SRT
	 * @throws SrtException
	 *             on error
	 */
	private void generalQuestionSetup(final TextQuestion textQuestion,
			final QuestionnaireAndRatingScoreAndResultsModel questionnaireAndRatingScoreAndResultsModel)
			throws SrtException {

		final String questionnaireType = questionnaireAndRatingScoreAndResultsModel.getSrtType();
		final String questionnaireYear = questionnaireAndRatingScoreAndResultsModel.getYear();
		final String elementName = textQuestion.getElementName();
		final Optional<String> optionalElementName = Optional.ofNullable(elementName);

		if (optionalElementName.isPresent()) {

			switch (elementName) {

			case SRTUtil.ORGANISATION_PROVIDER_TYPE:
				textQuestion.setOptions(getOrganisationTypeOptions(questionnaireYear, questionnaireType));
				break;

			case SRTUtil.ANNUAL_BUDGET_OF_THE_ORGANISATION:
				textQuestion.setOptions(getAnnualBudgetOptions(questionnaireYear, questionnaireType));
				break;

			case SRTUtil.STAFF_HEADCOUNT:
				textQuestion.setOptions(getStaffHeadCountOptions(questionnaireYear, questionnaireType));
				break;
			}

			if (questionnaireAndRatingScoreAndResultsModel.isWelshRegion()) {
				if (elementName.equalsIgnoreCase(SRTUtil.REGION)) {
					textQuestion.setQuestionValue(SRTUtil.WALES);
					textQuestion.setDisabled(true);
				} else if (elementName.equalsIgnoreCase(SRTUtil.TOTAL_DAYS)
						|| elementName.equalsIgnoreCase(SRTUtil.TOTAL_COST)
								&& SRT_TYPES.lcfs.toString().equalsIgnoreCase(questionnaireType)) {
					textQuestion.setDisabled(true);
				}
			} else {

				switch (elementName) {

				case SRTUtil.REGION:
					textQuestion.setOptions(getRegionOptions(questionnaireType, questionnaireYear, SRTUtil.NHSP));
					break;

				case SRTUtil.NHS_ENGLAND_REGION:
					textQuestion.setOptions(getRegionOptions(questionnaireType, questionnaireYear, SRTUtil.NHSE));
					break;

				case SRTUtil.COORDINATING_COMMISSIONER: {
					if (!questionnaireType.equals(SRT_TYPES.lcfscom.name())) {
						textQuestion.setOptions(getCCGOptions());
					}
				}
					break;

				case SRTUtil.TOTAL_DAYS: {
					if (SRT_TYPES.lcfs.toString().equalsIgnoreCase(questionnaireType)
							|| SRT_TYPES.lcfscom.toString().equalsIgnoreCase(questionnaireType)) {
						textQuestion.setDisabled(true);
					}
				}
					break;

				case SRTUtil.TOTAL_COST: {
					if (SRT_TYPES.lcfs.toString().equalsIgnoreCase(questionnaireType)
							|| SRT_TYPES.lcfscom.toString().equalsIgnoreCase(questionnaireType)) {
						textQuestion.setDisabled(true);
					}

				}
					break;

				}

			}
		}

	}

	private List<ChoiceQuestion> extractChoiceSection(
			List<QuestionnaireAndRatingScoreAndResultsModel> questionsRatingScoreAndResultsModel,
			final String sectionName) {

		final List<ChoiceQuestion> choiceQuestions = new ArrayList<ChoiceQuestion>();

		questionsRatingScoreAndResultsModel.stream().forEach(questionsRatingScoreAndResult -> {

			final Set<RatingScore> options = new TreeSet<RatingScore>(new RatingScore().new RatingScoreComparator());
			final String rating = questionsRatingScoreAndResult.getPossible_rating();
			final String ratingValue = questionsRatingScoreAndResult.getPossible_rating_value();

			final Optional<String> ratingOptional = Optional.ofNullable(ratingValue);

			if (ratingOptional.isPresent()) {

				getRatingScoreOptions(options, rating, ratingValue);
			}

			final ChoiceQuestion choiceQuestion = new ChoiceQuestion();

			choiceQuestion.setQuestionText(questionsRatingScoreAndResult.getQuestionText());
			choiceQuestion.setQuestionId(questionsRatingScoreAndResult.getQuestionId());
			choiceQuestion.setOptions(options);
			choiceQuestion.setHelpDocumentURL(questionsRatingScoreAndResult.getHelpPageUrl());
			choiceQuestion.setPriority(questionsRatingScoreAndResult.getPriority());

			// include the question order to aid retrieval later
			choiceQuestion.setQuestionOrderNo(questionsRatingScoreAndResult.getQuestionOrderNo());

			Long resultId = questionsRatingScoreAndResult.getResultId();

			if (null != resultId) {
				choiceQuestion.setComment(questionsRatingScoreAndResult.getComments());
				choiceQuestion.setResultId(questionsRatingScoreAndResult.getResultId());

				final Integer score = questionsRatingScoreAndResult.getScore();

				if (score != null) {
					choiceQuestion.setQuestionValue(questionsRatingScoreAndResult.getScore());

					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug("addAnswers2ChoiceSection - comment " + questionsRatingScoreAndResult.getComments()
								+ "	resultId " + questionsRatingScoreAndResult.getResultId() + " score  "
								+ questionsRatingScoreAndResult.getScore());
					}

				}
			}

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(
						"extractChoiceSection - adding question " + choiceQuestion + " to the section " + sectionName);
			}
			choiceQuestions.add(choiceQuestion);

		});

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("extractChoiceSection - number of questions added to the section " + sectionName + " : "
					+ choiceQuestions.size());
		}
		return choiceQuestions;
	}

	/**
	 * @param options
	 * @param rating
	 * @param ratingValue
	 */
	private void getRatingScoreOptions(final Set<RatingScore> options, final String rating, final String ratingValue) {

		final String[] ratingArray = rating.trim().split(",");

		final String[] ratingValueArray = ratingValue.trim().split(",");

		final String[] finalRatingValue = new String[ratingArray.length];

		IntStream.range(0, ratingValueArray.length)
				.forEach(i -> finalRatingValue[i] = ratingArray[i] + "=" + ratingValueArray[i]);

		final List<String> ratings = Arrays.asList(finalRatingValue);

		ratings.stream().map(s -> s.split("=")).forEach(strArray -> {
			final RatingScore ratingScore = new RatingScore();
			ratingScore.setRating(strArray[0]);
			ratingScore.setRatingValue(Integer.valueOf(strArray[1]));
			options.add(ratingScore);
		});
	}

	private List<String> getAnnualBudgetOptions(String year, String srtType) throws SrtException {

		final List<AnnualBudget> budgetOptions = annualBudgetService.getListOfBudgetOptions(year, srtType);

		final List<String> annualBudgets = getAnnualBudgetValueList(budgetOptions);

		return annualBudgets;
	}

	/**
	 * @param annualBudgets
	 * @param budgetOptions
	 */
	private List<String> getAnnualBudgetValueList(final List<AnnualBudget> budgetOptions) {

		final List<String> annualBudgets = new ArrayList<String>();

		final Optional<List<AnnualBudget>> optional = Optional.ofNullable(budgetOptions);

		if (optional.isPresent()) {
			budgetOptions.stream().forEach(budgetOption -> annualBudgets.add(budgetOption.getBudgetVal()));
		}

		return annualBudgets;
	}

	private List<String> getCCGOptions() throws SrtException {

		// TODO can this be cached - query to CPOD more expensive than
		// retrieving from cache

		final List<String> ccgList = new ArrayList<String>();

		final List<OrganisationByTypeCCG> ccgs = regionOrgService.getProviderTypeListForCCG();
		final Optional<List<OrganisationByTypeCCG>> optional = Optional.ofNullable(ccgs);

		if (optional.isPresent()) {
			ccgs.stream().forEach(ccg -> ccgList.add(ccg.getOrgName()));
		}

		return ccgList;
	}

	/**
	 * Method to retrieve the staff head count options.
	 * 
	 * @param year
	 *            to retrieve options for
	 * @param srtType
	 *            to retrieve options for
	 * @return List<String> head count options
	 * @throws SrtException
	 *             on error
	 */
	private List<String> getStaffHeadCountOptions(String year, String srtType) throws SrtException {

		final List<StaffHeadcount> headcountOptions = staffHeadcountService.getListOfStaffHeadcountOptions(year,
				srtType);

		final List<String> headCounts = getStaffHeadCountValueList(headcountOptions);

		return headCounts;
	}

	/**
	 * @param headCounts
	 * @param headcountOptions
	 */
	private List<String> getStaffHeadCountValueList(final List<StaffHeadcount> headcountOptions) {

		final List<String> headCounts = new ArrayList<String>();
		final Optional<List<String>> optional = Optional.ofNullable(headCounts);

		if (optional.isPresent()) {
			headcountOptions.stream()
					.forEach(headcountOption -> headCounts.add(headcountOption.getStaffHeadcountVal()));
		}
		return headCounts;
	}

	/**
	 * Method to retrieve the
	 * 
	 * @param srtType
	 * @param year
	 * @return
	 * @throws SrtException
	 */
	private List<String> getRegionOptions(String srtType, String year, String regionType) throws SrtException {

		final List<Regions> list = regionOrgService.getRegionList(srtType, year, regionType);

		final List<String> regionNameList = getRegionNameList(list);

		return regionNameList;

	}

	/**
	 * Method to retrieve the organisation type options for provider/commissioner
	 * organisation types
	 * 
	 * @param questionnaireYear
	 *            the year of the srt
	 * @param questionnaireType
	 *            the type of the srt
	 * @return List<String> the options for the srt
	 * @throws SrtException
	 */
	private List<String> getOrganisationTypeOptions(String questionnaireYear, String questionnaireType)
			throws SrtException {

		final List<OrganisationType> list = regionOrgService.getOrganisationTypes(questionnaireType, questionnaireYear);

		final List<String> listOfOrgNames = getProviderTypeNameList(list);

		return listOfOrgNames;

	}

	/**
	 * Retrieve list of organisation type names from OrganisationType object list
	 * 
	 * @param list
	 * @return
	 * @throws SrtException
	 */
	private List<String> getProviderTypeNameList(final List<OrganisationType> list) throws SrtException {

		final List<String> organisationTypeList = new ArrayList<String>();
		final Optional<List<String>> optional = Optional.ofNullable(organisationTypeList);

		if (optional.isPresent()) {
			list.stream().forEach(org -> organisationTypeList.add(org.getName()));
		}
		return organisationTypeList;
	}

	/**
	 * Retrieve list of region names from Regions object list
	 * 
	 * @param regionsList
	 * @return
	 * @throws SrtException
	 */
	private List<String> getRegionNameList(final List<Regions> regionsList) throws SrtException {

		final List<String> regionNameList = new ArrayList<String>();
		final Optional<List<String>> optional = Optional.ofNullable(regionNameList);

		if (optional.isPresent()) {
			regionsList.stream().forEach(region -> regionNameList.add(region.getRegionName()));

		}

		return regionNameList;
	}

}
