package uk.nhs.nhsprotect.srt.util;

import java.text.SimpleDateFormat;

import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestWrapper;

import uk.nhs.nhsprotect.srt.hibernate.enums.PersistentEnum;

public class SRTUtil {

	public enum SRTStatus {
		TODO, DRAFT, SUBMITTED, INACTIVE
	};

	public enum SRT_ROLES {
		ROLE_ADMIN, ROLE_LCFS, ROLE_CORP_LCFS, ROLE_CORP_LCFS_COM
	};

	public static final SimpleDateFormat YEAR_FORMAT = new SimpleDateFormat("yyyy");

	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

	public static final SimpleDateFormat DATE_TIME_FORMAT = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

	public static final String YEAR_PATTERN = "((19|20)\\d\\d)";

	public enum LOGIN_TYPES {
		fraud, fraudcom
	};

	public enum SRT_TYPES {
		lcfs, lcfscom;

		/**
		 * Method to math and SRT_TYPE to the string entered.
		 * 
		 * @param srtTypeString
		 * @return SRT_TYPE matching string or null
		 */
		public static SRT_TYPES findByString(String srtTypeString) {
			for (SRT_TYPES types : SRT_TYPES.values()) {
				if (types.name().equalsIgnoreCase(srtTypeString))
					return types;
			}
			return null;
		}
	};

	/**
	 * Represents the section of an SRT the name value matches that of the database
	 * column QUESTIONNAIRE_TBL.QUESTION_CATEGORY_TYPE.
	 * 
	 * @author ntones
	 */
	public enum SRT_SECTION {
		GENERAL("general", "tab0Content"), STRATEGIC_GOVERNANCE("sgovernance", "tab1Content"), INFORM_AND_INVOLVE(
				"informandinvolve",
				"tab2Content"), PREVENT_AND_DETER("preventanddeter", "tab3Content"), HOLD_TO_ACCOUNT("holdtoaccount",
						"tab4Content"), EXECUTIVE_AUTHORISATION("execauthorisation", "tab5Content");

		private final String name;
		private final String tabRef;

		private SRT_SECTION(String name, String tabRef) {
			this.name = name;
			this.tabRef = tabRef;
		}

		/**
		 * Returns the name value as per QUESTIONNAIRE_TBL.QUESTION_CATEGORY_TYPE.
		 * 
		 * @return the name
		 */
		public String getName() {
			return name;
		}

		/**
		 * @return the tabRef
		 */
		public String getTabRef() {
			return tabRef;
		}

	};

	public enum SCORE {

		RED(1), AMBER(2), GREEN(3), NEUTRAL(0), NOT_APPLICABLE(-1);

		private final int value;

		SCORE(int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}
	}

	public static final String SRT_ROLE_MONITOR = "ROLE_MONITOR";

	public enum SRTExportType {
		PDF, XLS
	}

	// positions for general section fields
	public static final int ORGANISATION_NAME_QUESTION_POSITION = 1;

	public static final String ORGANISATION_NAME = "nameOfTheOrganisation";

	public static final int ANNUAL_BUDGET_QUESTION_POSITION = 2;

	public static final String ANNUAL_BUDGET_OF_THE_ORGANISATION = "AnnualBudgetOfTheOrganisation";

	public static final int HEADCOUNT_QUESTION_POSITION = 3;

	public static final String STAFF_HEADCOUNT = "StaffHeadCount";

	public static final int ORGANISATION_CODE_QUESTION_POSITION = 4;

	public static final String ORGANISATION_CODE = "orgCode";

	public static final int PROVIDER_TYPE_QUESTION_POSITION = 5;

	public static final String ORGANISATION_PROVIDER_TYPE = "OrganisationProviderType";

	public static final int COORDINATING_COMMISSIONER_QUESTION_POSITION = 6;

	public static final String COORDINATING_COMMISSIONER = "CoordinatingCommissioner";

	public static final int REGION_QUESTION_POSITION = 8;

	public static final String REGION = "Region";

	public static final String WALES = "WALES";

	public static final String WELSH = "WELSH";

	public static final String NHSP = "NHSP";

	public static final String NHSE = "NHSE";

	public static final int COMPLETION_DATE_QUESTION_POSITION = 9;

	public static final String COMPLETION_DATE_OF_REVIEW = "DateOfCompletionOfThisReview";

	public static final int FRAUD_TOTAL_DAYS_QUESTION_POSITION = 14;

	public static final String TOTAL_DAYS = "totalDays";

	public static final int SECURITY_TOTAL_DAYS_QUESTION_POSITION = 15;

	public static final String COMMISSIONER_SUFFIX = "com";

	public static final int FRAUD_COM_TOTAL_DAYS_QUESTION_POSITION = 17;

	public static final Long INFORM_AND_INVOLVE_2015_PILOT_STANDARD_2_7_ID = 211L;

	/**
	 * The ID of question 2.6 for Security Providers 2016.
	 */
	public static final Long INFORM_AND_INVOLVE_2016_PILOT_STANDARD_2_6_ID = 399L;

	public static final int NHSE_REGION_QUESTION_POSITION_2016 = 9;

	public static final String NHS_ENGLAND_REGION = "NHSEnglandRegion";

	public static final int FRAUD_TOTAL_DAYS_QUESTION_POSITION_2016 = 15;

	public static final int COMPLETION_DATE_QUESTION_POSITION_2016 = 10;

	public static final int FRAUD_TOTAL_COST_QUESTION_POSITION_2016 = 18;

	public static final int FRAUD_TOTAL_DAYS_QUESTION_POSITION_2016_WELSH = 13;

	public static final int FRAUD_TOTAL_COST_QUESTION_POSITION_2016_WELSH = 16;

	public static final String TOTAL_COST = "totalCost";

	public static final int REGION_QUESTION_POSITION_2016_WELSH = 7;

	public static final int COMPLETION_DATE_QUESTION_POSITION_2016_WELSH = 8;

	public static final String WELSH_REGION_CODE = "WARO";

	public static final String NHSE_REGION = "NHSE";

	public static final String SUBMIT_TYPE_DRAFT = "DRAFT";

	public static final String SUBMIT_TYPE_SUBMIT = "SUBMIT";

	public static final int FRAUD_COM_TOTAL_COST_QUESTION_POSITION_2016 = 18;

	public static final int FRAUD_COM_TOTAL_DAYS_QUESTION_POSITION_2016 = 15;

	public static final int SECURITY_TOTAL_DAYS_QUESTION_POSITION_2016 = 16;

	public static final int SECURITY_COM_TOTAL_DAYS_QUESTION_POSITION_2016 = 16;

	public static final int RESPONSIBLE_EXECUTIVE_QUESTION_POSITION = 7;

	public static final String RESPONSIBLE_EXECUTIVE_QUESTION = "executiveBoardMember";

	/**
	 * Helper method to get colour name from rating value.
	 * 
	 * @param score
	 * @return
	 */
	public static String getColorFromRatingValue(int score) {

		switch (score) {
		case -1:
			return SCORE.NOT_APPLICABLE.toString();
		case 1:
			return SCORE.RED.toString();
		case 2:
			return SCORE.AMBER.toString();
		case 3:
			return SCORE.GREEN.toString();
		case 0:
			return SCORE.NEUTRAL.toString();
		default:
			return "";
		}
	}

	/**
	 * Enumerated type to represent CPOD ORG_TYPE_TBL entries. Used as hibernate
	 * UserType.
	 * 
	 * @author ntones
	 */
	public enum ORG_TYPE implements PersistentEnum {
		HA(7), NHS(8), NonNHS(9), PCT(10), SPHA(11), TRUST(12), SocE(17), NHSE_AREA_TEAM(18), NHSE_CCG(19), NHSE_CSU(
				20), WLHB(21), NAX_NonNHS(22), NHSP_Added(
						23), Independent_Sector_Healthcare_Providers(24), NHS_Support_Agencies_and_Shared_Services(25);

		/**
		 * The ID value.
		 */
		private final int id;

		private ORG_TYPE(int id) {
			this.id = id;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see uk.nhs.nhsprotect.srt.hibernate.enums.PersistentEnum#getId()
		 */
		@Override
		public int getId() {
			return id;
		}

	}

	public static String determinePersonType(SecurityContextHolderAwareRequestWrapper request) {

		if (request.isUserInRole(SRTUtil.SRT_ROLES.ROLE_CORP_LCFS.toString())) {
			return "lcfs";
		} else if (request.isUserInRole(SRTUtil.SRT_ROLES.ROLE_CORP_LCFS_COM.toString())) {
			return "lcfscom";
		}
		return null;
	}
}
