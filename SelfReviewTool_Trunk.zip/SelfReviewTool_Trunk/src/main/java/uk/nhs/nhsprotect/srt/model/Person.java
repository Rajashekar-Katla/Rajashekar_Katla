/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import org.apache.commons.lang.StringUtils;

/**
 * @author bvaidya
 */
@Entity
@Table(name = "LATEST_STAFF_VIEW")
public class Person implements Serializable {

    /**
     * Default UID.
     */
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "STAFF_ID")
    private String staffId;
    @Column(name = "ID")
    private Long personId;
    @Column(name = "PERSON_TYPE")
    private String personType;
    @Column(name = "TITLE")
    private String title;
    @Column(name = "SURNAME")
    private String surname;
    @Column(name = "FORENAME_1")
    private String forename1;
    @Column(name = "FORENAME_2")
    private String forename2;
    @Column(name = "KNOWN_AS")
    private String knownAs;
    @Column(name = "EMP_ORGCODE")
    private String empOrgCode;
    @Column(name = "EMP_NAME")
    private String empName;
    @Column(name = "JOB_TITLE")
    private String jobTitle;
    @Column(name = "EMAIL_NHS")
    private String emailNHS;
    @Column(name = "EMAIL_OTHER")
    private String emailOther;
    @Column(name = "TELEPHONE1")
    private String telephone1;
    @Column(name = "EXT")
    private String ext;
    @Column(name = "TELEPHONE2")
    private String telephone2;
    @Column(name = "MOBILE")
    private String mobile;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "STATUS_REASON")
    private String statusReason;
    @Column(name = "START_DATE")
    private Date startDate;
    @Column(name = "END_DATE")
    private Date endDate;

    // @OneToOne(fetch = FetchType.LAZY, mappedBy = "person", cascade =
    // CascadeType.ALL)
    // private Responsibility responsibility;

    /**
     * @return the personId
     */
    public Long getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    /**
     * @return the personType
     */
    public String getPersonType() {
        return personType;
    }

    /**
     * @param personType the personType to set
     */
    public void setPersonType(String personType) {
        this.personType = personType;
    }

    /**
     * @return the responsibility
     */
    /*
     * public Responsibility getResponsibility() { return responsibility; }
     *//**
       * @param responsibility the responsibility to set
       */
    /*
     * public void setResponsibility(Responsibility responsibility) {
     * this.responsibility = responsibility; }
     */

    /**
     * @return the staffId
     */
    public String getStaffId() {
        return staffId;
    }

    /**
     * @param staffId the staffId to set
     */
    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * @param surname the surname to set
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * @return the forename1
     */
    public String getForename1() {
        return forename1;
    }

    /**
     * @param forename1 the forename1 to set
     */
    public void setForename1(String forename1) {
        this.forename1 = forename1;
    }

    /**
     * @return the forename2
     */
    public String getForename2() {
        return forename2;
    }

    /**
     * @param forename2 the forename2 to set
     */
    public void setForename2(String forename2) {
        this.forename2 = forename2;
    }

    /**
     * @return the knownAs
     */
    public String getKnownAs() {
        return knownAs;
    }

    /**
     * @param knownAs the knownAs to set
     */
    public void setKnownAs(String knownAs) {
        this.knownAs = knownAs;
    }

    /**
     * @return the empOrgCode
     */
    public String getEmpOrgCode() {
        return empOrgCode;
    }

    /**
     * @param empOrgCode the empOrgCode to set
     */
    public void setEmpOrgCode(String empOrgCode) {
        this.empOrgCode = empOrgCode;
    }

    /**
     * @return the empName
     */
    public String getEmpName() {
        return empName;
    }

    /**
     * @param empName the empName to set
     */
    public void setEmpName(String empName) {
        this.empName = empName;
    }

    /**
     * @return the jobTitle
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * @param jobTitle the jobTitle to set
     */
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    /**
     * @return the emailNHS
     */
    public String getEmailNHS() {
        return emailNHS;
    }

    /**
     * @param emailNHS the emailNHS to set
     */
    public void setEmailNHS(String emailNHS) {
        this.emailNHS = emailNHS;
    }

    /**
     * @return the emailOther
     */
    public String getEmailOther() {
        return emailOther;
    }

    /**
     * @param emailOther the emailOther to set
     */
    public void setEmailOther(String emailOther) {
        this.emailOther = emailOther;
    }

    /**
     * @return the telephone1
     */
    public String getTelephone1() {
        return telephone1;
    }

    /**
     * @param telephone1 the telephone1 to set
     */
    public void setTelephone1(String telephone1) {
        this.telephone1 = telephone1;
    }

    /**
     * @return the ext
     */
    public String getExt() {
        return ext;
    }

    /**
     * @param ext the ext to set
     */
    public void setExt(String ext) {
        this.ext = ext;
    }

    /**
     * @return the telephone2
     */
    public String getTelephone2() {
        return telephone2;
    }

    /**
     * @param telephone2 the telephone2 to set
     */
    public void setTelephone2(String telephone2) {
        this.telephone2 = telephone2;
    }

    /**
     * @return the mobile
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * @param mobile the mobile to set
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the statusReason
     */
    public String getStatusReason() {
        return statusReason;
    }

    /**
     * @param statusReason the statusReason to set
     */
    public void setStatusReason(String statusReason) {
        this.statusReason = statusReason;
    }

    /**
     * @return the startDate
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * @param startDate the startDate to set
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the endDate
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getFullname() {
        String fullName = "";
        if (StringUtils.isNotEmpty(title)) {
            fullName += title;
        }
        if (StringUtils.isNotEmpty(forename1)) {
            fullName = fullName + " " + forename1;
        }
        if (StringUtils.isNotEmpty(surname)) {
            fullName = fullName + " " + surname;
        }
        return fullName;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((personId == null) ? 0 : personId.hashCode());
        result = prime * result + ((staffId == null) ? 0 : staffId.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Person other = (Person) obj;
        if (personId == null) {
            if (other.personId != null) {
                return false;
            }
        } else if (!personId.equals(other.personId)) {
            return false;
        }
        if (staffId == null) {
            if (other.staffId != null) {
                return false;
            }
        } else if (!staffId.equals(other.staffId)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Person [staffId=" + staffId + ", personId=" + personId + ", personType=" + personType + ", title="
                + title + ", surname=" + surname + ", forename1=" + forename1 + ", forename2=" + forename2
                + ", knownAs=" + knownAs + ", empOrgCode=" + empOrgCode + ", empName=" + empName + ", jobTitle="
                + jobTitle + ", emailNHS=" + emailNHS + ", emailOther=" + emailOther + ", telephone1=" + telephone1
                + ", ext=" + ext + ", telephone2=" + telephone2 + ", mobile=" + mobile + ", status=" + status
                + ", statusReason=" + statusReason + ", startDate=" + startDate + ", endDate=" + endDate + "]";
    }

}
