/**
 * 
 */
package uk.nhs.nhsprotect.srt.security;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.service.ResponsibilityService;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRT_ROLES;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRT_TYPES;

/**
 * Custom evaluator to check that the logged in user can access the requested
 * ORG_CODE by checking.
 * 
 * @author ntones
 */
public class ResponsibilityEvaluator implements PermissionEvaluator {

	/**
	 * Class logger instance.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ResponsibilityEvaluator.class);

	/**
	 * Reference to responsibility service.
	 */
	private ResponsibilityService responsibilityService;

	/**
	 * Creates a new instance of ResponsibiltyEvaluator.
	 * 
	 * @param responsibilityService
	 *            instance to user
	 */
	public ResponsibilityEvaluator(final ResponsibilityService responsibilityService) {
		this.responsibilityService = responsibilityService;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.access.PermissionEvaluator#hasPermission
	 * (org.springframework.security.core.Authentication, java.lang.Object,
	 * java.lang.Object)
	 */
	@Override
	public boolean hasPermission(final Authentication authentication, final Object accessType, final Object orgCode) {
		boolean sharedAccessUser = false;
		boolean accessGranted = false;
		String userName = authentication.getName();
		String orgCodeString = (String) orgCode;
		String accessTypeString = (String) accessType;

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Checking " + userName + " has valid access to org [" + orgCode + "]");
		}
		for (GrantedAuthority authority : authentication.getAuthorities()) {
			String authorityName = authority.getAuthority();
			if (StringUtils.equals(authorityName, SRT_ROLES.ROLE_CORP_LCFS.name())
					|| StringUtils.equals(authorityName, SRT_ROLES.ROLE_CORP_LCFS_COM.name())) {
				// shared access request
				sharedAccessUser = true;
			}
		}

		if (sharedAccessUser) {
			// check the user name contains the org code requested
			accessGranted = holdsValidSharedAccess(authentication, orgCodeString, accessTypeString);

		} else {
			// call custom code for validating user responsibility
			try {
				accessGranted = holdsActiveResponsibility(userName, accessTypeString, orgCodeString);
			} catch (SrtException e) {
				LOGGER.error("Error occured queryig responsibility for [" + userName + "] with accesstype ["
						+ accessTypeString + "] on orgCode [" + orgCodeString + "]", e);
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
					"Checking " + userName + " has valid access to org [" + orgCode + "] result is " + accessGranted);
		}
		return accessGranted;
	}

	/**
	 * Method to ensure that the shared user has access to the requested SRT.
	 * 
	 * @param authentication
	 *            current logged in user
	 * @param orgCodeString
	 *            requested SRT organisation
	 * @param accessTypeString
	 *            requested SRT type
	 * @return true only if shared access user is allowed to access trust and SRT
	 *         type.
	 */
	private boolean holdsValidSharedAccess(final Authentication authentication, final String orgCodeString,
			final String accessTypeString) {

		boolean result = false;
		String[] accessTypes = null;
		if (accessTypeString.contains(",")) {
			accessTypes = accessTypeString.split(",");
			for (String accessType : accessTypes) {
				result = checkSharedaccess(authentication, orgCodeString, accessType);
				if (result) {
					// stop as soon as we have a valid entry
					break;
				}
			}
		} else {
			result = checkSharedaccess(authentication, orgCodeString, accessTypeString);
		}

		return result;
	}

	/**
	 * Method to check that a shared access user has access to the requested trust.
	 * 
	 * @param authentication
	 *            the current Authentication object
	 * @param orgCodeString
	 *            the requested organisation code
	 * @param accessType
	 *            the type of user access
	 * @return boolean indicating access allowed or declined
	 */
	private boolean checkSharedaccess(final Authentication authentication, final String orgCodeString,
			final String accessType) {
		for (GrantedAuthority authority : authentication.getAuthorities()) {
			if (authority.getAuthority().equalsIgnoreCase(SRT_ROLES.ROLE_CORP_LCFS.name())) {
				return accessType.equals(SRT_TYPES.lcfs.name())
						&& StringUtils.containsAny(authentication.getName(), orgCodeString);
			} else if (authority.getAuthority().equalsIgnoreCase(SRT_ROLES.ROLE_CORP_LCFS_COM.name())) {
				return accessType.equals(SRT_TYPES.lcfs.name())
						&& StringUtils.containsAny(authentication.getName(), orgCodeString);
			}
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.access.PermissionEvaluator#hasPermission
	 * (org.springframework.security.core.Authentication, java.io.Serializable,
	 * java.lang.String, java.lang.Object)
	 */
	@Override
	public boolean hasPermission(final Authentication authentication, final Serializable serializable,
			final String string, final Object object) {
		return false;
	}

	/**
	 * Method to determine if a user holds a responsibility to the requested
	 * organisation.
	 * 
	 * @param userReference
	 *            the logged in user
	 * @param accessType
	 *            the SRT type being requested
	 * @param orgCode
	 *            the organisation
	 * @return true only if the user holds an active responsibility for the
	 *         organisation.
	 * @throws SrtException
	 *             on error querying responsibilities
	 */
	private boolean holdsActiveResponsibility(final String userReference, final String accessType, final String orgCode)
			throws SrtException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Checking " + accessType + " active responsibility for [" + userReference + "] and org ["
					+ orgCode + "]");
		}
		boolean result = false;
		if (StringUtils.containsAny(accessType, userReference)) {

			result = responsibilityService.getResponsibilitiesByStaffId(userReference).stream()
					.anyMatch(p -> StringUtils.equalsIgnoreCase(orgCode, p.getOrgCode()));

		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("result of current responsibility check was " + result);
		}
		return result;

	}
}
