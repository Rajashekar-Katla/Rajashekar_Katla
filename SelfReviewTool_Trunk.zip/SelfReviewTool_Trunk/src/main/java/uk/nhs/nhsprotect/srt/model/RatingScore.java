/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;
import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author bvaidya
 */
@Entity
@Table(name = "RATING_SCORE_TBL")
public class RatingScore implements Serializable{

    /**
     * Default Serial Version.
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "RATING_ID")
    private int ratingId;

    @Column(name = "RATING")
    private String rating;

    @Column(name = "RATING_VALUE")
    private int ratingValue;

    @Column(name = "YEAR")
    private String year;

    /**
     * @return the ratingId
     */
    public int getRatingId() {
        return ratingId;
    }

    /**
     * @param ratingId the ratingId to set
     */
    public void setRatingId(int ratingId) {
        this.ratingId = ratingId;
    }

    /**
     * @return the rating
     */
    public String getRating() {
        return rating;
    }

    /**
     * @param rating the rating to set
     */
    public void setRating(String rating) {
        this.rating = rating;
    }

    /**
     * @return the ratingValue
     */
    public int getRatingValue() {
        return ratingValue;
    }

    /**
     * @param ratingValue the ratingValue to set
     */
    public void setRatingValue(int ratingValue) {
        this.ratingValue = ratingValue;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

	public class RatingScoreComparator implements Comparator<RatingScore>,Serializable {

		private static final long serialVersionUID = 1L;

		@Override
		public int compare(RatingScore obj1, RatingScore obj2) {
			if (obj1.getRatingValue() > obj2.getRatingValue()) {
				return 1;
			} else if (obj1.getRatingValue() < obj2.getRatingValue()) {
				return -1;
			} else {
				return 0;
			}

		}
	}
	
}
