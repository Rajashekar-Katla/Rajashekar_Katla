package uk.nhs.nhsprotect.srt.service;

import java.util.Map;

import uk.nhs.nhsprotect.srt.exception.SrtException;

@FunctionalInterface
public interface PilotStandardService {

	public void getPilotStandardData(final Map<String, Long> pilotStandardMap)
			throws SrtException;

}
