package uk.nhs.nhsprotect.srt.service;

import org.springframework.mail.MailException;

import uk.nhs.nhsprotect.srt.model.Organisation;

/**
 * Interface defining email functions.
 * @author ntones
 */
public interface SRTEmailService {

  /**
   * Generic method to send an email message.
   * @param staffId the username of the person submitting this SRT
   * @param srtType the type of SRT being submitted
   * @param orgCode the organisation submitting this SRT
   * @return String response - empty if no errors occurred during creation of
   *         message.
   * @throws MailException on error
   */
  String sendMessage(String orgCode, String srtType, String staffId) throws MailException;

  /**
   * Method to send an email message informing that the entered responsible
   * executive does not match the record held in CPOD.
   * @param srtType the SRT type being submitted
   * @param organisation the Organisation completing the SRT
   * @param executiveName the expected executive name from CPOD
   * @param questionValue the actual executive name entered in SRT
   * @param userName the User submitting the SRT
   * @throws MailException on email error
   */
  void notifyResponsiblePersonVerificationFail(String srtType, Organisation organisation, String executiveName,
      String questionValue, String userName) throws MailException;

}
