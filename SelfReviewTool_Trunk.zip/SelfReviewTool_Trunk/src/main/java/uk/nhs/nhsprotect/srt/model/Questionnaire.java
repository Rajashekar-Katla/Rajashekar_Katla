/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import uk.nhs.nhsprotect.srt.util.SRTUtil;

/**
 * @author bvaidya
 */
@Entity
@Table(name = "QUESTIONNAIRE_TBL")
public class Questionnaire implements Serializable {

    /**
     * Default Serial Version.
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "QUESTION_ID")
    private Long questionId;

    @Column(name = "QUESTION_TEXT")
    private String questionText;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SECTION_ID")
    private Section section;

    @Column(name = "HELP_TEXT")
    private String helpText;

    @Column(name = "QUESTION_ORDER_NO")
    private int questionOrderNo;

    @Column(name = "SRT_TYPE")
    private String srtType;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "REGION")
    private String region;

    @Column(name = "Status")
    private String status;

    @Column(name = "PRIORITY")
    private int priority;

    @Column(name = "HELP_PAGE_URL")
    private String helpPageUrl;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name = "QUESTIONNAIRE_RATING_TBL", joinColumns = {
            @JoinColumn(name = "QUESTION_ID", nullable = false, updatable = false)
    }, inverseJoinColumns = {
            @JoinColumn(name = "RATING_ID", nullable = false, updatable = false)
    })
    @OrderBy("ratingId ASC")
    private Set<RatingScore> ratings = new HashSet<RatingScore>(0);

    @Column(name = "YEAR")
    private String year;

    @Column(name = "VALIDATION_TYPE")
    private String validationType;

    @Column(name = "ELEMENT_NAME")
    private String elementName;
    
    /**
     * @return the questionId
     */
    public Long getQuestionId() {
        return questionId;
    }

    /**
     * @param questionId the questionId to set
     */
    public void setQuestionId(Long questionId) {
        this.questionId = questionId;
    }

    /**
     * @return the questionText
     */
    public String getQuestionText() {
        return questionText;
    }

    /**
     * @param questionText the questionText to set
     */
    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    /**
     * @return the helpText
     */
    public String getHelpText() {
        return helpText;
    }

    /**
     * @param helpText the helpText to set
     */
    public void setHelpText(String helpText) {
        this.helpText = helpText;
    }

    /**
     * @return the questionOrderNo
     */
    public int getQuestionOrderNo() {
        return questionOrderNo;
    }

    /**
     * @param questionOrderNo the questionOrderNo to set
     */
    public void setQuestionOrderNo(int questionOrderNo) {
        this.questionOrderNo = questionOrderNo;
    }

    /**
     * @return the section
     */
    public Section getSection() {
        return section;
    }

    /**
     * @param section the section to set
     */
    public void setSection(Section section) {
        this.section = section;
    }

    /**
     * @return the srtType
     */
    public String getSrtType() {
        return srtType;
    }

    /**
     * @param srtType the srtType to set
     */
    public void setSrtType(String srtType) {
        this.srtType = srtType;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the region
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the priority
     */
    public int getPriority() {
        return priority;
    }

    /**
     * @param priority the priority to set
     */
    public void setPriority(int priority) {
        this.priority = priority;
    }

    /**
     * @return the helpPageUrl
     */
    public String getHelpPageUrl() {
        return helpPageUrl;
    }

    /**
     * @param helpPageReference the helpPageUrl to set
     */
    public void setHelpPageUrl(String helpPageUrl) {
        this.helpPageUrl = helpPageUrl;
    }

    public Set<RatingScore> getRatings() {
        return ratings;
    }

    public void setRatings(Set<RatingScore> ratings) {
        this.ratings = ratings;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    /**
     * @return the validationType
     */
    public String getValidationType() {
        return validationType;
    }

    /**
     * @param validationType the validationType to set
     */
    public void setValidationType(String validationType) {
        this.validationType = validationType;
    }

    /**
     * Indicates if this question is related to a Welsh SRT completion.
     * @return
     */
    public boolean isWelshRegion() {
        return SRTUtil.WELSH_REGION_CODE.equals(this.region);
    }

	/**
	 * @return the elementName
	 */
	public String getElementName() {
		return elementName;
	}

	/**
	 * @param elementName the elementName to set
	 */
	public void setElementName(String elementName) {
		this.elementName = elementName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((questionId == null) ? 0 : questionId.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Questionnaire other = (Questionnaire) obj;
		if (questionId == null) {
			if (other.questionId != null)
				return false;
		} else if (!questionId.equals(other.questionId))
			return false;
		return true;
	}

	
}
