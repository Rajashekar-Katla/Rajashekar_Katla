/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Model class representing an SRT Section.
 * @author ntones
 */
@Entity
@Table(name = "SECTION_TBL")
public class Section implements Serializable {

    /**
     * defualt serial version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Object primary key.
     */
    @Id
    @Column(name = "SECTION_ID")
    @SequenceGenerator(name = "section_seq", sequenceName = "SECTION_ID_SEQNO", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "section_seq")
    private Long id;

    /**
     * The short name of the section.
     */
    @Column(name = "SECTION_NAME")
    private String sectionName;

    /**
     * The order section appears.
     */
    @Column(name = "SECTION_ORDER")
    private int sectionOrder;

    /**
     * The display text for the section full name.
     */
    @Column(name = "DISPLAY_TEXT")
    private String displayText;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the sectionName
     */
    public String getSectionName() {
        return sectionName;
    }

    /**
     * @param sectionName the sectionName to set
     */
    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    /**
     * @return the sectionOrder
     */
    public int getSectionOrder() {
        return sectionOrder;
    }

    /**
     * @param sectionOrder the sectionOrder to set
     */
    public void setSectionOrder(int sectionOrder) {
        this.sectionOrder = sectionOrder;
    }

    /**
     * @return the displayText
     */
    public String getDisplayText() {
        return displayText;
    }

    /**
     * @param displayText the displayText to set
     */
    public void setDisplayText(String displayText) {
        this.displayText = displayText;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Section other = (Section) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Section [id=" + id + ", sectionName=" + sectionName + ", sectionOrder=" + sectionOrder
                + ", displayText=" + displayText + "]";
    }

}
