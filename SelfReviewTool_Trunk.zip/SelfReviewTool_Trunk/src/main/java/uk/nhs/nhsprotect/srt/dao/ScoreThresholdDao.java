package uk.nhs.nhsprotect.srt.dao;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.ScoreThreshold;

@FunctionalInterface
public interface ScoreThresholdDao {
	public List<ScoreThreshold> getScoreThresholdData() throws SrtException;

}
