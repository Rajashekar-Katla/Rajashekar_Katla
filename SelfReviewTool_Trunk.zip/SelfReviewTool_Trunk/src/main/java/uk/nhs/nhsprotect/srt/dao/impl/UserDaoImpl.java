package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.UserDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.model.authentication.User;

@Repository("userDao")
public class UserDaoImpl extends SRTHibernateDaoSupportImpl implements UserDao {

    /**
     * Class logger instance.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(UserDaoImpl.class);

    @SuppressWarnings("rawtypes")
    public Person getPersonDetails(String staffId) throws SrtException {

        try {
            String queryStr = "from Person as per where per.status = 'Y' and per.startDate < sysdate and (per.endDate > sysdate or per.endDate is null) and per.staffId = :staffId";

            Query exQuery = getCurrentSession().createQuery(queryStr).setParameter("staffId", staffId);

            List personList = exQuery.list();

            if (null != personList && !personList.isEmpty()) {

                return (Person) personList.get(0);
            }

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }
        return null;
    }

    public User findByUserName(String userName) throws SrtException {

        try {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("find By UserName=" + userName);
            }
            Criteria criteria = getCurrentSession().createCriteria(User.class)
                    .add(Restrictions.eq("username", userName));

            return (User) criteria.uniqueResult();

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }
    }

    public String getSharedPassword(String loginName) throws SrtException {

        try {

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("getShared access By loginName=" + loginName);
            }
            Criteria criteria = getCurrentSession().createCriteria(User.class)
                    .add(Restrictions.eq("username", loginName)).add(Restrictions.eq("enabled", true));

            User user = (User) criteria.uniqueResult();

            return (null != user ? user.getPassword() : null);

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }
    }

}
