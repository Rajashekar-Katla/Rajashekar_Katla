
/**
 * Package containing Spring Configuration classes.
 * @author ntones
 */
package uk.nhs.nhsprotect.srt.config;