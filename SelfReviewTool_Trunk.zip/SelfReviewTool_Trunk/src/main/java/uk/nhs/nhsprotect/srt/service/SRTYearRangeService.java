/**
 * 
 */
package uk.nhs.nhsprotect.srt.service;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTYearRange;

/**
 * @author bvaidya
 */

public interface SRTYearRangeService {

    /**
     * Service method to get the object for given year and srt type.
     * @param year
     * @param srtType
     * @return
     * @throws SrtException
     */
    SRTYearRange getYearRange(String year, String srtType) throws SrtException;

    /**
     * Service method to get distinct list of years.
     * @param srtType the SRT Type to query for
     * @return List<String> SRT Years as string
     * @throws SrtException
     */
    List<String> getDistinctListOfYears(String srtType) throws SrtException;

}
