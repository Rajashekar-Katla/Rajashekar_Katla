/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * @author ntones
 */
@Entity
@DiscriminatorValue("NHSE")
public class NHSERegion extends Regions {
}
