/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.PrintDao;
import uk.nhs.nhsprotect.srt.dto.SRTSummary;
import uk.nhs.nhsprotect.srt.exception.SrtException;

/**
 * @author bvaidya
 */
@Repository("printDao")
public class PrintDaoImpl extends SRTHibernateDaoSupportImpl implements PrintDao {

    @SuppressWarnings("unchecked")
    @Cacheable(cacheNames = "srtSummary", key = "{#orgCode, #srtType, #year}")
    @Override
    public List<SRTSummary> getResults(final String orgCode, final String srtType, final String year)
            throws SrtException {

        // TODO refactor this...
        String queryStr = "select qa.questionText, sec.sectionName, res.score, res.comments "
                + "from Result res, Questionnaire qa, Section sec where res.questionId = qa.questionId and "
                + "res.srtType = :srtType  and qa.srtType = :srtType and qa.year = :year and "
                + "res.orgCode =:orgCode and sec.id = qa.section.id  order by sec.sectionName, qa.questionOrderNo asc";

        try {

            Query query = getCurrentSession().createQuery(queryStr).setParameter("orgCode", orgCode)
                    .setParameter("srtType", srtType).setParameter("year", year);

            List<Object[]> list = query.list();

            List<SRTSummary> summaryList = new ArrayList<SRTSummary>();

            if (null != list && !list.isEmpty()) {

                for (Object[] object : list) {

                    SRTSummary srtSummary = new SRTSummary();
                    srtSummary.setQuestionText((String) object[0]);
                    srtSummary.setSectionName((String) object[1]);
                    srtSummary.setScore((Integer) object[2]);
                    srtSummary.setComments((String) object[3]);

                    summaryList.add(srtSummary);
                }
                return summaryList;
            }

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }
        return null;
    }

}
