/**
 * 
 */
package uk.nhs.nhsprotect.srt.hibernate.enums;

/**
 * Allows an enumerated type to be persisted based on an Id field rather than by
 * order (EnumType.ORDINAL) or name (EnumType.STRING).
 * @author ntones
 */
public interface PersistentEnum {

    /**
     * Return the numeric Id value.
     * @return int id
     */
    int getId();

}
