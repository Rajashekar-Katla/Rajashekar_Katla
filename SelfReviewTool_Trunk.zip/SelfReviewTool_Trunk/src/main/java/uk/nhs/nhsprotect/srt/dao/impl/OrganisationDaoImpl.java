/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.OrganisationDAO;
import uk.nhs.nhsprotect.srt.model.Organisation;

/**
 * @author ntones
 */
@Repository
@MonitoredWithSpring
public class OrganisationDaoImpl implements OrganisationDAO {

  @Autowired
  private SessionFactory sessionFactory;

  /*
   * (non-Javadoc)
   * @see
   * uk.nhs.nhsprotect.srt.dao.OrganisationDAO#findByOrgCode(java.lang.String)
   */
  @Override
  public Organisation findByOrgCode(String orgCode) {
    Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Organisation.class);
    criteria.add(Restrictions.eq("orgCode", orgCode));
    return (Organisation) criteria.uniqueResult();
  }

}
