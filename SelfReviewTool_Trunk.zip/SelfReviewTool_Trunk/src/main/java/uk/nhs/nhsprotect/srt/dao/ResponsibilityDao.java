/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Responsibility;

/**
 * @author bvaidya
 */
public interface ResponsibilityDao {

  /**
   * Get the responsibility list by staff id
   * @param staffId
   * @param includeCommissioningOrgs - flag to indicate if Commissiong orgs
   *          should be included in query
   * @return
   * @throws SrtException
   */
  List<Responsibility> getResponsibilitiesByStaffId(String staffId, boolean includeCommissioningOrgs)
      throws SrtException;

  /**
   * Get responsibility by user reference and organisation code
   * @param usreRef the user login
   * @param orgCode the org code
   * @return
   * @throws SrtException
   */
  List<Responsibility> getResponsibilityByPersonAndOrg(String usreRef, String orgCode) throws SrtException;

  /**
   * Get Responsibility by orgCode only, could be buggy, check data quality.
   * @param orgCode
   * @return
   * @throws SrtException
   */
  List<Responsibility> getResponsibilitiesByOrgCode(String orgCode) throws SrtException;

}
