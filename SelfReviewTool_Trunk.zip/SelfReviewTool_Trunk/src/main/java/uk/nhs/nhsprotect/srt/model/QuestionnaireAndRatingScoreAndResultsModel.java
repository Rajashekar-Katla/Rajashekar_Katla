package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

import uk.nhs.nhsprotect.srt.util.SRTUtil;

@Entity
public class QuestionnaireAndRatingScoreAndResultsModel implements Serializable {

	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "QUESTION_ID")
	private Long questionId;

	@Column(name = "QUESTION_TEXT")
	private String questionText;

	@Column(name = "HELP_TEXT")
	private String helpText;

	@Column(name = "QUESTION_ORDER_NO")
	private int questionOrderNo;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "REGION")
	private String region;

	@Column(name = "SRT_TYPE")
	private String srtType;

	@Column(name = "QUESTION_STATUS")
	private String questionStatus;

	@Column(name = "PRIORITY")
	private int priority;

	@Column(name = "HELP_PAGE_URL")
	private String helpPageUrl;

	@Column(name = "YEAR")
	private String year;

	@Column(name = "VALIDATION_TYPE")
	private String validationType;

	@Column(name = "STANDARD")
	private String standard;

	@Column(name = "SECTION_ID")
	private int sectionId;

	@Column(name = "ELEMENT_NAME")
	private String elementName;

	@Column(name = "SECTION_NAME")
	private String sectionName;

	@Column(name = "SECTION_ORDER")
	private int sectionOrder;

	@Column(name = "RESULT_ID")
	private Long resultId;

	@Column(name = "ORG_CODE")
	private String orgCode;

	@Column(name = "COMMENTS")
	private String comments;

	@Column(name = "SCORE")
	private Integer score;

	@Column(name = "RATING")
	private String rating;

	@Column(name = "POSSIBLE_RATING")
	private String possible_rating;
	
	@Column(name = "POSSIBLE_RATING_VALUE")
	private String possible_rating_value;

	@Column(name = "RESULTS_CREATED_BY")
	private String resultCreatedBy;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "RESULTS_CREATED_DATE")
	private Date resultCreatedDate;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	/**
	 * @return the questionId
	 */
	public Long getQuestionId() {
		return questionId;
	}

	/**
	 * @param questionId
	 *            the questionId to set
	 */
	public void setQuestionId(Long questionId) {
		this.questionId = questionId;
	}

	/**
	 * @return the questionText
	 */
	public String getQuestionText() {
		return questionText;
	}

	/**
	 * @param questionText
	 *            the questionText to set
	 */
	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	/**
	 * @return the helpText
	 */
	public String getHelpText() {
		return helpText;
	}

	/**
	 * @param helpText
	 *            the helpText to set
	 */
	public void setHelpText(String helpText) {
		this.helpText = helpText;
	}

	/**
	 * @return the questionOrderNo
	 */
	public int getQuestionOrderNo() {
		return questionOrderNo;
	}

	/**
	 * @param questionOrderNo
	 *            the questionOrderNo to set
	 */
	public void setQuestionOrderNo(int questionOrderNo) {
		this.questionOrderNo = questionOrderNo;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region
	 *            the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the srtType
	 */
	public String getSrtType() {
		return srtType;
	}

	/**
	 * @param srtType
	 *            the srtType to set
	 */
	public void setSrtType(String srtType) {
		this.srtType = srtType;
	}

	/**
	 * @return the questionStatus
	 */
	public String getQuestionStatus() {
		return questionStatus;
	}

	/**
	 * @param questionStatus
	 *            the questionStatus to set
	 */
	public void setQuestionStatus(String questionStatus) {
		this.questionStatus = questionStatus;
	}

	/**
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}

	/**
	 * @param priority
	 *            the priority to set
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * @return the helpPageReference
	 */
	public String getHelpPageUrl() {
		return helpPageUrl;
	}

	/**
	 * @param helpPageReference
	 *            the helpPageReference to set
	 */
	public void setHelpPageUrl(String helpPageUrl) {
		this.helpPageUrl = helpPageUrl;
	}

	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}

	/**
	 * @param year
	 *            the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * @return the validationType
	 */
	public String getValidationType() {
		return validationType;
	}

	/**
	 * @param validationType
	 *            the validationType to set
	 */
	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}

	/**
	 * @return the standard
	 */
	public String getStandard() {
		return standard;
	}

	/**
	 * @param standard
	 *            the standard to set
	 */
	public void setStandard(String standard) {
		this.standard = standard;
	}

	/**
	 * @return the sectionId
	 */
	public int getSectionId() {
		return sectionId;
	}

	/**
	 * @param sectionId
	 *            the sectionId to set
	 */
	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}

	/**
	 * @return the elementName
	 */
	public String getElementName() {
		return elementName;
	}

	/**
	 * @param elementName
	 *            the elementName to set
	 */
	public void setElementName(String elementName) {
		this.elementName = elementName;
	}

	/**
	 * @return the sectionName
	 */
	public String getSectionName() {
		return sectionName;
	}

	/**
	 * @param sectionName
	 *            the sectionName to set
	 */
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	/**
	 * @return the sectionOrder
	 */
	public int getSectionOrder() {
		return sectionOrder;
	}

	/**
	 * @param sectionOrder
	 *            the sectionOrder to set
	 */
	public void setSectionOrder(int sectionOrder) {
		this.sectionOrder = sectionOrder;
	}

	/**
	 * @return the resultId
	 */
	public Long getResultId() {
		return resultId;
	}

	/**
	 * @param resultId
	 *            the resultId to set
	 */
	public void setResultId(Long resultId) {
		this.resultId = resultId;
	}

	/**
	 * @return the orgCode
	 */
	public String getOrgCode() {
		return orgCode;
	}

	/**
	 * @param orgCode
	 *            the orgCode to set
	 */
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments
	 *            the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the score
	 */
	public Integer getScore() {
		return score;
	}

	/**
	 * @param score
	 *            the score to set
	 */
	public void setScore(Integer score) {
		this.score = score;
	}

	/**
	 * @return the rating
	 */
	public String getRating() {
		return rating;
	}

	/**
	 * @param rating
	 *            the rating to set
	 */
	public void setRating(String rating) {
		this.rating = rating;
	}

	/**
	 * @return the possible_rating
	 */
	public String getPossible_rating() {
		return possible_rating;
	}

	/**
	 * @param possible_rating
	 *            the possible_rating to set
	 */
	public void setPossible_rating(String possible_rating) {
		this.possible_rating = possible_rating;
	}

	/**
	 * @return the possible_rating_value
	 */
	public String getPossible_rating_value() {
		return possible_rating_value;
	}

	/**
	 * @param possible_rating_value the possible_rating_value to set
	 */
	public void setPossible_rating_value(String possible_rating_value) {
		this.possible_rating_value = possible_rating_value;
	}

	/**
	 * @return the resultCreatedBy
	 */
	public String getResultCreatedBy() {
		return resultCreatedBy;
	}

	/**
	 * @param resultCreatedBy
	 *            the resultCreatedBy to set
	 */
	public void setResultCreatedBy(String resultCreatedBy) {
		this.resultCreatedBy = resultCreatedBy;
	}

	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @param modifiedBy
	 *            the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return the resultCreatedDate
	 */
	public Date getResultCreatedDate() {
		return resultCreatedDate;
	}

	/**
	 * @param resultCreatedDate
	 *            the resultCreatedDate to set
	 */
	public void setResultCreatedDate(Date resultCreatedDate) {
		this.resultCreatedDate = resultCreatedDate;
	}

	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate
	 *            the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public boolean isWelshRegion() {
		return SRTUtil.WELSH_REGION_CODE.equals(this.region);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "QuestionnaireAndRatingScoreAndResultsModel [questionId="
				+ questionId + ", questionText=" + questionText + ", helpText="
				+ helpText + ", questionOrderNo=" + questionOrderNo
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy
				+ ", region=" + region + ", srtType=" + srtType
				+ ", questionStatus=" + questionStatus + ", priority="
				+ priority + ", helpPageReference=" + helpPageUrl
				+ ", year=" + year + ", validationType=" + validationType
				+ ", standard=" + standard + ", sectionId=" + sectionId
				+ ", elementName=" + elementName + ", sectionName="
				+ sectionName + ", sectionOrder=" + sectionOrder
				+ ", resultId=" + resultId + ", orgCode=" + orgCode
				+ ", comments=" + comments + ", score=" + score + ", rating="
				+ rating + ", possible_rating=" + possible_rating
				+ ", resultCreatedBy=" + resultCreatedBy + ", modifiedBy="
				+ modifiedBy + ", resultCreatedDate=" + resultCreatedDate
				+ ", modifiedDate=" + modifiedDate + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((comments == null) ? 0 : comments.hashCode());
		result = prime * result
				+ ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result
				+ ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result
				+ ((elementName == null) ? 0 : elementName.hashCode());
		result = prime
				* result
				+ ((helpPageUrl == null) ? 0 : helpPageUrl
						.hashCode());
		result = prime * result
				+ ((helpText == null) ? 0 : helpText.hashCode());
		result = prime * result
				+ ((modifiedBy == null) ? 0 : modifiedBy.hashCode());
		result = prime * result
				+ ((modifiedDate == null) ? 0 : modifiedDate.hashCode());
		result = prime * result + ((orgCode == null) ? 0 : orgCode.hashCode());
		result = prime * result
				+ ((possible_rating == null) ? 0 : possible_rating.hashCode());
		result = prime * result + priority;
		result = prime * result
				+ ((questionId == null) ? 0 : questionId.hashCode());
		result = prime * result + questionOrderNo;
		result = prime * result
				+ ((questionStatus == null) ? 0 : questionStatus.hashCode());
		result = prime * result
				+ ((questionText == null) ? 0 : questionText.hashCode());
		result = prime * result + ((rating == null) ? 0 : rating.hashCode());
		result = prime * result + ((region == null) ? 0 : region.hashCode());
		result = prime * result
				+ ((resultCreatedBy == null) ? 0 : resultCreatedBy.hashCode());
		result = prime
				* result
				+ ((resultCreatedDate == null) ? 0 : resultCreatedDate
						.hashCode());
		result = prime * result + (int) (resultId ^ (resultId >>> 32));
		result = prime * result + ((score == null) ? 0 : score.hashCode());
		result = prime * result + sectionId;
		result = prime * result
				+ ((sectionName == null) ? 0 : sectionName.hashCode());
		result = prime * result + sectionOrder;
		result = prime * result + ((srtType == null) ? 0 : srtType.hashCode());
		result = prime * result
				+ ((standard == null) ? 0 : standard.hashCode());
		result = prime * result
				+ ((validationType == null) ? 0 : validationType.hashCode());
		result = prime * result + ((year == null) ? 0 : year.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuestionnaireAndRatingScoreAndResultsModel other = (QuestionnaireAndRatingScoreAndResultsModel) obj;
		if (comments == null) {
			if (other.comments != null)
				return false;
		} else if (!comments.equals(other.comments))
			return false;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (elementName == null) {
			if (other.elementName != null)
				return false;
		} else if (!elementName.equals(other.elementName))
			return false;
		if (helpPageUrl == null) {
			if (other.helpPageUrl != null)
				return false;
		} else if (!helpPageUrl.equals(other.helpPageUrl))
			return false;
		if (helpText == null) {
			if (other.helpText != null)
				return false;
		} else if (!helpText.equals(other.helpText))
			return false;
		if (modifiedBy == null) {
			if (other.modifiedBy != null)
				return false;
		} else if (!modifiedBy.equals(other.modifiedBy))
			return false;
		if (modifiedDate == null) {
			if (other.modifiedDate != null)
				return false;
		} else if (!modifiedDate.equals(other.modifiedDate))
			return false;
		if (orgCode == null) {
			if (other.orgCode != null)
				return false;
		} else if (!orgCode.equals(other.orgCode))
			return false;
		if (possible_rating == null) {
			if (other.possible_rating != null)
				return false;
		} else if (!possible_rating.equals(other.possible_rating))
			return false;
		if (priority != other.priority)
			return false;
		if (questionId == null) {
			if (other.questionId != null)
				return false;
		} else if (!questionId.equals(other.questionId))
			return false;
		if (questionOrderNo != other.questionOrderNo)
			return false;
		if (questionStatus == null) {
			if (other.questionStatus != null)
				return false;
		} else if (!questionStatus.equals(other.questionStatus))
			return false;
		if (questionText == null) {
			if (other.questionText != null)
				return false;
		} else if (!questionText.equals(other.questionText))
			return false;
		if (rating == null) {
			if (other.rating != null)
				return false;
		} else if (!rating.equals(other.rating))
			return false;
		if (region == null) {
			if (other.region != null)
				return false;
		} else if (!region.equals(other.region))
			return false;
		if (resultCreatedBy == null) {
			if (other.resultCreatedBy != null)
				return false;
		} else if (!resultCreatedBy.equals(other.resultCreatedBy))
			return false;
		if (resultCreatedDate == null) {
			if (other.resultCreatedDate != null)
				return false;
		} else if (!resultCreatedDate.equals(other.resultCreatedDate))
			return false;
		if (resultId != other.resultId)
			return false;
		if (score == null) {
			if (other.score != null)
				return false;
		} else if (!score.equals(other.score))
			return false;
		if (sectionId != other.sectionId)
			return false;
		if (sectionName == null) {
			if (other.sectionName != null)
				return false;
		} else if (!sectionName.equals(other.sectionName))
			return false;
		if (sectionOrder != other.sectionOrder)
			return false;
		if (srtType == null) {
			if (other.srtType != null)
				return false;
		} else if (!srtType.equals(other.srtType))
			return false;
		if (standard == null) {
			if (other.standard != null)
				return false;
		} else if (!standard.equals(other.standard))
			return false;
		if (validationType == null) {
			if (other.validationType != null)
				return false;
		} else if (!validationType.equals(other.validationType))
			return false;
		if (year == null) {
			if (other.year != null)
				return false;
		} else if (!year.equals(other.year))
			return false;
		return true;
	}

}