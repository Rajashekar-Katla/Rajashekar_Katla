/**
 * 
 */
package uk.nhs.nhsprotect.srt.controller;

import org.apache.velocity.exception.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import net.bull.javamelody.MonitoredWithSpring;

/**
 * Controller to handle exceptions.
 * 
 * @author ntones
 */
@ControllerAdvice
@MonitoredWithSpring
public class ExceptionAdvice {

	/**
	 * Class logger instance.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionAdvice.class);

	@ExceptionHandler(value = AccessDeniedException.class)
	@ResponseStatus(HttpStatus.FORBIDDEN)
	public ModelAndView accessDenied(AccessDeniedException exception) {
		LOGGER.error("Error", exception);
		return new ModelAndView("access-denied");
	}

	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ModelAndView handleResourceNotFoundException() {
		return new ModelAndView("404");
	}

	@ExceptionHandler(value = Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ModelAndView exception(Exception exception) {

		LOGGER.error("Error", exception);
		return new ModelAndView("exception-caught");
	}

	

}
