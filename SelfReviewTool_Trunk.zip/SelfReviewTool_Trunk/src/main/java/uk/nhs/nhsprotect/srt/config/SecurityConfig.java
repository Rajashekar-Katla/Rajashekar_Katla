package uk.nhs.nhsprotect.srt.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configurers.provisioning.InMemoryUserDetailsManagerConfigurer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.header.writers.StaticHeadersWriter;
import org.springframework.security.web.session.HttpSessionEventPublisher;

/**
 * Configuration class for spring security.
 * @author ntones
 */
@Configuration
@EnableWebSecurity
class SecurityConfig extends WebSecurityConfigurerAdapter {

    /**
     * Spring provided UserService.
     */
    @Autowired
    private UserDetailsService userDetailsService;

    /*
     * (non-Javadoc)
     * @see org.springframework.security.config.annotation.web.configuration.
     * WebSecurityConfigurerAdapter#
     * configure(org.springframework.security.config.annotation.authentication.
     * builders. AuthenticationManagerBuilder)
     */
    @Override
    protected void configure(final AuthenticationManagerBuilder auth) throws Exception {
        // restrict access to monitoring URL
        inMemoryConfigurer().withUser("monitor").password("P@ssw0rd1!").authorities("ROLE_MONITOR").and()
                .configure(auth);
        auth.authenticationProvider(getDBAuthenticationProvider());

    }

    private InMemoryUserDetailsManagerConfigurer<AuthenticationManagerBuilder> inMemoryConfigurer() {
        return new InMemoryUserDetailsManagerConfigurer<>();
    }

    private AuthenticationProvider getDBAuthenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        return provider;
    }

    /*
     * (non-Javadoc)
     * @see org.springframework.security.config.annotation.web.configuration.
     * WebSecurityConfigurerAdapter
     * #configure(org.springframework.security.config.annotation.web.builders.
     * HttpSecurity)
     */
    @Override
    protected void configure(final HttpSecurity http) throws Exception {
        // restrict access to monitoring URL
        http.authorizeRequests().antMatchers("/monitoring/**").hasRole("MONITOR").antMatchers("/login", "/logout")
                .permitAll().antMatchers("/**").fullyAuthenticated()
                .and().formLogin().loginPage("/login").loginProcessingUrl("/authentication/security_check").failureUrl("/login?login_error=t")
                .and().exceptionHandling().accessDeniedPage("/403")
                .and().logout()
                .clearAuthentication(true).invalidateHttpSession(true).deleteCookies("JSESSIONID").logoutUrl("/logout")
                .logoutSuccessUrl("/login").and().headers().frameOptions().sameOrigin().and().headers()
                .addHeaderWriter(new StaticHeadersWriter("Server", "NHS Protect")).and().csrf();
        http.sessionManagement().enableSessionUrlRewriting(false).maximumSessions(1)
                .expiredUrl("/login?session_expired=t").and().sessionAuthenticationErrorUrl("/login?multiple_session=t")
                .and();

    }

    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }

    /*
     * (non-Javadoc)
     * @see org.springframework.security.config.annotation.web.configuration.
     * WebSecurityConfigurerAdapter#configure(org.springframework.security.
     * config.annotation.web.builders.WebSecurity)
     */
    @Override
    public void configure(final WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/wro/**","/resources/**", "/favicon.ico", "/errors");
    }

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

}