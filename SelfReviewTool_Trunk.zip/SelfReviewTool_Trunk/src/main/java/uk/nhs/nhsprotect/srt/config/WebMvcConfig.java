package uk.nhs.nhsprotect.srt.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.tiles3.TilesConfigurer;
import org.springframework.web.servlet.view.tiles3.TilesViewResolver;

import uk.nhs.nhsprotect.srt.Application;

/**
 * Configuration class for Spring MVC component.
 * @author ntones
 */
@Configuration
@ComponentScan(
               basePackageClasses = Application.class,
               includeFilters = @Filter(Controller.class),
               useDefaultFilters = false)
class WebMvcConfig extends WebMvcConfigurationSupport {

    /**
     * Location of MVC Views (pages).
     */
    private static final String VIEWS = "/WEB-INF/views/";

    /**
     * File type of MVC Views (pages).
     */
    private static final String JSP_SUFFIX = ".jsp";

    /**
     * Location of web resources JSs, CSSs, images, etc.
     */
    private static final String RESOURCES_LOCATION = "/resources/";

    /**
     * Path for web resources.
     */
    private static final String RESOURCES_HANDLER = RESOURCES_LOCATION + "**";

    /**
     * Location of Apache Tiles definitions.
     */
    private static final String TILES_DEF_LOCATION = "WEB-INF/tiles-definitions.xml";

    @Autowired
    private MessageSource messageSource;

    /*
     * (non-Javadoc)
     * @see org.springframework.web.servlet.config.annotation.
     * WebMvcConfigurationSupport#requestMappingHandlerMapping()
     */
    @Override
    public RequestMappingHandlerMapping requestMappingHandlerMapping() {
        RequestMappingHandlerMapping requestMappingHandlerMapping = super.requestMappingHandlerMapping();
        requestMappingHandlerMapping.setUseSuffixPatternMatch(false);
        requestMappingHandlerMapping.setUseTrailingSlashMatch(false);
        return requestMappingHandlerMapping;
    }

    
    /*
     * (non-Javadoc)
     * @see org.springframework.web.servlet.config.annotation.
     * WebMvcConfigurationSupport#getValidator()
     */
    @Override
    public Validator getValidator() {
        LocalValidatorFactoryBean validator = new LocalValidatorFactoryBean();
        validator.setValidationMessageSource(messageSource);
        return validator;
    }

    /*
     * (non-Javadoc)
     * @see org.springframework.web.servlet.config.annotation.
     * WebMvcConfigurationSupport#addResourceHandlers(org.springframework.web.
     * servlet.config.annotation.ResourceHandlerRegistry)
     */
    @Override
    public void addResourceHandlers(final ResourceHandlerRegistry registry) {
        registry.addResourceHandler(RESOURCES_HANDLER).addResourceLocations(RESOURCES_LOCATION)
                .setCachePeriod(315556926);

    }

    /*
     * (non-Javadoc)
     * @see org.springframework.web.servlet.config.annotation.
     * WebMvcConfigurationSupport#configureDefaultServletHandling(org.
     * springframework.web.servlet.config.annotation.
     * DefaultServletHandlerConfigurer)
     */
    @Override
    public void configureDefaultServletHandling(final DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }

    /**
     * Simple view resolver that attempts to render controller results to jsp
     * resources in the views directory.
     * @return InternalResourceViewResolver
     */
    @Bean
    public ViewResolver internalResourceViewResolver() {
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix(VIEWS);
        viewResolver.setSuffix(JSP_SUFFIX);
        viewResolver.setOrder(2);
        return viewResolver;
    }

    /**
     * TilesViewResolver bean to handle tiles view results.
     * @return ViewResolver
     */
    @Bean
    public ViewResolver tilesViewResolver() {
        TilesViewResolver tilesViewResolver = new TilesViewResolver();
        tilesViewResolver.setOrder(1);
        return tilesViewResolver;
    }

    /**
     * Tiles configuration to render controller results to tile definitions.
     * @return TilesConfigurer
     */
    @Bean
    public TilesConfigurer tilesConfigurer() {
        TilesConfigurer tilesConfigurer = new TilesConfigurer();
        tilesConfigurer.setDefinitions(TILES_DEF_LOCATION);
        return tilesConfigurer;
    }

}
