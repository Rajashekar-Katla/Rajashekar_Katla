/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author bvaidya
 */
@Entity
@Table(name = "SRT_STATUS_TBL")
public class SRTStatus implements Serializable {

  /**
   * Default Serial Version.
   */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "STATUS_ID")
  @SequenceGenerator(name = "my_seq", sequenceName = "STATUS_ID_SEQNO", allocationSize = 1)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_seq")
  private Long Id;

  @Column(name = "ORG_CODE")
  private String orgCode;

  @Column(name = "STATUS")
  private String status;

  @Column(name = "OVERALL_SCORE")
  private String overallScore;
  /*
   * @Column(name = "SUBMITTED_BY") private String submittedBy;
   */
  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "SUBMITTED_BY")
  private Person submittedBy;

  @Column(name = "SUBMITTED_BY", insertable = false, updatable = false)
  private String submittedById;

  @Column(name = "SUBMITTED_DATE")
  private Date submittedDate;

  @Column(name = "SRT_TYPE")
  private String srtType;

  @Column(name = "YEAR")
  private String year;

  @Column(name = "STRAT_GOV_SCORE")
  private String strategicGovernanceSectionScore;

  @Column(name = "INF_INV_SCORE")
  private String informAndInvolveSectionScore;

  @Column(name = "PREV_DET_SCORE")
  private String prventAndDeterSectionScore;

  @Column(name = "HOLD_ACCT_SCORE")
  private String holdToAccountSectionScore;

  /**
   * @return the id
   */
  public Long getId() {
    return Id;
  }

  /**
   * @param id the id to set
   */
  public void setId(Long id) {
    Id = id;
  }

  /**
   * @return the orgCode
   */
  public String getOrgCode() {
    return orgCode;
  }

  /**
   * @param orgCode the orgCode to set
   */
  public void setOrgCode(String orgCode) {
    this.orgCode = orgCode;
  }

  /**
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * @param status the status to set
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * @return the overallScore
   */
  public String getOverallScore() {
    return overallScore;
  }

  /**
   * @param overallScore the overallScore to set
   */
  public void setOverallScore(String overallScore) {
    this.overallScore = overallScore;
  }

  /**
   * @return the submittedBy
   */
  public Person getSubmittedBy() {
    return submittedBy;
  }

  /**
   * @param submittedBy the submittedBy to set
   */
  public void setSubmittedBy(Person submittedBy) {
    this.submittedBy = submittedBy;
  }

  /**
   * @return the submittedDate
   */
  public Date getSubmittedDate() {
    return submittedDate;
  }

  /**
   * @param submittedDate the submittedDate to set
   */
  public void setSubmittedDate(Date submittedDate) {
    this.submittedDate = submittedDate;
  }

  public String getSrtType() {
    return srtType;
  }

  public void setSrtType(String srtType) {
    this.srtType = srtType;
  }

  /**
   * @return the year
   */
  public String getYear() {
    return year;
  }

  /**
   * @param year the year to set
   */
  public void setYear(String year) {
    this.year = year;
  }

  /**
   * @return the strategicGovernanceSectionScore
   */
  public String getStrategicGovernanceSectionScore() {
    return strategicGovernanceSectionScore;
  }

  /**
   * @param strategicGovernanceSectionScore the strategicGovernanceSectionScore
   *          to set
   */
  public void setStrategicGovernanceSectionScore(String strategicGovernanceSectionScore) {
    this.strategicGovernanceSectionScore = strategicGovernanceSectionScore;
  }

  /**
   * @return the informAndInvolveSectionScore
   */
  public String getInformAndInvolveSectionScore() {
    return informAndInvolveSectionScore;
  }

  /**
   * @param informAndInvolveSectionScore the informAndInvolveSectionScore to set
   */
  public void setInformAndInvolveSectionScore(String informAndInvolveSectionScore) {
    this.informAndInvolveSectionScore = informAndInvolveSectionScore;
  }

  /**
   * @return the prventAndDeterSectionScore
   */
  public String getPrventAndDeterSectionScore() {
    return prventAndDeterSectionScore;
  }

  /**
   * @param prventAndDeterSectionScore the prventAndDeterSectionScore to set
   */
  public void setPrventAndDeterSectionScore(String prventAndDeterSectionScore) {
    this.prventAndDeterSectionScore = prventAndDeterSectionScore;
  }

  /**
   * @return the holdToAccountSectionScore
   */
  public String getHoldToAccountSectionScore() {
    return holdToAccountSectionScore;
  }

  /**
   * @param holdToAccountSectionScore the holdToAccountSectionScore to set
   */
  public void setHoldToAccountSectionScore(String holdToAccountSectionScore) {
    this.holdToAccountSectionScore = holdToAccountSectionScore;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "SRTStatus [Id=" + Id + ", orgCode=" + orgCode + ", status=" + status + ", overallScore=" + overallScore
        + ", submittedById=" + submittedById + ", submittedDate=" + submittedDate + ", srtType=" + srtType + ", year="
        + year + ", strategicGovernanceSectionScore=" + strategicGovernanceSectionScore
        + ", informAndInvolveSectionScore=" + informAndInvolveSectionScore + ", prventAndDeterSectionScore="
        + prventAndDeterSectionScore + ", holdToAccountSectionScore=" + holdToAccountSectionScore + "]";
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((Id == null) ? 0 : Id.hashCode());
    return result;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    SRTStatus other = (SRTStatus) obj;
    if (Id == null) {
      if (other.Id != null) {
        return false;
      }
    } else if (!Id.equals(other.Id)) {
      return false;
    }
    return true;
  }

}
