/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Organisation;
import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.service.OrganisationService;
import uk.nhs.nhsprotect.srt.service.SRTEmailService;
import uk.nhs.nhsprotect.srt.service.UserService;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRT_TYPES;

/**
 * @author ntones
 */
@Service("srtEmailService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class SRTEMailServiceImpl implements SRTEmailService {

	/**
	 * Class logger instance.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(SRTEMailServiceImpl.class);

	@Autowired
	private MailSender mailSender;

	@Autowired
	private SimpleMailMessage templateMessage;

	@Autowired
	private UserService userService;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private OrganisationService organisationService;

	@Value("${email.testMode}")
	private boolean testMode;

	@Value("${email.testAddress}")
	private String testEmailAddress;

	@Value("${email.testSender}")
	private String testEmailSender;

	@Value("${email.fraud.address}")
	private String fraudEmailAddress;

	@Value("${email.security.address}")
	private String securityEmailAddress;

	@Override
	@Transactional(noRollbackFor = MailException.class)
	public String sendMessage(final String orgCode, final String srtType, final String staffId) throws MailException {
		String response = null;
		Person person = null;
		try {
			person = userService.getUserDetails(staffId);
		} catch (SrtException e) {
			LOGGER.error("Unable to retrieve person details for StaffId: " + staffId, e);
		}
		if (person != null) {
			String recipientEmail = StringUtils.isEmpty(person.getEmailNHS())
					? (StringUtils.isEmpty(person.getEmailOther()) ? "" : person.getEmailOther())
					: person.getEmailNHS();

			if (StringUtils.isNotEmpty(recipientEmail)) {
				sendMail(prepareConfirmationEmail(organisationService.findOrganisationByCode(orgCode), recipientEmail),
						srtType);
			} else {
				response = "No email address for user ID " + staffId;
			}
		} else {
			response = "No person record for " + staffId;
		}

		return response;

	}

	@Override
	@Transactional(noRollbackFor = MailException.class)
	public void notifyResponsiblePersonVerificationFail(final String srtType, final Organisation organisation,
			final String expectedName, final String actualName, final String userName) throws MailException {
		sendMail(preparePersonVerificationFailEmail(srtType, organisation, expectedName, actualName, userName),
				srtType);

	}

	private SimpleMailMessage preparePersonVerificationFailEmail(final String srtType, final Organisation organisation,
			final String expectedName, final String actualName, final String userName) {
		String[] params = { srtType, organisation.getName(), userName, expectedName, actualName };
		SimpleMailMessage toSend = new SimpleMailMessage(templateMessage);
		toSend.setText(messageSource.getMessage("email.personverification.message.text", params, Locale.getDefault()));
		toSend.setSubject(
				messageSource.getMessage("email.personverification.subject.text", params, Locale.getDefault()));
		return toSend;

	}

	private SimpleMailMessage prepareConfirmationEmail(final Organisation organisation, final String recipientEmail) {

		String[] params = { organisation.getName() };
		SimpleMailMessage toSend = new SimpleMailMessage(templateMessage);
		toSend.setSubject(messageSource.getMessage("email.confirmation.subject.text", params, Locale.getDefault()));
		toSend.setText(messageSource.getMessage("email.confirmation.message.text", params, Locale.getDefault()));
		toSend.setTo(recipientEmail);
		return toSend;
	}

	private void sendMail(final SimpleMailMessage toSend, final String srtType) throws MailException {
		String bccEmail = null;
		String fromEmail = null;
		if (testMode) {
			// set values for test emails only
			toSend.setSubject("SRT EMAIL TEST!!! " + toSend.getSubject());
			toSend.setTo(testEmailAddress);
			bccEmail = testEmailAddress;
			fromEmail = testEmailSender;
		} else {

			if (srtType.equalsIgnoreCase(SRT_TYPES.lcfs.name()) || srtType.equalsIgnoreCase(SRT_TYPES.lcfscom.name())) {

				bccEmail = fraudEmailAddress;
				fromEmail = fraudEmailAddress;

			} else {
				bccEmail = securityEmailAddress;
				fromEmail = securityEmailAddress;
			}
		}
		toSend.setBcc(bccEmail);
		toSend.setFrom(fromEmail);
		mailSender.send(toSend);
	}
}
