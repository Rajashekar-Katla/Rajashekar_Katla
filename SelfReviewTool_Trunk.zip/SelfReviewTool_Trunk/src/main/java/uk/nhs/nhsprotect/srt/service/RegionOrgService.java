/**
 * 
 */
package uk.nhs.nhsprotect.srt.service;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.OrganisationByTypeCCG;
import uk.nhs.nhsprotect.srt.model.OrganisationType;
import uk.nhs.nhsprotect.srt.model.RegionOrgMapping;
import uk.nhs.nhsprotect.srt.model.Regions;

/**
 * @author bvaidya
 */
public interface RegionOrgService {

    /**
     * Service method to get region code value for given organisation code
     * @param orgCode
     * @return
     * @throws SrtException
     */
    RegionOrgMapping getRegionCodeByOrganization(String orgCode) throws SrtException;

    /**
     * Get the list of regions
     * @param srtType srt type to get options for
     * @param year the year to get options for
     * @param regionType the Type of Region to retrieve
     * @return List<Regions> for srt type and year
     * @throws SrtException
     */
    List<Regions> getRegionList(String srtType, String year, String regionType) throws SrtException;

    /**
     * Get the list of organisation/provider type.
     * @param srtType srt type to get options for
     * @param year the year to get options for
     * @return List<OrganisationType> for srt type and year
     * @throws SrtException
     */
    List<OrganisationType> getOrganisationTypes(String srtType, String year) throws SrtException;

    /**
     * Get the list of organisation/provider type for organisation type NHSE CCG
     * @return
     * @throws SrtException
     */
    List<OrganisationByTypeCCG> getProviderTypeListForCCG() throws SrtException;
}
