/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * Class to enforce the order specified in database table rather than relying on
 * natural sort of RDBMS.
 * @author ntones
 */
@MappedSuperclass
public class DisplayOrder implements Comparable<DisplayOrder> {

    @Column(name = "DISPLAY_ORDER")
    private Long displayOrder;

    /**
     * @return the displayOrder
     */
    public Long getDisplayOrder() {
        return displayOrder;
    }

    /**
     * @param displayOrder the displayOrder to set
     */
    public void setDisplayOrder(Long displayOrder) {
        this.displayOrder = displayOrder;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(DisplayOrder other) {

        return this.getDisplayOrder().compareTo(other.getDisplayOrder());

    }

}
