package uk.nhs.nhsprotect.srt.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestWrapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dto.ResponsibilityDTO;
import uk.nhs.nhsprotect.srt.dto.SRT;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.model.SRTStatus;
import uk.nhs.nhsprotect.srt.model.SRTYearRange;
import uk.nhs.nhsprotect.srt.model.authentication.SrtUser;
import uk.nhs.nhsprotect.srt.service.ResponsibilityService;
import uk.nhs.nhsprotect.srt.service.SRTStatusService;
import uk.nhs.nhsprotect.srt.service.SRTYearRangeService;
import uk.nhs.nhsprotect.srt.service.UserService;
import uk.nhs.nhsprotect.srt.util.SRTUtil;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRT_TYPES;
import uk.nhs.nhsprotect.srt.util.UserContextUtil;

@Controller
@SessionAttributes({ "person" })
@MonitoredWithSpring
public class LoginController {

	/**
	 * Class logger instance.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	private UserService userService;

	@Autowired
	private SRTYearRangeService yearRangeService;

	@Autowired
	private ResponsibilityService responsibilityService;

	@Autowired
	private SRTStatusService sRTStatusService;

	@RequestMapping(value = { "/main", "/" }, method = RequestMethod.GET)
	public ModelAndView printWelcome(ModelMap model, SecurityContextHolderAwareRequestWrapper request)
			throws Exception {

		// check if this is the monitoring user
		if (request.isUserInRole(SRTUtil.SRT_ROLE_MONITOR)) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("MONITOR user logged in redirect to JavaMelody screen");
			}
			return new ModelAndView(new RedirectView("/monitoring", true));

		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Main request ");
		}
		List<ResponsibilityDTO> responsibilities = null;
		SrtUser user = (SrtUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		String userName = user.getUsername();

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("printWelcome - user name " + userName);
			LOGGER.info("printWelcome - isCorporateUser " + UserContextUtil.isCorporateUser(request));
		}
		Person person;

		if (UserContextUtil.isCorporateUser(request)) {

			person = createPersonFromContextRequest(request);
			String orgCode = prepareOrgCodeFromUserName(userName);

			if (orgCode != null && StringUtils.isNotEmpty(orgCode)) {
				// TODO: Depends on the CPOD data quality.
				responsibilities = responsibilityService.getResponsibilitiesByOrgCode(orgCode);
			}

			if (null != responsibilities && !responsibilities.isEmpty()) {

				model.addAttribute("person", person);
				model.addAttribute("responsibilities", responsibilities);
				return this.getRedirectView(responsibilities.get(0).getOrgCode(), userName);
			} else {
				String errorMsg = "No responsibilities available for Shared access user=" + userName;
				LOGGER.error(errorMsg);
				throw new Exception(errorMsg);
			}

		} else {

			person = userService.getUserDetails(userName);

			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("printWelcome- is user null ? " + (null == person));
			}
			if (null != person) {
				try {
					if (LOGGER.isInfoEnabled()) {
						LOGGER.info(" printWelcome- PersonId:" + person.getPersonId());
					}
					responsibilities = responsibilityService.getResponsibilitiesByStaffId(userName);

				} catch (Exception e) {
					LOGGER.error("ERROR getting Responsibilities By userName=" + userName + "," + e.getMessage());
				}
			}
		}
		if (LOGGER.isDebugEnabled()) {

			LOGGER.debug("Responsibilities Count=" + (null != responsibilities ? responsibilities.size() : "NONE"));
		}

		model.addAttribute("person", person);
		model.addAttribute("responsibilities", responsibilities);

		return new ModelAndView("main", "Main", model);
	}

	private Person createPersonFromContextRequest(SecurityContextHolderAwareRequestWrapper request) {
		Person person = new Person();
		person.setTitle("");
		person.setForename1("Shared");
		person.setSurname("Access");
		String personType = SRTUtil.determinePersonType(request);
		person.setPersonType(personType);

		return person;
	}

	private String prepareOrgCodeFromUserName(String userName) {

		String orgCode = null;

		StringTokenizer strTokens = new StringTokenizer(userName, "_");

		if (strTokens.hasMoreElements()) {

			orgCode = (String) strTokens.nextElement();

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("OrgCode for Share ACCESS=" + orgCode);
			}
		}
		return orgCode;
	}

	/**
	 * Srtlist has dynamic params like
	 * orgCode=${srt.orgCode}&srt_type=${srt.type}&view=showsharedaccess
	 * 
	 * @param person
	 * @param orgCode
	 * @param request
	 * @param model
	 * @return
	 * @throws SrtException
	 */
	@RequestMapping(value = "/srtlist", method = RequestMethod.GET)
	@PreAuthorize("hasPermission('lcfs',#orgCode)")
	public ModelAndView srtlist(@ModelAttribute("person") Person person, @RequestParam("orgCode") String orgCode,
			HttpServletRequest request, ModelMap model) throws SrtException {

		if (LOGGER.isDebugEnabled()) {

			LOGGER.debug("Person=" + person + ", orgCode=" + orgCode);
		}

		List<SRT> srtList = new ArrayList<SRT>();

		ResponsibilityDTO orgDetails = null;

		Long personId = person.getPersonId();

		// END- Request for shared access
		// use user ID for mulitrole logins...
		SrtUser user = (SrtUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		String userName = user.getUsername();
		List<ResponsibilityDTO> responsibilities = responsibilityService.getResponsibilityByPersonAndOrg(userName,
				orgCode);

		if (LOGGER.isDebugEnabled()) {

			LOGGER.debug("Responsibility size =" + (null != responsibilities ? responsibilities.size() : 0)
					+ ", for personId=" + personId);
		}

		for (ResponsibilityDTO responsibility : responsibilities) {

			orgDetails = responsibility; // ???

			String comSuffix = responsibility.isCommissioningOrg() ? SRTUtil.COMMISSIONER_SUFFIX : "";
			String type = null;
			if (null != responsibility && null != responsibility.getPersonType()) {

				type = responsibility.getPersonType().toLowerCase() + comSuffix;
			} else {
				String err = "Responsibility / type data missing. Please contact service desk";
				LOGGER.error(err);
				throw new SrtException(err);
			}

			for (String year : getYearListByType(type)) {

				SRTStatus srtStatus = sRTStatusService.getSRTStatusByOrgCodeAndType(orgCode, type, year);

				SRT srt = new SRT();
				srt.setOrgCode(responsibility.getOrgCode());
				srt.setOrgName(responsibility.getOrgName());
				srt.setType(responsibility.getPersonType().toLowerCase() + comSuffix);
				srt.setYear(year);

				if (null != srtStatus) {

					srt.setStatus(srtStatus.getStatus());

					if (LOGGER.isInfoEnabled()) {
						LOGGER.info("SRTStatus is " + srtStatus.getStatus());
					}
					if (!SRTUtil.SRTStatus.SUBMITTED.toString().equals(srtStatus.getStatus())) {

						if (year.equals(SRTUtil.YEAR_FORMAT.format(new Date()))) {
							srt.setCreatedDate(new Date());
						} else {
							this.updateSRTDetails(srt, year);
						}
					} else {
						srt.setCreatedDate(srtStatus.getSubmittedDate());
					}
				} else if (year.equals(SRTUtil.YEAR_FORMAT.format(new Date()))) {

					srt.setCreatedDate(new Date());
					srt.setStatus(SRTUtil.SRTStatus.TODO.toString());
				} else {
					// TODO: Archived years, WITH NO SRTStatus records.
					this.updateSRTDetails(srt, year);
				}

				// show shared acess for all
				this.updateShareAccess(srt, year);

				srtList.add(srt);
			}
		}

		model.addAttribute("srts", srtList);
		model.addAttribute("responsibity", orgDetails);

		return new ModelAndView("srtlist", "model", model);
	}

	private List<String> getYearListByType(String srtType) throws SrtException {

		List<String> yearList = yearRangeService.getDistinctListOfYears(srtType);

		if (null == yearList || (null != yearList && yearList.isEmpty())) {

			String err = "YEAR DATA Missing, Please contact the service desk";
			LOGGER.error(err);
			throw new SrtException(err);
		}

		return yearList;
	}

	/**
	 * Method to set the created date of an SRT to the date of the start for the SRT
	 * period.
	 * 
	 * @param srt
	 * @param year
	 */
	private void updateSRTDetails(SRT srt, String year) throws SrtException {

		SRTYearRange range = yearRangeService.getYearRange(year, srt.getType());

		try {

			if (null == range || (null != range && null == range.getStartDate())) {

				srt.setCreatedDate(SRTUtil.DATE_FORMAT.parse("01/05/" + Integer.parseInt(year)));

			} else {
				if (!range.isActive()) {
					srt.setStatus("INACTIVE");
				}
				srt.setCreatedDate(range.getStartDate());
			}
		} catch (NumberFormatException nfe) {
			LOGGER.error("ERROR FORMATTING SRT CreatedDate= 01/05/" + year);
		} catch (ParseException e) {
			LOGGER.error("ERROR PARSING SRT CreatedDate= 01/05/" + year);
		}
	}

	/**
	 * Format for the Shared Access Login users is <ORG_CODE>_<FRAUD>_<YYYY> or
	 * <ORG_CODE>_<SMS>_<YYYY>.
	 * 
	 * @param srt
	 * @param reqParamYear
	 * @throws SrtException
	 * @throws UsernameNotFoundException
	 */
	private void updateShareAccess(SRT srt, String reqParamYear) throws UsernameNotFoundException, SrtException {

		String loginType = SRTUtil.LOGIN_TYPES.fraud.toString();

		if (null != srt) {
			if (SRT_TYPES.lcfscom.name().equalsIgnoreCase(srt.getType())) {
				loginType = SRTUtil.LOGIN_TYPES.fraudcom.toString();
			}
		}
		String loginName = srt.getOrgCode() + "_" + loginType + "_";

		if (reqParamYear.equals(SRTUtil.YEAR_FORMAT.format(new Date()))) {

			loginName = loginName + SRTUtil.YEAR_FORMAT.format(new Date());
		} else {

			loginName = loginName + reqParamYear;
		}

		String sharedPass = userService.getSharedPassword(loginName);

		srt.setSharedLogin(loginName);

		if (StringUtils.isNotEmpty(sharedPass)) {
			srt.setSharedPassword(sharedPass);
		}
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(ModelMap model) {

		if (LOGGER.isDebugEnabled()) {

			LOGGER.debug("Starting with LOGIN PAGE ");

		}
		return "login";

	}

	/**
	 * Redirection View
	 * 
	 * @param orgCode
	 * @param srtType
	 * @return
	 */
	private ModelAndView getRedirectView(String orgCode, String userName) {

		String year = null;

		StringBuffer param = new StringBuffer();

		if (StringUtils.isNotEmpty(userName)) {

			year = userName.substring(userName.length() - 4, userName.length());
		}

		if (StringUtils.isEmpty(userName)) {
			// If empty fill it will current year..
			year = SRTUtil.YEAR_FORMAT.format(new Date());
		}

		param.append("LCFSForm");

		param.append("?");
		param.append("orgCode=").append(orgCode);
		param.append("&").append("year=").append(year);

		return new ModelAndView(new RedirectView(param.toString()));
	}
}