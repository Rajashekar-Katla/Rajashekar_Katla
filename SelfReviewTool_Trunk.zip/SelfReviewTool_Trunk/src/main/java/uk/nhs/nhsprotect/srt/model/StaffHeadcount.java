/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author bvaidya
 */
@Entity
@Table(name = "STAFF_HEADCOUNT_TBL")
public class StaffHeadcount implements Serializable{

    /**
     * Default Serial Version.
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    private int id;
    @Column(name = "STAFF_HEADCOUNT_VAL")
    private String staffHeadcountVal;
    @Column(name = "CREATED_DATE")
    private Date createdDate;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "YEAR")
    private String year;
    @Column(name = "SRT_TYPE")
    private String srtType;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the staffHeadcountVal
     */
    public String getStaffHeadcountVal() {
        return staffHeadcountVal;
    }

    /**
     * @param staffHeadcountVal the staffHeadcountVal to set
     */
    public void setStaffHeadcountVal(String staffHeadcountVal) {
        this.staffHeadcountVal = staffHeadcountVal;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the year
     */
    public String getYear() {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(String year) {
        this.year = year;
    }

    /**
     * @return the srtType
     */
    public String getSrtType() {
        return srtType;
    }

    /**
     * @param srtType the srtType to set
     */
    public void setSrtType(String srtType) {
        this.srtType = srtType;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "StaffHeadcount [id=" + id + ", staffHeadcountVal=" + staffHeadcountVal + ", createdDate=" + createdDate
                + ", createdBy=" + createdBy + ", status=" + status + ", year=" + year + ", srtType=" + srtType + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((srtType == null) ? 0 : srtType.hashCode());
        result = prime * result + ((staffHeadcountVal == null) ? 0 : staffHeadcountVal.hashCode());
        result = prime * result + ((year == null) ? 0 : year.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        StaffHeadcount other = (StaffHeadcount) obj;
        if (srtType == null) {
            if (other.srtType != null) {
                return false;
            }
        } else if (!srtType.equals(other.srtType)) {
            return false;
        }
        if (staffHeadcountVal == null) {
            if (other.staffHeadcountVal != null) {
                return false;
            }
        } else if (!staffHeadcountVal.equals(other.staffHeadcountVal)) {
            return false;
        }
        if (year == null) {
            if (other.year != null) {
                return false;
            }
        } else if (!year.equals(other.year)) {
            return false;
        }
        return true;
    }

}
