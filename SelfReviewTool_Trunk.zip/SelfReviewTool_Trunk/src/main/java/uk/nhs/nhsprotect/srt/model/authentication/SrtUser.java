/**
 * 
 */
package uk.nhs.nhsprotect.srt.model.authentication;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import uk.nhs.nhsprotect.srt.model.Person;

/**
 * @author ntones
 */
public class SrtUser implements Serializable, UserDetails {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String username;
    private String password;
    private boolean accountNonExpired;
    private boolean accountNonLocked;
    private boolean credentialsNonExpired;
    private boolean enabled;
    private List<GrantedAuthority> grantedAuthorities;
    private User user;

    public SrtUser() {
    }

    /**
     * @param username
     * @param password
     * @param accountNonExpired
     * @param accountNonLocked
     * @param credentialsNonExpired
     * @param enabled
     * @param grantedAuthorities
     * @param user
     */
    public SrtUser(String username, String password, boolean accountNonExpired, boolean accountNonLocked,
            boolean credentialsNonExpired, boolean enabled, List<GrantedAuthority> grantedAuthorities, User user) {
        this.username = username;
        this.password = password;
        this.accountNonExpired = accountNonExpired;
        this.accountNonLocked = accountNonLocked;
        this.credentialsNonExpired = credentialsNonExpired;
        this.enabled = enabled;
        this.grantedAuthorities = grantedAuthorities;
        this.user = user;
    }

    /*
     * (non-Javadoc)
     * @see
     * org.springframework.security.core.userdetails.UserDetails#getAuthorities
     * ()
     */
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.grantedAuthorities;
    }

    /*
     * (non-Javadoc)
     * @see
     * org.springframework.security.core.userdetails.UserDetails#getPassword()
     */
    public String getPassword() {
        return this.password;
    }

    /*
     * (non-Javadoc)
     * @see
     * org.springframework.security.core.userdetails.UserDetails#getUsername()
     */
    public String getUsername() {
        return this.username;
    }

    /*
     * (non-Javadoc)
     * @see org.springframework.security.core.userdetails.UserDetails#
     * isAccountNonExpired ()
     */
    public boolean isAccountNonExpired() {
        return this.accountNonExpired;
    }

    /*
     * (non-Javadoc)
     * @see org.springframework.security.core.userdetails.UserDetails#
     * isAccountNonLocked ()
     */
    public boolean isAccountNonLocked() {
        return this.accountNonLocked;
    }

    /*
     * (non-Javadoc)
     * @see org.springframework.security.core.userdetails.UserDetails#
     * isCredentialsNonExpired()
     */
    public boolean isCredentialsNonExpired() {
        return this.credentialsNonExpired;
    }

    /*
     * (non-Javadoc)
     * @see
     * org.springframework.security.core.userdetails.UserDetails#isEnabled()
     */
    public boolean isEnabled() {
        return this.enabled;
    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    public String getFullname() {
        String fullname = "";

        Person person = user.getPerson();
        if (person != null) {
            fullname = person.getFullname();
        }
        return fullname;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((username == null) ? 0 : username.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SrtUser other = (SrtUser) obj;
        if (username == null) {
            if (other.username != null) {
                return false;
            }
        } else if (!username.equals(other.username)) {
            return false;
        }
        return true;
    }

}
