/**
 * 
 */
package uk.nhs.nhsprotect.srt.service;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTStatus;

/**
 * @author bvaidya
 */

public interface SRTStatusService {

    /**
     * Service method to update the status of SRT process
     * @param srtStatus
     * @throws SrtException
     */
    void saveSRTStatus(SRTStatus srtStatus) throws SrtException;

    /**
     * Service method to get the status of SRT process
     * @param orgCode
     * @param srtType
     * @param year
     * @return
     * @throws SrtException
     */
    SRTStatus getSRTStatusByOrgCodeAndType(String orgCode, String srtType, String year) throws SrtException;

}
