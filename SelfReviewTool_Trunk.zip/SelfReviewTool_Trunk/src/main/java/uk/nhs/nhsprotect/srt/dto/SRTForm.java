package uk.nhs.nhsprotect.srt.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.Arrays;

import uk.nhs.nhsprotect.srt.util.SRTUtil;

public class SRTForm implements Serializable {

	/**
	 * Default Serial Version.
	 */
	private static final long serialVersionUID = 1L;

	private String strgSecScore;

	private String INISecScore;

	private String PNDSecScore;

	private String HTASecScore;

	private String totalScore;

	private long statusId;

	private boolean submitted;

	private List<TextQuestion> generalQuestions = new ArrayList<TextQuestion>();

	private List<ChoiceQuestion> strgSecQuestions = new ArrayList<ChoiceQuestion>();

	private List<ChoiceQuestion> INISecQuestions = new ArrayList<ChoiceQuestion>();

	private List<ChoiceQuestion> PNDSecQuestions = new ArrayList<ChoiceQuestion>();

	private List<ChoiceQuestion> HTASecQuestions = new ArrayList<ChoiceQuestion>();

	private List<ChoiceQuestion> excvSecQuestions = new ArrayList<ChoiceQuestion>();

	private Map<Integer, TextQuestion> generalQuestionsKeyedByOrder = new HashMap<Integer, TextQuestion>();

	private Map<Integer, ChoiceQuestion> strgSecQuestionsKeyedByOrder = new HashMap<Integer, ChoiceQuestion>();

	private Map<Integer, ChoiceQuestion> INISecQuestionsKeyedByOrder = new HashMap<Integer, ChoiceQuestion>();

	private Map<Integer, ChoiceQuestion> PNDSecQuestionsKeyedByOrder = new HashMap<Integer, ChoiceQuestion>();

	private Map<Integer, ChoiceQuestion> HTASecQuestionsKeyedByOrder = new HashMap<Integer, ChoiceQuestion>();

	private boolean archived;

	private SRTStatusTO srtStatus;

	private String currentSection;

	private String regionCode;

	public String getStrgSecScore() {
		return strgSecScore;
	}

	public void setStrgSecScore(String strgSecScore) {
		this.strgSecScore = strgSecScore;
	}

	public String getINISecScore() {
		return INISecScore;
	}

	public void setINISecScore(String INISecScore) {
		this.INISecScore = INISecScore;
	}

	public String getPNDSecScore() {
		return PNDSecScore;
	}

	public void setPNDSecScore(String PNDSecScore) {
		this.PNDSecScore = PNDSecScore;
	}

	public String getHTASecScore() {
		return HTASecScore;
	}

	public void setHTASecScore(String HTASecScore) {
		this.HTASecScore = HTASecScore;
	}

	public String getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(String totalScore) {
		this.totalScore = totalScore;
	}

	public boolean getSubmitted() {
		return submitted;
	}

	public void setSubmitted(boolean submitted) {
		this.submitted = submitted;
	}

	public long getStatusId() {
		return statusId;
	}

	public void setStatusId(long statusId) {
		this.statusId = statusId;
	}

	public List<TextQuestion> getGeneralQuestions() {
		return generalQuestions;
	}

	public void setGeneralQuestions(List<TextQuestion> generalQuestions) {
		this.generalQuestions = generalQuestions;
		// set corresponding Map for section
		if (generalQuestions != null) {
			createOrderMapForGeneralQuestions(generalQuestions,
					generalQuestionsKeyedByOrder);
		}
	}

	public List<ChoiceQuestion> getStrgSecQuestions() {
		return strgSecQuestions;
	}

	public void setStrgSecQuestions(List<ChoiceQuestion> strgSecQuestions) {
		this.strgSecQuestions = strgSecQuestions;

		// set corresponding Map for section
		if (strgSecQuestions != null) {
			createOrderMapForSectionQuestions(strgSecQuestions,
					strgSecQuestionsKeyedByOrder);
		}

	}

	public List<ChoiceQuestion> getINISecQuestions() {
		return INISecQuestions;
	}

	public void setINISecQuestions(List<ChoiceQuestion> INISecQuestions) {
		this.INISecQuestions = INISecQuestions;

		// set corresponding Map for section
		if (INISecQuestions != null) {
			createOrderMapForSectionQuestions(INISecQuestions,
					INISecQuestionsKeyedByOrder);
		}
	}

	public List<ChoiceQuestion> getPNDSecQuestions() {
		return PNDSecQuestions;
	}

	public void setPNDSecQuestions(List<ChoiceQuestion> PNDSecQuestions) {
		this.PNDSecQuestions = PNDSecQuestions;
		// set corresponding Map for section
		if (PNDSecQuestions != null) {
			createOrderMapForSectionQuestions(PNDSecQuestions,
					PNDSecQuestionsKeyedByOrder);
		}
	}

	public List<ChoiceQuestion> getHTASecQuestions() {
		return HTASecQuestions;
	}

	public void setHTASecQuestions(List<ChoiceQuestion> HTASecQuestions) {
		this.HTASecQuestions = HTASecQuestions;
		// set corresponding Map for section
		if (HTASecQuestions != null) {
			createOrderMapForSectionQuestions(HTASecQuestions,
					HTASecQuestionsKeyedByOrder);
		}
	}

	public List<ChoiceQuestion> getExcvSecQuestions() {
		return excvSecQuestions;
	}

	public void setExcvSecQuestions(List<ChoiceQuestion> excvSecQuestions) {
		this.excvSecQuestions = excvSecQuestions;
	}

	public boolean isArchived() {
		return archived;
	}

	public void setArchived(boolean archived) {
		this.archived = archived;
	}

	public SRTStatusTO getSrtStatus() {
		return srtStatus;
	}

	public void setSrtStatus(SRTStatusTO srtStatus) {
		this.srtStatus = srtStatus;
	}

	/**
	 * @return the strgSecQuestionsKeyedByOrder
	 */
	public Map<Integer, ChoiceQuestion> getStrgSecQuestionsKeyedByOrder() {
		if (strgSecQuestionsKeyedByOrder.isEmpty()) {
			if (strgSecQuestions != null) {
				createOrderMapForSectionQuestions(strgSecQuestions,
						strgSecQuestionsKeyedByOrder);
			}
		}
		return strgSecQuestionsKeyedByOrder;
	}

	/**
	 * @param strgSecQuestionsKeyedByOrder
	 *            the strgSecQuestionsKeyedByOrder to set
	 */
	public void setStrgSecQuestionsKeyedByOrder(
			Map<Integer, ChoiceQuestion> strgSecQuestionsKeyedByOrder) {

		this.strgSecQuestionsKeyedByOrder = strgSecQuestionsKeyedByOrder;
	}

	/**
	 * @return the iNISecQuestionsKeyedByOrder
	 */
	public Map<Integer, ChoiceQuestion> getINISecQuestionsKeyedByOrder() {
		if (INISecQuestionsKeyedByOrder.isEmpty()) {
			if (INISecQuestions != null) {
				createOrderMapForSectionQuestions(INISecQuestions,
						INISecQuestionsKeyedByOrder);
			}
		}
		return INISecQuestionsKeyedByOrder;
	}

	/**
	 * @param iNISecQuestionsKeyedByOrder
	 *            the iNISecQuestionsKeyedByOrder to set
	 */
	public void setINISecQuestionsKeyedByOrder(
			Map<Integer, ChoiceQuestion> iNISecQuestionsKeyedByOrder) {
		INISecQuestionsKeyedByOrder = iNISecQuestionsKeyedByOrder;
	}

	/**
	 * @return the pNDSecQuestionsKeyedByOrder
	 */
	public Map<Integer, ChoiceQuestion> getPNDSecQuestionsKeyedByOrder() {
		if (PNDSecQuestionsKeyedByOrder.isEmpty()) {
			if (PNDSecQuestions != null) {
				createOrderMapForSectionQuestions(PNDSecQuestions,
						PNDSecQuestionsKeyedByOrder);
			}
		}
		return PNDSecQuestionsKeyedByOrder;
	}

	/**
	 * @param pNDSecQuestionsKeyedByOrder
	 *            the pNDSecQuestionsKeyedByOrder to set
	 */
	public void setPNDSecQuestionsKeyedByOrder(
			Map<Integer, ChoiceQuestion> pNDSecQuestionsKeyedByOrder) {
		PNDSecQuestionsKeyedByOrder = pNDSecQuestionsKeyedByOrder;
	}

	/**
	 * @return the hTASecQuestionsKeyedByOrder
	 */
	public Map<Integer, ChoiceQuestion> getHTASecQuestionsKeyedByOrder() {
		if (HTASecQuestionsKeyedByOrder.isEmpty()) {
			if (HTASecQuestions != null) {
				createOrderMapForSectionQuestions(HTASecQuestions,
						HTASecQuestionsKeyedByOrder);
			}
		}
		return HTASecQuestionsKeyedByOrder;
	}

	/**
	 * @param hTASecQuestionsKeyedByOrder
	 *            the hTASecQuestionsKeyedByOrder to set
	 */
	public void setHTASecQuestionsKeyedByOrder(
			Map<Integer, ChoiceQuestion> hTASecQuestionsKeyedByOrder) {
		HTASecQuestionsKeyedByOrder = hTASecQuestionsKeyedByOrder;
	}

	/**
	 * Method to populate corresponding map of question for a section keyed by
	 * their order.
	 * 
	 * @param choiceQuestions
	 *            for a section
	 * @param map
	 *            to populate
	 */
	private void createOrderMapForSectionQuestions(
			List<ChoiceQuestion> choiceQuestions,
			Map<Integer, ChoiceQuestion> map) {

		for (ChoiceQuestion question : choiceQuestions) {
			map.put(Integer.valueOf(question.getQuestionOrderNo()), question);
		}

	}

	/**
	 * Method to populate corresponding map of question for the general section
	 * keyed by their order.
	 * 
	 * @param textQuestions
	 *            for general section
	 * @param map
	 *            to populate
	 */
	private void createOrderMapForGeneralQuestions(
			List<TextQuestion> textQuestions, Map<Integer, TextQuestion> map) {

		for (TextQuestion question : textQuestions) {
			map.put(Integer.valueOf(question.getQuestionOrderNo()), question);
		}

	}

	/**
	 * @return the generalQuestionsKeyedByOrder
	 */
	public Map<Integer, TextQuestion> getGeneralQuestionsKeyedByOrder() {
		if (generalQuestionsKeyedByOrder.isEmpty()) {
			if (generalQuestions != null) {
				createOrderMapForGeneralQuestions(generalQuestions,
						generalQuestionsKeyedByOrder);
			}
		}
		return generalQuestionsKeyedByOrder;
	}

	/**
	 * @param generalQuestionsKeyedByOrder
	 *            the generalQuestionsKeyedByOrder to set
	 */
	public void setGeneralQuestionsKeyedByOrder(
			Map<Integer, TextQuestion> generalQuestionsKeyedByOrder) {
		this.generalQuestionsKeyedByOrder = generalQuestionsKeyedByOrder;
	}

	/**
	 * @return the currentSection
	 */
	public String getCurrentSection() {
		return currentSection;
	}

	/**
	 * @param currentSection
	 *            the currentSection to set
	 */
	public void setCurrentSection(String currentSection) {
		this.currentSection = currentSection;
	}

	/**
	 * @return the regionCode
	 */
	public String getRegionCode() {
		return regionCode;
	}

	/**
	 * @param regionCode
	 *            the regionCode to set
	 */
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	/**
	 * Indicates if the current organisation belongs to the Welsh Region.
	 * 
	 * @return
	 */
	public boolean isWelshRegion() {
		return SRTUtil.WELSH_REGION_CODE.equals(this.regionCode);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SRTForm [strgSecScore=" + strgSecScore + ", INISecScore="
				+ INISecScore + ", PNDSecScore=" + PNDSecScore
				+ ", HTASecScore=" + HTASecScore + ", totalScore=" + totalScore
				+ ", statusId=" + statusId + ", submitted=" + submitted
				+ ", generalQuestions="
				+ Arrays.toString(generalQuestions.toArray())
				+ ", strgSecQuestions="
				+ Arrays.toString(strgSecQuestions.toArray())
				+ ", INISecQuestions="
				+ Arrays.toString(INISecQuestions.toArray())
				+ ", PNDSecQuestions="
				+ Arrays.toString(PNDSecQuestions.toArray())
				+ ", HTASecQuestions="
				+ Arrays.toString(HTASecQuestions.toArray())
				+ ", excvSecQuestions="
				+ Arrays.toString(excvSecQuestions.toArray())
				+ ", generalQuestionsKeyedByOrder="
				+ generalQuestionsKeyedByOrder
				+ ", strgSecQuestionsKeyedByOrder="
				+ strgSecQuestionsKeyedByOrder
				+ ", INISecQuestionsKeyedByOrder="
				+ INISecQuestionsKeyedByOrder
				+ ", PNDSecQuestionsKeyedByOrder="
				+ PNDSecQuestionsKeyedByOrder
				+ ", HTASecQuestionsKeyedByOrder="
				+ HTASecQuestionsKeyedByOrder + ", archived=" + archived
				+ ", srtStatus=" + srtStatus + ", currentSection="
				+ currentSection + ", regionCode=" + regionCode + "]";
	}

}
