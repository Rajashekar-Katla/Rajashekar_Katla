/**
 * 
 */
package uk.nhs.nhsprotect.srt.service;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.AnnualBudget;

/**
 * @author bvaidya
 */
public interface AnnualBudgetService {
    /**
     * Service method to retrieve the list of annual budget options
     * @param year the year to retrieve options for
     * @param srtType the SRT type to retrieve options for
     * @return List<AnnualBudget> budget options for year
     * @throws SrtException
     */
    List<AnnualBudget> getListOfBudgetOptions(String year, String srtType) throws SrtException;

}
