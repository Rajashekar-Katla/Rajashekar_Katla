package uk.nhs.nhsprotect.srt.enums;

public enum SectionNameMap {
	GENERAL(1), STRATEGIC_GOVERNANCE(2), INFORM_AND_INVOLVE(3), PREVENT_AND_DETER(
			4), HOLD_TO_ACCOUNT(5), EXECUTIVE_AUTHORISATION(6);

	int value;

	private SectionNameMap(int value) {
		this.value = value;
	}

	public int getSectionValue() {
		return value;
	}
}
