/**
 * 
 */
package uk.nhs.nhsprotect.srt.hibernate.enums;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;

import uk.nhs.nhsprotect.srt.util.SRTUtil.ORG_TYPE;

/**
 * User Type for ORG_TYPE enum.
 * @author ntones
 */
public class OrgTypeUserType extends PersistentEnumUserType<ORG_TYPE> {

    @Override
    public Class<ORG_TYPE> returnedClass() {
        return ORG_TYPE.class;
    }

    @Override
    public Object nullSafeGet(ResultSet rs, String[] names, SharedSessionContractImplementor implementor, Object owner)
            throws HibernateException, SQLException {
        int id = rs.getInt(names[0]);
        if (rs.wasNull()) {
            return null;
        }
        for (PersistentEnum value : returnedClass().getEnumConstants()) {
            if (id == value.getId()) {
                return value;
            }
        }
        throw new IllegalStateException("Unknown " + returnedClass().getSimpleName() + " id");
    }

    @Override
    public void nullSafeSet(PreparedStatement st, Object value, int index, SharedSessionContractImplementor implementor)
            throws HibernateException, SQLException {
        if (value == null) {
            st.setNull(index, Types.INTEGER);
        } else {
            st.setInt(index, ((PersistentEnum) value).getId());
        }

    }

}
