package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.ScoreThresholdDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.ScoreThreshold;

@Repository(value = "scoreThresholdDao")
public class ScoreThresholdDaoImpl extends SRTHibernateDaoSupportImpl implements
		ScoreThresholdDao {

	@Override
	public List<ScoreThreshold> getScoreThresholdData() throws SrtException {
		final Query<ScoreThreshold> query = getCurrentSession()
				.createQuery("from ScoreThreshold s order by s.id asc",
						ScoreThreshold.class);
		final List<ScoreThreshold> queryResult = query.getResultList();
		return queryResult;
	}
}
