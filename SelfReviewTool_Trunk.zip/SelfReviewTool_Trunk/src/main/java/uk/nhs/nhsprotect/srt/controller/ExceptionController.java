/**
 * 
 */
package uk.nhs.nhsprotect.srt.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import net.bull.javamelody.MonitoredWithSpring;

/**
 * Controller to handle exceptions.
 * 
 * @author ntones
 */
@Controller
@MonitoredWithSpring
public class ExceptionController {

	/**
	 * Class logger instance.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionController.class);

	@RequestMapping(value = "/errors", method = RequestMethod.GET)
	public ModelAndView renderErrorPage(HttpServletRequest httpRequest, ModelMap modelMap) {

		String errorMsg = "";
		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
		int httpErrorCode = getErrorCode(httpRequest);
		switch (httpErrorCode) {
		case 400: {
			errorMsg = "Http Error Code: 400. Bad Request";
			break;
		}
		case 401: {
			errorMsg = "Http Error Code: 401. Unauthorized";
			break;
		}
		case 404: {
			errorMsg = "Http Error Code: 404. Resource not found";
			status = HttpStatus.NOT_FOUND;
			break;
		}
		case 500: {
			errorMsg = "Http Error Code: 500. Internal Server Error";
			break;
		}
		default: {
			errorMsg = "Http Error Code: 500. Internal Server Error";
			break;
		}
		}
		Throwable throwable = (Throwable) httpRequest.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
		LOGGER.error(errorMsg, throwable);
		modelMap.addAttribute("errorMsg", errorMsg);
		return new ModelAndView("exception-caught", modelMap, status);
	}

	private int getErrorCode(HttpServletRequest httpRequest) {
		return (Integer) httpRequest.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
	}

}
