/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author bvaidya
 */
@Entity
@Table(name = "ANNUAL_BUDGET_TBL")
public class AnnualBudget extends DisplayOrder implements Serializable{

    /**
     * Default Serial Version.
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "BUDGET_ID")
    private int budgetId;
    @Column(name = "BUDGET_VAL")
    private String budgetVal;
    @Column(name = "CREATED_DATE")
    private Date createdDate;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "YEAR")
    private String year;
    @Column(name = "SRT_TYPE")
    private String srtType;

    /**
     * @return the budgetId
     */
    public int getBudgetId() {
        return budgetId;
    }

    /**
     * @param budgetId the budgetId to set
     */
    public void setBudgetId(int budgetId) {
        this.budgetId = budgetId;
    }

    /**
     * @return the budgetVal
     */
    public String getBudgetVal() {
        return budgetVal;
    }

    /**
     * @param budgetVal the budgetVal to set
     */
    public void setBudgetVal(String budgetVal) {
        this.budgetVal = budgetVal;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the year
     */
    public String getYear() {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(String year) {
        this.year = year;
    }

    /**
     * @return the srtType
     */
    public String getSrtType() {
        return srtType;
    }

    /**
     * @param srtType the srtType to set
     */
    public void setSrtType(String srtType) {
        this.srtType = srtType;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((budgetVal == null) ? 0 : budgetVal.hashCode());
        result = prime * result + ((srtType == null) ? 0 : srtType.hashCode());
        result = prime * result + ((year == null) ? 0 : year.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        AnnualBudget other = (AnnualBudget) obj;
        if (budgetVal == null) {
            if (other.budgetVal != null) {
                return false;
            }
        } else if (!budgetVal.equals(other.budgetVal)) {
            return false;
        }
        if (srtType == null) {
            if (other.srtType != null) {
                return false;
            }
        } else if (!srtType.equals(other.srtType)) {
            return false;
        }
        if (year == null) {
            if (other.year != null) {
                return false;
            }
        } else if (!year.equals(other.year)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "AnnualBudget [budgetId=" + budgetId + ", budgetVal=" + budgetVal + ", createdDate=" + createdDate
                + ", createdBy=" + createdBy + ", status=" + status + ", year=" + year + ", srtType=" + srtType + "]";
    }

}
