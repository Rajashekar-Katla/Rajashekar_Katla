/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.AnnualBudgetDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.AnnualBudget;
import uk.nhs.nhsprotect.srt.service.AnnualBudgetService;

/**
 * @author bvaidya
 */
@Service("annualBudgetService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class AnnualBudgetServiceImpl implements AnnualBudgetService {

    @Autowired
    AnnualBudgetDao annualBudgetDao;

    /**
     * @param annualBudgetDao the annualBudgetDao to set
     */
    public void setAnnualBudgetDao(AnnualBudgetDao annualBudgetDao) {
        this.annualBudgetDao = annualBudgetDao;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.service.AnnualBudgetService#getListOfBudgetOptions(
     * java.lang.String, java.lang.String)
     */
    @Cacheable(cacheNames = {
            "budgets"
    }, key = "{#year, #srtType}")
    public List<AnnualBudget> getListOfBudgetOptions(String year, String srtType) throws SrtException {

        return annualBudgetDao.getListOfBudgetOptions(year, srtType);
    }

}
