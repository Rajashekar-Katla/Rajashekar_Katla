/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.OrganisationDAO;
import uk.nhs.nhsprotect.srt.model.Organisation;
import uk.nhs.nhsprotect.srt.service.OrganisationService;

/**
 * @author ntones
 */
@MonitoredWithSpring
@Transactional(readOnly = true)
@Service
public class OrganisationServiceImpl implements OrganisationService {

	@Autowired
	private OrganisationDAO organisationDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * uk.nhs.nhsprotect.srt.service.OrganisationService#findOrganisationByCode(
	 * java.lang.String)
	 */
	@Override
	@Cacheable(cacheNames = "organisations", key = "{#orgCode}")
	public Organisation findOrganisationByCode(final String orgCode) {
		return organisationDao.findByOrgCode(orgCode);
	}

}
