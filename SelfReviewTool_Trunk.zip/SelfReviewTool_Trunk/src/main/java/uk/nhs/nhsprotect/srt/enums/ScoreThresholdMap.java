package uk.nhs.nhsprotect.srt.enums;

import java.util.HashMap;
import java.util.Map;

public enum ScoreThresholdMap {
	MAP;

	private ScoreThresholdMap() {
	}

	final Map<String, Float> map = new HashMap<String, Float>();

	public Map<String, Float> getScoreThresholdMap() {
		return map;
	}
}
