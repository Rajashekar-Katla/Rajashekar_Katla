/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.SRTYearRangeDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTYearRange;
import uk.nhs.nhsprotect.srt.service.SRTYearRangeService;

/**
 * @author bvaidya
 */
@Service("srtYearRangeService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class SRTYearRangeServiceImpl implements SRTYearRangeService {

    @Autowired
    private SRTYearRangeDao srtYearRangeDao;

    /*
     * Service method to get the object for given year and srt type.
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.service.SRTYearRangeService#getYearRange(java.lang
     * .String, java.lang.String)
     */
    @Cacheable(cacheNames = "yearRange", key = "{#year, #srtType}")
    public SRTYearRange getYearRange(String year, String srtType) throws SrtException {
        return srtYearRangeDao.getYearRange(year, srtType);
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.service.SRTYearRangeService#getDistinctListOfYears
     * (java.lang.String)
     */
    @Cacheable(cacheNames = "yearRanges", key = "{#srtType}")
    public List<String> getDistinctListOfYears(String srtType) throws SrtException {
        return srtYearRangeDao.getDistinctListOfYears(srtType);
    }

}
