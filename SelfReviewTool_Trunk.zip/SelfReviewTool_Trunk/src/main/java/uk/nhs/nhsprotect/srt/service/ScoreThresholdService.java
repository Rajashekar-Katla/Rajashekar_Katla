package uk.nhs.nhsprotect.srt.service;

import java.util.Map;

import uk.nhs.nhsprotect.srt.exception.SrtException;

@FunctionalInterface
public interface ScoreThresholdService {

	public void getScoreThresholdData(Map<String, Float> scoreThresholdMap)
			throws SrtException;
}
