/**
 * 
 */
package uk.nhs.nhsprotect.srt.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import net.bull.javamelody.MonitoredWithSpring;

/**
 * Simple controller for favicon requests.
 * 
 * @author ntones
 *
 */
@Controller
@MonitoredWithSpring
public class FaviconController {

	@RequestMapping("favicon.ico")
	String favicon() {
		return "forward:/resources/images/favicon.ico";
	}

}
