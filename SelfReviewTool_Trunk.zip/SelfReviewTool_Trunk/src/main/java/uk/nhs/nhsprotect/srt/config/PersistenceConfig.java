package uk.nhs.nhsprotect.srt.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.HibernateExceptionTranslator;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;

/**
 * Class containing all JPA specific configuration for application.
 * 
 * @author ntones
 */
@Configuration
@EnableTransactionManagement
class PersistenceConfig implements TransactionManagementConfigurer {

	/**
	 * The current application environment.
	 */
	@Autowired
	private Environment env;

	/**
	 * DataSource reference.
	 */
	@Autowired
	private DataSource dataSource;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.transaction.annotation.
	 * TransactionManagementConfigurer#annotationDrivenTransactionManager()
	 */
	@Bean(name = "transactionManager")
	@Autowired
	@Override
	public PlatformTransactionManager annotationDrivenTransactionManager() {
		SessionFactory sessionFactory = this.sessionFactory().getObject();
		return new HibernateTransactionManager(sessionFactory);

	}

	/**
	 * Method to create a LocalContainerEntityManagerFactoryBean.
	 * 
	 * @return LocalContainerEntityManagerFactoryBean configured
	 */
	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		final LocalSessionFactoryBean entityManagerFactoryBean = new LocalSessionFactoryBean();
		entityManagerFactoryBean.setDataSource(dataSource);
		entityManagerFactoryBean.setPackagesToScan("uk.nhs.nhsprotect.srt.model");

		final Properties hibernateProperties = new Properties();
		hibernateProperties.put(org.hibernate.cfg.Environment.DIALECT,
				this.env.getProperty(org.hibernate.cfg.Environment.DIALECT));
		hibernateProperties.put(org.hibernate.cfg.Environment.HBM2DDL_AUTO,
				this.env.getProperty(org.hibernate.cfg.Environment.HBM2DDL_AUTO));
		hibernateProperties.put(org.hibernate.cfg.Environment.SHOW_SQL,
				this.env.getProperty(org.hibernate.cfg.Environment.SHOW_SQL));
		hibernateProperties.put(org.hibernate.cfg.Environment.FORMAT_SQL,
				this.env.getProperty(org.hibernate.cfg.Environment.FORMAT_SQL));
		entityManagerFactoryBean.setHibernateProperties(hibernateProperties);
		hibernateProperties.put(org.hibernate.cfg.Environment.STATEMENT_BATCH_SIZE, 10);

		return entityManagerFactoryBean;
	}

	@Bean
	public HibernateExceptionTranslator hibernateExceptionTranslator() {
		return new HibernateExceptionTranslator();
	}

}
