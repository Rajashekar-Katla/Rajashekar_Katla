/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.SRTHibernateDaoSupport;

/**
 * @author bvaidya
 */
@Repository
@MonitoredWithSpring
public class SRTHibernateDaoSupportImpl implements SRTHibernateDaoSupport {

  @Autowired
  private SessionFactory sessionFactory;

  /*
   * Retrieves session object from session factory (non-Javadoc)
   * @see uk.nhs.nhsprotect.srt.dao.SRTHibernateDaoSupport#getCurrentSession()
   */
  public Session getCurrentSession() {

    return sessionFactory.getCurrentSession();

  }

}
