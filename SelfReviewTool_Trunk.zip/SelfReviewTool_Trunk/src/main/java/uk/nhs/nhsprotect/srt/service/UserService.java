package uk.nhs.nhsprotect.srt.service;

import org.springframework.security.core.userdetails.UsernameNotFoundException;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.model.authentication.User;

public interface UserService {

    Person getUserDetails(String staffId) throws SrtException;

    /**
     * Find User by staffId.
     * @param userName to search for
     * @return User matching user
     */
    User findByUserName(String userName) throws UsernameNotFoundException, SrtException;

    /**
     * Shared Access login and password only...
     * @param loginName
     * @return
     * @throws UsernameNotFoundException
     * @throws SrtException
     */
    String getSharedPassword(String loginName) throws UsernameNotFoundException, SrtException;

}
