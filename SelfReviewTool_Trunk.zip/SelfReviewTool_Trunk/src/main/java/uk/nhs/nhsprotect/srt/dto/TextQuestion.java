package uk.nhs.nhsprotect.srt.dto;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

public class TextQuestion implements Serializable {

	/**
	 * Default serial version.
	 */
	private static final long serialVersionUID = 1L;

	private boolean disabled = false;
	private String questionText;
	private String questionValue;
	private long questionId;
	private long resultId;
	private List<String> options = Collections.emptyList();
	private String validationType;
	private int questionOrderNo;
	private String helptext;
	private String elementName;

	public String getQuestionText() {
		return questionText;
	}

	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	public String getQuestionValue() {
		return questionValue;
	}

	public void setQuestionValue(String questionValue) {
		this.questionValue = questionValue;
	}

	public long getQuestionId() {
		return questionId;
	}

	public void setQuestionId(long questionId) {
		this.questionId = questionId;
	}

	public List<String> getOptions() {
		return options;
	}

	public void setOptions(List<String> options) {
		this.options = options;
	}

	public boolean getDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public long getResultId() {
		return resultId;
	}

	public void setResultId(long resultId) {
		this.resultId = resultId;
	}

	public String getValidationType() {
		return validationType;
	}

	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}

	/**
	 * @return the questionOrderNo
	 */
	public int getQuestionOrderNo() {
		return questionOrderNo;
	}

	/**
	 * @param questionOrderNo
	 *            the questionOrderNo to set
	 */
	public void setQuestionOrderNo(int questionOrderNo) {
		this.questionOrderNo = questionOrderNo;
	}

	/**
	 * @return the helptext
	 */
	public String getHelptext() {
		return helptext;
	}

	/**
	 * @param helptext
	 *            the helptext to set
	 */
	public void setHelptext(String helptext) {
		this.helptext = helptext;
	}

	/**
	 * @return the elementName
	 */
	public String getElementName() {
		return elementName;
	}

	/**
	 * @param elementName
	 *            the elementName to set
	 */
	public void setElementName(String elementName) {
		this.elementName = elementName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TextQuestion [disabled=" + disabled + ", questionText="
				+ questionText + ", questionValue=" + questionValue
				+ ", questionId=" + questionId + ", resultId=" + resultId
				+ ", options=" + options + ", validationType=" + validationType
				+ ", questionOrderNo=" + questionOrderNo + ", helptext="
				+ helptext + ", elementName=" + elementName + "]";
	}

}
