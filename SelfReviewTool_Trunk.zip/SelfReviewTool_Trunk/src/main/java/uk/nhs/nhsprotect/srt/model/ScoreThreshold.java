package uk.nhs.nhsprotect.srt.model;

import static org.apache.commons.lang.builder.ToStringBuilder.reflectionToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SCORE_THRESHOLD_TBL")
public class ScoreThreshold {

	@Id
	@Column(name = "ID")
	private Long id;

	@Column(name = "YEAR")
	private String year;

	@Column(name = "THRESHOLD_TYPE")
	private String thresholdType;

	@Column(name = "THRESHOLD_VALUE")
	private float thresholdValue;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}

	/**
	 * @param year
	 *            the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * @return the thresholdType
	 */
	public String getThresholdType() {
		return thresholdType;
	}

	/**
	 * @param thresholdType
	 *            the thresholdType to set
	 */
	public void setThresholdType(String thresholdType) {
		this.thresholdType = thresholdType;
	}

	/**
	 * @return the thresholdValue
	 */
	public float getThresholdValue() {
		return thresholdValue;
	}

	/**
	 * @param thresholdValue
	 *            the thresholdValue to set
	 */
	public void setThresholdValue(float thresholdValue) {
		this.thresholdValue = thresholdValue;
	}

	@Override
	public String toString() {
		return reflectionToString(this);
	}

}
