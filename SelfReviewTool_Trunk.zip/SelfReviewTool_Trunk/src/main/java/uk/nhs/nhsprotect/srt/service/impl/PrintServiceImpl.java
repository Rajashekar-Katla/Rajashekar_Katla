/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.PrintDao;
import uk.nhs.nhsprotect.srt.dto.SRTSummary;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTStatus;
import uk.nhs.nhsprotect.srt.service.PrintService;
import uk.nhs.nhsprotect.srt.service.SRTStatusService;
import uk.nhs.nhsprotect.srt.util.PDFGenerationUtility;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRTExportType;
import uk.nhs.nhsprotect.srt.util.XLSGenerationUtility;

/**
 * @author bvaidya
 */
@Service("printService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class PrintServiceImpl implements PrintService {

  @Autowired
  private PDFGenerationUtility pdfGenerationUtility;

  @Autowired
  private PrintDao printDao;

  @Autowired
  private SRTStatusService srtStatusService;

  @Autowired
  private XLSGenerationUtility xlsGenerationUtility;

  /*
   * (non-Javadoc)
   * @see
   * uk.nhs.nhsprotect.srt.service.PrintService#generateSRTSummary(java.lang
   * .String, java.lang.String, java.lang.String, java.lang.String,
   * uk.nhs.nhsprotect.srt.util.SRTUtil.SRTExportType)
   */
  @Override
  public File generateSRTSummary(String orgCode, String srtType, String year, SRTExportType srtExportType)
      throws SrtException {
    List<SRTSummary> list = printDao.getResults(orgCode, srtType, year);

    SRTStatus srtStatus = srtStatusService.getSRTStatusByOrgCodeAndType(orgCode, srtType, year);
    if (srtExportType.equals(SRTExportType.PDF)) {
      return pdfGenerationUtility.generateSRTProcessSummaryPDF(list, srtStatus);
    } else if (srtExportType.equals(SRTExportType.XLS)) {
      return xlsGenerationUtility.generateSRTProcessSummaryXLS(list, srtStatus);
    }
    throw new SrtException("Unsupported SRT Summary requested");
  }

}
