/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import uk.nhs.nhsprotect.srt.model.Organisation;

/**
 * @author ntones
 */
public interface OrganisationDAO {

  /**
   * Method to retrieve on organisation based on its Organisation Code.
   * @param orgCode the value to lookup
   * @return Organisation entity or null if non found.
   */
  Organisation findByOrgCode(String orgCode);

}
