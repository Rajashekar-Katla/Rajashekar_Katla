/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.QuestionnaireDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Questionnaire;
import uk.nhs.nhsprotect.srt.model.QuestionnaireAndRatingScoreAndResultsModel;
import uk.nhs.nhsprotect.srt.model.SectionScore;
import uk.nhs.nhsprotect.srt.service.QuestionnaireService;

/**
 * @author bvaidya
 */
@Service("questionnaireService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class QuestionnaireServiceImpl implements QuestionnaireService {

	@Autowired
	private QuestionnaireDao questionnaireDao;

	/*
	 * Service method to get the question list for current year (non-Javadoc)
	 * @see uk.nhs.nhsprotect.srt.service.QuestionnaireService#
	 * findQuessionnaireListForCurrentYear(java.lang.String, java.lang.String)
	 */
	@Cacheable(cacheNames = { "currentQuestionnaires" }, key = "{#srtType, #region}")
	public List<Questionnaire> findQuessionnaireListForCurrentYear(
			final String region, final String srtType) throws SrtException {
		// get from cache
		return questionnaireDao.findQuessionnaireListForCurrentYear(region,
				srtType);

	}

	/*
	 * Service method to get the question list for previous years (non-Javadoc)
	 * @see uk.nhs.nhsprotect.srt.service.QuestionnaireService#
	 * findQuessionnaireListForPreviousYears(java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Cacheable(cacheNames = { "previousQuestionnaires" }, key = "{#srtType, #region,#year}")
	public List<Questionnaire> findQuessionnaireListForPreviousYears(
			final String region, final String srtType, final String year)
			throws SrtException {
		return questionnaireDao.findQuessionnaireListForPreviousYears(region,
				srtType, year);
	}

	public List<QuestionnaireAndRatingScoreAndResultsModel> getQuessionnaireAndResultsList(
			final String region, final String srtType, final String year,
			final String orgCode) throws SrtException {
		return questionnaireDao.getQuessionnaireAndResultsList(region, srtType,
				year, orgCode);
	}

	@Override
	public List<SectionScore> getSectionScoreData() throws SrtException {
		return questionnaireDao.getSectionScoreData();
	}

}
