package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.PilotStandardDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.PilotStandard;

@Repository(value = "pilotStandardDao")
public class PilotStandardDaoImpl extends SRTHibernateDaoSupportImpl implements
		PilotStandardDao {

	@Override
	public List<PilotStandard> getPilotStandardData(Map<String, Long> map)
			throws SrtException {
		final Query<PilotStandard> query = getCurrentSession().createQuery(
				"from PilotStandard p order by p.id asc", PilotStandard.class);
		final List<PilotStandard> queryResult = query.getResultList();
		return queryResult;
	}

}
