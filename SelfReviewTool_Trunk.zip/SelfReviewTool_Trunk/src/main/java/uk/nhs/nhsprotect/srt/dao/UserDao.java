/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.model.authentication.User;

/**
 * @author bvaidya
 */
public interface UserDao {

    Person getPersonDetails(String staffId) throws SrtException;

    User findByUserName(String userName) throws SrtException;

    String getSharedPassword(String loginName) throws SrtException;
}
