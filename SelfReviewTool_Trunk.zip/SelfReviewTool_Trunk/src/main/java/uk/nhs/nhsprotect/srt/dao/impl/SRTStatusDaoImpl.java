/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import uk.nhs.nhsprotect.srt.dao.SRTStatusDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTStatus;
import uk.nhs.nhsprotect.srt.util.SRTUtil;

/**
 * @author bvaidya
 */
@Repository("srtStatusDao")
public class SRTStatusDaoImpl extends SRTHibernateDaoSupportImpl implements SRTStatusDao {

    /*
     * Method to update the status of SRT process (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.dao.SRTStatusDao#saveSRTStatus(uk.nhs.nhsprotect
     * .srt.model.SRTStatus)
     */
    public void saveSRTStatus(SRTStatus srtStatus) throws SrtException {
        try {
            getCurrentSession().saveOrUpdate(srtStatus);
        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }
    }

    public SRTStatus checkStatusOfSRTProcess(String orgCode) throws SrtException {

        SRTStatus srtStatus = null;

        try {
            Query query = getCurrentSession().createQuery("from SRTStatus where orgCode = :orgCode")
                    .setParameter("orgCode", orgCode);

            List<SRTStatus> list = query.list();

            if (list != null && !list.isEmpty()) {

                srtStatus = list.get(0);
            }
            if (null == srtStatus) {

                srtStatus = new SRTStatus();

            }
            if (StringUtils.isEmpty(srtStatus.getStatus())) {

                srtStatus.setStatus(SRTUtil.SRTStatus.TODO.toString());
            }

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }

        return srtStatus;
    }

    /**
     * Method to check status of SRT process
     * @param orgCode
     * @param srtType
     * @param year
     * @return
     * @throws SrtException
     */
    public SRTStatus getSRTStatusByOrgCodeAndType(String orgCode, String srtType, String year) throws SrtException {
        SRTStatus srtStatus = null;

        try {

            Query query = getCurrentSession()
                    .createQuery("from SRTStatus where orgCode = :orgCode and "
                            + "srtType = :srtType and year = :year order by submittedDate DESC")
                    .setParameter("orgCode", orgCode).setParameter("srtType", srtType).setParameter("year", year);

            List<SRTStatus> list = query.list();

            if (list != null && !list.isEmpty()) {

                srtStatus = list.get(0);
            }
            if (null == srtStatus) {

                srtStatus = new SRTStatus();
            }
            if (StringUtils.isEmpty(srtStatus.getStatus())) {

                srtStatus.setStatus(SRTUtil.SRTStatus.TODO.toString());
            }

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }

        return srtStatus;
    }

}
