/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.SRTStatusDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTStatus;
import uk.nhs.nhsprotect.srt.service.SRTStatusService;

/**
 * @author bvaidya
 */
@Service("srtStatusService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class SRTStatusServiceImpl implements SRTStatusService {

	@Autowired
	SRTStatusDao srtStatusDao;

	/*
	 * Service method to update the status of SRT process (non-Javadoc)
	 * 
	 * @see uk.nhs.nhsprotect.srt.service.SRTStatusService#saveSRTStatus(uk.nhs.
	 * nhsprotect.srt.model.SRTStatus)
	 */
	@Transactional(readOnly = false)
	@Override
	@Caching(evict = {
			@CacheEvict(cacheNames = "srtForms", key = "{#srtStatus.orgCode,#srtStatus.srtType,#srtStatus.year}"),
			@CacheEvict(cacheNames = "srtSummary", key = "{#srtStatus.orgCode,#srtStatus.srtType,#srtStatus.year}"),
			@CacheEvict(cacheNames = "srtStatus", key = "{#srtStatus.orgCode,#srtStatus.srtType,#srtStatus.year}") })
	public void saveSRTStatus(SRTStatus srtStatus) throws SrtException {

		srtStatusDao.saveSRTStatus(srtStatus);
	}

	/*
	 * Service method to get status of SRT process (non-Javadoc)
	 * 
	 * @see uk.nhs.nhsprotect.srt.service.SRTStatusService#
	 * getSRTStatusByOrgCodeAndType(java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	@Cacheable(cacheNames = "srtStatus", key = "{#orgCode, #srtType, #year}")
	public SRTStatus getSRTStatusByOrgCodeAndType(String orgCode, String srtType, String year) throws SrtException {

		return srtStatusDao.getSRTStatusByOrgCodeAndType(orgCode, srtType, year);
	}

}
