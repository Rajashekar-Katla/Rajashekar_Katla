/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.RegionOrgDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.OrganisationByTypeCCG;
import uk.nhs.nhsprotect.srt.model.OrganisationType;
import uk.nhs.nhsprotect.srt.model.RegionOrgMapping;
import uk.nhs.nhsprotect.srt.model.Regions;

/**
 * @author bvaidya
 */
@Repository("regionOrgDao")
public class RegionOrgDaoImpl extends SRTHibernateDaoSupportImpl implements RegionOrgDao {

    /*
     * Get region code value for given organisation code (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.dao.RegionOrgDao#getRegionCodeAsPerOrganization
     * (java.lang.String)
     */
    @SuppressWarnings("unchecked")
    public RegionOrgMapping getRegionCodeByOrganization(String orgCode) throws SrtException {
        try {
            Query query = getCurrentSession().createQuery("from RegionOrgMapping where orgCode = :orgCode")
                    .setParameter("orgCode", orgCode);

            List<RegionOrgMapping> list = query.list();

            if (null != list && !list.isEmpty()) {

                RegionOrgMapping mapping = list.get(0);
                return mapping;
            }

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }

        return null;
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.dao.RegionOrgDao#getOrganisationTypes(java.lang
     * .String, java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<OrganisationType> getOrganisationTypes(String srtType, String year) throws SrtException {

        String strQuery = "from OrganisationType where status = 'A' and year = :year and srtType = :srtType order by name";

        try {
            Query query = getCurrentSession().createQuery(strQuery);
            query.setString("year", year);
            query.setString("srtType", srtType);
            return query.list();

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }

    }

    /*
     * Get the list of organisation/provider type for organisation type NHSE CCG
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.srt.dao.RegionOrgDao#getProviderTypeListForCCG()
     */
    @SuppressWarnings("unchecked")
    public List<OrganisationByTypeCCG> getProviderTypeListForCCG() throws SrtException {

        String strQuery = "from OrganisationByTypeCCG order by orgName";

        try {
            Query query = getCurrentSession().createQuery(strQuery);

            return query.list();

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }
    }

    /*
     * (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.dao.RegionOrgDao#getRegionList(java.lang.String,
     * java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Regions> getRegionList(String srtType, String year, String regionType) throws SrtException {

        String strQuery = "from Regions where status = 'A' and srtType = :srtType and year = :year and type = :regionType order by regionName";

        try {
            Query query = getCurrentSession().createQuery(strQuery);
            query.setString("year", year);
            query.setString("srtType", srtType);
            query.setString("regionType", regionType);
            return query.list();

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }

    }

}
