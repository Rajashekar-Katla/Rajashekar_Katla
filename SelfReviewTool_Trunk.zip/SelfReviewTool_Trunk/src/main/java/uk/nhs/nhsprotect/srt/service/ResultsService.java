/**
 * 
 */
package uk.nhs.nhsprotect.srt.service;

import java.util.List;

import uk.nhs.nhsprotect.srt.model.Result;

/**
 * @author bvaidya
 */
public interface ResultsService {

  /**
   * Service method to persist single object of type Result.
   * @param result to save
   * @deprecated not used in 5.0.0 to be removed
   */
  void save(Result result);

  /**
   * Service method to persist list of objects of type Result.
   * @param results to save
   */
  void saveAll(List<Result> results);

  /**
   * Service method to get the list of questions with answered comments and
   * ratings.
   * @param orgCode organisation of SRT
   * @param srtType SRT type
   * @param year SRT year
   * @return List<Result> matching criteria
   */
  List<Result> getAnsweredQuestionsList(String orgCode, String srtType, String year);
}
