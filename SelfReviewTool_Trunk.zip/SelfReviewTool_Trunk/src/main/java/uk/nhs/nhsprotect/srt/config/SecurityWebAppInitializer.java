package uk.nhs.nhsprotect.srt.config;

import java.util.EnumSet;

import javax.servlet.DispatcherType;
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;

import org.springframework.orm.hibernate5.support.OpenSessionInViewFilter;
import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
import org.springframework.web.filter.CharacterEncodingFilter;

public class SecurityWebAppInitializer extends AbstractSecurityWebApplicationInitializer {

	@Override
	protected void beforeSpringSecurityFilterChain(ServletContext servletContext) {
		// OSIV needs to be fired BEFORE security FilterChain
		OpenSessionInViewFilter viewFilter = new OpenSessionInViewFilter();
		viewFilter.setSessionFactoryBeanName("sessionFactory");
		FilterRegistration.Dynamic openSessionInViewFilter = servletContext.addFilter("openSessionInViewFilter",
				viewFilter);
		openSessionInViewFilter.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), true, "/*");

		FilterRegistration.Dynamic characterEncodingFilter = servletContext.addFilter("encodingFilter",
				new CharacterEncodingFilter());
		characterEncodingFilter.setInitParameter("encoding", "UTF-8");
		characterEncodingFilter.setInitParameter("forceEncoding", "true");
		characterEncodingFilter.addMappingForUrlPatterns(null, false, "/*");
	}
}
