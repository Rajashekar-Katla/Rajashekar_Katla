
package uk.nhs.nhsprotect.srt.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;

import uk.nhs.nhsprotect.srt.security.ResponsibilityEvaluator;
import uk.nhs.nhsprotect.srt.service.ResponsibilityService;

/**
 * Configuration Class to define the custom PermissionEvaluator used to check
 * that a user is permitted to view a particular organisations SRT.
 * @author ntones
 */
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
@Order(1)
public class MethodSecurityConfig extends GlobalMethodSecurityConfiguration {

    /**
     * Spring provided {@link ResponsibilityService}.
     */
    @Autowired
    private ResponsibilityService responsibilityService;

    /*
     * (non-Javadoc)
     * @see org.springframework.security.config.annotation.method.configuration.
     * GlobalMethodSecurityConfiguration#createExpressionHandler()
     */
    @Override
    protected MethodSecurityExpressionHandler createExpressionHandler() {
        DefaultMethodSecurityExpressionHandler expressionHandler = new DefaultMethodSecurityExpressionHandler();
        expressionHandler.setPermissionEvaluator(new ResponsibilityEvaluator(responsibilityService));
        return expressionHandler;
    }

}
