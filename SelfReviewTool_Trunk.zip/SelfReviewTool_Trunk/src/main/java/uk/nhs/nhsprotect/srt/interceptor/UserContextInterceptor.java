package uk.nhs.nhsprotect.srt.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import uk.nhs.nhsprotect.srt.util.UserContextUtil;

/**
 * Exposes the 'userContext' bean to the view.
 * @author ntones
 */
@Service
public class UserContextInterceptor implements HandlerInterceptor {

    @Autowired
    UserContextUtil userContext;

    public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
            throws Exception {
        // no specific implementation

    }

    public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
            throws Exception {
        // no specific implementation

    }

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object object) throws Exception {

        // get the user context
        request.setAttribute("userContext", userContext);
        return true;
    }
}
