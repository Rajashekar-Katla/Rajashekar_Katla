/**
 * 
 */
package uk.nhs.nhsprotect.srt.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author bvaidya
 */
@Entity
@Table(name = "LATEST_STAFF_RESP_VIEW")
public class Responsibility implements Serializable {

    /**
     * SerialVersion UID.
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "RESP_ID")
    private String respId;

    @Column(name = "STAFF_ID", insertable = false, updatable = false)
    private String staffId;

    @Column(name = "ID")
    private Long personId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ORG_ID")
    private Organisation organisation;

    @Column(name = "ORG_ID", updatable = false, insertable = false, nullable = false)
    private Long organisationId;

    @Column(name = "LEAD")
    private String lead;

    @Column(name = "START_DATE")
    private Date startDate;

    @Column(name = "END_DATE")
    private Date endDate;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "STAFF_ID")
    private Person person;

    /**
     * @return the lead
     */
    public String getLead() {
        return lead;
    }

    /**
     * @param lead the lead to set
     */
    public void setLead(String lead) {
        this.lead = lead;
    }

    /**
     * @return the person
     */

    public Person getPerson() {
        return person;
    }

    /**
     * @param person the person to set
     */
    public void setPerson(Person person) {
        this.person = person;
    }

    /**
     * @return the staffId
     */
    public String getStaffId() {
        return staffId;
    }

    /**
     * @param staffId the staffId to set
     */
    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    /**
     * @return the personId
     */
    public Long getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    /**
     * @return the respId
     */
    public String getRespId() {
        return respId;
    }

    /**
     * @param respId the respId to set
     */
    public void setRespId(String respId) {
        this.respId = respId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * @return the organisation
     */
    public Organisation getOrganisation() {
        return organisation;
    }

    /**
     * @param organisation the organisation to set
     */
    public void setOrganisation(Organisation organisation) {
        this.organisation = organisation;
    }

    /**
     * @return the organisationId
     */
    public Long getOrganisationId() {
        return organisationId;
    }

    /**
     * @param organisationId the organisationId to set
     */
    public void setOrganisationId(Long organisationId) {
        this.organisationId = organisationId;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((respId == null) ? 0 : respId.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Responsibility other = (Responsibility) obj;
        if (respId == null) {
            if (other.respId != null) {
                return false;
            }
        } else if (!respId.equals(other.respId)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Responsibility [respId=" + respId + ", staffId=" + staffId + ", personId=" + personId
                + ", organisationId=" + organisationId + ", lead=" + lead + ", startDate=" + startDate + ", endDate="
                + endDate + ", person=" + person + "]";
    }

    /**
     * Utility method to return the organisation code.
     * @return String orgCode
     */
    @Transient
    public String getOrgCode() {
        return this.getOrganisation().getOrgCode();
    }

    /**
     * Utility method to return the organisation name.
     * @return String orgName
     */
    @Transient
    public String getOrgName() {
        return this.getOrganisation().getName();
    }
}
