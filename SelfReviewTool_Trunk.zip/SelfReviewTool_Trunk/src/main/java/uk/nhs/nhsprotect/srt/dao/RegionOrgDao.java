/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.OrganisationByTypeCCG;
import uk.nhs.nhsprotect.srt.model.OrganisationType;
import uk.nhs.nhsprotect.srt.model.RegionOrgMapping;
import uk.nhs.nhsprotect.srt.model.Regions;

/**
 * @author bvaidya
 */
public interface RegionOrgDao {

    /**
     * Get region code value for given organisation code
     * @param orgCode
     * @return
     * @throws SrtException
     */
    RegionOrgMapping getRegionCodeByOrganization(String orgCode) throws SrtException;

    /**
     * Get the list of regions for the specified srt
     * @param year of srt
     * @param srtType type of srt
     * @param regionType the region type to retrieve
     * @return List<Regions> for srt
     * @throws SrtException on error
     */
    List<Regions> getRegionList(String srtType, String year, String regionType) throws SrtException;

    /**
     * Get the list of organisation/provider type.
     * @param year year of srt
     * @param srtType type of srt
     * @return List<OrganisationTypes> for the specified srt
     * @throws SrtException on error
     */
    List<OrganisationType> getOrganisationTypes(String srtType, String year) throws SrtException;

    /**
     * Get the list of organisation/provider type for organisation type NHSE CCG
     * @return
     * @throws SrtException
     */
    List<OrganisationByTypeCCG> getProviderTypeListForCCG() throws SrtException;

}
