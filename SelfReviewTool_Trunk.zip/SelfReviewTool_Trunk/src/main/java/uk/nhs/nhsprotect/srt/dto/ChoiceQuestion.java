package uk.nhs.nhsprotect.srt.dto;

import java.io.Serializable;
import java.util.Set;

import uk.nhs.nhsprotect.srt.model.RatingScore;

public class ChoiceQuestion implements Serializable {

	/**
	 * Default Serial Version.
	 */
	private static final long serialVersionUID = 1L;

	private long questionId;

	private String questionText;
	// default score for the choice question
	private int questionValue = -99;

	private String comment;

	private int priority;

	private Set<RatingScore> options = null;

	private Long resultId;

	private String helpDocumentURL;

	private int questionOrderNo;

	/**
	 * @return the helpDocumentURL
	 */
	public String getHelpDocumentURL() {
		return helpDocumentURL;
	}

	/**
	 * @param helpDocumentURL
	 *            the helpDocumentURL to set
	 */
	public void setHelpDocumentURL(String helpDocumentURL) {
		this.helpDocumentURL = helpDocumentURL;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public long getQuestionId() {
		return questionId;
	}

	public void setQuestionId(long questionId) {
		this.questionId = questionId;
	}

	public String getQuestionText() {
		return questionText;
	}

	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	public int getQuestionValue() {
		return questionValue;
	}

	public void setQuestionValue(int questionValue) {
		this.questionValue = questionValue;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Set<RatingScore> getOptions() {
		return options;
	}

	public void setOptions(Set<RatingScore> options) {
		this.options = options;
	}

	public Long getResultId() {
		return resultId;
	}

	public void setResultId(Long resultId) {
		this.resultId = resultId;
	}

	/**
	 * @return the questionOrderNo
	 */
	public int getQuestionOrderNo() {
		return questionOrderNo;
	}

	/**
	 * @param questionOrderNo
	 *            the questionOrderNo to set
	 */
	public void setQuestionOrderNo(int questionOrderNo) {
		this.questionOrderNo = questionOrderNo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ChoiceQuestion [questionId=" + questionId + ", questionText=" + questionText + ", questionValue="
				+ questionValue + ", comment=" + comment + ", priority=" + priority + ", options=" + options
				+ ", helpDocumentURL=" + helpDocumentURL + ", questionOrderNo=" + questionOrderNo + "]";
	}

}
