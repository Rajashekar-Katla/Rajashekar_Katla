package uk.nhs.nhsprotect.srt.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.service.PrintService;
import uk.nhs.nhsprotect.srt.util.SRTUtil;
import uk.nhs.nhsprotect.srt.util.SRTUtil.SRTExportType;

@Controller
@SessionAttributes({
    "person"
})
@MonitoredWithSpring
public class DownloadController {

  @Autowired
  private PrintService printService;

  /**
   * Class logger instance.
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(DownloadController.class);

  @RequestMapping(value = "/download", method = RequestMethod.GET)
  @PreAuthorize("hasPermission('lcfs,lsms',#orgCode)")
  public void getFile(@ModelAttribute("person") Person person, @RequestParam("srtType") String srtType,
      @RequestParam("orgCode") String orgCode, @RequestParam(value = "year") String year,
      @RequestParam(value = "type") String type, HttpServletResponse response, ModelMap model) throws SrtException {

    if (type.equals("PDF")) {
      downloadContent(srtType, orgCode, year, response, SRTExportType.PDF);
    } else {
      downloadContent(srtType, orgCode, year, response, SRTExportType.XLS);
    }

  }

  private void downloadContent(String srtType, String orgCode, String year, HttpServletResponse response,
      SRTExportType exportType) throws SrtException {

    File file = null;
    try {
      if (StringUtils.isNotEmpty(orgCode) && StringUtils.isNotEmpty(srtType) && StringUtils.isNotEmpty(year)
          && year.matches(SRTUtil.YEAR_PATTERN)) {
        file = printService.generateSRTSummary(orgCode, srtType, year, exportType);
      } else {
        throw new SrtException("Please provide the OrgCode/Type/Year to generate report");
      }

    } catch (SrtException e) {
      LOGGER.error("ERROR generating summary : " + e.getMessage());
      throw new SrtException(e);
    }

    if (file != null) {
      String contentType = "application/xls";
      if (exportType.equals(SRTExportType.PDF)) {
        contentType = "application/pdf";
      }
      try (InputStream inputStream = new FileInputStream(file);
          ServletOutputStream outputStream = response.getOutputStream();) {
        response.setContentType(contentType);
        response.setContentLengthLong(inputStream.available());
        response.setHeader("Content-disposition", "attachment;filename=\"" + file.getName() + "\"");

        IOUtils.copy(inputStream, outputStream);
        response.flushBuffer();
        IOUtils.closeQuietly(inputStream);
        IOUtils.closeQuietly(outputStream);
      } catch (IOException ex) {
        LOGGER.error("Error writing file to output stream", ex);
        throw new SrtException("IOError writing file to output stream", ex);
      }

    }
  }

}
