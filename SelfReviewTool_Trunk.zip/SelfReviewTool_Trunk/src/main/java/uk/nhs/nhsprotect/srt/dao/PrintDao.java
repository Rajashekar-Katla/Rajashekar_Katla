/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import java.util.List;

import uk.nhs.nhsprotect.srt.dto.SRTSummary;
import uk.nhs.nhsprotect.srt.exception.SrtException;

/**
 * @author bvaidya
 */
public interface PrintDao {

    /**
     * Get all the Results based on Organisations, Type and Year.
     * @param orgCode
     * @param srtType
     * @param year
     * @return List
     * @throws SrtException
     */
    List<SRTSummary> getResults(String orgCode, String srtType, String year) throws SrtException;

}
