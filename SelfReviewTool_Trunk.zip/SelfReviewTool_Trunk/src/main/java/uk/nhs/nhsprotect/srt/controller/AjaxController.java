/**
 * 
 */
package uk.nhs.nhsprotect.srt.controller;

import javax.script.ScriptException;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dto.SRTForm;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.util.SRTCalculationsUtil;

/**
 * Controller class containing methods called via AJAX.
 * 
 * @author ntones
 */
@Controller
@MonitoredWithSpring
public class AjaxController {

	/**
	 * Class logger instance.
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(AjaxController.class);

	/**
	 * Method to determine the rating for a particular SRT section.
	 * 
	 * @param srtForm
	 *            containing selections
	 * @return String score
	 */
	@RequestMapping(value = "calculateSectionScore", method = RequestMethod.POST)
	public @ResponseBody String calculateSectionScore(
			@ModelAttribute("form") SRTForm srtForm) {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("In calculateSectionScore");
		}
		String sectionScore = null;
		try {
			sectionScore = SRTCalculationsUtil.getInstance()
					.calculateSectionScore(srtForm);

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Got sectionScore result = " + sectionScore);
			}

		} catch (Exception exception) {
			System.out.println(ExceptionUtils.getStackTrace(exception));
		}
		return sectionScore;
	}

	/**
	 * Method to determine the overall score of an SRT.
	 * 
	 * @param srtForm
	 *            containing selections
	 * @return String score
	 * @throws SrtException 
	 * @throws ScriptException 
	 */
	@RequestMapping(value = "calculateSRTScore", method = RequestMethod.POST)
	public @ResponseBody String calculateSRTScore(
			@ModelAttribute("form") SRTForm srtForm) throws SrtException, ScriptException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("In calculateSRTScore");
		}
		String srtScore = null;
		srtScore = SRTCalculationsUtil.getInstance().calculateSRTScore(srtForm);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Got srtScore result = " + srtScore);
		}
		return srtScore;

	}
}
