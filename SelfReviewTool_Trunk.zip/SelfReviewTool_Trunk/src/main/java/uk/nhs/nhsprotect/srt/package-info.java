/**
 * Root package.
 * @author ntones
 *
 */
package uk.nhs.nhsprotect.srt;