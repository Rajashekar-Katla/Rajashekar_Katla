/**
 * 
 */
package uk.nhs.nhsprotect.srt.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.ResponsibilityDao;
import uk.nhs.nhsprotect.srt.dto.ResponsibilityDTO;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.service.ResponsibilityService;

/**
 * @author bvaidya
 */
@Service("responsibilityService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class ResponsibilityServiceImpl implements ResponsibilityService {

	@Autowired
	private ResponsibilityDao responsibilityDao;

	/*
	 * Service method to get the responsibility list by staff id (non-Javadoc)
	 * 
	 * @see uk.nhs.nhsprotect.srt.service.ResponsibilityService#findOrganizationList
	 * (java.lang.String)
	 */
	@Cacheable(cacheNames = "responsibilities", key = "{#staffId}")
	public List<ResponsibilityDTO> getResponsibilitiesByStaffId(String staffId) throws SrtException {

		// both fraud and security commissioners now active in SRT
		return responsibilityDao.getResponsibilitiesByStaffId(staffId, true).stream()
				.map(ResponsibilityDTO::fromResponsibity).collect(Collectors.toList());
	}

	@Cacheable(cacheNames = "responsibilities", key = "{#staffId, #orgCode}")
	public List<ResponsibilityDTO> getResponsibilityByPersonAndOrg(String userRef, String orgCode) throws SrtException {

		return responsibilityDao.getResponsibilityByPersonAndOrg(userRef, orgCode).stream()
				.map(ResponsibilityDTO::fromResponsibity).collect(Collectors.toList());
	}

	@Cacheable(cacheNames = "responsibilities", key = "{#orgCode}")
	public List<ResponsibilityDTO> getResponsibilitiesByOrgCode(String orgCode) throws SrtException {

		return responsibilityDao.getResponsibilitiesByOrgCode(orgCode).stream().map(ResponsibilityDTO::fromResponsibity)
				.collect(Collectors.toList());
	}

}
