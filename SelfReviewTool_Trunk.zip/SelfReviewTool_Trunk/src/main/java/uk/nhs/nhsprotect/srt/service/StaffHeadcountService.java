/**
 * 
 */
package uk.nhs.nhsprotect.srt.service;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.StaffHeadcount;

/**
 * @author bvaidya
 */

public interface StaffHeadcountService {

    /**
     * Service method to retrieve the list of staff head count options.
     * @param year the year to retrieve values for
     * @param srtType the srt Type to retrieve values for
     * @return List<StaffHeadcount> for year
     * @throws SrtException
     */
    List<StaffHeadcount> getListOfStaffHeadcountOptions(String year, String srtType) throws SrtException;
}
