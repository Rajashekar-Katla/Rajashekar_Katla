/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTStatus;

/**
 * @author bvaidya
 */
public interface SRTStatusDao {

    /**
     * Method to update the status of SRT process
     * @param srtStatus
     * @throws SrtException
     */
    void saveSRTStatus(SRTStatus srtStatus) throws SrtException;

    @Deprecated
    SRTStatus checkStatusOfSRTProcess(String orgCode) throws SrtException;

    /**
     * Method to check status of SRT process
     * @param orgCode
     * @param srtType
     * @param year
     * @return
     * @throws SrtException
     */
    SRTStatus getSRTStatusByOrgCodeAndType(String orgCode, String srtType, String year) throws SrtException;

}
