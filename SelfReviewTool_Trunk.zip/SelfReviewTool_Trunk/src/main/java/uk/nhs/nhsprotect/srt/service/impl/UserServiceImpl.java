package uk.nhs.nhsprotect.srt.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dao.UserDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.model.authentication.User;
import uk.nhs.nhsprotect.srt.service.UserService;

@Service("userService")
@MonitoredWithSpring
@Transactional(readOnly = true)
public class UserServiceImpl implements UserService {

    /**
     * Class logger instance.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    UserDao userDao;

    @Override
    @Cacheable(cacheNames="person",key="{#staffId}")
    public Person getUserDetails(String staffId) throws SrtException {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("get UserDetails staffId =" + staffId);
        }
        return userDao.getPersonDetails(staffId);
    }

    @Override
    public User findByUserName(String userName) throws UsernameNotFoundException, SrtException {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("find By UserName=" + userName);
        }
        return userDao.findByUserName(userName);
    }

    @Override
    @Cacheable(cacheNames="sharedPassword",key="{#loginName}")
    public String getSharedPassword(String loginName) throws UsernameNotFoundException, SrtException {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("find Shared Access pass=" + loginName);
        }
        return userDao.getSharedPassword(loginName);
    }

}
