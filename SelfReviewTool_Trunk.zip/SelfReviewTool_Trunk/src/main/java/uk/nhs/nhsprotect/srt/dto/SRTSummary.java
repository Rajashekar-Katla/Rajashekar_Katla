/**
 * 
 */
package uk.nhs.nhsprotect.srt.dto;

import java.io.Serializable;

/**
 * @author bvaidya
 */
public class SRTSummary implements Serializable {

    /**
     * Default Version UID.
     */
    private static final long serialVersionUID = 1L;

    private String questionText;
    private String sectionName;
    private String comments;
    private Integer score;
    private String overallScore;

    /**
     * @return the questionText
     */
    public String getQuestionText() {
        return questionText;
    }

    /**
     * @param questionText the questionText to set
     */
    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    /**
     * @return the sectionName
     */
    public String getSectionName() {
        return sectionName;
    }

    /**
     * @param sectionName the sectionName to set
     */
    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    /**
     * @return the comments
     */
    public String getComments() {
        return comments;
    }

    /**
     * @param comments the comments to set
     */
    public void setComments(String comments) {
        this.comments = comments;
    }

    /**
     * @return the score
     */
    public Integer getScore() {
        return score;
    }

    /**
     * @param score the score to set
     */
    public void setScore(Integer score) {
        this.score = score;
    }

    /**
     * @return the overallScore
     */
    public String getOverallScore() {
        return overallScore;
    }

    /**
     * @param overallScore the overallScore to set
     */
    public void setOverallScore(String overallScore) {
        this.overallScore = overallScore;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SRTSummary [questionText=" + questionText + ", sectionName=" + sectionName + ", comments=" + comments
                + ", score=" + score + ", overallScore=" + overallScore + "]";
    }

}
