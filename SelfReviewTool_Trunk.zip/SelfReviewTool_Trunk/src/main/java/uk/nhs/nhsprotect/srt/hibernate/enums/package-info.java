/**
 * Package containing classes associated to custom enumerater types for
 * hibernate.
 * @author ntones
 */
package uk.nhs.nhsprotect.srt.hibernate.enums;