package uk.nhs.nhsprotect.srt.service;

import java.util.Map;

import uk.nhs.nhsprotect.srt.exception.SrtException;

@FunctionalInterface
public interface SectionScoreService {

	public void getSectionScoreData(Map<String, String> sectionScoreMap)
			throws SrtException;
}
