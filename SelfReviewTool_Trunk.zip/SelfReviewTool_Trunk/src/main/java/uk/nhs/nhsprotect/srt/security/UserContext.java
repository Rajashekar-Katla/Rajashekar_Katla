/**
 * 
 */
package uk.nhs.nhsprotect.srt.security;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import uk.nhs.nhsprotect.srt.model.authentication.SrtUser;

/**
 * Accesses the Spring Security Context for the logged in user.
 * @author ntones
 */
public class UserContext implements Serializable {

    /**
     * Serialisation version.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Returns the SrtUser object for the logged in user.
     * @return CpodUser currently logged in
     */
    public static SrtUser getCurrentUser() {
        SrtUser user = null;
        if (null != SecurityContextHolder.getContext().getAuthentication()) {
            user = (SrtUser) (SecurityContextHolder.getContext().getAuthentication().getPrincipal());
        }
        if (user != null) {
            return user;
        } else {
            return null;
        }
    }

    /**
     * Get the current username. Note that it may not correspond to a username
     * that currently exists in your accounts' repository; it could be a spring
     * security 'anonymous user'.
     * @return the current user's username, or null if none.
     */
    public static String getUsername() {
        SrtUser srtUser = getCurrentUser();
        if (srtUser != null) {

            return srtUser.getUsername();
        }
        return "";
    }

    /**
     * @return Locale the current locale
     */
    public static Locale getLocale() {
        return LocaleContextHolder.getLocale();
    }

    /**
     * Retrieve the current UserDetails bound to the current thread by Spring
     * Security, if any.
     * @return UserDetails the user currently in secure context.
     */
    public static SrtUser getUserDetails() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth != null && auth.getPrincipal() instanceof UserDetails) {
            return ((SrtUser) auth.getPrincipal());
        }

        return null;
    }

    /**
     * Return current roles bound to the current thread by Spring Security.
     * @return List<String> roles list
     */
    public static List<String> getRoles() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            List<String> result = new ArrayList<String>();

            for (GrantedAuthority grantedAuthority : auth.getAuthorities()) {
                result.add(grantedAuthority.getAuthority());
            }
            return result;
        }
        return Collections.emptyList();
    }

    /**
     * Return the personId for the currently logged in user.
     * @return Long personId from session user
     */
    public static Long getPersonId() {
        return getCurrentUser().getUser().getPersonId();
    }

    /**
     * Return the userId for the currently logged in user.
     * @return Long userId from session user
     */
    public static Long getUserId() {
        return getCurrentUser().getUser().getId();
    }

}
