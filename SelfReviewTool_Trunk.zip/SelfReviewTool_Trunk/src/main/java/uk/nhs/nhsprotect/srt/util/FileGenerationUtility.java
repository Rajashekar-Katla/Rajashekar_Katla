/**
 * 
 */
package uk.nhs.nhsprotect.srt.util;

import java.util.List;

import uk.nhs.nhsprotect.srt.dto.SRTSummary;

import static uk.nhs.nhsprotect.srt.util.SRTUtil.SRT_SECTION;

/**
 * @author ntones
 */
public class FileGenerationUtility {

    /**
     * Helper method to generate different lists of question info per section
     * from main list consisting all the questions for the given organisation
     * and staff id .
     * @param list
     * @param generalTabList
     * @param sgovernanceTabList
     * @param informinvolveTabList
     * @param preventdeterTabList
     * @param holdtoaccountTabList
     * @throws Exception
     */
    public static void populateQuestionListBySections(List<SRTSummary> list, List<SRTSummary> generalTabList,
            List<SRTSummary> sgovernanceTabList, List<SRTSummary> informinvolveTabList,
            List<SRTSummary> preventdeterTabList, List<SRTSummary> holdtoaccountTabList) {

        if (null != list && !list.isEmpty()) {

            for (SRTSummary srtSummary : list) {

                if (srtSummary.getSectionName().equals(SRT_SECTION.GENERAL.getName())) {
                    generalTabList.add(srtSummary);
                } else if (srtSummary.getSectionName().equals(SRT_SECTION.STRATEGIC_GOVERNANCE.getName())) {
                    sgovernanceTabList.add(srtSummary);
                } else if (srtSummary.getSectionName().equals(SRT_SECTION.INFORM_AND_INVOLVE.getName())) {
                    informinvolveTabList.add(srtSummary);
                } else if (srtSummary.getSectionName().equals(SRT_SECTION.PREVENT_AND_DETER.getName())) {
                    preventdeterTabList.add(srtSummary);
                } else if (srtSummary.getSectionName().equals(SRT_SECTION.HOLD_TO_ACCOUNT.getName())) {
                    holdtoaccountTabList.add(srtSummary);
                }
            }
        }
    }

}
