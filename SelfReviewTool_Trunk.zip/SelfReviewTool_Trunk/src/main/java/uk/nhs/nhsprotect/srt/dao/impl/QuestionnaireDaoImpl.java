/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.QuestionnaireDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Questionnaire;
import uk.nhs.nhsprotect.srt.model.QuestionnaireAndRatingScoreAndResultsModel;
import uk.nhs.nhsprotect.srt.model.SectionScore;

/**
 * @author bvaidya
 */
@Repository("questionnaireDao")
public class QuestionnaireDaoImpl extends SRTHibernateDaoSupportImpl implements
		QuestionnaireDao {

	/*
	 * Get the question list for current year (non-Javadoc)
	 * @see uk.nhs.nhsprotect.srt.dao.QuestionnaireDao#
	 * findQuessionnaireListForCurrentYear(java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Questionnaire> findQuessionnaireListForCurrentYear(
			String region, String srtType) throws SrtException {
		try {
			Query<Questionnaire> exQuery = null;

			if (StringUtils.isEmpty(region)) {
				exQuery = getCurrentSession()
						.createQuery(
								"from Questionnaire where status = 'A'and srtType = :srtType and region is null order by questionId asc")
						.setParameter("srtType", srtType);
			} else {
				exQuery = getCurrentSession()
						.createQuery(
								"from Questionnaire where status = 'A' and region = :region and srtType = :srtType order by questionId asc")
						.setParameter("region", region)
						.setParameter("srtType", srtType);
			}

			return exQuery.list();
		} catch (HibernateException e) {
			throw new SrtException(e);
		} catch (Exception e) {
			throw new SrtException(e);
		}
	}

	/*
	 * Get the question list for previous years (non-Javadoc)
	 * @see uk.nhs.nhsprotect.srt.dao.QuestionnaireDao#
	 * findQuessionnaireListForPreviousYears(java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Questionnaire> findQuessionnaireListForPreviousYears(
			String region, String srtType, String year) throws SrtException {
		try {
			Query<Questionnaire> exQuery = null;

			if (StringUtils.isEmpty(region)) {
				exQuery = getCurrentSession()
						.createQuery(
								"from Questionnaire where year = :year and srtType = :srtType and region is null order by questionId asc")
						.setParameter("year", year)
						.setParameter("srtType", srtType);
			} else {
				exQuery = getCurrentSession()
						.createQuery(
								"from Questionnaire where year = :year and region = :region and srtType = :srtType order by questionId asc")
						.setParameter("year", year)
						.setParameter("region", region)
						.setParameter("srtType", srtType);
			}
			return exQuery.list();
		} catch (HibernateException e) {
			throw new SrtException(e);
		} catch (Exception e) {
			throw new SrtException(e);
		}
	}

	public List<QuestionnaireAndRatingScoreAndResultsModel> getQuessionnaireAndResultsList(
			final String region, final String srtType, final String year,
			final String orgCode) throws SrtException {

		final String sqlQuery = "select * from table(QUESTION_AND_RESULTS_FUNCTION(:year, :srtType, :orgCode, :region))";

		try {
			final NativeQuery<QuestionnaireAndRatingScoreAndResultsModel> query = getCurrentSession()
					.createNativeQuery(sqlQuery,
							QuestionnaireAndRatingScoreAndResultsModel.class);

			query.setParameter("year", year);
			query.setParameter("srtType", srtType);
			query.setParameter("orgCode", orgCode);
			query.setParameter("region", region);

			final List<QuestionnaireAndRatingScoreAndResultsModel> queryResult = query
					.getResultList();

			return queryResult;
		} catch (HibernateException e) {
			throw new SrtException(e);
		} catch (Exception e) {
			throw new SrtException(e);
		}
	}

	public List<SectionScore> getSectionScoreData() throws SrtException {
		final NativeQuery<SectionScore> query = getCurrentSession()
				.createNativeQuery(
						"select * from SECTION_SCORE_TBL order by ID",
						SectionScore.class);
		final List<SectionScore> queryResult = query.getResultList();

		return queryResult;
	}
}
