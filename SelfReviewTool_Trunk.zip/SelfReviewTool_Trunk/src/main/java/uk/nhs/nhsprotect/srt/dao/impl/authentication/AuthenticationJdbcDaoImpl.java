/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl.authentication;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.model.authentication.SrtUser;
import uk.nhs.nhsprotect.srt.model.authentication.User;
import uk.nhs.nhsprotect.srt.model.authentication.UserAuthorities;

/**
 * Custom authentication implementation.
 * @author ntones
 */
@Repository("userDetailsService")
@MonitoredWithSpring
@Transactional
public class AuthenticationJdbcDaoImpl implements UserDetailsService {

    /**
     * Logger instance for AuthenticationJdbcDaoImpl.class.
     **/

    /**
     * Class logger instance.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationJdbcDaoImpl.class);

    @Autowired
    private SessionFactory sessionFactory;

    /*
     * (non-Javadoc)
     * @see org.springframework.security.core.userdetails.UserDetailsService#
     * loadUserByUsername(java.lang.String)
     */
    public UserDetails loadUserByUsername(final String username) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("\n\n**loadUserByUsername=" + username);
        }
        Session session = null;
        try {
            session = sessionFactory.openSession();
            StringBuffer sb = new StringBuffer("from User");
            sb.append(" where username = :username");
            Query userQuery = session.createQuery(sb.toString());
            userQuery.setString("username", username);
            User user = (User) userQuery.uniqueResult();

            if (user != null) {
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug(
                            "\n\n UserDetails =" + user.getUsername() + " : Authorities=" + user.getUserAuthorities());
                }
                List<UserAuthorities> authorities = user.getUserAuthorities();
                List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();

                for (int iCounter = 0; iCounter < authorities.size(); iCounter++) {
                    grantedAuthorities.add(authorities.get(iCounter).getAuthority());
                }
                return new SrtUser(user.getUsername(), user.getPassword(), true, true, true, user.isEnabled(),
                        grantedAuthorities, user);
            } else {
                throw new UsernameNotFoundException("Username " + username + "not found.");
            }
        } finally {
            if (session != null && session.isOpen()) {
                session.close();
            }
        }
    }

}
