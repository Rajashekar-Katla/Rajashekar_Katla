package uk.nhs.nhsprotect.srt.dto;

import java.util.Date;

public class SRT {

    private String orgCode;

    private String orgName;

    private String status;

    private String type;

    private Date createdDate;

    private String sharedLogin;

    private String sharedPassword;

    private String year;

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getSharedLogin() {
        return sharedLogin;
    }

    public void setSharedLogin(String sharedLogin) {
        this.sharedLogin = sharedLogin;
    }

    public String getSharedPassword() {
        return sharedPassword;
    }

    public void setSharedPassword(String sharedPassword) {
        this.sharedPassword = sharedPassword;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

}
