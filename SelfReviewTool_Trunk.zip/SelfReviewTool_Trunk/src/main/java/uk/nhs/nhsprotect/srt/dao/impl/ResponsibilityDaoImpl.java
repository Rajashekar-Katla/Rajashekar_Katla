/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.ResponsibilityDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Responsibility;

/**
 * @author bvaidya
 */
@Repository("responsibilityDao")
public class ResponsibilityDaoImpl extends SRTHibernateDaoSupportImpl implements ResponsibilityDao {

  /*
   * (non-Javadoc)
   * @see
   * uk.nhs.nhsprotect.srt.dao.ResponsibilityDao#getResponsibilitiesByStaffId(
   * java.lang.String, boolean)
   */
  @Override
  public List<Responsibility> getResponsibilitiesByStaffId(String staffId, boolean includeCommissioningOrgs)
      throws SrtException {

    try {
      String currentlyActive = "res.person.startDate < sysdate and res.person.endDate > sysdate";

      StringBuffer buffer = new StringBuffer();
      buffer.append(" from Responsibility as res where res.person.status = 'Y'and ");
      buffer.append(currentlyActive);
      buffer.append(" and res.staffId = :staffId");
      Query exQuery = getCurrentSession().createQuery(buffer.toString()).setParameter("staffId", staffId);
      return exQuery.list();
    } catch (HibernateException e) {
      throw new SrtException(e);
    }
  }

  /*
   * (non-Javadoc)
   * @see uk.nhs.nhsprotect.srt.dao.ResponsibilityDao#
   * getResponsibilityByPersonAndOrg(java.lang.String, java.lang.String)
   */
  @SuppressWarnings("unchecked")
  @Override
  public List<Responsibility> getResponsibilityByPersonAndOrg(String userRef, String orgCode) throws SrtException {

    try {
      String queryStr = "from Responsibility as res where res.startDate < sysdate and (res.endDate > sysdate or res.endDate is null) and res.organisation.orgCode = :orgCode and res.staffId = :staffId";

      Query exQuery = getCurrentSession().createQuery(queryStr).setParameter("staffId", userRef).setParameter("orgCode",
          orgCode);

      return exQuery.list();
    } catch (HibernateException e) {
      throw new SrtException(e);
    } catch (Exception e) {
      throw new SrtException(e);
    }

  }

  /*
   * (non-Javadoc)
   * @see
   * uk.nhs.nhsprotect.srt.dao.ResponsibilityDao#getResponsibilitiesByOrgCode(
   * java.lang.String)
   */
  @Override
  public List<Responsibility> getResponsibilitiesByOrgCode(String orgCode) throws SrtException {

    try {
      String queryStr = "from Responsibility as res where res.startDate < sysdate and (res.endDate > sysdate or res.endDate is null) and res.organisation.orgCode = :orgCode";

      Query exQuery = getCurrentSession().createQuery(queryStr).setParameter("orgCode", orgCode);

      return exQuery.list();
    } catch (HibernateException e) {
      throw new SrtException(e);
    } catch (Exception e) {
      throw new SrtException(e);
    }
  }

}
