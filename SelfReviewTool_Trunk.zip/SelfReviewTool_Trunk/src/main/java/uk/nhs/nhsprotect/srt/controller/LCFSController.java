package uk.nhs.nhsprotect.srt.controller;

import java.util.Calendar;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestWrapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import net.bull.javamelody.MonitoredWithSpring;
import uk.nhs.nhsprotect.srt.dto.SRTForm;
import uk.nhs.nhsprotect.srt.enums.PilotStandardMap;
import uk.nhs.nhsprotect.srt.enums.ScoreThresholdMap;
import uk.nhs.nhsprotect.srt.enums.SectionScoreMap;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.Organisation;
import uk.nhs.nhsprotect.srt.model.Person;
import uk.nhs.nhsprotect.srt.model.SRTStatus;
import uk.nhs.nhsprotect.srt.service.OrganisationService;
import uk.nhs.nhsprotect.srt.service.PilotStandardService;
import uk.nhs.nhsprotect.srt.service.SRTEmailService;
import uk.nhs.nhsprotect.srt.service.SRTService;
import uk.nhs.nhsprotect.srt.service.ScoreThresholdService;
import uk.nhs.nhsprotect.srt.service.SectionScoreService;

@Controller
@RequestMapping(value = "/LCFSForm")
@SessionAttributes({ "person" })
@MonitoredWithSpring
public class LCFSController {

	@Autowired
	private OrganisationService organisationService;

	@Autowired
	private SRTService sRTService;

	@Autowired
	private SRTEmailService srtEmailService;

	@Autowired
	private SectionScoreService sectionScoreService;

	@Autowired
	private ScoreThresholdService scoreThresholdService;

	@Autowired
	private PilotStandardService pilotStandardService;

	/**
	 * Class logger instance.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(LCFSController.class);

	@RequestMapping(method = RequestMethod.GET)
	@PreAuthorize("hasPermission('lcfs',#orgCode)")
	public ModelAndView getSRTForm(@ModelAttribute("person") Person person, @RequestParam("orgCode") String orgCode,
			@RequestParam("year") String year, ModelMap model) throws Exception {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("LCFSForm ,orgCode=" + orgCode + ", year=" + year);
		}

		String staffId = person.getStaffId();

		final Map<String, String> sectionScoreMap = SectionScoreMap.MAP.getSectionScoreMap();

		if (sectionScoreMap.isEmpty()) {
			sectionScoreService.getSectionScoreData(sectionScoreMap);
		}

		final Map<String, Float> scoreThresholdMap = ScoreThresholdMap.MAP.getScoreThresholdMap();

		if (scoreThresholdMap.isEmpty()) {
			scoreThresholdService.getScoreThresholdData(scoreThresholdMap);
		}

		final Map<String, Long> pilotStandardMap = PilotStandardMap.MAP.getPilotStandardMap();

		if (pilotStandardMap.isEmpty()) {
			pilotStandardService.getPilotStandardData(pilotStandardMap);
		}

		return prepareModelAndView(model, staffId, year, orgCode, person);
	}

	@RequestMapping(method = RequestMethod.POST)
	@PreAuthorize("hasPermission('lcfs',#orgCode)")
	public ModelAndView submitSRTForm(@ModelAttribute("person") Person person,
			@ModelAttribute("lcfsform.form") SRTForm lcfsSRTForm, @RequestParam("submitType") String submitType,
			@RequestParam("orgCode") String orgCode, ModelMap model, SecurityContextHolderAwareRequestWrapper request)
			throws Exception {

		Organisation organisation = organisationService.findOrganisationByCode(orgCode);

		String srtType = "lcfs";
		if (organisation.isCommissioningOrg()) {
			srtType = "lcfscom";
		}

		String staffId = person.getStaffId();

		String year = lcfsSRTForm.getSrtStatus().getYear();

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("submitLCFSForm  submitType: " + submitType + " orgCode: " + orgCode + "	SRT_TYPE: "
					+ srtType + "	staffId " + staffId);
		}

		if (submitType.equalsIgnoreCase("submit")) {
			sRTService.sumbitSRTForm(lcfsSRTForm, orgCode, srtType, staffId);

			// set confirmation message
			try {
				String responseMessage = srtEmailService.sendMessage(orgCode, srtType, staffId);
				model.put("responseMessage", responseMessage);
			} catch (MailException exception) {
				LOGGER.error("Error occured sending email confirmation.", exception);
				model.put("responseMessage", "Error occured sending email confirmation.");
			}

			String submitMessage = "Thank you for completing the SRT for " + orgCode
					+ ".  Your responses have been submitted.";
			model.put("submitMessage", submitMessage);

		} else {
			sRTService.draftSRTForm(lcfsSRTForm, orgCode, srtType, staffId);
			String submitMessage = "Your responses have been saved.";
			model.put("submitMessage", submitMessage);
		}

		return prepareModelAndView(model, staffId, year, orgCode, person);

	}

	private ModelAndView prepareModelAndView(final ModelMap model, final String staffId, final String year,
			final String orgCode, final Person person) throws SrtException {

		Organisation organisation = organisationService.findOrganisationByCode(orgCode);
		String orgName = "-";
		if (organisation != null) {
			orgName = organisation.getName();
		}
		String srtType = "lcfs";
		if (organisation.isCommissioningOrg()) {
			srtType = "lcfscom";
		}
		SRTStatus srtStatus = sRTService.retrieveSRTStatus(orgCode, srtType, year);

		SRTForm srtForm = sRTService.retrieveSRTForm(orgCode, srtType, staffId, year);

		model.addAttribute("person", person);
		model.addAttribute("form", srtForm);
		model.addAttribute("orgCode", orgCode);
		model.addAttribute("srtType", srtType);
		model.addAttribute("srtStatus", srtStatus);
		model.addAttribute("orgName", orgName);
		model.addAttribute("pre2016", isPre2016SRTForm(year));

		return new ModelAndView("lcfsform", "lcfsform", model);

	}

	private boolean isPre2016SRTForm(String year) {
		Calendar calendarSRTYear = Calendar.getInstance();
		calendarSRTYear.set(Calendar.YEAR, Integer.parseInt(year));
		Calendar calendar2016 = Calendar.getInstance();
		calendar2016.set(Calendar.YEAR, 2016);
		return calendarSRTYear.before(calendar2016);
	}

}