package uk.nhs.nhsprotect.srt;

/**
 * Dummy interface to serve as a reference point for Spring component scanning.
 * @author ntones
 */
public interface Application {
}
