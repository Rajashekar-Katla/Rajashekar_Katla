/**
 * 
 */
package uk.nhs.nhsprotect.srt.dto;

import java.io.Serializable;

import uk.nhs.nhsprotect.srt.model.Responsibility;

/**
 * Representation of {@link Responsibility} object for use in views.
 * 
 * @author ntones
 *
 */
public class ResponsibilityDTO implements Serializable {

	/**
	 * Serial version.
	 */
	private static final long serialVersionUID = 1L;

	private Long id;

	private String orgCode;

	private String orgName;

	private boolean commissioningOrg;

	private String personType;

	/**
	 * Default constructor.
	 */
	public ResponsibilityDTO() {
		// Default constructor
	}

	/**
	 * Constructor to create a DTO instance from the source object
	 * 
	 * @param responsibility
	 *            sources
	 */
	public ResponsibilityDTO(final Responsibility responsibility) {
		this.id = Long.valueOf(responsibility.getRespId());
		this.orgCode = responsibility.getOrgCode();
		this.orgName = responsibility.getOrgName();
		this.commissioningOrg = responsibility.getOrganisation().isCommissioningOrg();
		this.personType = responsibility.getPerson().getPersonType();

	}

	/**
	 * Utility method to create a DTO instance from the source object.
	 * 
	 * @param responsibility
	 *            source
	 * @return ResponsibilityDTO based on source object
	 */
	public static ResponsibilityDTO fromResponsibity(Responsibility responsibility) {
		return new ResponsibilityDTO(responsibility);

	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the orgCode
	 */
	public String getOrgCode() {
		return orgCode;
	}

	/**
	 * @param orgCode
	 *            the orgCode to set
	 */
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	/**
	 * @return the orgName
	 */
	public String getOrgName() {
		return orgName;
	}

	/**
	 * @param orgName
	 *            the orgName to set
	 */
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	/**
	 * @return the commissioningOrg
	 */
	public boolean isCommissioningOrg() {
		return commissioningOrg;
	}

	/**
	 * @param commissioningOrg
	 *            the commissioningOrg to set
	 */
	public void setCommissioningOrg(boolean commissioningOrg) {
		this.commissioningOrg = commissioningOrg;
	}

	/**
	 * @return the personType
	 */
	public String getPersonType() {
		return personType;
	}

	/**
	 * @param personType
	 *            the personType to set
	 */
	public void setPersonType(String personType) {
		this.personType = personType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orgCode == null) ? 0 : orgCode.hashCode());
		result = prime * result + ((orgName == null) ? 0 : orgName.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResponsibilityDTO other = (ResponsibilityDTO) obj;
		if (orgCode == null) {
			if (other.orgCode != null)
				return false;
		} else if (!orgCode.equals(other.orgCode))
			return false;
		if (orgName == null) {
			if (other.orgName != null)
				return false;
		} else if (!orgName.equals(other.orgName))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ResponsibilityDTO [orgCode=" + orgCode + ", orgName=" + orgName + "]";
	}

}
