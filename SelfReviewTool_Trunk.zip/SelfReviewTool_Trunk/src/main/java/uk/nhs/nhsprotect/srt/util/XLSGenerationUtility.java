/**
 * 
 */
package uk.nhs.nhsprotect.srt.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.BorderFormatting;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ComparisonOperator;
import org.apache.poi.ss.usermodel.ConditionalFormattingRule;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FontFormatting;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.PatternFormatting;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.SheetConditionalFormatting;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dto.SRTSummary;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTStatus;

/**
 * Class holding methods to create an excel document containing an SRT.
 * @author ntones
 */
@Repository
public class XLSGenerationUtility {

  /**
   * Class logger instance.
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(XLSGenerationUtility.class);

  private ConditionalFormattingRule[] rules;

  private static final String[] sections = {
      "1 General", "2 Strategic Governance", "3 Inform and Involve", "4 Prevent and Deter", "5 Hold to Account"
  };

  /**
   * Method to generate an XLS file containing the current SRT.
   * @param list of questions and responses
   * @param status of SRT
   * @throws SrtException on error
   */
  public File generateSRTProcessSummaryXLS(List<SRTSummary> list, SRTStatus status) throws SrtException {

    Workbook wb = new HSSFWorkbook();

    List<SRTSummary> generalTabList = new ArrayList<SRTSummary>();

    List<SRTSummary> sgovernanceTabList = new ArrayList<SRTSummary>();

    List<SRTSummary> informinvolveTabList = new ArrayList<SRTSummary>();

    List<SRTSummary> preventdeterTabList = new ArrayList<SRTSummary>();

    List<SRTSummary> holdtoaccountTabList = new ArrayList<SRTSummary>();

    FileGenerationUtility.populateQuestionListBySections(list, generalTabList, sgovernanceTabList, informinvolveTabList,
        preventdeterTabList, holdtoaccountTabList);

    Map<String, CellStyle> styles = createStyles(wb);

    File tempFile = null;

    for (int section = 0; section < sections.length; section++) {

      // create a sheet for each section
      Sheet sheet = wb.createSheet(sections[section]);

      // turn off gridlines
      sheet.setDisplayGridlines(false);
      sheet.setPrintGridlines(false);
      sheet.setFitToPage(true);
      sheet.setHorizontallyCenter(true);
      PrintSetup printSetup = sheet.getPrintSetup();
      printSetup.setLandscape(true);

      // the following three statements are required only for HSSF
      sheet.setAutobreaks(true);
      printSetup.setFitHeight((short) 1);
      printSetup.setFitWidth((short) 1);

      // the header row: centered text in 48pt font
      int rowCount = 0;
      Row headerRow = sheet.createRow(rowCount++);
      // headerRow.setHeightInPoints(80);
      Cell titleCell = headerRow.createCell(0);
      titleCell.setCellValue((status.getSrtType().contains("lcfs") ? "FRAUD " : "SECURITY ") + "Summary - "
          + status.getOrgCode() + " - " + status.getYear());
      titleCell.setCellStyle(styles.get("title"));
      sheet.addMergedRegion(CellRangeAddress.valueOf("$A$1:$E$1"));
      Row headerRow2 = sheet.createRow(rowCount++);
      Cell titleCell2 = headerRow2.createCell(0);
      titleCell2.setCellValue("Overall Score: " + status.getOverallScore() + " ["
          + SRTUtil.getColorFromRatingValue(Integer.parseInt(status.getOverallScore())) + "]");
      titleCell2.setCellStyle(styles.get("title"));
      sheet.addMergedRegion(CellRangeAddress.valueOf("$A$2:$E$2"));
      Row headerRow3 = sheet.createRow(rowCount++);
      Cell titleCell3 = headerRow3.createCell(0);
      titleCell3.setCellValue(
          "Submitted By: " + (status.getSubmittedBy() == null ? "IN PROGRESS" : status.getSubmittedBy().getFullname()));
      titleCell3.setCellStyle(styles.get("title"));
      sheet.addMergedRegion(CellRangeAddress.valueOf("$A$3:$E$3"));
      Row headerRow4 = sheet.createRow(rowCount++);
      Cell titleCell4 = headerRow4.createCell(0);
      titleCell4.setCellValue("Submitted Date: " + status.getSubmittedDate());
      titleCell4.setCellStyle(styles.get("title"));
      sheet.addMergedRegion(CellRangeAddress.valueOf("$A$4:$E$4"));

      // header with month titles
      Row monthRow = sheet.createRow(rowCount++);

      // set column widths, the width is measured in units of 1/256th
      // of a character width
      int i = 0;
      sheet.setColumnWidth(i * 2, 30 * 256); // the column is 30
      // characters wide
      sheet.setColumnWidth(i * 2 + 1, 13 * 256); // the column is 13
      // characters wide
      sheet.setColumnWidth(i * 2 + 2, 55 * 256); // the column is 13
      // characters wide
      sheet.setColumnWidth(i * 2 + 3, 55 * 256); // the column is 13
      // characters wide

      Cell sectionTitle = monthRow.createCell(0);
      sectionTitle.setCellValue(sections[section]);
      sectionTitle.setCellStyle(styles.get("month"));

      Row questionHeaderRow = sheet.createRow(rowCount++);
      questionHeaderRow.setHeightInPoints(20);

      Cell cellQuestionHeader = questionHeaderRow.createCell(2);
      Cell cellResponseHeader = questionHeaderRow.createCell(3);

      cellQuestionHeader.setCellValue("Standard");
      cellResponseHeader.setCellValue("Comments");

      cellQuestionHeader.setCellStyle(styles.get("comment_header"));
      cellResponseHeader.setCellStyle(styles.get("comment_header"));
      // iterate over general section questions
      if (sections[section].contains("1")) {
        processSRTSummaryList(generalTabList, sheet, rowCount, styles, false, null);
      } else {
        Cell cellQuestionNo = questionHeaderRow.createCell(1);
        cellQuestionNo.setCellValue("No.");
        cellQuestionNo.setCellStyle(styles.get("comment_header"));

        Cell cellRatingsHeader = questionHeaderRow.createCell(4);
        cellRatingsHeader.setCellValue("Score");
        cellRatingsHeader.setCellStyle(styles.get("comment_header"));

        if (sections[section].contains("2")) {
          processSRTSummaryList(sgovernanceTabList, sheet, rowCount, styles, true, "1.");
        } else if (sections[section].contains("3")) {
          processSRTSummaryList(informinvolveTabList, sheet, rowCount, styles, true, "2.");
        } else if (sections[section].contains("4")) {
          processSRTSummaryList(preventdeterTabList, sheet, rowCount, styles, true, "3.");
        } else if (sections[section].contains("5")) {
          processSRTSummaryList(holdtoaccountTabList, sheet, rowCount, styles, true, "4.");
        }
      }

    }

    String suffix = ".xls";
    if (wb instanceof XSSFWorkbook) {
      suffix += "x";
    }

    FileOutputStream out = null;
    try {
      // Write the output to a file
      tempFile = File.createTempFile("SRT_" + status.getOrgCode() + "_" + status.getYear() + "_" + status.getSrtType(),
          suffix);
      out = new FileOutputStream(tempFile);
      wb.write(out);

    } catch (IOException e) {
      LOGGER.error("Exception occured creating excel summary.", e);
      throw new SrtException(e);
    } finally {
      IOUtils.closeQuietly(out);
    }

    return tempFile;

  }

  /**
   * Method to process a sections questions and responses into a readable
   * format.
   * @param summaries the list of SRTSummary for this section
   * @param sheet the current worksheet
   * @param rowCount the current row count
   * @param styles the worksheet styles
   * @param ratingsApply indicate if this section has ratings
   * @param sectionNumber the section number to populate
   */
  private void processSRTSummaryList(List<SRTSummary> summaries, Sheet sheet, int rowCount,
      Map<String, CellStyle> styles, boolean ratingsApply, String sectionNumber) {

    int questionNumber = 0;
    for (SRTSummary summary : summaries) {
      Row questionRow = sheet.createRow(rowCount++);
      if (summary.getComments() != null && summary.getComments().length() > 50
          || summary.getQuestionText() != null && summary.getQuestionText().length() > 50) {
        questionRow.setHeightInPoints(60);
      } else {
        questionRow.setHeightInPoints(20);
      }
      Cell cellQuestion = questionRow.createCell(2);
      Cell cellResponse = questionRow.createCell(3);

      cellQuestion.setCellValue(summary.getQuestionText());
      cellQuestion.setCellStyle(styles.get("comment_wrap"));
      cellResponse.setCellValue(summary.getComments());
      cellResponse.setCellStyle(styles.get("comment_wrap"));

      if (ratingsApply) {

        Cell cellNumber = questionRow.createCell(1);
        cellNumber.setCellValue(sectionNumber + "" + (++questionNumber));
        cellNumber.setCellStyle(styles.get("comment_wrap"));

        Cell cellRatings = questionRow.createCell(4);
        cellRatings.setCellValue(summary.getScore());

        StringBuffer buffer = new StringBuffer();
        buffer.append("$E$7:$E$");
        buffer.append(7 + summaries.size());
        String range = buffer.toString();

        if (LOGGER.isDebugEnabled()) {
          LOGGER.debug("Applying conditional formatting to the range " + range);
        }

        CellRangeAddress[] regions = {
            CellRangeAddress.valueOf(range)
        };
        // conditional formatting
        SheetConditionalFormatting formatting = sheet.getSheetConditionalFormatting();
        formatting.addConditionalFormatting(regions, getRatingsFormattingRules(formatting));
      }

    }

  }

  private ConditionalFormattingRule[] getRatingsFormattingRules(SheetConditionalFormatting formatting) {

    if (rules == null) {
      List<ConditionalFormattingRule> formattingRules = new ArrayList<ConditionalFormattingRule>();

      // // 0-NEUTRAL = BLACK FILL
      // ConditionalFormattingRule rule0 = formatting
      // .createConditionalFormattingRule(ComparisonOperator.EQUAL,
      // "0");
      // PatternFormatting fill0 = rule0.createPatternFormatting();
      // fill0.setFillBackgroundColor(IndexedColors.BLACK.index);
      // fill0.setFillPattern(PatternFormatting.SOLID_FOREGROUND);
      // formattingRules.add(rule0);
      // RATING = 1 = RED FILL - RED TEXT
      ConditionalFormattingRule rule1 = formatting.createConditionalFormattingRule(ComparisonOperator.EQUAL, "1");
      // borders
      BorderFormatting border1 = rule1.createBorderFormatting();
      border1.setBorderBottom(CellStyle.BORDER_THIN);
      border1.setBorderTop(CellStyle.BORDER_THIN);
      border1.setBorderRight(CellStyle.BORDER_THIN);
      border1.setBottomBorderColor(IndexedColors.GREY_50_PERCENT.index);
      border1.setTopBorderColor(IndexedColors.GREY_50_PERCENT.index);
      border1.setRightBorderColor(IndexedColors.GREY_50_PERCENT.index);
      // font
      FontFormatting font1 = rule1.createFontFormatting();
      font1.setFontColorIndex(IndexedColors.WHITE.index);
      // fill
      PatternFormatting fill1 = rule1.createPatternFormatting();
      fill1.setFillBackgroundColor(IndexedColors.RED.index);
      fill1.setFillPattern(PatternFormatting.SOLID_FOREGROUND);
      // alignment

      formattingRules.add(rule1);

      // RATING = 2 = ORANGE FILL - ORANGE TEXT
      ConditionalFormattingRule rule2 = formatting.createConditionalFormattingRule(ComparisonOperator.EQUAL, "2");
      // borders
      BorderFormatting border2 = rule2.createBorderFormatting();
      border2.setBorderBottom(CellStyle.BORDER_THIN);
      border2.setBorderTop(CellStyle.BORDER_THIN);
      border2.setBorderRight(CellStyle.BORDER_THIN);
      border2.setBottomBorderColor(IndexedColors.GREY_50_PERCENT.index);
      border2.setTopBorderColor(IndexedColors.GREY_50_PERCENT.index);
      border2.setRightBorderColor(IndexedColors.GREY_50_PERCENT.index);
      // font
      FontFormatting font2 = rule2.createFontFormatting();
      font2.setFontColorIndex(IndexedColors.WHITE.index);
      // fill
      PatternFormatting fill2 = rule2.createPatternFormatting();
      fill2.setFillBackgroundColor(IndexedColors.ORANGE.index);
      fill2.setFillPattern(PatternFormatting.SOLID_FOREGROUND);
      formattingRules.add(rule2);

      // RATING = 3 = GREEN FILL - GREEN TEXT
      ConditionalFormattingRule rule3 = formatting.createConditionalFormattingRule(ComparisonOperator.EQUAL, "3");
      // borders
      BorderFormatting border3 = rule3.createBorderFormatting();
      border3.setBorderBottom(CellStyle.BORDER_THIN);
      border3.setBorderTop(CellStyle.BORDER_THIN);
      border3.setBorderRight(CellStyle.BORDER_THIN);
      border3.setBottomBorderColor(IndexedColors.GREY_50_PERCENT.index);
      border3.setTopBorderColor(IndexedColors.GREY_50_PERCENT.index);
      border3.setRightBorderColor(IndexedColors.GREY_50_PERCENT.index);
      // font
      FontFormatting font3 = rule3.createFontFormatting();
      font3.setFontColorIndex(IndexedColors.WHITE.index);
      // fill
      PatternFormatting fill3 = rule3.createPatternFormatting();
      fill3.setFillBackgroundColor(IndexedColors.GREEN.index);
      fill3.setFillPattern(PatternFormatting.SOLID_FOREGROUND);
      formattingRules.add(rule3);

      rules = new ConditionalFormattingRule[formattingRules.size()];
      int index = 0;
      for (ConditionalFormattingRule rule : formattingRules) {
        rules[index++] = rule;

      }
    }

    return rules;
  }

  /**
   * cell styles used for formatting sheets
   */
  private static Map<String, CellStyle> createStyles(Workbook wb) {
    Map<String, CellStyle> styles = new HashMap<String, CellStyle>();

    short borderColor = IndexedColors.GREY_50_PERCENT.getIndex();

    CellStyle style;
    Font titleFont = wb.createFont();
    titleFont.setFontHeightInPoints((short) 12);
    titleFont.setColor(IndexedColors.DARK_BLUE.getIndex());
    style = wb.createCellStyle();
    style.setAlignment(CellStyle.ALIGN_CENTER);
    style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
    style.setFont(titleFont);
    styles.put("title", style);

    Font monthFont = wb.createFont();
    monthFont.setFontHeightInPoints((short) 12);
    monthFont.setColor(IndexedColors.WHITE.getIndex());
    monthFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
    style = wb.createCellStyle();
    style.setAlignment(CellStyle.ALIGN_CENTER);
    style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
    style.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    style.setFont(monthFont);
    styles.put("month", style);

    Font commentHeaderFont = wb.createFont();
    commentHeaderFont.setFontHeightInPoints((short) 11);
    commentHeaderFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
    style = wb.createCellStyle();
    style.setAlignment(CellStyle.ALIGN_LEFT);
    style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
    style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    style.setBorderTop(CellStyle.BORDER_THIN);
    style.setTopBorderColor(borderColor);
    style.setBorderBottom(CellStyle.BORDER_THIN);
    style.setBottomBorderColor(borderColor);
    style.setBorderLeft(CellStyle.BORDER_THIN);
    style.setLeftBorderColor(borderColor);
    style.setBorderRight(CellStyle.BORDER_THIN);
    style.setRightBorderColor(borderColor);

    style.setFont(commentHeaderFont);
    styles.put("comment_header", style);

    style = wb.createCellStyle();
    style.setAlignment(CellStyle.ALIGN_CENTER);
    style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
    style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    style.setBorderRight(CellStyle.BORDER_THIN);
    style.setRightBorderColor(borderColor);
    style.setBorderBottom(CellStyle.BORDER_THIN);
    style.setBottomBorderColor(borderColor);
    styles.put("weekend_right", style);

    style = wb.createCellStyle();
    Font commentFont = wb.createFont();
    commentFont.setFontHeightInPoints((short) 11);
    style.setAlignment(CellStyle.ALIGN_LEFT);
    style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
    style.setBorderLeft(CellStyle.BORDER_THIN);
    style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    style.setLeftBorderColor(borderColor);
    style.setBorderBottom(CellStyle.BORDER_THIN);
    style.setBottomBorderColor(borderColor);
    style.setRightBorderColor(borderColor);
    style.setBorderRight(CellStyle.BORDER_THIN);
    style.setFont(commentFont);
    style.setWrapText(true);
    styles.put("comment_wrap", style);

    style = wb.createCellStyle();
    Font ratingFont = wb.createFont();
    ratingFont.setFontHeightInPoints((short) 11);
    ratingFont.setColor(IndexedColors.WHITE.getIndex());
    style.setAlignment(CellStyle.ALIGN_LEFT);
    style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
    style.setBorderLeft(CellStyle.BORDER_THIN);
    style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    style.setLeftBorderColor(borderColor);
    style.setBorderBottom(CellStyle.BORDER_THIN);
    style.setBottomBorderColor(borderColor);
    style.setRightBorderColor(borderColor);
    style.setBorderRight(CellStyle.BORDER_THIN);
    style.setFont(ratingFont);
    style.setWrapText(true);
    styles.put("rating_wrap", style);

    style = wb.createCellStyle();
    style.setAlignment(CellStyle.ALIGN_CENTER);
    style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
    style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    style.setBorderRight(CellStyle.BORDER_THIN);
    style.setRightBorderColor(borderColor);
    style.setBorderBottom(CellStyle.BORDER_THIN);
    style.setBottomBorderColor(borderColor);
    styles.put("workday_right", style);

    style = wb.createCellStyle();
    style.setBorderLeft(CellStyle.BORDER_THIN);
    style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    style.setBorderBottom(CellStyle.BORDER_THIN);
    style.setBottomBorderColor(borderColor);
    styles.put("grey_left", style);

    style = wb.createCellStyle();
    style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    style.setBorderRight(CellStyle.BORDER_THIN);
    style.setRightBorderColor(borderColor);
    style.setBorderBottom(CellStyle.BORDER_THIN);
    style.setBottomBorderColor(borderColor);
    styles.put("grey_right", style);

    return styles;
  }
}
