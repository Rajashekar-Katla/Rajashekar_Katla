/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao;

import java.util.List;

import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTYearRange;

/**
 * @author bvaidya
 */
public interface SRTYearRangeDao {

    /**
     * Get list of records for the given year
     * @param year
     * @return
     * @throws SrtException
     */
    List<SRTYearRange> getListOfRecordsForGivenYear(String year) throws SrtException;

    /**
     * Get the object for given year and srt type.
     * @param year
     * @param srtType
     * @return
     * @throws SrtException
     */
    SRTYearRange getYearRange(String year, String srtType) throws SrtException;

    /**
     * Get distinct list of years.
     * @param srtType type of SRT To query for
     * @return List<String> SRT years as strings
     * @throws SrtException
     */
    List<String> getDistinctListOfYears(String srtType) throws SrtException;

}
