/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.SRTYearRangeDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.SRTYearRange;

/**
 * @author bvaidya
 */
@Repository("srtYearRangeDao")
public class SRTYearRangeDaoImpl extends SRTHibernateDaoSupportImpl implements SRTYearRangeDao {

    /*
     * Get list of records for the given year (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.dao.SRTYearRangeDao#getListOfRecordsForGivenYear
     * (java.lang.String)
     */
    public List<SRTYearRange> getListOfRecordsForGivenYear(String year) throws SrtException {
        List<SRTYearRange> list = null;
        try {
            Query query = getCurrentSession().createQuery("from SRTYearRange where year = :year").setParameter("year",
                    year);

            list = query.list();

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }
        return list;
    }

    /*
     * Get the object for given year and srt type. (non-Javadoc)
     * @see
     * uk.nhs.nhsprotect.srt.dao.SRTYearRangeDao#getYearRange(java.lang.String,
     * java.lang.String)
     */
    public SRTYearRange getYearRange(String year, String srtType) throws SrtException {
        SRTYearRange srtYearRange = null;
        try {
            Query query = getCurrentSession().createQuery("from SRTYearRange where year = :year and srtType = :srtType")
                    .setParameter("year", year).setParameter("srtType", srtType);

            List<SRTYearRange> list = query.list();
            if (null != list && !list.isEmpty()) {
                srtYearRange = (SRTYearRange) list.get(0);
            }

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }

        return srtYearRange;
    }

    /*
     * Get distinct list of years. (non-Javadoc)
     * @see uk.nhs.nhsprotect.srt.dao.SRTYearRangeDao#getDistinctListOfYears()
     */
    public List<String> getDistinctListOfYears(String srtType) throws SrtException {
        List<String> list = null;
        try {
            Query query = getCurrentSession()
                    .createQuery("select distinct year from SRTYearRange where srtType = :srtType order by year desc");

            query.setString("srtType", srtType);
            list = query.list();

        } catch (HibernateException e) {
            throw new SrtException(e);
        } catch (Exception e) {
            throw new SrtException(e);
        }
        return list;
    }

}
