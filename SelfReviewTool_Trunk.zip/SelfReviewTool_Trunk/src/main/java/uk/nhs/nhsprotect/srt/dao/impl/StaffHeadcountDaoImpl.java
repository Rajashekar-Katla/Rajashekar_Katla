/**
 * 
 */
package uk.nhs.nhsprotect.srt.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import uk.nhs.nhsprotect.srt.dao.StaffHeadcountDao;
import uk.nhs.nhsprotect.srt.exception.SrtException;
import uk.nhs.nhsprotect.srt.model.StaffHeadcount;

/**
 * @author bvaidya
 */
@Repository("staffHeadcountDao")
public class StaffHeadcountDaoImpl extends SRTHibernateDaoSupportImpl implements StaffHeadcountDao {

    /*
     * (non-Javadoc)
     * @see uk.nhs.nhsprotect.srt.dao.StaffHeadcountDao#
     * getListOfStaffHeadcountOptions (java.lang.String, java.lang.String)
     */
    @SuppressWarnings("unchecked")
    public List<StaffHeadcount> getListOfStaffHeadcountOptions(String year, String srtType) throws SrtException {
        try {
            Query query = getCurrentSession()
                    .createQuery("from StaffHeadcount where year = :year and srtType = :srtType");
            query.setString("year", year);
            query.setString("srtType", srtType);
            List<StaffHeadcount> list = query.list();

            return list;
        } catch (HibernateException he) {
            throw new SrtException(he);
        } catch (Exception e) {
            throw new SrtException(e);
        }
    }

}
