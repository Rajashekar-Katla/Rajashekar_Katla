$(document)
		.ready(
				function() {
					
					createTabMap(tabMap);

					var form = $("#form1");
					var status = $('#status').val();
					var submitMessage = $('#submitMessage').val();
					var responseMessage = $('#responseMessage').val();

					$('.user_login')
							.find('table tbody tr')
							.prepend(
									'<td><b>STATUS: <span id="statusValue"></span></b></td>');
					$('#statusValue').html(status);

					// display submit message
					if (submitMessage != '') {
						//auto closes after 1000 ms
						$('#successMessage').fadeTo(2000, 500).slideUp(1000, function(){
						    $("#successMessage").alert('close');
						});
					}

					// display warning message
					if (responseMessage != '') {
						$('#warnMessage').removeClass('collapse');

					}

					$("#day1").numeric();
					$("#day2").numeric();
					$("#totalDays").numeric();

					$("#cost1").numeric();
					$("#cost2").numeric();
					$("#totalCost").numeric();

					$("#day1").attr('maxlength', '3');
					$("#day2").attr('maxlength', '3');
					$("#totalDays").attr('maxlength', '3');

					$('#day1, #day2').change(function() {

						var day1 = $("#day1").val();
						var day2 = $("#day2").val();
						var totalDays = (new Number(day1) + new Number(day2));

						if (totalDays == 0) {
							$('#totalDays').val('');
						} else {
							$('#totalDays').val(totalDays);
						}

					});

					$('#cost1, #cost2')
							.blur(function() {
								$(this).formatCurrency({
									colorize : true,
									negativeFormat : '-%s%n',
									roundToDecimalPlace : 2
								});
							})
							.keyup(
									function(e) {
										var e = window.event || e;
										var keyUnicode = e.charCode
												|| e.keyCode;
										if (e !== undefined) {
											switch (keyUnicode) {
											case 16:
												break; // Shift
											case 17:
												break; // Ctrl
											case 18:
												break; // Alt
											case 27:
												this.value = '';
												break; // Esc: clear entry
											case 35:
												break; // End
											case 36:
												break; // Home
											case 37:
												break; // cursor left
											case 38:
												break; // cursor up
											case 39:
												break; // cursor right
											case 40:
												break; // cursor down
											case 78:
												break; // N (Opera 9.63+ maps
											// the "." from the
											// number key section to
											// the "N" key too!)
											// (See:
											// http://unixpapa.com/js/key.html
											// search for ". Del")
											case 110:
												break; // . number block (Opera
											// 9.63+ maps the "."
											// from the number block
											// to the "N" key (78)
											// !!!)
											case 190:
												break; // .
											default:
												$(this)
														.formatCurrency(
																{
																	colorize : true,
																	negativeFormat : '-%s%n',
																	roundToDecimalPlace : -1,
																	eventOnDecimalsEntered : true
																});
											}
										}

										var cost1 = $("#cost1").val().replace(
												'£', '').replace(/,/g, '');
										var cost2 = $("#cost2").val().replace(
												'£', '').replace(/,/g, '');

										if (cost1 != '' && cost2 == '') {
											$("#totalCost").val(
													parseFloat(cost1));
										}

										if (cost2 != '' && cost1 == '') {
											$("#totalCost").val(
													parseFloat(cost2));
										}

										if (cost2 != '' && cost1 != '') {
											var totalCost = (parseFloat(cost1) + parseFloat(cost2));
											$("#totalCost").val(totalCost);
										}

										if (cost2 == '' && cost1 == '') {
											$("#totalCost").val('');
										}

										$("#totalCost").formatCurrency({
											colorize : true,
											negativeFormat : '-%s%n',
											roundToDecimalPlace : 2
										});
									});

					$('#general')
							.find("[id$='cost']")
							.each(
									function(i, element) {
										var id = $(element).attr('id');

										$('#' + id).numeric();

										$('#' + id)
												.blur(
														function() {
															$(this)
																	.formatCurrency(
																			{
																				colorize : true,
																				negativeFormat : '-%s%n',
																				roundToDecimalPlace : 2
																			});
														})
												.keyup(
														function(e) {
															var e = window.event
																	|| e;
															var keyUnicode = e.charCode
																	|| e.keyCode;
															if (e !== undefined) {
																switch (keyUnicode) {
																case 16:
																	break; // Shift
																case 17:
																	break; // Ctrl
																case 18:
																	break; // Alt
																case 27:
																	this.value = '';
																	break; // Esc:
																// clear
																// entry
																case 35:
																	break; // End
																case 36:
																	break; // Home
																case 37:
																	break; // cursor
																// left
																case 38:
																	break; // cursor
																// up
																case 39:
																	break; // cursor
																// right
																case 40:
																	break; // cursor
																// down
																case 78:
																	break; // N
																// (Opera
																// 9.63+
																// maps
																// the
																// "."
																// from
																// the
																// number
																// key
																// section
																// to
																// the
																// "N"
																// key
																// too!)
																// (See:
																// http://unixpapa.com/js/key.html
																// search
																// for
																// ".
																// Del")
																case 110:
																	break; // .
																// number
																// block
																// (Opera
																// 9.63+
																// maps
																// the
																// "."
																// from
																// the
																// number
																// block
																// to
																// the
																// "N"
																// key
																// (78)
																// !!!)
																case 190:
																	break; // .
																default:
																	$(this)
																			.formatCurrency(
																					{
																						colorize : true,
																						negativeFormat : '-%s%n',
																						roundToDecimalPlace : -1,
																						eventOnDecimalsEntered : true
																					});
																}
															}

															var cost = $(
																	'#' + id)
																	.val()
																	.replace(
																			'£',
																			'')
																	.replace(
																			/,/g,
																			'');
														});
									});

					$('#executiveBoardMember').change(
							function() {
								var executiveBoardMember = $(
										'#executiveBoardMember').val();
								$('#execAuth').html(executiveBoardMember);
							});

					$('.commentColumn').resizable({
						maxHeight : 250,
						maxWidth : 350,
						minHeight : 150,
						minWidth : 300
					});

					$(function() {
						$('#form-submit').click(function(e) {
							e.preventDefault();
							var l = Ladda.create(this);
							l.start();
							$('#submitType').val('submit');
							$('#form1').submit();
						});
					});
					
					$(function() {
						$('#form-cancel').click(function(e) {
							e.preventDefault();
							Ladda.stopAll();
							$('#form-draft').prop('disabled', false);
							
						});
					});

					$(function() {
						$('#form-confirm').click(function(e) {
							e.preventDefault();
							var validateResult = validateAll();
							if (validateResult) {
								var l = Ladda.create(this);
								l.start();
								$('#form-submit-modal').modal('show')
								$('#form-draft').prop('disabled', true);
							} else {
								$("#errors-dialog-modal").modal('show');
								return false;
							}

						});
					});

					$(function() {
						$('#form-draft').click(function(e) {
							// e.preventDefault();
							$('#submitType').val('Save As Draft');
							$('#form-confirm').prop('disabled', true);
							 
							var l = Ladda.create(this);
							l.start();
							$('#form1').submit();

						});
					});

				}); // document ready close

function createTabMap(tabMap) {
	tabMap["general"] = 'tab1';
	tabMap["strategic_governance"] = 'tab2';
	tabMap["informandinvolve"] = 'tab3';
	tabMap["preventanddeter"] = 'tab4';
	tabMap["holdtoaccount"] = 'tab5';
	tabMap["executiveauthorisation"] = 'tab6';
}

function validateAll() {
	var submitFlag = new Array();

	var general = validate("general");
	submitFlag.push(general);

	var strategicGovernance = validate("strategic_governance");
	submitFlag.push(strategicGovernance);

	var informandinvolve = validate("informandinvolve");
	submitFlag.push(informandinvolve);

	var preventanddeter = validate("preventanddeter");
	submitFlag.push(preventanddeter);

	var holdtoaccount = validate("holdtoaccount");
	submitFlag.push(holdtoaccount);

	var executiveauthorisation = validate("executiveauthorisation");
	submitFlag.push(executiveauthorisation);

	var error = $.inArray(true, submitFlag) > -1;

	if (error) {
		$("#errors-dialog-modal").modal('show');
		return false;
	} else {
		return true;
	}
}

function validate(sectionId) {
	var anyErrors = false;
	var tabId = tabMap[sectionId];

	if (sectionId == 'general') {

		var listOfQuestions = new Array();

		$('#general :input').each(function(i, elementNames) {
			if ($(elementNames).attr('name') == 'elementNameQuestionId') {
				listOfQuestions.push($(elementNames));
			}
		});

		$(listOfQuestions).each(function(index, elementName) {
			var elementId = $(elementName).val();
			var validationType = $('#' + elementId + 'validationType').val();
			if (!validateText($('#' + elementId), validationType)) {
				highlight('#' + elementId);
				anyErrors = true;
			} else {
				clearHighlight('#' + elementId);
			}

		});
	} else if (sectionId == 'executiveauthorisation') {

		if (!$('#declarationCheckbox').prop('checked')) {
			highlightDeclaration('#declaration');
			anyErrors = true;
		} else {
			clearDeclaration('#declaration');
		}
	} else {
		var fieldsetRadioMap = {};

		$('.' + sectionId + 'Fieldset').each(
				function(i, fieldset) {
					var radioArray = [];

					$('#' + $(fieldset).attr('id')).find("input[type='radio']")
							.each(function(j, radio) {
								if (!$(radio).prop('checked')) {
									radioArray.push(false);
								} else {
									radioArray.push(true);
								}
								fieldsetRadioMap[j] = radioArray;

							});

					$(fieldsetRadioMap).each(function(index, fieldsetMap) {
						if ($.inArray(true, fieldsetMap[index]) == -1) {
							highlight(fieldset);
							anyErrors = true;
						} else {
							clearHighlight(fieldset);
						}
					});

				});

	}

	if (anyErrors) {
		highlightSection('#' + tabId);
		return true;
	} else {
		clearSectionHighlight('#' + tabId);
		return false;
	}
}

function clearHighlight(elementName) {
	if ($(elementName).hasClass("fieldset_error")) {
		$(elementName).removeClass("fieldset_error");
	}
}

function highlight(elementName) {
	if (!$(elementName).hasClass("fieldset_error")) {
		$(elementName).addClass("fieldset_error");
	}
}
function highlightDeclaration(declarationCheckbox) {
	$(declarationCheckbox).addClass('fieldset_error');
}

function clearDeclaration(declarationCheckbox) {
	$(declarationCheckbox).removeClass('fieldset_error');
}

function highlightSection(section) {
	$(section).addClass('fieldset_error');
}

function clearSectionHighlight(section) {
	$(section).removeClass('fieldset_error');
}

function updateFormField(form_field, value) {
	$('input[name=' + form_field + ']').val(value);
}

function updateStatusPane(statuspane, score) {
	var array_options = [ 'btn-gray', 'btn-red', 'btn-green', 'btn-amber' ];
	var el = 'btn-gray';
	var tooltip = "This section has not yet been rated. Click to view"

	if (score == 1) {
		el = 'btn-red';
		tooltip = "This section has been rated as red risk. Click to view"
	} else if (score == 2) {
		el = 'btn-amber';
		tooltip = "This section has been rated as amber risk. Click to view"
	} else {
		el = 'btn-green';
		tooltip = "This section has been rated as green risk.  Click to view"
	}

	var status = $('#' + statuspane);
	if (null != status) {
		array_options = array_options.filter(function(e) {
			return e !== el
		});
		$.each(array_options, function(index, value) {
			$(status).removeClass(value);
		});
		$(status).addClass(el);
		$(status).attr('data-original-title', tooltip);
	}
}

function clearHighlightForSaveAsDraft() {
	$.each(tabMap, function(key, value) {
		if (key != 'general') {
			clearSectionHighlight('#' + value);
		}
		if (key == 'executiveauthorisation') {
			clearDeclaration('#declaration');
		}
		if (key != 'general' && key != 'executiveauthorisation') {
			$('.dataTable tr td .' + key + 'Fieldset').each(
					function(i, fieldset) {
						var radioArray = [];
						clearHighlight(fieldset);
					});

			$('#' + key).find('textarea').each(function(i, textArea) {
				clearHighlight(textArea);
			});
		}
	});
}
(function($) {
	
	$('#sidebar').scrollNav({
	    sections: 'h2',
	    subSections: false,
	    sectionElem: 'section',
	    showHeadline: true,
	    headlineText: 'Scroll To',
	    showTopLink: true,
	    topLinkText: 'Top',
	    fixedMargin: 40,
	    scrollOffset: 40,
	    animated: true,
	    speed: 500,
	    insertTarget: this.selector,
	    insertLocation: 'insertBefore',
	    arrowKeys: false,
	    scrollToHash: true,
	    onInit: null,
	    onRender: null,
	    onDestroy: null
	});
    /*var element = $('#sidebar'),
        originalY = element.offset().top;

    // Space between element and top of screen (when scrolling)
    var topMargin = 20;

    // Should probably be set in CSS; but here just for emphasis
    element.css('position', 'relative');

    $(window).on('scroll', function(event) {
        var scrollTop = $(window).scrollTop();

        element.stop(false, false).animate({
            top: scrollTop < originalY
                    ? 0
                    : scrollTop - originalY + topMargin
        }, 300);
    });*/
})(jQuery);