/* Global variable */
var tabMap = {};
var fields = [];
var count = 0;

/* Document ready load functions */

$(document).ready(function() {
	setScrollToTop();

	//enable popovers
	$('[data-toggle="popover"]').popover();
	//enable tooltips
	$('[data-toggle="tooltip"]').tooltip();

	$("#resptable").on("click", "tr", function(e) {
		e.preventDefault;
		var _self = $(this);
		window.location = _self.children().children('a').attr('href');
	});

	$('.section-nav').click(function() {
		$($(this).data('target')).tab('show');

	});

	/**
	 * Method to activate the next SRT tab
	 */
	$('.srtSectionNext').click(function() {
		$('.nav-tabs > .active').next('li').find('a[data-toggle="tab"]').tab('show');
		$('body,html').animate({
			scrollTop : 0
		}, 700);
	});

	/**
	 * Method to activate the previous SRT tab
	 *
	 */
	$('.srtSectionPrevious').click(function() {
		$('.nav-tabs > .active').prev('li').find('a[data-toggle="tab"]').tab('show');
		$('body,html').animate({
			scrollTop : 0
		}, 700);
	});


});

/**
 * Method to display modal for shared access and update fields with correct values.
 */
$(document).on("click", ".open-sharedAccessModal", function(e) {
	e.preventDefault();
	var _self = $(this);
	//console.log(_self.data);
	var orgName = _self.data('orgname');
	var orgCode = _self.data('orgcode');
	var sharedAccessLogin = _self.data('login');
	var sharedAccessPassword = _self.data('password');
	$(".modal-title #orgName").text(orgName);
	$(".modal-title #orgCode").text(orgCode);
	$(".modal-body #sharedAccessLogin").val(sharedAccessLogin);
	$(".modal-body #sharedAccessPassword").val(sharedAccessPassword);
	$('#sharedAccessModal').modal('show');
});

/**
 * Method to update SRT message modal with content
 */
$(document).on("click", ".confirmAction", function(e) {
	e.preventDefault();

	var message = $(this).data('message').replace("\n", "<br/><br/>");
	var action = $(this).data('action');
	$("#message-dialog-modal-title").html($(this).data('title'));
	$(".modal-body #modalMessage").html(message);
	$(".modal-body #modalAction").val(action);
	$('#message-dialog-modal').modal('show');
	$('#actionConfirm').on("click", function() {
		if (action === 'corpQuit') {
			$('#logout').submit();
		} else {
			window.location = $(".modal-body #modalAction").val();
		}
	});

});


/**
 * Method to add scroll to top button when user scrolls past offset.
 */
function setScrollToTop() {
	var offset = 300,
		offset_opacity = 1200,
		scroll_top_duration = 700,
		$back_to_top = $('.cd-top');

	$(window).scroll(
		function() {
			($(this).scrollTop() > offset) ? $back_to_top
				.addClass('cd-is-visible') : $back_to_top
				.removeClass('cd-is-visible cd-fade-out');
			if ($(this).scrollTop() > offset_opacity) {
				$back_to_top.addClass('cd-fade-out');
			}
		});

	$back_to_top.on('click', function(event) {
		event.preventDefault();
		$('body,html').animate({
			scrollTop : 0
		}, scroll_top_duration);
	});
}