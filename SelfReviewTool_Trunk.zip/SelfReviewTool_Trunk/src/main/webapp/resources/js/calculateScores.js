
$(document).ready(function(){

	var allStGovRadiosArray = [];
	var allInformInvolveRadioArray = [];
	var allPreventDeterRadioArray = [];
	var allHoldToAccountRadioArray = [];
	var allStGovRadiosChecked = false;
	var allInformInvolveRadiosChecked = false;
	var allPreventDeterRadiosChecked = false;
	var allHoldToAccountRadiosChecked = false;	
	var selectedStGovRadiosArray = [];
	var selectedInformInvolveRadiosArray =  [];
	var selectedPrecentedDeterRadiosArray = [];
	var selectedHoldToAccountRadiosArray =  [];
	var status = $('#status').val();
	
	$('.questionnaireTab tr td .strategic_governanceFieldset').each(function(i,strFSet){
			$(strFSet).find("input[type='radio']").each(function(j,strRadio){
				var id = $(strRadio).attr('id');
				if($.inArray(id, allStGovRadiosArray) == -1){
				   allStGovRadiosArray.push(id);
				}
			});
		});
	
	$('.questionnaireTab tr td .informandinvolveFieldset').each(function(i,iniFSet){
			$(iniFSet).find("input[type='radio']").each(function(j,iniRadio){
				var id = $(iniRadio).attr('id');
				if($.inArray(id, allInformInvolveRadioArray) == -1){
					allInformInvolveRadioArray.push(id);
				}
			});
		});
	
	$('.questionnaireTab tr td .preventanddeterFieldset').each(function(i,strFSet){
			$(strFSet).find("input[type='radio']").each(function(j,strRadio){
				var id = $(strRadio).attr('id');
				if($.inArray(id, allPreventDeterRadioArray) == -1){
					allPreventDeterRadioArray.push(id);
				}
			});
		});
	
	$('.questionnaireTab tr td .holdtoaccountFieldset').each(function(i,strFSet){
			$(strFSet).find("input[type='radio']").each(function(j,strRadio){
				var id = $(strRadio).attr('id');
				if($.inArray(id, allHoldToAccountRadioArray) == -1){
					allHoldToAccountRadioArray.push(id);
				}
			});
		});
	
	if(status !='TODO'){
		updateScore();
	}
	
	
	$(".questionnaireTab tr td .strategic_governanceFieldset input[type='radio']").change(function(){
			var id = $(this).attr('id');
			if($.inArray(id, selectedStGovRadiosArray) == -1){
				selectedStGovRadiosArray.push(id);
			}
			
			if(checkAllSGovRadiosChecked()){
				allStGovRadiosChecked = true;
				
					var strgScore = calculateSectionScoreAjax("tab1Content");
					updateFormField("strgSecScore", strgScore);
					updateStatusPane("STRGStatus", strgScore);
			}
			
			checkAllSectionsChecked();
	});
	
	$(".questionnaireTab tr td .informandinvolveFieldset input[type='radio']").change(function(){
		var id = $(this).attr('id');
		if($.inArray(id, selectedInformInvolveRadiosArray) == -1){
			selectedInformInvolveRadiosArray.push(id);
		}
		
		if(checkAllInformInvolveRadiosChecked()){
			allInformInvolveRadiosChecked = true;
			
				var strgScore = calculateSectionScoreAjax("tab2Content");
				updateFormField("INISecScore", strgScore);
				updateStatusPane("INIStatus", strgScore);
		}
		
		checkAllSectionsChecked();
    });
	
	$(".questionnaireTab tr td .preventanddeterFieldset input[type='radio']").change(function(){
		var id = $(this).attr('id');
		if($.inArray(id, selectedPrecentedDeterRadiosArray) == -1){
			selectedPrecentedDeterRadiosArray.push(id);
		}
		
		if(checkAllPreventDeterRadiosChecked()){
			allPreventDeterRadiosChecked = true;
			
				var strgScore = calculateSectionScoreAjax("tab3Content");
				updateFormField("PNDSecScore", strgScore);
				updateStatusPane("PNDStatus", strgScore);
		}
		
		checkAllSectionsChecked();
    });
	
	$(".questionnaireTab tr td .holdtoaccountFieldset input[type='radio']").change(function(){
		var id = $(this).attr('id');
		if($.inArray(id, selectedHoldToAccountRadiosArray) == -1){
			selectedHoldToAccountRadiosArray.push(id);
		}
		
		if(checkAllHoldToAccountRadiosChecked()){
			allHoldToAccountRadiosChecked = true;
			
				var strgScore = calculateSectionScoreAjax("tab4Content");
				updateFormField("HTASecScore", strgScore);
				updateStatusPane("HTAStatus", strgScore);
		}
		
		checkAllSectionsChecked();
    });
	
	 
function updateScore(){
	
	$('.questionnaireTab tr td .strategic_governanceFieldset').each(function(i,strFSet){
		$(strFSet).find("input[type='radio']:checked").each(function(j,strRadio){
			var id = $(strRadio).attr('id');
			if($.inArray(id, selectedStGovRadiosArray) == -1){
				selectedStGovRadiosArray.push(id);
			}
		});
		
		if(checkAllSGovRadiosChecked()){
			allStGovRadiosChecked = true;
			
				var strgScore = calculateSectionScoreAjax("tab1Content");
				updateFormField("strgSecScore", strgScore);
				updateStatusPane("STRGStatus", strgScore);
		}
	});

 $('.questionnaireTab tr td .informandinvolveFieldset').each(function(i,iniFSet){
		$(iniFSet).find("input[type='radio']:checked").each(function(j,iniRadio){
			var id = $(iniRadio).attr('id');
			if($.inArray(id, selectedInformInvolveRadiosArray) == -1){
				selectedInformInvolveRadiosArray.push(id);
			}
		});
		if(checkAllInformInvolveRadiosChecked()){
			allInformInvolveRadiosChecked = true;
			
				var strgScore = calculateSectionScoreAjax("tab2Content");
				updateFormField("INISecScore", strgScore);
				updateStatusPane("INIStatus", strgScore);
		}
	});

$('.questionnaireTab tr td .preventanddeterFieldset').each(function(i,strFSet){
		$(strFSet).find("input[type='radio']:checked").each(function(j,strRadio){
			var id = $(strRadio).attr('id');
			if($.inArray(id, selectedPrecentedDeterRadiosArray) == -1){
				selectedPrecentedDeterRadiosArray.push(id);
			}
		});
		
		if(checkAllPreventDeterRadiosChecked()){
			allPreventDeterRadiosChecked = true;
				var strgScore = calculateSectionScoreAjax("tab3Content");
				updateFormField("PNDSecScore", strgScore);
				updateStatusPane("PNDStatus", strgScore);
		}
		
	});

$('.questionnaireTab tr td .holdtoaccountFieldset').each(function(i,strFSet){
		$(strFSet).find("input[type='radio']:checked").each(function(j,strRadio){
			var id = $(strRadio).attr('id');
			if($.inArray(id, selectedHoldToAccountRadiosArray) == -1){
				selectedHoldToAccountRadiosArray.push(id);
			}
		});
		
		if(checkAllHoldToAccountRadiosChecked()){
			allHoldToAccountRadiosChecked = true;
				var strgScore = calculateSectionScoreAjax("tab4Content");
				updateFormField("HTASecScore", strgScore);
				updateStatusPane("HTAStatus", strgScore);
		}
		
	});
	checkAllSectionsChecked();
}// update score end

	function checkAllSGovRadiosChecked(){
		return $(allStGovRadiosArray).not(selectedStGovRadiosArray).length == 0 && $(selectedStGovRadiosArray).not(allStGovRadiosArray).length == 0;
	}
	
	function checkAllInformInvolveRadiosChecked(){
		return $(allInformInvolveRadioArray).not(selectedInformInvolveRadiosArray).length == 0 && $(selectedInformInvolveRadiosArray).not(allInformInvolveRadioArray).length == 0;
	}
	
	function checkAllPreventDeterRadiosChecked(){
		return $(allPreventDeterRadioArray).not(selectedPrecentedDeterRadiosArray).length == 0 && $(selectedPrecentedDeterRadiosArray).not(allPreventDeterRadioArray).length == 0;
	}
	
	function checkAllHoldToAccountRadiosChecked(){
		return $(allHoldToAccountRadioArray).not(selectedHoldToAccountRadiosArray).length == 0 && $(selectedHoldToAccountRadiosArray).not(allHoldToAccountRadioArray).length == 0;
	}
	
	function checkAllSectionsChecked(){
		if(allStGovRadiosChecked && allInformInvolveRadiosChecked && allPreventDeterRadiosChecked && allHoldToAccountRadiosChecked){
			var TotalScore = calculateSRTScoreAjax();
			updateFormField("totalScore", TotalScore);
			updateStatusPane("SRTStatus", TotalScore);
		}
	}

function calculateSectionScoreAjax(sectionId) {
	
	$("#currentSection").val(sectionId);
	var result;
	var formData = $("#form1").serialize();
	$.ajax({
		type : "POST",
		url : "calculateSectionScore",
		async : false,
		data : formData,
		success : function(data) {
			result = data
		},error: function (xhr, ajaxOptions, thrownError) {
	        //console.log(xhr.status);
	        //console.log(thrownError);
	      }
	});
	return result;
}

function calculateSRTScoreAjax() {
	
	var result;
	
	$.ajax({
		type : "POST",
		url : "calculateSRTScore",
		async : false,
		data : $("#form1").serialize(),
		success : function(data) {
			result = data
		},error: function (xhr, ajaxOptions, thrownError) {
	        //console.log(xhr.status);
	        //console.log(thrownError);
	      }
	});
	return result;
}


});// document ready close

