
function validateText(elementNameId, validationType) {
	var result = false;
	var fieldValue = $(elementNameId).val();

	if (validationType == "string") {
		result = isValidLength(fieldValue, "Y", "1000");
	}
	if (validationType == "email") {
		result = isValidEmail(fieldValue, "Y");
	}
	if (validationType == "number") {
		result = isValidNumber(fieldValue, "Y", "3");
	}
	if (validationType == "cost") {
		result = isValidCost(fieldValue, "Y");
	}
	if (validationType == "date") {
		result = isValidDate(fieldValue, "Y");
	}
	if (validationType == "none") {
		result = true;
	}

	console.log("Validating [" + elementNameId + "] for type [" + validationType + "] with value [" + fieldValue + "] result = [" + result + "]");
	return result;
}

function isValidLength(fieldValue, isMandatory, len) {
	var result = true;
	if (isMandatory === 'Y') {
		if (isEmpty(fieldValue) || fieldValue.length > len)
			result = false;
	} else {
		result = fieldValue.length <= len;
	}

	//console.log("validating length of [" + fieldValue + "] is <=  [" + len + "] with value [" + fieldValue + "] is mandatory = [" + isMandatory + "] result  = [" + result + "]");
	return result;


}

function isEmpty(fieldValue) {
	var result = false;
	if (fieldValue == null || $.trim(fieldValue).length <= 0) {
		result =  true;
	} 
	//console.log("validating fieldvalue [" + fieldValue + "] is emtpy result  = [" + result + "]");
	return result;
}

function isValidEmail(fieldValue, isMandatory) {
	if (isMandatory == 'Y' && isEmpty(fieldValue)) {
		return false;
	} else if (isMandatory == 'N' && isEmpty(fieldValue)) {
		return true;
	} else {
		var regEx = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
		return regEx.test(fieldValue);

	}
}

function isValidNumber(fieldValue, isMandatory, len) {
	if (isMandatory == 'Y' && isEmpty(fieldValue)) {
		return false;
	} else if (isMandatory == 'N' && isEmpty(fieldValue)) {
		return true;
	} else {
		return true;
	}
}

function isValidCost(fieldValue, isMandatory) {
	if (isMandatory == 'Y' && isEmpty(fieldValue)) {
		return false;
	} else {
		return true;
	}
}

function isValidDate(fieldValue, isMandatory) {
	if (isMandatory == 'Y' && isEmpty(fieldValue)) {
		return false;
	} else if (isMandatory == 'N' && isEmpty(fieldValue)) {
		return true;
	} else {
		var toCheck = /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;

		if (fieldValue.match(toCheck)) {
			return true;
		} else {
			return false;
		}
	}
}

function validateTextAreaValue(textAreaValue) {
	var result = false;
	result = isValidLength(textAreaValue, "Y", "750");
	//console.log("Validating textAreaValue [" + textAreaValue + "] result = [" + result + "]");
	return result;
}