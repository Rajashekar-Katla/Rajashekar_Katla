var currentTab = "tab0";

function main(newTab) {

	var currentTabContent=currentTab+"Content";
	var newTabContent= newTab + "Content";

	var currentTabContentElement = document.getElementById(currentTabContent);
	var newTabContentElement = document.getElementById(newTabContent);

	currentTabContentElement.style.display = 'none';
	newTabContentElement.style.display = 'block';

	var currentTabElement = document.getElementById(currentTab);
	var newTabElement = document.getElementById(newTab);
	
	
	currentTabElement.className="none";
	newTabElement.className ="current";
	currentTabContent = newTabContent;
	currentTab =newTab;

}

function load() {

	// adding ids and events to anchors

	var tabs_ul = document.getElementById("tabs");

	// alert("tabs "+tabs_ul);

	if (null != tabs_ul && "" != tabs_ul) 
	{
		var tab_li = tabs_ul.getElementsByTagName("li");

		// alert("tab list length "+tab_li.length);
		
		if (null != tab_li && "" != tab_li) 
		{
			for (i = 0; i < tab_li.length; i++) {

				// alert("i "+i);

				var tab_li_a = tab_li[i].getElementsByTagName("a");

				// alert("current tab list anchor "+tab_li_a);

				var attribute = "tab" + i;

				// alert("setting attribute "+attribute);

				tab_li_a[0].setAttribute("id", attribute);

				// attach the onclick event handler
				attachOnclickToAnchor(tab_li_a[0]);

				// alert(i+" "+tab_li_a[0].innerHTML+" "+attribute);
			}
		}
	}

	// adding ids to tab contents

	var tab_contents = document.getElementsByTagName("div");

	var attribute_index = 0;

	// alert(tab_contents.length);

	for (j = 0; j < tab_contents.length; j++) {

		// alert(j+" "+tab_contents[j].className );

		if (tab_contents[j].className == "tabsContent") {

			var attribute = "tab" + attribute_index + "Content";
			attribute_index = attribute_index + 1;

			// alert(attribute_index+" setting attribute "+attribute);

			tab_contents[j].setAttribute("id", attribute);

		}

	}

	
	/*
	  if (tab_li_a[0].addEventListener) {
		
		  tab_li_a[0].addEventListener("click", function(){main(tab_li_a[0].id);}); 
	  }
	  else {
		  tab_li_a[0].attachEvent('onclick',function(){main(tab_li_a[0].id);}); 
	  }
	  */
	 
	if (null != document.getElementById(currentTab)) 
	{
		main(currentTab);
//		document.getElementById(currenttabContent).style.display = 'block';
	}
	/*
	 * var anchor = document.getElementById("tab0"); anchor.onclick =
	 * function(){ main("tab0"); }
	 */

}


function attachOnclickToAnchor(tabId){
	  if (tabId.addEventListener) {
			
		  tabId.addEventListener("click", function(){main(tabId.id);}); 
	  }
	  else {
		  tabId.attachEvent('onclick',function(){main(tabId.id);}); 
	  }
}