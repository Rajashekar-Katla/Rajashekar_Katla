package rewards.rest;


/* TODO 10: Annotate with @ResponseStatus to return a 409 Conflict when thrown from a controller method.
			Run the test again and make sure both the test methods passes. */

@SuppressWarnings("serial")
public class DiningAlreadyProcessedException extends RuntimeException {

}
