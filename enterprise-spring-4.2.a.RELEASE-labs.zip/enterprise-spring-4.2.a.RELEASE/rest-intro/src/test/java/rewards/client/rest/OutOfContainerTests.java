package rewards.client.rest;

import static org.junit.Assert.*;

import java.util.UUID;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

//	TODO 12 (PART 2): Stop any server you may have running.

//	TODO 13 (PART 2): Add two static imports above, 
//	one for org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*
//	one for org.springframework.test.web.servlet.result.MockMvcResultMatchers.*

//	TODO 14 (PART 2): Annotate this test class with @RunWith, @SpringApplicationConfiguration, and @WebAppConfiguration.  
//	Be sure to include both config files in @SpringApplicationConfiguration (see which ones below.)
//  ("/system-test-config.xml" and "file:./src/main/webapp/WEB-INF/rest-servlet.xml")
//	Run the test, it should pass, though we really haven't done any testing yet.
public class OutOfContainerTests {
	
	String diningXml = "<dining xmlns=\"http://www.springsource.com/dining-request\">" +
			"<amount value=\"100.00\"/>" +
			"<creditcard number=\"1234123412341234\"/>" +
			"<merchant number=\"1234567890\"/>" +
			"<timestamp> " +
			"<date>2009-04-21</date>" +
			"</timestamp>" +
			"</dining>";

	String diningJson = 
			"{ " +
			"\"amount\": {\"value\": \"100.00\"}, " +
			"\"creditcard\": {\"number\": \"1234123412341234\"}, " +
			"\"merchant\": {\"number\": \"1234567890\"}, " +
			"\"timestamp\": {\"date\": \"2009-04-21\"} " +
			"}";
	
	
	//	TODO 14 (PART 2): Add a member variables for the WebApplicationContext.  Autowire it.
	//	TODO 16 (PART 2): Add a member variable for MockMvc.  Do NOT autowire it.

    @Before
    public void setup() {
    	//	TODO 17 (PART 2): Before each test runs, build the mockMvc 
    	//	using MockMvcBuilders and the autowired WebApplicationContext:
    }

    
    public void test(String input, MediaType mediaType) throws Exception {

		String txId = UUID.randomUUID().toString();

		//	TODO 18 (PART 2): Use the mockMvc to perform a POST to "/dining/{transactionId}".
		//	Pass the txId (declared above) as a unique transaction ID.
		//	Use the "input" String variable as the posted content.
		//	Use the "mediaType" variable as the posted content-type.
		//	Ensure that the returned status code is 201 (created).
		//	Populate the 'result' variable with the result of the call.
    	MvcResult result = null;
    	
    	//	TODO 19 (PART 2): Obtain the "location" response header from the returned result.
    	//	Assert that it is not null.
    	String location = null;
    	
    	
    	//	TODO 20 (PART 2): Use the mockMvc to perform a GET to the location you just obtained in the last step.
    	//	Set application/json as the desired media type.
		//	Ensure that the returned status code is 200 (ok).
    	//  Use JSON path to check the content of the response.
		//	Populate the 'result' variable with the result of the call.
    	result = null;

    	String conf = result.getResponse().getContentAsString();
    	System.out.println(conf);
    	
    	assertTrue( conf.indexOf(txId)>0 );
    	assertTrue( conf.indexOf("8.0")>0 );
    	assertTrue( conf.indexOf("100.0")>0 );
    	assertTrue( conf.indexOf("1234567890")>0 );
    	
    	
    }

    //	TODO 21 (PART 2): Remove the @Ignore annotation and run this test.  
    //	It should pass using XML as the posted input.
    //	Double-check - your server should NOT be running.
    @Test
    @Ignore
    public void testXml() throws Exception {
    	test(diningXml, MediaType.APPLICATION_XML);
    }
    
    //	TODO 22 (PART 2): Remove the @Ignore annotation and run this test.  
    //	It should pass using JSON as the posted input.
    @Test
    @Ignore
    public void testJson() throws Exception {
    	test(diningJson, MediaType.APPLICATION_JSON);
    }
 
}
